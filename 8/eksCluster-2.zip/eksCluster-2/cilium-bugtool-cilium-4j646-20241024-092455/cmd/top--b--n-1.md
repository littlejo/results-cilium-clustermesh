top - 09:24:57 up 10 min,  0 users,  load average: 0.46, 0.53, 0.31
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 70.0 us, 30.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    968.2 free,    765.2 used,   2102.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2894.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1404700 188580  77608 S   6.7   4.8   0:22.06 cilium-+
   2805 root      20   0 1240432  15984  10640 S   6.7   0.4   0:00.03 cilium-+
    391 root      20   0 1228848   3820   3140 S   0.0   0.1   0:00.01 cilium-+
   2801 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   2809 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   2836 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2858 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2877 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
