1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 02:c1:f5:cd:eb:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.200/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3007sec preferred_lft 3007sec
    inet6 fe80::c1:f5ff:fecd:eb67/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:48:23:4a:30:38 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c48:23ff:fe4a:3038/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d4:8c:52:e4:9b brd ff:ff:ff:ff:ff:ff
    inet 10.2.0.161/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::34d4:8cff:fe52:e49b/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:f4:6e:ac:89:56 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58f4:6eff:feac:8956/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:1e:93:b4:d4:91 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::801e:93ff:feb4:d491/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc6d3e55619805@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:d0:08:a8:6b:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4d0:8ff:fea8:6bb1/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcb010f7dd4388@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:eb:38:26:91:7a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0eb:38ff:fe26:917a/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc6ea98be53e5b@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:91:e9:dd:97:bf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9091:e9ff:fedd:97bf/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc467576798b18@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:9c:a0:3b:a9:28 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::609c:a0ff:fe3b:a928/64 scope link 
       valid_lft forever preferred_lft forever
19: lxcb29fc3d997cf@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:7e:22:05:e4:6f brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::347e:22ff:fe05:e46f/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc60b0de84790a@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:47:2d:36:39:f0 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::a847:2dff:fe36:39f0/64 scope link 
       valid_lft forever preferred_lft forever
