35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:15:01+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
71: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:15:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
72: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
75: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
447: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:15:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
448: sched_cls  name tail_handle_ipv4  tag 00f0977c757fc470  gpl
	loaded_at 2024-10-24T09:15:43+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
449: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:15:43+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
450: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:15:43+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
479: sched_cls  name handle_policy  tag 616789f44dfb6bd4  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,100,33,72,97,31,76,67,32,29,30
	btf_id 145
483: sched_cls  name tail_handle_ipv4  tag a2954f89c3ba3688  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 151
484: sched_cls  name tail_ipv4_ct_egress  tag 629ff9bd8da927c2  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 155
485: sched_cls  name tail_handle_arp  tag 7adf8870733cbb34  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 156
487: sched_cls  name tail_ipv4_to_endpoint  tag e26d0b1b866913ff  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,97,31,99,32,29,30
	btf_id 157
489: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 159
490: sched_cls  name cil_from_container  tag 1fb9c22bdb8a9ef4  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 160
491: sched_cls  name __send_drop_notify  tag 894c2fec1cd01df6  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 161
492: sched_cls  name tail_ipv4_ct_ingress  tag 0c9ea926d7a5ee33  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 162
493: sched_cls  name tail_handle_ipv4_cont  tag 99039833e235faed  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 164
494: sched_cls  name cil_from_container  tag cf65d83125722776  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 165
496: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 168
497: sched_cls  name tail_handle_ipv4_cont  tag d3b7d2aeb255e865  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,97,74,75,31,68,66,69,99,32,29,30,73
	btf_id 167
499: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 172
500: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 173
502: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 175
503: sched_cls  name tail_handle_ipv4_from_host  tag 5627298e0f26cb36  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 176
504: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 177
507: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 181
508: sched_cls  name handle_policy  tag d2457c41f4cecbec  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 169
509: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 183
511: sched_cls  name tail_ipv4_to_endpoint  tag ebe10f1c8c59eadc  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 182
512: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 186
513: sched_cls  name tail_ipv4_ct_egress  tag 629ff9bd8da927c2  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 185
514: sched_cls  name __send_drop_notify  tag c94b7fe1ae089ff8  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 188
515: sched_cls  name tail_handle_ipv4_from_host  tag 5627298e0f26cb36  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 187
517: sched_cls  name tail_handle_ipv4_from_host  tag 5627298e0f26cb36  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 192
520: sched_cls  name tail_handle_ipv4  tag 5d0d7b3532dd637f  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 189
521: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 195
522: sched_cls  name __send_drop_notify  tag 9409c4c4e2844c6e  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 196
523: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 197
524: sched_cls  name tail_handle_arp  tag 8774d84740a12fe6  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 200
525: sched_cls  name tail_ipv4_ct_ingress  tag 6d03c2e200731e82  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 199
526: sched_cls  name tail_ipv4_ct_ingress  tag a07ef527abd0c279  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 201
527: sched_cls  name tail_handle_ipv4  tag d8ddd3630777d0e8  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 202
529: sched_cls  name __send_drop_notify  tag 1238f1ae63d3f0af  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 204
530: sched_cls  name tail_handle_arp  tag 2fa4eb6f9e8bd511  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 205
531: sched_cls  name tail_ipv4_to_endpoint  tag eeb4f2bd9ed7df32  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 206
532: sched_cls  name cil_from_container  tag c67a4a13e62f3e18  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,68
	btf_id 207
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 208
534: sched_cls  name tail_handle_ipv4_cont  tag 6679efaa7bd99736  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 209
535: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 210
536: sched_cls  name handle_policy  tag e29e05f8be7246ac  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 211
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: sched_cls  name tail_ipv4_to_endpoint  tag a24872f82237a758  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,128,33,74,75,72,127,31,129,32,29,30
	btf_id 227
593: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,129
	btf_id 228
594: sched_cls  name handle_policy  tag 06154ca570bc2943  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,129,74,75,128,33,72,127,31,76,67,32,29,30
	btf_id 229
595: sched_cls  name cil_from_container  tag 5f556c0e2ed06e75  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 129,68
	btf_id 230
597: sched_cls  name tail_handle_arp  tag 72cd1cf75ce7ab6f  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,129
	btf_id 232
598: sched_cls  name __send_drop_notify  tag 895f80e0e8bff930  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 233
599: sched_cls  name tail_handle_ipv4_cont  tag 458f03d8b6127993  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,128,33,127,74,75,31,68,66,69,129,32,29,30,73
	btf_id 234
600: sched_cls  name tail_ipv4_ct_egress  tag 6e08241d401b6c1b  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 235
601: sched_cls  name tail_ipv4_ct_ingress  tag b8c96027bf07436a  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,129,74,75,128,76
	btf_id 236
602: sched_cls  name tail_handle_ipv4  tag 721b13a23e47049e  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,129
	btf_id 237
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
619: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
622: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
676: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
679: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
680: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
683: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
684: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
687: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3365: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,639
	btf_id 3191
3366: sched_cls  name tail_handle_ipv4  tag ef9c45710dea9728  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,639
	btf_id 3192
3367: sched_cls  name tail_handle_ipv4_cont  tag 1c9305c33703fd32  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,640,33,145,74,75,31,68,66,69,639,32,29,30,73
	btf_id 3193
3368: sched_cls  name tail_ipv4_to_endpoint  tag 0c4c8514f6536285  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,640,33,74,75,72,145,31,639,32,29,30
	btf_id 3194
3369: sched_cls  name tail_ipv4_ct_ingress  tag f473012ebb66ccf4  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,639,74,75,640,76
	btf_id 3195
3370: sched_cls  name cil_from_container  tag c57099e3cbe756f1  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 639,68
	btf_id 3196
3372: sched_cls  name handle_policy  tag d13b4ecd72cfb74d  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,639,74,75,640,33,72,145,31,76,67,32,29,30
	btf_id 3198
3373: sched_cls  name tail_handle_arp  tag 02beb48533ff4e42  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,639
	btf_id 3199
3374: sched_cls  name __send_drop_notify  tag de084ce4ac195e7b  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3200
3375: sched_cls  name tail_ipv4_ct_egress  tag c97cd691cca9f37a  gpl
	loaded_at 2024-10-24T09:23:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,639,74,75,640,76
	btf_id 3201
3663: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,694
	btf_id 3516
3664: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,696
	btf_id 3518
3665: sched_cls  name tail_ipv4_to_endpoint  tag 0903640f75e89362  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,695,33,74,75,72,140,31,696,32,29,30
	btf_id 3520
3666: sched_cls  name handle_policy  tag 617f94ce35c88419  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,694,74,75,693,33,72,137,31,76,67,32,29,30
	btf_id 3519
3667: sched_cls  name tail_handle_ipv4_cont  tag ba7fd7282626d94a  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,695,33,140,74,75,31,68,66,69,696,32,29,30,73
	btf_id 3521
3668: sched_cls  name __send_drop_notify  tag aff144c81e9cf848  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3523
3669: sched_cls  name tail_ipv4_to_endpoint  tag 766372d77c1befaf  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,693,33,74,75,72,137,31,694,32,29,30
	btf_id 3522
3670: sched_cls  name __send_drop_notify  tag 53b94502bfc4f143  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3525
3671: sched_cls  name tail_handle_ipv4  tag ed948992d66997d1  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,696
	btf_id 3524
3672: sched_cls  name tail_handle_ipv4  tag b49bb9f51acd254e  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,694
	btf_id 3526
3673: sched_cls  name tail_handle_arp  tag a70b6eb91749656f  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,694
	btf_id 3528
3675: sched_cls  name tail_ipv4_ct_ingress  tag 24a7c7a22e50f017  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,694,74,75,693,76
	btf_id 3530
3676: sched_cls  name tail_handle_ipv4_cont  tag dc67b8ac5d093877  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,693,33,137,74,75,31,68,66,69,694,32,29,30,73
	btf_id 3531
3677: sched_cls  name handle_policy  tag 6bc86b9304f2089e  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,696,74,75,695,33,72,140,31,76,67,32,29,30
	btf_id 3527
3678: sched_cls  name tail_ipv4_ct_egress  tag 824d25ca5a950dcd  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,694,74,75,693,76
	btf_id 3532
3679: sched_cls  name cil_from_container  tag ab214ea1750fe94c  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 694,68
	btf_id 3534
3680: sched_cls  name tail_ipv4_ct_ingress  tag 5f47f42f7bac58f4  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,696,74,75,695,76
	btf_id 3533
3681: sched_cls  name cil_from_container  tag 948ccd5132d32a0a  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 696,68
	btf_id 3535
3682: sched_cls  name tail_ipv4_ct_egress  tag a89985bf19d7cbcf  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,696,74,75,695,76
	btf_id 3536
3683: sched_cls  name tail_handle_arp  tag f90b7302a05da103  gpl
	loaded_at 2024-10-24T09:24:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,696
	btf_id 3537
