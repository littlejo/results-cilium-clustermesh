USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2836  0.0  0.0 1228744 3596 ?        Ssl  09:24   0:00 /bin/gops stats 1
root        2809  0.0  0.0 1228744 3600 ?        Ssl  09:24   0:00 /bin/gops pprof-heap 1
root        2805  0.0  0.3 1240432 15664 ?       Ssl  09:24   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2847  0.0  0.0   6408  1648 ?        R    09:24   0:00  \_ ps auxfw
root        2848  0.0  0.0      4     4 ?        R    09:24   0:00  \_ [bash]
root        2801  0.0  0.1 1229000 4056 ?        Ssl  09:24   0:00 /bin/gops pprof-cpu 1
root           1  3.9  4.8 1404700 188580 ?      Ssl  09:15   0:22 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.0 1228848 3820 ?        Sl   09:15   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
