IP ADDRESS         LOCAL ENDPOINT INFO
10.2.0.36:0        id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0   
172.31.140.200:0   (localhost)                                                                                       
10.2.0.185:0       id=165   sec_id=220496 flags=0x0000 ifindex=11  mac=46:36:24:79:0E:96 nodemac=D2:EB:38:26:91:7A   
10.2.0.161:0       (localhost)                                                                                       
10.2.0.34:0        id=2904  sec_id=4     flags=0x0000 ifindex=7   mac=B2:1B:CB:22:75:F3 nodemac=82:1E:93:B4:D4:91    
10.2.0.154:0       id=1991  sec_id=220496 flags=0x0000 ifindex=9   mac=36:6D:35:91:4A:8F nodemac=06:D0:08:A8:6B:B1   
10.2.0.168:0       id=1164  sec_id=225266 flags=0x0000 ifindex=15  mac=76:3C:8B:11:C5:68 nodemac=92:91:E9:DD:97:BF   
10.2.0.242:0       id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28   
10.2.0.25:0        id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F   
