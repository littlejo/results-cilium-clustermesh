# Cilium debug information

#### Cilium encryption



#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
165        Disabled           Disabled          220496     k8s:eks.amazonaws.com/component=coredns                                               10.2.0.185   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
782        Disabled           Disabled          207272     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.2.0.242   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
941        Disabled           Disabled          200572     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.2.0.36    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
1164       Disabled           Disabled          225266     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.2.0.168   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
1971       Disabled           Disabled          221974     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.2.0.25    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
1991       Disabled           Disabled          220496     k8s:eks.amazonaws.com/component=coredns                                               10.2.0.154   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh3                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2101       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1a                                                                 
                                                           reserved:host                                                                                              
2904       Disabled           Disabled          4          reserved:health                                                                       10.2.0.34    ready   
```

#### BPF Policy Get 165

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5770    61        0        
Allow    Ingress     1          ANY          NONE         disabled    54310   627       0        
Allow    Egress      0          ANY          NONE         disabled    12369   126       0        

```


#### BPF CT List 165

```
Invalid argument: unknown type 165
```


#### Endpoint Get 165

```
[
  {
    "id": 165,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-165-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "61bdbb8e-5cee-4b91-8f38-1ae7c040de9b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-165",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:43.090Z",
            "success-count": 2
          },
          "uuid": "884bc04d-f789-4549-aab1-7d1f8be06b6b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-n67ss",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:43.090Z",
            "success-count": 1
          },
          "uuid": "b546d0ee-1530-46b2-bbd3-c0d2b7baa507"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-165",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:45.957Z",
            "success-count": 1
          },
          "uuid": "8acf6eb7-c535-4aa7-9ec0-1b5ee7b255ad"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (165)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:23.140Z",
            "success-count": 60
          },
          "uuid": "3cf688a4-8a49-43bb-9010-9ff9dc1a7c07"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fbb3207931e04e3c1f375df195319b521537b3aad9c230e4a3f583136f56b93f:eth0",
        "container-id": "fbb3207931e04e3c1f375df195319b521537b3aad9c230e4a3f583136f56b93f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-n67ss",
        "pod-name": "kube-system/coredns-586b798467-n67ss"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 220496,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.185",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d2:eb:38:26:91:7a",
        "interface-index": 11,
        "interface-name": "lxcb010f7dd4388",
        "mac": "46:36:24:79:0e:96"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 220496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 220496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 165

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 165

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:45Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:43Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 220496

```
ID       LABELS
220496   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 782

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 782

```
Invalid argument: unknown type 782
```


#### Endpoint Get 782

```
[
  {
    "id": 782,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-782-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c1351de7-b994-4576-8ff1-fd3efed23e6a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-782",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.855Z",
            "success-count": 2
          },
          "uuid": "8924043c-f146-403e-87c2-9894c614fc96"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-zr62r",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.853Z",
            "success-count": 1
          },
          "uuid": "61c3ccca-0d89-4ed9-9720-cf14eac57278"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-782",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.946Z",
            "success-count": 1
          },
          "uuid": "57a239f5-f86a-4dce-986a-55b2fdbc7ce6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (782)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.885Z",
            "success-count": 33
          },
          "uuid": "08e4bfc5-9538-4901-988a-639924db9731"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fbb9ed78db56ebf65a82c2213b8e70594fd92b579945133e99fa5e68ac932310:eth0",
        "container-id": "fbb9ed78db56ebf65a82c2213b8e70594fd92b579945133e99fa5e68ac932310",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-zr62r",
        "pod-name": "cilium-test-1/client-974f6c69d-zr62r"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 207272,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:47Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.242",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "62:9c:a0:3b:a9:28",
        "interface-index": 17,
        "interface-name": "lxc467576798b18",
        "mac": "76:06:c7:e3:97:64"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 207272,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 207272,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 782

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 782

```
Timestamp              Status   State                   Message
2024-10-24T09:24:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 207272

```
ID       LABELS
207272   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### BPF Policy Get 941

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4399     33        0        
Allow    Ingress     1          ANY          NONE         disabled    301539   3529      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 941

```
Invalid argument: unknown type 941
```


#### Endpoint Get 941

```
[
  {
    "id": 941,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-941-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9357c0fb-da81-4187-9e3a-245f8ab0da98"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-941",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:16.788Z",
            "success-count": 2
          },
          "uuid": "797f702f-a382-4933-9fb1-4a4152ae40d3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-2mcww",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:16.785Z",
            "success-count": 1
          },
          "uuid": "810bac46-7d17-4e2b-b94b-1f9bf7f6d486"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-941",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:16.819Z",
            "success-count": 1
          },
          "uuid": "5351a39f-c957-475f-8672-f6a19c3c4c02"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (941)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:26.816Z",
            "success-count": 33
          },
          "uuid": "91cacc2d-2aed-4018-81a2-2fe1c55418b7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "78e5aeb0076c5192b57ad917dfb01c215c02eb2f1669e7f5b3770fa656d047b0:eth0",
        "container-id": "78e5aeb0076c5192b57ad917dfb01c215c02eb2f1669e7f5b3770fa656d047b0",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-2mcww",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-2mcww"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 200572,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:23Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.36",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "aa:47:2d:36:39:f0",
        "interface-index": 21,
        "interface-name": "lxc60b0de84790a",
        "mac": "22:48:82:13:1f:d7"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 200572,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 200572,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 941

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 941

```
Timestamp              Status   State                   Message
2024-10-24T09:23:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:16Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 200572

```
ID       LABELS
200572   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 1164

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    211441   2000      0        
Allow    Ingress     1          ANY          NONE         disabled    200723   2075      0        
Allow    Egress      0          ANY          NONE         disabled    284904   2587      0        

```


#### BPF CT List 1164

```
Invalid argument: unknown type 1164
```


#### Endpoint Get 1164

```
[
  {
    "id": 1164,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1164-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c62dc598-7b2f-42b7-8fdd-a389c7c8fad7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:23:38.258Z",
            "success-count": 2
          },
          "uuid": "b76fc417-a387-4ca7-92f1-874d49fba8c4"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-bb44565f9-727ls",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:38.257Z",
            "success-count": 1
          },
          "uuid": "35853e4c-2ba0-4776-9d5a-e30739ac47f9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1164",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:38.289Z",
            "success-count": 1
          },
          "uuid": "5ff608da-34b7-45fd-9fb5-dcc92596c4fe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1164)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:28.304Z",
            "success-count": 43
          },
          "uuid": "e5147bef-ab18-4aca-aa2e-f5f30eb76e2a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "e32ff168bdfc32c9d744992d913669198860bfaa400a221ced89092cc0f24730:eth0",
        "container-id": "e32ff168bdfc32c9d744992d913669198860bfaa400a221ced89092cc0f24730",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-bb44565f9-727ls",
        "pod-name": "kube-system/clustermesh-apiserver-bb44565f9-727ls"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 225266,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=bb44565f9"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.168",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "92:91:e9:dd:97:bf",
        "interface-index": 15,
        "interface-name": "lxc6ea98be53e5b",
        "mac": "76:3c:8b:11:c5:68"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 225266,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 225266,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1164

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1164

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:18:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:38Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:18:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:18:38Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:18:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 225266

```
ID       LABELS
225266   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1971

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1971

```
Invalid argument: unknown type 1971
```


#### Endpoint Get 1971

```
[
  {
    "id": 1971,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1971-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "19ef6f98-d7c7-4bab-8001-18b5d6a9423d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1971",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.954Z",
            "success-count": 2
          },
          "uuid": "c37749cc-ec4e-43a0-899f-d76eb15651d9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-hbsf4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.952Z",
            "success-count": 1
          },
          "uuid": "0d08926b-f133-44a2-b5e2-0cec24ca53f8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1971",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:16.009Z",
            "success-count": 1
          },
          "uuid": "fc6f5286-f64d-4251-aad2-f018d284c57b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1971)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.987Z",
            "success-count": 33
          },
          "uuid": "aecd3611-afc5-4d16-b22d-c8cf584aafd2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d1903de83231997ae59b587c432d1c08af954b895d629d149a6092f49981e627:eth0",
        "container-id": "d1903de83231997ae59b587c432d1c08af954b895d629d149a6092f49981e627",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-hbsf4",
        "pod-name": "cilium-test-1/client2-57cf4468f-hbsf4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 221974,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:47Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.25",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "36:7e:22:05:e4:6f",
        "interface-index": 19,
        "interface-name": "lxcb29fc3d997cf",
        "mac": "52:2a:91:1b:2e:80"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 221974,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 221974,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1971

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1971

```
Timestamp              Status   State                   Message
2024-10-24T09:24:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:08Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:59Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added

```


#### Identity get 221974

```
ID       LABELS
221974   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 1991

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5606    63        0        
Allow    Ingress     1          ANY          NONE         disabled    53650   617       0        
Allow    Egress      0          ANY          NONE         disabled    12774   130       0        

```


#### BPF CT List 1991

```
Invalid argument: unknown type 1991
```


#### Endpoint Get 1991

```
[
  {
    "id": 1991,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1991-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "52a82913-5c51-4dff-bb06-fa896531e86b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1991",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:43.020Z",
            "success-count": 2
          },
          "uuid": "a07c23ab-825c-479f-b4fc-539d7b99b95c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-lllk4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:43.020Z",
            "success-count": 1
          },
          "uuid": "17e019fc-507e-46b1-8081-dc033877ac00"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1991",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:45.933Z",
            "success-count": 1
          },
          "uuid": "1a904e43-542f-454c-8eb5-1290388b01c3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1991)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:23.073Z",
            "success-count": 60
          },
          "uuid": "7267e551-13bd-4146-8669-1796b814eb8a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "40d8865063cb33e75039bd0db7ec520dfc58932ce19898a435619aec28cc6eca:eth0",
        "container-id": "40d8865063cb33e75039bd0db7ec520dfc58932ce19898a435619aec28cc6eca",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-lllk4",
        "pod-name": "kube-system/coredns-586b798467-lllk4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 220496,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh3",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.154",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "06:d0:08:a8:6b:b1",
        "interface-index": 9,
        "interface-name": "lxc6d3e55619805",
        "mac": "36:6d:35:91:4a:8f"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 220496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 220496,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1991

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1991

```
Timestamp              Status    State                   Message
2024-10-24T09:20:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:38Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:19:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:37Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:36Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:36Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:36Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:36Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:55Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:55Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:55Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:55Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:54Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:54Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:54Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:54Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:44Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:15:43Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:43Z   OK        ready                   Set identity for this endpoint
2024-10-24T09:15:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:42Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 220496

```
ID       LABELS
220496   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh3
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2101

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2101

```
Invalid argument: unknown type 2101
```


#### Endpoint Get 2101

```
[
  {
    "id": 2101,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2101-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "80d3741d-fd83-43d3-bfad-9f6702580214"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2101",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:41.475Z",
            "success-count": 2
          },
          "uuid": "9eabf278-e29e-4c67-9c9c-8f6842dee295"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2101",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:42.579Z",
            "success-count": 1
          },
          "uuid": "3ac9674f-edcc-409b-8532-7554de73bc43"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "36:d4:8c:52:e4:9b",
        "interface-name": "cilium_host",
        "mac": "36:d4:8c:52:e4:9b"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2101

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2101

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T09:15:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:45Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T09:15:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T09:15:43Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:41Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2904

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23570   293       0        
Allow    Ingress     1          ANY          NONE         disabled    7438    85        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2904

```
Invalid argument: unknown type 2904
```


#### Endpoint Get 2904

```
[
  {
    "id": 2904,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2904-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "894808d4-f1a4-4ae8-ab10-de70a308ba99"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2904",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:42.526Z",
            "success-count": 2
          },
          "uuid": "6babb7a9-5669-4c3a-9406-eb49469e3264"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2904",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:45.913Z",
            "success-count": 1
          },
          "uuid": "b96ccba2-69a6-4fd6-99c9-57749dffe774"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.2.0.34",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "82:1e:93:b4:d4:91",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "b2:1b:cb:22:75:f3"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2904

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2904

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:38Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:45Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:42Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.244.238:443 (active)    
                                          2 => 172.31.135.214:443 (active)    
2    10.100.152.246:443    ClusterIP      1 => 172.31.140.200:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.2.0.185:53 (active)         
                                          2 => 10.2.0.154:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.2.0.185:9153 (active)       
                                          2 => 10.2.0.154:9153 (active)       
5    10.100.58.4:2379      ClusterIP      1 => 10.2.0.168:2379 (active)       
6    10.100.168.114:8080   ClusterIP      1 => 10.2.0.36:8080 (active)        
```

#### Policy get

```
:
 []
Revision: 157

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=9) "10.2.0.25": (string) (len=37) "cilium-test-1/client2-57cf4468f-hbsf4",
  (string) (len=9) "10.2.0.36": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-2mcww",
  (string) (len=10) "10.2.0.161": (string) (len=6) "router",
  (string) (len=9) "10.2.0.34": (string) (len=6) "health",
  (string) (len=10) "10.2.0.154": (string) (len=36) "kube-system/coredns-586b798467-lllk4",
  (string) (len=10) "10.2.0.185": (string) (len=36) "kube-system/coredns-586b798467-n67ss",
  (string) (len=10) "10.2.0.242": (string) (len=36) "cilium-test-1/client-974f6c69d-zr62r",
  (string) (len=10) "10.2.0.168": (string) (len=49) "kube-system/clustermesh-apiserver-bb44565f9-727ls"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.140.200": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023b6630)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40002178c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40002178c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x400235fad0)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4003637a20)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4003637ad0)(frontends:[10.100.58.4]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x40023ae000)(frontends:[10.100.168.114]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x400235f970)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x400235fa20)(frontends:[10.100.152.246]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400154c0f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-t2scb": (*k8s.Endpoints)(0x4000b39a00)(172.31.140.200:4244/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400154c0f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-l2zpm": (*k8s.Endpoints)(0x40038660d0)(10.2.0.154:53/TCP[us-east-1a],10.2.0.154:53/UDP[us-east-1a],10.2.0.154:9153/TCP[us-east-1a],10.2.0.185:53/TCP[us-east-1a],10.2.0.185:53/UDP[us-east-1a],10.2.0.185:9153/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000d7e238)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-85k69": (*k8s.Endpoints)(0x40030fda00)(10.2.0.168:2379/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4001622c98)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-ghqlx": (*k8s.Endpoints)(0x4003c73860)(10.2.0.36:8080/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400154c0e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003757930)(172.31.135.214:443/TCP,172.31.244.238:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4000448770)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40028b13b0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40049aad50
  },
  gcTrigger: (chan struct {}) (cap=1) 0x40028c6960,
  gcExited: (chan struct {}) 0x40028c69c0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40008ed880)({
     ObserverVec: (*prometheus.HistogramVec)(0x40019b7768)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6bd0)({
       metricMap: (*prometheus.metricMap)(0x40007c6c00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f260)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40008ed980)({
     ObserverVec: (*prometheus.HistogramVec)(0x40019b7770)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6c60)({
       metricMap: (*prometheus.metricMap)(0x40007c6cc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f2c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40008eda80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b7778)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6d20)({
       metricMap: (*prometheus.metricMap)(0x40007c6d50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f320)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40008edb00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b7780)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6db0)({
       metricMap: (*prometheus.metricMap)(0x40007c6de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f380)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40008edb80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b7788)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6ea0)({
       metricMap: (*prometheus.metricMap)(0x40007c6ed0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f3e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40008edc80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b7790)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6f30)({
       metricMap: (*prometheus.metricMap)(0x40007c6f60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f440)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40008edd00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b7798)({
      MetricVec: (*prometheus.MetricVec)(0x40007c6fc0)({
       metricMap: (*prometheus.metricMap)(0x40007c6ff0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f4a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40008edd80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40019b77a0)({
      MetricVec: (*prometheus.MetricVec)(0x40007c7080)({
       metricMap: (*prometheus.metricMap)(0x40007c70b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f500)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40008ede00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40019b77a8)({
      MetricVec: (*prometheus.MetricVec)(0x40007c7110)({
       metricMap: (*prometheus.metricMap)(0x40007c7140)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x400198f560)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4000448770)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40002641c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001434f78)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 500ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 23083213                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 23083213                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 23083213                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006400000 rw-p 00000000 00:00 0 
4006400000-4008000000 ---p 00000000 00:00 0 
ffff73ae6000-ffff73bf7000 rw-p 00000000 00:00 0 
ffff73bf7000-ffff73c38000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c38000-ffff73c79000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c79000-ffff73c7b000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c7b000-ffff73c7d000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff73c7d000-ffff74214000 rw-p 00000000 00:00 0 
ffff74214000-ffff74314000 rw-p 00000000 00:00 0 
ffff74314000-ffff74325000 rw-p 00000000 00:00 0 
ffff74325000-ffff76325000 rw-p 00000000 00:00 0 
ffff76325000-ffff763a5000 ---p 00000000 00:00 0 
ffff763a5000-ffff763a6000 rw-p 00000000 00:00 0 
ffff763a6000-ffff963a5000 ---p 00000000 00:00 0 
ffff963a5000-ffff963a6000 rw-p 00000000 00:00 0 
ffff963a6000-ffffb6335000 ---p 00000000 00:00 0 
ffffb6335000-ffffb6336000 rw-p 00000000 00:00 0 
ffffb6336000-ffffba327000 ---p 00000000 00:00 0 
ffffba327000-ffffba328000 rw-p 00000000 00:00 0 
ffffba328000-ffffbab25000 ---p 00000000 00:00 0 
ffffbab25000-ffffbab26000 rw-p 00000000 00:00 0 
ffffbab26000-ffffbac25000 ---p 00000000 00:00 0 
ffffbac25000-ffffbac85000 rw-p 00000000 00:00 0 
ffffbac85000-ffffbac87000 r--p 00000000 00:00 0                          [vvar]
ffffbac87000-ffffbac88000 r-xp 00000000 00:00 0                          [vdso]
ffffe2b8b000-ffffe2bac000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.2.0.0/24, 
Allocated addresses:
  10.2.0.154 (kube-system/coredns-586b798467-lllk4)
  10.2.0.161 (router)
  10.2.0.168 (kube-system/clustermesh-apiserver-bb44565f9-727ls)
  10.2.0.185 (kube-system/coredns-586b798467-n67ss)
  10.2.0.242 (cilium-test-1/client-974f6c69d-zr62r)
  10.2.0.25 (cilium-test-1/client2-57cf4468f-hbsf4)
  10.2.0.34 (health)
  10.2.0.36 (cilium-test-1/echo-same-node-86d9cc975c-2mcww)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 34c9eb74c9baac8e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   46s ago        never        0       no error   
  ct-map-pressure                                                    18s ago        never        0       no error   
  daemon-validate-config                                             39s ago        never        0       no error   
  dns-garbage-collector-job                                          50s ago        never        0       no error   
  endpoint-1164-regeneration-recovery                                never          never        0       no error   
  endpoint-165-regeneration-recovery                                 never          never        0       no error   
  endpoint-1971-regeneration-recovery                                never          never        0       no error   
  endpoint-1991-regeneration-recovery                                never          never        0       no error   
  endpoint-2101-regeneration-recovery                                never          never        0       no error   
  endpoint-2904-regeneration-recovery                                never          never        0       no error   
  endpoint-782-regeneration-recovery                                 never          never        0       no error   
  endpoint-941-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        4m51s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               18s ago        never        0       no error   
  ipcache-inject-labels                                              42s ago        never        0       no error   
  k8s-heartbeat                                                      21s ago        never        0       no error   
  link-cache                                                         3s ago         never        0       no error   
  local-identity-checkpoint                                          38s ago        never        0       no error   
  node-neighbor-link-updater                                         8s ago         never        0       no error   
  remote-etcd-cmesh1                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh2                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh4                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh5                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh6                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh7                                                 5m53s ago      never        0       no error   
  remote-etcd-cmesh8                                                 5m53s ago      never        0       no error   
  resolve-identity-1164                                              1m51s ago      never        0       no error   
  resolve-identity-165                                               4m46s ago      never        0       no error   
  resolve-identity-1971                                              13s ago        never        0       no error   
  resolve-identity-1991                                              4m46s ago      never        0       no error   
  resolve-identity-2101                                              4m48s ago      never        0       no error   
  resolve-identity-2904                                              4m47s ago      never        0       no error   
  resolve-identity-782                                               14s ago        never        0       no error   
  resolve-identity-941                                               13s ago        never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-zr62r                5m14s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-hbsf4               5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-2mcww       5m13s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-bb44565f9-727ls   6m51s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-lllk4                9m46s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-n67ss                9m46s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                     9m48s ago      never        0       no error   
  sync-policymap-1164                                                6m51s ago      never        0       no error   
  sync-policymap-165                                                 9m43s ago      never        0       no error   
  sync-policymap-1971                                                5m13s ago      never        0       no error   
  sync-policymap-1991                                                9m43s ago      never        0       no error   
  sync-policymap-2101                                                9m47s ago      never        0       no error   
  sync-policymap-2904                                                9m43s ago      never        0       no error   
  sync-policymap-782                                                 5m13s ago      never        0       no error   
  sync-policymap-941                                                 5m13s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1164)                                  11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (165)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1971)                                  3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1991)                                  6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (782)                                   3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (941)                                   13s ago        never        0       no error   
  sync-utime                                                         48s ago        never        0       no error   
  write-cni-file                                                     9m51s ago      never        0       no error   
Proxy Status:            OK, ip 10.2.0.161, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 196608, max 262143
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 21.68   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
bpf-ct-timeout-regular-any:1m0s
vtep-mask:
enable-ipv6-big-tcp:false
bpf-policy-map-max:16384
local-router-ipv6:
enable-well-known-identities:false
pprof:false
enable-host-legacy-routing:false
k8s-heartbeat-timeout:30s
enable-k8s-endpoint-slice:true
agent-labels:
kvstore-lease-ttl:15m0s
dnsproxy-lock-timeout:500ms
tofqdns-proxy-response-max-delay:100ms
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
disable-iptables-feeder-rules:
ipam-multi-pool-pre-allocation:
hubble-redact-http-urlquery:false
hubble-export-file-compress:false
bpf-lb-sock-hostns-only:false
l2-announcements-renew-deadline:5s
enable-external-ips:false
allow-localhost:auto
hubble-export-allowlist:
pprof-port:6060
bpf-fragments-map-max:8192
vtep-mac:
crd-wait-timeout:5m0s
set-cilium-is-up-condition:true
enable-local-node-route:true
monitor-aggregation-flags:all
hubble-recorder-sink-queue-size:1024
enable-hubble-recorder-api:true
cni-exclusive:true
enable-health-checking:true
envoy-config-retry-interval:15s
install-no-conntrack-iptables-rules:false
ipv4-node:auto
trace-sock:true
routing-mode:tunnel
enable-l2-announcements:false
policy-queue-size:100
enable-hubble:true
cni-log-file:/var/run/cilium/cilium-cni.log
hubble-redact-kafka-apikey:false
mke-cgroup-mount:
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-host-port:false
mesh-auth-mutual-connect-timeout:5s
k8s-sync-timeout:3m0s
node-port-bind-protection:true
fixed-identity-mapping:
k8s-require-ipv4-pod-cidr:false
config-sources:config-map:kube-system/cilium-config
ipv6-cluster-alloc-cidr:f00d::/64
enable-ipsec-key-watcher:true
bpf-filter-priority:1
enable-nat46x64-gateway:false
bpf-nat-global-max:524288
enable-stale-cilium-endpoint-cleanup:true
k8s-require-ipv6-pod-cidr:false
enable-runtime-device-detection:true
monitor-aggregation-interval:5s
enable-envoy-config:false
nodes-gc-interval:5m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-redact-enabled:false
bgp-announce-pod-cidr:false
kvstore-opt:
kvstore-max-consecutive-quorum-errors:2
mesh-auth-mutual-listener-port:0
allow-icmp-frag-needed:true
agent-health-port:9879
enable-endpoint-health-checking:true
ipam-default-ip-pool:default
enable-ipv6-masquerade:true
enable-custom-calls:false
ipv6-range:auto
enable-ip-masq-agent:false
enable-wireguard-userspace-fallback:false
tofqdns-proxy-port:0
mtu:0
cgroup-root:/run/cilium/cgroupv2
enable-svc-source-range-check:true
enable-sctp:false
bpf-ct-timeout-service-tcp:2h13m20s
enable-recorder:false
nat-map-stats-entries:32
enable-ipsec-xfrm-state-caching:true
ipsec-key-file:
nodeport-addresses:
encryption-strict-mode-allow-remote-node-identities:false
k8s-client-burst:20
dnsproxy-concurrency-limit:0
l2-announcements-retry-period:2s
enable-route-mtu-for-cni-chaining:false
proxy-max-connection-duration-seconds:0
enable-bpf-masquerade:false
bpf-lb-dsr-l4-xlate:frontend
enable-bpf-tproxy:false
enable-ipv4-egress-gateway:false
identity-allocation-mode:crd
local-router-ipv4:
lib-dir:/var/lib/cilium
hubble-drop-events-reasons:auth_required,policy_denied
kvstore-periodic-sync:5m0s
http-retry-count:3
bpf-lb-acceleration:disabled
node-port-algorithm:random
hubble-redact-http-userinfo:true
ipv6-mcast-device:
tofqdns-enable-dns-compression:true
enable-policy:default
config:
enable-session-affinity:false
enable-cilium-endpoint-slice:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
hubble-metrics:
hubble-redact-http-headers-deny:
hubble-export-denylist:
bpf-lb-sock-terminate-pod-connections:false
hubble-export-file-path:
enable-k8s:true
hubble-redact-http-headers-allow:
enable-bpf-clock-probe:false
version:false
encrypt-interface:
dnsproxy-enable-transparent-mode:true
auto-direct-node-routes:false
l2-announcements-lease-duration:15s
bpf-lb-rss-ipv6-src-cidr:
certificates-directory:/var/run/cilium/certs
envoy-keep-cap-netbindservice:false
tofqdns-idle-connection-grace-period:0s
cluster-pool-ipv4-mask-size:24
enable-bgp-control-plane:false
proxy-xff-num-trusted-hops-ingress:0
bpf-auth-map-max:524288
tunnel-protocol:vxlan
ipv4-pod-subnets:
enable-auto-protect-node-port-range:true
ipsec-key-rotation-duration:5m0s
policy-accounting:true
bpf-events-trace-enabled:true
force-device-detection:false
egress-gateway-policy-map-max:16384
envoy-config-timeout:2m0s
cflags:
hubble-event-buffer-capacity:4095
log-system-load:false
enable-metrics:true
k8s-api-server:
bpf-lb-service-map-max:0
clustermesh-enable-endpoint-sync:false
encrypt-node:false
proxy-prometheus-port:0
mesh-auth-spire-admin-socket:
proxy-gid:1337
enable-monitor:true
controller-group-metrics:
cmdref:
srv6-encap-mode:reduced
k8s-service-cache-size:128
route-metric:0
bpf-lb-map-max:65536
ipv6-native-routing-cidr:
operator-prometheus-serve-addr::9963
exclude-local-address:
direct-routing-skip-unreachable:false
bpf-ct-global-any-max:262144
direct-routing-device:
enable-host-firewall:false
enable-masquerade-to-route-source:false
debug:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
hubble-socket-path:/var/run/cilium/hubble.sock
config-dir:/tmp/cilium/config-map
wireguard-persistent-keepalive:0s
dnsproxy-concurrency-processing-grace-period:0s
endpoint-bpf-prog-watchdog-interval:30s
nat-map-stats-interval:30s
enable-l2-pod-announcements:false
prepend-iptables-chains:true
ipv4-service-range:auto
proxy-portrange-max:20000
bpf-events-policy-verdict-enabled:true
enable-icmp-rules:true
enable-bandwidth-manager:false
envoy-base-id:0
disable-envoy-version-check:false
k8s-client-connection-timeout:30s
debug-verbose:
unmanaged-pod-watcher-interval:15
ipam-cilium-node-update-rate:15s
tofqdns-pre-cache:
enable-pmtu-discovery:false
enable-encryption-strict-mode:false
multicast-enabled:false
identity-gc-interval:15m0s
iptables-lock-timeout:5s
gops-port:9890
enable-mke:false
enable-local-redirect-policy:false
dnsproxy-insecure-skip-transparent-mode-check:false
cni-chaining-mode:none
devices:
cluster-pool-ipv4-cidr:10.2.0.0/16
ip-masq-agent-config-path:/etc/config/ip-masq-agent
exclude-node-label-patterns:
tofqdns-max-deferred-connection-deletes:10000
enable-node-selector-labels:false
tunnel-port:0
arping-refresh-period:30s
metrics:
conntrack-gc-interval:0s
use-full-tls-context:false
enable-k8s-networkpolicy:true
enable-ipsec:false
kube-proxy-replacement-healthz-bind-address:
bpf-lb-maglev-table-size:16381
endpoint-gc-interval:5m0s
mesh-auth-queue-size:1024
encryption-strict-mode-cidr:
http-normalize-path:true
enable-xdp-prefilter:false
bpf-ct-timeout-regular-tcp-syn:1m0s
k8s-service-proxy-name:
bpf-lb-maglev-map-max:0
enable-k8s-terminating-endpoint:true
mesh-auth-enabled:true
ipam:cluster-pool
bpf-lb-rss-ipv4-src-cidr:
enable-active-connection-tracking:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
prometheus-serve-addr:
proxy-idle-timeout-seconds:60
enable-l7-proxy:true
join-cluster:false
bpf-neigh-global-max:524288
read-cni-conf:
bpf-ct-global-tcp-max:524288
enable-wireguard:false
max-controller-interval:0
log-opt:
ipv4-native-routing-cidr:
hubble-drop-events-interval:2m0s
hubble-prefer-ipv6:false
remove-cilium-node-taints:true
bpf-map-event-buffers:
k8s-client-qps:10
ipv4-service-loopback-address:169.254.42.1
vlan-bpf-bypass:
bpf-root:/sys/fs/bpf
hubble-export-file-max-size-mb:10
custom-cni-conf:false
static-cnp-path:
tofqdns-min-ttl:0
k8s-client-connection-keep-alive:30s
enable-identity-mark:true
operator-api-serve-addr:127.0.0.1:9234
clustermesh-sync-timeout:1m0s
bpf-policy-map-full-reconciliation-interval:15m0s
mesh-auth-rotated-identities-queue-size:1024
envoy-log:
procfs:/host/proc
bpf-ct-timeout-regular-tcp-fin:10s
clustermesh-ip-identities-sync-timeout:1m0s
endpoint-queue-size:25
node-port-mode:snat
vtep-endpoint:
clustermesh-enable-mcs-api:false
bpf-lb-rev-nat-map-max:0
hubble-export-file-max-backups:5
cilium-endpoint-gc-interval:5m0s
cluster-name:cmesh3
envoy-secrets-namespace:
kvstore-connectivity-timeout:2m0s
policy-cidr-match-mode:
node-port-acceleration:disabled
trace-payloadlen:128
log-driver:
bpf-map-dynamic-size-ratio:0.0025
bpf-lb-dsr-dispatch:opt
agent-liveness-update-interval:1s
bpf-node-map-max:16384
cluster-health-port:4240
kube-proxy-replacement:false
conntrack-gc-max-interval:0s
service-no-backend-response:reject
hubble-skip-unknown-cgroup-ids:true
enable-cilium-health-api-server-access:
enable-ipip-termination:false
monitor-aggregation:medium
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-lb-affinity-map-max:0
gateway-api-secrets-namespace:
disable-external-ip-mitigation:false
cni-chaining-target:
enable-ipv4-fragment-tracking:true
proxy-connect-timeout:2
ipv6-pod-subnets:
proxy-portrange-min:10000
node-port-range:
enable-high-scale-ipcache:false
hubble-listen-address::4244
dnsproxy-socket-linger-timeout:10
enable-gateway-api:false
bpf-lb-sock:false
enable-vtep:false
dns-max-ips-per-restored-rule:1000
vtep-cidr:
synchronize-k8s-nodes:true
enable-ipv4-masquerade:true
preallocate-bpf-maps:false
bpf-events-drop-enabled:true
dnsproxy-lock-count:131
ingress-secrets-namespace:
tofqdns-endpoint-max-ip-per-hostname:50
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
external-envoy-proxy:true
hubble-disable-tls:false
container-ip-local-reserved-ports:auto
fqdn-regex-compile-lru-size:1024
policy-trigger-interval:1s
proxy-admin-port:0
datapath-mode:veth
enable-xt-socket-fallback:true
enable-srv6:false
enable-endpoint-routes:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
bpf-lb-external-clusterip:false
enable-node-port:false
http-retry-timeout:0
use-cilium-internal-ip-for-ipsec:false
install-iptables-rules:true
bpf-lb-mode:snat
set-cilium-node-taints:true
tofqdns-dns-reject-response-code:refused
enable-ipv4-big-tcp:false
enable-health-check-loadbalancer-ip:false
hubble-metrics-server:
bpf-lb-source-range-map-max:0
enable-tracing:false
socket-path:/var/run/cilium/cilium.sock
egress-masquerade-interfaces:ens+
cluster-id:3
hubble-event-queue-size:0
enable-service-topology:false
proxy-xff-num-trusted-hops-egress:0
hubble-drop-events:false
bypass-ip-availability-upon-restore:false
bpf-lb-service-backend-map-max:0
clustermesh-config:/var/lib/cilium/clustermesh/
allocator-list-timeout:3m0s
policy-audit-mode:false
keep-config:false
enable-cilium-api-server-access:
labels:
enable-ipv4:true
http-max-grpc-timeout:0
ipv6-node:auto
bpf-ct-timeout-regular-tcp:2h13m20s
l2-pod-announcements-interface:
egress-multi-home-ip-rule-compat:false
dns-policy-unload-on-shutdown:false
monitor-queue-size:0
hubble-flowlogs-config-path:
identity-restore-grace-period:30s
identity-heartbeat-timeout:30m0s
bgp-announce-lb-ip:false
k8s-namespace:kube-system
state-dir:/var/run/cilium
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
restore:true
bpf-ct-timeout-service-any:1m0s
bpf-lb-algorithm:random
proxy-max-requests-per-connection:0
egress-gateway-reconciliation-trigger-interval:1s
enable-health-check-nodeport:true
hubble-export-fieldmask:
derive-masq-ip-addr-from-device:
http-idle-timeout:0
disable-endpoint-crd:false
max-connected-clusters:255
mesh-auth-signal-backoff-duration:1s
iptables-random-fully:false
enable-tcx:true
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-sock-rev-map-max:262144
enable-ingress-controller:false
http-request-timeout:3600
kvstore:
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-bbr:false
identity-change-grace-period:5s
max-internal-timer-delay:0s
enable-l2-neigh-discovery:true
local-max-addr-scope:252
enable-ipsec-encrypted-overlay:false
ipv6-service-range:auto
cni-external-routing:false
ipv4-range:auto
enable-ipv6:false
mesh-auth-gc-interval:5m0s
enable-ipv6-ndp:false
label-prefix-file:
enable-unreachable-routes:false
enable-k8s-api-discovery:false
annotate-k8s-node:false
pprof-address:localhost
node-labels:
hubble-monitor-events:
auto-create-cilium-node-resource:true
api-rate-limit:
k8s-kubeconfig-path:
```

