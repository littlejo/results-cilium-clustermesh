 09:24:57 up 10 min,  0 users,  load average: 0.46, 0.53, 0.31
