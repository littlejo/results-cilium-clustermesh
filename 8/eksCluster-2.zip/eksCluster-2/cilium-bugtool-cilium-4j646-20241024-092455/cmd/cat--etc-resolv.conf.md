search ec2.internal
nameserver 172.31.0.2
