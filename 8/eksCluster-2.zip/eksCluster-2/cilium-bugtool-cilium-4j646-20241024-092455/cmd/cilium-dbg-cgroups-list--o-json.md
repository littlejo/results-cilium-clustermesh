[
  {
    "containers": [
      {
        "cgroup-id": 6747,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f9c60b7_7ce3_43bd_b6f9_8377b658deae.slice/cri-containerd-a8db2b3b119659cf3100f901be38a9b65c9632c7e04bfa29d1f60cf5c85043dc.scope"
      }
    ],
    "ips": [
      "10.2.0.154"
    ],
    "name": "coredns-586b798467-lllk4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8847,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f802b5_58e2_490a_8d65_1c08aefe3261.slice/cri-containerd-74bb6582d70a9b3afced52fe7f8843f0050dd3b8c79904d70dafec42a7d9ac94.scope"
      }
    ],
    "ips": [
      "10.2.0.242"
    ],
    "name": "client-974f6c69d-zr62r",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9099,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ce3fef0_64b3_4a5f_977b_daa6eca6d49f.slice/cri-containerd-44872827ff5b5dde8b9f3f6a860688488c514c409ac8dc75070f083f72a053cc.scope"
      },
      {
        "cgroup-id": 9015,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ce3fef0_64b3_4a5f_977b_daa6eca6d49f.slice/cri-containerd-cab4c89cd591357c386fa75bc25569e990c8a88c5b0185691e6b6e056d83a704.scope"
      }
    ],
    "ips": [
      "10.2.0.36"
    ],
    "name": "echo-same-node-86d9cc975c-2mcww",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8175,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-bc1d77c9a5506e5f90a8607fc6c4dd1531ca8d56bf6e60d3a67ae65aa91e7c42.scope"
      },
      {
        "cgroup-id": 8259,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-b35f67a89e936d83caea8e657ff876efe4b1822c4430056c276c381370b9973f.scope"
      },
      {
        "cgroup-id": 8091,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-47becd6f0bfa1d97fb91015e4403a613c7f5ef9b6ea0c3e42f2e7c0f8d457bdb.scope"
      }
    ],
    "ips": [
      "10.2.0.168"
    ],
    "name": "clustermesh-apiserver-bb44565f9-727ls",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6663,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0d2d268_020a_400f_aa4d_2e2cfa2a67d6.slice/cri-containerd-aed347410357ea7c9394f46481716ba8bfdec512ed47b059df6c1f1b916d9ccf.scope"
      }
    ],
    "ips": [
      "10.2.0.185"
    ],
    "name": "coredns-586b798467-n67ss",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8931,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1afa56b_1740_4726_8b58_bb957e481cdb.slice/cri-containerd-3170725c31996b9b92d9898cfab501a8beb5366cc32910e6cae4fd50f3f45ccc.scope"
      }
    ],
    "ips": [
      "10.2.0.25"
    ],
    "name": "client2-57cf4468f-hbsf4",
    "namespace": "cilium-test-1"
  }
]

