Node 0, zone      DMA      1      1      2      0      2      2      2      4      6      7    221 
Node 0, zone   Normal      1      9     90     97     44     53     10      5      3      4      4 
