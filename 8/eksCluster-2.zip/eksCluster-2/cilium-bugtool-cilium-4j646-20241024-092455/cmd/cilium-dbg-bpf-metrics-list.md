REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     527       41836       677    bpf_overlay.c
Interface                   INGRESS     60686     194587893   1132   bpf_host.c
Policy denied               EGRESS      136       10064       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      520       41322       53     encap.h
Success                     EGRESS      708       170215      86     l3.h
Success                     EGRESS      886       62370       1694   bpf_host.c
Success                     EGRESS      9978      1900959     1308   bpf_lxc.c
Success                     INGRESS     11910     1736932     86     l3.h
Success                     INGRESS     12776     1914951     235    trace.h
Unsupported L3 protocol     EGRESS      69        5230        1492   bpf_lxc.c
