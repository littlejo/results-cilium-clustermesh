CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0d2d268_020a_400f_aa4d_2e2cfa2a67d6.slice/cri-containerd-fbb3207931e04e3c1f375df195319b521537b3aad9c230e4a3f583136f56b93f.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda0d2d268_020a_400f_aa4d_2e2cfa2a67d6.slice/cri-containerd-aed347410357ea7c9394f46481716ba8bfdec512ed47b059df6c1f1b916d9ccf.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4414108_1ed7_48ae_a34b_d94b5f1e990b.slice/cri-containerd-3116d2587311236de571e6e35048d4ade862e908d473e79cd1a5d979cbc04935.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4414108_1ed7_48ae_a34b_d94b5f1e990b.slice/cri-containerd-1ac6cf6b70ce296168c04b73d302f9164a4b2ba9477d40c56db1fa71e3cb93ec.scope
    71       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f9c60b7_7ce3_43bd_b6f9_8377b658deae.slice/cri-containerd-40d8865063cb33e75039bd0db7ec520dfc58932ce19898a435619aec28cc6eca.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9f9c60b7_7ce3_43bd_b6f9_8377b658deae.slice/cri-containerd-a8db2b3b119659cf3100f901be38a9b65c9632c7e04bfa29d1f60cf5c85043dc.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod769aeadd_4ace_4b14_82a2_2093650f6e71.slice/cri-containerd-75fccdb9034dc506532d12d56cc6588c324c1d1abf715dfdf9ca373b93306c4e.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod769aeadd_4ace_4b14_82a2_2093650f6e71.slice/cri-containerd-60c0f2f3458046fd0b984d4a88e17a3dc3f8ad2b78fe9c9fa46159fb8595634e.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f802b5_58e2_490a_8d65_1c08aefe3261.slice/cri-containerd-fbb9ed78db56ebf65a82c2213b8e70594fd92b579945133e99fa5e68ac932310.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd9f802b5_58e2_490a_8d65_1c08aefe3261.slice/cri-containerd-74bb6582d70a9b3afced52fe7f8843f0050dd3b8c79904d70dafec42a7d9ac94.scope
    679      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ce3fef0_64b3_4a5f_977b_daa6eca6d49f.slice/cri-containerd-78e5aeb0076c5192b57ad917dfb01c215c02eb2f1669e7f5b3770fa656d047b0.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ce3fef0_64b3_4a5f_977b_daa6eca6d49f.slice/cri-containerd-44872827ff5b5dde8b9f3f6a860688488c514c409ac8dc75070f083f72a053cc.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ce3fef0_64b3_4a5f_977b_daa6eca6d49f.slice/cri-containerd-cab4c89cd591357c386fa75bc25569e990c8a88c5b0185691e6b6e056d83a704.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1afa56b_1740_4726_8b58_bb957e481cdb.slice/cri-containerd-3170725c31996b9b92d9898cfab501a8beb5366cc32910e6cae4fd50f3f45ccc.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode1afa56b_1740_4726_8b58_bb957e481cdb.slice/cri-containerd-d1903de83231997ae59b587c432d1c08af954b895d629d149a6092f49981e627.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ed69418_e72f_4433_a6d5_bd9bf13d2d71.slice/cri-containerd-20446d60b8ac63c89cf05b7bbc00687153e29bd740c8cc63eda3b9f89ed3ccc1.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ed69418_e72f_4433_a6d5_bd9bf13d2d71.slice/cri-containerd-62fa1af554e320445c4292bda526f5f7d18b76ed4d929bda87794b472651dc61.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80648006_b0e9_4b8f_b4b5_9ffdd504f9d3.slice/cri-containerd-8a66de7db176df8b08c21bddd36bda26922f1a40381b5d73764a270439e0a106.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80648006_b0e9_4b8f_b4b5_9ffdd504f9d3.slice/cri-containerd-9b3197470c82c714d3e01d642ad65722aa32f9ee8063755652e7b1ac64160ac5.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-e32ff168bdfc32c9d744992d913669198860bfaa400a221ced89092cc0f24730.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-47becd6f0bfa1d97fb91015e4403a613c7f5ef9b6ea0c3e42f2e7c0f8d457bdb.scope
    622      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-b35f67a89e936d83caea8e657ff876efe4b1822c4430056c276c381370b9973f.scope
    630      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82bacb1a_9abf_4721_b936_4df4137d5809.slice/cri-containerd-bc1d77c9a5506e5f90a8607fc6c4dd1531ca8d56bf6e60d3a67ae65aa91e7c42.scope
    626      cgroup_device   multi                                          
