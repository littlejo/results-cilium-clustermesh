goroutine 171 [running]:
runtime/pprof.writeGoroutineStacks({0xffff73b62440, 0x400089c000})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6c
runtime/pprof.writeGoroutine({0xffff73b62440?, 0x400089c000?}, 0x10?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x2c
runtime/pprof.(*Profile).WriteTo(0x61dd090?, {0xffff73b62440?, 0x400089c000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x148
github.com/google/gops/agent.handle({0xffff73b62418, 0x400089c000}, {0x400110715d?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x23a0
github.com/google/gops/agent.listen({0x3e0bbf0, 0x4000df7c60})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x188
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x320

goroutine 1 [select, 9 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x400018a5a0, 0x4000f22980)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x104
github.com/cilium/hive.(*Hive).Run(0x400018a5a0, 0x4000f22980)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0xe8
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x40007ce008, {0x377b213?, 0x4?, 0x377b083?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x170
github.com/spf13/cobra.(*Command).execute(0x40007ce008, {0x400013c010, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0x828
github.com/spf13/cobra.(*Command).ExecuteC(0x40007ce008)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x344
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0x400018a5a0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x1c
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x64

goroutine 161 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000e5ba40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 25 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40008704e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 47 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000e5b680)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 42 [select, 9 minutes]:
io.(*pipe).read(0x4000ee4c00, {0x4001c04000, 0x10000, 0x0?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001c04000?, 0x4000094e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000094f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400027c460, 0x4000ee4c00, 0x4000f22900)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 43 [select, 9 minutes]:
io.(*pipe).read(0x4000ee4c60, {0x4001c14000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001c14000?, 0x4000096e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b07f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400027c460, 0x4000ee4c60, 0x4000f22920)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 44 [select, 9 minutes]:
io.(*pipe).read(0x4000ee4cc0, {0x4001c24000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001c24000?, 0x4000097678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b09f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400027c460, 0x4000ee4cc0, 0x4000f22940)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 45 [select, 9 minutes]:
io.(*pipe).read(0x4000ee4d20, {0x4001c34000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001c34000?, 0x4000097e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b0af18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400027c460, 0x4000ee4d20, 0x4000f22960)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 46 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x5c
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x8c

goroutine 152 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400047c000, {{{0x379a274, 0xd}}, {0x0, 0x0}, 0x400006e080, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 162 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x74
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x70

goroutine 163 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000e5bb80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 164 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001118f50, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001118f40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0x40022fc840, {0x3e23828, 0x400289b220})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xfc
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x10c
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x15c

goroutine 165 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x138
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1506 [select, 4 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x3cc
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa8

goroutine 3808 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40011122e0, {0x3e23828, 0x40036e4b90})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3811
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1488 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1338
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1523 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4a00, {{{0x3799d7a, 0xd}}, {0x0, 0x0}, 0x40022a7c50, 0x0, 0x4001bb7980, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1402 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400351ede8, 0x16)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400351edd8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400351edc0, 0x4000fa9d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4003532be0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400232dec0, {0x3ddab40, 0x4001881560}, 0x1, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002eccec0, 0x3b9aca00, 0x0, 0x1, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4003532be0, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400181f780, 0x40036a7740)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1342
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 172 [select, 5 minutes]:
github.com/cilium/statedb.graveyardWorker(0x4000448770, {0x3e23828, 0x40028b13b0}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x12c
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x14c

goroutine 3892 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4458, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40036e0600?, 0x40002ce880?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40036e0600, {0x40002ce880, 0xd80, 0xd80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40036e0600, {0x40002ce880?, 0xffff73b3b6f0?, 0x40048df920?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400187a2c8, {0x40002ce880?, 0x4002c3d928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df920, {0x40002ce880?, 0x0?, 0x40048df920?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400383a630, {0x3dd1940, 0x40048df920})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400383a388, {0x3dcbd80, 0x400187a2c8}, 0x4002c3da00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400383a388, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400383a388, {0x40038f2000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40038e2480, {0x4001ab2740, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40038e2480}, {0x4001ab2740, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001ab2740, 0x9, 0x8a0a9907c2?}, {0x3dcc0a0?, 0x40038e2480?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001ab2700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002408248, 0x40038e24e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3802
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 462 [select, 5 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x40001bd480)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x74
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x60

goroutine 3882 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4740, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40036e0b80?, 0x4003200c00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40036e0b80, {0x4003200c00, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40036e0b80, {0x4003200c00?, 0xffff73b3b6f0?, 0x40048df638?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400187a2b8, {0x4003200c00?, 0x4003383928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df638, {0x4003200c00?, 0x0?, 0x40048df638?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400383a2b0, {0x3dd1940, 0x40048df638})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400383a008, {0x3dcbd80, 0x400187a2b8}, 0x4003383a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400383a008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400383a008, {0x40037f6000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40037e1560, {0x40019559a0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40037e1560}, {0x40019559a0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x40019559a0, 0x9, 0x8a0956f815?}, {0x3dcc0a0?, 0x40037e1560?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001955960)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40023fc908, 0x40037e15c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3826
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 1507 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400371eb40, {{{0x37e6ffb, 0x1e}}, {0x0, 0x0}, 0x4002255128, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1505
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1484 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002574e60})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4280, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001999660, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1485 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x3def2c0?, 0xffff73ec4b08?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x3e34068?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 181 [IO wait]:
internal/poll.runtime_pollWait(0xffff74045d78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40028c2580?, 0x4001ede000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40028c2580, {0x4001ede000, 0x4800, 0x4800})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40028c2580, {0x4001ede000?, 0x4000a2ad48?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124db48, {0x4001ede000?, 0x40028eb868?, 0x1fd48?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x400483e6c0, {0x4001ede000?, 0x0?, 0x400483e6c0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400190e630, {0x3dd1940, 0x400483e6c0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400190e388, {0xffff73cd25c0, 0x400195f410}, 0x40028eb9d0?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400190e388, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400190e388, {0x40027ca000, 0x1000, 0x4004907200?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002849620, {0x40019183c0, 0x9, 0x7?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002849620}, {0x40019183c0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x40019183c0, 0x9, 0x2f8ed20?}, {0x3dcc0a0?, 0x4002849620?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001918380)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
golang.org/x/net/http2.(*clientConnReadLoop).run(0x40028ebf98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xd0
golang.org/x/net/http2.(*ClientConn).readLoop(0x4000ca0180)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x80
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 180
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xae0

goroutine 154 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e54fc0, {0x3e237f0, 0x4002285260}, {0x3e2b960, 0x40028497a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x294
github.com/cilium/hive/job.(*jobOneShot).start(0x400198fe00, {0x3e237f0, 0x4002285260}, 0xba7cf0?, {0x3e2b960, 0x400198faa0}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 841 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005560e80}, {0xffff73cd50b8, 0x40022ffad0}, {0x3e672a8, 0x36f6aa0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40013c7960, {0x0?, 0x0?}, 0x40025f8f00, 0x40025e15c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40013c7960, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002e4bf40, {0x3ddab60, 0x40008483c0}, 0x1, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40013c7960, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 836
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 2304 [select]:
net/http.(*persistConn).writeLoop(0x4001500d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 2301
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 257 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0x4000c11860, {0x3e23828?, 0x400082b9a0?}, 0x400234ec40)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xa4
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x3c
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x304

goroutine 1531 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 705 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 669
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10133 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4001802180, 0x4003fcdd40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4001802180, 0x8a6d4?, 0x400169a280?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 754
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 711 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001c56c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 730
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 648 [syscall]:
syscall.Syscall6(0x16, 0x19, 0x4000eb7820, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x6207cb0?, {0x4000eb7820?, 0x40001360c0?, 0x4002beb9e0?}, 0x4002beba58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x4000834c40, {0x4000eb7820, 0x2, 0x2}, {0x40028ce840?, 0x32d640?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4000e31500, 0x4002bebbd8)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(0x4000416b60?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x38
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x78
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x128

goroutine 669 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40022ff4c8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022ff4b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022ff4a0, 0x4000b2d3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000e5ac80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002867ec0, {0x3ddab40, 0x40013f6060}, 0x1, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002867ec0, 0x3b9aca00, 0x0, 0x1, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000e5ac80, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000835d80, 0x4001c01560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 668 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 681
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 666 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001c56000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 681
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 642 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0x400184b500)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xa4
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x20c

goroutine 1629 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000267b80, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000e02af0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1523
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 660 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 242
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 665 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001489e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 681
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1405 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1402
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 7740 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400399db00, 0x40050ca240, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400399db00, 0x8a6d4?, 0x4001606380?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 647 [select, 4 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x40016d6960, {0x3e237f0, 0x4002393710}, 0x4001bbad20?, {0x3e2b960, 0x40016d6660}, {{{0x40001efdc0, 0x1, 0x1}}, 0x400091ad30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 645 [chan receive, 9 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c220, {0x3e237f0, 0x4002393650}, 0x4001bbba38, {0x3e2b960?, 0x40016d6660}, {{{0x40001efdc0, 0x1, 0x1}}, 0x400091ad30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 210 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x40022fe238, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022fe228)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022fe210, 0x4001020c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001d123c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40028faec0, {0x3ddab40, 0x400247a060}, 0x1, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40028faec0, 0x3b9aca00, 0x0, 0x1, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001d123c0, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400006e340, 0x40025df680)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 155
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 211 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 155
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1392 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001053200, {0x3e237f0, 0x40018801b0}, 0x40030c8060?, {0x3e2b960, 0x4001053140}, {{{0x4000b58aa0, 0x1, 0x1}}, 0x4000e401a0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 214 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 210
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 649 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x40016d6a80, {0x3e237f0, 0x4002393c20}, {0x3e2b960, 0x4002080a20})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x3c4
github.com/cilium/hive/job.(*jobOneShot).start(0x40016d6ae0, {0x3e237f0, 0x4002393c20}, 0x4001bbb6e0?, {0x3e2b960, 0x400198f800}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 216 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 210
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 652 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400184ba00?, 0x7a2bb0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001843c80?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 217 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40050a9d80}, {0xffff73cd50b8, 0x40022fe210}, {0x3e672a8, 0x371cf40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400238c1c0, {0x0?, 0x0?}, 0x40025df680, 0x400198f860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400238c1c0, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000f5bf40, {0x3ddab60, 0x400284adc0}, 0x1, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400238c1c0, 0x40025df680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 210
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 207 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400238c1c0, 0x40025df680, 0x400233ed20, 0x400198f860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 3904 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40028aebe0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3828
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 437 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1530 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 707 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 669
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 627 [select, 9 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 645
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xc0

goroutine 708 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40012cac40}, {0xffff73cd50b8, 0x40022ff4a0}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400238d5e0, {0x0?, 0x0?}, 0x4001c01560, 0x40024f5980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400238d5e0, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bf3f40, {0x3ddab60, 0x400082af00}, 0x1, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400238d5e0, 0x4001c01560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 669
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 659 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40022ff2b8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022ff2a8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022ff290, 0x4000b2ce80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000e5a960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029bdec0, {0x3ddab40, 0x4002458930}, 0x1, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40029bdec0, 0x3b9aca00, 0x0, 0x1, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000e5a960, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000835ae0, 0x40022aa600)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 242
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 840 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 836
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 667 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000b2d250, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b2d240)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001489e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x400082ad20}, 0x4001c011a0, {0x3e3b570, 0x4000796420})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 681
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 11255 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 1388 [select, 5 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0x4001003d60, {0x3e237f0, 0x400186de60})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0x8c
github.com/cilium/hive/job.(*jobTimer).start(0x400356de00, {0x3e237f0, 0x400186de60}, 0x40025e1f20?, {0x3e2b960, 0x4001052b40}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x34c
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 816 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40013c60e0, 0x4001c01e00, 0x400244f800, 0x40024f5da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 754
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 245 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x4001606490, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001606480)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40008709c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4afc0, {0x3e23828, 0x4000cb8b90}, 0x400233f620, {0x3e3b518, 0x400191a408})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 712 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001c56d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 730
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 758 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 399
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 670 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10134 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40018021c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018021b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40018021b0, {0x40047715dc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400286bcc8?}, {0x40047715dc?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4001802180}, {0x40047715dc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400554f128, {0x4000b02c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40048e7e50, 0x0, {0x3e02238, 0x40058a9dc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000d137a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4003d6be00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 754
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 441 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 396
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 757 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40022ff6d8, 0x36)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022ff6c8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022ff6b0, 0x4000b2dd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000e5adc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000ff4ec0, {0x3ddab40, 0x40013f7560}, 0x1, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4000ff4ec0, 0x3b9aca00, 0x0, 0x1, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000e5adc0, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400153ed80, 0x400244e360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 399
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 246 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 257
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 244 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000871080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 257
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 248 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 268
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 243 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40008709c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 257
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 258 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x400235f080, 0x40023979e0, 0x4002397aa0, 0x4002397bc0)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x1d0
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x400235f080, {0x3e23828?, 0x400284b8b0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x3d8
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x400235f080, {0x3e23828, 0x400284b8b0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x70
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x120

goroutine 259 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x2c
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x108

goroutine 260 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x13, 0x40020bddb0, 0x10000, 0x0, 0x40032aab60, 0x40020bdd64)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x50?, {0x40020bddb0?, 0x0?, 0x1400000050?}, 0x0?, 0x40032dbe10?, 0x40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x13, {0x40020bddb0, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x40032dbe10?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x70
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x30c

goroutine 261 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x2c
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x108

goroutine 262 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x14, 0x40020fd940, 0x10000, 0x0, 0x40034e95e0, 0x40020fd8f4)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x74?, {0x40020fd940?, 0x0?, 0x600001800000074?}, 0x0?, 0x40019a9710?, 0x64?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x14, {0x40020fd940, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x15?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x74
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x30c

goroutine 263 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x2c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x100

goroutine 264 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x15, 0x4001d79e90, 0x10000, 0x0, 0x40016e5c70, 0x4001d79e44)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x59c?, {0x4001d79e90?, 0x0?, 0x100000059c?}, 0x0?, 0x400280ac10?, 0x58c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x15, {0x4001d79e90, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x4001d89ee8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x70
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 258
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x304

goroutine 265 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff74045c80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002530c60?, 0x400213de2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002530c60, {0x400213de2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000d7eba8, {0x400213de2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4000d6ad80)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 266 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000e5d540, {{{0x379eee1, 0xe}}, {0x0, 0x0}, 0x40005e5dd0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 267 [select, 9 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0x4000f8b860)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0xc0
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x318

goroutine 268 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x3e237f0, 0x4002337890}, {0x3e62c10, 0x40004495e0}, {0x3e2b960, 0x4002531080}, 0x1, 0x4001846460, 0x4001fb1d50, 0x4001fb1d40, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x5c4
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x3e237f0, 0x4002337890}, {0x3e2b960, 0x4002531080})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0xdc
github.com/cilium/hive/job.(*jobOneShot).start(0x4001601200, {0x3e237f0, 0x4002337890}, 0x400198ee40?, {0x3e2b960, 0x40016011a0}, {{{0x40019801e0, 0x1, 0x1}}, 0x4001b8b960, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 753 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 725
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 761 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 757
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 754 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4003d6be00}, {0xffff73cd50b8, 0x400235ebb0}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40013c60e0, {0x0?, 0x0?}, 0x4001c01e00, 0x40024f5da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40013c60e0, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c23f40, {0x3ddab60, 0x400082b1d0}, 0x1, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40013c60e0, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 725
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 718 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 721
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 719 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 725
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 442 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 396
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 358 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000ca1c80?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 391 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff740454c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1a?, 0x6e69727473066572?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40001bce00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40001bce00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40021cedc8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4000eebbf0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x40008621c0, {0x3e23828, 0x40008485f0}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xbc
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x144

goroutine 717 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000b2da10, 0x6d)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b2da00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001c57020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4aec0, {0x3e23828, 0x400082b130}, 0x4001c01c80, {0x3e3b468, 0x4000796d98})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 721
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 716 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001c571a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 721
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 386 [select]:
golang.org/x/time/rate.(*Limiter).wait(0x400537e000, {0x3e23828, 0x4000cb9400}, 0x1, {0x400379d918?, 0x1e301d0?, 0x6279580?}, 0x39bb3e8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:285 +0x320
golang.org/x/time/rate.(*Limiter).WaitN(0x400537e000, {0x3e23828, 0x4000cb9400}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:248 +0x54
golang.org/x/time/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:233
github.com/cilium/cilium/pkg/node/manager.(*manager).singleBackgroundLoop(0x4001491900, {0x3e23828, 0x4000cb9400}, 0x1eb1e32e50)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:429 +0x114
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x4001491900, {0x3e23828, 0x4000cb9400})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:398 +0x1f8
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x78
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 364
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x50

goroutine 713 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4000b2d690, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b2d680)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001c56c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x400082afa0}, 0x4001c01aa0, {0x3e3b4c0, 0x4000797068})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 730
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 715 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001c57020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 721
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 357 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x6972747306010165?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000eb8180?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 714 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 730
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 813 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400238d5e0, 0x4001c01560, 0x400244f1a0, 0x40024f5980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 708
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 356 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003dc640, {{{0x3791109, 0xb}}, {0x3e2b960, 0x4000eb47e0}, 0x4000455510, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 359 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e70e80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 7564 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400399cdc8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400399cdb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400399cdb0, {0x40036fcc01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400297bcc8?}, {0x40036fcc01?, 0x400297bcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40000c8b40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40000c8b40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40000c8b40, {0x30150e0, 0x40046743c0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003a7b650, {0x4003a15000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003374ff0, 0x0, {0x3e02238, 0x4004f6c300})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000791d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005560e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 841
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 393 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x38
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x184

goroutine 395 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40028af720)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 394 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff740455b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1e?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40001bd180)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40001bd180)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x400297fc48?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4000eebf20)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4001324200, {0x3e0bc20, 0x4000eebf20})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x19c

goroutine 1341 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40016d6d80, {0x3e237f0, 0x400186d4a0}, 0x400356c900?, {0x3e2b960, 0x40016d6ba0}, {{{0x4000790a80, 0x1, 0x1}}, 0x4000ce3780, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 440 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x38
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 391
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0x88

goroutine 392 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0xffff74045a90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1d?, 0x967e0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40001bd000)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40001bd000)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4000f5dd98?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).AcceptUnix(0x4000eebd70)
	/usr/local/go/src/net/unixsock.go:247 +0x2c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x124

goroutine 364 [chan receive, 9 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x4000cb93b0, {0x3e23828, 0x4000cb9400})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x60
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x134

goroutine 363 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e55100, {0x3e237f0, 0x4000eea660}, {0x3e2b960, 0x4000eb57a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x298
github.com/cilium/hive/job.(*jobOneShot).start(0x4001601a40, {0x3e237f0, 0x4000eea660}, 0x4000dbade0?, {0x3e2b960, 0x40016017a0}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 646 [chan receive, 9 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c1e0, {0x3e237f0, 0x40023936b0}, 0x4001bbba98, {0x3e2b960?, 0x40016d6660}, {{{0x40001efdc0, 0x1, 0x1}}, 0x400091ad30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 948 [select, 4 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0x40025f08c0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x1d4
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 837
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x68

goroutine 365 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40028af4a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 396 [select, 5 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x40019f8b40, {0x3e237f0, 0x40023a7560}, {0x3e2b960, 0x40013387e0})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x2d8
github.com/cilium/hive/job.(*jobOneShot).start(0x4000217800, {0x3e237f0, 0x40023a7560}, 0x4000e7c3c0?, {0x3e2b960, 0x4000217500}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 5526 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40033da1c8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40033da1b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40033da1b0, {0x4005036601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40042a1cc8?}, {0x4005036601?, 0x40042a1cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4000c73040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4000c73040)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4000c73040, {0x30150e0, 0x40040e9698})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40028b9da0, {0x4003624c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003959e50, 0x0, {0x3e02238, 0x4000f1f200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000e43ca0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40011163c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 675
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 643 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e726e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 630 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0x40003dc000)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0xd4
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x5c

goroutine 678 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001919180, 0x40022aa600, 0x40022aa840, 0x40023101e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 675
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 641 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff740452d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40014887e0?, 0x4002bd5e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40014887e0, {0x4002bd5e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000d7fd10, {0x4002bd5e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x400184b4c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 3903 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003994640, {0x400398a7c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003994640, {0x400398a7c0?, 0x40037c5908?, 0x40037e9930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400398a780, {0x400398a7c0?, 0x40037e99b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400398a780}, {0x400398a7c0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001920360, {0x400398a7c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400398a7b0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400398a7b0, 0x4001920360, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001920360?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40048e3d40}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002747380, {0x3612420, 0x40048e3d40}, 0x40048e3f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40037e9d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001920120, 0x40037e9e10, 0x40037e9e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001920120, {0x3612420?, 0x40048e3d40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003935668, {0x3612420, 0x40048e3d40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40012d32c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40028aebe0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3828
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3900 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d1950, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40005633b0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3802
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 947 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x120
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 946
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1535 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1409 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003706600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 656 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x400082a190}, 0x4001c00c60, {0x3e3b4c0, 0x400238fe78})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x4dc
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 657 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 681 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0x40003dc000, 0x4001b8eab0, 0x4001d0c060)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x160

goroutine 655 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001489200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 634 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002288500, {{{0x37ce973, 0x19}}, {0x0, 0x0}, 0x4001bbe6a0, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 683 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002310660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 654 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40014890e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 635 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff74045998, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x29?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40005a6f00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40005a6f00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001b89980)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001b89980)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
github.com/cilium/dns.(*Server).serveTCP(0x400289fe00, {0x3e0bbf0, 0x4001b89980})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0xe4
github.com/cilium/dns.(*Server).ActivateAndServe(0x400289fe00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x208
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x400289fe00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 685 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000b37490, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b37480)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002310660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ae40, {0x3e23828, 0x40007fc780}, 0x40022aacc0, {0x3e3b410, 0x4001526cf0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 640 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 659
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 636 [IO wait]:
internal/poll.runtime_pollWait(0xffff740453c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40005a6f80?, 0x4005578a00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x40005a6f80, {0x4005578a00, 0x200, 0x200}, {0x40058b0330, 0x2c, 0x2c}, 0x0, 0x400381f818)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x254
net.(*netFD).readMsgInet4(0x40005a6f80, {0x4005578a00?, 0x400381f808?, 0x71368?}, {0x40058b0330?, 0x71374?, 0x400381f7d8?}, 0x1ea1c?, 0x400381f7f8?)
	/usr/local/go/src/net/fd_posix.go:84 +0x2c
net.(*UDPConn).readMsg(0x31926c0?, {0x4005578a00?, 0x1ea?, 0x2?}, {0x40058b0330?, 0x10?, 0x400381f918?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x124
net.(*UDPConn).ReadMsgUDPAddrPort(0x4000ab8db0, {0x4005578a00?, 0xffff740453c8?, 0x77359168?}, {0x40058b0330?, 0x2a69c84?, 0x4002424e40?})
	/usr/local/go/src/net/udpsock.go:203 +0x34
net.(*UDPConn).ReadMsgUDP(0x4002424e40?, {0x4005578a00?, 0x0?, 0x40015630b0?}, {0x40058b0330?, 0x2a098e0?, 0x10?})
	/usr/local/go/src/net/udpsock.go:191 +0x24
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x4000ab8db0?, 0x4000ab8db0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x5c
github.com/cilium/dns.(*Server).readUDP(0x4000360800, 0x4000ab8db0, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0x140
github.com/cilium/dns.defaultReader.ReadUDP({0x40040a45f0?}, 0x318dd00?, 0x4002a10ab8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x1c
github.com/cilium/dns.(*Server).serveUDP(0x4000360800, {0x3e35e70, 0x4000ab8db0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x20c
github.com/cilium/dns.(*Server).ActivateAndServe(0x4000360800)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x178
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4000360800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 684 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40023107e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 5537 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40033da180, 0x400246e6c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40033da180, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 675
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 674 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 659
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 686 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1248 [select, 9 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x40033dbb00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x174
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1261
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1410

goroutine 675 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40011163c0}, {0xffff73cd50b8, 0x40022ff290}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001919180, {0x0?, 0x0?}, 0x40022aa600, 0x40023101e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001919180, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bedf40, {0x3ddab60, 0x40007fc3c0}, 0x1, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001919180, 0x40022aa600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 659
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 653 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000e5a8c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 687 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0x9c
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1d4

goroutine 3296 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b8f00, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40008938b0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3291
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1381 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e711c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 690 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40023108a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 691 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002310a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 692 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000b378d0, 0x22)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b378c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40023108a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40007fc960}, 0x40022aaf00, {0x3e3b258, 0x4001526e28})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 693 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 694 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xac
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1fc

goroutine 695 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0x40019f97a0, {0x3e23828, 0x4001cbbe50}, 0x4001b8eaa0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x2bc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x2ec

goroutine 696 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0x4001aa8240, {0x3e23828, 0x4001cbbe50}, 0x4001b8eaa0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x220
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x118

goroutine 836 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40022ffaf8, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022ffae8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022ffad0, 0x4001805140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001002140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4003805e00, {0x3ddab40, 0x4001c6d1d0}, 0x1, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002866e00, 0x3b9aca00, 0x0, 0x1, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001002140, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x4001b0d4a0, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0xa8
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x4001c6cdb0, {0x1?, 0x0?}, {0x3e148d0, 0x40025f0978}, 0x40025f8f00)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x480
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 784
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 698 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x100
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 696
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x1d8

goroutine 699 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x40022ab0e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 696
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 3917 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a32550, {0x4003a30970, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a32550, {0x4003a30970?, 0x4003a340f0?, 0x4003a3b930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a30930, {0x4003a30970?, 0x4003a3b9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a30930}, {0x4003a30970, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400226c240, {0x4003a30970, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a30960, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a30960, 0x400226c240, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400226c240?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40048e3dc0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003494b60, {0x3612420, 0x40048e3dc0}, 0x40048e3f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003a3bd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400226c000, 0x4003a3be10, 0x4003a3be58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400226c000, {0x3612420?, 0x40048e3dc0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400386aab0, {0x3612420, 0x40048e3dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40012194f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40028aefa0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3836
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 701 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400235ea78, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400235ea68)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400235ea50, 0x4000b37ac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400130eaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029b9ec0, {0x3ddab40, 0x4001d0d590}, 0x1, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40029b9ec0, 0x3b9aca00, 0x0, 0x1, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400130eaa0, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a30720, 0x40022abce0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 400
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 702 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 400
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1395 [select, 4 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x40000cbd00, {0x3e237f0, 0x40018804e0}, {0x3e0e5f0, 0x4001880ff0}, 0x40036a54a0)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x204
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x40000cbd00, {0x3e237f0, 0x40018804e0}, {0x671a103d?, 0x40036b3d68?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x2d0
github.com/cilium/hive/job.(*jobOneShot).start(0x40010535c0, {0x3e237f0, 0x40018804e0}, 0x4002fcfc80?, {0x3e2b960, 0x4001053560}, {{{0x4000df6020, 0x1, 0x1}}, 0x4000e41da0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 721 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 688
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xcc

goroutine 1398 [syscall, 9 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x30
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x1c
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x28

goroutine 3291 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b8dc0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40031b2eb0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3269
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 725 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400235ebd8, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400235ebc8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400235ebb0, 0x4000b37b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400130eb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c33ec0, {0x3ddab40, 0x40013f6cc0}, 0x1, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a11ec0, 0x3b9aca00, 0x0, 0x1, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400130eb40, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a307a0, 0x4001c01e00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 398
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 726 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 398
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1393 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400364a3c0, {{{0x378dd05, 0xa}}, {0x0, 0x0}, 0x40018f4f40, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1387 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 730 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x130
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x200

goroutine 731 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x240
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x274

goroutine 732 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x40022ab9e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 832 [select, 9 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x14c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x15c

goroutine 734 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002390060)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 698
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 735 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000b37c10, 0x12)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000b37c00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002311ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ab40, {0x3e23828, 0x40007fd270}, 0x40022abb00, {0x3e3b200, 0x4001527008})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 698
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 736 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 698
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 737 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 701
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 787 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 768
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 739 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 701
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 740 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004aa6d40}, {0xffff73cd50b8, 0x400235ea50}, {0x3e672a8, 0x371cba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001919dc0, {0x0?, 0x0?}, 0x40022abce0, 0x4002391980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001919dc0, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c25f40, {0x3ddab60, 0x40007fd310}, 0x1, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001919dc0, 0x40022abce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 701
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 774 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001919dc0, 0x40022abce0, 0x40023aaa20, 0x4002391980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 740
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 12292 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4004472648, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004472638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004472630, {0x400471de20, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002a51cc8?}, {0x400471de20?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4004472600}, {0x400471de20, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40045bd8d8, {0x4003557800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004689b30, 0x0, {0x3e02238, 0x4004aa6d80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a30500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004aa6d40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 740
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 831 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 749 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 745
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 745 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400235f158, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400235f148)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400235f130, 0x4000b37e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400130ebe0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002993ec0, {0x3ddab40, 0x4001d0dc50}, 0x1, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002c26ec0, 0x3b9aca00, 0x0, 0x1, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400130ebe0, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a30c00, 0x40023aa300)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 361
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 746 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 361
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1403 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1342
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 751 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 745
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 752 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40037daf40}, {0xffff73cd50b8, 0x400235f130}, {0x3e672a8, 0x36f67e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40006bdea0, {0x0?, 0x0?}, 0x40023aa300, 0x4002391b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40006bdea0, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002beff40, {0x3ddab60, 0x40007fd630}, 0x1, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40006bdea0, 0x40023aa300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 745
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 776 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40006bdea0, 0x40023aa300, 0x40023aade0, 0x4002391b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 752
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1376 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003706480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1606 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff73cb4930, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40026a6600?, 0x40016fc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40026a6600, {0x40016fc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40026a6600, {0x40016fc000?, 0x1?, 0x40023a5a40?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40019b68d8, {0x40016fc000?, 0xc?, 0x4002576700?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4000966c60, {0x40016fc000?, 0x18550?, 0x400233fbc0?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002071ec0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002071ec0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4000966c60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1605
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 845 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40013c7960, 0x40025f8f00, 0x40025f9b60, 0x40025e15c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 841
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1340 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40016d6cc0, {0x3e237f0, 0x400186d440}, 0x40035b11a0?, {0x3e2b960, 0x40016d6ba0}, {{{0x4000790a80, 0x1, 0x1}}, 0x4000ce3780, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 763 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 757
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 764 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40016b6c40}, {0xffff73cd50b8, 0x40022ff6b0}, {0x3e672a8, 0x373c000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40013c6540, {0x0?, 0x0?}, 0x400244e360, 0x40025e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40013c6540, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c35f40, {0x3ddab60, 0x400082b540}, 0x1, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40013c6540, 0x400244e360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 757
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 825 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40013c6540, 0x400244e360, 0x400244ff80, 0x40025e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 768 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40022ff788, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40022ff778)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40022ff760, 0x4000cfa140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000e5af00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a3eec0, {0x3ddab40, 0x40013f7c20}, 0x1, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a3eec0, 0x3b9aca00, 0x0, 0x1, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000e5af00, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400153f120, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 785 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 360
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 7563 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400399cd80, 0x40019dcc60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400399cd80, 0x8a6d4?, 0x40036b4780?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 841
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 789 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 768
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 790 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004d5e400}, {0xffff73cd50b8, 0x40022ff760}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40013c6a80, {0x0?, 0x0?}, 0x400244e7e0, 0x40025e0c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40013c6a80, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c1ff40, {0x3ddab60, 0x400082b6d0}, 0x1, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40013c6a80, 0x400244e7e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 768
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 827 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40013c6a80, 0x400244e7e0, 0x40025f82a0, 0x40025e0c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 790
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 7587 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40035da1c8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40035da1b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40035da1b0, {0x40036fc601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40058f7cc8?}, {0x40036fc601?, 0x40058f7cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003346dc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003346dc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003346dc0, {0x30150e0, 0x4004698c90})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400354e030, {0x400392b800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003328960, 0x0, {0x3e02238, 0x4004a7b940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400068d580)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004d5e400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 790
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 2303 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2e20, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002664900?, 0x40028dc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002664900, {0x40028dc000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002664900, {0x40028dc000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d7f8, {0x40028dc000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001500d80, {0x40028dc000?, 0x4002a2ad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40028daf00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40028daf00, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001500d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 2301
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3824 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116e130, {0x3e23828, 0x40036092c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3813
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1378 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400364a280, {{{0x37b8e08, 0x14}}, {0x3e2b960, 0x400356dce0}, 0x40024d4ff0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1396 [select]:
github.com/cilium/cilium/pkg/hive/health.publishJob({0x3e237f0, 0x40018805a0}, {{{}}, 0x4000448770, {0x3e5d368, 0x40004487e0}, {0x3e24e30, 0x40019c7b00}, 0x40013e7080}, 0x40016b7200)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:79 +0x22c
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x3e237f0?, 0x40018805a0?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x40
github.com/cilium/hive/job.(*jobOneShot).start(0x4001053f20, {0x3e237f0, 0x40018805a0}, 0x4002fcfc80?, {0x3e2b960, 0x4001053ec0}, {{{0x4000df7b00, 0x1, 0x1}}, 0x4001989f30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1394 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x40010532c0, {0x3e237f0, 0x4001880330}, 0x400307a2a0?, {0x3e2b960, 0x4001053260}, {{{0x0, 0x0, 0x0}}, 0x4000e41240, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 3907 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001a20480)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3829
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 1379 [select, 9 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x3e23a20, 0x4000d133a0}, {0x3dd0840, 0x400151f200}, {0x3e2b960, 0x4001052600}, 0x4000448770, {0x3e5d2a0, 0x40002641c0}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x688
github.com/cilium/hive/job.(*jobOneShot).start(0x40010526c0, {0x3e237f0, 0x400186d950}, 0x4003497a40?, {0x3e2b960, 0x4001052600}, {{{0x0, 0x0, 0x0}}, 0x40019cacb0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1382 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1384 [select]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x248
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x7c

goroutine 783 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xc0
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x26c

goroutine 1343 [IO wait]:
internal/poll.runtime_pollWait(0xffff74044fe8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x2d?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4003527e00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4003527e00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4002c38db8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x400186d590)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x40032fb770, {0x3e0bc20, 0x400186d590})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3e0bc20?, 0x400186d590?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x70
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x418

goroutine 3847 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116ef20, {0x3e23828, 0x4003609860})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3818
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1482 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4140, {{{0x37a4a9e, 0xf}}, {0x0, 0x0}, 0x4002277d10, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1483 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4003718500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1481 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4000, {{{0x37b1743, 0x12}}, {0x0, 0x0}, 0x4001999ed0, 0x0, 0x4001999ee0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 163
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1487 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4640, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001999ad0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1633 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff73cb4838, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003520100?, 0x4000c43000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003520100, {0x4000c43000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003520100, {0x4000c43000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000c0fc78, {0x4000c43000?, 0x72?, 0x40005bc158?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40005bc150, {0x4000c43000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002530f00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002530f00, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40017f22d0, {0x3e237f0, 0x40018a0030})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1343
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1522 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0x4002296f60, 0x0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x4ec
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1338
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x210

goroutine 3818 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003704c80, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000fcf270, 0x1, 0x4000fcf280, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10177 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b40aa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40023ba480?, 0x4001c84000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0x40023ba480, {0x4001c84000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x40000000)
	/usr/local/go/src/internal/poll/fd_unix.go:301 +0x284
net.(*netFD).readMsg(0x40023ba480, {0x4001c84000?, 0x400247b380?, 0x400247b350?}, {0x0?, 0x4002fb6e10?, 0x4003807b88?}, 0x25809a0?)
	/usr/local/go/src/net/fd_posix.go:78 +0x30
net.(*UnixConn).readMsg(0x400085eec8, {0x4001c84000?, 0x4003807be8?, 0x2577428?}, {0x0?, 0x4000b3f740?, 0x400131b010?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x38
net.(*UnixConn).ReadMsgUnix(0x400085eec8, {0x4001c84000?, 0x5?, 0x377a3b0?}, {0x0?, 0x88?, 0x3788a53?})
	/usr/local/go/src/net/unixsock.go:143 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0x4000b3f9e0, {0x3e23828, 0x400078cdc0}, 0x400085eec8)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:132 +0x12c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1 in goroutine 392
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x138

goroutine 10163 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4001802780, 0x40019cc7e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4001802780, 0x8a6d4?, 0x4000cfa800?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 708
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 818 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40025d0500, {{{0x37be248, 0x15}}, {0x0, 0x0}, 0x4001cccd90, 0x0, 0x39b9348, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 694
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1424 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x400333d418, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400333d408)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400333d3f0, 0x4001877040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40031d3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002e41ec0, {0x3ddab40, 0x4001881ce0}, 0x1, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002e41ec0, 0x3b9aca00, 0x0, 0x1, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40031d3e00, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001815ae0, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 433
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1401 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1396
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 9610 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003511980, 0x4001730c60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003511980, 0x4002ea6420?, 0x4000cf6540?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 752
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1380 [select, 4 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001052780, {0x3e237f0, 0x400186da10}, 0x40035b07e0?, {0x3e2b960, 0x4001052720}, {{{0x4000d13c40, 0x1, 0x1}}, 0x4000dbe8e0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 12291 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004472600, 0x40019dc5a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004472600, 0x8a6d4?, 0x400169a380?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 740
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 11069 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4001802600, 0x40017a4c60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4001802600, 0x8a6d4?, 0x400169a700?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 7586 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40035da180, 0x4001a8f7a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40035da180, 0x4002c75c20?, 0x4002c75bc0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 790
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1459 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1434
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1262 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4002034e60, {0x400184f210, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002034e60, {0x400184f210?, 0x400348e330?, 0x40035ff510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400183b770, {0x400184f210?, 0x40035ff598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400183b770}, {0x400184f210, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001628480, {0x400184f210, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400184f200, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400184f200, 0x4001628480, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40035ff7c8?, {0xffff73cec798, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400130f900}, 0x40025f1500?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40032fb680, {0x35bf9e0, 0x400130f900})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0x4001a35a10)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x4002f8f380?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1266
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1247 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x400208eb90, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028ae00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xbc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1261
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x13d0

goroutine 1265 [IO wait]:
internal/poll.runtime_pollWait(0xffff740450e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40033fe180?, 0x400346a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40033fe180, {0x400346a000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40033fe180, {0x400346a000?, 0x40038108c0?, 0x800010601?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40019b7058, {0x400346a000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
bufio.(*Reader).Read(0x400345d740, {0x4001866e40, 0x9, 0x400184ef90?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400345d740}, {0x4001866e40, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001866e40, 0x9, 0x40023380f0?}, {0x3dcc0a0?, 0x400345d740?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001866e00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x40033dbb00, {0x3e237f0, 0x400183b5f0}, 0x400183b620)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x11c
google.golang.org/grpc.(*Server).serveStreams(0x4001324200, {0x3e23698?, 0x680cae0?}, {0x3e42860, 0x40033dbb00}, {0x3e3a840?, 0x40019b7058?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x300
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x5c
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1261
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d4

goroutine 1266 [select]:
reflect.rselect({0x4001530a20, 0x9, 0xffff73d4eb20?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x40033fc200?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x40023a6600, {0x3e237f0, 0x400184f260}, 0x400028aee0, {0xffff73cec7c0, 0x4001a35a10}, 0x40034681e0, {0x385b1ff?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x40023a6600, {0x3e237f0, 0x400184f260}, {0xffff73cec7c0, 0x4001a35a10}, {0x385b1ff, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0x40023a6600, {0x3e3e7a8, 0x4001a35a10})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x78
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x365dfc0?, 0x40023a6600}, {0x3e32818, 0x40032fb680})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001324200, {0x3e237f0, 0x400184f140}, {0x3e42860, 0x40033dbb00}, 0x4001628480, 0x40023a68d0, 0x62382a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001324200, {0x3e42860, 0x40033dbb00}, 0x4001628480)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1265
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 3888 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4360, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400372d300?, 0x400301b500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400372d300, {0x400301b500, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400372d300, {0x400301b500?, 0xffff73b3b6f0?, 0x40048df5c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfe9d0, {0x400301b500?, 0x400374c928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df5c0, {0x400301b500?, 0x0?, 0x40048df5c0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400347bb30, {0x3dd1940, 0x40048df5c0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400347b888, {0x3dcbd80, 0x4000dfe9d0}, 0x400374ca00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400347b888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400347b888, {0x40038bc000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40038b6b40, {0x4001ab22e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40038b6b40}, {0x4001ab22e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001ab22e0, 0x9, 0x8a0956ead0?}, {0x3dcc0a0?, 0x40038b6b40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001ab22a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002400fc8, 0x40038b6ba0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3841
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 1337 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x100
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb0

goroutine 1365 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400333cde8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400333cdd8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400333cdc0, 0x4001073d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40031d3d60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002ed0ec0, {0x3ddab40, 0x4001863aa0}, 0x1, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002ed0ec0, 0x3b9aca00, 0x0, 0x1, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40031d3d60, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001815500, 0x40034ff440)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1366 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1534 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1744 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002c128c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400347f200}, 0x40018aa730, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1658
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1533 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1368 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1365
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1757 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b7f180, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003496c60}, 0x40018d2590, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1695
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11584 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40043fd980, 0x4004ed65a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40043fd980, 0x4004e86a80?, 0x4004e86a20?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1452
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1417 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003706a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1410 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x4001876210, 0x22)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001876200)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003706480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4adc0, {0x3e23828, 0x40024fac30}, 0x4003702a80, {0x3e3b3b8, 0x4001bb6390})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1371 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40014f1700}, {0xffff73cd50b8, 0x400333cdc0}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002356380, {0x0?, 0x0?}, 0x40034ff440, 0x4003717ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002356380, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40035f7f40, {0x3ddab60, 0x40024fa1e0}, 0x1, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002356380, 0x40034ff440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1365
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1419 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1412 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40037066c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1370 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1365
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1422 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4001876ed0, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001876ec0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003706b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ac40, {0x3e23828, 0x40024faf50}, 0x4003702cc0, {0x3e3b2b0, 0x4001bb65a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1411 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1471 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002356380, 0x40034ff440, 0x400371ce40, 0x4003717ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1371
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1421 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003706cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1415 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1413 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003706840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1420 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003706b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1416 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003706900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1384
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1414 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40018766d0, 0x198)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018766c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40037066c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ad40, {0x3e23828, 0x40024fad70}, 0x4003702b40, {0x3e3b360, 0x4001bb6438})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1425 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 433
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1423 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1418 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4001876ad0, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001876ac0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003706900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4acc0, {0x3e23828, 0x40024fae60}, 0x4003702c00, {0x3e3b308, 0x4001bb64e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1384
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1526 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 12350 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004472780, 0x400182ed80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004472780, 0x8a6d4?, 0x40036b4780?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1447
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1407 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1408 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001544a00}, {0xffff73cd50b8, 0x400351edc0}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001867180, {0x0?, 0x0?}, 0x40036a7740, 0x40037321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001867180, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40036adf40, {0x3ddab60, 0x4002544b40}, 0x1, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001867180, 0x40036a7740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1402
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1473 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001867180, 0x40036a7740, 0x400371d200, 0x40037321e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1408
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1444 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1429
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1429 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400333d4c8, 0xcc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400333d4b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400333d4a0, 0x4001877080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40031d3ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40031abec0, {0x3ddab40, 0x4001881980}, 0x1, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40031abec0, 0x3b9aca00, 0x0, 0x1, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40031d3ea0, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001815b60, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 434
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1430 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 434
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1527 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1443 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1424
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1434 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x400333d578, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400333d568)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400333d550, 0x40018770c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4003718000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c4cec0, {0x3ddab40, 0x40018a1f20}, 0x1, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002c4cec0, 0x3b9aca00, 0x0, 0x1, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4003718000, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001815c00, 0x400371c840)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 435
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1435 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 435
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1528 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1465 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1439
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1439 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x400333d628, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400333d618)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400333d600, 0x4001877100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40037180a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c47ec0, {0x3ddab40, 0x40018f2420}, 0x1, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002c47ec0, 0x3b9aca00, 0x0, 0x1, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40037180a0, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001815c60, 0x400371cb40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 436
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1440 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 436
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1529 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 5530 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40035113c8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40035113b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40035113b0, {0x400111eedc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40031a9cc8?}, {0x400111eedc?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4003511380}, {0x400111eedc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400229c630, {0x4003625000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400256a690, 0x0, {0x3e02238, 0x400147fc80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400181e040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001544a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1408
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5529 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003511380, 0x40005a85a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003511380, 0x8a6d4?, 0x4001877980?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1408
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1446 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1429
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1447 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400492c7c0}, {0xffff73cd50b8, 0x400333d4a0}, {0x3e672a8, 0x370c0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019540e0, {0x0?, 0x0?}, 0x40036a7c80, 0x40036c0a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019540e0, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40036bbf40, {0x3ddab60, 0x4002544c30}, 0x1, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019540e0, 0x40036a7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1429
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1455 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019540e0, 0x40036a7c80, 0x40036c4480, 0x40036c0a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1447
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 12351 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40044727c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40044727b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40044727b0, {0x4004916c00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40028f2cc8?}, {0x4004916c00?, 0x2?, 0x18f3c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003c603c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003c603c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003c603c0, {0x30150e0, 0x400483e6d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40052ec690, {0x40050cd000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400492ec30, 0x0, {0x3e02238, 0x400492c800})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000b58280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400492c7c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1447
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1451 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1424
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1452 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004eed540}, {0xffff73cd50b8, 0x400333d3f0}, {0x3e672a8, 0x3722640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001954620, {0x0?, 0x0?}, 0x40036a7c20, 0x40036c0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001954620, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40036bdf40, {0x3ddab60, 0x4002544d70}, 0x1, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001954620, 0x40036a7c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1424
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1489 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001954620, 0x40036a7c20, 0x40036c4840, 0x40036c0ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1452
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1461 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1434
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1462 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4000d04d00}, {0xffff73cd50b8, 0x400333d550}, {0x3e672a8, 0x3703740}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002357340, {0x0?, 0x0?}, 0x400371c840, 0x40036c0ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002357340, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002e45f40, {0x3ddab60, 0x4002574140}, 0x1, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002357340, 0x400371c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1434
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 11601 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40043fd9c8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40043fd9b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40043fd9b0, {0x400473fc7c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002e3dcc8?}, {0x400473fc7c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x40043fd980}, {0x400473fc7c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4004ae57a0, {0x4004eb8400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004eebc70, 0x0, {0x3e02238, 0x400473b000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40001ef240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004eed540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1452
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1491 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002357340, 0x400371c840, 0x40036c4c00, 0x40036c0ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 11094 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4001802948, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001802938)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4001802930, {0x4002f52601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400272dcc8?}, {0x4002f52601?, 0x400272dcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40036b5040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40036b5040)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40036b5040, {0x30150e0, 0x4002254198})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4001927e90, {0x40050cc800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002ab58b0, 0x0, {0x3e02238, 0x40012fdb80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400006e420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4000d04d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12144 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40045907c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40045907b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40045907b0, {0x400168e300, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003186cc8?}, {0x400168e300?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4004590780}, {0x400168e300, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40019364c8, {0x4003556000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002fe50e0, 0x0, {0x3e02238, 0x40014f1740})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40000406a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40014f1700)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1371
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1467 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1439
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1468 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004a7bdc0}, {0xffff73cd50b8, 0x400333d600}, {0x3e672a8, 0x36f2b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002357880, {0x0?, 0x0?}, 0x400371cb40, 0x4003732840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002357880, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40036aff40, {0x3ddab60, 0x4002574230}, 0x1, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002357880, 0x400371cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1439
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1478 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002357880, 0x400371cb40, 0x400371db00, 0x4003732840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1468
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 12297 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40030de648, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40030de638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40030de630, {0x4004693a00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002ecbcc8?}, {0x4004693a00?, 0x2?, 0x18f3c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003841180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003841180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003841180, {0x30150e0, 0x4004699110})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003eba4e0, {0x4003557c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400478f180, 0x0, {0x3e02238, 0x4004a7be00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a31400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004a7bdc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1468
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12158 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004590780, 0x40017a4360, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004590780, 0x8a6d4?, 0x4001877a00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1371
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 11071 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4001802900, 0x40017a5200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4001802900, 0x3e237f0?, 0x40018a0030?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 12309 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40030de600, 0x4001a20ea0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40030de600, 0x3e237f0?, 0x40018a0030?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1468
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1532 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1496 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003732960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1340
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1497 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003732a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1340
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1498 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40016a4dd0, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40016a4dc0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003732960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x40025440f0}, 0x40036c5140, {0x3e3b570, 0x4001acb878})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1340
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1499 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1340
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1536 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1537 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1538 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1539 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1540 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1541 [IO wait]:
internal/poll.runtime_pollWait(0xffff74045b88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x2f?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40008ec680)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40008ec680)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4000d12d00)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4000d12d00)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x4001846780, {0x3e0bbf0, 0x4000d12d00})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0x40011b1e30, 0xe}, {0x3e0bbf0, 0x4000d12d00})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xa0
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1338
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x560

goroutine 1542 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4b40, {{{0x37bdc75, 0x15}}, {0x0, 0x0}, 0x40022c4300, 0x0, 0x39b9348, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10101 [select]:
reflect.rselect({0x4001530480, 0x9, 0xffff73d4eb20?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4003862a00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x40023a6600, {0x3e237f0, 0x40022a6f30}, 0x4000317490, {0xffff73b152d8, 0x4000cf6080}, 0x4003703b60, {0x381b81a?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x40023a6600, {0x3e237f0, 0x40022a6f30}, {0xffff73b152d8, 0x4000cf6080}, {0x381b81a, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0x40023a6600, {0x3e3e378, 0x4000cf6080})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:144 +0x78
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x365dfc0?, 0x40023a6600}, {0x3e32818, 0x400566c690})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1711 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001324200, {0x3e237f0, 0x40022a6e40}, {0x3e42860, 0x40033dbb00}, 0x4003b62a20, 0x40023a6960, 0x6217f00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001324200, {0x3e42860, 0x40033dbb00}, 0x4003b62a20)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1265
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1544 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036b4c80, {{{0x37c1af7, 0x16}}, {0x3e2b960, 0x400198f800}, 0x4000b511c0, 0x0, 0x39b9348, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3794 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3800 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f3a650, {0x3e23828, 0x40036c9a90})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3795
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1812 [select, 9 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4003864960, {0x4003861060, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003864960, {0x4003861060?, 0x400385c570?, 0x40029ed510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003860f30, {0x4003861060?, 0x40029ed598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003860f30}, {0x4003861060, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400185e120, {0x4003861060, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003861050, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003861050, 0x400185e120, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40029ed7c8?, {0xffff73cec798, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400130e500}, 0x40025a81c0?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4003492c30, {0x35bf9e0, 0x400130e500})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0x4001816020)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x4001801e50?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1811
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1519 [syscall, 9 minutes]:
syscall.Syscall6(0x5f, 0x1, 0x187, 0x4000b06ca8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
os.(*Process).blockUntilWaitable(0x4002333080)
	/usr/local/go/src/os/wait_waitid.go:32 +0x6c
os.(*Process).wait(0x4002333080)
	/usr/local/go/src/os/exec_unix.go:22 +0x2c
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0x40035db680)
	/usr/local/go/src/os/exec/exec.go:901 +0x38
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 1518
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x3bc

goroutine 1520 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4003532640)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1523
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3883 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4001bdf448)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3852
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3300 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400364a000, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002a307e0}, 0x4001d1e4e0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3289
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1672 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002289040, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001cee6e0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1660
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3786 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f23130, {0x3e23828, 0x4003608370})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3793
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3918 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40028aefa0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3836
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3801 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f3a680, {0x3e23828, 0x40036c9ae0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3795
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3901 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4003937270, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000563650)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3789
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3792 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3793
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 1638 [semacquire, 9 minutes]:
sync.runtime_Semacquire(0x4000a95dc0?)
	/usr/local/go/src/runtime/sema.go:62 +0x2c
sync.(*WaitGroup).Wait(0x4003712340)
	/usr/local/go/src/sync/waitgroup.go:116 +0x74
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x4003712200)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0xa8
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x4003712200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x100
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x28
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1636
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xd0

goroutine 1637 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x4001bb7938)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xd4
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x2c
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1636
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x80

goroutine 1636 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x4003712200)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xe0
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x5c
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 1522
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1d8

goroutine 1632 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400047d400, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4000b75bc0}, 0x4000e49440, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1485
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1718 [select]:
net/http.(*persistConn).writeLoop(0x4001828000)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1715
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1717 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4550, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40027cc780?, 0x40027db000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40027cc780, {0x40027db000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40027cc780, {0x40027db000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c4e8, {0x40027db000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001828000, {0x40027db000?, 0x4002194d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002fabaa0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002fabaa0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001828000)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1715
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1607 [select, 9 minutes]:
net/http.(*persistConn).writeLoop(0x4000966c60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1605
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3788 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f23190, {0x3e23828, 0x4003608410})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3793
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1627 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400191b350?, 0x4000c0f5d8?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001601140?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1523
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1626 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40028b1db0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40002672c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000e02740, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1523
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1595 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1341
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1594 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001336950, 0x29)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001336940)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002530360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40028b0be0}, 0x4000ec6540, {0x3e3b258, 0x4002254138})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1341
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1593 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002530480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1592 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002530360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 3898 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d1450, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000563110)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3841
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1587 [select, 7 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x110
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1585
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x200

goroutine 1576 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1543
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1577 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40000c9cc0, {{{0x378d189, 0xa}}, {0x0, 0x0}, 0x39b9e78, 0x0, 0x39b9348, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1543
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1578 [select, 4 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x40022d26c0, {0x3e23828, 0x4001cbbe50})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xec
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x20f0

goroutine 1579 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x40000c9e00)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x78
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x216c

goroutine 1580 [syscall]:
syscall.Syscall6(0x16, 0x39, 0x400224c240, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x4000074001?, {0x400224c240?, 0x4002c31918?, 0x1ea7078?}, 0x3ddd880?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x4000d22b40, {0x400224c240, 0x2, 0x2}, {0x74?, 0x74?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x400079e240, 0x4002c31af0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x4000264070, {0x3e23828, 0x40028b06e0})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x404
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1543
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd4

goroutine 1581 [IO wait]:
internal/poll.runtime_pollWait(0xffff740451d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x34?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000a62f00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000a62f00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4002c2fb28?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40022d2870)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4000591c00, {0x3e0bc20, 0x40022d2870})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4c
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x2fc8

goroutine 1582 [chan receive, 9 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x3028

goroutine 1583 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff73cb4d10, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40016d7aa0?, 0x400222de2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40016d7aa0, {0x400222de2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000c0e9a0, {0x400222de2b?, 0x0?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40013361c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1543
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1584 [select, 7 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x40022d2f60)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0x90
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1543
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1f8

goroutine 1589 [chan receive, 9 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x3adc

goroutine 1588 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff73cb4b20, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x3c?, 0x4002319ad0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000a63400)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000a63400)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4000b3c080)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4000b3c080)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4001768200, {0x3e0bbf0, 0x4000b3c080})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x54
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1543
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x3a7c

goroutine 1642 [IO wait, 4 minutes]:
internal/poll.runtime_pollWait(0xffff73cb4648, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x32?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400337a080)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400337a080)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4000b58580)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4000b58580)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x40018465a0, {0x3e0bbf0, 0x4000b58580})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
net/http.(*Server).ListenAndServe(0x40018465a0)
	/usr/local/go/src/net/http/server.go:3189 +0x84
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x28
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1637
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x58

goroutine 3822 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116e0d0, {0x3e23828, 0x4003609220})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3813
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3799 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f3a620, {0x3e23828, 0x40036c9a40})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3795
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3816 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000fceec0, {0x3e23828, 0x4003608ff0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3797
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1719 [IO wait]:
internal/poll.runtime_pollWait(0xffff740457a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40027cc800?, 0x40022c8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40027cc800, {0x40022c8000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40027cc800, {0x40022c8000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c4f0, {0x40022c8000?, 0x72?, 0x400192e698?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400192e690, {0x40022c8000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002751320)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002751320, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400152c6c0, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 3936 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4001d13c20, {0x3e23828, 0x4003a32050}, 0x4cc692bdd22942e0, 0x4003a2eae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3843
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 1655 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001d12960)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3795 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400352b180, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ed37d0, 0x1, 0x4000ed37e0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1657 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40007999a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002704c80, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001a509a0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1658 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40022d2f60?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1659 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002704dc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40013396e0}, 0x400027a770, 0x0, 0x4000690720, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1660 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002704f00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4000799b80, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3957 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001a8ec60)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3844
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3846 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116eef0, {0x3e23828, 0x4003609810})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3818
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3895 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002409b08)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3789
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1692 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001d13860)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1681
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3820 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003704dc0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000fcf640, 0x1, 0x4000fcf650, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1694 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000836730})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40025d1a40, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001989de0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1681
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1695 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40022fef01?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x3e23828?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1681
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1696 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40025d1cc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40027a0f60}, 0x400045ae00, 0x0, 0x4001023a40, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1681
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1697 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40025d1e00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4000836aa0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1681
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3893 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d0cd0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40000e7500)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3826
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1674 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b8780, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001d1e650, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1697
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1811 [select, 9 minutes]:
reflect.rselect({0x4001886360, 0x9, 0xffff73e15718?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4003862c00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x40023a6600, {0x3e237f0, 0x40038610b0}, 0x400028a0e0, {0xffff73b7b760, 0x4001816020}, 0x40038432c0, {0x3852034?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x40023a6600, {0x3e237f0, 0x40038610b0}, {0xffff73b7b760, 0x4001816020}, {0x3852034, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0x40023a6600, {0x3e3e6a0, 0x4001816020})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x78
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x365dfc0?, 0x40023a6600}, {0x3e32818, 0x4003492c30})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001324200, {0x3e237f0, 0x4003860fc0}, {0x3e42860, 0x40033dbb00}, 0x400185e120, 0x40023a67b0, 0x6238200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001324200, {0x3e42860, 0x40033dbb00}, 0x400185e120)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1265
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 3819 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3821 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1723 [select]:
github.com/servak/go-fastping.(*Pinger).run(0x400152d170, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x494
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1638
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x1b0

goroutine 3912 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40028aebe0, {0x3e3fa98, 0x40012d32c0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3903
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3288 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40031b2d70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b8a00, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40008931c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3269
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3817 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000fceef0, {0x3e23828, 0x4003609040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3797
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1756 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b7e3c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400345c780}, 0x4001a351b0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1724 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x80
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1638
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x68

goroutine 1725 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb3f80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x49?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40027cca00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40027cca00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x400298cdb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x400192f7d0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x40027e2000, {0x3e0bc20, 0x400192f7d0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3e0bc20?, 0x400192f7d0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x70
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1638
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x3f0

goroutine 1726 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb3e88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40027ccb80?, 0x4004a35000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0x40027ccb80, {0x4004a35000, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x214
net.(*netFD).readFrom(0x40027ccb80, {0x4004a35000?, 0x72?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x28
net.(*IPConn).readFrom(0x40027ccb80?, {0x4004a35000, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0x400124c568, {0x4004a35000?, 0x400298bea8?, 0x400298be70?})
	/usr/local/go/src/net/iprawsock.go:129 +0x2c
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1bea281bacc66f7?, {0x4004a35000?, 0x6279580?, 0x6279580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x34
github.com/servak/go-fastping.(*Pinger).recvICMP(0x400152d170, 0x4000d00600, 0x4002fabe00, 0x4000d00620, 0x40013fb1c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x114
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1723
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x2d8

goroutine 3823 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116e100, {0x3e23828, 0x4003609270})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3813
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3814 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3899 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d1680, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000563260)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3848
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3894 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d0f50, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40000e75e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3852
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1796 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4001607310, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001607300)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40016072c0, {0x3e23828, 0x4003929b30}, {0x4001ffe940, 0x33}, 0x1, {0x4000637c85, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1811
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 3845 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400116eec0, {0x3e23828, 0x40036097c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3818
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3897 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40037d1180, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000562fc0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3834
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3844 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3797
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3896 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2f18, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400384b780?, 0x400301a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400384b780, {0x400301a000, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400384b780, {0x400301a000?, 0xffff73b3b6f0?, 0x40048df7e8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfe9a0, {0x400301a000?, 0x4000fee928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df7e8, {0x400301a000?, 0x0?, 0x40048df7e8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400347b430, {0x3dd1940, 0x40048df7e8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400347b188, {0x3dcbd80, 0x4000dfe9a0}, 0x4000feea00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400347b188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400347b188, {0x40039ae000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400395b9e0, {0x4001ab2900, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400395b9e0}, {0x4001ab2900, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001ab2900, 0x9, 0x8a0a00300b?}, {0x3dcc0a0?, 0x400395b9e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001ab28c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002409b08, 0x400395ba40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3789
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3911 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3903
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3798 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3832 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001113570, {0x3e23828, 0x40036e5950})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3820
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3815 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000fcee90, {0x3e23828, 0x4003608fa0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3797
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3937 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001a21d40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3837
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3890 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4078, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400372d600?, 0x4003200000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400372d600, {0x4003200000, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400372d600, {0x4003200000?, 0xffff73b3b6f0?, 0x40048df650?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfea00, {0x4003200000?, 0x4002739928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df650, {0x4003200000?, 0x0?, 0x40048df650?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40037dc2b0, {0x3dd1940, 0x40048df650})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40037dc008, {0x3dcbd80, 0x4000dfea00}, 0x4002739a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40037dc008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40037dc008, {0x40038d0000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40038ce780, {0x4001ab2580, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40038ce780}, {0x4001ab2580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001ab2580, 0x9, 0x8a0958889a?}, {0x3dcc0a0?, 0x40038ce780?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001ab2540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002401d48, 0x40038ce7e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3848
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3793 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400352b040, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ed3400, 0x1, 0x4000ed3410, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3787 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f23160, {0x3e23828, 0x40036083c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3793
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3886 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4170, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40036e1100?, 0x4003bc6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40036e1100, {0x4003bc6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40036e1100, {0x4003bc6000?, 0xffff73b3b6f0?, 0x40048df620?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfe9b0, {0x4003bc6000?, 0x4002c50928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df620, {0x4003bc6000?, 0x0?, 0x40048df620?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400347b7b0, {0x3dd1940, 0x40048df620})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400347b508, {0x3dcbd80, 0x4000dfe9b0}, 0x4002c50a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400347b508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400347b508, {0x40038a2000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400389ce40, {0x4001ab2120, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400389ce40}, {0x4001ab2120, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001ab2120, 0x9, 0x8a0956fccb?}, {0x3dcc0a0?, 0x400389ce40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001ab20e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002402b48, 0x400389cea0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3834
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3913 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003994820}, {0x3e5f080?, 0x4001a20480?}, 0x4000f3b350)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3811
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3289 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000892090?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3269
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3884 [IO wait]:
internal/poll.runtime_pollWait(0xffff73cb4268, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400372d700?, 0x4003201800?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400372d700, {0x4003201800, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400372d700, {0x4003201800?, 0xffff73b3b6f0?, 0x40048df668?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfe9f0, {0x4003201800?, 0x400273a928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40048df668, {0x4003201800?, 0x0?, 0x40048df668?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400347beb0, {0x3dd1940, 0x40048df668})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400347bc08, {0x3dcbd80, 0x4000dfe9f0}, 0x400273aa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400347bc08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400347bc08, {0x400388a000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40037ff200, {0x4001955e00, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40037ff200}, {0x4001955e00, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001955e00, 0x9, 0x8a0956f33e?}, {0x3dcc0a0?, 0x40037ff200?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001955dc0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4001bdf448, 0x40037ff260)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3852
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3807 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40011122b0, {0x3e23828, 0x40036e4b40})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3811
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3833 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40011135a0, {0x3e23828, 0x40036e59a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3820
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3290 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b8b40, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002b2c540}, 0x400027de30, 0x0, 0x40013f7cb0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3269
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3829 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3811
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3796 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3994 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40019d4000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3792
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3797 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400352b2c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ed3ba0, 0x1, 0x4000ed3bb0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3902 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40028aebe0, {0x3e23828, 0x4003937b30}, 0x4cc692bdd22942d8, 0x400397cc00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3828
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3286 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400130f220)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3269
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3813 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003704780, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000fce600, 0x1, 0x4000fce610, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3825 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001112310, {0x3e23828, 0x40036e4be0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3811
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3831 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001113540, {0x3e23828, 0x40036e5900})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3820
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3812 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3978 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003a96100, {0x3e23828, 0x4003994820}, {0xffff73b89ab8, 0x4001a20480}, {0x40037c5f08?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003a93980, {0x3e23828, 0x4003994820})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001955260, {0x3e23828, 0x4003994820}, {0x3e5f080, 0x4001a20480}, {0x4, {0x1, 0x1, 0xff}}, 0x40039f7500)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3811
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3916 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40028aefa0, {0x3e23828, 0x4003995180}, 0x4cc692bdd22942dc, 0x400397d8c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3836
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3805 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3795
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3887 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002400fc8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3841
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3811 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003704640, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000fce230, 0x1, 0x4000fce240, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 642
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3889 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002401d48)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3848
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3885 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002402b48)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3834
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3908 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e23828, 0x4003608c80}, 0x4000dc2bc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3829
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3837 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3820
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3922 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000afa240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3851
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3851 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3813
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3906 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40036e0b00, 0x4003949c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3828
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3946 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000afab40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3855 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3818
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3905 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3828
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3881 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40023fc908)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3826
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3891 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002408248)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3802
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3863 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3908
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3864 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4002bffc70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3908
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3867 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038231d0, {0x400383ccd0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038231d0, {0x400383ccd0?, 0x4003603d40?, 0x4003ac5950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400383cc90, {0x400383ccd0?, 0x4003ac59d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400383cc90}, {0x400383ccd0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40018e2fc0, {0x400383ccd0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400383ccc0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400383ccc0, 0x40018e2fc0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40018e2fc0?, {0xffff73cec798, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce1570}, 0x400273b958?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002bffe10, {0x368b2c0, 0x4003ce1570}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003ac5d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40018e25a0, 0x4003ac5e30, 0x4003ac5e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40018e25a0, {0x368b2c0?, 0x4003ce1570?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400386a138, {0x368b2c0, 0x4003ce1570})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001218610)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4002bffc70, {0x3e3faf0, 0x4001218610})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3866 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3868 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x40033a5080, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3869 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000e5a000, {0x3e23828, 0x4003823450}, 0x4cc692bdd22942de, 0x4003813da0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3850
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3870 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003823950, {0x400383da50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003823950, {0x400383da50?, 0x4003603ed8?, 0x400298f930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400383da10, {0x400383da50?, 0x400298f9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400383da10}, {0x400383da50, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001aa8000, {0x400383da50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400383da40, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400383da40, 0x4001aa8000, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001aa8000?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40048e3e40}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003494750, {0x3612420, 0x40048e3e40}, 0x40048e3f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400298fd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40018e3d40, 0x400298fe10, 0x400298fe58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40018e3d40, {0x3612420?, 0x40048e3e40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400386a660, {0x3612420, 0x40048e3e40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4001218d90)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000e5a000)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3850
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3871 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000e5a000)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3850
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3872 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3850
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3921 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x400372d280, 0x400383d3b0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3850
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3923 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e23828, 0x4003608d20}, 0x40010c8c40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3851
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3926 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3870
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3919 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3836
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3920 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40036e1080, 0x400398b770)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3836
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3927 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000e5a000, {0x3e3fa98, 0x4001218d90})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3870
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3938 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e23828, 0x40036090e0}, 0x4000dc37c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3837
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3941 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000e5a1e0, {0x3e23828, 0x4003995540}, 0x4cc692bdd22942da, 0x400397dd40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3854
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3942 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003995e50, {0x40039a48e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003995e50, {0x40039a48e0?, 0x40037c5cf8?, 0x4002c7b930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a48a0, {0x40039a48e0?, 0x4002c7b9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a48a0}, {0x40039a48e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001b55d40, {0x40039a48e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a48d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a48d0, 0x4001b55d40, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001b55d40?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40048e3cc0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003174270, {0x3612420, 0x40048e3cc0}, 0x40048e3f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002c7bd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001b55b00, 0x4002c7be10, 0x4002c7be58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001b55b00, {0x3612420?, 0x40048e3cc0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f80f0, {0x3612420, 0x40048e3cc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40013f0200)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000e5a1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3854
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3928 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x1945910?, {0x3e23828, 0x4003823a90}, {0x3e5f080?, 0x4000afa240?}, 0x4000fcf6b0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3813
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 4023 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003ab3000, {0x3e23828, 0x4003823a90}, {0xffff73b89ab8, 0x4000afa240}, {0x4003a9c798?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003ab69c0, {0x3e23828, 0x4003823a90})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40023562a0, {0x3e23828, 0x4003823a90}, {0x3e5f080, 0x4000afa240}, {0x2, {0x1, 0x1, 0xff}}, 0x4003aa58c0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3813
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3931 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40028ae780, {0x3e23828, 0x4003823ea0}, 0x4cc692bdd22942e2, 0x4003a2e960)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3943 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000e5a1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3854
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3944 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3854
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3945 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x400372d580, 0x400398bdd0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3854
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3947 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e23828, 0x4003609090}, 0x4000dc3a80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3950 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40037d82a0?, {0x3e23828, 0x4003995900}, {0x3e5f080?, 0x4001a21d40?}, 0x4001112a80)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3820
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3932 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a327d0, {0x4003a30be0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a327d0, {0x4003a30be0?, 0x4003a34108?, 0x4003825930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a30ba0, {0x4003a30be0?, 0x40038259b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a30ba0}, {0x4003a30be0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400226c5a0, {0x4003a30be0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a30bd0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a30bd0, 0x400226c5a0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400226c5a0?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4004a28580}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003494c30, {0x3612420, 0x4004a28580}, 0x4004a29f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003825d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400226c360, 0x4003825e10, 0x4003825e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400226c360, {0x3612420?, 0x4004a28580?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400386aba0, {0x3612420, 0x4004a28580})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40012195b0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40028ae780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3933 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40028ae780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 4016 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003ab2500, {0x3e23828, 0x4003995900}, {0xffff73b89ab8, 0x4001a21d40}, {0x4003a9c5a0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003aa1e00, {0x3e23828, 0x4003995900})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40023567e0, {0x3e23828, 0x4003995900}, {0x3e5f080, 0x4001a21d40}, {0x1, {0x1, 0x1, 0xff}}, 0x4003aa4e40)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3820
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3934 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3935 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40036e0580, 0x4003a300f0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3804
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3953 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a90910, {0x40039a5300, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a90910, {0x40039a5300?, 0x40037c5da0?, 0x4002e95930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a52c0, {0x40039a5300?, 0x4002e959b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a52c0}, {0x40039a5300, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002245560, {0x40039a5300, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a52f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a52f0, 0x4002245560, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002245560?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40048e3c40}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40031744e0, {0x3612420, 0x40048e3c40}, 0x40048e3f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002e95d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002245200, 0x4002e95e10, 0x4002e95e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002245200, {0x3612420?, 0x40048e3c40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f83c0, {0x3612420, 0x40048e3c40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40013f06f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4001d13c20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3843
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3954 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4001d13c20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3843
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3955 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3843
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3956 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x400372ce00, 0x4003a302d0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3969 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3942
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3958 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e23828, 0x40036c9900}, 0x40010c9200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3844
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3961 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3917
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3970 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000e5a1e0, {0x3e3fa98, 0x40013f0200})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3942
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3962 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40028aefa0, {0x3e3fa98, 0x40012194f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3917
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3971 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x400397d860?, {0x3e23828, 0x4003a90050}, {0x3e5f080?, 0x4000afab40?}, 0x400116e640)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3818
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 4100 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003afe280, {0x3e23828, 0x4003a90050}, {0xffff73b89ab8, 0x4000afab40}, {0x4003a9d2d8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003ae39e0, {0x3e23828, 0x4003a90050})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4002356700, {0x3e23828, 0x4003a90050}, {0x3e5f080, 0x4000afab40}, {0x5, {0x1, 0x1, 0xff}}, 0x4003afc6c0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3818
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3974 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003a90460}, {0x3e5f080?, 0x4001a8ec60?}, 0x4000f3aad0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3797
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3963 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3932
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3964 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40028ae780, {0x3e3fa98, 0x40012195b0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3932
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3965 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001a86a20)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3805
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3966 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e23828, 0x40036c98b0}, 0x40010c9600)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3805
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3986 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x4003a2ea80?, {0x3e23828, 0x4003a32c80}, {0x3e5f080?, 0x4001a86a20?}, 0x4000ed3c10)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3795
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3984 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003a96b80, {0x3e23828, 0x4003a32c80}, {0xffff73b89ab8, 0x4001a86a20}, {0x4003a9c0f0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003aa04e0, {0x3e23828, 0x4003a32c80})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40019548c0, {0x3e23828, 0x4003a32c80}, {0x3e5f080, 0x4001a86a20}, {0x7, {0x1, 0x1, 0xff}}, 0x40039f7ce0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3795
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3998 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003a17400, {0x3e23828, 0x4003a90460}, {0xffff73b89ab8, 0x4001a8ec60}, {0x4003a34468?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003a39bc0, {0x3e23828, 0x4003a90460})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001954fc0, {0x3e23828, 0x4003a90460}, {0x3e5f080, 0x4001a8ec60}, {0x8, {0x1, 0x1, 0xff}}, 0x4003a6c240)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3797
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3976 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3953
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3977 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4001d13c20, {0x3e3fa98, 0x40013f06f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3953
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3989 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4001d13680, {0x3e23828, 0x4003a333b0}, 0x4cc692bdd22942e4, 0x4003a2fce0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3791
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3979 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e23828, 0x4003994820}, 0x40011508c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3982 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3990
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3983 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4001d13680, {0x3e3fa98, 0x40013f0e00})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3990
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3990 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a910e0, {0x4003a9a2e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a910e0, {0x4003a9a2e0?, 0x4003a9c018?, 0x4003829930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a9a2a0, {0x4003a9a2e0?, 0x40038299b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a9a2a0}, {0x4003a9a2e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002292ea0, {0x4003a9a2e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a9a2d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a9a2d0, 0x4002292ea0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002292ea0?, {0xffff73cec798, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4004a281c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003174a90, {0x3612420, 0x4004a281c0}, 0x4004a29f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003829d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002292b40, 0x4003829e10, 0x4003829e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002292b40, {0x3612420?, 0x4004a281c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f8768, {0x3612420, 0x4004a281c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40013f0e00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4001d13680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3791
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3991 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4001d13680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3791
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3992 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3791
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3993 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x400384b600, 0x4003a31ad0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3791
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 4001 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e23828, 0x4003a32c80}, 0x4001796240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3984
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4004 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3966
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4005 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003174d00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3966
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4008 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a91860, {0x4003a9b720, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a91860, {0x4003a9b720?, 0x4003a9c318?, 0x4002c42950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a9b6e0, {0x4003a9b720?, 0x4002c429d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a9b6e0}, {0x4003a9b720, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40022b6900, {0x4003a9b720, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a9b710, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a9b710, 0x40022b6900, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40022b6900?, {0xffff73cec798, 0x680cae0}, 0x35dd8a0?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce0ee0}, 0x30?, 0x3314d60?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003174ea0, {0x368b2c0, 0x4003ce0ee0}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002c42d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40022b65a0, 0x4002c42e30, 0x4002c42e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40022b65a0, {0x368b2c0?, 0x4003ce0ee0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f8cd8, {0x368b2c0, 0x4003ce0ee0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40013f1800)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003174d00, {0x3e3faf0, 0x40013f1800})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4007 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4009 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002543b80, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4010 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3938
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4011 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003174f70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3938
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4014 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a91b80, {0x4003aa8250, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a91b80, {0x4003aa8250?, 0x4003a9c480?, 0x4002989950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003aa8210, {0x4003aa8250?, 0x40029899d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003aa8210}, {0x4003aa8250, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40022b7200, {0x4003aa8250, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003aa8240, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003aa8240, 0x40022b7200, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40022b7200?, {0xffff73cec798, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce1110}, 0x4002989958?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003175110, {0x368b2c0, 0x4003ce1110}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002989d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40022b6fc0, 0x4002989e30, 0x4002989e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40022b6fc0, {0x368b2c0?, 0x4003ce1110?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f90c8, {0x368b2c0, 0x4003ce1110})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40013f1ed0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003174f70, {0x3e3faf0, 0x40013f1ed0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4013 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4015 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x4002543c30, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4017 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e23828, 0x4003995900}, 0x4001797440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4016
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4020 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x4003995900?, {0x3e23828, 0x4003ab4190}, {0x3e5f080?, 0x40019d4000?}, 0x4000d21950)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3793
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 4070 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003ac9b80, {0x3e23828, 0x4003ab4190}, {0xffff73b89ab8, 0x40019d4000}, {0x4003a9ce40?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003ae2ea0, {0x3e23828, 0x4003ab4190})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40019547e0, {0x3e23828, 0x4003ab4190}, {0x3e5f080, 0x40019d4000}, {0x6, {0x1, 0x1, 0xff}}, 0x4003abd6e0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3793
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 4024 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e23828, 0x4003823a90}, 0x400118c4c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4027 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3923
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4028 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40031755f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3923
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4031 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003ab4c30, {0x4003aba5b0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003ab4c30, {0x4003aba5b0?, 0x4003a9c9a8?, 0x4002190950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003aba570, {0x4003aba5b0?, 0x40021909d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003aba570}, {0x4003aba5b0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40012bed80, {0x4003aba5b0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003aba5a0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003aba5a0, 0x40012bed80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40012bed80?, {0xffff73cec798, 0x680cae0}, 0x2f4d90?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce1420}, 0x4002190c88?, 0x2a200?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003175790, {0x368b2c0, 0x4003ce1420}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002190d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40012beb40, 0x4002190e30, 0x4002190e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40012beb40, {0x368b2c0?, 0x4003ce1420?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039f9830, {0x368b2c0, 0x4003ce1420})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40013f9000)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40031755f0, {0x3e3faf0, 0x40013f9000})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4030 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4032 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x4002543ce0, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3995 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e23828, 0x40036c9860}, 0x40010c9d40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3792
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3999 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3995
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4000 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40034951e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3995
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4033 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003994820}, 0x40039a59b0, 0x40013f9430)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003994820})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4034 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40036e0300, {0x3e23828, 0x4003994820}, {0xffff73b89ab8, 0x4001a20480}, {0x40038efc00?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x40036ced80, {0x3e23828, 0x4003994820}, {0xffff73b89ab8, 0x4001a20480}, {0x4000dff320, 0x1, 0x206bc?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003994820})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4035 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400058e9a0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400399faf8}, 0x40039f75c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4033
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4036 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e236d0, 0x680cae0}, 0x400118cd40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4035
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4039 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40036e0200, {0x3e23828, 0x4003994820}, {0xffff73b89ab8, 0x4001a20480}, {0x40038efdc0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003994820})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4040 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40036e0280, {0x3e23828, 0x4003994820}, {0xffff73b89ab8, 0x4001a20480}, {0x40038efca0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003994820})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4041 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e23828, 0x4003994820}, 0x400118d140)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4040
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4044 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e23828, 0x4003a90460}, 0x400118d240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3998
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4047 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e23828, 0x4003994820}, 0x400118d440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4039
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4066 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x40038cc370, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4056 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a33e50, {0x4003a7a0a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a33e50, {0x4003a7a0a0?, 0x4003a345e8?, 0x4002c54950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a7a060, {0x4003a7a0a0?, 0x4002c549d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a7a060}, {0x4003a7a0a0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40022e3c20, {0x4003a7a0a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a7a090, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a7a090, 0x40022e3c20, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40022e3c20?, {0xffff73cec798, 0x680cae0}, 0xffffbac45102?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce16c0}, 0x8000000000068?, 0xffff73e00158?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003495380, {0x368b2c0, 0x4003ce16c0}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002c54d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40022e39e0, 0x4002c54e30, 0x4002c54e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40022e39e0, {0x368b2c0?, 0x4003ce16c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400386b9b0, {0x368b2c0, 0x4003ce16c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001402f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40034951e0, {0x3e3faf0, 0x4001402f80})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4050 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4067 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a20480, {0x3e23828, 0x4003994820}, 0x400118d5c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4034
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4071 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e23828, 0x4003ab4190}, 0x400118da80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4070
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4074 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003995900}, 0x4003aa86c0, 0x400148d0c0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003995900})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4016
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4051 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003823a90}, 0x4003aa9a70, 0x4001403530)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003823a90})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4052 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400384bb80, {0x3e23828, 0x4003823a90}, {0xffff73b89ab8, 0x4000afa240}, {0x4002312d80?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400365ede0, {0x3e23828, 0x4003823a90}, {0xffff73b89ab8, 0x4000afa240}, {0x400187a5f8, 0x1, 0x13dd1f8?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003823a90})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4053 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e23828, 0x4003823a90}, 0x4001624180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4052
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4057 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x4002b8e420, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4058 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003a32c80}, 0x4003a9aba0, 0x4001403790)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003a32c80})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3984
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4059 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423680, {0x3e23828, 0x4003a32c80}, {0xffff73b89ab8, 0x4001a86a20}, {0x4002312f40?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x40036ce240, {0x3e23828, 0x4003a32c80}, {0xffff73b89ab8, 0x4001a86a20}, {0x400187a640, 0x1, 0x4003a37c00?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003a32c80})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3984
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4060 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400384ba80, {0x3e23828, 0x4003823a90}, {0xffff73b89ab8, 0x4000afa240}, {0x4002313260?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003823a90})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4061 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400384bb00, {0x3e23828, 0x4003823a90}, {0xffff73b89ab8, 0x4000afa240}, {0x4002313000?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003823a90})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4075 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c880, {0x3e23828, 0x4003995900}, {0xffff73b89ab8, 0x4001a21d40}, {0x4003af4100?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400365f920, {0x3e23828, 0x4003995900}, {0xffff73b89ab8, 0x4001a21d40}, {0x4000dff470, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003995900})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4016
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4062 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e23828, 0x4003823a90}, 0x4001624a00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4061
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4081 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400058f0a0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003a98278}, 0x40039f7da0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4058
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4082 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e236d0, 0x680cae0}, 0x4001624c40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4081
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4076 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3958
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4085 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423580, {0x3e23828, 0x4003a32c80}, {0xffff73b89ab8, 0x4001a86a20}, {0x4002313380?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003a32c80})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3984
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4077 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003af80d0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3958
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4086 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423600, {0x3e23828, 0x4003a32c80}, {0xffff73b89ab8, 0x4001a86a20}, {0x4002313140?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003a32c80})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3984
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4119 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003af2780, {0x4003aef600, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003af2780, {0x4003aef600?, 0x4003a9d0c8?, 0x4003ace950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003aef5c0, {0x4003aef600?, 0x4003ace9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003aef5c0}, {0x4003aef600, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002749560, {0x4003aef600, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003aef5f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003aef5f0, 0x4002749560, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002749560?, {0xffff73cec798, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce1960}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003af8270, {0x368b2c0, 0x4003ce1960}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003aced98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002749320, 0x4003acee30, 0x4003acee78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002749320, {0x368b2c0?, 0x4003ce1960?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003ae45e8, {0x368b2c0, 0x4003ce1960})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400148c4a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003af80d0, {0x3e3faf0, 0x400148c4a0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4079 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4087 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e23828, 0x4003a32c80}, 0x4001625000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4086
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4090 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e23828, 0x4003823a90}, 0x4001625200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4060
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4093 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x4002b8e4d0, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4080 [select, 7 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3947
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 4097 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003af8340)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3947
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 4131 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003af29b0, {0x4003aefd80, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003af29b0, {0x4003aefd80?, 0x4003a9d200?, 0x40028f7950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003aefd40, {0x4003aefd80?, 0x40028f79d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003aefd40}, {0x4003aefd80, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400277e120, {0x4003aefd80, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003aefd70, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003aefd70, 0x400277e120, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400277e120?, {0xffff73cec798, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x4003ce12d0}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003af84e0, {0x368b2c0, 0x4003ce12d0}, 0x4003ce1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40028f7d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002749e60, 0x40028f7e30, 0x40028f7e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002749e60, {0x368b2c0?, 0x4003ce12d0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003ae48a0, {0x368b2c0, 0x4003ce12d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400148ca20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003af8340, {0x3e3faf0, 0x400148ca20})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4099 [select, 7 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4094 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e23828, 0x4003a32c80}, 0x4001625480)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4085
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4101 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e23828, 0x4003a90050}, 0x4001652d00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4100
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4104 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a86a20, {0x3e23828, 0x4003a32c80}, 0x4001652e00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4059
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4107 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000594ee0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003ab80b8}, 0x4003aa5980)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4051
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4113 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002b8e580, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4114 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c780, {0x3e23828, 0x4003995900}, {0xffff73b89ab8, 0x4001a21d40}, {0x4003af4320?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003995900})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4016
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4108 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afa240, {0x3e236d0, 0x680cae0}, 0x4001652f00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4107
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4111 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000594150, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003a99778}, 0x4003aa4f00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4074
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4112 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e236d0, 0x680cae0}, 0x4001653040)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4111
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4132 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x40038cc420, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4133 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e23828, 0x4003995900}, 0x40016531c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4075
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4115 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c800, {0x3e23828, 0x4003995900}, {0xffff73b89ab8, 0x4001a21d40}, {0x40023134c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003995900})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4016
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4116 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e23828, 0x4003995900}, 0x4001625940)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4115
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4120 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x4002b8e630, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4136 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a21d40, {0x3e23828, 0x4003995900}, 0x4001653380)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4114
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4121 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x4002b8e6e0, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4139 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x40038cc4d0, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4140 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003ab4190}, 0x4003aee840, 0x4001670670)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003ab4190})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4070
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4158 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x4002b8eb00, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4124 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002b8e790, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4125 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002b8e840, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4126 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002b8e8f0, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4127 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174d00, 0x4002b8e9a0, 0x4003aa43c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4005
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4157 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x4002b8ea50, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4178 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003a90460}, 0x4003a6ee40, 0x4001567250)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003a90460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3998
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4160 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x4002b8ec60, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4159 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x4002b8ebb0, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4184 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c380, {0x3e23828, 0x4003a90050}, {0xffff73b89ab8, 0x4000afab40}, {0x4003c54a40?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400365f740, {0x3e23828, 0x4003a90050}, {0xffff73b89ab8, 0x4000afab40}, {0x400187ae28, 0x1, 0x4003b39dc0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003a90050})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4100
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4183 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40025f08c0, {0x3e23828, 0x4003a90050}, 0x4003b88180, 0x40015676a0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003a90050})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4100
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4180 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e23828, 0x4003a90460}, 0x4000f34f00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4179
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4179 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423b00, {0x3e23828, 0x4003a90460}, {0xffff73b89ab8, 0x4001a8ec60}, {0x4003c54860?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x40036ce420, {0x3e23828, 0x4003a90460}, {0xffff73b89ab8, 0x4001a8ec60}, {0x400187adf0, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003a90460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3998
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4177 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x4002b8ed10, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4141 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423200, {0x3e23828, 0x4003ab4190}, {0xffff73b89ab8, 0x40019d4000}, {0x4003af46c0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x40036ce060, {0x3e23828, 0x4003ab4190}, {0xffff73b89ab8, 0x40019d4000}, {0x4000dff688, 0x1, 0x4003baa700?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003ab4190})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4070
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4142 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e23828, 0x4003ab4190}, 0x40013e8300)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4141
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4161 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x40038cc580, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4162 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x40038cc630, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4163 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003174f70, 0x40038cc6e0, 0x4003aa4a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4011
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4164 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x40038cc790, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4165 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400062bea0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003af0278}, 0x4003abd7a0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4140
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4166 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e236d0, 0x680cae0}, 0x40013e9580)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4165
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4169 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423100, {0x3e23828, 0x4003ab4190}, {0xffff73b89ab8, 0x40019d4000}, {0x4003af4ba0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003ab4190})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4070
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4170 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423180, {0x3e23828, 0x4003ab4190}, {0xffff73b89ab8, 0x40019d4000}, {0x4003af4a20?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003ab4190})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4070
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4171 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e23828, 0x4003ab4190}, 0x4001a6c000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4170
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4174 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40019d4000, {0x3e23828, 0x4003ab4190}, 0x4001a6d140)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4169
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4209 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x40038cc840, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4185 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e23828, 0x4003a90050}, 0x4000f352c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4184
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4188 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40005c2380, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003a37e78}, 0x4003a6c300)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4178
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4189 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e236d0, 0x680cae0}, 0x4000f35540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4188
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4192 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423a00, {0x3e23828, 0x4003a90460}, {0xffff73b89ab8, 0x4001a8ec60}, {0x4003c54d40?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003a90460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3998
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4193 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003423a80, {0x3e23828, 0x4003a90460}, {0xffff73b89ab8, 0x4001a8ec60}, {0x4003c54b80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003a90460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3998
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4194 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e23828, 0x4003a90460}, 0x4000f35840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4193
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4197 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c280, {0x3e23828, 0x4003a90050}, {0xffff73b89ab8, 0x4000afab40}, {0x4003c54dc0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003a90050})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4100
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4198 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400372c300, {0x3e23828, 0x4003a90050}, {0xffff73b89ab8, 0x4000afab40}, {0x4003c54cc0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003a90050})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 4100
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4199 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x4002b8edc0, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4210 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002bffc70, 0x40038cc8f0, 0x4003813920)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3864
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4200 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e23828, 0x4003a90050}, 0x4000f35e40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4197
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4203 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x4002b8ee70, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4204 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004d38f0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003af13f8}, 0x4003afc780)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4183
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4205 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e236d0, 0x680cae0}, 0x4000f4c240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4204
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4208 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031755f0, 0x4002b8ef20, 0x4003aa5f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4028
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4225 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000afab40, {0x3e23828, 0x4003a90050}, 0x4000f4c3c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4198
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4228 [select, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001a8ec60, {0x3e23828, 0x4003a90460}, 0x4000f4c4c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4192
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4231 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x4002b8efd0, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4232 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x4002b8f080, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4211 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x40038cc9a0, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4212 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x40038cca50, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4213 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x40038ccb00, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4214 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x40038ccbb0, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4215 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x40038ccc60, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4233 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af8340, 0x4002b8f130, 0x4003afc300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4097
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4234 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40034951e0, 0x4002b8f1e0, 0x4003a6c660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4000
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4216 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x40038ccd10, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4217 [select, 7 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x40038ccdc0, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4218 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003af80d0, 0x40038cce70, 0x4003abdda0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4077
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4620 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4003063040})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40028c8dc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001b8ac70, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5376 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41070, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f500?, 0x40052cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f500, {0x40052cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f500, {0x40052cb000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d4b8, {0x40052cb000?, 0x13?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40027759e0, {0x40052cb000?, 0x400408ed18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400330a5a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400330a5a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40027759e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5374
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4628 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40022883c0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40028db8c0}, 0x4002465260, 0x0, 0x40013fde30, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4594
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5380 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b40f78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f580?, 0x40052cd000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f580, {0x40052cd000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f580, {0x40052cd000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d520, {0x40052cd000?, 0x12?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002775d40, {0x40052cd000?, 0x4003f09d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400330aae0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400330aae0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002775d40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5378
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4627 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x7000102?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001c55520?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4594
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4626 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002c71590})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002288280, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40019887f0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4594
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4639 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002288c80, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001b99d10, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4660 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40028c9900, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002a31860}, 0x4001b8b800, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4623 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40028c9040, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4003063180, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5339 [select]:
net/http.(*persistConn).writeLoop(0x40027485a0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5336
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5373 [select]:
net/http.(*persistConn).writeLoop(0x4002775200)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5370
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4871 [select, 5 minutes]:
net/http.(*persistConn).writeLoop(0x4002244fc0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4869
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5348 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2188, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476e900?, 0x40052b1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476e900, {0x40052b1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476e900, {0x40052b1000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c798, {0x40052b1000?, 0x12?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002749200, {0x40052b1000?, 0x4002a39d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003266f60)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003266f60, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002749200)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5346
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10333 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4701
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5364 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41358, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f380?, 0x40052c5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f380, {0x40052c5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f380, {0x40052c5000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d2e0, {0x40052c5000?, 0xf?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002774900, {0x40052c5000?, 0x4003dc4d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400334e4e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400334e4e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002774900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5362
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4622 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40028c8f00, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002a309c0}, 0x400044a0e0, 0x0, 0x4000dfb7a0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4612
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10656 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5369 [select]:
net/http.(*persistConn).writeLoop(0x4002774c60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5366
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4890 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff73bc2a40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40036ec500?, 0x4002801000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40036ec500, {0x4002801000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40036ec500, {0x4002801000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000dfef70, {0x4002801000?, 0x72?, 0x4003b3a158?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003b3a150, {0x4002801000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002fcf740)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002fcf740, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400412c240, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10509 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5311 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2378, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476e800?, 0x40051c3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476e800, {0x40051c3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476e800, {0x40051c3000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001622cd0, {0x40051c3000?, 0x13?, 0x4004093d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002748900, {0x40051c3000?, 0x4003dc6d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40030ef920)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40030ef920, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002748900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5340
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4608 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400109dae0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4594
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 10664 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4644 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b9540, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001a349a0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4623
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4698 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400130f7c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 5428 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b40c90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003546180?, 0x40023de000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003546180, {0x40023de000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003546180, {0x40023de000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400154caa0, {0x40023de000?, 0x72?, 0x40018f3388?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40018f3380, {0x40023de000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40025e1500)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40025e1500, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001660d80, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5365 [select]:
net/http.(*persistConn).writeLoop(0x4002774900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5362
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4702 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b7fcc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40031888a0}, 0x40003d83f0, 0x0, 0x40011721b0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5368 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41260, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f400?, 0x40052c7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f400, {0x40052c7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f400, {0x40052c7000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d320, {0x40052c7000?, 0x11?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002774c60, {0x40052c7000?, 0x4003e87d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400334f920)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400334f920, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002774c60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5366
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 12052 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12067 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4618 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400130e320)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4612
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4701 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40018b7808?, 0x40017f0390?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40018abd40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 5338 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2568, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476e780?, 0x40049b7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476e780, {0x40049b7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476e780, {0x40049b7000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c018, {0x40049b7000?, 0x13?, 0x4004093d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40027485a0, {0x40049b7000?, 0x4002168d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40032ad620)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40032ad620, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40027485a0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5336
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4648 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40026b9b80, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002b8bb00}, 0x40018ab360, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5345 [select]:
net/http.(*persistConn).writeLoop(0x4002748ea0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5342
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4700 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400325bc70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b7fb80, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000627e00, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4798 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2c30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003cd1180?, 0x4000ed1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003cd1180, {0x4000ed1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003cd1180, {0x4000ed1000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000ab8a20, {0x4000ed1000?, 0x72?, 0x40038492f8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40038492f0, {0x4000ed1000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40024b3500)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40024b3500, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40030274d0, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4629 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002288640, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002c716d0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4594
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4621 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4004092fa8?, 0x258f874?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40003eac08?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4612
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 5352 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2090, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f100?, 0x40052b9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f100, {0x40052b9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f100, {0x40052b9000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c8d0, {0x40052b9000?, 0xf?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40027497a0, {0x40052b9000?, 0x4003e81d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003267440)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003267440, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40027497a0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5350
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4584 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2948, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40022efe80?, 0x4000d9b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40022efe80, {0x4000d9b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40022efe80, {0x4000d9b000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400187b488, {0x4000d9b000?, 0x72?, 0x4000eeb3b8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000eeb3b0, {0x4000d9b000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002071a40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002071a40, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400265eab0, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4703 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b7fe00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400325be50, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5381 [select]:
net/http.(*persistConn).writeLoop(0x4002775d40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5378
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5385 [select]:
net/http.(*persistConn).writeLoop(0x400277e240)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5382
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5372 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41168, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f480?, 0x40052c9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f480, {0x40052c9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f480, {0x40052c9000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d350, {0x40052c9000?, 0xf?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002775200, {0x40052c9000?, 0x40021d0d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400330a180)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400330a180, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002775200)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5370
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5377 [select]:
net/http.(*persistConn).writeLoop(0x40027759e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5374
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4727 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002c137c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40031985a0}, 0x400007c1f0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4701
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4725 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002c12b40, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40001e9750, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4703
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4872 [IO wait, 5 minutes]:
internal/poll.runtime_pollWait(0xffff73bc2850, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1b200?, 0x4003459000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1b200, {0x4003459000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1b200, {0x4003459000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40015829b8, {0x4003459000?, 0x72?, 0x40037c0cf8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40037c0cf0, {0x4003459000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40034026c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40034026c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003d54480, {0x3e237f0, 0x400192f950})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1725
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5344 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2280, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476e880?, 0x40049bf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476e880, {0x40049bf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476e880, {0x40049bf000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124c0e8, {0x40049bf000?, 0xe?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002748ea0, {0x40049bf000?, 0x4004092d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40032665a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40032665a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002748ea0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5342
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5349 [select]:
net/http.(*persistConn).writeLoop(0x4002749200)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5346
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5353 [select]:
net/http.(*persistConn).writeLoop(0x40027497a0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5350
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5384 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b40e80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f600?, 0x40052d5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f600, {0x40052d5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f600, {0x40052d5000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d6a0, {0x40052d5000?, 0xe?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400277e240, {0x40052d5000?, 0x400408dd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400330aea0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400330aea0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400277e240)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5382
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4771 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2758, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003b6f280?, 0x4002667000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003b6f280, {0x4002667000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003b6f280, {0x4002667000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124d4e8, {0x4002667000?, 0x72?, 0x4002f01bc8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4002f01bc0, {0x4002667000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002fcefc0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002fcefc0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40032b54d0, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4870 [IO wait, 5 minutes]:
internal/poll.runtime_pollWait(0xffff73bc2660, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1af80?, 0x4003433000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1af80, {0x4003433000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1af80, {0x4003433000?, 0x1?, 0x4002ed5180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001582990, {0x4003433000?, 0xc?, 0x4004092d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002244fc0, {0x4003433000?, 0x18550?, 0x4003c3d0e0?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003402540)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003402540, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002244fc0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4869
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10241 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4701
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11531 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10508 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5309 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2470, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40044bda80?, 0x4005193000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40044bda80, {0x4005193000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40044bda80, {0x4005193000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001622cc8, {0x4005193000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001f31b00, {0x4005193000?, 0x40046d0d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40030ef860)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40030ef860, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001f31b00)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5307
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5356 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41548, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f280?, 0x40052bd000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f280, {0x40052bd000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f280, {0x40052bd000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124ce18, {0x40052bd000?, 0xf?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002749d40, {0x40052bd000?, 0x40036f2d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003267800)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003267800, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002749d40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5354
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5361 [select]:
net/http.(*persistConn).writeLoop(0x4002774360)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5358
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 7518 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40019ef390, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019ef380)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0x4000449810)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:159 +0x134
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 818
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:176 +0x60

goroutine 5312 [select]:
net/http.(*persistConn).writeLoop(0x4002748900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5340
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 11770 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5310 [select]:
net/http.(*persistConn).writeLoop(0x4001f31b00)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5307
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5357 [select]:
net/http.(*persistConn).writeLoop(0x4002749d40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5354
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 11534 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5360 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b41450, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400476f300?, 0x40052bf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400476f300, {0x40052bf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400476f300, {0x40052bf000?, 0x40025a9340?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400124cfa0, {0x40052bf000?, 0x13?, 0x4003f07d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002774360, {0x40052bf000?, 0x4003b15d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003267c20)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003267c20, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002774360)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5358
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 11511 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11767 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5915 [IO wait]:
internal/poll.runtime_pollWait(0xffff73bc2b38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004fdd980?, 0x4003a5e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004fdd980, {0x4003a5e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004fdd980, {0x4003a5e000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001280d80, {0x4003a5e000?, 0x72?, 0x400522f8f8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400522f8f0, {0x4003a5e000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003535da0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003535da0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400528b950, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 11533 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10178 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:117 +0x68
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn in goroutine 10177
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:116 +0xb4

goroutine 11258 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11768 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11539 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10506 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 7741 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400399db48, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400399db38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400399db30, {0x40046bddc4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003302cc8?}, {0x40046bddc4?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x400399db00}, {0x40046bddc4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40050bc630, {0x40050cc000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400472a4b0, 0x0, {0x3e02238, 0x40055b1300})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000ed56a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40050a9d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 217
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11254 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10655 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11259 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10690 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10164 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40018027c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018027b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40018027b0, {0x400161d69c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003b18cc8?}, {0x400161d69c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4001802780}, {0x400161d69c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4004081338, {0x4000b03000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40039a9d60, 0x0, {0x3e02238, 0x4004db3600})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018c1420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40012cac40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 708
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11769 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10689 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9611 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40035119c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40035119b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40035119b0, {0x400280a001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4005d33cc8?}, {0x400280a001?, 0x4005d33cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40009117c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40009117c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40009117c0, {0x30150e0, 0x40040e80d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4000eeaf30, {0x400576d400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002f5eaa0, 0x0, {0x3e02238, 0x4000ed8bc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400095bc20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40037daf40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 752
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10661 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11510 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11538 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10484 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11540 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5571 [IO wait]:
internal/poll.runtime_pollWait(0xffff73b40d88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002764980?, 0x4004671000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002764980, {0x4004671000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002764980, {0x4004671000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163ea80, {0x4004671000?, 0x72?, 0x4001283478?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001283470, {0x4004671000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40036a4720)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40036a4720, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4002baf560, {0x3e237f0, 0x4000710600})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1642
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10691 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11256 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11257 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10487 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11773 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12054 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11766 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11772 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11070 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4001802648, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001802638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4001802630, {0x400111fd6c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003dc3cc8?}, {0x400111fd6c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff73c9cd00, 0x4001802600}, {0x400111fd6c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4002254618, {0x400576cc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002a221e0, 0x0, {0x3e02238, 0x4000c9e180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001b89ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40016b6c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10505 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10507 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10662 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11532 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10103 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4002f5f9a0, {0x40022a6ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002f5f9a0, {0x40022a6ee0?, 0x4004ff2d38?, 0x400421f510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40022a6c60, {0x40022a6ee0?, 0x400421f598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40022a6c60}, {0x40022a6ee0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003b62a20, {0x40022a6ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40022a6ed0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40022a6ed0, 0x4003b62a20, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400421f7c8?, {0xffff73cec798, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400130f860}, 0x4000a94380?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x400566c690, {0x35bf9e0, 0x400130f860})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0x4000cf6080)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1730 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x3e31c48?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 10101
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 10486 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11226 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10927 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11225 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10485 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10663 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11227 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12065 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11224 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11771 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10942 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10944 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10977 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11537 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10943 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12047 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4001607110, 0x1d)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001607100)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40016070c0, {0x3e23828, 0x4002e7e410}, {0x4003551d10, 0x28}, 0x12b, {0x4001b97065, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 10101
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 12048 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4001607210, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001607200)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40016071c0, {0x3e23828, 0x4002e7e500}, {0x4001f8b980, 0x35}, 0x11, {0x400136e8a5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1266
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 10926 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10967 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10928 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10945 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12053 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10966 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12068 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12056 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12055 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4627
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12066 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12069 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4621
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4
