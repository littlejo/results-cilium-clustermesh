## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
5     10.100.58.4:2379      sync    
6     10.100.168.114:8080   sync    
1     10.100.0.1:443        sync    
2     10.100.152.246:443    sync    
3     10.100.0.10:53        sync    
4     10.100.0.10:9153      sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_02904
Key              Value         State   Error
Ingress: 0 ANY   0 292 23504           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 85 7438             

## Map: cilium_policy_01164
Key              Value           State   Error
Ingress: 0 ANY   0 2000 211441           
Egress: 0 ANY    0 2587 284904           
Ingress: 1 ANY   0 2075 200723           

## Map: cilium_policy_00941
Key              Value           State   Error
Ingress: 0 ANY   0 33 4399               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3540 302490           

## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440027343750           
AgentLiveness   633862394699               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_tunnel_map
Key        Value              State   Error
10.1.0.0   172.31.234.224:0   sync    
10.3.0.0   172.31.224.68:0    sync    
10.4.0.0   172.31.167.173:0   sync    
10.5.0.0   172.31.249.188:0   sync    
10.7.0.0   172.31.208.9:0     sync    
10.6.0.0   172.31.162.53:0    sync    
10.0.0.0   172.31.190.177:0   sync    

## Map: cilium_policy_01991
Key              Value         State   Error
Ingress: 0 ANY   0 63 5606             
Egress: 0 ANY    0 130 12774           
Ingress: 1 ANY   0 617 53650           

## Map: cilium_policy_00165
Key              Value         State   Error
Ingress: 0 ANY   0 61 5770             
Egress: 0 ANY    0 126 12369           
Ingress: 1 ANY   0 627 54310           

## Map: cilium_policy_00782
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_lxc
Key                Value                                                                                             State   Error
10.2.0.168:0       id=1164  sec_id=225266 flags=0x0000 ifindex=15  mac=76:3C:8B:11:C5:68 nodemac=92:91:E9:DD:97:BF   sync    
10.2.0.25:0        id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F   sync    
10.2.0.36:0        id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0   sync    
10.2.0.161:0       (localhost)                                                                                       sync    
172.31.140.200:0   (localhost)                                                                                       sync    
10.2.0.185:0       id=165   sec_id=220496 flags=0x0000 ifindex=11  mac=46:36:24:79:0E:96 nodemac=D2:EB:38:26:91:7A   sync    
10.2.0.34:0        id=2904  sec_id=4     flags=0x0000 ifindex=7   mac=B2:1B:CB:22:75:F3 nodemac=82:1E:93:B4:D4:91    sync    
10.2.0.154:0       id=1991  sec_id=220496 flags=0x0000 ifindex=9   mac=36:6D:35:91:4A:8F nodemac=06:D0:08:A8:6B:B1   sync    
10.2.0.242:0       id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28   sync    

## Map: cilium_policy_01971
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
172.31.135.214/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.140.200/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.2.0.161/32       identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.244.238/32   identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    

## Map: cilium_lb4_services_v2
Key                       Value                State   Error
10.100.58.4:2379 (0)      0 1 (5) [0x0 0x0]    sync    
10.100.58.4:2379 (1)      9 0 (5) [0x0 0x0]    sync    
10.100.0.10:9153 (1)      4 0 (4) [0x0 0x0]    sync    
10.100.168.114:8080 (0)   0 1 (6) [0x0 0x0]    sync    
10.100.152.246:443 (0)    0 1 (2) [0x0 0x10]   sync    
10.100.0.10:9153 (0)      0 2 (4) [0x0 0x0]    sync    
10.100.0.10:53 (0)        0 2 (3) [0x0 0x0]    sync    
10.100.0.10:53 (2)        5 0 (3) [0x0 0x0]    sync    
10.100.0.1:443 (1)        1 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (0)        0 2 (1) [0x0 0x0]    sync    
10.100.0.10:9153 (2)      6 0 (4) [0x0 0x0]    sync    
10.100.0.1:443 (2)        8 0 (1) [0x0 0x0]    sync    
10.100.168.114:8080 (1)   10 0 (6) [0x0 0x0]   sync    
10.100.152.246:443 (1)    2 0 (2) [0x0 0x0]    sync    
10.100.0.10:53 (1)        3 0 (3) [0x0 0x0]    sync    

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
8     ANY://172.31.135.214   sync    
9     ANY://10.2.0.168       sync    
2     ANY://172.31.140.200   sync    
5     ANY://10.2.0.154       sync    
4     ANY://10.2.0.185       sync    
6     ANY://10.2.0.154       sync    
10    ANY://10.2.0.36        sync    
1     ANY://172.31.244.238   sync    
3     ANY://10.2.0.185       sync    

## Map: cilium_policy_02101
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_node_map
Cache is disabled


