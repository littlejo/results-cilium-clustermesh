xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 523
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 512
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 502
cilium_host(4) clsact/egress cil_from_host-cilium_host id 504
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 449
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 450
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 532
lxc6d3e55619805(9) clsact/ingress cil_from_container-lxc6d3e55619805 id 490
lxcb010f7dd4388(11) clsact/ingress cil_from_container-lxcb010f7dd4388 id 494
lxc6ea98be53e5b(15) clsact/ingress cil_from_container-lxc6ea98be53e5b id 595
lxc467576798b18(17) clsact/ingress cil_from_container-lxc467576798b18 id 3679
lxcb29fc3d997cf(19) clsact/ingress cil_from_container-lxcb29fc3d997cf id 3681
lxc60b0de84790a(21) clsact/ingress cil_from_container-lxc60b0de84790a id 3370

flow_dissector:

netfilter:

