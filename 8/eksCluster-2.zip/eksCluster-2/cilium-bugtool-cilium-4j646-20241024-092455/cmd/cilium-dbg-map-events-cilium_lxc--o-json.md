{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:35.075Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:35.076Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.402Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.403Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.443Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.465Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.478Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.675Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.683Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.721Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.739Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.767Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.060Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.100Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.112Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.144Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.159Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.187Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.376Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.393Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.423Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.441Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.460Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.765Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.815Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.820Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.863Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.867Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.895Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.102Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.120Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.144Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.159Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.180Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.549Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.619Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.632Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.664Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.701Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.702Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.898Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.904Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.939Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.947Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.975Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.363Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.366Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.398Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.433Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.441Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.681Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.693Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.723Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.728Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.762Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.997Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.039Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.050Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.077Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.099Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.140Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.311Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.323Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.364Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.367Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.408Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.635Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.673Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.677Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.719Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.726Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.769Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.976Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.978Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.981Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.982Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.017Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.629Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.630Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.678Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.683Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.717Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.922Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.924Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:08.571Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:08.581Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:09.971Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:16.742Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:17.019Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:23.799Z",
  "value": "id=941   sec_id=200572 flags=0x0000 ifindex=21  mac=22:48:82:13:1F:D7 nodemac=AA:47:2D:36:39:F0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.095Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.098Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.100Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:30.833Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:30.881Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:30.883Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.177Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.184Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.185Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:37.846Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:37.886Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:37.895Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.153Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.158Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.164Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:50.957Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:51.000Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:51.004Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:51.286Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:51.292Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:51.293Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.212Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.253Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.267Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.534Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.540Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:04.541Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:17.378Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:17.433Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:17.435Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:17.705Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:17.705Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:34.679Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:34.690Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:34.945Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:34.946Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:47.890Z",
  "value": "id=782   sec_id=207272 flags=0x0000 ifindex=17  mac=76:06:C7:E3:97:64 nodemac=62:9C:A0:3B:A9:28"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:47.894Z",
  "value": "id=1971  sec_id=221974 flags=0x0000 ifindex=19  mac=52:2A:91:1B:2E:80 nodemac=36:7E:22:05:E4:6F"
}

