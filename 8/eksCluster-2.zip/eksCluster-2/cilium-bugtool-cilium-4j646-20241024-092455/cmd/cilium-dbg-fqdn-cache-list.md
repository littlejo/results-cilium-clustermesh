Endpoint   Source   FQDN               TTL   ExpirationTime             IPs                                         
782        lookup   cilium.io.         30    2024-10-24T09:25:13.609Z   104.198.14.52                               
782        lookup   one.one.one.one.   30    2024-10-24T09:24:54.142Z   2606:4700:4700::1001,2606:4700:4700::1111   
782        lookup   one.one.one.one.   30    2024-10-24T09:24:54.142Z   1.0.0.1,1.1.1.1                             
1971       lookup   one.one.one.one.   13    2024-10-24T09:24:54.523Z   2606:4700:4700::1001,2606:4700:4700::1111   
1971       lookup   one.one.one.one.   13    2024-10-24T09:24:54.523Z   1.0.0.1,1.1.1.1                             
1971       lookup   cilium.io.         28    2024-10-24T09:25:13.693Z   104.198.14.52                               
