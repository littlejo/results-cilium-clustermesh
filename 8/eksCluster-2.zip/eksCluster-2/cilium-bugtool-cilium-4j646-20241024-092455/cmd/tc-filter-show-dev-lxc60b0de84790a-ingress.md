filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc60b0de84790a direct-action not_in_hw id 3370 tag c57099e3cbe756f1 jited 
