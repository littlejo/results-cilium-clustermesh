key: a5 00 00 00  value: fc 01 00 00
key: 0e 03 00 00  value: 52 0e 00 00
key: ad 03 00 00  value: 2c 0d 00 00
key: 8c 04 00 00  value: 52 02 00 00
key: b3 07 00 00  value: 5d 0e 00 00
key: c7 07 00 00  value: df 01 00 00
key: 58 0b 00 00  value: 18 02 00 00
Found 7 elements
