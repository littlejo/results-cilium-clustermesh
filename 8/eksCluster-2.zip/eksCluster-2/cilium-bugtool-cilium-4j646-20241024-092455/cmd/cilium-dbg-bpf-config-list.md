KEY             VALUE
AgentLiveness   632862043753
UTimeOffset     3378440027343750
