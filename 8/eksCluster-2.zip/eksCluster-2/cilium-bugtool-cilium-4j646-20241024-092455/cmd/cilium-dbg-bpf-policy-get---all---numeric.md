Endpoint ID: 165
Path: /sys/fs/bpf/tc/globals/cilium_policy_00165

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5770    61        0        
Allow    Ingress     1          ANY          NONE         disabled    54310   627       0        
Allow    Egress      0          ANY          NONE         disabled    12369   126       0        


Endpoint ID: 782
Path: /sys/fs/bpf/tc/globals/cilium_policy_00782

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 941
Path: /sys/fs/bpf/tc/globals/cilium_policy_00941

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4399     33        0        
Allow    Ingress     1          ANY          NONE         disabled    302490   3540      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1164
Path: /sys/fs/bpf/tc/globals/cilium_policy_01164

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    211441   2000      0        
Allow    Ingress     1          ANY          NONE         disabled    200723   2075      0        
Allow    Egress      0          ANY          NONE         disabled    284904   2587      0        


Endpoint ID: 1971
Path: /sys/fs/bpf/tc/globals/cilium_policy_01971

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1991
Path: /sys/fs/bpf/tc/globals/cilium_policy_01991

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5606    63        0        
Allow    Ingress     1          ANY          NONE         disabled    53650   617       0        
Allow    Egress      0          ANY          NONE         disabled    12774   130       0        


Endpoint ID: 2101
Path: /sys/fs/bpf/tc/globals/cilium_policy_02101

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2904
Path: /sys/fs/bpf/tc/globals/cilium_policy_02904

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23438   291       0        
Allow    Ingress     1          ANY          NONE         disabled    7438    85        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


