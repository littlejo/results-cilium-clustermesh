alloc: 75.94MB (79624448 bytes)
total-alloc: 1.44GB (1544553880 bytes)
sys: 108.11MB (113364276 bytes)
lookups: 0
mallocs: 46647278
frees: 46005769
heap-alloc: 75.94MB (79624448 bytes)
heap-sys: 93.33MB (97861632 bytes)
heap-idle: 6.76MB (7086080 bytes)
heap-in-use: 86.57MB (90775552 bytes)
heap-released: 2.17MB (2277376 bytes)
heap-objects: 641509
stack-in-use: 6.62MB (6946816 bytes)
stack-sys: 6.62MB (6946816 bytes)
stack-mspan-inuse: 1.21MB (1267040 bytes)
stack-mspan-sys: 1.21MB (1272960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 486.84KB (498529 bytes)
gc-sys: 4.54MB (4758016 bytes)
next-gc: when heap-alloc >= 84.54MB (88648888 bytes)
last-gc: 2024-10-24 09:24:34.670504082 +0000 UTC
gc-pause-total: 7.225524ms
gc-pause: 62418
gc-pause-end: 1729761874670504082
num-gc: 78
num-forced-gc: 0
gc-cpu-fraction: 0.0005906443423296839
enable-gc: true
debug-gc: false
