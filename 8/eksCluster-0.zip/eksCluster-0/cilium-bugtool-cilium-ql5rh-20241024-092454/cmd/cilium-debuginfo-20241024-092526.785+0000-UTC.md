# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
36         Disabled           Disabled          90675      k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.0.0.133   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
89         Disabled           Disabled          4          reserved:health                                                                       10.0.0.193   ready   
222        Disabled           Disabled          67854      k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.0.0.239   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
245        Disabled           Disabled          73336      k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.0.0.146   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
593        Disabled           Disabled          82485      k8s:eks.amazonaws.com/component=coredns                                               10.0.0.115   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2397       Disabled           Disabled          82485      k8s:eks.amazonaws.com/component=coredns                                               10.0.0.242   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2470       Disabled           Disabled          86420      k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.0.0.58    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh1                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
3414       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1a                                                                 
                                                           reserved:host                                                                                              
```

#### BPF Policy Get 36

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 36

```
Invalid argument: unknown type 36
```


#### Endpoint Get 36

```
[
  {
    "id": 36,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-36-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d6b061af-6992-48a2-b2e2-ca66af74b641"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-36",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.866Z",
            "success-count": 2
          },
          "uuid": "15661dff-97fa-4988-91a7-b63885792407"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-n4msm",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.864Z",
            "success-count": 1
          },
          "uuid": "e1f69ecc-9920-4c45-827f-a0bce912aa02"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-36",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.921Z",
            "success-count": 1
          },
          "uuid": "bbc8604e-6c7c-466c-87ca-e84d741138cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (36)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.895Z",
            "success-count": 33
          },
          "uuid": "f509248f-a784-440a-b894-de33dca80b97"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0cb1add8ac36d26abce10f32a4aeb85f8d8975559063ce2352b0bb47d4881c06:eth0",
        "container-id": "0cb1add8ac36d26abce10f32a4aeb85f8d8975559063ce2352b0bb47d4881c06",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-n4msm",
        "pod-name": "cilium-test-1/client2-57cf4468f-n4msm"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 90675,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.133",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:b7:5e:8a:85:d5",
        "interface-index": 19,
        "interface-name": "lxc835446adac6e",
        "mac": "16:06:e4:96:c1:24"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 90675,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 90675,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 36

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 36

```
Timestamp              Status   State                   Message
2024-10-24T09:24:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:34Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added

```


#### Identity get 90675

```
ID      LABELS
90675   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=client2
        k8s:io.kubernetes.pod.namespace=cilium-test-1
        k8s:kind=client
        k8s:name=client2
        k8s:other=client

```


#### BPF Policy Get 89

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23127   287       0        
Allow    Ingress     1          ANY          NONE         disabled    6669    76        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 89

```
Invalid argument: unknown type 89
```


#### Endpoint Get 89

```
[
  {
    "id": 89,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-89-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7d447403-f62f-448e-a8ad-738d0cbe399c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-89",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:43.758Z",
            "success-count": 2
          },
          "uuid": "3566795d-b988-4063-9f6f-bd02221db0d6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-89",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:47.351Z",
            "success-count": 1
          },
          "uuid": "2931851b-4287-477f-a8d5-ca3d0f3d4857"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.193",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3a:e8:26:54:78:f4",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "4e:22:72:6b:0a:b2"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 89

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 89

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:07Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:43Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:43Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 222

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4614     36        0        
Allow    Ingress     1          ANY          NONE         disabled    299628   3496      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 222

```
Invalid argument: unknown type 222
```


#### Endpoint Get 222

```
[
  {
    "id": 222,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-222-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "01f8d8c4-ade6-407a-a7e2-402dec7d7fd0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-222",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:16.733Z",
            "success-count": 2
          },
          "uuid": "fe2065b5-bd07-4ab6-bceb-ea32b88c77e6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-tsm52",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:16.731Z",
            "success-count": 1
          },
          "uuid": "85229b35-33e6-415f-9c3a-352925dfa6ce"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-222",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:16.766Z",
            "success-count": 1
          },
          "uuid": "89934b59-6b0e-40df-b35d-e6a316dee14d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (222)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:26.763Z",
            "success-count": 33
          },
          "uuid": "931796de-b42c-4c9f-af7d-df8ab8418a87"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "eafae5df2aa3e774d8de18b412b28393d602e3c6e4a20bd23d442cfacb7183f5:eth0",
        "container-id": "eafae5df2aa3e774d8de18b412b28393d602e3c6e4a20bd23d442cfacb7183f5",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-tsm52",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-tsm52"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 67854,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:26Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.239",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:c4:7f:14:23:ea",
        "interface-index": 21,
        "interface-name": "lxc8894d1685771",
        "mac": "0a:10:87:ad:5a:94"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67854,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 67854,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 222

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 222

```
Timestamp              Status   State                   Message
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 67854

```
ID      LABELS
67854   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
        k8s:io.kubernetes.pod.namespace=cilium-test-1
        k8s:kind=echo
        k8s:name=echo-same-node
        k8s:other=echo

```


#### BPF Policy Get 245

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 245

```
Invalid argument: unknown type 245
```


#### Endpoint Get 245

```
[
  {
    "id": 245,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-245-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b9050d3a-d04e-4ac6-98e3-1862173ab30a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-245",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.744Z",
            "success-count": 2
          },
          "uuid": "85cf428f-4f27-48f4-a63d-f8738c0762e9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-d6w4f",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.743Z",
            "success-count": 1
          },
          "uuid": "7d9df619-5987-44dd-828b-1a38c6015109"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-245",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.858Z",
            "success-count": 1
          },
          "uuid": "c0067d25-6499-4d12-9629-bcafa3c91f0f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (245)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.789Z",
            "success-count": 33
          },
          "uuid": "26adbe33-5e5f-4694-ae54-1d799c8836d9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a27e969809bc4ce977166802c3d6eef9e791768903f0d31c9d930ece10d4608c:eth0",
        "container-id": "a27e969809bc4ce977166802c3d6eef9e791768903f0d31c9d930ece10d4608c",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-d6w4f",
        "pod-name": "cilium-test-1/client-974f6c69d-d6w4f"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 73336,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.146",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1e:c8:65:b7:49:f7",
        "interface-index": 17,
        "interface-name": "lxcf3b77bac316d",
        "mac": "b6:f9:56:30:0b:08"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 73336,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 73336,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 245

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 245

```
Timestamp              Status   State                   Message
2024-10-24T09:24:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:11Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 73336

```
ID      LABELS
73336   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=client
        k8s:io.kubernetes.pod.namespace=cilium-test-1
        k8s:kind=client
        k8s:name=client

```


#### BPF Policy Get 593

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6138    67        0        
Allow    Ingress     1          ANY          NONE         disabled    48226   556       0        
Allow    Egress      0          ANY          NONE         disabled    12309   123       0        

```


#### BPF CT List 593

```
Invalid argument: unknown type 593
```


#### Endpoint Get 593

```
[
  {
    "id": 593,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-593-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b58c0c33-92cb-4709-8f9a-404045aa0d1a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-593",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:43.986Z",
            "success-count": 2
          },
          "uuid": "704e9e06-9be8-4ce8-b758-982a993d1af7"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-shdm8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:43.985Z",
            "success-count": 1
          },
          "uuid": "06888777-49c4-45de-8ece-e70274af9128"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-593",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:47.421Z",
            "success-count": 1
          },
          "uuid": "caba1fd9-60c5-4e8d-941e-30a65b20cb24"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (593)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:24.036Z",
            "success-count": 54
          },
          "uuid": "390b10d8-1adb-41a7-8a75-42210f09787c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "62e3049bb26b1633136f92d265e34f9767c33ddacf63bc8953c47b35c9fe3f4d:eth0",
        "container-id": "62e3049bb26b1633136f92d265e34f9767c33ddacf63bc8953c47b35c9fe3f4d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-shdm8",
        "pod-name": "kube-system/coredns-586b798467-shdm8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 82485,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.115",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:5e:f0:90:7f:13",
        "interface-index": 11,
        "interface-name": "lxc3cefcb94209d",
        "mac": "56:69:5d:8f:90:b1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 82485,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 82485,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 593

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 593

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:07Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:43Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:43Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 82485

```
ID      LABELS
82485   k8s:eks.amazonaws.com/component=coredns
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2397

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5238    57        0        
Allow    Ingress     1          ANY          NONE         disabled    47698   548       0        
Allow    Egress      0          ANY          NONE         disabled    12027   120       0        

```


#### BPF CT List 2397

```
Invalid argument: unknown type 2397
```


#### Endpoint Get 2397

```
[
  {
    "id": 2397,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2397-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "13136d27-8abd-4d50-97c0-78549a3ee7d0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2397",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:43.902Z",
            "success-count": 2
          },
          "uuid": "8a91b6da-7fde-46ae-9f52-23dc6ddde8cd"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-rnt5q",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:43.901Z",
            "success-count": 1
          },
          "uuid": "38d44ae7-6090-4777-a125-e8398d215ad3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2397",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:47.352Z",
            "success-count": 1
          },
          "uuid": "25c4e68f-51f0-4efe-a528-875d57d44c20"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2397)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:23.947Z",
            "success-count": 54
          },
          "uuid": "07fcdd70-26d3-4947-9699-6ac6b7514ccd"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0c80087387f9bb68f5b8f68d780c2e680839c133f83ed3354305f5d78c6356c2:eth0",
        "container-id": "0c80087387f9bb68f5b8f68d780c2e680839c133f83ed3354305f5d78c6356c2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-rnt5q",
        "pod-name": "kube-system/coredns-586b798467-rnt5q"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 82485,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.242",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7e:28:83:fc:21:a7",
        "interface-index": 9,
        "interface-name": "lxc8d5dd18629b0",
        "mac": "d6:57:31:74:80:8d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 82485,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 82485,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2397

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2397

```
Timestamp              Status    State                   Message
2024-10-24T09:20:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:07Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:07Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:07Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:19:07Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:06Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:06Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:06Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:06Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:05Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:05Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:05Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:05Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:47Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:47Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:47Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:47Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:44Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:44Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:44Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:43Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:43Z   OK        ready                   Set identity for this endpoint
2024-10-24T09:16:43Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:43Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 82485

```
ID      LABELS
82485   k8s:eks.amazonaws.com/component=coredns
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=coredns
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2470

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    203026   1931      0        
Allow    Ingress     1          ANY          NONE         disabled    213081   2208      0        
Allow    Egress      0          ANY          NONE         disabled    293679   2664      0        

```


#### BPF CT List 2470

```
Invalid argument: unknown type 2470
```


#### Endpoint Get 2470

```
[
  {
    "id": 2470,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2470-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "e0df62a5-d210-4218-a163-45e98e478994"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2470",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:23:29.206Z",
            "success-count": 2
          },
          "uuid": "57d8d477-153f-44b7-98e1-92f657d6672f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-787d76979f-bbgd4",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:29.205Z",
            "success-count": 1
          },
          "uuid": "2a0b84fc-9cdc-44b5-ab1b-53228d8ba14d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2470",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:29.237Z",
            "success-count": 1
          },
          "uuid": "000387a0-5ca3-4120-b83f-aa13c5f502a7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2470)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:19.244Z",
            "success-count": 43
          },
          "uuid": "eea423bc-f527-4ac9-885f-4b785b108da5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "12fcb5e29c49f09c660e77028af086390800d20046b08ea95f624f6325c7769e:eth0",
        "container-id": "12fcb5e29c49f09c660e77028af086390800d20046b08ea95f624f6325c7769e",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-787d76979f-bbgd4",
        "pod-name": "kube-system/clustermesh-apiserver-787d76979f-bbgd4"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 86420,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=787d76979f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh1",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.0.0.58",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:2f:0f:b3:31:8e",
        "interface-index": 15,
        "interface-name": "lxc6d043d655508",
        "mac": "4e:19:98:89:49:9d"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 86420,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 86420,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2470

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2470

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:07Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:18:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:29Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:18:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:18:29Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:18:29Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 86420

```
ID      LABELS
86420   k8s:app.kubernetes.io/name=clustermesh-apiserver
        k8s:app.kubernetes.io/part-of=cilium
        k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
        k8s:io.cilium.k8s.policy.cluster=cmesh1
        k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
        k8s:io.kubernetes.pod.namespace=kube-system
        k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3414

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3414

```
Invalid argument: unknown type 3414
```


#### Endpoint Get 3414

```
[
  {
    "id": 3414,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3414-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "dbfe0158-de19-4f80-92c7-785da8f339ef"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3414",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:42.679Z",
            "success-count": 2
          },
          "uuid": "d0a06f1d-75e5-43f5-aa13-dc609ea65b82"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3414",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:44.048Z",
            "success-count": 1
          },
          "uuid": "10f301c2-4cab-4fef-a775-4e46d2b46843"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "4e:a8:a3:7d:bb:d0",
        "interface-name": "cilium_host",
        "mac": "4e:a8:a3:7d:bb:d0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3414

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3414

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:07Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:05Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:47Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:42Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Service list

```
ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.217.199:443 (active)    
                                        2 => 172.31.161.101:443 (active)    
2    10.100.61.31:443    ClusterIP      1 => 172.31.190.177:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.0.0.242:53 (active)         
                                        2 => 10.0.0.115:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.0.0.242:9153 (active)       
                                        2 => 10.0.0.115:9153 (active)       
5    10.100.1.174:2379   ClusterIP      1 => 10.0.0.58:2379 (active)        
6    10.100.77.16:8080   ClusterIP      1 => 10.0.0.239:8080 (active)       
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37765300                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37765300                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37765300                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006400000 rw-p 00000000 00:00 0 
4006400000-4008000000 ---p 00000000 00:00 0 
ffff54cf4000-ffff54e05000 rw-p 00000000 00:00 0 
ffff54e05000-ffff54e46000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff54e46000-ffff54e87000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff54e87000-ffff54ec7000 rw-p 00000000 00:00 0 
ffff54ec7000-ffff54ec9000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff54ec9000-ffff54ecb000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff54ecb000-ffff55472000 rw-p 00000000 00:00 0 
ffff55472000-ffff55572000 rw-p 00000000 00:00 0 
ffff55572000-ffff55583000 rw-p 00000000 00:00 0 
ffff55583000-ffff57583000 rw-p 00000000 00:00 0 
ffff57583000-ffff57603000 ---p 00000000 00:00 0 
ffff57603000-ffff57604000 rw-p 00000000 00:00 0 
ffff57604000-ffff77603000 ---p 00000000 00:00 0 
ffff77603000-ffff77604000 rw-p 00000000 00:00 0 
ffff77604000-ffff97593000 ---p 00000000 00:00 0 
ffff97593000-ffff97594000 rw-p 00000000 00:00 0 
ffff97594000-ffff9b585000 ---p 00000000 00:00 0 
ffff9b585000-ffff9b586000 rw-p 00000000 00:00 0 
ffff9b586000-ffff9bd83000 ---p 00000000 00:00 0 
ffff9bd83000-ffff9bd84000 rw-p 00000000 00:00 0 
ffff9bd84000-ffff9be83000 ---p 00000000 00:00 0 
ffff9be83000-ffff9bee3000 rw-p 00000000 00:00 0 
ffff9bee3000-ffff9bee5000 r--p 00000000 00:00 0                          [vvar]
ffff9bee5000-ffff9bee6000 r-xp 00000000 00:00 0                          [vdso]
ffffe9664000-ffffe9685000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=10) "10.0.0.119": (string) (len=6) "router",
  (string) (len=10) "10.0.0.193": (string) (len=6) "health",
  (string) (len=10) "10.0.0.242": (string) (len=36) "kube-system/coredns-586b798467-rnt5q",
  (string) (len=10) "10.0.0.115": (string) (len=36) "kube-system/coredns-586b798467-shdm8",
  (string) (len=10) "10.0.0.146": (string) (len=36) "cilium-test-1/client-974f6c69d-d6w4f",
  (string) (len=9) "10.0.0.58": (string) (len=50) "kube-system/clustermesh-apiserver-787d76979f-bbgd4",
  (string) (len=10) "10.0.0.133": (string) (len=37) "cilium-test-1/client2-57cf4468f-n4msm",
  (string) (len=10) "10.0.0.239": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-tsm52"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.190.177": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001ffa160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001fbc9c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001fbc9c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4002f8d810)(frontends:[10.100.77.16]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001233d90)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001233e40)(frontends:[10.100.61.31]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000bcc9a0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001d45080)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002a15d90)(frontends:[10.100.1.174]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000fddc10)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-kv2xw": (*k8s.Endpoints)(0x4003850b60)(10.0.0.239:8080/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40015999f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002b65ba0)(172.31.161.101:443/TCP,172.31.217.199:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001599a08)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-9nxhj": (*k8s.Endpoints)(0x4001b72c30)(172.31.190.177:4244/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001599a10)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-wk6dh": (*k8s.Endpoints)(0x4002713380)(10.0.0.115:53/TCP[us-east-1a],10.0.0.115:53/UDP[us-east-1a],10.0.0.115:9153/TCP[us-east-1a],10.0.0.242:53/TCP[us-east-1a],10.0.0.242:53/UDP[us-east-1a],10.0.0.242:9153/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001579430)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-hgvrz": (*k8s.Endpoints)(0x4001c16750)(10.0.0.58:2379/TCP[us-east-1a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400184a460)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40005b6690)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4003554828
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001c342a0,
  gcExited: (chan struct {}) 0x4001c34300,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b18300)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000a3bc60)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2d8c0)({
       metricMap: (*prometheus.metricMap)(0x4001b2d8f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c120)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b18380)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000a3bc68)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2d950)({
       metricMap: (*prometheus.metricMap)(0x4001b2d980)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c180)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b18400)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc70)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2d9e0)({
       metricMap: (*prometheus.metricMap)(0x4001b2da10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c1e0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b18480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc78)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2da70)({
       metricMap: (*prometheus.metricMap)(0x4001b2daa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c240)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b18500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc80)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2db00)({
       metricMap: (*prometheus.metricMap)(0x4001b2db30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c2a0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b18580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc88)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2db90)({
       metricMap: (*prometheus.metricMap)(0x4001b2dbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c300)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b18600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc90)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2dc20)({
       metricMap: (*prometheus.metricMap)(0x4001b2dc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c360)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b18680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000a3bc98)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2dcb0)({
       metricMap: (*prometheus.metricMap)(0x4001b2dce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c3c0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b18700)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000a3bca0)({
      MetricVec: (*prometheus.MetricVec)(0x4001b2dd40)({
       metricMap: (*prometheus.metricMap)(0x4001b2dd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b3c420)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400184a460)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001fe61c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001fc6978)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.0.0.0/24, 
Allocated addresses:
  10.0.0.115 (kube-system/coredns-586b798467-shdm8)
  10.0.0.119 (router)
  10.0.0.133 (cilium-test-1/client2-57cf4468f-n4msm)
  10.0.0.146 (cilium-test-1/client-974f6c69d-d6w4f)
  10.0.0.193 (health)
  10.0.0.239 (cilium-test-1/echo-same-node-86d9cc975c-tsm52)
  10.0.0.242 (kube-system/coredns-586b798467-rnt5q)
  10.0.0.58 (kube-system/clustermesh-apiserver-787d76979f-bbgd4)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6443fd3710cbf41e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    44s ago        never        0       no error   
  ct-map-pressure                                                     16s ago        never        0       no error   
  daemon-validate-config                                              38s ago        never        0       no error   
  dns-garbage-collector-job                                           49s ago        never        0       no error   
  endpoint-222-regeneration-recovery                                  never          never        0       no error   
  endpoint-2397-regeneration-recovery                                 never          never        0       no error   
  endpoint-245-regeneration-recovery                                  never          never        0       no error   
  endpoint-2470-regeneration-recovery                                 never          never        0       no error   
  endpoint-3414-regeneration-recovery                                 never          never        0       no error   
  endpoint-36-regeneration-recovery                                   never          never        0       no error   
  endpoint-593-regeneration-recovery                                  never          never        0       no error   
  endpoint-89-regeneration-recovery                                   never          never        0       no error   
  endpoint-gc                                                         3m49s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                16s ago        never        0       no error   
  ipcache-inject-labels                                               38s ago        never        0       no error   
  k8s-heartbeat                                                       19s ago        never        0       no error   
  link-cache                                                          16s ago        never        0       no error   
  local-identity-checkpoint                                           35s ago        never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh2                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m23s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m23s ago      never        0       no error   
  resolve-identity-222                                                12s ago        never        0       no error   
  resolve-identity-2397                                               3m45s ago      never        0       no error   
  resolve-identity-245                                                13s ago        never        0       no error   
  resolve-identity-2470                                               2m0s ago       never        0       no error   
  resolve-identity-3414                                               3m46s ago      never        0       no error   
  resolve-identity-36                                                 13s ago        never        0       no error   
  resolve-identity-593                                                3m45s ago      never        0       no error   
  resolve-identity-89                                                 3m45s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-d6w4f                 5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-n4msm                5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-tsm52        5m12s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-787d76979f-bbgd4   7m0s ago       never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-rnt5q                 8m45s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-shdm8                 8m45s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      8m46s ago      never        0       no error   
  sync-policymap-222                                                  5m12s ago      never        0       no error   
  sync-policymap-2397                                                 8m41s ago      never        0       no error   
  sync-policymap-245                                                  5m13s ago      never        0       no error   
  sync-policymap-2470                                                 7m0s ago       never        0       no error   
  sync-policymap-3414                                                 8m45s ago      never        0       no error   
  sync-policymap-36                                                   5m13s ago      never        0       no error   
  sync-policymap-593                                                  8m41s ago      never        0       no error   
  sync-policymap-89                                                   8m41s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (222)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2397)                                   15s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (245)                                    13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2470)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (36)                                     13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (593)                                    15s ago        never        0       no error   
  sync-utime                                                          46s ago        never        0       no error   
  write-cni-file                                                      8m49s ago      never        0       no error   
Proxy Status:            OK, ip 10.0.0.119, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 65536, max 131071
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 23.60   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
use-cilium-internal-ip-for-ipsec:false
node-port-algorithm:random
http-request-timeout:3600
enable-k8s-terminating-endpoint:true
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-redact-kafka-apikey:false
crd-wait-timeout:5m0s
ipv4-pod-subnets:
kvstore:
k8s-client-qps:10
conntrack-gc-max-interval:0s
trace-payloadlen:128
enable-ipv4-masquerade:true
bpf-lb-service-map-max:0
enable-host-port:false
proxy-idle-timeout-seconds:60
mesh-auth-spiffe-trust-domain:spiffe.cilium
prepend-iptables-chains:true
ipv6-cluster-alloc-cidr:f00d::/64
node-labels:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
ipv6-pod-subnets:
mesh-auth-gc-interval:5m0s
enable-ipv4-fragment-tracking:true
clustermesh-enable-mcs-api:false
enable-host-firewall:false
ingress-secrets-namespace:
enable-mke:false
route-metric:0
fixed-identity-mapping:
controller-group-metrics:
prometheus-serve-addr:
use-full-tls-context:false
bpf-fragments-map-max:8192
label-prefix-file:
envoy-config-retry-interval:15s
enable-wireguard-userspace-fallback:false
enable-identity-mark:true
nat-map-stats-entries:32
mesh-auth-queue-size:1024
devices:
proxy-gid:1337
ipv6-node:auto
enable-ipsec-xfrm-state-caching:true
enable-policy:default
k8s-sync-timeout:3m0s
vtep-cidr:
bpf-lb-source-range-map-max:0
restore:true
enable-endpoint-routes:false
preallocate-bpf-maps:false
dnsproxy-concurrency-processing-grace-period:0s
kvstore-lease-ttl:15m0s
enable-bgp-control-plane:false
cgroup-root:/run/cilium/cgroupv2
mtu:0
cni-chaining-target:
agent-labels:
envoy-keep-cap-netbindservice:false
k8s-client-connection-timeout:30s
hubble-disable-tls:false
bpf-root:/sys/fs/bpf
proxy-connect-timeout:2
local-max-addr-scope:252
enable-custom-calls:false
enable-ipv4-big-tcp:false
bypass-ip-availability-upon-restore:false
enable-stale-cilium-endpoint-cleanup:true
enable-health-checking:true
enable-high-scale-ipcache:false
lib-dir:/var/lib/cilium
hubble-metrics-server:
http-idle-timeout:0
enable-cilium-endpoint-slice:false
auto-direct-node-routes:false
hubble-event-buffer-capacity:4095
hubble-listen-address::4244
hubble-flowlogs-config-path:
enable-metrics:true
bpf-events-drop-enabled:true
set-cilium-is-up-condition:true
proxy-max-requests-per-connection:0
bpf-lb-maglev-table-size:16381
clustermesh-ip-identities-sync-timeout:1m0s
node-port-acceleration:disabled
disable-iptables-feeder-rules:
bpf-lb-dsr-l4-xlate:frontend
enable-tracing:false
bpf-nat-global-max:524288
envoy-log:
cluster-pool-ipv4-mask-size:24
proxy-prometheus-port:0
exclude-node-label-patterns:
ipv6-service-range:auto
force-device-detection:false
identity-change-grace-period:5s
kube-proxy-replacement:false
dns-policy-unload-on-shutdown:false
enable-l7-proxy:true
identity-heartbeat-timeout:30m0s
enable-endpoint-health-checking:true
enable-auto-protect-node-port-range:true
bpf-ct-global-tcp-max:524288
bpf-lb-sock-hostns-only:false
iptables-lock-timeout:5s
static-cnp-path:
bpf-lb-dsr-dispatch:opt
log-driver:
tofqdns-idle-connection-grace-period:0s
clustermesh-enable-endpoint-sync:false
external-envoy-proxy:true
k8s-heartbeat-timeout:30s
enable-ipv6-ndp:false
hubble-drop-events-reasons:auth_required,policy_denied
clustermesh-config:/var/lib/cilium/clustermesh/
identity-allocation-mode:crd
ipv4-range:auto
enable-ipv6:false
hubble-socket-path:/var/run/cilium/hubble.sock
mesh-auth-signal-backoff-duration:1s
enable-masquerade-to-route-source:false
enable-host-legacy-routing:false
mesh-auth-enabled:true
cluster-id:1
enable-wireguard:false
ipam-default-ip-pool:default
iptables-random-fully:false
identity-gc-interval:15m0s
dnsproxy-lock-timeout:500ms
debug-verbose:
mesh-auth-mutual-listener-port:0
pprof-port:6060
bpf-ct-global-any-max:262144
endpoint-gc-interval:5m0s
http-retry-timeout:0
k8s-client-burst:20
cluster-name:cmesh1
dns-max-ips-per-restored-rule:1000
l2-announcements-renew-deadline:5s
egress-masquerade-interfaces:ens+
bpf-lb-affinity-map-max:0
enable-k8s-networkpolicy:true
enable-hubble:true
encryption-strict-mode-allow-remote-node-identities:false
conntrack-gc-interval:0s
service-no-backend-response:reject
enable-ipv4:true
nodeport-addresses:
derive-masq-ip-addr-from-device:
cni-exclusive:true
container-ip-local-reserved-ports:auto
bpf-ct-timeout-regular-tcp-syn:1m0s
monitor-aggregation:medium
vtep-mac:
k8s-client-connection-keep-alive:30s
policy-accounting:true
k8s-kubeconfig-path:
cflags:
cmdref:
disable-endpoint-crd:false
monitor-queue-size:0
hubble-drop-events-interval:2m0s
vtep-mask:
dnsproxy-concurrency-limit:0
enable-ipsec-encrypted-overlay:false
enable-tcx:true
bpf-policy-map-full-reconciliation-interval:15m0s
k8s-service-proxy-name:
monitor-aggregation-flags:all
unmanaged-pod-watcher-interval:15
ipam-cilium-node-update-rate:15s
bpf-sock-rev-map-max:262144
l2-pod-announcements-interface:
enable-active-connection-tracking:false
proxy-max-connection-duration-seconds:0
policy-audit-mode:false
cluster-pool-ipv4-cidr:10.0.0.0/16
pprof-address:localhost
tofqdns-min-ttl:0
hubble-export-denylist:
tunnel-protocol:vxlan
hubble-recorder-storage-path:/var/run/cilium/pcaps
cni-chaining-mode:none
enable-ipv6-big-tcp:false
enable-ipv4-egress-gateway:false
install-no-conntrack-iptables-rules:false
annotate-k8s-node:false
fqdn-regex-compile-lru-size:1024
l2-announcements-lease-duration:15s
enable-pmtu-discovery:false
cni-log-file:/var/run/cilium/cilium-cni.log
config-sources:config-map:kube-system/cilium-config
endpoint-bpf-prog-watchdog-interval:30s
bpf-lb-maglev-map-max:0
mesh-auth-rotated-identities-queue-size:1024
identity-restore-grace-period:30s
hubble-event-queue-size:0
envoy-base-id:0
enable-xdp-prefilter:false
gops-port:9890
bpf-lb-sock:false
ipsec-key-rotation-duration:5m0s
proxy-portrange-max:20000
tofqdns-proxy-port:0
bpf-lb-service-backend-map-max:0
hubble-redact-http-headers-deny:
proxy-xff-num-trusted-hops-egress:0
bpf-filter-priority:1
bpf-ct-timeout-service-tcp:2h13m20s
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-export-file-compress:false
version:false
bpf-lb-algorithm:random
policy-cidr-match-mode:
nodes-gc-interval:5m0s
wireguard-persistent-keepalive:0s
hubble-export-file-max-size-mb:10
enable-local-redirect-policy:false
proxy-admin-port:0
enable-ingress-controller:false
node-port-mode:snat
hubble-monitor-events:
read-cni-conf:
enable-srv6:false
enable-cilium-health-api-server-access:
bpf-lb-acceleration:disabled
egress-multi-home-ip-rule-compat:false
multicast-enabled:false
proxy-portrange-min:10000
bpf-lb-external-clusterip:false
hubble-export-file-path:
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
hubble-drop-events:false
datapath-mode:veth
enable-route-mtu-for-cni-chaining:false
tofqdns-max-deferred-connection-deletes:10000
enable-runtime-device-detection:true
bpf-map-dynamic-size-ratio:0.0025
exclude-local-address:
envoy-secrets-namespace:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
ipv4-service-range:auto
enable-cilium-api-server-access:
allow-icmp-frag-needed:true
kvstore-connectivity-timeout:2m0s
bgp-announce-lb-ip:false
auto-create-cilium-node-resource:true
vtep-endpoint:
bpf-auth-map-max:524288
envoy-config-timeout:2m0s
join-cluster:false
custom-cni-conf:false
bpf-node-map-max:16384
egress-gateway-policy-map-max:16384
enable-k8s-api-discovery:false
bpf-events-policy-verdict-enabled:true
labels:
bpf-events-trace-enabled:true
enable-ip-masq-agent:false
enable-ipv6-masquerade:true
config:
bpf-ct-timeout-service-any:1m0s
pprof:false
http-normalize-path:true
mesh-auth-spire-admin-socket:
procfs:/host/proc
keep-config:false
enable-vtep:false
kvstore-opt:
k8s-namespace:kube-system
disable-envoy-version-check:false
enable-k8s-endpoint-slice:true
tofqdns-enable-dns-compression:true
tofqdns-endpoint-max-ip-per-hostname:50
allocator-list-timeout:3m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dnsproxy-insecure-skip-transparent-mode-check:false
max-internal-timer-delay:0s
ipv6-native-routing-cidr:
trace-sock:true
proxy-xff-num-trusted-hops-ingress:0
enable-session-affinity:false
disable-external-ip-mitigation:false
enable-bpf-masquerade:false
enable-gateway-api:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-ct-timeout-regular-tcp:2h13m20s
log-system-load:false
enable-monitor:true
arping-refresh-period:30s
dnsproxy-socket-linger-timeout:10
config-dir:/tmp/cilium/config-map
debug:false
k8s-require-ipv6-pod-cidr:false
ipv6-range:auto
state-dir:/var/run/cilium
agent-health-port:9879
enable-icmp-rules:true
enable-health-check-loadbalancer-ip:false
enable-local-node-route:true
hubble-export-file-max-backups:5
install-iptables-rules:true
enable-recorder:false
hubble-redact-http-headers-allow:
enable-bandwidth-manager:false
k8s-require-ipv4-pod-cidr:false
mke-cgroup-mount:
tofqdns-proxy-response-max-delay:100ms
bpf-lb-mode:snat
gateway-api-secrets-namespace:
node-port-range:
hubble-metrics:
bgp-announce-pod-cidr:false
bpf-lb-rss-ipv4-src-cidr:
hubble-export-fieldmask:
l2-announcements-retry-period:2s
enable-well-known-identities:false
srv6-encap-mode:reduced
enable-svc-source-range-check:true
enable-health-check-nodeport:true
kvstore-max-consecutive-quorum-errors:2
enable-l2-neigh-discovery:true
bpf-ct-timeout-regular-any:1m0s
local-router-ipv4:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
operator-api-serve-addr:127.0.0.1:9234
kube-proxy-replacement-healthz-bind-address:
dnsproxy-lock-count:131
enable-l2-pod-announcements:false
enable-k8s:true
k8s-api-server:
bpf-neigh-global-max:524288
hubble-prefer-ipv6:false
certificates-directory:/var/run/cilium/certs
api-rate-limit:
socket-path:/var/run/cilium/cilium.sock
cluster-health-port:4240
policy-trigger-interval:1s
encrypt-interface:
enable-ipip-termination:false
hubble-skip-unknown-cgroup-ids:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
bpf-lb-map-max:65536
metrics:
monitor-aggregation-interval:5s
mesh-auth-mutual-connect-timeout:5s
enable-ipsec-key-watcher:true
clustermesh-sync-timeout:1m0s
hubble-redact-http-userinfo:true
ipam:cluster-pool
encrypt-node:false
vlan-bpf-bypass:
enable-envoy-config:false
cilium-endpoint-gc-interval:5m0s
bpf-ct-timeout-regular-tcp-fin:10s
enable-encryption-strict-mode:false
enable-xt-socket-fallback:true
synchronize-k8s-nodes:true
enable-node-port:false
ipv6-mcast-device:
dnsproxy-enable-transparent-mode:true
tofqdns-pre-cache:
enable-bbr:false
cni-external-routing:false
ipv4-node:auto
hubble-redact-http-urlquery:false
routing-mode:tunnel
endpoint-queue-size:25
ipsec-key-file:
enable-external-ips:false
encryption-strict-mode-cidr:
enable-bpf-clock-probe:false
enable-node-selector-labels:false
operator-prometheus-serve-addr::9963
log-opt:
local-router-ipv6:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
allow-localhost:auto
tofqdns-dns-reject-response-code:refused
ipv4-native-routing-cidr:
bpf-policy-map-max:16384
policy-queue-size:100
enable-hubble-recorder-api:true
hubble-redact-enabled:false
http-retry-count:3
bgp-config-path:/var/lib/cilium/bgp/config.yaml
egress-gateway-reconciliation-trigger-interval:1s
node-port-bind-protection:true
enable-unreachable-routes:false
set-cilium-node-taints:true
nat-map-stats-interval:30s
kvstore-periodic-sync:5m0s
k8s-service-cache-size:128
max-controller-interval:0
http-max-grpc-timeout:0
enable-ipsec:false
bpf-lb-rss-ipv6-src-cidr:
enable-nat46x64-gateway:false
enable-bpf-tproxy:false
tunnel-port:0
hubble-export-allowlist:
ipam-multi-pool-pre-allocation:
remove-cilium-node-taints:true
direct-routing-skip-unreachable:false
ipv4-service-loopback-address:169.254.42.1
enable-l2-announcements:false
enable-service-topology:false
bpf-lb-sock-terminate-pod-connections:false
agent-liveness-update-interval:1s
bpf-map-event-buffers:
hubble-recorder-sink-queue-size:1024
bpf-lb-rev-nat-map-max:0
direct-routing-device:
max-connected-clusters:255
enable-sctp:false
```


#### Policy get

```
:
 []
Revision: 157

```

