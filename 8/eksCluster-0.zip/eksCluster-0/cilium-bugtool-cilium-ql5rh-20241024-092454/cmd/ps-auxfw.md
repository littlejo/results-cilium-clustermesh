USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2777  0.0  0.4 1240432 16084 ?       Ssl  09:24   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2808  0.0  0.0   6408  1648 ?        R    09:24   0:00  \_ ps auxfw
root        2809  0.0  0.0   3728   488 ?        R    09:24   0:00  \_ bash -c hostname
root           1  4.6  4.7 1405020 186552 ?      Ssl  09:16   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         389  0.0  0.0 1228848 3824 ?        Sl   09:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
