filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3cefcb94209d direct-action not_in_hw id 473 tag e2832373819c5f35 jited 
