filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc835446adac6e direct-action not_in_hw id 3663 tag f37612c83ab6a67c jited 
