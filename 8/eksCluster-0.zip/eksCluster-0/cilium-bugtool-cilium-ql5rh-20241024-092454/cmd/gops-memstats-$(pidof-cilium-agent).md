alloc: 41.61MB (43632088 bytes)
total-alloc: 1.43GB (1537413528 bytes)
sys: 108.43MB (113691956 bytes)
lookups: 0
mallocs: 46550816
frees: 46212997
heap-alloc: 41.61MB (43632088 bytes)
heap-sys: 93.76MB (98312192 bytes)
heap-idle: 31.39MB (32915456 bytes)
heap-in-use: 62.37MB (65396736 bytes)
heap-released: 4.55MB (4775936 bytes)
heap-objects: 337819
stack-in-use: 6.22MB (6520832 bytes)
stack-sys: 6.22MB (6520832 bytes)
stack-mspan-inuse: 1013.44KB (1037760 bytes)
stack-mspan-sys: 1.20MB (1256640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 775.24KB (793849 bytes)
gc-sys: 4.56MB (4782568 bytes)
next-gc: when heap-alloc >= 85.22MB (89357384 bytes)
last-gc: 2024-10-24 09:25:16.4905151 +0000 UTC
gc-pause-total: 15.322299ms
gc-pause: 68052
gc-pause-end: 1729761916490515100
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0006475450781452549
enable-gc: true
debug-gc: false
