 09:24:56 up 9 min,  0 users,  load average: 0.52, 0.62, 0.34
