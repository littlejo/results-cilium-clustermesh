## Map: cilium_policy_00593
Key              Value         State   Error
Ingress: 0 ANY   0 67 6138             
Egress: 0 ANY    0 123 12309           
Ingress: 1 ANY   0 556 48226           

## Map: cilium_policy_00245
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_policy_00222
Key              Value           State   Error
Ingress: 0 ANY   0 36 4614               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3507 300581           

## Map: cilium_lxc
Key                Value                                                                                            State   Error
10.0.0.242:0       id=2397  sec_id=82485 flags=0x0000 ifindex=9   mac=D6:57:31:74:80:8D nodemac=7E:28:83:FC:21:A7   sync    
10.0.0.133:0       id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5   sync    
10.0.0.119:0       (localhost)                                                                                      sync    
10.0.0.193:0       id=89    sec_id=4     flags=0x0000 ifindex=7   mac=4E:22:72:6B:0A:B2 nodemac=3A:E8:26:54:78:F4   sync    
10.0.0.115:0       id=593   sec_id=82485 flags=0x0000 ifindex=11  mac=56:69:5D:8F:90:B1 nodemac=F2:5E:F0:90:7F:13   sync    
10.0.0.146:0       id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7   sync    
10.0.0.58:0        id=2470  sec_id=86420 flags=0x0000 ifindex=15  mac=4E:19:98:89:49:9D nodemac=EE:2F:0F:B3:31:8E   sync    
10.0.0.239:0       id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA   sync    
172.31.190.177:0   (localhost)                                                                                      sync    

## Map: cilium_tunnel_map
Key        Value              State   Error
10.1.0.0   172.31.234.224:0   sync    
10.3.0.0   172.31.224.68:0    sync    
10.7.0.0   172.31.208.9:0     sync    
10.5.0.0   172.31.249.188:0   sync    
10.2.0.0   172.31.140.200:0   sync    
10.4.0.0   172.31.167.173:0   sync    
10.6.0.0   172.31.162.53:0    sync    

## Map: cilium_lb4_reverse_nat
Key   Value               State   Error
6     10.100.77.16:8080   sync    
1     10.100.0.1:443      sync    
2     10.100.61.31:443    sync    
3     10.100.0.10:53      sync    
4     10.100.0.10:9153    sync    
5     10.100.1.174:2379   sync    

## Map: cilium_policy_00089
Key              Value         State   Error
Ingress: 0 ANY   0 291 23484           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 76 6669             

## Map: cilium_policy_00036
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.0.0.119/32       identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
172.31.190.177/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.217.199/32   identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.161.101/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>           sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_03414
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_02397
Key              Value         State   Error
Ingress: 0 ANY   0 57 5238             
Egress: 0 ANY    0 120 12027           
Ingress: 1 ANY   0 548 47698           

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
1     ANY://172.31.217.199   sync    
6     ANY://10.0.0.115       sync    
10    ANY://10.0.0.239       sync    
9     ANY://10.0.0.58        sync    
7     ANY://172.31.161.101   sync    
2     ANY://172.31.190.177   sync    
3     ANY://10.0.0.242       sync    
4     ANY://10.0.0.242       sync    
5     ANY://10.0.0.115       sync    

## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440140625000           
AgentLiveness   576067783013               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_lb4_services_v2
Key                     Value                State   Error
10.100.0.1:443 (1)      1 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (0)      0 2 (1) [0x0 0x0]    sync    
10.100.1.174:2379 (1)   9 0 (5) [0x0 0x0]    sync    
10.100.77.16:8080 (1)   10 0 (6) [0x0 0x0]   sync    
10.100.61.31:443 (0)    0 1 (2) [0x0 0x10]   sync    
10.100.0.10:53 (0)      0 2 (3) [0x0 0x0]    sync    
10.100.0.10:9153 (0)    0 2 (4) [0x0 0x0]    sync    
10.100.0.10:9153 (1)    4 0 (4) [0x0 0x0]    sync    
10.100.0.10:9153 (2)    6 0 (4) [0x0 0x0]    sync    
10.100.1.174:2379 (0)   0 1 (5) [0x0 0x0]    sync    
10.100.77.16:8080 (0)   0 1 (6) [0x0 0x0]    sync    
10.100.61.31:443 (1)    2 0 (2) [0x0 0x0]    sync    
10.100.0.10:53 (1)      3 0 (3) [0x0 0x0]    sync    
10.100.0.10:53 (2)      5 0 (3) [0x0 0x0]    sync    
10.100.0.1:443 (2)      7 0 (1) [0x0 0x0]    sync    

## Map: cilium_policy_02470
Key              Value           State   Error
Ingress: 0 ANY   0 1931 203026           
Egress: 0 ANY    0 2664 293679           
Ingress: 1 ANY   0 2205 212883           

## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


