IP ADDRESS         LOCAL ENDPOINT INFO
10.0.0.193:0       id=89    sec_id=4     flags=0x0000 ifindex=7   mac=4E:22:72:6B:0A:B2 nodemac=3A:E8:26:54:78:F4   
10.0.0.115:0       id=593   sec_id=82485 flags=0x0000 ifindex=11  mac=56:69:5D:8F:90:B1 nodemac=F2:5E:F0:90:7F:13   
10.0.0.242:0       id=2397  sec_id=82485 flags=0x0000 ifindex=9   mac=D6:57:31:74:80:8D nodemac=7E:28:83:FC:21:A7   
10.0.0.133:0       id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5   
10.0.0.58:0        id=2470  sec_id=86420 flags=0x0000 ifindex=15  mac=4E:19:98:89:49:9D nodemac=EE:2F:0F:B3:31:8E   
10.0.0.239:0       id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA   
10.0.0.119:0       (localhost)                                                                                      
172.31.190.177:0   (localhost)                                                                                      
10.0.0.146:0       id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7   
