KEY             VALUE
AgentLiveness   574068354042
UTimeOffset     3378440140625000
