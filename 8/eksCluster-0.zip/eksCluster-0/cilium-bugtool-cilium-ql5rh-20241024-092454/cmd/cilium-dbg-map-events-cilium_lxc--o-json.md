{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.310Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.315Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.350Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:37.375Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.773Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.783Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.823Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.824Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.859Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.083Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.098Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.138Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.191Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:40.198Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.583Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.614Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.634Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.657Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.685Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.882Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.883Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.927Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.945Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.968Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.390Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.434Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.441Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.478Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.500Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.512Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.782Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.790Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.825Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.827Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.861Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.182Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.240Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.249Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.299Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.316Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.344Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.551Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.563Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.607Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.610Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.643Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:51.992Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.004Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.037Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.045Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.073Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.273Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.280Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.324Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.324Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.364Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.594Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.636Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.643Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.684Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.695Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.721Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.942Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:54.958Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.017Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.055Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.062Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.288Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.340Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.354Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.382Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.387Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.418Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.639Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.646Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.648Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.673Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.414Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.415Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.453Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.505Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.509Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.789Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:02.803Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:11.384Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:11.387Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:12.816Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:19.594Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:19.856Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:26.637Z",
  "value": "id=222   sec_id=67854 flags=0x0000 ifindex=21  mac=0A:10:87:AD:5A:94 nodemac=0E:C4:7F:14:23:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:26.936Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:26.937Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:26.941Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:33.670Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:33.722Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:33.736Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:34.030Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:34.039Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:34.041Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:40.753Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:40.796Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:40.812Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:41.086Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:41.088Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:41.091Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:53.948Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:53.998Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:54.006Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:54.307Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:54.312Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:54.316Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.309Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.353Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.375Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.665Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.667Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:07.670Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:20.585Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:20.630Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:20.640Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:20.935Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:20.937Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:37.837Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:37.849Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:38.127Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:38.131Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:51.085Z",
  "value": "id=36    sec_id=90675 flags=0x0000 ifindex=19  mac=16:06:E4:96:C1:24 nodemac=A6:B7:5E:8A:85:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:51.090Z",
  "value": "id=245   sec_id=73336 flags=0x0000 ifindex=17  mac=B6:F9:56:30:0B:08 nodemac=1E:C8:65:B7:49:F7"
}

