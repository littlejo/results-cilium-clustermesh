Node 0, zone      DMA    201    177    136    102     76     52     20     11      6      3    217 
Node 0, zone   Normal      3     17     42    243    162     63     13      5      3      2      6 
