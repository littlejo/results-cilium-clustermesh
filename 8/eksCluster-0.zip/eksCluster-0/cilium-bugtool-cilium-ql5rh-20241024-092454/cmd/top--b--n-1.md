top - 09:24:56 up 9 min,  0 users,  load average: 0.52, 0.62, 0.34
Tasks:   6 total,   1 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 37.9 sy,  0.0 ni, 48.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1010.8 free,    721.5 used,   2103.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2937.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1405020 189228  80228 S   6.7   4.8   0:23.59 cilium-+
    389 root      20   0 1228848   3824   3140 S   0.0   0.1   0:00.00 cilium-+
   2777 root      20   0 1240432  16376  11164 S   0.0   0.4   0:00.02 cilium-+
   2819 root      20   0    6576   2412   2088 R   0.0   0.1   0:00.00 top
   2825 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   2847 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
