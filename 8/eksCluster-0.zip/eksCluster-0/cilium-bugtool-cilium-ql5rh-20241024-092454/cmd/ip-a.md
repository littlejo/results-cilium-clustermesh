1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 02:8e:43:ac:ec:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.177/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3069sec preferred_lft 3069sec
    inet6 fe80::8e:43ff:feac:eceb/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:c9:49:f1:aa:48 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30c9:49ff:fef1:aa48/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:a8:a3:7d:bb:d0 brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.119/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4ca8:a3ff:fe7d:bbd0/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:ab:6d:4b:ca:54 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4ab:6dff:fe4b:ca54/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:e8:26:54:78:f4 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::38e8:26ff:fe54:78f4/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc8d5dd18629b0@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:28:83:fc:21:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7c28:83ff:fefc:21a7/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc3cefcb94209d@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:5e:f0:90:7f:13 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f05e:f0ff:fe90:7f13/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc6d043d655508@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:2f:0f:b3:31:8e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ec2f:fff:feb3:318e/64 scope link 
       valid_lft forever preferred_lft forever
17: lxcf3b77bac316d@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:c8:65:b7:49:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::1cc8:65ff:feb7:49f7/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc835446adac6e@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:b7:5e:8a:85:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::a4b7:5eff:fe8a:85d5/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc8894d1685771@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:c4:7f:14:23:ea brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::cc4:7fff:fe14:23ea/64 scope link 
       valid_lft forever preferred_lft forever
