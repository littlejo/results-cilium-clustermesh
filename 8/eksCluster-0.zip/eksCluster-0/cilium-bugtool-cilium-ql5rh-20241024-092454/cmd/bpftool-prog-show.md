32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:16:02+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
68: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:16:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:16:44+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
445: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:16:44+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
446: sched_cls  name tail_handle_ipv4  tag 4da2b3790b2d51ad  gpl
	loaded_at 2024-10-24T09:16:44+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
447: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:16:44+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
470: sched_cls  name tail_ipv4_to_endpoint  tag 20b6445b4fa36105  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,98,33,74,75,72,96,31,97,32,29,30
	btf_id 141
471: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,97
	btf_id 142
472: sched_cls  name tail_ipv4_ct_egress  tag 8d81dfe9a6ae15e8  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 143
473: sched_cls  name cil_from_container  tag e2832373819c5f35  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 97,68
	btf_id 144
474: sched_cls  name handle_policy  tag 199fe68f3ce330c0  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,97,74,75,98,33,72,96,31,76,67,32,29,30
	btf_id 145
475: sched_cls  name __send_drop_notify  tag c2f90ddca971e874  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 146
477: sched_cls  name tail_handle_ipv4  tag a318f1ace8117a42  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,97
	btf_id 148
478: sched_cls  name tail_handle_ipv4_cont  tag b54edb6ebadddc37  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,98,33,96,74,75,31,68,66,69,97,32,29,30,73
	btf_id 149
479: sched_cls  name tail_handle_arp  tag 4bd3d2a9f0dc7525  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,97
	btf_id 150
480: sched_cls  name tail_ipv4_ct_ingress  tag ccf9538baf663461  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 151
481: sched_cls  name cil_from_container  tag aff9c26adab4815b  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 100,68
	btf_id 153
482: sched_cls  name handle_policy  tag c246a1e1d1466c8f  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,100,74,75,99,33,72,91,31,76,67,32,29,30
	btf_id 154
483: sched_cls  name tail_handle_ipv4  tag 6cd81dfe301e4bcf  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 155
485: sched_cls  name tail_handle_arp  tag 0b72a6070791fc78  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 157
486: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 158
487: sched_cls  name __send_drop_notify  tag 935bce9072b01d24  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 159
488: sched_cls  name tail_handle_ipv4_cont  tag 94f5e3026589d46b  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,99,33,91,74,75,31,68,66,69,100,32,29,30,73
	btf_id 160
489: sched_cls  name tail_ipv4_to_endpoint  tag ffe3052432061c67  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,99,33,74,75,72,91,31,100,32,29,30
	btf_id 161
490: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 162
491: sched_cls  name tail_ipv4_ct_ingress  tag 672dcab1e032daf9  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 163
492: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 165
493: sched_cls  name __send_drop_notify  tag 9887e2e1ca2c28a7  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 166
494: sched_cls  name cil_from_container  tag 989fd5f3c0244fa2  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,68
	btf_id 167
495: sched_cls  name tail_ipv4_ct_egress  tag 8d81dfe9a6ae15e8  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 168
496: sched_cls  name tail_handle_arp  tag ec1c01144aa88358  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 169
497: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
500: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
501: sched_cls  name tail_ipv4_to_endpoint  tag 3bc9f6c36b3b0af0  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,90,31,102,32,29,30
	btf_id 170
502: sched_cls  name tail_handle_ipv4  tag 31ff140fd06dee1c  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 171
503: sched_cls  name handle_policy  tag c5af6144614053bb  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,102,74,75,101,33,72,90,31,76,67,32,29,30
	btf_id 172
504: sched_cls  name tail_handle_ipv4_cont  tag 380764570ece6b0c  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,90,74,75,31,68,66,69,102,32,29,30,73
	btf_id 173
506: sched_cls  name tail_ipv4_ct_ingress  tag ece63440904f70dc  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 175
507: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
510: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
511: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 177
513: sched_cls  name tail_handle_ipv4_from_host  tag a2dc1300710b39a1  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 179
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 180
515: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 181
517: sched_cls  name __send_drop_notify  tag c0a02886873b423c  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 183
519: sched_cls  name __send_drop_notify  tag c0a02886873b423c  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 186
522: sched_cls  name tail_handle_ipv4_from_host  tag a2dc1300710b39a1  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 189
523: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 190
524: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 191
527: sched_cls  name tail_handle_ipv4_from_host  tag a2dc1300710b39a1  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 195
528: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 196
530: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 198
531: sched_cls  name __send_drop_notify  tag c0a02886873b423c  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 199
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
539: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name handle_policy  tag fbc86ad5f1dbfc0d  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,125,74,75,124,33,72,123,31,76,67,32,29,30
	btf_id 215
580: sched_cls  name cil_from_container  tag 32c66942c4cb7ae5  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 125,68
	btf_id 216
581: sched_cls  name tail_ipv4_ct_ingress  tag c3d8b885384bf06b  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 217
582: sched_cls  name tail_handle_ipv4  tag 62d183c04aa0f398  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,125
	btf_id 218
583: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,125
	btf_id 219
584: sched_cls  name tail_ipv4_ct_egress  tag 5796f224c533891a  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,125,74,75,124,76
	btf_id 220
585: sched_cls  name tail_handle_ipv4_cont  tag 440882da7a5a7aee  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,124,33,123,74,75,31,68,66,69,125,32,29,30,73
	btf_id 221
586: sched_cls  name tail_handle_arp  tag 55331608d5c40a69  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,125
	btf_id 222
587: sched_cls  name tail_ipv4_to_endpoint  tag 940e68da6dbd962f  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,124,33,74,75,72,123,31,125,32,29,30
	btf_id 223
588: sched_cls  name __send_drop_notify  tag 8af8431e6514f429  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 224
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
606: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
609: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
610: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
613: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
614: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
617: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
663: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
666: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3353: sched_cls  name tail_handle_ipv4  tag fdd873e416972a3f  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,636
	btf_id 3180
3354: sched_cls  name tail_ipv4_to_endpoint  tag 18764188579ac778  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,635,33,74,75,72,141,31,636,32,29,30
	btf_id 3181
3355: sched_cls  name tail_ipv4_ct_egress  tag 739d19ab454d5bfa  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,636,74,75,635,76
	btf_id 3182
3356: sched_cls  name tail_handle_arp  tag 00500f328dfb30b8  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,636
	btf_id 3183
3357: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,636
	btf_id 3184
3358: sched_cls  name tail_handle_ipv4_cont  tag 85d24ca67dc104a8  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,635,33,141,74,75,31,68,66,69,636,32,29,30,73
	btf_id 3185
3359: sched_cls  name __send_drop_notify  tag 71fd8f29f25169c2  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3186
3360: sched_cls  name cil_from_container  tag 77da233e29a568a0  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 636,68
	btf_id 3187
3361: sched_cls  name tail_ipv4_ct_ingress  tag 10074d5b042ceca6  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,636,74,75,635,76
	btf_id 3188
3362: sched_cls  name handle_policy  tag 31d7e57a7d027f7a  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,636,74,75,635,33,72,141,31,76,67,32,29,30
	btf_id 3189
3649: sched_cls  name tail_ipv4_to_endpoint  tag a41bd6de037b7cd4  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,690,33,74,75,72,136,31,689,32,29,30
	btf_id 3504
3650: sched_cls  name tail_ipv4_to_endpoint  tag ca187db4ccdbe6a5  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,692,33,74,75,72,133,31,691,32,29,30
	btf_id 3505
3651: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,689
	btf_id 3507
3652: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,691
	btf_id 3506
3653: sched_cls  name tail_handle_ipv4_cont  tag f75648cbd055eee7  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,692,33,133,74,75,31,68,66,69,691,32,29,30,73
	btf_id 3509
3654: sched_cls  name tail_handle_arp  tag 4c2b6a01b7bcb23c  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,691
	btf_id 3510
3655: sched_cls  name tail_handle_ipv4  tag be7f5b6131149563  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,689
	btf_id 3508
3656: sched_cls  name tail_ipv4_ct_egress  tag f2c76ecdc8889812  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,692,76
	btf_id 3511
3657: sched_cls  name __send_drop_notify  tag e3e2d2766e8efa68  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3513
3658: sched_cls  name tail_ipv4_ct_ingress  tag 0a69b55ef808808f  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,689,74,75,690,76
	btf_id 3512
3659: sched_cls  name tail_handle_ipv4  tag 082584346ed044e7  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,691
	btf_id 3514
3660: sched_cls  name tail_ipv4_ct_ingress  tag 70e2c183573e34cf  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,692,76
	btf_id 3516
3661: sched_cls  name cil_from_container  tag 1f49982d64fe4eb4  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 691,68
	btf_id 3517
3662: sched_cls  name handle_policy  tag 38c1b13cf4f14134  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,689,74,75,690,33,72,136,31,76,67,32,29,30
	btf_id 3515
3663: sched_cls  name cil_from_container  tag f37612c83ab6a67c  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 689,68
	btf_id 3518
3664: sched_cls  name tail_handle_ipv4_cont  tag 841af812429e2ec0  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,690,33,136,74,75,31,68,66,69,689,32,29,30,73
	btf_id 3519
3665: sched_cls  name tail_ipv4_ct_egress  tag 0a3598bd663a7600  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,689,74,75,690,76
	btf_id 3520
3666: sched_cls  name __send_drop_notify  tag 944665ff059b7cee  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3522
3667: sched_cls  name tail_handle_arp  tag ddae534600312a6f  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,689
	btf_id 3523
3669: sched_cls  name handle_policy  tag 190236703fc33113  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,691,74,75,692,33,72,133,31,76,67,32,29,30
	btf_id 3521
