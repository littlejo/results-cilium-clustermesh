Page block order: 9
Pages per block:  512

Free pages count per migrate type at order       0      1      2      3      4      5      6      7      8      9     10 
Node    0, zone      DMA, type    Unmovable     17     17     17     19      8      6      2      0      1      0      0 
Node    0, zone      DMA, type      Movable    184    158    118     82     67     44     16     10      4      1    202 
Node    0, zone      DMA, type  Reclaimable      0      1      1      1      1      1      1      1      1      1      0 
Node    0, zone      DMA, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone      DMA, type          CMA      0      1      0      0      0      1      1      0      0      1     15 
Node    0, zone      DMA, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type    Unmovable      1     15     34     71     32     11      5      1      0      0      0 
Node    0, zone   Normal, type      Movable      1      1      7    171    129     51      7      3      2      1      6 
Node    0, zone   Normal, type  Reclaimable      1      1      1      1      1      1      1      1      1      1      0 
Node    0, zone   Normal, type   HighAtomic      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type          CMA      0      0      0      0      0      0      0      0      0      0      0 
Node    0, zone   Normal, type      Isolate      0      0      0      0      0      0      0      0      0      0      0 

Number of blocks type     Unmovable      Movable  Reclaimable   HighAtomic          CMA      Isolate 
Node 0, zone      DMA            2          476            2            0           32            0 
Node 0, zone   Normal          120         1336           44            0            0            0 
