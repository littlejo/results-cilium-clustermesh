172.31.162.53 dev ens5 lladdr 02:4e:27:e1:f2:15 REACHABLE
172.31.167.173 dev ens5 lladdr 02:0b:f9:02:e9:4b REACHABLE
172.31.140.200 dev ens5 lladdr 02:c1:f5:cd:eb:67 REACHABLE
172.31.161.101 dev ens5 lladdr 02:7e:6d:c0:3a:9b REACHABLE
172.31.128.1 dev ens5 lladdr 02:3b:03:d4:6c:49 REACHABLE
