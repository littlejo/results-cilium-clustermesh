[
  {
    "containers": [
      {
        "cgroup-id": 6742,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59076bc7_57c7_4c38_9a3b_47f8a9bc1da3.slice/cri-containerd-c4ca764e4e256382ba2c5b60dacd638f5f6a319fec33e86aaa87e5b1bfc29e1a.scope"
      }
    ],
    "ips": [
      "10.0.0.115"
    ],
    "name": "coredns-586b798467-shdm8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8842,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82193b7b_95fc_48a0_bd7e_398cc97bc71b.slice/cri-containerd-9cf2f7be4548e73048b76a40f6de85248ed3522e7061857fde4b075086319b45.scope"
      }
    ],
    "ips": [
      "10.0.0.133"
    ],
    "name": "client2-57cf4468f-n4msm",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8170,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-3a5a1272ef3d5e1d8645242b7fbab65062093f92e743d7e733e9e8e30203f5be.scope"
      },
      {
        "cgroup-id": 8086,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-0c9b5efe10b3ca18a2c3cfc648af77967957cf0039a0be32ce38afa4e34c60a0.scope"
      },
      {
        "cgroup-id": 8254,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-3400780ad9c441922d393dd1f605ecdce963bf13e8690cb09a6a8e02207a1248.scope"
      }
    ],
    "ips": [
      "10.0.0.58"
    ],
    "name": "clustermesh-apiserver-787d76979f-bbgd4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6658,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fd18b66_0089_4d70_b3e8_a58ae8b79d18.slice/cri-containerd-c794b33a88ddded5adc9a88b9c841ea25e92f3df9dfb1eef6547d5c4d7c2f38d.scope"
      }
    ],
    "ips": [
      "10.0.0.242"
    ],
    "name": "coredns-586b798467-rnt5q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8926,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89685e20_acec_4f69_a5b7_b9df0e5c0785.slice/cri-containerd-6e5c689ac55d2f845eaeb32193f94c73ff9e6061c85ffe070d259d3b3d1a3d5a.scope"
      }
    ],
    "ips": [
      "10.0.0.146"
    ],
    "name": "client-974f6c69d-d6w4f",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9094,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779c7526_848c_4b65_b468_ef3fbf43bb97.slice/cri-containerd-7b28e0b90e156aaea2dfa7d0a140e30bb1f2fd1b84389ca9b8bea647bf27fb4f.scope"
      },
      {
        "cgroup-id": 9010,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779c7526_848c_4b65_b468_ef3fbf43bb97.slice/cri-containerd-f28ac85fa4fcef9be209d342f21f340d898d216c664cf6c84de43cc28f1e5035.scope"
      }
    ],
    "ips": [
      "10.0.0.239"
    ],
    "name": "echo-same-node-86d9cc975c-tsm52",
    "namespace": "cilium-test-1"
  }
]

