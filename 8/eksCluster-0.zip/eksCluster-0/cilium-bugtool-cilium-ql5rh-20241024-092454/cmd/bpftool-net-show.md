xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 530
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 524
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 515
cilium_host(4) clsact/egress cil_from_host-cilium_host id 511
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 447
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 481
lxc8d5dd18629b0(9) clsact/ingress cil_from_container-lxc8d5dd18629b0 id 494
lxc3cefcb94209d(11) clsact/ingress cil_from_container-lxc3cefcb94209d id 473
lxc6d043d655508(15) clsact/ingress cil_from_container-lxc6d043d655508 id 580
lxcf3b77bac316d(17) clsact/ingress cil_from_container-lxcf3b77bac316d id 3661
lxc835446adac6e(19) clsact/ingress cil_from_container-lxc835446adac6e id 3663
lxc8894d1685771(21) clsact/ingress cil_from_container-lxc8894d1685771 id 3360

flow_dissector:

netfilter:

