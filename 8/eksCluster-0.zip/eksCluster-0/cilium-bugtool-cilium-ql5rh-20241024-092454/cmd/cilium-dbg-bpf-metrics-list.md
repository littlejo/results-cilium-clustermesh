REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     524       41591       677    bpf_overlay.c
Interface                   INGRESS     55878     194254975   1132   bpf_host.c
Policy denied               EGRESS      136       10064       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      522       41349       53     encap.h
Success                     EGRESS      708       170259      86     l3.h
Success                     EGRESS      884       62230       1694   bpf_host.c
Success                     EGRESS      9781      1876368     1308   bpf_lxc.c
Success                     INGRESS     11682     1712518     86     l3.h
Success                     INGRESS     12545     1890330     235    trace.h
Unsupported L3 protocol     EGRESS      66        5000        1492   bpf_lxc.c
