Endpoint   Source   FQDN               TTL   ExpirationTime             IPs                                         
245        lookup   cilium.io.         30    2024-10-24T09:25:16.838Z   104.198.14.52                               
245        lookup   one.one.one.one.   9     2024-10-24T09:24:49.440Z   2606:4700:4700::1111,2606:4700:4700::1001   
245        lookup   one.one.one.one.   9     2024-10-24T09:24:49.440Z   1.1.1.1,1.0.0.1                             
36         lookup   cilium.io.         30    2024-10-24T09:25:18.901Z   104.198.14.52                               
36         lookup   one.one.one.one.   13    2024-10-24T09:24:48.638Z   2606:4700:4700::1111,2606:4700:4700::1001   
36         lookup   one.one.one.one.   13    2024-10-24T09:24:48.639Z   1.1.1.1,1.0.0.1                             
