Found 7 cluster configurations

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.1.174
     ✅ TCP connection successfully established to 10.100.1.174:2379
     ✅ TLS connection successfully established to 10.100.1.174:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       8c:93:9d:fc:0b:48:63:3e:c1:99:08:92:c7:83:16:4f
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:58 +0000 UTC
          Not after:   2027-10-24 09:15:58 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       75:7a:c2:b7:6d:e9:f5:87:4d:d0:1c:e5:71:ef:a5:5d:cc:bf:b1:35
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:13:00 +0000 UTC
          Not after:   2027-10-24 09:13:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6443fd3710cbf41e
