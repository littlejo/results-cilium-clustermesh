Endpoint ID: 36
Path: /sys/fs/bpf/tc/globals/cilium_policy_00036

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 89
Path: /sys/fs/bpf/tc/globals/cilium_policy_00089

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23418   290       0        
Allow    Ingress     1          ANY          NONE         disabled    6669    76        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 222
Path: /sys/fs/bpf/tc/globals/cilium_policy_00222

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4614     36        0        
Allow    Ingress     1          ANY          NONE         disabled    300581   3507      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 245
Path: /sys/fs/bpf/tc/globals/cilium_policy_00245

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 593
Path: /sys/fs/bpf/tc/globals/cilium_policy_00593

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6138    67        0        
Allow    Ingress     1          ANY          NONE         disabled    48226   556       0        
Allow    Egress      0          ANY          NONE         disabled    12309   123       0        


Endpoint ID: 2397
Path: /sys/fs/bpf/tc/globals/cilium_policy_02397

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5238    57        0        
Allow    Ingress     1          ANY          NONE         disabled    47698   548       0        
Allow    Egress      0          ANY          NONE         disabled    12027   120       0        


Endpoint ID: 2470
Path: /sys/fs/bpf/tc/globals/cilium_policy_02470

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    203026   1931      0        
Allow    Ingress     1          ANY          NONE         disabled    210547   2180      0        
Allow    Egress      0          ANY          NONE         disabled    293679   2664      0        


Endpoint ID: 3414
Path: /sys/fs/bpf/tc/globals/cilium_policy_03414

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


