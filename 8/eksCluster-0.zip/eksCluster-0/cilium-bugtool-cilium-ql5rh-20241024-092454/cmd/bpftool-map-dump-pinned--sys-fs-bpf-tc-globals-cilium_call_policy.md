key: 24 00 00 00  value: 4e 0e 00 00
key: 59 00 00 00  value: e2 01 00 00
key: de 00 00 00  value: 22 0d 00 00
key: f5 00 00 00  value: 55 0e 00 00
key: 51 02 00 00  value: da 01 00 00
key: 5d 09 00 00  value: f7 01 00 00
key: a6 09 00 00  value: 43 02 00 00
Found 7 elements
