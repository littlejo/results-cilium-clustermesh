CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fd18b66_0089_4d70_b3e8_a58ae8b79d18.slice/cri-containerd-c794b33a88ddded5adc9a88b9c841ea25e92f3df9dfb1eef6547d5c4d7c2f38d.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fd18b66_0089_4d70_b3e8_a58ae8b79d18.slice/cri-containerd-0c80087387f9bb68f5b8f68d780c2e680839c133f83ed3354305f5d78c6356c2.scope
    500      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfad85f51_cb52_4b9c_a084_bb57b0e6b42d.slice/cri-containerd-2b90644b78fc96f5b8396a63e2a099fee565ee292a873a839176fd642f1f984b.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfad85f51_cb52_4b9c_a084_bb57b0e6b42d.slice/cri-containerd-9eb255fff2d2b4b019071b40300e7b27419663141d6ea8dafbdfd7b1e70c069b.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fac33dc_83a8_4add_8e0b_bafb267ed2ea.slice/cri-containerd-4e34a2705427619ae25d9e4488f0975dc63d73dbece16024484fb4c975dff93c.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fac33dc_83a8_4add_8e0b_bafb267ed2ea.slice/cri-containerd-ce995cfb3e5dbfe8f4dd552941ce0f845a111cdf7e06788072866a68534100fd.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59076bc7_57c7_4c38_9a3b_47f8a9bc1da3.slice/cri-containerd-62e3049bb26b1633136f92d265e34f9767c33ddacf63bc8953c47b35c9fe3f4d.scope
    510      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59076bc7_57c7_4c38_9a3b_47f8a9bc1da3.slice/cri-containerd-c4ca764e4e256382ba2c5b60dacd638f5f6a319fec33e86aaa87e5b1bfc29e1a.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-3a5a1272ef3d5e1d8645242b7fbab65062093f92e743d7e733e9e8e30203f5be.scope
    613      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-0c9b5efe10b3ca18a2c3cfc648af77967957cf0039a0be32ce38afa4e34c60a0.scope
    609      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-12fcb5e29c49f09c660e77028af086390800d20046b08ea95f624f6325c7769e.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode6d114d1_ae51_4f8b_90f4_ad544119db4b.slice/cri-containerd-3400780ad9c441922d393dd1f605ecdce963bf13e8690cb09a6a8e02207a1248.scope
    617      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89685e20_acec_4f69_a5b7_b9df0e5c0785.slice/cri-containerd-6e5c689ac55d2f845eaeb32193f94c73ff9e6061c85ffe070d259d3b3d1a3d5a.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89685e20_acec_4f69_a5b7_b9df0e5c0785.slice/cri-containerd-a27e969809bc4ce977166802c3d6eef9e791768903f0d31c9d930ece10d4608c.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779c7526_848c_4b65_b468_ef3fbf43bb97.slice/cri-containerd-eafae5df2aa3e774d8de18b412b28393d602e3c6e4a20bd23d442cfacb7183f5.scope
    662      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779c7526_848c_4b65_b468_ef3fbf43bb97.slice/cri-containerd-f28ac85fa4fcef9be209d342f21f340d898d216c664cf6c84de43cc28f1e5035.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779c7526_848c_4b65_b468_ef3fbf43bb97.slice/cri-containerd-7b28e0b90e156aaea2dfa7d0a140e30bb1f2fd1b84389ca9b8bea647bf27fb4f.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82193b7b_95fc_48a0_bd7e_398cc97bc71b.slice/cri-containerd-0cb1add8ac36d26abce10f32a4aeb85f8d8975559063ce2352b0bb47d4881c06.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82193b7b_95fc_48a0_bd7e_398cc97bc71b.slice/cri-containerd-9cf2f7be4548e73048b76a40f6de85248ed3522e7061857fde4b075086319b45.scope
    666      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee13716c_dc17_4175_95fa_b81f0fc282e7.slice/cri-containerd-bcd74ab6eb9248bf5b6afa4c372d3bd34e39c9baa9b972970934a0ef5c2b2867.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podee13716c_dc17_4175_95fa_b81f0fc282e7.slice/cri-containerd-f2f01e93e535c69d132a05ce0cf18af6f89ec9d88d58e0dd8cd1e6f3beff1458.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf11e4d5_bb7c_4980_b143_e3d2832fbdc8.slice/cri-containerd-070b3f14302d5721974eadbe06ff21d12e3e8e956dd58448348254f97c3e69f5.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf11e4d5_bb7c_4980_b143_e3d2832fbdc8.slice/cri-containerd-0631d9e371f75d289190c0b54327efb7fc4b58177312140d50fe03c37487bd6c.scope
    72       cgroup_device   multi                                          
