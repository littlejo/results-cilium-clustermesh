{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.249Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.281Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.293Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.758Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.772Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.798Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.831Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.840Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:38.870Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.103Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.124Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.174Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.209Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.212Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.573Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.586Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.629Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.666Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.675Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.886Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.901Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.947Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.952Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.996Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.349Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.384Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.393Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.438Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.446Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.472Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.671Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.712Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.745Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.754Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.797Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.132Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.141Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.181Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.196Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.216Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.468Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.477Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.516Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.531Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.553Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.859Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.904Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.922Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.950Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.978Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.005Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.257Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.274Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.315Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.320Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.352Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.571Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.611Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.615Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.647Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.658Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.684Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.915Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.916Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.952Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.981Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.009Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.257Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.303Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.343Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.345Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.400Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.407Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.612Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.634Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.635Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:55.652Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.473Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.571Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.574Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.575Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.607Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.825Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.828Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:09.462Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:09.477Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:10.984Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:17.651Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:17.905Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.709Z",
  "value": "id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.941Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.949Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:24.952Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.685Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.720Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:31.741Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.025Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.026Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.034Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.879Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.917Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:38.932Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.198Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.205Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.206Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.079Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.152Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.163Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.422Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.424Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.426Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.355Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.391Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.412Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.686Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.687Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.699Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:18.528Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:18.585Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:18.599Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:18.897Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:18.901Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:35.826Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:35.837Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.127Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.129Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:48.993Z",
  "value": "id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:48.993Z",
  "value": "id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C"
}

