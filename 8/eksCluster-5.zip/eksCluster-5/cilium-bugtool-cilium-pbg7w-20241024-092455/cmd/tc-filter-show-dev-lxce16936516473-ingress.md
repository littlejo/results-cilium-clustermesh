filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce16936516473 direct-action not_in_hw id 3676 tag f250a7c5d61e601b jited 
