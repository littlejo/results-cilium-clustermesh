top - 09:24:57 up 8 min,  0 users,  load average: 0.15, 0.50, 0.32
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.1 us, 37.5 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  9.4 si,  0.0 st
MiB Mem :   3836.2 total,    991.2 free,    743.9 used,   2101.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2915.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   2829 root      20   0 1244340  22700  14148 R  43.8   0.6   0:00.07 hubble
      1 root      20   0 1405148 188156  79556 S  12.5   4.8   0:23.15 cilium-+
   2759 root      20   0 1240432  16268  11292 S   6.2   0.4   0:00.03 cilium-+
    389 root      20   0 1228848   3820   2872 S   0.0   0.1   0:00.01 cilium-+
   2768 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2773 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2819 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2822 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   2860 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
