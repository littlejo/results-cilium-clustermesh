172.31.213.129 dev ens5 lladdr 12:f9:fd:f2:21:db REACHABLE
172.31.234.224 dev ens5 lladdr 12:32:69:1c:56:3b REACHABLE
172.31.192.1 dev ens5 lladdr 12:77:39:73:55:d5 REACHABLE
172.31.224.68 dev ens5 lladdr 12:8e:8d:ec:57:b3 REACHABLE
172.31.208.9 dev ens5 lladdr 12:92:ce:3b:56:0b REACHABLE
