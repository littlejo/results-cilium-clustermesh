key: 95 00 00 00  value: 62 0e 00 00
key: c7 05 00 00  value: 2d 0d 00 00
key: f4 06 00 00  value: fd 01 00 00
key: 97 08 00 00  value: 59 0e 00 00
key: d6 0b 00 00  value: e3 01 00 00
key: 14 0f 00 00  value: 4e 02 00 00
key: db 0f 00 00  value: 0e 02 00 00
Found 7 elements
