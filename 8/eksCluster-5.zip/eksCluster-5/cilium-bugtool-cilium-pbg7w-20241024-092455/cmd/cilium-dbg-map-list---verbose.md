## Map: cilium_policy_03860
Key              Value           State   Error
Ingress: 0 ANY   0 2109 225527           
Egress: 0 ANY    0 2153 228751           
Ingress: 1 ANY   0 2047 197686           

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
2     ANY://172.31.249.188   sync    
6     ANY://10.5.0.187       sync    
8     ANY://172.31.213.129   sync    
9     ANY://10.5.0.83        sync    
10    ANY://10.5.0.244       sync    
1     ANY://172.31.184.224   sync    
3     ANY://10.5.0.226       sync    
4     ANY://10.5.0.226       sync    
5     ANY://10.5.0.187       sync    

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
3     10.100.0.10:53        sync    
4     10.100.0.10:9153      sync    
5     10.100.27.127:2379    sync    
6     10.100.211.127:8080   sync    
1     10.100.0.1:443        sync    
2     10.100.89.6:443       sync    

## Map: cilium_policy_00409
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_02199
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_policy_00149
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_lb4_services_v2
Key                       Value                State   Error
10.100.27.127:2379 (0)    0 1 (5) [0x0 0x0]    sync    
10.100.89.6:443 (0)       0 1 (2) [0x0 0x10]   sync    
10.100.0.1:443 (0)        0 2 (1) [0x0 0x0]    sync    
10.100.0.10:9153 (0)      0 2 (4) [0x0 0x0]    sync    
10.100.89.6:443 (1)       2 0 (2) [0x0 0x0]    sync    
10.100.0.10:9153 (1)      4 0 (4) [0x0 0x0]    sync    
10.100.27.127:2379 (1)    9 0 (5) [0x0 0x0]    sync    
10.100.0.1:443 (2)        8 0 (1) [0x0 0x0]    sync    
10.100.211.127:8080 (0)   0 1 (6) [0x0 0x0]    sync    
10.100.0.1:443 (1)        1 0 (1) [0x0 0x0]    sync    
10.100.211.127:8080 (1)   10 0 (6) [0x0 0x0]   sync    
10.100.0.10:53 (1)        3 0 (3) [0x0 0x0]    sync    
10.100.0.10:53 (2)        5 0 (3) [0x0 0x0]    sync    
10.100.0.10:9153 (2)      6 0 (4) [0x0 0x0]    sync    
10.100.0.10:53 (0)        0 2 (3) [0x0 0x0]    sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_01479
Key              Value           State   Error
Ingress: 0 ANY   0 33 4408               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3516 301518           

## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440224609375           
AgentLiveness   533475183876               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_policy_03030
Key              Value         State   Error
Ingress: 0 ANY   0 96 9257             
Egress: 0 ANY    0 138 13771           
Ingress: 1 ANY   0 508 44126           

## Map: cilium_tunnel_map
Key        Value              State   Error
10.0.0.0   172.31.190.177:0   sync    
10.2.0.0   172.31.140.200:0   sync    
10.4.0.0   172.31.167.173:0   sync    
10.7.0.0   172.31.208.9:0     sync    
10.6.0.0   172.31.162.53:0    sync    
10.3.0.0   172.31.224.68:0    sync    
10.1.0.0   172.31.234.224:0   sync    

## Map: cilium_policy_04059
Key              Value         State   Error
Ingress: 0 ANY   0 296 23768           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 73 6454             

## Map: cilium_policy_01780
Key              Value         State   Error
Ingress: 0 ANY   0 98 9609             
Egress: 0 ANY    0 133 13222           
Ingress: 1 ANY   0 499 43532           

## Map: cilium_lxc
Key                Value                                                                                             State   Error
172.31.249.188:0   (localhost)                                                                                       sync    
10.5.0.80:0        id=4059  sec_id=4     flags=0x0000 ifindex=7   mac=5E:0A:54:EE:4C:78 nodemac=FA:AE:6C:5B:4A:88    sync    
10.5.0.187:0       id=1780  sec_id=409754 flags=0x0000 ifindex=11  mac=72:66:9E:78:CF:FA nodemac=52:31:43:A7:54:6B   sync    
10.5.0.38:0        id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9   sync    
10.5.0.160:0       id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C   sync    
10.5.0.219:0       (localhost)                                                                                       sync    
10.5.0.226:0       id=3030  sec_id=409754 flags=0x0000 ifindex=9   mac=3A:2E:5B:A6:22:36 nodemac=B2:29:61:E6:C8:14   sync    
10.5.0.83:0        id=3860  sec_id=400535 flags=0x0000 ifindex=15  mac=46:24:37:E5:21:65 nodemac=6A:B4:C7:47:7D:93   sync    
10.5.0.244:0       id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60   sync    

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.184.224/32   identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.5.0.219/32       identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
172.31.249.188/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.213.129/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    

## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


