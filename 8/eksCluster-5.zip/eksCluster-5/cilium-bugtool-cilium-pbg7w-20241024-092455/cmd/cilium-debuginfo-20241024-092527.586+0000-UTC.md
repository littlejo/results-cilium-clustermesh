# Cilium debug information

#### Policy get

```
:
 []
Revision: 157

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37786112                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37786112                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37786112                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006400000 rw-p 00000000 00:00 0 
4006400000-4008000000 ---p 00000000 00:00 0 
ffff4f155000-ffff4f266000 rw-p 00000000 00:00 0 
ffff4f266000-ffff4f2a7000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4f2a7000-ffff4f2e8000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4f2e8000-ffff4f328000 rw-p 00000000 00:00 0 
ffff4f328000-ffff4f32a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4f32a000-ffff4f32c000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff4f32c000-ffff4f8f3000 rw-p 00000000 00:00 0 
ffff4f8f3000-ffff4f9f3000 rw-p 00000000 00:00 0 
ffff4f9f3000-ffff4fa04000 rw-p 00000000 00:00 0 
ffff4fa04000-ffff51a04000 rw-p 00000000 00:00 0 
ffff51a04000-ffff51a84000 ---p 00000000 00:00 0 
ffff51a84000-ffff51a85000 rw-p 00000000 00:00 0 
ffff51a85000-ffff71a84000 ---p 00000000 00:00 0 
ffff71a84000-ffff71a85000 rw-p 00000000 00:00 0 
ffff71a85000-ffff91a14000 ---p 00000000 00:00 0 
ffff91a14000-ffff91a15000 rw-p 00000000 00:00 0 
ffff91a15000-ffff95a06000 ---p 00000000 00:00 0 
ffff95a06000-ffff95a07000 rw-p 00000000 00:00 0 
ffff95a07000-ffff96204000 ---p 00000000 00:00 0 
ffff96204000-ffff96205000 rw-p 00000000 00:00 0 
ffff96205000-ffff96304000 ---p 00000000 00:00 0 
ffff96304000-ffff96364000 rw-p 00000000 00:00 0 
ffff96364000-ffff96366000 r--p 00000000 00:00 0                          [vvar]
ffff96366000-ffff96367000 r-xp 00000000 00:00 0                          [vdso]
ffffe0827000-ffffe0848000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=9) "10.5.0.80": (string) (len=6) "health",
  (string) (len=10) "10.5.0.226": (string) (len=36) "kube-system/coredns-586b798467-p2mr5",
  (string) (len=10) "10.5.0.187": (string) (len=36) "kube-system/coredns-586b798467-t5p4l",
  (string) (len=9) "10.5.0.38": (string) (len=36) "cilium-test-1/client-974f6c69d-ngz88",
  (string) (len=9) "10.5.0.83": (string) (len=49) "kube-system/clustermesh-apiserver-5f7c67789-2td27",
  (string) (len=10) "10.5.0.160": (string) (len=37) "cilium-test-1/client2-57cf4468f-wqh2h",
  (string) (len=10) "10.5.0.244": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-x4t7h",
  (string) (len=10) "10.5.0.219": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.249.188": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40016096b0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001cabe00,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001cabe00,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002bf02c0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4002947810)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40029478c0)(frontends:[10.100.27.127]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4002e0b6b0)(frontends:[10.100.211.127]/ports=[http]/selector=map[name:echo-same-node]),
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002bf0160)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002bf0210)(frontends:[10.100.89.6]/ports=[peer-service]/selector=map[k8s-app:cilium])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x400168a128)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003172d00)(172.31.184.224:443/TCP,172.31.213.129:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x400168a130)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-592rd": (*k8s.Endpoints)(0x4003172000)(172.31.249.188:4244/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x400168a138)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-6x48d": (*k8s.Endpoints)(0x4002b4b2b0)(10.5.0.187:53/TCP[us-east-1b],10.5.0.187:53/UDP[us-east-1b],10.5.0.187:9153/TCP[us-east-1b],10.5.0.226:53/TCP[us-east-1b],10.5.0.226:53/UDP[us-east-1b],10.5.0.226:9153/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001418740)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-bkz8g": (*k8s.Endpoints)(0x4001851ba0)(10.5.0.83:2379/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000712ef0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-jz7c8": (*k8s.Endpoints)(0x4003297c70)(10.5.0.244:8080/TCP[us-east-1b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40019c6d20)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40008435e0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4004998ee8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4000dfe480,
  gcExited: (chan struct {}) 0x4000dfe4e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001c70380)({
     ObserverVec: (*prometheus.HistogramVec)(0x400163be10)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8d8c0)({
       metricMap: (*prometheus.metricMap)(0x4001c8d8f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1680)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001c70400)({
     ObserverVec: (*prometheus.HistogramVec)(0x400163be18)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8d950)({
       metricMap: (*prometheus.metricMap)(0x4001c8d980)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c16e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c70480)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be20)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8d9e0)({
       metricMap: (*prometheus.metricMap)(0x4001c8da10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1740)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c70500)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be28)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8da70)({
       metricMap: (*prometheus.metricMap)(0x4001c8daa0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c17a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c70580)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be30)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8db00)({
       metricMap: (*prometheus.metricMap)(0x4001c8db30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1800)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c70600)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be38)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8db90)({
       metricMap: (*prometheus.metricMap)(0x4001c8dbc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1860)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c70680)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be40)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8dc20)({
       metricMap: (*prometheus.metricMap)(0x4001c8dc50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c18c0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c70700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400163be48)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8dcb0)({
       metricMap: (*prometheus.metricMap)(0x4001c8dce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1920)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c70780)({
     ObserverVec: (*prometheus.HistogramVec)(0x400163be50)({
      MetricVec: (*prometheus.MetricVec)(0x4001c8dd40)({
       metricMap: (*prometheus.metricMap)(0x4001c8dd70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019c1980)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40019c6d20)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40019c7ea0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d40a20)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.184.224:443 (active)    
                                          2 => 172.31.213.129:443 (active)    
2    10.100.89.6:443       ClusterIP      1 => 172.31.249.188:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.5.0.226:53 (active)         
                                          2 => 10.5.0.187:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.5.0.226:9153 (active)       
                                          2 => 10.5.0.187:9153 (active)       
5    10.100.27.127:2379    ClusterIP      1 => 10.5.0.83:2379 (active)        
6    10.100.211.127:8080   ClusterIP      1 => 10.5.0.244:8080 (active)       
```

#### Cilium environment keys

```
tofqdns-proxy-port:0
pprof-port:6060
trace-payloadlen:128
nodeport-addresses:
policy-queue-size:100
bpf-lb-acceleration:disabled
enable-ipv6-big-tcp:false
state-dir:/var/run/cilium
ipv6-service-range:auto
ipam:cluster-pool
proxy-gid:1337
bpf-events-policy-verdict-enabled:true
gateway-api-secrets-namespace:
bpf-nat-global-max:524288
tofqdns-pre-cache:
k8s-api-server:
kvstore-periodic-sync:5m0s
bpf-lb-sock-hostns-only:false
enable-ipsec-xfrm-state-caching:true
enable-ipv6-ndp:false
bpf-neigh-global-max:524288
encrypt-interface:
hubble-prefer-ipv6:false
bpf-lb-dsr-l4-xlate:frontend
enable-cilium-endpoint-slice:false
dns-max-ips-per-restored-rule:1000
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-redact-http-headers-deny:
devices:
policy-cidr-match-mode:
hubble-export-file-compress:false
enable-ipsec:false
agent-health-port:9879
annotate-k8s-node:false
log-system-load:false
bpf-lb-maglev-table-size:16381
label-prefix-file:
dnsproxy-lock-count:131
tofqdns-endpoint-max-ip-per-hostname:50
api-rate-limit:
k8s-namespace:kube-system
nodes-gc-interval:5m0s
encrypt-node:false
bpf-lb-external-clusterip:false
node-port-acceleration:disabled
k8s-client-qps:10
metrics:
certificates-directory:/var/run/cilium/certs
enable-ipv6:false
bpf-events-drop-enabled:true
clustermesh-sync-timeout:1m0s
bpf-node-map-max:16384
bpf-policy-map-full-reconciliation-interval:15m0s
cni-log-file:/var/run/cilium/cilium-cni.log
enable-local-node-route:true
enable-mke:false
enable-icmp-rules:true
enable-cilium-health-api-server-access:
proxy-portrange-min:10000
enable-masquerade-to-route-source:false
bpf-map-event-buffers:
crd-wait-timeout:5m0s
mesh-auth-queue-size:1024
hubble-export-allowlist:
mtu:0
hubble-drop-events-reasons:auth_required,policy_denied
enable-xt-socket-fallback:true
ipv6-cluster-alloc-cidr:f00d::/64
envoy-keep-cap-netbindservice:false
enable-k8s-api-discovery:false
hubble-skip-unknown-cgroup-ids:true
policy-trigger-interval:1s
enable-ipv4-masquerade:true
enable-ingress-controller:false
ipv6-pod-subnets:
bpf-lb-sock-terminate-pod-connections:false
bpf-ct-global-any-max:262144
tofqdns-idle-connection-grace-period:0s
enable-host-port:false
hubble-drop-events:false
http-retry-count:3
enable-bgp-control-plane:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
enable-bpf-clock-probe:false
hubble-drop-events-interval:2m0s
envoy-config-retry-interval:15s
labels:
enable-endpoint-routes:false
clustermesh-enable-mcs-api:false
bpf-ct-timeout-regular-tcp-fin:10s
ipsec-key-file:
bpf-events-trace-enabled:true
allocator-list-timeout:3m0s
kvstore-connectivity-timeout:2m0s
kvstore-opt:
envoy-secrets-namespace:
route-metric:0
enable-policy:default
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
unmanaged-pod-watcher-interval:15
hubble-redact-kafka-apikey:false
http-normalize-path:true
k8s-client-connection-timeout:30s
enable-l2-announcements:false
identity-gc-interval:15m0s
egress-masquerade-interfaces:ens+
remove-cilium-node-taints:true
policy-audit-mode:false
node-labels:
proxy-max-requests-per-connection:0
mesh-auth-mutual-listener-port:0
use-full-tls-context:false
enable-sctp:false
disable-iptables-feeder-rules:
proxy-prometheus-port:0
bpf-auth-map-max:524288
proxy-admin-port:0
enable-bandwidth-manager:false
k8s-require-ipv6-pod-cidr:false
hubble-metrics:
enable-endpoint-health-checking:true
nat-map-stats-interval:30s
exclude-local-address:
enable-active-connection-tracking:false
proxy-xff-num-trusted-hops-ingress:0
multicast-enabled:false
kvstore:
enable-tcx:true
monitor-aggregation:medium
bpf-fragments-map-max:8192
proxy-portrange-max:20000
set-cilium-node-taints:true
enable-nat46x64-gateway:false
ingress-secrets-namespace:
custom-cni-conf:false
hubble-redact-http-urlquery:false
vtep-endpoint:
ipam-cilium-node-update-rate:15s
cluster-pool-ipv4-cidr:10.5.0.0/16
cluster-pool-ipv4-mask-size:24
enable-k8s:true
join-cluster:false
cmdref:
k8s-client-connection-keep-alive:30s
identity-heartbeat-timeout:30m0s
derive-masq-ip-addr-from-device:
enable-external-ips:false
enable-hubble:true
hubble-export-file-max-size-mb:10
enable-host-legacy-routing:false
disable-endpoint-crd:false
operator-prometheus-serve-addr::9963
force-device-detection:false
config:
k8s-service-cache-size:128
controller-group-metrics:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
fqdn-regex-compile-lru-size:1024
enable-l2-pod-announcements:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
hubble-redact-http-headers-allow:
wireguard-persistent-keepalive:0s
max-connected-clusters:255
bpf-ct-global-tcp-max:524288
identity-change-grace-period:5s
bpf-ct-timeout-regular-any:1m0s
http-idle-timeout:0
dnsproxy-concurrency-limit:0
local-max-addr-scope:252
kube-proxy-replacement-healthz-bind-address:
enable-srv6:false
http-max-grpc-timeout:0
enable-local-redirect-policy:false
ipv4-native-routing-cidr:
log-opt:
enable-cilium-api-server-access:
debug:false
mesh-auth-spire-admin-socket:
lib-dir:/var/lib/cilium
k8s-client-burst:20
enable-vtep:false
enable-wireguard-userspace-fallback:false
enable-runtime-device-detection:true
enable-recorder:false
enable-ipv4-egress-gateway:false
ipv4-service-range:auto
hubble-redact-enabled:false
bpf-filter-priority:1
fixed-identity-mapping:
cni-exclusive:true
enable-route-mtu-for-cni-chaining:false
local-router-ipv6:
enable-k8s-networkpolicy:true
encryption-strict-mode-cidr:
kvstore-lease-ttl:15m0s
enable-bpf-tproxy:false
agent-liveness-update-interval:1s
config-sources:config-map:kube-system/cilium-config
use-cilium-internal-ip-for-ipsec:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-socket-path:/var/run/cilium/hubble.sock
synchronize-k8s-nodes:true
envoy-config-timeout:2m0s
identity-restore-grace-period:30s
cluster-health-port:4240
enable-k8s-terminating-endpoint:true
clustermesh-enable-endpoint-sync:false
kvstore-max-consecutive-quorum-errors:2
auto-create-cilium-node-resource:true
enable-bbr:false
cni-chaining-mode:none
identity-allocation-mode:crd
enable-auto-protect-node-port-range:true
hubble-event-queue-size:0
enable-gateway-api:false
encryption-strict-mode-allow-remote-node-identities:false
envoy-base-id:0
bpf-lb-source-range-map-max:0
bpf-ct-timeout-service-any:1m0s
enable-identity-mark:true
trace-sock:true
disable-external-ip-mitigation:false
enable-node-selector-labels:false
dnsproxy-concurrency-processing-grace-period:0s
enable-well-known-identities:false
hubble-monitor-events:
node-port-algorithm:random
k8s-heartbeat-timeout:30s
vlan-bpf-bypass:
tofqdns-proxy-response-max-delay:100ms
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-service-backend-map-max:0
enable-metrics:true
enable-stale-cilium-endpoint-cleanup:true
prometheus-serve-addr:
install-no-conntrack-iptables-rules:false
dnsproxy-enable-transparent-mode:true
node-port-range:
kube-proxy-replacement:false
l2-announcements-lease-duration:15s
tofqdns-dns-reject-response-code:refused
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
max-internal-timer-delay:0s
set-cilium-is-up-condition:true
hubble-event-buffer-capacity:4095
enable-encryption-strict-mode:false
vtep-mask:
agent-labels:
dnsproxy-socket-linger-timeout:10
max-controller-interval:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-high-scale-ipcache:false
ipv4-service-loopback-address:169.254.42.1
policy-accounting:true
egress-gateway-reconciliation-trigger-interval:1s
routing-mode:tunnel
debug-verbose:
ipam-default-ip-pool:default
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
prepend-iptables-chains:true
socket-path:/var/run/cilium/cilium.sock
direct-routing-skip-unreachable:false
hubble-redact-http-userinfo:true
enable-session-affinity:false
http-retry-timeout:0
mesh-auth-signal-backoff-duration:1s
bpf-lb-algorithm:random
bpf-lb-dsr-dispatch:opt
auto-direct-node-routes:false
bpf-lb-rss-ipv4-src-cidr:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
container-ip-local-reserved-ports:auto
bgp-announce-pod-cidr:false
cluster-name:cmesh6
k8s-require-ipv4-pod-cidr:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
clustermesh-ip-identities-sync-timeout:1m0s
mesh-auth-gc-interval:5m0s
mesh-auth-mutual-connect-timeout:5s
enable-pmtu-discovery:false
proxy-connect-timeout:2
restore:true
enable-xdp-prefilter:false
bpf-lb-maglev-map-max:0
ipam-multi-pool-pre-allocation:
exclude-node-label-patterns:
direct-routing-device:
bpf-root:/sys/fs/bpf
static-cnp-path:
tofqdns-max-deferred-connection-deletes:10000
dns-policy-unload-on-shutdown:false
l2-pod-announcements-interface:
endpoint-bpf-prog-watchdog-interval:30s
tofqdns-min-ttl:0
egress-gateway-policy-map-max:16384
enable-health-checking:true
enable-health-check-nodeport:true
enable-l7-proxy:true
enable-health-check-loadbalancer-ip:false
local-router-ipv4:
log-driver:
preallocate-bpf-maps:false
k8s-sync-timeout:3m0s
k8s-kubeconfig-path:
enable-k8s-endpoint-slice:true
bpf-sock-rev-map-max:262144
enable-ipv4:true
bpf-ct-timeout-regular-tcp:2h13m20s
srv6-encap-mode:reduced
bgp-announce-lb-ip:false
enable-l2-neigh-discovery:true
bpf-lb-map-max:65536
read-cni-conf:
enable-tracing:false
conntrack-gc-max-interval:0s
tunnel-port:0
bypass-ip-availability-upon-restore:false
enable-ipsec-key-watcher:true
hubble-flowlogs-config-path:
l2-announcements-retry-period:2s
proxy-idle-timeout-seconds:60
bpf-lb-affinity-map-max:0
node-port-mode:snat
install-iptables-rules:true
bpf-ct-timeout-service-tcp-grace:1m0s
iptables-lock-timeout:5s
allow-localhost:auto
hubble-export-file-path:
ipv4-node:auto
ipv6-mcast-device:
gops-port:9890
cluster-id:6
cflags:
monitor-aggregation-flags:all
tunnel-protocol:vxlan
tofqdns-enable-dns-compression:true
conntrack-gc-interval:0s
ipv4-pod-subnets:
disable-envoy-version-check:false
enable-bpf-masquerade:false
node-port-bind-protection:true
cni-chaining-target:
mke-cgroup-mount:
vtep-mac:
enable-hubble-recorder-api:true
hubble-disable-tls:false
cni-external-routing:false
egress-multi-home-ip-rule-compat:false
ipv6-native-routing-cidr:
bpf-lb-mode:snat
enable-svc-source-range-check:true
external-envoy-proxy:true
enable-wireguard:false
iptables-random-fully:false
bpf-lb-service-map-max:0
mesh-auth-rotated-identities-queue-size:1024
monitor-aggregation-interval:5s
enable-monitor:true
ipv4-range:auto
bpf-lb-rss-ipv6-src-cidr:
mesh-auth-enabled:true
vtep-cidr:
enable-ipv4-fragment-tracking:true
l2-announcements-renew-deadline:5s
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-ipsec-encrypted-overlay:false
arping-refresh-period:30s
ipv6-node:auto
pprof:false
monitor-queue-size:0
endpoint-gc-interval:5m0s
hubble-metrics-server:
hubble-export-fieldmask:
enable-service-topology:false
enable-unreachable-routes:false
envoy-log:
bpf-ct-timeout-service-tcp:2h13m20s
proxy-xff-num-trusted-hops-egress:0
allow-icmp-frag-needed:true
hubble-export-denylist:
cilium-endpoint-gc-interval:5m0s
pprof-address:localhost
nat-map-stats-entries:32
ipv6-range:auto
dnsproxy-lock-timeout:500ms
enable-ipip-termination:false
keep-config:false
hubble-listen-address::4244
cgroup-root:/run/cilium/cgroupv2
proxy-max-connection-duration-seconds:0
k8s-service-proxy-name:
enable-ipv6-masquerade:true
enable-ipv4-big-tcp:false
hubble-export-file-max-backups:5
enable-host-firewall:false
bpf-map-dynamic-size-ratio:0.0025
operator-api-serve-addr:127.0.0.1:9234
enable-envoy-config:false
enable-node-port:false
clustermesh-config:/var/lib/cilium/clustermesh/
datapath-mode:veth
bpf-lb-sock:false
version:false
endpoint-queue-size:25
procfs:/host/proc
config-dir:/tmp/cilium/config-map
dnsproxy-insecure-skip-transparent-mode-check:false
http-request-timeout:3600
bpf-lb-rev-nat-map-max:0
bpf-policy-map-max:16384
enable-custom-calls:false
ipsec-key-rotation-duration:5m0s
service-no-backend-response:reject
hubble-recorder-sink-queue-size:1024
enable-ip-masq-agent:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
149        Disabled           Disabled          397076     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.5.0.160   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
409        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1b                                                                 
                                                           reserved:host                                                                                              
1479       Disabled           Disabled          395399     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.5.0.244   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
1780       Disabled           Disabled          409754     k8s:eks.amazonaws.com/component=coredns                                               10.5.0.187   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2199       Disabled           Disabled          406305     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.5.0.38    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
3030       Disabled           Disabled          409754     k8s:eks.amazonaws.com/component=coredns                                               10.5.0.226   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
3860       Disabled           Disabled          400535     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.5.0.83    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh6                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
4059       Disabled           Disabled          4          reserved:health                                                                       10.5.0.80    ready   
```

#### BPF Policy Get 149

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 149

```
Invalid argument: unknown type 149
```


#### Endpoint Get 149

```
[
  {
    "id": 149,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-149-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "765139c6-c9d0-4477-b115-ee220ebdf2cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-149",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.951Z",
            "success-count": 2
          },
          "uuid": "ac5cb025-2ebd-42d4-8b43-08cff2983772"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-wqh2h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.950Z",
            "success-count": 1
          },
          "uuid": "884048c9-b04b-4e63-b8e8-e00b2b0b6050"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-149",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.999Z",
            "success-count": 1
          },
          "uuid": "bbb686e4-9e2f-4687-b168-439b67600798"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (149)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.998Z",
            "success-count": 33
          },
          "uuid": "40cfa182-0c50-47de-8af9-9a84cdf2a2e7"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "a69ca5affdce60b9401f2bb54ef9de843925021a7f458e32682676521845540d:eth0",
        "container-id": "a69ca5affdce60b9401f2bb54ef9de843925021a7f458e32682676521845540d",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-wqh2h",
        "pod-name": "cilium-test-1/client2-57cf4468f-wqh2h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 397076,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:48Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.160",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "76:72:67:1b:60:2c",
        "interface-index": 19,
        "interface-name": "lxc2afe08556c18",
        "mac": "16:1d:56:3e:a7:ab"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 397076,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 397076,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 149

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 149

```
Timestamp              Status   State                   Message
2024-10-24T09:24:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 397076

```
ID       LABELS
397076   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 409

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 409

```
Invalid argument: unknown type 409
```


#### Endpoint Get 409

```
[
  {
    "id": 409,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-409-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "55038bae-5501-437c-8ee4-d79b020eb1fe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-409",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:22:22.027Z",
            "success-count": 2
          },
          "uuid": "37a6b11d-5193-49e4-8639-efe444907ed7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-409",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:23.225Z",
            "success-count": 1
          },
          "uuid": "7cf7d51e-5653-456a-8dcd-e3a22faedadc"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "9a:a3:14:f5:1e:ab",
        "interface-name": "cilium_host",
        "mac": "9a:a3:14:f5:1e:ab"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 409

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 409

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T09:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:26Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T09:17:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T09:17:23Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:17:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:17:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:17:22Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:17:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1479

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4408     33        0        
Allow    Ingress     1          ANY          NONE         disabled    300499   3504      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1479

```
Invalid argument: unknown type 1479
```


#### Endpoint Get 1479

```
[
  {
    "id": 1479,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1479-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7edbb564-1e97-45b3-b979-4d5cd9ff0c39"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1479",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:17.128Z",
            "success-count": 2
          },
          "uuid": "ca1d861e-7be1-430e-8891-b538258aec7d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-x4t7h",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.127Z",
            "success-count": 1
          },
          "uuid": "6d12cdfc-94a3-4cf4-bfac-481edb442ad8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1479",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.170Z",
            "success-count": 1
          },
          "uuid": "1a0ff92e-c821-4c74-b080-60df3547e2c1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1479)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:27.167Z",
            "success-count": 33
          },
          "uuid": "c15a840e-549d-4be7-84ed-c2a8618b1073"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d426770335e606c19f7440ac3a9c96caa8b269f753cecd6e02c28238a463aa93:eth0",
        "container-id": "d426770335e606c19f7440ac3a9c96caa8b269f753cecd6e02c28238a463aa93",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-x4t7h",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-x4t7h"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 395399,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:24Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.244",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "da:e8:0a:38:40:60",
        "interface-index": 21,
        "interface-name": "lxcded33390d67f",
        "mac": "76:84:1f:ba:24:b9"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 395399,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 395399,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1479

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1479

```
Timestamp              Status   State                   Message
2024-10-24T09:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:21Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:04Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 395399

```
ID       LABELS
395399   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 1780

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    9609    98        0        
Allow    Ingress     1          ANY          NONE         disabled    43532   499       0        
Allow    Egress      0          ANY          NONE         disabled    13156   132       0        

```


#### BPF CT List 1780

```
Invalid argument: unknown type 1780
```


#### Endpoint Get 1780

```
[
  {
    "id": 1780,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1780-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "32bc60d1-d829-4d4a-a62c-dca185baedd4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1780",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:22:23.608Z",
            "success-count": 2
          },
          "uuid": "d22c0e2f-de9c-4722-afe0-30e4a8de1209"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-t5p4l",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:23.608Z",
            "success-count": 1
          },
          "uuid": "80d737fa-2c6e-47ad-b78f-14e6c5e9eac1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1780",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:26.690Z",
            "success-count": 1
          },
          "uuid": "76766879-1509-47cd-bf6c-62097a7e3c3e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1780)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:23.657Z",
            "success-count": 50
          },
          "uuid": "22cf2a35-405f-41de-ba43-e3a707dbfc3c"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "16ddce83d010ccfe60457e73f29b646a2a9a3cd285aabfa695dd266d575fbade:eth0",
        "container-id": "16ddce83d010ccfe60457e73f29b646a2a9a3cd285aabfa695dd266d575fbade",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-t5p4l",
        "pod-name": "kube-system/coredns-586b798467-t5p4l"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 409754,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.187",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:31:43:a7:54:6b",
        "interface-index": 11,
        "interface-name": "lxcff94c5b195f7",
        "mac": "72:66:9e:78:cf:fa"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 409754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 409754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1780

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1780

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:26Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:17:23Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:17:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 409754

```
ID       LABELS
409754   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2199

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2199

```
Invalid argument: unknown type 2199
```


#### Endpoint Get 2199

```
[
  {
    "id": 2199,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2199-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "aa8be0df-d8d0-48a6-8e7c-0a2921152da3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2199",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.850Z",
            "success-count": 2
          },
          "uuid": "d0274d6f-723a-454a-82f7-24ca7009417d"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-ngz88",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.849Z",
            "success-count": 1
          },
          "uuid": "78af5843-9e37-44a6-aac5-8528ad5d2c46"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2199",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.938Z",
            "success-count": 1
          },
          "uuid": "5f38430d-f434-4dbd-a3c5-05b0ba3c1682"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2199)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.890Z",
            "success-count": 33
          },
          "uuid": "f7ed34fc-c55d-4115-a92c-5d3bfd6fbd25"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "84c23041be13badf964cd487d2314aca607c8df430dc12b6e93a39a18c970fe4:eth0",
        "container-id": "84c23041be13badf964cd487d2314aca607c8df430dc12b6e93a39a18c970fe4",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-ngz88",
        "pod-name": "cilium-test-1/client-974f6c69d-ngz88"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 406305,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:48Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.38",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "02:05:08:ea:33:b9",
        "interface-index": 17,
        "interface-name": "lxce16936516473",
        "mac": "22:a1:bd:77:41:48"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 406305,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 406305,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2199

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2199

```
Timestamp              Status   State                   Message
2024-10-24T09:24:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:55Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:52Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:50Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:30Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 406305

```
ID       LABELS
406305   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### BPF Policy Get 3030

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    9257    96        0        
Allow    Ingress     1          ANY          NONE         disabled    44126   508       0        
Allow    Egress      0          ANY          NONE         disabled    13771   138       0        

```


#### BPF CT List 3030

```
Invalid argument: unknown type 3030
```


#### Endpoint Get 3030

```
[
  {
    "id": 3030,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3030-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "38073f34-0459-4294-b906-0aebc16053dc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3030",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:22:23.532Z",
            "success-count": 2
          },
          "uuid": "8472f793-2e4c-458e-8cc5-07adc94e4b48"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-p2mr5",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:23.531Z",
            "success-count": 1
          },
          "uuid": "8dd9ce5d-2d9c-4682-9c7c-9015f761a047"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3030",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:26.648Z",
            "success-count": 1
          },
          "uuid": "329255dd-5dde-400c-bd16-30396c1cf588"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3030)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:23.574Z",
            "success-count": 50
          },
          "uuid": "fbf599f0-c0bc-45cb-8f6b-940e1bbc1854"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8fae3f75be1e40765803d4c3b8394508d66a498ad7b6f926b5b970a688cd772e:eth0",
        "container-id": "8fae3f75be1e40765803d4c3b8394508d66a498ad7b6f926b5b970a688cd772e",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-p2mr5",
        "pod-name": "kube-system/coredns-586b798467-p2mr5"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 409754,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.226",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "b2:29:61:e6:c8:14",
        "interface-index": 9,
        "interface-name": "lxc90c637bf1e20",
        "mac": "3a:2e:5b:a6:22:36"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 409754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 409754,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3030

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3030

```
Timestamp              Status    State                   Message
2024-10-24T09:20:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:53Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:53Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:53Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:19:53Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:52Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:52Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:52Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:52Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:51Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:51Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:51Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:51Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:35Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:34Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:34Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:34Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:34Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:26Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:17:26Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:25Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:17:24Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:17:24Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:17:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:17:23Z   OK        ready                   Set identity for this endpoint
2024-10-24T09:17:23Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:23Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 409754

```
ID       LABELS
409754   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3860

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    225593   2110      0        
Allow    Ingress     1          ANY          NONE         disabled    197686   2047      0        
Allow    Egress      0          ANY          NONE         disabled    228751   2153      0        

```


#### BPF CT List 3860

```
Invalid argument: unknown type 3860
```


#### Endpoint Get 3860

```
[
  {
    "id": 3860,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3860-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "50b1c004-ab60-4ffb-8f33-7a7f227250f1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3860",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:23:55.820Z",
            "success-count": 2
          },
          "uuid": "62509461-ca9f-4e1e-9672-4fe92d956177"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-5f7c67789-2td27",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:55.819Z",
            "success-count": 1
          },
          "uuid": "b724178e-68ae-452a-9e98-29fa8bf006c5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3860",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:55.869Z",
            "success-count": 1
          },
          "uuid": "cd2b9dc1-9452-48b1-8e8d-4868db75f7d4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3860)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.863Z",
            "success-count": 41
          },
          "uuid": "4a2e8d03-0437-4c74-bd7b-bc86ab8c623a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b12c606b13279ba39cc0676d92d454235234edd880536c32c4b0cdcf1dc4d575:eth0",
        "container-id": "b12c606b13279ba39cc0676d92d454235234edd880536c32c4b0cdcf1dc4d575",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-5f7c67789-2td27",
        "pod-name": "kube-system/clustermesh-apiserver-5f7c67789-2td27"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 400535,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=5f7c67789"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh6",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.83",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6a:b4:c7:47:7d:93",
        "interface-index": 15,
        "interface-name": "lxca191ee3a0dc6",
        "mac": "46:24:37:e5:21:65"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 400535,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 400535,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3860

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3860

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:18:55Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:18:55Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 400535

```
ID       LABELS
400535   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh6
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 4059

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23834   297       0        
Allow    Ingress     1          ANY          NONE         disabled    6454    73        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 4059

```
Invalid argument: unknown type 4059
```


#### Endpoint Get 4059

```
[
  {
    "id": 4059,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-4059-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "567e4568-7c2c-4cf6-acd7-cb11a571d52e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-4059",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:22:23.086Z",
            "success-count": 2
          },
          "uuid": "aea5be46-3a0d-481b-90aa-6c3706e21d79"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-4059",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:17:26.628Z",
            "success-count": 1
          },
          "uuid": "0ba34a6f-a262-4210-99c3-82b44e39f15a"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.5.0.80",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "fa:ae:6c:5b:4a:88",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "5e:0a:54:ee:4c:78"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 4059

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 4059

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:53Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:52Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:52Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:52Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:52Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:51Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:34Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:17:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:17:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:17:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:17:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:17:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:17:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:17:23Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:17:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.5.0.0/24, 
Allocated addresses:
  10.5.0.160 (cilium-test-1/client2-57cf4468f-wqh2h)
  10.5.0.187 (kube-system/coredns-586b798467-t5p4l)
  10.5.0.219 (router)
  10.5.0.226 (kube-system/coredns-586b798467-p2mr5)
  10.5.0.244 (cilium-test-1/echo-same-node-86d9cc975c-x4t7h)
  10.5.0.38 (cilium-test-1/client-974f6c69d-ngz88)
  10.5.0.80 (health)
  10.5.0.83 (kube-system/clustermesh-apiserver-5f7c67789-2td27)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 41872c21071c9da8
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   6s ago         never        0       no error   
  ct-map-pressure                                                    8s ago         never        0       no error   
  daemon-validate-config                                             1m1s ago       never        0       no error   
  dns-garbage-collector-job                                          10s ago        never        0       no error   
  endpoint-1479-regeneration-recovery                                never          never        0       no error   
  endpoint-149-regeneration-recovery                                 never          never        0       no error   
  endpoint-1780-regeneration-recovery                                never          never        0       no error   
  endpoint-2199-regeneration-recovery                                never          never        0       no error   
  endpoint-3030-regeneration-recovery                                never          never        0       no error   
  endpoint-3860-regeneration-recovery                                never          never        0       no error   
  endpoint-4059-regeneration-recovery                                never          never        0       no error   
  endpoint-409-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        3m10s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               8s ago         never        0       no error   
  ipcache-inject-labels                                              8s ago         never        0       no error   
  k8s-heartbeat                                                      11s ago        never        0       no error   
  link-cache                                                         8s ago         never        0       no error   
  local-identity-checkpoint                                          38s ago        never        0       no error   
  node-neighbor-link-updater                                         8s ago         never        0       no error   
  remote-etcd-cmesh1                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh2                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh3                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh4                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh5                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh7                                                 5m38s ago      never        0       no error   
  remote-etcd-cmesh8                                                 5m38s ago      never        0       no error   
  resolve-identity-1479                                              13s ago        never        0       no error   
  resolve-identity-149                                               14s ago        never        0       no error   
  resolve-identity-1780                                              3m6s ago       never        0       no error   
  resolve-identity-2199                                              14s ago        never        0       no error   
  resolve-identity-3030                                              3m6s ago       never        0       no error   
  resolve-identity-3860                                              1m34s ago      never        0       no error   
  resolve-identity-4059                                              3m7s ago       never        0       no error   
  resolve-identity-409                                               3m8s ago       never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-ngz88                5m14s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-wqh2h               5m14s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-x4t7h       5m13s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-5f7c67789-2td27   6m34s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-p2mr5                8m6s ago       never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-t5p4l                8m6s ago       never        0       no error   
  sync-lb-maps-with-k8s-services                                     8m8s ago       never        0       no error   
  sync-policymap-1479                                                5m13s ago      never        0       no error   
  sync-policymap-149                                                 5m14s ago      never        0       no error   
  sync-policymap-1780                                                8m3s ago       never        0       no error   
  sync-policymap-2199                                                5m14s ago      never        0       no error   
  sync-policymap-3030                                                8m3s ago       never        0       no error   
  sync-policymap-3860                                                6m34s ago      never        0       no error   
  sync-policymap-4059                                                8m3s ago       never        0       no error   
  sync-policymap-409                                                 8m7s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1479)                                  13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (149)                                   4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (1780)                                  6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2199)                                  4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3030)                                  6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3860)                                  4s ago         never        0       no error   
  sync-utime                                                         8s ago         never        0       no error   
  write-cni-file                                                     8m11s ago      never        0       no error   
Proxy Status:            OK, ip 10.5.0.219, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 393216, max 458751
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 25.30   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```
