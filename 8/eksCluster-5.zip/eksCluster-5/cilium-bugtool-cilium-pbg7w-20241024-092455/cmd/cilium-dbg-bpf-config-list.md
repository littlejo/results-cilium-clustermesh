KEY             VALUE
AgentLiveness   532474771068
UTimeOffset     3378440224609375
