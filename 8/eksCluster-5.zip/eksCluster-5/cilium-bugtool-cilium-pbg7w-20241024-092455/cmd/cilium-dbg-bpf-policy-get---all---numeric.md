Endpoint ID: 149
Path: /sys/fs/bpf/tc/globals/cilium_policy_00149

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 409
Path: /sys/fs/bpf/tc/globals/cilium_policy_00409

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1479
Path: /sys/fs/bpf/tc/globals/cilium_policy_01479

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4408     33        0        
Allow    Ingress     1          ANY          NONE         disabled    301518   3516      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1780
Path: /sys/fs/bpf/tc/globals/cilium_policy_01780

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    9609    98        0        
Allow    Ingress     1          ANY          NONE         disabled    43532   499       0        
Allow    Egress      0          ANY          NONE         disabled    13156   132       0        


Endpoint ID: 2199
Path: /sys/fs/bpf/tc/globals/cilium_policy_02199

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3030
Path: /sys/fs/bpf/tc/globals/cilium_policy_03030

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    9257    96        0        
Allow    Ingress     1          ANY          NONE         disabled    44126   508       0        
Allow    Egress      0          ANY          NONE         disabled    13771   138       0        


Endpoint ID: 3860
Path: /sys/fs/bpf/tc/globals/cilium_policy_03860

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    223059   2082      0        
Allow    Ingress     1          ANY          NONE         disabled    197686   2047      0        
Allow    Egress      0          ANY          NONE         disabled    228751   2153      0        


Endpoint ID: 4059
Path: /sys/fs/bpf/tc/globals/cilium_policy_04059

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23768   296       0        
Allow    Ingress     1          ANY          NONE         disabled    6454    73        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


