CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode50d32e5_0ac3_408e_9490_ce8a24332076.slice/cri-containerd-16ddce83d010ccfe60457e73f29b646a2a9a3cd285aabfa695dd266d575fbade.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode50d32e5_0ac3_408e_9490_ce8a24332076.slice/cri-containerd-ce83f3a1cf197bf586e92236e87570afcbce621e5f7b4d88cb7efc4880e188cf.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeeb0ec4_677a_472d_bedc_60039842c243.slice/cri-containerd-bee1fcacceb93c5c3371d9f9378d8416dd573f9a91ac06f28d07e663b769de98.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeeb0ec4_677a_472d_bedc_60039842c243.slice/cri-containerd-fa3c5767056d002fe72a8b02046b76410a23ad17a640ab0f446cd008624c4659.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9eaabf92_6d3b_42cd_9b6f_510ab538897a.slice/cri-containerd-628f0b7fe996eb8d743fbb4b139f319413a846cddff38bab75845afd59f4db74.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9eaabf92_6d3b_42cd_9b6f_510ab538897a.slice/cri-containerd-0c4ee68099f310a9c5f67c66018c8c388e29f6d8bb640cab64a16f6bdfbb1cd1.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbe16600_dc94_479c_a847_74cbd8244a15.slice/cri-containerd-7b5ebf03193447aa14ffc8e8842d99ba7ce92180bed743ae83abcf312c975aa2.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbe16600_dc94_479c_a847_74cbd8244a15.slice/cri-containerd-8fae3f75be1e40765803d4c3b8394508d66a498ad7b6f926b5b970a688cd772e.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ab602ed_b213_4514_ab47_9215f50a7229.slice/cri-containerd-a69ca5affdce60b9401f2bb54ef9de843925021a7f458e32682676521845540d.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ab602ed_b213_4514_ab47_9215f50a7229.slice/cri-containerd-5c3b4e4614aa83a99a999fc635e8999534917396a71ae0786eb69ce1b12da4ac.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c44e1af_11c9_48e3_bf0b_4c5b3d177862.slice/cri-containerd-4188486cf12c220ddbbb56c39f218aeb52e9ba43d46038a461138373ba0646a3.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c44e1af_11c9_48e3_bf0b_4c5b3d177862.slice/cri-containerd-12a07de4131ae352c1c5cfcaea030c5b8cf444523e5e19acfea134db55904c2a.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod839b3996_9fb8_4b31_a805_5f6d09f77822.slice/cri-containerd-fec2ff9dacf78dc52b01c9ebc449fc4a5eb50dd0c313b30e6e911c85ac7ee419.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod839b3996_9fb8_4b31_a805_5f6d09f77822.slice/cri-containerd-84c23041be13badf964cd487d2314aca607c8df430dc12b6e93a39a18c970fe4.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-c6d5bcbc1e15eee38302a2046b394a311cad851e228e4a02128356d8985c4324.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-b12c606b13279ba39cc0676d92d454235234edd880536c32c4b0cdcf1dc4d575.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-411ac17c1b814ba7291da690e673a43b6a2560a03cc381fae3add5c044619d2b.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-1698ad7f3e524b3cbe1ad484a5deaaa8f2dc08775c8727a1023fbc310dc34bf0.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72e783f9_4063_4f25_9f9f_f3b9b2efdcb4.slice/cri-containerd-0a21f053fe5afe6a7fa7b38829707c7747a8bf35fa4c01d9646eacecf97f437a.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72e783f9_4063_4f25_9f9f_f3b9b2efdcb4.slice/cri-containerd-30fc90debb51c6f3afdbfc4dd47086298482ce65aba7ad2cb87ab9be198c8552.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5ba55d4_bc4e_4f8d_a546_62fe6d7b869f.slice/cri-containerd-173287ffe145df73a9a0a600bc13695181f01e0545d2c4a7d101b38454d7b07e.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5ba55d4_bc4e_4f8d_a546_62fe6d7b869f.slice/cri-containerd-b82abd4ea81e663a46736212d5befb81123184eaba62cfc91b471b5702216159.scope
    685      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5ba55d4_bc4e_4f8d_a546_62fe6d7b869f.slice/cri-containerd-d426770335e606c19f7440ac3a9c96caa8b269f753cecd6e02c28238a463aa93.scope
    677      cgroup_device   multi                                          
