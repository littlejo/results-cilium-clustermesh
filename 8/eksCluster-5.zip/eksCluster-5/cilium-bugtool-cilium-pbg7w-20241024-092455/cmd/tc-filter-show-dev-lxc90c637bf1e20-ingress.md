filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc90c637bf1e20 direct-action not_in_hw id 486 tag 617e12ebbaa7cf22 jited 
