[
  {
    "containers": [
      {
        "cgroup-id": 6658,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbbe16600_dc94_479c_a847_74cbd8244a15.slice/cri-containerd-7b5ebf03193447aa14ffc8e8842d99ba7ce92180bed743ae83abcf312c975aa2.scope"
      }
    ],
    "ips": [
      "10.5.0.226"
    ],
    "name": "coredns-586b798467-p2mr5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8086,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-411ac17c1b814ba7291da690e673a43b6a2560a03cc381fae3add5c044619d2b.scope"
      },
      {
        "cgroup-id": 8170,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-1698ad7f3e524b3cbe1ad484a5deaaa8f2dc08775c8727a1023fbc310dc34bf0.scope"
      },
      {
        "cgroup-id": 8254,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0868fdb9_72b4_401e_8fda_595d63421e17.slice/cri-containerd-c6d5bcbc1e15eee38302a2046b394a311cad851e228e4a02128356d8985c4324.scope"
      }
    ],
    "ips": [
      "10.5.0.83"
    ],
    "name": "clustermesh-apiserver-5f7c67789-2td27",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8758,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7ab602ed_b213_4514_ab47_9215f50a7229.slice/cri-containerd-5c3b4e4614aa83a99a999fc635e8999534917396a71ae0786eb69ce1b12da4ac.scope"
      }
    ],
    "ips": [
      "10.5.0.160"
    ],
    "name": "client2-57cf4468f-wqh2h",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6742,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode50d32e5_0ac3_408e_9490_ce8a24332076.slice/cri-containerd-ce83f3a1cf197bf586e92236e87570afcbce621e5f7b4d88cb7efc4880e188cf.scope"
      }
    ],
    "ips": [
      "10.5.0.187"
    ],
    "name": "coredns-586b798467-t5p4l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8842,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod839b3996_9fb8_4b31_a805_5f6d09f77822.slice/cri-containerd-fec2ff9dacf78dc52b01c9ebc449fc4a5eb50dd0c313b30e6e911c85ac7ee419.scope"
      }
    ],
    "ips": [
      "10.5.0.38"
    ],
    "name": "client-974f6c69d-ngz88",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 9010,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5ba55d4_bc4e_4f8d_a546_62fe6d7b869f.slice/cri-containerd-173287ffe145df73a9a0a600bc13695181f01e0545d2c4a7d101b38454d7b07e.scope"
      },
      {
        "cgroup-id": 9094,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5ba55d4_bc4e_4f8d_a546_62fe6d7b869f.slice/cri-containerd-b82abd4ea81e663a46736212d5befb81123184eaba62cfc91b471b5702216159.scope"
      }
    ],
    "ips": [
      "10.5.0.244"
    ],
    "name": "echo-same-node-86d9cc975c-x4t7h",
    "namespace": "cilium-test-1"
  }
]

