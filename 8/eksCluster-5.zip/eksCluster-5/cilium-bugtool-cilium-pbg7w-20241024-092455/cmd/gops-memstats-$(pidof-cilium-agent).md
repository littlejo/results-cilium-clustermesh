alloc: 68.55MB (71884344 bytes)
total-alloc: 1.43GB (1533796080 bytes)
sys: 108.55MB (113823028 bytes)
lookups: 0
mallocs: 46504782
frees: 45929409
heap-alloc: 68.55MB (71884344 bytes)
heap-sys: 93.30MB (97828864 bytes)
heap-idle: 12.88MB (13500416 bytes)
heap-in-use: 80.42MB (84328448 bytes)
heap-released: 4.21MB (4415488 bytes)
heap-objects: 575373
stack-in-use: 6.66MB (6979584 bytes)
stack-sys: 6.66MB (6979584 bytes)
stack-mspan-inuse: 1.15MB (1209120 bytes)
stack-mspan-sys: 1.21MB (1272960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 737.77KB (755481 bytes)
gc-sys: 4.72MB (4952600 bytes)
next-gc: when heap-alloc >= 81.40MB (85351288 bytes)
last-gc: 2024-10-24 09:24:37.079785339 +0000 UTC
gc-pause-total: 8.973131ms
gc-pause: 68314
gc-pause-end: 1729761877079785339
num-gc: 77
num-forced-gc: 0
gc-cpu-fraction: 0.0008580216778542097
enable-gc: true
debug-gc: false
