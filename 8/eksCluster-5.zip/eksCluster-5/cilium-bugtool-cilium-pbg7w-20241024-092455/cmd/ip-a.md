1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 12:cf:9a:37:81:39 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.249.188/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3109sec preferred_lft 3109sec
    inet6 fe80::10cf:9aff:fe37:8139/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:cc:25:5d:6e:ad brd ff:ff:ff:ff:ff:ff
    inet6 fe80::10cc:25ff:fe5d:6ead/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:a3:14:f5:1e:ab brd ff:ff:ff:ff:ff:ff
    inet 10.5.0.219/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::98a3:14ff:fef5:1eab/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:6f:d4:1b:75:bc brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c6f:d4ff:fe1b:75bc/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:ae:6c:5b:4a:88 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8ae:6cff:fe5b:4a88/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc90c637bf1e20@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:29:61:e6:c8:14 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b029:61ff:fee6:c814/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcff94c5b195f7@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:31:43:a7:54:6b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5031:43ff:fea7:546b/64 scope link 
       valid_lft forever preferred_lft forever
15: lxca191ee3a0dc6@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:b4:c7:47:7d:93 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::68b4:c7ff:fe47:7d93/64 scope link 
       valid_lft forever preferred_lft forever
17: lxce16936516473@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:05:08:ea:33:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::5:8ff:feea:33b9/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc2afe08556c18@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:72:67:1b:60:2c brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::7472:67ff:fe1b:602c/64 scope link 
       valid_lft forever preferred_lft forever
21: lxcded33390d67f@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:e8:0a:38:40:60 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d8e8:aff:fe38:4060/64 scope link 
       valid_lft forever preferred_lft forever
