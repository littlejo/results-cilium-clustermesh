Node 0, zone      DMA      5      6      4      4     10      9      8      7      6      6    222 
Node 0, zone   Normal      2     63    150     77     40     17      6      2      2      1      9 
