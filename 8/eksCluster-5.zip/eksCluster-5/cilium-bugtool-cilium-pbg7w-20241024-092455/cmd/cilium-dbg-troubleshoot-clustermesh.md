Found 7 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.27.127
     ✅ TCP connection successfully established to 10.100.27.127:2379
     ✅ TLS connection successfully established to 10.100.27.127:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d3:20:e8:c9:7a:06:4e:6d:dd:f2:a6:db:9d:df:cf:ba
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:39 +0000 UTC
          Not after:   2027-10-24 09:16:39 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       64:86:72:f3:1d:55:b4:6c:bd:df:64:1d:38:db:1c:d2:c1:5f:20:c3
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 41872c21071c9da8
