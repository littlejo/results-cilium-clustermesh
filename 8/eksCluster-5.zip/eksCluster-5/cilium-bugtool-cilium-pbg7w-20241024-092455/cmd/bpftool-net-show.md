xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 503
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 497
cilium_host(4) clsact/egress cil_from_host-cilium_host id 496
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 443
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 519
lxc90c637bf1e20(9) clsact/ingress cil_from_container-lxc90c637bf1e20 id 486
lxcff94c5b195f7(11) clsact/ingress cil_from_container-lxcff94c5b195f7 id 491
lxca191ee3a0dc6(15) clsact/ingress cil_from_container-lxca191ee3a0dc6 id 587
lxce16936516473(17) clsact/ingress cil_from_container-lxce16936516473 id 3676
lxc2afe08556c18(19) clsact/ingress cil_from_container-lxc2afe08556c18 id 3687
lxcded33390d67f(21) clsact/ingress cil_from_container-lxcded33390d67f id 3375

flow_dissector:

netfilter:

