IP ADDRESS         LOCAL ENDPOINT INFO
10.5.0.83:0        id=3860  sec_id=400535 flags=0x0000 ifindex=15  mac=46:24:37:E5:21:65 nodemac=6A:B4:C7:47:7D:93   
172.31.249.188:0   (localhost)                                                                                       
10.5.0.219:0       (localhost)                                                                                       
10.5.0.160:0       id=149   sec_id=397076 flags=0x0000 ifindex=19  mac=16:1D:56:3E:A7:AB nodemac=76:72:67:1B:60:2C   
10.5.0.187:0       id=1780  sec_id=409754 flags=0x0000 ifindex=11  mac=72:66:9E:78:CF:FA nodemac=52:31:43:A7:54:6B   
10.5.0.226:0       id=3030  sec_id=409754 flags=0x0000 ifindex=9   mac=3A:2E:5B:A6:22:36 nodemac=B2:29:61:E6:C8:14   
10.5.0.80:0        id=4059  sec_id=4     flags=0x0000 ifindex=7   mac=5E:0A:54:EE:4C:78 nodemac=FA:AE:6C:5B:4A:88    
10.5.0.38:0        id=2199  sec_id=406305 flags=0x0000 ifindex=17  mac=22:A1:BD:77:41:48 nodemac=02:05:08:EA:33:B9   
10.5.0.244:0       id=1479  sec_id=395399 flags=0x0000 ifindex=21  mac=76:84:1F:BA:24:B9 nodemac=DA:E8:0A:38:40:60   
