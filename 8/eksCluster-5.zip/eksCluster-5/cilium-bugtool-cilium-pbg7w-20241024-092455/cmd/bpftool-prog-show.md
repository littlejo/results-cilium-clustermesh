29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:16:37+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:16:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:16:43+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:16:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:17:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
442: sched_cls  name tail_handle_ipv4  tag bb8e8d777d635af3  gpl
	loaded_at 2024-10-24T09:17:24+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
443: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:17:24+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:17:24+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
466: sched_cls  name tail_handle_arp  tag cd9d6cdc31ce025e  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 143
472: sched_cls  name tail_ipv4_to_endpoint  tag c994237dfbb0711b  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,97,31,100,32,29,30
	btf_id 144
474: sched_cls  name tail_ipv4_ct_egress  tag 0800433162c0bffc  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 150
477: sched_cls  name tail_ipv4_ct_ingress  tag 79d0191adb65654d  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,101,76
	btf_id 152
479: sched_cls  name tail_handle_ipv4  tag 9be26c5ba9fb3199  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 155
480: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 157
483: sched_cls  name handle_policy  tag 0478a79ca7623c97  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,101,33,72,97,31,76,67,32,29,30
	btf_id 158
484: sched_cls  name tail_handle_arp  tag da16f55c9d25da0c  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 162
486: sched_cls  name cil_from_container  tag 617e12ebbaa7cf22  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 163
487: sched_cls  name __send_drop_notify  tag bea065a61d35deb3  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 165
488: sched_cls  name tail_handle_ipv4_cont  tag 007fed1b443f0076  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 164
489: sched_cls  name tail_handle_ipv4_cont  tag 437b355067e72a9b  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 166
490: sched_cls  name tail_ipv4_ct_egress  tag 0800433162c0bffc  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 167
491: sched_cls  name cil_from_container  tag 106b6d839ba0d9bd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 170
494: sched_cls  name tail_handle_ipv4_from_host  tag 2b22c8592607e15e  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,105
	btf_id 173
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,105
	btf_id 174
496: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,105
	btf_id 175
497: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 176
498: sched_cls  name __send_drop_notify  tag d789b9d5e9b36be9  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 177
500: sched_cls  name tail_handle_ipv4_from_host  tag 2b22c8592607e15e  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 180
501: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 181
503: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 183
504: sched_cls  name __send_drop_notify  tag d789b9d5e9b36be9  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 184
506: sched_cls  name __send_drop_notify  tag d789b9d5e9b36be9  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
507: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 188
509: sched_cls  name handle_policy  tag 82c329430ac41aa9  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 172
510: sched_cls  name tail_handle_ipv4_from_host  tag 2b22c8592607e15e  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 190
511: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 192
514: sched_cls  name tail_handle_ipv4  tag 15e4d7b5fa22cad3  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,111
	btf_id 196
515: sched_cls  name tail_handle_ipv4_cont  tag 34ab4a9efb66e27e  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,112,33,90,74,75,31,68,66,69,111,32,29,30,73
	btf_id 197
516: sched_cls  name tail_ipv4_ct_ingress  tag fe0f75f4876bf5aa  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 198
517: sched_cls  name __send_drop_notify  tag 6d4b5745abb1a945  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 199
518: sched_cls  name tail_handle_ipv4  tag 098d2d84a89abd83  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 191
519: sched_cls  name cil_from_container  tag 7857eef5c73632c1  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 111,68
	btf_id 200
520: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 201
522: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,111,74,75,112,76
	btf_id 203
523: sched_cls  name tail_ipv4_ct_ingress  tag 914b836fc0305cf2  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 204
524: sched_cls  name __send_drop_notify  tag 729a4cafe1606886  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 205
525: sched_cls  name tail_ipv4_to_endpoint  tag da40769fe7ba1df0  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 207
526: sched_cls  name handle_policy  tag 5848323f6848a2c7  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,111,74,75,112,33,72,90,31,76,67,32,29,30
	btf_id 206
527: sched_cls  name tail_ipv4_to_endpoint  tag 5e82790fec209925  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,112,33,74,75,72,90,31,111,32,29,30
	btf_id 208
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,111
	btf_id 209
529: sched_cls  name tail_handle_arp  tag 7fd9a544cb294088  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,111
	btf_id 210
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
542: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
543: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_ipv4_cont  tag 854e3590b219ed42  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 227
587: sched_cls  name cil_from_container  tag 631ed458b59c102c  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 228
588: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 229
589: sched_cls  name tail_ipv4_ct_ingress  tag 7397faf362bc5f7f  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 230
590: sched_cls  name handle_policy  tag bfd7d926227d70fc  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 231
591: sched_cls  name __send_drop_notify  tag 0a23268b86e46c9a  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 232
592: sched_cls  name tail_ipv4_ct_egress  tag 7ad9dd354b157b50  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 233
594: sched_cls  name tail_ipv4_to_endpoint  tag bba20a2108662829  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 235
595: sched_cls  name tail_handle_arp  tag 632c989b60fc9389  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 236
596: sched_cls  name tail_handle_ipv4  tag 37ff983a3d6217d1  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 237
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
669: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
672: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
682: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
685: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3370: sched_cls  name tail_ipv4_ct_ingress  tag fa2a802627b7093d  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,641,74,75,642,76
	btf_id 3203
3371: sched_cls  name tail_handle_ipv4_cont  tag e59c15b4b35a441e  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,642,33,145,74,75,31,68,66,69,641,32,29,30,73
	btf_id 3204
3372: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,641
	btf_id 3205
3373: sched_cls  name handle_policy  tag 6d91c21bf2310207  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,641,74,75,642,33,72,145,31,76,67,32,29,30
	btf_id 3206
3374: sched_cls  name tail_handle_ipv4  tag 383b47f1c6143143  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,641
	btf_id 3207
3375: sched_cls  name cil_from_container  tag 30300411a495d4b5  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 641,68
	btf_id 3208
3376: sched_cls  name tail_handle_arp  tag 40390d41f7a8493f  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,641
	btf_id 3209
3378: sched_cls  name tail_ipv4_ct_egress  tag d48cc1f1691d0427  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,641,74,75,642,76
	btf_id 3211
3379: sched_cls  name __send_drop_notify  tag 0b5cc941c5589cf5  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3212
3380: sched_cls  name tail_ipv4_to_endpoint  tag 11153fb233f393ef  gpl
	loaded_at 2024-10-24T09:23:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,642,33,74,75,72,145,31,641,32,29,30
	btf_id 3213
3667: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,697
	btf_id 3529
3668: sched_cls  name __send_drop_notify  tag 9371ab5b01a44ce6  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3530
3669: sched_cls  name tail_handle_ipv4  tag 347ce05299690cdb  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,696
	btf_id 3527
3670: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,696
	btf_id 3532
3671: sched_cls  name tail_ipv4_ct_egress  tag b6d0aa893c3b11cc  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,696,74,75,695,76
	btf_id 3533
3672: sched_cls  name tail_ipv4_ct_ingress  tag 6c880a6c03739118  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,696,74,75,695,76
	btf_id 3534
3673: sched_cls  name handle_policy  tag 2b7c4662e3ef45e5  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,697,74,75,698,33,72,137,31,76,67,32,29,30
	btf_id 3531
3674: sched_cls  name tail_handle_ipv4_cont  tag 3a6bda01c6e97eb7  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,698,33,137,74,75,31,68,66,69,697,32,29,30,73
	btf_id 3535
3675: sched_cls  name tail_ipv4_ct_ingress  tag c053760c83b11909  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,697,74,75,698,76
	btf_id 3537
3676: sched_cls  name cil_from_container  tag f250a7c5d61e601b  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 697,68
	btf_id 3538
3677: sched_cls  name tail_ipv4_to_endpoint  tag 41462c2b1cb21846  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,695,33,74,75,72,140,31,696,32,29,30
	btf_id 3536
3678: sched_cls  name tail_ipv4_to_endpoint  tag a9724f2931896333  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,698,33,74,75,72,137,31,697,32,29,30
	btf_id 3539
3679: sched_cls  name tail_handle_ipv4  tag 9f106c676e54cb7b  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,697
	btf_id 3541
3681: sched_cls  name tail_handle_arp  tag 5024f4aef68eb2ce  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,697
	btf_id 3543
3682: sched_cls  name handle_policy  tag e79534f897737fb2  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,696,74,75,695,33,72,140,31,76,67,32,29,30
	btf_id 3540
3684: sched_cls  name tail_ipv4_ct_egress  tag d58d4de5c970ce6d  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,697,74,75,698,76
	btf_id 3544
3685: sched_cls  name tail_handle_ipv4_cont  tag 375e871a60cb3ef4  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,695,33,140,74,75,31,68,66,69,696,32,29,30,73
	btf_id 3546
3686: sched_cls  name __send_drop_notify  tag 8642bc08c41d1ec1  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3547
3687: sched_cls  name cil_from_container  tag c87eb7e1eecb0c62  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 696,68
	btf_id 3548
3688: sched_cls  name tail_handle_arp  tag f1e09fcc2d8214d6  gpl
	loaded_at 2024-10-24T09:24:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,696
	btf_id 3549
