 09:24:57 up 8 min,  0 users,  load average: 0.15, 0.50, 0.32
