key: 05 00 00 00  value: 0a 05 00 bb 00 35 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 05 00 f4 1f 90 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 05 00 bb 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 05 00 53 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f9 bc 10 94 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 05 00 e2 00 35 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 05 00 e2 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b8 e0 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: ac 1f d5 81 01 bb 00 00  00 00 00 00
Found 9 elements
