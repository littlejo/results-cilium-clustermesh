35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:15:14+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:15+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:15:19+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:15:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
458: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
461: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
462: sched_cls  name tail_handle_ipv4  tag 3ceea741d1dd7a2b  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 124
463: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 125
464: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
465: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 127
466: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
469: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: sched_cls  name tail_ipv4_ct_ingress  tag fbb0974a91a54010  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 154
493: sched_cls  name cil_from_container  tag 370671b2b7fe2460  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 102,68
	btf_id 155
494: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,102
	btf_id 156
495: sched_cls  name tail_handle_ipv4  tag 0904934510814a70  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,102
	btf_id 157
496: sched_cls  name __send_drop_notify  tag 62f7eb4344a4c67a  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 158
497: sched_cls  name tail_handle_arp  tag d9c3a89ac83fe2ab  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,102
	btf_id 159
498: sched_cls  name tail_ipv4_to_endpoint  tag 8a6246c832c0e0d9  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,101,33,74,75,72,83,31,102,32,29,30
	btf_id 160
499: sched_cls  name tail_ipv4_ct_egress  tag 6ce64708d1fdcb7a  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,102,74,75,101,76
	btf_id 161
500: sched_cls  name tail_handle_ipv4_cont  tag 8fe7ad81ce88030a  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,101,33,83,74,75,31,68,66,69,102,32,29,30,73
	btf_id 162
501: sched_cls  name handle_policy  tag 5cdc8e1b8b6ef632  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,102,74,75,101,33,72,83,31,76,67,32,29,30
	btf_id 163
504: sched_cls  name __send_drop_notify  tag feee1f37f81cb957  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 167
505: sched_cls  name tail_handle_ipv4  tag 54b36b6bda885545  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,103
	btf_id 168
506: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,103
	btf_id 169
507: sched_cls  name handle_policy  tag 54d83758ac068d46  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,103,74,75,104,33,72,94,31,76,67,32,29,30
	btf_id 170
508: sched_cls  name tail_handle_arp  tag 7333850c8b109a4a  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,103
	btf_id 171
509: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 172
510: sched_cls  name cil_from_container  tag be2682dbf83bd053  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 103,68
	btf_id 173
511: sched_cls  name tail_ipv4_to_endpoint  tag 7d22c13eb6764c69  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,104,33,74,75,72,94,31,103,32,29,30
	btf_id 174
512: sched_cls  name tail_ipv4_ct_ingress  tag 181ab885b0a802f3  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,103,74,75,104,76
	btf_id 175
513: sched_cls  name tail_handle_ipv4_cont  tag 666ae67281b4d553  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,104,33,94,74,75,31,68,66,69,103,32,29,30,73
	btf_id 176
514: sched_cls  name tail_handle_ipv4  tag 8b5d9dd928342ab0  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 178
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 179
516: sched_cls  name tail_handle_ipv4_cont  tag 34fc87bb807233d4  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,106,33,95,74,75,31,68,66,69,105,32,29,30,73
	btf_id 180
517: sched_cls  name tail_ipv4_to_endpoint  tag 5435bfd0201af77f  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,106,33,74,75,72,95,31,105,32,29,30
	btf_id 181
518: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
521: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
522: sched_cls  name tail_ipv4_ct_egress  tag 6ce64708d1fdcb7a  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 182
524: sched_cls  name tail_ipv4_ct_ingress  tag 5d4ca63985d32e58  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 184
525: sched_cls  name tail_handle_arp  tag 4fbb67dd5b4eb396  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 185
526: sched_cls  name handle_policy  tag 05cdf7fab2bdcbc0  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,105,74,75,106,33,72,95,31,76,67,32,29,30
	btf_id 186
527: sched_cls  name __send_drop_notify  tag ecd7e6d8e3fbf53c  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
528: sched_cls  name cil_from_container  tag d141947cadf5de05  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,68
	btf_id 188
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,109
	btf_id 190
534: sched_cls  name tail_handle_ipv4_from_host  tag 47538b5cc6aacf26  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 191
535: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 192
537: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 194
538: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 195
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 198
542: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 200
543: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,111
	btf_id 201
546: sched_cls  name tail_handle_ipv4_from_host  tag 47538b5cc6aacf26  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,111
	btf_id 204
547: sched_cls  name tail_handle_ipv4_from_host  tag 47538b5cc6aacf26  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,113
	btf_id 206
549: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,113,67
	btf_id 208
550: sched_cls  name __send_drop_notify  tag 3f5d89d958ded1ad  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 209
551: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:17+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,113
	btf_id 210
593: sched_cls  name handle_policy  tag c5d968cf905683a4  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,127,74,75,126,33,72,125,31,76,67,32,29,30
	btf_id 227
594: sched_cls  name tail_handle_ipv4  tag 3a6e9e434465ea5a  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,127
	btf_id 228
595: sched_cls  name tail_ipv4_ct_ingress  tag 0abf8d0e4e16cfec  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 229
596: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,127
	btf_id 230
597: sched_cls  name tail_ipv4_ct_egress  tag fb1e0c7e3dda8690  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,127,74,75,126,76
	btf_id 231
598: sched_cls  name tail_handle_ipv4_cont  tag bd8554016fbd337e  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,126,33,125,74,75,31,68,66,69,127,32,29,30,73
	btf_id 232
599: sched_cls  name __send_drop_notify  tag 4c86549455954cf8  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 233
600: sched_cls  name tail_ipv4_to_endpoint  tag ab29640ef985c1d7  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,126,33,74,75,72,125,31,127,32,29,30
	btf_id 234
602: sched_cls  name tail_handle_arp  tag 80721702c23ab37b  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,127
	btf_id 236
603: sched_cls  name cil_from_container  tag 7cac2f0dc23594a9  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 127,68
	btf_id 237
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:19:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:19:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:19:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:19:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:19:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:19:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:19:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
677: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
680: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3366: sched_cls  name __send_drop_notify  tag 0ba72223af718340  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3191
3367: sched_cls  name cil_from_container  tag f2dad93d8d87e3be  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 637,68
	btf_id 3192
3368: sched_cls  name tail_ipv4_ct_egress  tag 60ae777c0547cdf0  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,637,74,75,638,76
	btf_id 3193
3369: sched_cls  name tail_handle_arp  tag 54124a82ba114dbb  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,637
	btf_id 3194
3370: sched_cls  name tail_ipv4_ct_ingress  tag 91ab07e7ba4c8190  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,637,74,75,638,76
	btf_id 3195
3371: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,637
	btf_id 3196
3373: sched_cls  name tail_handle_ipv4  tag 3359d87fadc9666c  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,637
	btf_id 3198
3374: sched_cls  name handle_policy  tag 4f6277d9621ee6cf  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,637,74,75,638,33,72,143,31,76,67,32,29,30
	btf_id 3199
3375: sched_cls  name tail_handle_ipv4_cont  tag 2bbbeb6370aafcbb  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,638,33,143,74,75,31,68,66,69,637,32,29,30,73
	btf_id 3200
3376: sched_cls  name tail_ipv4_to_endpoint  tag 2fee17a690f1173d  gpl
	loaded_at 2024-10-24T09:23:26+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,638,33,74,75,72,143,31,637,32,29,30
	btf_id 3201
3663: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,693
	btf_id 3516
3664: sched_cls  name tail_handle_arp  tag d8f86f270f2b4c8a  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,693
	btf_id 3518
3666: sched_cls  name tail_ipv4_ct_ingress  tag 377fc34fbd4cbb8a  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,693,74,75,692,76
	btf_id 3520
3667: sched_cls  name __send_drop_notify  tag b0a42f1c05825264  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3521
3668: sched_cls  name handle_policy  tag a4d7730c69a21882  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,691,74,75,694,33,72,138,31,76,67,32,29,30
	btf_id 3517
3670: sched_cls  name handle_policy  tag dedf17a088638f89  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,693,74,75,692,33,72,135,31,76,67,32,29,30
	btf_id 3522
3671: sched_cls  name tail_handle_ipv4  tag 0e53cbb5462b81df  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,691
	btf_id 3524
3672: sched_cls  name tail_handle_arp  tag 8d5f27547a5ada2d  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,691
	btf_id 3526
3673: sched_cls  name tail_handle_ipv4_cont  tag 72c21fd41f68017e  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,692,33,135,74,75,31,68,66,69,693,32,29,30,73
	btf_id 3525
3674: sched_cls  name cil_from_container  tag 51d948d590cd5aef  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 693,68
	btf_id 3528
3675: sched_cls  name tail_handle_ipv4  tag 05a84eacd1f9665a  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,693
	btf_id 3529
3676: sched_cls  name tail_ipv4_to_endpoint  tag 6dfb0de86393fb49  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,694,33,74,75,72,138,31,691,32,29,30
	btf_id 3527
3677: sched_cls  name tail_ipv4_ct_egress  tag 6836e2bc5f33f814  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,694,76
	btf_id 3531
3678: sched_cls  name tail_ipv4_ct_egress  tag ea62bd1470178c6e  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,693,74,75,692,76
	btf_id 3530
3679: sched_cls  name tail_ipv4_ct_ingress  tag 91abdb1ca2ac03cb  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,694,76
	btf_id 3532
3680: sched_cls  name tail_ipv4_to_endpoint  tag fbdb2c0145273274  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,692,33,74,75,72,135,31,693,32,29,30
	btf_id 3533
3681: sched_cls  name tail_handle_ipv4_cont  tag e153090ae3d2be73  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,694,33,138,74,75,31,68,66,69,691,32,29,30,73
	btf_id 3534
3682: sched_cls  name __send_drop_notify  tag 6071ab8bcf795dc3  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3535
3683: sched_cls  name cil_from_container  tag f1d4bbda34c88753  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 691,68
	btf_id 3536
3684: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:51+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,691
	btf_id 3537
