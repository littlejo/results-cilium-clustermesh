# Cilium debug information

#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.7.0.0/24, 
Allocated addresses:
  10.7.0.104 (kube-system/coredns-586b798467-dqsrq)
  10.7.0.123 (health)
  10.7.0.141 (cilium-test-1/client-974f6c69d-c7cc6)
  10.7.0.201 (cilium-test-1/echo-same-node-86d9cc975c-49kk9)
  10.7.0.228 (kube-system/coredns-586b798467-hlzgr)
  10.7.0.6 (cilium-test-1/client2-57cf4468f-gwqrv)
  10.7.0.78 (kube-system/clustermesh-apiserver-64fff5c868-86dnl)
  10.7.0.95 (router)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m19s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    14s ago        never        0       no error   
  ct-map-pressure                                                     16s ago        never        0       no error   
  daemon-validate-config                                              7s ago         never        0       no error   
  dns-garbage-collector-job                                           21s ago        never        0       no error   
  endpoint-119-regeneration-recovery                                  never          never        0       no error   
  endpoint-1673-regeneration-recovery                                 never          never        0       no error   
  endpoint-1842-regeneration-recovery                                 never          never        0       no error   
  endpoint-189-regeneration-recovery                                  never          never        0       no error   
  endpoint-2953-regeneration-recovery                                 never          never        0       no error   
  endpoint-410-regeneration-recovery                                  never          never        0       no error   
  endpoint-83-regeneration-recovery                                   never          never        0       no error   
  endpoint-851-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m21s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                16s ago        never        0       no error   
  ipcache-inject-labels                                               16s ago        never        0       no error   
  k8s-heartbeat                                                       1s ago         never        0       no error   
  link-cache                                                          1s ago         never        0       no error   
  local-identity-checkpoint                                           33s ago        never        0       no error   
  node-neighbor-link-updater                                          6s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m19s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m19s ago      never        0       no error   
  resolve-identity-119                                                4m16s ago      never        0       no error   
  resolve-identity-1673                                               11s ago        never        0       no error   
  resolve-identity-1842                                               4m15s ago      never        0       no error   
  resolve-identity-189                                                1m24s ago      never        0       no error   
  resolve-identity-2953                                               11s ago        never        0       no error   
  resolve-identity-410                                                4m16s ago      never        0       no error   
  resolve-identity-83                                                 4m16s ago      never        0       no error   
  resolve-identity-851                                                9s ago         never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-c7cc6                 5m11s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-gwqrv                5m11s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-49kk9        5m9s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-64fff5c868-86dnl   6m24s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-dqsrq                 9m16s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-hlzgr                 9m16s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      9m16s ago      never        0       no error   
  sync-policymap-119                                                  9m15s ago      never        0       no error   
  sync-policymap-1673                                                 5m11s ago      never        0       no error   
  sync-policymap-1842                                                 9m10s ago      never        0       no error   
  sync-policymap-189                                                  6m24s ago      never        0       no error   
  sync-policymap-2953                                                 5m11s ago      never        0       no error   
  sync-policymap-410                                                  9m10s ago      never        0       no error   
  sync-policymap-83                                                   9m14s ago      never        0       no error   
  sync-policymap-851                                                  5m9s ago       never        0       no error   
  sync-to-k8s-ciliumendpoint (1673)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (189)                                    4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2953)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (410)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (83)                                     6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (851)                                    9s ago         never        0       no error   
  sync-utime                                                          16s ago        never        0       no error   
  write-cni-file                                                      9m21s ago      never        0       no error   
Proxy Status:            OK, ip 10.7.0.95, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 524288, max 589823
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 22.66   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
bpf-lb-source-range-map-max:0
dns-max-ips-per-restored-rule:1000
enable-recorder:false
enable-wireguard-userspace-fallback:false
enable-auto-protect-node-port-range:true
restore:true
enable-local-node-route:true
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
clustermesh-enable-endpoint-sync:false
nat-map-stats-entries:32
multicast-enabled:false
synchronize-k8s-nodes:true
use-full-tls-context:false
tofqdns-proxy-port:0
bpf-filter-priority:1
cmdref:
state-dir:/var/run/cilium
pprof:false
mesh-auth-queue-size:1024
agent-health-port:9879
enable-l7-proxy:true
enable-ipsec-xfrm-state-caching:true
cilium-endpoint-gc-interval:5m0s
enable-cilium-health-api-server-access:
bpf-lb-service-backend-map-max:0
vtep-cidr:
enable-ipsec-encrypted-overlay:false
enable-ipv4:true
enable-mke:false
hubble-redact-enabled:false
enable-sctp:false
l2-announcements-retry-period:2s
set-cilium-is-up-condition:true
kube-proxy-replacement:false
http-normalize-path:true
fixed-identity-mapping:
local-router-ipv6:
enable-k8s-endpoint-slice:true
dnsproxy-lock-count:131
hubble-drop-events-interval:2m0s
enable-ipv6:false
cni-log-file:/var/run/cilium/cilium-cni.log
enable-node-selector-labels:false
enable-bgp-control-plane:false
k8s-client-burst:20
enable-host-port:false
hubble-monitor-events:
identity-heartbeat-timeout:30m0s
set-cilium-node-taints:true
enable-envoy-config:false
encrypt-node:false
bpf-neigh-global-max:524288
tofqdns-pre-cache:
iptables-random-fully:false
ipsec-key-rotation-duration:5m0s
node-port-mode:snat
ipv6-native-routing-cidr:
prometheus-serve-addr:
policy-cidr-match-mode:
log-opt:
vtep-mac:
ipv4-native-routing-cidr:
l2-pod-announcements-interface:
enable-health-check-nodeport:true
agent-liveness-update-interval:1s
controller-group-metrics:
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-acceleration:disabled
use-cilium-internal-ip-for-ipsec:false
bpf-lb-rev-nat-map-max:0
bpf-ct-timeout-regular-tcp-syn:1m0s
envoy-base-id:0
enable-identity-mark:true
enable-well-known-identities:false
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-ipv6-masquerade:true
hubble-export-denylist:
hubble-socket-path:/var/run/cilium/hubble.sock
config-sources:config-map:kube-system/cilium-config
endpoint-queue-size:25
tofqdns-idle-connection-grace-period:0s
enable-metrics:true
k8s-client-connection-keep-alive:30s
bpf-ct-timeout-regular-tcp:2h13m20s
cluster-id:8
enable-ip-masq-agent:false
debug-verbose:
labels:
tunnel-port:0
nodes-gc-interval:5m0s
enable-node-port:false
pprof-port:6060
tofqdns-max-deferred-connection-deletes:10000
enable-stale-cilium-endpoint-cleanup:true
tofqdns-dns-reject-response-code:refused
clustermesh-ip-identities-sync-timeout:1m0s
bypass-ip-availability-upon-restore:false
api-rate-limit:
k8s-namespace:kube-system
bpf-ct-timeout-regular-any:1m0s
operator-api-serve-addr:127.0.0.1:9234
kube-proxy-replacement-healthz-bind-address:
bgp-announce-pod-cidr:false
enable-endpoint-routes:false
k8s-client-qps:10
ipv4-service-loopback-address:169.254.42.1
clustermesh-config:/var/lib/cilium/clustermesh/
devices:
node-labels:
dnsproxy-concurrency-processing-grace-period:0s
bpf-ct-timeout-service-tcp-grace:1m0s
endpoint-bpf-prog-watchdog-interval:30s
enable-l2-pod-announcements:false
clustermesh-enable-mcs-api:false
enable-ipv4-masquerade:true
route-metric:0
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
tofqdns-min-ttl:0
enable-gateway-api:false
tofqdns-endpoint-max-ip-per-hostname:50
enable-srv6:false
local-max-addr-scope:252
enable-route-mtu-for-cni-chaining:false
enable-health-check-loadbalancer-ip:false
enable-hubble-recorder-api:true
trace-sock:true
vlan-bpf-bypass:
bpf-lb-external-clusterip:false
bpf-lb-sock-hostns-only:false
annotate-k8s-node:false
gateway-api-secrets-namespace:
kvstore-periodic-sync:5m0s
preallocate-bpf-maps:false
mesh-auth-mutual-connect-timeout:5s
bpf-lb-service-map-max:0
enable-ipv4-fragment-tracking:true
proxy-portrange-min:10000
enable-ipv6-ndp:false
join-cluster:false
identity-change-grace-period:5s
dnsproxy-concurrency-limit:0
identity-restore-grace-period:30s
egress-masquerade-interfaces:ens+
enable-nat46x64-gateway:false
hubble-flowlogs-config-path:
ingress-secrets-namespace:
hubble-export-fieldmask:
bpf-lb-mode:snat
proxy-xff-num-trusted-hops-ingress:0
allocator-list-timeout:3m0s
k8s-require-ipv4-pod-cidr:false
log-driver:
disable-envoy-version-check:false
nodeport-addresses:
hubble-listen-address::4244
keep-config:false
dnsproxy-insecure-skip-transparent-mode-check:false
clustermesh-sync-timeout:1m0s
cni-exclusive:true
ipv4-range:auto
cflags:
bpf-map-dynamic-size-ratio:0.0025
derive-masq-ip-addr-from-device:
proxy-max-connection-duration-seconds:0
enable-host-legacy-routing:false
proxy-idle-timeout-seconds:60
l2-announcements-lease-duration:15s
hubble-redact-http-headers-deny:
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-cilium-endpoint-slice:false
enable-runtime-device-detection:true
bpf-lb-sock:false
kvstore-connectivity-timeout:2m0s
bpf-lb-maglev-map-max:0
unmanaged-pod-watcher-interval:15
ipv4-node:auto
proxy-max-requests-per-connection:0
envoy-keep-cap-netbindservice:false
max-internal-timer-delay:0s
install-no-conntrack-iptables-rules:false
enable-tcx:true
arping-refresh-period:30s
node-port-algorithm:random
encryption-strict-mode-cidr:
http-request-timeout:3600
bpf-sock-rev-map-max:262144
envoy-log:
enable-k8s-api-discovery:false
enable-cilium-api-server-access:
mesh-auth-rotated-identities-queue-size:1024
dnsproxy-lock-timeout:500ms
exclude-local-address:
force-device-detection:false
auto-direct-node-routes:false
ipam-default-ip-pool:default
enable-service-topology:false
hubble-redact-http-urlquery:false
ipv6-cluster-alloc-cidr:f00d::/64
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-events-policy-verdict-enabled:true
policy-accounting:true
mesh-auth-signal-backoff-duration:1s
lib-dir:/var/lib/cilium
kvstore-max-consecutive-quorum-errors:2
monitor-queue-size:0
bpf-lb-dsr-dispatch:opt
enable-ipv4-egress-gateway:false
procfs:/host/proc
mke-cgroup-mount:
hubble-drop-events-reasons:auth_required,policy_denied
enable-bpf-clock-probe:false
service-no-backend-response:reject
debug:false
enable-encryption-strict-mode:false
disable-external-ip-mitigation:false
hubble-export-file-compress:false
bpf-ct-timeout-regular-tcp-fin:10s
bpf-auth-map-max:524288
k8s-api-server:
pprof-address:localhost
trace-payloadlen:128
hubble-metrics:
enable-active-connection-tracking:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
node-port-acceleration:disabled
enable-custom-calls:false
mtu:0
cni-chaining-mode:none
max-controller-interval:0
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-metrics-server:
bpf-events-drop-enabled:true
exclude-node-label-patterns:
cluster-health-port:4240
cluster-pool-ipv4-cidr:10.7.0.0/16
auto-create-cilium-node-resource:true
proxy-gid:1337
k8s-heartbeat-timeout:30s
metrics:
ipv4-service-range:auto
ipam-cilium-node-update-rate:15s
k8s-client-connection-timeout:30s
install-iptables-rules:true
bpf-lb-affinity-map-max:0
monitor-aggregation:medium
bgp-announce-lb-ip:false
crd-wait-timeout:5m0s
proxy-xff-num-trusted-hops-egress:0
endpoint-gc-interval:5m0s
enable-ingress-controller:false
bpf-lb-sock-terminate-pod-connections:false
local-router-ipv4:
container-ip-local-reserved-ports:auto
bpf-node-map-max:16384
enable-local-redirect-policy:false
mesh-auth-spire-admin-socket:
node-port-bind-protection:true
mesh-auth-mutual-listener-port:0
enable-bpf-tproxy:false
k8s-kubeconfig-path:
bpf-lb-map-max:65536
cni-external-routing:false
identity-allocation-mode:crd
agent-labels:
egress-multi-home-ip-rule-compat:false
config-dir:/tmp/cilium/config-map
bpf-lb-algorithm:random
enable-icmp-rules:true
node-port-range:
label-prefix-file:
direct-routing-device:
enable-session-affinity:false
kvstore-opt:
dnsproxy-socket-linger-timeout:10
k8s-sync-timeout:3m0s
ipv6-node:auto
tofqdns-enable-dns-compression:true
wireguard-persistent-keepalive:0s
enable-ipsec-key-watcher:true
tofqdns-proxy-response-max-delay:100ms
l2-announcements-renew-deadline:5s
remove-cilium-node-taints:true
bpf-ct-timeout-service-tcp:2h13m20s
disable-endpoint-crd:false
static-cnp-path:
ipam-multi-pool-pre-allocation:
hubble-event-queue-size:0
enable-tracing:false
identity-gc-interval:15m0s
vtep-endpoint:
allow-localhost:auto
custom-cni-conf:false
policy-audit-mode:false
log-system-load:false
enable-unreachable-routes:false
hubble-redact-http-headers-allow:
hubble-export-file-max-size-mb:10
ipv6-service-range:auto
enable-k8s:true
enable-xt-socket-fallback:true
vtep-mask:
allow-icmp-frag-needed:true
kvstore-lease-ttl:15m0s
bpf-lb-maglev-table-size:16381
enable-hubble:true
bpf-lb-rss-ipv6-src-cidr:
bpf-ct-timeout-service-any:1m0s
disable-iptables-feeder-rules:
bpf-events-trace-enabled:true
enable-pmtu-discovery:false
ipv6-range:auto
k8s-service-cache-size:128
enable-host-firewall:false
routing-mode:tunnel
enable-health-checking:true
enable-l2-announcements:false
monitor-aggregation-flags:all
enable-k8s-networkpolicy:true
external-envoy-proxy:true
bpf-ct-global-any-max:262144
mesh-auth-enabled:true
enable-external-ips:false
envoy-secrets-namespace:
policy-trigger-interval:1s
bpf-policy-map-full-reconciliation-interval:15m0s
monitor-aggregation-interval:5s
hubble-recorder-sink-queue-size:1024
ipv4-pod-subnets:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
certificates-directory:/var/run/cilium/certs
hubble-event-buffer-capacity:4095
cgroup-root:/run/cilium/cgroupv2
prepend-iptables-chains:true
cluster-name:cmesh8
http-idle-timeout:0
max-connected-clusters:255
nat-map-stats-interval:30s
kvstore:
ipv6-pod-subnets:
ipsec-key-file:
enable-masquerade-to-route-source:false
hubble-redact-kafka-apikey:false
enable-k8s-terminating-endpoint:true
proxy-prometheus-port:0
enable-ipsec:false
bpf-policy-map-max:16384
config:
hubble-export-file-max-backups:5
dns-policy-unload-on-shutdown:false
conntrack-gc-max-interval:0s
enable-l2-neigh-discovery:true
enable-policy:default
srv6-encap-mode:reduced
enable-bandwidth-manager:false
enable-endpoint-health-checking:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-fragments-map-max:8192
bpf-lb-rss-ipv4-src-cidr:
read-cni-conf:
hubble-skip-unknown-cgroup-ids:true
mesh-auth-gc-interval:5m0s
hubble-redact-http-userinfo:true
encrypt-interface:
iptables-lock-timeout:5s
k8s-require-ipv6-pod-cidr:false
hubble-export-file-path:
hubble-export-allowlist:
operator-prometheus-serve-addr::9963
enable-ipip-termination:false
socket-path:/var/run/cilium/cilium.sock
encryption-strict-mode-allow-remote-node-identities:false
proxy-portrange-max:20000
hubble-prefer-ipv6:false
hubble-drop-events:false
dnsproxy-enable-transparent-mode:true
enable-vtep:false
egress-gateway-policy-map-max:16384
http-max-grpc-timeout:0
bpf-map-event-buffers:
enable-high-scale-ipcache:false
cluster-pool-ipv4-mask-size:24
http-retry-count:3
bpf-ct-global-tcp-max:524288
datapath-mode:veth
enable-monitor:true
ipam:cluster-pool
egress-gateway-reconciliation-trigger-interval:1s
enable-xdp-prefilter:false
envoy-config-retry-interval:15s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
direct-routing-skip-unreachable:false
gops-port:9890
bpf-root:/sys/fs/bpf
cni-chaining-target:
bpf-nat-global-max:524288
k8s-service-proxy-name:
tunnel-protocol:vxlan
enable-ipv4-big-tcp:false
enable-svc-source-range-check:true
http-retry-timeout:0
bgp-config-path:/var/lib/cilium/bgp/config.yaml
policy-queue-size:100
ipv6-mcast-device:
enable-ipv6-big-tcp:false
proxy-admin-port:0
fqdn-regex-compile-lru-size:1024
proxy-connect-timeout:2
enable-bbr:false
enable-bpf-masquerade:false
conntrack-gc-interval:0s
enable-wireguard:false
envoy-config-timeout:2m0s
hubble-disable-tls:false
version:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
83         Disabled           Disabled          585156     k8s:eks.amazonaws.com/component=coredns                                               10.7.0.228   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
119        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1b                                                                 
                                                           reserved:host                                                                                              
189        Disabled           Disabled          580057     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.7.0.78    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
410        Disabled           Disabled          585156     k8s:eks.amazonaws.com/component=coredns                                               10.7.0.104   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
851        Disabled           Disabled          556252     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.7.0.201   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
1673       Disabled           Disabled          528627     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.7.0.6     ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
1842       Disabled           Disabled          4          reserved:health                                                                       10.7.0.123   ready   
2953       Disabled           Disabled          536794     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.7.0.141   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh8                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
```

#### BPF Policy Get 83

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6964    73        0        
Allow    Ingress     1          ANY          NONE         disabled    50641   582       0        
Allow    Egress      0          ANY          NONE         disabled    12969   133       0        

```


#### BPF CT List 83

```
Invalid argument: unknown type 83
```


#### Endpoint Get 83

```
[
  {
    "id": 83,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-83-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "53c58ab8-08fc-4fb7-9aa3-1f9320060fbc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-83",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:10.841Z",
            "success-count": 2
          },
          "uuid": "a1cf774c-f1c9-45a0-b16d-a817d4994515"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-hlzgr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:10.840Z",
            "success-count": 1
          },
          "uuid": "3a16e48d-6a07-4637-a0bc-b05aaa2ad5ee"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-83",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:13.250Z",
            "success-count": 1
          },
          "uuid": "4e81a076-2195-41f0-8c00-2c962a09bc85"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (83)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.889Z",
            "success-count": 57
          },
          "uuid": "e640e839-8de5-4f65-85cb-475b9ade2c04"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b4729f40f5123d73fb351ede81c818b1a9740108d7c132adc9059f6f61878d6b:eth0",
        "container-id": "b4729f40f5123d73fb351ede81c818b1a9740108d7c132adc9059f6f61878d6b",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-hlzgr",
        "pod-name": "kube-system/coredns-586b798467-hlzgr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 585156,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.228",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "86:7b:cb:b5:cb:96",
        "interface-index": 9,
        "interface-name": "lxc327e9cd056d8",
        "mac": "ca:3f:90:69:37:ff"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 585156,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 585156,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 83

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 83

```
Timestamp              Status    State                   Message
2024-10-24T09:20:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:10Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:19:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:28Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:28Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:28Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:28Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:14Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:13Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:11Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:10Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:10Z   OK        ready                   Set identity for this endpoint
2024-10-24T09:16:10Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:10Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 585156

```
ID       LABELS
585156   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 119

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 119

```
Invalid argument: unknown type 119
```


#### Endpoint Get 119

```
[
  {
    "id": 119,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-119-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5d8b1d60-22bb-44b3-87fe-1484a39e867c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-119",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:10.683Z",
            "success-count": 2
          },
          "uuid": "2207e464-def2-448b-aaa3-5d75049c0826"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-119",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:12.188Z",
            "success-count": 1
          },
          "uuid": "ba84ebdc-9b2c-41ff-a26f-2f9c56593d5c"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "1e:39:af:0c:5b:af",
        "interface-name": "cilium_host",
        "mac": "1e:39:af:0c:5b:af"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 119

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 119

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:14Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:12Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:10Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:10Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:10Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 189

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    227980   2113      0        
Allow    Ingress     1          ANY          NONE         disabled    224165   2229      0        
Allow    Egress      0          ANY          NONE         disabled    215787   2043      0        

```


#### BPF CT List 189

```
Invalid argument: unknown type 189
```


#### Endpoint Get 189

```
[
  {
    "id": 189,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-189-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c2583981-a4a6-4808-986b-11b3a65e0836"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-189",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:24:02.735Z",
            "success-count": 2
          },
          "uuid": "39a71c75-1ed5-4d2a-83e3-e6e25de626b5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-64fff5c868-86dnl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:19:02.734Z",
            "success-count": 1
          },
          "uuid": "c8b7dd89-af84-4eac-bf8f-9ac93335f60a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-189",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:19:02.767Z",
            "success-count": 1
          },
          "uuid": "54537551-7004-48fe-aed0-da11fc3a49c0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (189)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:22.770Z",
            "success-count": 40
          },
          "uuid": "bea64584-0064-4529-94b6-f78c9fe90538"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ba1f3fd2f497e74ce846cb6dfaf01a3b781736bfb731bea06ae8d8f15f9b174d:eth0",
        "container-id": "ba1f3fd2f497e74ce846cb6dfaf01a3b781736bfb731bea06ae8d8f15f9b174d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-64fff5c868-86dnl",
        "pod-name": "kube-system/clustermesh-apiserver-64fff5c868-86dnl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 580057,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=64fff5c868"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.78",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "02:e4:23:56:7a:1a",
        "interface-index": 15,
        "interface-name": "lxc12019566f818",
        "mac": "7a:c3:56:3b:bd:64"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 580057,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 580057,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 189

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 189

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:19:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:02Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:19:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:19:02Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:19:02Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 580057

```
ID       LABELS
580057   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 410

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4412    51        0        
Allow    Ingress     1          ANY          NONE         disabled    50692   581       0        
Allow    Egress      0          ANY          NONE         disabled    12468   126       0        

```


#### BPF CT List 410

```
Invalid argument: unknown type 410
```


#### Endpoint Get 410

```
[
  {
    "id": 410,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-410-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8efaaa54-4a99-445e-94a7-aa9b1f5854ad"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-410",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:10.965Z",
            "success-count": 2
          },
          "uuid": "f966b28e-8c13-458e-bf3a-84b01f29ee97"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-dqsrq",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:10.961Z",
            "success-count": 1
          },
          "uuid": "dcbbb1e8-e11f-4337-9a8b-6ef7caae0819"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-410",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:16.572Z",
            "success-count": 1
          },
          "uuid": "543adf61-2b8c-40b3-8244-a8f2ebfbb575"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (410)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:21.011Z",
            "success-count": 57
          },
          "uuid": "2c3cabef-5546-4600-89e9-8721ce18a8ab"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bed57b9941794d98eddd6c0799400e17c7e67347cd9cb598d9170e8006ee0943:eth0",
        "container-id": "bed57b9941794d98eddd6c0799400e17c7e67347cd9cb598d9170e8006ee0943",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-dqsrq",
        "pod-name": "kube-system/coredns-586b798467-dqsrq"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 585156,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.104",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2e:67:e7:65:db:7f",
        "interface-index": 11,
        "interface-name": "lxc28d61e217dac",
        "mac": "f6:25:fe:da:21:85"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 585156,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 585156,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 410

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 410

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T09:16:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:16Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T09:16:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T09:16:12Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:11Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:10Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:10Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 585156

```
ID       LABELS
585156   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 851

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4202     30        0        
Allow    Ingress     1          ANY          NONE         disabled    300775   3508      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 851

```
Invalid argument: unknown type 851
```


#### Endpoint Get 851

```
[
  {
    "id": 851,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-851-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "b90baedf-4aaf-4763-80c0-4dfed1bf6c67"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-851",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:17.314Z",
            "success-count": 2
          },
          "uuid": "6402a586-d68a-4b57-b832-3ee3d3d6af5f"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-49kk9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.312Z",
            "success-count": 1
          },
          "uuid": "d5fdceaf-6a12-4f9d-9987-b3b3a67085fe"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-851",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.343Z",
            "success-count": 1
          },
          "uuid": "af043a97-adab-45a7-83aa-af2d6125b928"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (851)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:27.343Z",
            "success-count": 33
          },
          "uuid": "f486ce86-7b97-4f00-bdb8-aa6475c69d97"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "bd4146d953b65ce896568045606512c3f5249738201c8a8af320e47170c9402e:eth0",
        "container-id": "bd4146d953b65ce896568045606512c3f5249738201c8a8af320e47170c9402e",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-49kk9",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-49kk9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 556252,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:26Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.201",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "8e:6f:65:c0:d6:e4",
        "interface-index": 21,
        "interface-name": "lxc4a21c46c83f9",
        "mac": "ce:da:37:a5:77:7d"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 556252,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 556252,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 851

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 851

```
Timestamp              Status   State                   Message
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:12Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:41Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 556252

```
ID       LABELS
556252   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 1673

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1673

```
Invalid argument: unknown type 1673
```


#### Endpoint Get 1673

```
[
  {
    "id": 1673,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1673-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7aa83ca8-0b1f-40cc-858c-ef84ee974e3a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1673",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.922Z",
            "success-count": 2
          },
          "uuid": "1a152620-9ab5-4d14-b06c-393d664cb8ac"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-gwqrv",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.921Z",
            "success-count": 1
          },
          "uuid": "fa1a0ae1-1908-47a1-b3ec-7dc0ce4433e1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1673",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.965Z",
            "success-count": 1
          },
          "uuid": "95ea4f47-68b5-419f-ac0a-35338da051e6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1673)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.972Z",
            "success-count": 33
          },
          "uuid": "5d3991a6-c40f-4a91-a388-1b4aa75055e5"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d49078068c6a561e240c6a93cb1cb0c7b064276f59cd49d356f838b2828f73e8:eth0",
        "container-id": "d49078068c6a561e240c6a93cb1cb0c7b064276f59cd49d356f838b2828f73e8",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-gwqrv",
        "pod-name": "cilium-test-1/client2-57cf4468f-gwqrv"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 528627,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.6",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:ce:b3:e8:a4:4a",
        "interface-index": 19,
        "interface-name": "lxc81d5b86e7885",
        "mac": "da:89:1e:8e:74:f3"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 528627,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 528627,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1673

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1673

```
Timestamp              Status   State                   Message
2024-10-24T09:24:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 528627

```
ID       LABELS
528627   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 1842

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23127   287       0        
Allow    Ingress     1          ANY          NONE         disabled    7325    83        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1842

```
Invalid argument: unknown type 1842
```


#### Endpoint Get 1842

```
[
  {
    "id": 1842,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1842-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d9c47b7c-07d7-46bb-b94b-4b7c4727a3d9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1842",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:11.993Z",
            "success-count": 2
          },
          "uuid": "8944dec5-c0d4-49a2-8ed7-33f34bd8c306"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1842",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:16.568Z",
            "success-count": 1
          },
          "uuid": "81b97e76-87db-4f9e-b2be-343f4edebcad"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.123",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "0e:9c:32:e2:04:10",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "32:44:cb:43:5f:c4"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1842

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1842

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:19:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:10Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:19:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:19:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:19:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:19:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:19:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:19:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:28Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:28Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T09:16:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:16Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T09:16:16Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T09:16:13Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:11Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:10Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 2953

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2953

```
Invalid argument: unknown type 2953
```


#### Endpoint Get 2953

```
[
  {
    "id": 2953,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2953-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bb023322-196b-4dca-abdf-5ec3bc036d44"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2953",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.853Z",
            "success-count": 2
          },
          "uuid": "27336d2c-08c0-4295-aa77-04179f458270"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-c7cc6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.852Z",
            "success-count": 1
          },
          "uuid": "6b3ebc7c-ce07-4a3a-a86c-be56b9fa1e85"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2953",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.907Z",
            "success-count": 1
          },
          "uuid": "c2167f23-df72-4585-8718-f47bf6439237"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2953)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.896Z",
            "success-count": 33
          },
          "uuid": "06217526-d029-4d5b-820b-6c4153852b63"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "be69c3a34d00a00fa0b1c7acaa2c696a935129b7a5ad38d5308cc5de9508ef69:eth0",
        "container-id": "be69c3a34d00a00fa0b1c7acaa2c696a935129b7a5ad38d5308cc5de9508ef69",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-c7cc6",
        "pod-name": "cilium-test-1/client-974f6c69d-c7cc6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 536794,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh8",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:51Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.7.0.141",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "0e:48:fd:51:c6:13",
        "interface-index": 17,
        "interface-name": "lxc547ab3a48d4f",
        "mac": "36:e4:4e:e1:7c:65"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 536794,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 536794,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2953

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2953

```
Timestamp              Status   State                   Message
2024-10-24T09:24:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:07Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:02Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:02Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:54Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:24Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added

```


#### Identity get 536794

```
ID       LABELS
536794   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh8
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.193.150:443 (active)   
                                          2 => 172.31.149.153:443 (active)   
2    10.100.209.56:443     ClusterIP      1 => 172.31.208.9:4244 (active)    
3    10.100.0.10:9153      ClusterIP      1 => 10.7.0.228:9153 (active)      
                                          2 => 10.7.0.104:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.7.0.228:53 (active)        
                                          2 => 10.7.0.104:53 (active)        
5    10.100.32.25:2379     ClusterIP      1 => 10.7.0.78:2379 (active)       
6    10.100.190.237:8080   ClusterIP      1 => 10.7.0.201:8080 (active)      
```

#### Policy get

```
:
 []
Revision: 157

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37821351                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37821351                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37821351                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006400000 rw-p 00000000 00:00 0 
4006400000-4008000000 ---p 00000000 00:00 0 
ffff6232c000-ffff6247d000 rw-p 00000000 00:00 0 
ffff6247d000-ffff624be000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff624be000-ffff624ff000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff624ff000-ffff62501000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff62501000-ffff62503000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff62503000-ffff62a9a000 rw-p 00000000 00:00 0 
ffff62a9a000-ffff62b9a000 rw-p 00000000 00:00 0 
ffff62b9a000-ffff62bab000 rw-p 00000000 00:00 0 
ffff62bab000-ffff64bab000 rw-p 00000000 00:00 0 
ffff64bab000-ffff64c2b000 ---p 00000000 00:00 0 
ffff64c2b000-ffff64c2c000 rw-p 00000000 00:00 0 
ffff64c2c000-ffff84c2b000 ---p 00000000 00:00 0 
ffff84c2b000-ffff84c2c000 rw-p 00000000 00:00 0 
ffff84c2c000-ffffa4bbb000 ---p 00000000 00:00 0 
ffffa4bbb000-ffffa4bbc000 rw-p 00000000 00:00 0 
ffffa4bbc000-ffffa8bad000 ---p 00000000 00:00 0 
ffffa8bad000-ffffa8bae000 rw-p 00000000 00:00 0 
ffffa8bae000-ffffa93ab000 ---p 00000000 00:00 0 
ffffa93ab000-ffffa93ac000 rw-p 00000000 00:00 0 
ffffa93ac000-ffffa94ab000 ---p 00000000 00:00 0 
ffffa94ab000-ffffa950b000 rw-p 00000000 00:00 0 
ffffa950b000-ffffa950d000 r--p 00000000 00:00 0                          [vvar]
ffffa950d000-ffffa950e000 r-xp 00000000 00:00 0                          [vdso]
ffffef51f000-ffffef540000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=10) "10.7.0.141": (string) (len=36) "cilium-test-1/client-974f6c69d-c7cc6",
  (string) (len=9) "10.7.0.78": (string) (len=50) "kube-system/clustermesh-apiserver-64fff5c868-86dnl",
  (string) (len=8) "10.7.0.6": (string) (len=37) "cilium-test-1/client2-57cf4468f-gwqrv",
  (string) (len=10) "10.7.0.201": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-49kk9",
  (string) (len=9) "10.7.0.95": (string) (len=6) "router",
  (string) (len=10) "10.7.0.123": (string) (len=6) "health",
  (string) (len=10) "10.7.0.228": (string) (len=36) "kube-system/coredns-586b798467-hlzgr",
  (string) (len=10) "10.7.0.104": (string) (len=36) "kube-system/coredns-586b798467-dqsrq"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=20) "default:172.31.208.9": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x400123a840)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d348a0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d348a0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000bfbce0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4000bfbd90)(frontends:[10.100.209.56]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000bfbe40)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40038d31e0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40038d3290)(frontends:[10.100.32.25]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x400206d8c0)(frontends:[10.100.190.237]/ports=[http]/selector=map[name:echo-same-node])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40012b8118)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-nzm78": (*k8s.Endpoints)(0x40032ff380)(10.7.0.78:2379/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4000d71f38)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-kqqls": (*k8s.Endpoints)(0x4003913380)(10.7.0.201:8080/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000d700f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4000c5ba00)(172.31.149.153:443/TCP,172.31.193.150:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000d70100)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-9dhtv": (*k8s.Endpoints)(0x4003361450)(172.31.208.9:4244/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000d70108)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-frjfn": (*k8s.Endpoints)(0x40035e5d40)(10.7.0.104:53/TCP[us-east-1b],10.7.0.104:53/UDP[us-east-1b],10.7.0.104:9153/TCP[us-east-1b],10.7.0.228:53/TCP[us-east-1b],10.7.0.228:53/UDP[us-east-1b],10.7.0.228:9153/TCP[us-east-1b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x400196ae70)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400157fa40)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40046191d0
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4002149980,
  gcExited: (chan struct {}) 0x40021499e0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x400195f580)({
     ObserverVec: (*prometheus.HistogramVec)(0x400142b420)({
      MetricVec: (*prometheus.MetricVec)(0x4001c814d0)({
       metricMap: (*prometheus.metricMap)(0x4001c81500)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52960)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x400195f600)({
     ObserverVec: (*prometheus.HistogramVec)(0x400142b428)({
      MetricVec: (*prometheus.MetricVec)(0x4001c81560)({
       metricMap: (*prometheus.metricMap)(0x4001c81590)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a529c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x400195f680)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b430)({
      MetricVec: (*prometheus.MetricVec)(0x4001c815f0)({
       metricMap: (*prometheus.metricMap)(0x4001c81620)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52a20)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x400195f700)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b438)({
      MetricVec: (*prometheus.MetricVec)(0x4001c81680)({
       metricMap: (*prometheus.metricMap)(0x4001c816b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52a80)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x400195f780)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b440)({
      MetricVec: (*prometheus.MetricVec)(0x4001c81710)({
       metricMap: (*prometheus.metricMap)(0x4001c81740)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52ae0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x400195f800)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b448)({
      MetricVec: (*prometheus.MetricVec)(0x4001c817a0)({
       metricMap: (*prometheus.metricMap)(0x4001c817d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52b40)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x400195f880)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b450)({
      MetricVec: (*prometheus.MetricVec)(0x4001c81830)({
       metricMap: (*prometheus.metricMap)(0x4001c81860)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52ba0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x400195f900)({
     GaugeVec: (*prometheus.GaugeVec)(0x400142b458)({
      MetricVec: (*prometheus.MetricVec)(0x4001c818c0)({
       metricMap: (*prometheus.metricMap)(0x4001c818f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52c00)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x400195f980)({
     ObserverVec: (*prometheus.HistogramVec)(0x400142b460)({
      MetricVec: (*prometheus.MetricVec)(0x4001c81950)({
       metricMap: (*prometheus.metricMap)(0x4001c81980)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a52c60)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x400196ae70)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001d28380)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40001495d8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 82ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption


