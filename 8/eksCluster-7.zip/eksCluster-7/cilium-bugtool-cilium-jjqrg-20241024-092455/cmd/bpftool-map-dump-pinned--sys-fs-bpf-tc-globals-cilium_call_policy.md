key: 53 00 00 00  value: f5 01 00 00
key: bd 00 00 00  value: 51 02 00 00
key: 9a 01 00 00  value: 0e 02 00 00
key: 53 03 00 00  value: 2e 0d 00 00
key: 89 06 00 00  value: 54 0e 00 00
key: 32 07 00 00  value: fb 01 00 00
key: 89 0b 00 00  value: 56 0e 00 00
Found 7 elements
