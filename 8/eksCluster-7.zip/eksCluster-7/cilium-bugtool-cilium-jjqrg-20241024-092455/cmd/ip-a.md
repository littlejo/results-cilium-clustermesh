1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 12:92:ce:3b:56:0b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.208.9/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3025sec preferred_lft 3025sec
    inet6 fe80::1092:ceff:fe3b:560b/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:67:f8:8c:f7:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bc67:f8ff:fe8c:f7be/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:39:af:0c:5b:af brd ff:ff:ff:ff:ff:ff
    inet 10.7.0.95/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1c39:afff:fe0c:5baf/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e2:94:90:37:69:2d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e094:90ff:fe37:692d/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:9c:32:e2:04:10 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c9c:32ff:fee2:410/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc327e9cd056d8@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:7b:cb:b5:cb:96 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::847b:cbff:feb5:cb96/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc28d61e217dac@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:67:e7:65:db:7f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c67:e7ff:fe65:db7f/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc12019566f818@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:e4:23:56:7a:1a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e4:23ff:fe56:7a1a/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc547ab3a48d4f@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:48:fd:51:c6:13 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::c48:fdff:fe51:c613/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc81d5b86e7885@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:ce:b3:e8:a4:4a brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::3cce:b3ff:fee8:a44a/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc4a21c46c83f9@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:6f:65:c0:d6:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::8c6f:65ff:fec0:d6e4/64 scope link 
       valid_lft forever preferred_lft forever
