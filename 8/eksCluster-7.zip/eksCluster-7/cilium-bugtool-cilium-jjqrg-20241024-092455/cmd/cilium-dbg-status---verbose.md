KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.7.0.0/24, 
Allocated addresses:
  10.7.0.104 (kube-system/coredns-586b798467-dqsrq)
  10.7.0.123 (health)
  10.7.0.141 (cilium-test-1/client-974f6c69d-c7cc6)
  10.7.0.201 (cilium-test-1/echo-same-node-86d9cc975c-49kk9)
  10.7.0.228 (kube-system/coredns-586b798467-hlzgr)
  10.7.0.6 (cilium-test-1/client2-57cf4468f-gwqrv)
  10.7.0.78 (kube-system/clustermesh-apiserver-64fff5c868-86dnl)
  10.7.0.95 (router)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 1 reconnections (last: 6m21s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d22dc02a137dc9dc
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    16s ago        never        0       no error   
  ct-map-pressure                                                     18s ago        never        0       no error   
  daemon-validate-config                                              9s ago         never        0       no error   
  dns-garbage-collector-job                                           23s ago        never        0       no error   
  endpoint-119-regeneration-recovery                                  never          never        0       no error   
  endpoint-1673-regeneration-recovery                                 never          never        0       no error   
  endpoint-1842-regeneration-recovery                                 never          never        0       no error   
  endpoint-189-regeneration-recovery                                  never          never        0       no error   
  endpoint-2953-regeneration-recovery                                 never          never        0       no error   
  endpoint-410-regeneration-recovery                                  never          never        0       no error   
  endpoint-83-regeneration-recovery                                   never          never        0       no error   
  endpoint-851-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m23s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                18s ago        never        0       no error   
  ipcache-inject-labels                                               19s ago        never        0       no error   
  k8s-heartbeat                                                       3s ago         never        0       no error   
  link-cache                                                          3s ago         never        0       no error   
  local-identity-checkpoint                                           35s ago        never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m21s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m21s ago      never        0       no error   
  resolve-identity-119                                                4m19s ago      never        0       no error   
  resolve-identity-1673                                               13s ago        never        0       no error   
  resolve-identity-1842                                               4m17s ago      never        0       no error   
  resolve-identity-189                                                1m26s ago      never        0       no error   
  resolve-identity-2953                                               13s ago        never        0       no error   
  resolve-identity-410                                                4m18s ago      never        0       no error   
  resolve-identity-83                                                 4m18s ago      never        0       no error   
  resolve-identity-851                                                12s ago        never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-c7cc6                 5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-gwqrv                5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-49kk9        5m12s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-64fff5c868-86dnl   6m26s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-dqsrq                 9m18s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-hlzgr                 9m18s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      9m19s ago      never        0       no error   
  sync-policymap-119                                                  9m17s ago      never        0       no error   
  sync-policymap-1673                                                 5m13s ago      never        0       no error   
  sync-policymap-1842                                                 9m13s ago      never        0       no error   
  sync-policymap-189                                                  6m26s ago      never        0       no error   
  sync-policymap-2953                                                 5m13s ago      never        0       no error   
  sync-policymap-410                                                  9m13s ago      never        0       no error   
  sync-policymap-83                                                   9m16s ago      never        0       no error   
  sync-policymap-851                                                  5m12s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1673)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (189)                                    6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2953)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (410)                                    8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (83)                                     8s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (851)                                    12s ago        never        0       no error   
  sync-utime                                                          19s ago        never        0       no error   
  write-cni-file                                                      9m23s ago      never        0       no error   
Proxy Status:            OK, ip 10.7.0.95, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 524288, max 589823
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 22.66   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                                         Disabled         
Cluster health:                                     8/8 reachable    (2024-10-24T09:25:13Z)
  Name                                              IP               Node        Endpoints
  cmesh8/ip-172-31-208-9.ec2.internal (localhost)   172.31.208.9     reachable   reachable
  cmesh1/ip-172-31-190-177.ec2.internal             172.31.190.177   reachable   reachable
  cmesh2/ip-172-31-234-224.ec2.internal             172.31.234.224   reachable   reachable
  cmesh3/ip-172-31-140-200.ec2.internal             172.31.140.200   reachable   reachable
  cmesh4/ip-172-31-224-68.ec2.internal              172.31.224.68    reachable   reachable
  cmesh5/ip-172-31-167-173.ec2.internal             172.31.167.173   reachable   reachable
  cmesh6/ip-172-31-249-188.ec2.internal             172.31.249.188   reachable   reachable
  cmesh7/ip-172-31-162-53.ec2.internal              172.31.162.53    reachable   reachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] OK (5.949µs) [6] (5m12s, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (9m23s, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (24.041µs) (4m23s, x1)
      │   ├── bgp-control-plane
      │   │   └── job-diffstore-events                            [OK] Running (9m19s, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (9m19s, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (9m19s, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (9s, x10)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (18s, x19)
      │   │   └── job-sync-hostips                                [OK] Synchronized (19s, x10)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-119 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m9s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-119 (9m17s, x1)
      │   │   ├── cilium-endpoint-1673 (cilium-test-1/client2-57cf4468f-gwqrv)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1673) (3s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38s, x124)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1673 (5m13s, x1)
      │   │   ├── cilium-endpoint-1842 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m9s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1842 (9m13s, x1)
      │   │   ├── cilium-endpoint-189 (kube-system/clustermesh-apiserver-64fff5c868-86dnl)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (189) (6s, x40)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m9s, x9)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-189 (6m26s, x1)
      │   │   ├── cilium-endpoint-2953 (cilium-test-1/client-974f6c69d-c7cc6)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2953) (3s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (38s, x103)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2953 (5m13s, x1)
      │   │   ├── cilium-endpoint-410 (kube-system/coredns-586b798467-dqsrq)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (410) (8s, x57)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m9s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-410 (9m13s, x1)
      │   │   ├── cilium-endpoint-83 (kube-system/coredns-586b798467-hlzgr)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (83) (8s, x57)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m9s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-83 (9m16s, x1)
      │   │   ├── cilium-endpoint-851 (cilium-test-1/echo-same-node-86d9cc975c-49kk9)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (851) (2s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (2m3s, x80)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-851 (5m12s, x1)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (4m23s, x2)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (2.595457ms) (4m19s, x1)
      │   ├── l2-announcer
      │   │   └── job-l2-announcer lease-gc                       [OK] Running (9m23s, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (115s, x6)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (4m21s, x4)
      │   │   └── nodes-add                                       [OK] Node adds successful (6m21s, x8)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 1 NodePort frontend addresses (9m19s, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Synchronized (6m27s, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (9m19s, x1)
      │   └── timer-job-device-reloader                           [OK] OK (15.31µs) (5m10s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (34.651µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (9m23s, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 0 objects (9m23s, x1)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (9m19s, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (9m19s, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (2.141µs) (19s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] 10.7.0.95 (primary), fe80::1c39:afff:fe0c:5baf (primary) (9m20s, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 20 objects (9m16s, x15)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (9m34s, x1)
      
