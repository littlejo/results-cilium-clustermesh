IP ADDRESS       LOCAL ENDPOINT INFO
10.7.0.141:0     id=2953  sec_id=536794 flags=0x0000 ifindex=17  mac=36:E4:4E:E1:7C:65 nodemac=0E:48:FD:51:C6:13   
10.7.0.228:0     id=83    sec_id=585156 flags=0x0000 ifindex=9   mac=CA:3F:90:69:37:FF nodemac=86:7B:CB:B5:CB:96   
10.7.0.78:0      id=189   sec_id=580057 flags=0x0000 ifindex=15  mac=7A:C3:56:3B:BD:64 nodemac=02:E4:23:56:7A:1A   
172.31.208.9:0   (localhost)                                                                                       
10.7.0.104:0     id=410   sec_id=585156 flags=0x0000 ifindex=11  mac=F6:25:FE:DA:21:85 nodemac=2E:67:E7:65:DB:7F   
10.7.0.123:0     id=1842  sec_id=4     flags=0x0000 ifindex=7   mac=32:44:CB:43:5F:C4 nodemac=0E:9C:32:E2:04:10    
10.7.0.201:0     id=851   sec_id=556252 flags=0x0000 ifindex=21  mac=CE:DA:37:A5:77:7D nodemac=8E:6F:65:C0:D6:E4   
10.7.0.6:0       id=1673  sec_id=528627 flags=0x0000 ifindex=19  mac=DA:89:1E:8E:74:F3 nodemac=3E:CE:B3:E8:A4:4A   
10.7.0.95:0      (localhost)                                                                                       
