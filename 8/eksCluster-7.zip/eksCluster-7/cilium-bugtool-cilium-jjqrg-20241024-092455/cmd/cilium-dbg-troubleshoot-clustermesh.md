Found 7 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.32.25
     ✅ TCP connection successfully established to 10.100.32.25:2379
     ✅ TLS connection successfully established to 10.100.32.25:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       d6:53:79:4b:65:28:21:e5:fc:1d:69:68:b6:a6:3e:5c
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:17 +0000 UTC
          Not after:   2027-10-24 09:15:17 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       76:c5:9a:93:c9:a7:54:36:b9:0e:f7:4d:fd:38:e9:3d:8a:42:8a:00
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: d22dc02a137dc9dc
