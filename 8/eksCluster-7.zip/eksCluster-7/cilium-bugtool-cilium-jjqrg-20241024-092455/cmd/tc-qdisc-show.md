qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxc327e9cd056d8 root refcnt 2 
qdisc clsact ffff: dev lxc327e9cd056d8 parent ffff:fff1 
qdisc noqueue 0: dev lxc28d61e217dac root refcnt 2 
qdisc clsact ffff: dev lxc28d61e217dac parent ffff:fff1 
qdisc noqueue 0: dev lxc12019566f818 root refcnt 2 
qdisc clsact ffff: dev lxc12019566f818 parent ffff:fff1 
qdisc noqueue 0: dev lxc547ab3a48d4f root refcnt 2 
qdisc clsact ffff: dev lxc547ab3a48d4f parent ffff:fff1 
qdisc noqueue 0: dev lxc81d5b86e7885 root refcnt 2 
qdisc clsact ffff: dev lxc81d5b86e7885 parent ffff:fff1 
qdisc noqueue 0: dev lxc4a21c46c83f9 root refcnt 2 
qdisc clsact ffff: dev lxc4a21c46c83f9 parent ffff:fff1 
