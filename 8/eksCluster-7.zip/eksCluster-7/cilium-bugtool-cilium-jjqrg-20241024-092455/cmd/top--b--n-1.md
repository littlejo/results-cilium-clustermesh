top - 09:24:57 up 9 min,  0 users,  load average: 0.03, 0.25, 0.20
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 12.9 us, 38.7 sy,  0.0 ni, 48.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,   1014.9 free,    719.4 used,   2101.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2939.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1404956 187780  78548 S   0.0   4.8   0:23.86 cilium-+
    508 root      20   0 1228848   4720   3844 S   0.0   0.1   0:00.01 cilium-+
   2891 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
   2900 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   2910 root      20   0 1228744   3716   3040 S   0.0   0.1   0:00.00 gops
   2916 root      20   0 1240176  16340  11292 S   0.0   0.4   0:00.02 cilium-+
   2945 root      20   0    6576   2424   2100 R   0.0   0.1   0:00.00 top
   2963 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   2968 root      20   0 1692104   8756   6220 S   0.0   0.2   0:00.00 runc:[2+
