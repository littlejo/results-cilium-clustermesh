CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1a52743_8df4_4248_9409_1774ba0b0d10.slice/cri-containerd-07bf70c6e5926fca7c4bf1acef2e77daff784ac63b476ad6aaeae81d11e3a5cd.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1a52743_8df4_4248_9409_1774ba0b0d10.slice/cri-containerd-5a6a793103e8380aa13d5c87984b8d86baae8766d07121095ff7ea93502ed236.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode514cd43_1977_4843_b02d_26c2c7e3c18f.slice/cri-containerd-bed57b9941794d98eddd6c0799400e17c7e67347cd9cb598d9170e8006ee0943.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode514cd43_1977_4843_b02d_26c2c7e3c18f.slice/cri-containerd-335505a729a40e386e80caa06241023465188528aa5087208de6ef3f293e71cb.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d2b167_63f3_40f2_9c37_2c35af59eb1e.slice/cri-containerd-127afdb54fdbd7fd90c611ff5a09219939cea77a7a1ec47b3ca8c57f737b2c1f.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d2b167_63f3_40f2_9c37_2c35af59eb1e.slice/cri-containerd-b4729f40f5123d73fb351ede81c818b1a9740108d7c132adc9059f6f61878d6b.scope
    461      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d1e0bd0_b9e3_4c74_9629_cd8b5cefdf39.slice/cri-containerd-e0a61779f2e026a3f30fea9e959484b9149bf24d850769b226944fac66335936.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d1e0bd0_b9e3_4c74_9629_cd8b5cefdf39.slice/cri-containerd-62148c7852c774994b9bb2e32f4746dcbcb366c4cd1960f288ca6e2b3e32f75f.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb64caa4_567f_46ec_920e_62bd2f29eeaf.slice/cri-containerd-be69c3a34d00a00fa0b1c7acaa2c696a935129b7a5ad38d5308cc5de9508ef69.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb64caa4_567f_46ec_920e_62bd2f29eeaf.slice/cri-containerd-1c10db3cd58d31d4a3dd52a93480a00a5c7c5ca3489869ced05c5f46c567c906.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5a3c996_1d49_4e33_b567_fab7c07480a4.slice/cri-containerd-b8f495a6560e538df6145968dde28f05111319aea2d7c67ec61bb59eba2cb6c4.scope
    680      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5a3c996_1d49_4e33_b567_fab7c07480a4.slice/cri-containerd-d49078068c6a561e240c6a93cb1cb0c7b064276f59cd49d356f838b2828f73e8.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0bea1fe_a618_45d2_a662_d9f86339328b.slice/cri-containerd-d73eacd1e861b2f8cccb96d0c51c4958f7ba968b3e15249fc9884d293b9e0ab7.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0bea1fe_a618_45d2_a662_d9f86339328b.slice/cri-containerd-d9c822dd7fee37646c2a1d77ec63e404bcb8c440f585c1872e23ebb33f5d04ce.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0bea1fe_a618_45d2_a662_d9f86339328b.slice/cri-containerd-bd4146d953b65ce896568045606512c3f5249738201c8a8af320e47170c9402e.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-6a7b65a09a57f0dacb63d6e69414b39e8fe8803e04f5f9ca16322b41fd1d3a23.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-9b41e97330a3cce2220e9240bb5ae21a0b07733df6fa859c89bd7d4c5f81011a.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-cbed0bff5e87ae86ee4cc9cd4e623901b78cd5d0ab1aedd3afc3d42ad2e207bd.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-ba1f3fd2f497e74ce846cb6dfaf01a3b781736bfb731bea06ae8d8f15f9b174d.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b0bd329_6560_4ef7_8d20_8bb7903e5a30.slice/cri-containerd-60d90532d732a3294a861744de4323b59e0cc04d976ff013dc0cd5eea571429d.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0b0bd329_6560_4ef7_8d20_8bb7903e5a30.slice/cri-containerd-7efecab8e685b18faf906fded4690009ac096d095047d541416782eb30f3f319.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75309dc8_bb04_439a_9b9b_a5bd475b2ad8.slice/cri-containerd-e199a0c0e41cb434e852a7a5341c3c0c1c5a4f62ca4930e590772f756314ed8b.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75309dc8_bb04_439a_9b9b_a5bd475b2ad8.slice/cri-containerd-f6bc77cc6b174f79233a1267622ab949731cfe48a580508e9ae7f64a34fc01d1.scope
    68       cgroup_device   multi                                          
