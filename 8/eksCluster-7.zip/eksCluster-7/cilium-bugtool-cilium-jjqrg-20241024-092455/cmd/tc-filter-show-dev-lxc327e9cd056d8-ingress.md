filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc327e9cd056d8 direct-action not_in_hw id 493 tag 370671b2b7fe2460 jited 
