Total: 336
TCP:   351 (estab 60, closed 272, orphaned 0, timewait 213)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  79        68        11       
INET	  89        74        15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                    Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                     172.31.208.9%ens5:68         0.0.0.0:*    uid:192 ino:16475 sk:125 cgroup:unreachable:bd0 <->                            
UNCONN 0      0                               0.0.0.0:8472       0.0.0.0:*    ino:22668 sk:126 cgroup:/ <->                                                  
UNCONN 0      0                             127.0.0.1:323        0.0.0.0:*    ino:15214 sk:127 cgroup:unreachable:e8e <->                                    
UNCONN 0      0                             127.0.0.1:35401      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:21348 sk:128 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                  [::]:8472          [::]:*    ino:22667 sk:129 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                 [::1]:323           [::]:*    ino:15215 sk:12a cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::1092:ceff:fe3b:560b]%ens5:546           [::]:*    uid:192 ino:16473 sk:12b cgroup:unreachable:bd0 v6only:1 <->                   
