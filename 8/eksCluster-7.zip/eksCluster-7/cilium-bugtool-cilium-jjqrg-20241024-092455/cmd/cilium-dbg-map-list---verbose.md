## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_00119
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_00410
Key              Value         State   Error
Ingress: 0 ANY   0 51 4412             
Egress: 0 ANY    0 126 12468           
Ingress: 1 ANY   0 581 50692           

## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440062500000           
AgentLiveness   616036336829               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_lxc
Key              Value                                                                                             State   Error
10.7.0.95:0      (localhost)                                                                                       sync    
172.31.208.9:0   (localhost)                                                                                       sync    
10.7.0.228:0     id=83    sec_id=585156 flags=0x0000 ifindex=9   mac=CA:3F:90:69:37:FF nodemac=86:7B:CB:B5:CB:96   sync    
10.7.0.123:0     id=1842  sec_id=4     flags=0x0000 ifindex=7   mac=32:44:CB:43:5F:C4 nodemac=0E:9C:32:E2:04:10    sync    
10.7.0.141:0     id=2953  sec_id=536794 flags=0x0000 ifindex=17  mac=36:E4:4E:E1:7C:65 nodemac=0E:48:FD:51:C6:13   sync    
10.7.0.104:0     id=410   sec_id=585156 flags=0x0000 ifindex=11  mac=F6:25:FE:DA:21:85 nodemac=2E:67:E7:65:DB:7F   sync    
10.7.0.78:0      id=189   sec_id=580057 flags=0x0000 ifindex=15  mac=7A:C3:56:3B:BD:64 nodemac=02:E4:23:56:7A:1A   sync    
10.7.0.6:0       id=1673  sec_id=528627 flags=0x0000 ifindex=19  mac=DA:89:1E:8E:74:F3 nodemac=3E:CE:B3:E8:A4:4A   sync    
10.7.0.201:0     id=851   sec_id=556252 flags=0x0000 ifindex=21  mac=CE:DA:37:A5:77:7D nodemac=8E:6F:65:C0:D6:E4   sync    

## Map: cilium_lb4_services_v2
Key                       Value                State   Error
10.100.0.10:9153 (2)      6 0 (3) [0x0 0x0]    sync    
10.100.32.25:2379 (1)     9 0 (5) [0x0 0x0]    sync    
10.100.0.1:443 (2)        8 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (1)        1 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (0)        0 2 (1) [0x0 0x0]    sync    
10.100.0.10:53 (0)        0 2 (4) [0x0 0x0]    sync    
10.100.0.10:53 (1)        3 0 (4) [0x0 0x0]    sync    
10.100.0.10:9153 (1)      4 0 (3) [0x0 0x0]    sync    
10.100.0.10:9153 (0)      0 2 (3) [0x0 0x0]    sync    
10.100.0.10:53 (2)        5 0 (4) [0x0 0x0]    sync    
10.100.190.237:8080 (0)   0 1 (6) [0x0 0x0]    sync    
10.100.209.56:443 (0)     0 1 (2) [0x0 0x10]   sync    
10.100.32.25:2379 (0)     0 1 (5) [0x0 0x0]    sync    
10.100.209.56:443 (1)     2 0 (2) [0x0 0x0]    sync    
10.100.190.237:8080 (1)   10 0 (6) [0x0 0x0]   sync    

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
1     ANY://172.31.193.150   sync    
2     ANY://172.31.208.9     sync    
3     ANY://10.7.0.228       sync    
9     ANY://10.7.0.78        sync    
4     ANY://10.7.0.228       sync    
5     ANY://10.7.0.104       sync    
6     ANY://10.7.0.104       sync    
8     ANY://172.31.149.153   sync    
10    ANY://10.7.0.201       sync    

## Map: cilium_tunnel_map
Key        Value              State   Error
10.2.0.0   172.31.140.200:0   sync    
10.3.0.0   172.31.224.68:0    sync    
10.5.0.0   172.31.249.188:0   sync    
10.1.0.0   172.31.234.224:0   sync    
10.4.0.0   172.31.167.173:0   sync    
10.0.0.0   172.31.190.177:0   sync    
10.6.0.0   172.31.162.53:0    sync    

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
2     10.100.209.56:443     sync    
3     10.100.0.10:9153      sync    
4     10.100.0.10:53        sync    
5     10.100.32.25:2379     sync    
6     10.100.190.237:8080   sync    
1     10.100.0.1:443        sync    

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
172.31.149.153/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.208.9/32     identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.193.150/32   identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.7.0.95/32        identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    

## Map: cilium_policy_01842
Key              Value         State   Error
Ingress: 0 ANY   0 286 23061           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 83 7325             

## Map: cilium_policy_02953
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_policy_00851
Key              Value           State   Error
Ingress: 0 ANY   0 30 4202               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3508 300775           

## Map: cilium_policy_00083
Key              Value         State   Error
Ingress: 0 ANY   0 73 6964             
Egress: 0 ANY    0 133 12969           
Ingress: 1 ANY   0 592 51534           

## Map: cilium_policy_00189
Key              Value           State   Error
Ingress: 0 ANY   0 2113 227980           
Egress: 0 ANY    0 2043 215787           
Ingress: 1 ANY   0 2229 224165           

## Map: cilium_policy_01673
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


