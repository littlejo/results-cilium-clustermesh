USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2916  0.0  0.4 1240176 16340 ?       Ssl  09:24   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2933  0.0  0.0   6408  1632 ?        R    09:24   0:00  \_ ps auxfw
root        2935  0.0  0.0   3852  1276 ?        R    09:24   0:00  \_ bash -c hostname
root        2910  0.0  0.0 1228744 3716 ?        Ssl  09:24   0:00 /bin/gops pprof-heap 1
root        2900  0.0  0.1 1229000 4056 ?        Ssl  09:24   0:00 /bin/gops stats 1
root        2891  0.0  0.1 1228744 4040 ?        Ssl  09:24   0:00 /bin/gops pprof-cpu 1
root           1  4.3  4.7 1404956 187780 ?      Ssl  09:15   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         508  0.0  0.1 1228848 4720 ?        Sl   09:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
