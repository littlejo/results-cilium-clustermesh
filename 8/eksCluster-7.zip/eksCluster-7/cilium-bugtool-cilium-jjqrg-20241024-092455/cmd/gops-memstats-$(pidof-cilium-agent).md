alloc: 53.94MB (56561504 bytes)
total-alloc: 1.44GB (1549013808 bytes)
sys: 108.36MB (113626420 bytes)
lookups: 0
mallocs: 46683588
frees: 46241901
heap-alloc: 53.94MB (56561504 bytes)
heap-sys: 93.30MB (97828864 bytes)
heap-idle: 22.42MB (23511040 bytes)
heap-in-use: 70.88MB (74317824 bytes)
heap-released: 3.63MB (3809280 bytes)
heap-objects: 441687
stack-in-use: 6.66MB (6979584 bytes)
stack-sys: 6.66MB (6979584 bytes)
stack-mspan-inuse: 1.05MB (1106080 bytes)
stack-mspan-sys: 1.23MB (1289280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 725.14KB (742545 bytes)
gc-sys: 4.55MB (4766280 bytes)
next-gc: when heap-alloc >= 84.77MB (88888056 bytes)
last-gc: 2024-10-24 09:24:57.85911805 +0000 UTC
gc-pause-total: 7.354996ms
gc-pause: 83373
gc-pause-end: 1729761897859118050
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005819406169820785
enable-gc: true
debug-gc: false
