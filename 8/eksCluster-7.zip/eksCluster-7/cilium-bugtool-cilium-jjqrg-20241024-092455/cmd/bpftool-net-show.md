xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 549
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 540
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 535
cilium_host(4) clsact/egress cil_from_host-cilium_host id 533
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 463
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 464
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 510
lxc327e9cd056d8(9) clsact/ingress cil_from_container-lxc327e9cd056d8 id 493
lxc28d61e217dac(11) clsact/ingress cil_from_container-lxc28d61e217dac id 528
lxc12019566f818(15) clsact/ingress cil_from_container-lxc12019566f818 id 603
lxc547ab3a48d4f(17) clsact/ingress cil_from_container-lxc547ab3a48d4f id 3674
lxc81d5b86e7885(19) clsact/ingress cil_from_container-lxc81d5b86e7885 id 3683
lxc4a21c46c83f9(21) clsact/ingress cil_from_container-lxc4a21c46c83f9 id 3367

flow_dissector:

netfilter:

