filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc12019566f818 direct-action not_in_hw id 603 tag 7cac2f0dc23594a9 jited 
