[
  {
    "containers": [
      {
        "cgroup-id": 9010,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0bea1fe_a618_45d2_a662_d9f86339328b.slice/cri-containerd-d9c822dd7fee37646c2a1d77ec63e404bcb8c440f585c1872e23ebb33f5d04ce.scope"
      },
      {
        "cgroup-id": 9094,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda0bea1fe_a618_45d2_a662_d9f86339328b.slice/cri-containerd-d73eacd1e861b2f8cccb96d0c51c4958f7ba968b3e15249fc9884d293b9e0ab7.scope"
      }
    ],
    "ips": [
      "10.7.0.201"
    ],
    "name": "echo-same-node-86d9cc975c-49kk9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6742,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode514cd43_1977_4843_b02d_26c2c7e3c18f.slice/cri-containerd-335505a729a40e386e80caa06241023465188528aa5087208de6ef3f293e71cb.scope"
      }
    ],
    "ips": [
      "10.7.0.104"
    ],
    "name": "coredns-586b798467-dqsrq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8926,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb64caa4_567f_46ec_920e_62bd2f29eeaf.slice/cri-containerd-1c10db3cd58d31d4a3dd52a93480a00a5c7c5ca3489869ced05c5f46c567c906.scope"
      }
    ],
    "ips": [
      "10.7.0.141"
    ],
    "name": "client-974f6c69d-c7cc6",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8086,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-9b41e97330a3cce2220e9240bb5ae21a0b07733df6fa859c89bd7d4c5f81011a.scope"
      },
      {
        "cgroup-id": 8254,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-6a7b65a09a57f0dacb63d6e69414b39e8fe8803e04f5f9ca16322b41fd1d3a23.scope"
      },
      {
        "cgroup-id": 8170,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c2bafec_cdc2_49ef_afcb_dbab43d367dd.slice/cri-containerd-cbed0bff5e87ae86ee4cc9cd4e623901b78cd5d0ab1aedd3afc3d42ad2e207bd.scope"
      }
    ],
    "ips": [
      "10.7.0.78"
    ],
    "name": "clustermesh-apiserver-64fff5c868-86dnl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6574,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46d2b167_63f3_40f2_9c37_2c35af59eb1e.slice/cri-containerd-127afdb54fdbd7fd90c611ff5a09219939cea77a7a1ec47b3ca8c57f737b2c1f.scope"
      }
    ],
    "ips": [
      "10.7.0.228"
    ],
    "name": "coredns-586b798467-hlzgr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8842,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf5a3c996_1d49_4e33_b567_fab7c07480a4.slice/cri-containerd-b8f495a6560e538df6145968dde28f05111319aea2d7c67ec61bb59eba2cb6c4.scope"
      }
    ],
    "ips": [
      "10.7.0.6"
    ],
    "name": "client2-57cf4468f-gwqrv",
    "namespace": "cilium-test-1"
  }
]

