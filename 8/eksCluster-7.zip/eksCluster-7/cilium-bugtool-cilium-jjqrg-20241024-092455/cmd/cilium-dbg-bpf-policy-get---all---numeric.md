Endpoint ID: 83
Path: /sys/fs/bpf/tc/globals/cilium_policy_00083

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6964    73        0        
Allow    Ingress     1          ANY          NONE         disabled    51534   592       0        
Allow    Egress      0          ANY          NONE         disabled    12969   133       0        


Endpoint ID: 119
Path: /sys/fs/bpf/tc/globals/cilium_policy_00119

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 189
Path: /sys/fs/bpf/tc/globals/cilium_policy_00189

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    227980   2113      0        
Allow    Ingress     1          ANY          NONE         disabled    224165   2229      0        
Allow    Egress      0          ANY          NONE         disabled    215787   2043      0        


Endpoint ID: 410
Path: /sys/fs/bpf/tc/globals/cilium_policy_00410

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4412    51        0        
Allow    Ingress     1          ANY          NONE         disabled    50692   581       0        
Allow    Egress      0          ANY          NONE         disabled    12468   126       0        


Endpoint ID: 851
Path: /sys/fs/bpf/tc/globals/cilium_policy_00851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4202     30        0        
Allow    Ingress     1          ANY          NONE         disabled    300775   3508      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1673
Path: /sys/fs/bpf/tc/globals/cilium_policy_01673

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1842
Path: /sys/fs/bpf/tc/globals/cilium_policy_01842

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23061   286       0        
Allow    Ingress     1          ANY          NONE         disabled    7325    83        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2953
Path: /sys/fs/bpf/tc/globals/cilium_policy_02953

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


