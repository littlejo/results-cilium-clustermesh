default via 172.31.192.1 dev ens5 proto dhcp src 172.31.208.9 metric 1024 
10.0.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.1.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.2.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.3.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.4.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.5.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.6.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 mtu 8951 
10.7.0.0/24 via 10.7.0.95 dev cilium_host proto kernel src 10.7.0.95 
10.7.0.95 dev cilium_host proto kernel scope link 
172.31.0.2 via 172.31.192.1 dev ens5 proto dhcp src 172.31.208.9 metric 1024 
172.31.192.0/18 dev ens5 proto kernel scope link src 172.31.208.9 metric 1024 
172.31.192.1 dev ens5 proto dhcp scope link src 172.31.208.9 metric 1024 
