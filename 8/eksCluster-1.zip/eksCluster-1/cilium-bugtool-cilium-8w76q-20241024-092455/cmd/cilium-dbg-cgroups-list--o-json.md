[
  {
    "containers": [
      {
        "cgroup-id": 9084,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8d4d6a0_d63a_420a_ae21_b75b5d4da315.slice/cri-containerd-881b35508da7f12c964a3d6cca48ae090979ea23a9534ce05e911a488c0220a3.scope"
      },
      {
        "cgroup-id": 9000,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8d4d6a0_d63a_420a_ae21_b75b5d4da315.slice/cri-containerd-760a46b0301ce4fd18d83361b00438c6638ec1fafb173127fb2c5f0236bbb024.scope"
      }
    ],
    "ips": [
      "10.1.0.16"
    ],
    "name": "echo-same-node-86d9cc975c-p9lln",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6648,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a3d9c4f_2f68_4b4c_8cf8_1278449b33cd.slice/cri-containerd-27302399e81d8d980af842a06e1143d4534a045be4395f3c9394f9f57fd4e07e.scope"
      }
    ],
    "ips": [
      "10.1.0.64"
    ],
    "name": "coredns-586b798467-q2jt9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8832,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cd1ea81_8bcc_4c54_85bd_3393df102ed4.slice/cri-containerd-c5e4aaf1b66158e28f40e22355a23b8d240f418212b69e9f3e1d6ff68655d365.scope"
      }
    ],
    "ips": [
      "10.1.0.252"
    ],
    "name": "client-974f6c69d-2cghr",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8160,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-5a2a75c42c9f503c9e33450b5e1b0f7bc2d10ff73da328274daeb2161d644896.scope"
      },
      {
        "cgroup-id": 8076,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-72a37bbfbb9c624d90e89036a14eaeecc0d2b0285ccab915f97411068c7d68c5.scope"
      },
      {
        "cgroup-id": 8244,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-b969c58c0769dced069a1a763a6bbf0e4995266110d8a333af826f82090b413b.scope"
      }
    ],
    "ips": [
      "10.1.0.56"
    ],
    "name": "clustermesh-apiserver-6c945c9c98-gw6dk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6732,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac1a60a9_17a1_429a_b345_603afe6f0dff.slice/cri-containerd-7bf033aa5d29f7e293a1c0a7fff876d01a43e8f0d693edec4f7ee877bbae796d.scope"
      }
    ],
    "ips": [
      "10.1.0.196"
    ],
    "name": "coredns-586b798467-qbnzz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8916,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41b574b1_ab9f_4691_b8bd_aeb666fe89cd.slice/cri-containerd-0dfa8c2d048f08a4b5a0f114043e5057c074c26a84106a66b90c4cf81ebb6c63.scope"
      }
    ],
    "ips": [
      "10.1.0.21"
    ],
    "name": "client2-57cf4468f-z8v9j",
    "namespace": "cilium-test-1"
  }
]

