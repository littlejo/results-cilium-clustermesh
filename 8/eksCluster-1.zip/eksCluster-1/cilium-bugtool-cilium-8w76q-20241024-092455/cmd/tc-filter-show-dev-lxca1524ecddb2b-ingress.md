filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca1524ecddb2b direct-action not_in_hw id 595 tag 16f40be105fe52e1 jited 
