top - 09:24:56 up 9 min,  0 users,  load average: 2.07, 0.86, 0.41
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 41.9 us, 29.0 sy,  0.0 ni, 29.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    982.6 free,    751.3 used,   2102.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2908.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1405148 187380  77604 S   0.0   4.8   0:23.32 cilium-+
    412 root      20   0 1228848   4600   3716 S   0.0   0.1   0:00.01 cilium-+
   2768 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   2769 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2770 root      20   0 1240432  15632  10576 S   0.0   0.4   0:00.02 cilium-+
   2783 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2785 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
   2835 root      20   0    6576   2416   2088 R   0.0   0.1   0:00.00 top
   2854 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
