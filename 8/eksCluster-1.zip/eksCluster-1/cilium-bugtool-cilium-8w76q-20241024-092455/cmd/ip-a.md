1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 12:32:69:1c:56:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.224/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3044sec preferred_lft 3044sec
    inet6 fe80::1032:69ff:fe1c:563b/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:7a:25:67:b4:13 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c7a:25ff:fe67:b413/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:df:00:89:dd:67 brd ff:ff:ff:ff:ff:ff
    inet 10.1.0.5/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::74df:ff:fe89:dd67/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:79:6c:26:cd:23 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5879:6cff:fe26:cd23/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:4b:e0:4e:c1:79 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::344b:e0ff:fe4e:c179/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc6a643fec6e13@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:27:71:5a:89:11 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::2427:71ff:fe5a:8911/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc200722d09950@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:a4:32:94:db:86 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::18a4:32ff:fe94:db86/64 scope link 
       valid_lft forever preferred_lft forever
15: lxca1524ecddb2b@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:02:c3:e2:71:bd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5002:c3ff:fee2:71bd/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc7c42cc664569@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:72:7d:a9:64:2b brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::a872:7dff:fea9:642b/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc507037ab939e@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:db:14:06:1c:50 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::48db:14ff:fe06:1c50/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc8ec32609c67b@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:33:02:84:4c:4a brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::ec33:2ff:fe84:4c4a/64 scope link 
       valid_lft forever preferred_lft forever
