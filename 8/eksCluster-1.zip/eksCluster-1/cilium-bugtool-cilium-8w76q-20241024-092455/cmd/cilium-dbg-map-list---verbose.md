## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440097656250           
AgentLiveness   597315447006               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
1     10.100.0.1:443        sync    
2     10.100.57.203:443     sync    
3     10.100.0.10:53        sync    
4     10.100.0.10:9153      sync    
5     10.100.199.121:2379   sync    
6     10.100.154.88:8080    sync    

## Map: cilium_policy_01376
Key              Value           State   Error
Ingress: 0 ANY   0 36 4605               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3484 298904           

## Map: cilium_lxc
Key                Value                                                                                             State   Error
10.1.0.252:0       id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B   sync    
10.1.0.64:0        id=1341  sec_id=135727 flags=0x0000 ifindex=11  mac=EE:13:1E:19:4D:CE nodemac=1A:A4:32:94:DB:86   sync    
172.31.234.224:0   (localhost)                                                                                       sync    
10.1.0.196:0       id=303   sec_id=135727 flags=0x0000 ifindex=9   mac=8E:0A:60:A7:4E:19 nodemac=26:27:71:5A:89:11   sync    
10.1.0.39:0        id=1997  sec_id=4     flags=0x0000 ifindex=7   mac=7A:83:71:9F:4D:AF nodemac=36:4B:E0:4E:C1:79    sync    
10.1.0.56:0        id=1730  sec_id=147144 flags=0x0000 ifindex=15  mac=62:D9:C0:B3:AB:0A nodemac=52:02:C3:E2:71:BD   sync    
10.1.0.21:0        id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50   sync    
10.1.0.16:0        id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A   sync    
10.1.0.5:0         (localhost)                                                                                       sync    

## Map: cilium_tunnel_map
Key        Value              State   Error
10.2.0.0   172.31.140.200:0   sync    
10.4.0.0   172.31.167.173:0   sync    
10.3.0.0   172.31.224.68:0    sync    
10.0.0.0   172.31.190.177:0   sync    
10.6.0.0   172.31.162.53:0    sync    
10.5.0.0   172.31.249.188:0   sync    
10.7.0.0   172.31.208.9:0     sync    

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
9     ANY://10.1.0.56        sync    
5     ANY://10.1.0.64        sync    
6     ANY://10.1.0.196       sync    
10    ANY://10.1.0.16        sync    
4     ANY://10.1.0.64        sync    
8     ANY://172.31.248.255   sync    
1     ANY://172.31.166.57    sync    
2     ANY://172.31.234.224   sync    
3     ANY://10.1.0.196       sync    

## Map: cilium_policy_01997
Key              Value         State   Error
Ingress: 0 ANY   0 287 23082           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 82 7240             

## Map: cilium_policy_03112
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.1.0.5/32         identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
172.31.166.57/32    identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.248.255/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.234.224/32   identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    

## Map: cilium_policy_00359
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_01730
Key              Value           State   Error
Ingress: 0 ANY   0 1985 210657           
Egress: 0 ANY    0 2549 282044           
Ingress: 1 ANY   0 2283 219058           

## Map: cilium_policy_00216
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_lb4_services_v2
Key                       Value                State   Error
10.100.0.1:443 (1)        1 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (0)        0 2 (1) [0x0 0x0]    sync    
10.100.0.10:9153 (2)      4 0 (4) [0x0 0x0]    sync    
10.100.57.203:443 (0)     0 1 (2) [0x0 0x10]   sync    
10.100.0.10:53 (0)        0 2 (3) [0x0 0x0]    sync    
10.100.0.10:9153 (0)      0 2 (4) [0x0 0x0]    sync    
10.100.0.1:443 (2)        8 0 (1) [0x0 0x0]    sync    
10.100.57.203:443 (1)     2 0 (2) [0x0 0x0]    sync    
10.100.0.10:9153 (1)      3 0 (4) [0x0 0x0]    sync    
10.100.0.10:53 (2)        6 0 (3) [0x0 0x0]    sync    
10.100.0.10:53 (1)        5 0 (3) [0x0 0x0]    sync    
10.100.199.121:2379 (0)   0 1 (5) [0x0 0x0]    sync    
10.100.199.121:2379 (1)   9 0 (5) [0x0 0x0]    sync    
10.100.154.88:8080 (0)    0 1 (6) [0x0 0x0]    sync    
10.100.154.88:8080 (1)    10 0 (6) [0x0 0x0]   sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_00303
Key              Value         State   Error
Ingress: 0 ANY   0 46 4138             
Egress: 0 ANY    0 126 12495           
Ingress: 1 ANY   0 576 50245           

## Map: cilium_policy_01341
Key              Value         State   Error
Ingress: 0 ANY   0 78 7238             
Egress: 0 ANY    0 125 12335           
Ingress: 1 ANY   0 583 50602           

## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


