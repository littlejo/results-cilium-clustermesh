filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8ec32609c67b direct-action not_in_hw id 3330 tag 611c97934481a777 jited 
