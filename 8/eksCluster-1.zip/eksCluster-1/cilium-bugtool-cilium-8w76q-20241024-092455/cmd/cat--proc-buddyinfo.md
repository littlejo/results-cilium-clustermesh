Node 0, zone      DMA      0      3      1      2      0      2      3      6      7      7    221 
Node 0, zone   Normal    194     30     68     31     22      5      3      2      2      0      9 
