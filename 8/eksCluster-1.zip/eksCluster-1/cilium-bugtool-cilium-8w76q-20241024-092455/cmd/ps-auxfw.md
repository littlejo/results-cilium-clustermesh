USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2785  0.0  0.1 1229000 4052 ?        Ssl  09:24   0:00 /bin/gops stats 1
root        2783  0.0  0.0 1228744 3596 ?        Ssl  09:24   0:00 /bin/gops pprof-heap 1
root        2770  0.0  0.3 1240432 15632 ?       Ssl  09:24   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2823  0.0  0.0   6408  1648 ?        R    09:24   0:00  \_ ps auxfw
root        2825  0.0  0.0    352     4 ?        R    09:24   0:00  \_ hostname
root        2769  0.0  0.0 1228744 3596 ?        Ssl  09:24   0:00 /bin/gops memstats 1
root        2768  0.0  0.1 1229000 4056 ?        Ssl  09:24   0:00 /bin/gops pprof-cpu 1
root           1  4.4  4.7 1405148 187380 ?      Ssl  09:16   0:23 cilium-agent --config-dir=/tmp/cilium/config-map
root         412  0.0  0.1 1228848 4600 ?        Sl   09:16   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
