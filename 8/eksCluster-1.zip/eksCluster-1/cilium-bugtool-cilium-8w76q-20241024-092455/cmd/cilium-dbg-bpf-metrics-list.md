REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     540       42987       677    bpf_overlay.c
Interface                   INGRESS     59129     194510781   1132   bpf_host.c
Policy denied               EGRESS      137       10138       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      547       43586       53     encap.h
Success                     EGRESS      708       170215      86     l3.h
Success                     EGRESS      905       64097       1694   bpf_host.c
Success                     EGRESS      9998      1913101     1308   bpf_lxc.c
Success                     INGRESS     11869     1730092     86     l3.h
Success                     INGRESS     12728     1907465     235    trace.h
Unsupported L3 protocol     EGRESS      68        5160        1492   bpf_lxc.c
