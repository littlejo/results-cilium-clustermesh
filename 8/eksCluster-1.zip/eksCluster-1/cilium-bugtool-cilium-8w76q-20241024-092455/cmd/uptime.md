 09:24:56 up 9 min,  0 users,  load average: 0.51, 0.53, 0.31
