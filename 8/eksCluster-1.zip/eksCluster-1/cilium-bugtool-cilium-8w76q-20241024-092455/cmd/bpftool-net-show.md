xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 510
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 504
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 499
cilium_host(4) clsact/egress cil_from_host-cilium_host id 498
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 444
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 441
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 525
lxc6a643fec6e13(9) clsact/ingress cil_from_container-lxc6a643fec6e13 id 476
lxc200722d09950(11) clsact/ingress cil_from_container-lxc200722d09950 id 491
lxca1524ecddb2b(15) clsact/ingress cil_from_container-lxca1524ecddb2b id 595
lxc7c42cc664569(17) clsact/ingress cil_from_container-lxc7c42cc664569 id 3633
lxc507037ab939e(19) clsact/ingress cil_from_container-lxc507037ab939e id 3642
lxc8ec32609c67b(21) clsact/ingress cil_from_container-lxc8ec32609c67b id 3330

flow_dissector:

netfilter:

