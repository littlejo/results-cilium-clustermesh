KEY             VALUE
AgentLiveness   596315519701
UTimeOffset     3378440097656250
