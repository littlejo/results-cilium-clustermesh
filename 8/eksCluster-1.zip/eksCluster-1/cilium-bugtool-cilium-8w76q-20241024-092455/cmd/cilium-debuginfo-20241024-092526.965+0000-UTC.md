# Cilium debug information

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
216        Disabled           Disabled          148646     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.1.0.21    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
303        Disabled           Disabled          135727     k8s:eks.amazonaws.com/component=coredns                                               10.1.0.196   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
359        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1b                                                                 
                                                           reserved:host                                                                                              
1341       Disabled           Disabled          135727     k8s:eks.amazonaws.com/component=coredns                                               10.1.0.64    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
1376       Disabled           Disabled          157096     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.1.0.16    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
1730       Disabled           Disabled          147144     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.1.0.56    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
1997       Disabled           Disabled          4          reserved:health                                                                       10.1.0.39    ready   
3112       Disabled           Disabled          151863     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.1.0.252   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh2                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
```

#### BPF Policy Get 216

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 216

```
Invalid argument: unknown type 216
```


#### Endpoint Get 216

```
[
  {
    "id": 216,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-216-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "641584b3-6f16-4d18-98b8-ee530ee94065"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-216",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.917Z",
            "success-count": 2
          },
          "uuid": "4e6bc89d-5569-4401-9a42-22318442fb5c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-z8v9j",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.916Z",
            "success-count": 1
          },
          "uuid": "8be6efae-7bb0-4370-8fe2-8d1fcf323758"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-216",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.956Z",
            "success-count": 1
          },
          "uuid": "4354b835-be13-4a40-97e6-0d09a5524ac7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (216)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.953Z",
            "success-count": 33
          },
          "uuid": "d701495b-8fef-4620-8afa-d1ab0ca07cf6"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "760aa2780654ab54bc0c6c7341ce6732e5d811a1a2ebeb5d6ecf4d3e581dba43:eth0",
        "container-id": "760aa2780654ab54bc0c6c7341ce6732e5d811a1a2ebeb5d6ecf4d3e581dba43",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-z8v9j",
        "pod-name": "cilium-test-1/client2-57cf4468f-z8v9j"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 148646,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:53Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.21",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "4a:db:14:06:1c:50",
        "interface-index": 19,
        "interface-name": "lxc507037ab939e",
        "mac": "de:87:d2:a0:f3:6b"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 148646,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 148646,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 216

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 216

```
Timestamp              Status   State                   Message
2024-10-24T09:24:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:10Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:57Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:57Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 148646

```
ID       LABELS
148646   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 303

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4138    46        0        
Allow    Ingress     1          ANY          NONE         disabled    49220   564       0        
Allow    Egress      0          ANY          NONE         disabled    12495   126       0        

```


#### BPF CT List 303

```
Invalid argument: unknown type 303
```


#### Endpoint Get 303

```
[
  {
    "id": 303,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-303-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7b12c949-9af6-4fe8-8306-a0d87b28ed61"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-303",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:18.225Z",
            "success-count": 2
          },
          "uuid": "68ea2d3d-703f-4f5b-971a-4d6bc9d3e365"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-qbnzz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:18.224Z",
            "success-count": 1
          },
          "uuid": "d3c2aaf9-94f4-412b-b2ab-19a849e71597"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-303",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:21.769Z",
            "success-count": 1
          },
          "uuid": "742adc82-c92e-4bba-a245-ec40ed9a3dd5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (303)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:18.279Z",
            "success-count": 56
          },
          "uuid": "524fca2c-6cd0-439d-a9e2-e17946266b8b"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0cf01e3699c4d073614f56d84b5b956025c99c71859799149c51034a1e9ad5c8:eth0",
        "container-id": "0cf01e3699c4d073614f56d84b5b956025c99c71859799149c51034a1e9ad5c8",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-qbnzz",
        "pod-name": "kube-system/coredns-586b798467-qbnzz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 135727,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.196",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "26:27:71:5a:89:11",
        "interface-index": 9,
        "interface-name": "lxc6a643fec6e13",
        "mac": "8e:0a:60:a7:4e:19"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 303

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 303

```
Timestamp              Status    State                   Message
2024-10-24T09:20:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:58Z   OK        regenerating            Regenerating endpoint: 
2024-10-24T09:18:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:30Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:30Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:21Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:21Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:20Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:19Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:16:19Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:18Z   OK        ready                   Set identity for this endpoint
2024-10-24T09:16:18Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:18Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 135727

```
ID       LABELS
135727   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 359

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 359

```
Invalid argument: unknown type 359
```


#### Endpoint Get 359

```
[
  {
    "id": 359,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-359-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "48156e9f-8a0f-4339-b8e7-4a76b6f61890"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:16.904Z",
            "success-count": 2
          },
          "uuid": "046c6f88-94d9-43cb-99e5-8ae7fb7bbca7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-359",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:18.022Z",
            "success-count": 1
          },
          "uuid": "8b5932dd-8535-403f-b35e-76851dd427b7"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az2",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "76:df:00:89:dd:67",
        "interface-name": "cilium_host",
        "mac": "76:df:00:89:dd:67"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 359

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 359

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-24T09:16:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:21Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-24T09:16:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-24T09:16:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:16Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:16Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1341

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    7238    78        0        
Allow    Ingress     1          ANY          NONE         disabled    49711   573       0        
Allow    Egress      0          ANY          NONE         disabled    12335   125       0        

```


#### BPF CT List 1341

```
Invalid argument: unknown type 1341
```


#### Endpoint Get 1341

```
[
  {
    "id": 1341,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1341-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "ba9f4f17-04a3-4109-9063-d6d83e350614"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1341",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:18.333Z",
            "success-count": 2
          },
          "uuid": "9db7c1a7-c2ff-4884-b27f-e568dc330994"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-q2jt9",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:18.331Z",
            "success-count": 1
          },
          "uuid": "b10777df-c6b0-4832-8b62-5cd2e3ca5a53"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1341",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:21.807Z",
            "success-count": 1
          },
          "uuid": "bd1a8e11-83ce-463f-9ccf-ca3136293b88"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1341)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:18.401Z",
            "success-count": 56
          },
          "uuid": "047de8e2-bea9-4325-bee8-2ca050e4fffc"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "49ecf0e19ba9d8fbc24a2c2829de8e8289f02f4654c59ccd5ec7be2ca82ff5d2:eth0",
        "container-id": "49ecf0e19ba9d8fbc24a2c2829de8e8289f02f4654c59ccd5ec7be2ca82ff5d2",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-q2jt9",
        "pod-name": "kube-system/coredns-586b798467-q2jt9"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 135727,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.64",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:a4:32:94:db:86",
        "interface-index": 11,
        "interface-name": "lxc200722d09950",
        "mac": "ee:13:1e:19:4d:ce"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 135727,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1341

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1341

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:21Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:18Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:18Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 135727

```
ID       LABELS
135727   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1376

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4605     36        0        
Allow    Ingress     1          ANY          NONE         disabled    297887   3472      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 1376

```
Invalid argument: unknown type 1376
```


#### Endpoint Get 1376

```
[
  {
    "id": 1376,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1376-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a361aaac-3448-489b-930b-cf48ee00815c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1376",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:17.548Z",
            "success-count": 2
          },
          "uuid": "a96deca6-59fb-4d31-9175-beef23f77d9a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-p9lln",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.546Z",
            "success-count": 1
          },
          "uuid": "0c424b5b-562b-48fa-a4f5-fbb5ee46ecb1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1376",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.581Z",
            "success-count": 1
          },
          "uuid": "fd30c07c-be16-443d-8bce-1534f3d90c7f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1376)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:27.580Z",
            "success-count": 33
          },
          "uuid": "a9c3370a-0c49-4c63-878f-24cefe414519"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "91bc2ad1f4a6cb3f525daa89ba0c09dfd11f8eb2bee7beb1fa240a373fde76b1:eth0",
        "container-id": "91bc2ad1f4a6cb3f525daa89ba0c09dfd11f8eb2bee7beb1fa240a373fde76b1",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-p9lln",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-p9lln"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 157096,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:29Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.16",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ee:33:02:84:4c:4a",
        "interface-index": 21,
        "interface-name": "lxc8ec32609c67b",
        "mac": "3a:d2:94:f0:73:39"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 157096,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 157096,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1376

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1376

```
Timestamp              Status   State                   Message
2024-10-24T09:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:15Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:50Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:03Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:03Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:02Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:02Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 157096

```
ID       LABELS
157096   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 1730

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    210657   1985      0        
Allow    Ingress     1          ANY          NONE         disabled    219058   2283      0        
Allow    Egress      0          ANY          NONE         disabled    282044   2549      0        

```


#### BPF CT List 1730

```
Invalid argument: unknown type 1730
```


#### Endpoint Get 1730

```
[
  {
    "id": 1730,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1730-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "48fcadaf-66ff-4eee-8c14-0c16d54388e2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1730",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:23:38.309Z",
            "success-count": 2
          },
          "uuid": "f608b630-8354-473e-b2b2-c918dc15e444"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-6c945c9c98-gw6dk",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:38.307Z",
            "success-count": 1
          },
          "uuid": "68f08b0c-0a62-4f61-a784-5eb4b8fef23c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1730",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:38.341Z",
            "success-count": 1
          },
          "uuid": "901aff3b-9426-40ce-836e-a5610b8fb639"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1730)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:28.352Z",
            "success-count": 43
          },
          "uuid": "78dd8e63-1200-4139-aebb-0d2522b91068"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "32900b64d042b63e98455ffca2b57bcbfed4ff106b9fba92a7d13ea7ba2a7c61:eth0",
        "container-id": "32900b64d042b63e98455ffca2b57bcbfed4ff106b9fba92a7d13ea7ba2a7c61",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-6c945c9c98-gw6dk",
        "pod-name": "kube-system/clustermesh-apiserver-6c945c9c98-gw6dk"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 147144,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=6c945c9c98"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.56",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "52:02:c3:e2:71:bd",
        "interface-index": 15,
        "interface-name": "lxca1524ecddb2b",
        "mac": "62:d9:c0:b3:ab:0a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 147144,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 147144,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1730

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1730

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:18:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:38Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:18:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:18:38Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:18:38Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 147144

```
ID       LABELS
147144   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1997

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23082   287       0        
Allow    Ingress     1          ANY          NONE         disabled    7240    82        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1997

```
Invalid argument: unknown type 1997
```


#### Endpoint Get 1997

```
[
  {
    "id": 1997,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1997-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "32c361ca-fac4-45b3-9fc4-b3f615be90db"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1997",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:21:17.971Z",
            "success-count": 2
          },
          "uuid": "861a6471-2890-4730-8014-69633c4ee5aa"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1997",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:16:21.769Z",
            "success-count": 1
          },
          "uuid": "e56a4c32-75bb-486a-96b7-bf340f87930e"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.39",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "36:4b:e0:4e:c1:79",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "7a:83:71:9f:4d:af"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1997

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1997

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:58Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:30Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:21Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:16:21Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:16:21Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:16:21Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-24T09:16:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:16:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:16:17Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:16:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:16:17Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:16:16Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 3112

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3112

```
Invalid argument: unknown type 3112
```


#### Endpoint Get 3112

```
[
  {
    "id": 3112,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3112-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "04df864a-28d9-438e-bd18-b5a18a813dc8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3112",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.807Z",
            "success-count": 2
          },
          "uuid": "fa4de291-fed8-46df-9b91-f2e52771f769"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-2cghr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.805Z",
            "success-count": 1
          },
          "uuid": "7e454e07-04a7-450f-a2f5-2fcfdf94f236"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3112",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.856Z",
            "success-count": 1
          },
          "uuid": "4aa9d4c9-bae0-4e2a-b080-091cc8f7ceea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (3112)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.840Z",
            "success-count": 33
          },
          "uuid": "b3d78dfd-1ca6-46d9-a2cd-ce7a51041c2a"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7d070ce3487e19843762dfda4f27be66fb88d1c95f69af36ef4a25dfd439a631:eth0",
        "container-id": "7d070ce3487e19843762dfda4f27be66fb88d1c95f69af36ef4a25dfd439a631",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-2cghr",
        "pod-name": "cilium-test-1/client-974f6c69d-2cghr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 151863,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh2",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:53Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.1.0.252",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "aa:72:7d:a9:64:2b",
        "interface-index": 17,
        "interface-name": "lxc7c42cc664569",
        "mac": "a2:9e:bd:f8:fd:03"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 151863,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 151863,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3112

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3112

```
Timestamp              Status   State                   Message
2024-10-24T09:24:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:10Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:09Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:29Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:29Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:00Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:58Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:53Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:53Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:53Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:53Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:50Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:50Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:47Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:42Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:42Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:42Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:26Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:26Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:26Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:25Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:23Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:23Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests

```


#### Identity get 151863

```
ID       LABELS
151863   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh2
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.166.57:443 (active)     
                                          2 => 172.31.248.255:443 (active)    
2    10.100.57.203:443     ClusterIP      1 => 172.31.234.224:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.1.0.64:53 (active)          
                                          2 => 10.1.0.196:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.1.0.196:9153 (active)       
                                          2 => 10.1.0.64:9153 (active)        
5    10.100.199.121:2379   ClusterIP      1 => 10.1.0.56:2379 (active)        
6    10.100.154.88:8080    ClusterIP      1 => 10.1.0.16:8080 (active)        
```

#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=9) "10.1.0.39": (string) (len=6) "health",
  (string) (len=10) "10.1.0.196": (string) (len=36) "kube-system/coredns-586b798467-qbnzz",
  (string) (len=9) "10.1.0.64": (string) (len=36) "kube-system/coredns-586b798467-q2jt9",
  (string) (len=10) "10.1.0.252": (string) (len=36) "cilium-test-1/client-974f6c69d-2cghr",
  (string) (len=9) "10.1.0.56": (string) (len=50) "kube-system/clustermesh-apiserver-6c945c9c98-gw6dk",
  (string) (len=9) "10.1.0.21": (string) (len=37) "cilium-test-1/client2-57cf4468f-z8v9j",
  (string) (len=9) "10.1.0.16": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-p9lln",
  (string) (len=8) "10.1.0.5": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.234.224": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001b920b0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x40024aaf60,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x40024aaf60,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000771550)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40007718c0)(frontends:[10.100.57.203]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4000771970)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400399c6e0)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40038b7d90)(frontends:[10.100.199.121]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x4001f344d0)(frontends:[10.100.154.88]/ports=[http]/selector=map[name:echo-same-node])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001226da0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003b3fba0)(172.31.166.57:443/TCP,172.31.248.255:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001226da8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-l847w": (*k8s.Endpoints)(0x40034a1a00)(172.31.234.224:4244/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001226db0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-fj28q": (*k8s.Endpoints)(0x40031252b0)(10.1.0.196:53/TCP[us-east-1b],10.1.0.196:53/UDP[us-east-1b],10.1.0.196:9153/TCP[us-east-1b],10.1.0.64:53/TCP[us-east-1b],10.1.0.64:53/UDP[us-east-1b],10.1.0.64:9153/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40012262c8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-ct8kz": (*k8s.Endpoints)(0x40034a05b0)(10.1.0.56:2379/TCP[us-east-1b])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x4001226010)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-hx29q": (*k8s.Endpoints)(0x400382c5b0)(10.1.0.16:8080/TCP[us-east-1b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001e78000)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400217cdc0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x40043102e8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400218c7e0,
  gcExited: (chan struct {}) 0x400218c840,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001e22500)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015cc708)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66ae0)({
       metricMap: (*prometheus.metricMap)(0x4001e66b10)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76000)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001e22580)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015cc710)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66b70)({
       metricMap: (*prometheus.metricMap)(0x4001e66ba0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76060)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001e22600)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc718)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66c00)({
       metricMap: (*prometheus.metricMap)(0x4001e66c30)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e760c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001e22680)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc720)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66c90)({
       metricMap: (*prometheus.metricMap)(0x4001e66cc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76120)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001e22700)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc728)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66d20)({
       metricMap: (*prometheus.metricMap)(0x4001e66d50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76180)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001e22780)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc730)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66db0)({
       metricMap: (*prometheus.metricMap)(0x4001e66de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e761e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001e22800)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc738)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66e40)({
       metricMap: (*prometheus.metricMap)(0x4001e66e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76240)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001e22880)({
     GaugeVec: (*prometheus.GaugeVec)(0x40015cc740)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66ed0)({
       metricMap: (*prometheus.metricMap)(0x4001e66f00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e762a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001e22900)({
     ObserverVec: (*prometheus.HistogramVec)(0x40015cc748)({
      MetricVec: (*prometheus.MetricVec)(0x4001e66f60)({
       metricMap: (*prometheus.metricMap)(0x4001e66f90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001e76300)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001e78000)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40024be2a0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40017f35a8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium environment keys

```
disable-envoy-version-check:false
enable-ipsec-xfrm-state-caching:true
enable-bpf-clock-probe:false
egress-gateway-policy-map-max:16384
ipv6-service-range:auto
bpf-lb-acceleration:disabled
bpf-lb-rss-ipv4-src-cidr:
max-connected-clusters:255
bpf-filter-priority:1
policy-cidr-match-mode:
k8s-require-ipv4-pod-cidr:false
mesh-auth-mutual-connect-timeout:5s
http-retry-timeout:0
egress-masquerade-interfaces:ens+
kvstore-connectivity-timeout:2m0s
enable-host-port:false
k8s-kubeconfig-path:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
ipv4-range:auto
identity-change-grace-period:5s
bpf-lb-map-max:65536
policy-audit-mode:false
enable-xdp-prefilter:false
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
read-cni-conf:
bpf-policy-map-max:16384
enable-gateway-api:false
enable-stale-cilium-endpoint-cleanup:true
hubble-metrics:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
tunnel-port:0
conntrack-gc-max-interval:0s
hubble-skip-unknown-cgroup-ids:true
procfs:/host/proc
enable-host-legacy-routing:false
mesh-auth-spire-admin-socket:
disable-external-ip-mitigation:false
enable-k8s-api-discovery:false
tofqdns-endpoint-max-ip-per-hostname:50
proxy-max-requests-per-connection:0
envoy-base-id:0
config:
auto-create-cilium-node-resource:true
nat-map-stats-interval:30s
max-internal-timer-delay:0s
enable-envoy-config:false
service-no-backend-response:reject
enable-recorder:false
dnsproxy-concurrency-limit:0
cluster-pool-ipv4-mask-size:24
enable-identity-mark:true
identity-restore-grace-period:30s
cilium-endpoint-gc-interval:5m0s
node-port-acceleration:disabled
enable-ipv6-big-tcp:false
config-dir:/tmp/cilium/config-map
pprof-address:localhost
dnsproxy-lock-timeout:500ms
hubble-disable-tls:false
enable-k8s:true
cni-log-file:/var/run/cilium/cilium-cni.log
vtep-mac:
envoy-config-retry-interval:15s
proxy-admin-port:0
enable-k8s-endpoint-slice:true
hubble-monitor-events:
bpf-ct-timeout-service-tcp:2h13m20s
lib-dir:/var/lib/cilium
agent-liveness-update-interval:1s
tofqdns-idle-connection-grace-period:0s
bpf-node-map-max:16384
enable-ipv6-ndp:false
http-normalize-path:true
max-controller-interval:0
dnsproxy-concurrency-processing-grace-period:0s
hubble-drop-events-reasons:auth_required,policy_denied
hubble-export-allowlist:
enable-ipv6-masquerade:true
hubble-export-file-max-size-mb:10
bypass-ip-availability-upon-restore:false
tofqdns-enable-dns-compression:true
dns-max-ips-per-restored-rule:1000
pprof-port:6060
envoy-keep-cap-netbindservice:false
unmanaged-pod-watcher-interval:15
policy-accounting:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
proxy-idle-timeout-seconds:60
ipv4-service-loopback-address:169.254.42.1
enable-k8s-terminating-endpoint:true
restore:true
bpf-events-trace-enabled:true
enable-bpf-masquerade:false
enable-auto-protect-node-port-range:true
debug:false
bgp-announce-lb-ip:false
kvstore-opt:
k8s-require-ipv6-pod-cidr:false
proxy-prometheus-port:0
enable-k8s-networkpolicy:true
bpf-lb-dsr-l4-xlate:frontend
bpf-auth-map-max:524288
nat-map-stats-entries:32
api-rate-limit:
trace-sock:true
hubble-redact-http-headers-deny:
gops-port:9890
enable-health-check-loadbalancer-ip:false
enable-bbr:false
hubble-recorder-sink-queue-size:1024
exclude-local-address:
enable-ipv6:false
enable-icmp-rules:true
synchronize-k8s-nodes:true
ipv6-node:auto
bpf-map-dynamic-size-ratio:0.0025
bpf-root:/sys/fs/bpf
cluster-health-port:4240
log-driver:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
tofqdns-pre-cache:
k8s-api-server:
enable-bgp-control-plane:false
mesh-auth-enabled:true
proxy-xff-num-trusted-hops-ingress:0
policy-queue-size:100
k8s-sync-timeout:3m0s
enable-local-node-route:true
l2-pod-announcements-interface:
tofqdns-max-deferred-connection-deletes:10000
enable-well-known-identities:false
enable-ipip-termination:false
enable-ipv4-fragment-tracking:true
enable-l2-pod-announcements:false
bgp-announce-pod-cidr:false
custom-cni-conf:false
install-iptables-rules:true
bpf-lb-rss-ipv6-src-cidr:
cni-external-routing:false
hubble-listen-address::4244
hubble-redact-http-userinfo:true
encrypt-interface:
datapath-mode:veth
enable-cilium-api-server-access:
exclude-node-label-patterns:
bpf-ct-timeout-regular-tcp-fin:10s
enable-node-selector-labels:false
allocator-list-timeout:3m0s
mtu:0
allow-icmp-frag-needed:true
version:false
bpf-lb-source-range-map-max:0
monitor-queue-size:0
enable-ipv4-egress-gateway:false
bpf-ct-timeout-service-any:1m0s
egress-gateway-reconciliation-trigger-interval:1s
bpf-lb-maglev-table-size:16381
pprof:false
l2-announcements-renew-deadline:5s
tofqdns-min-ttl:0
enable-policy:default
proxy-portrange-min:10000
local-router-ipv6:
bpf-lb-sock:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
enable-host-firewall:false
enable-custom-calls:false
vtep-mask:
bpf-map-event-buffers:
http-retry-count:3
identity-gc-interval:15m0s
ipv6-cluster-alloc-cidr:f00d::/64
enable-active-connection-tracking:false
proxy-portrange-max:20000
mke-cgroup-mount:
bpf-lb-mode:snat
enable-vtep:false
local-router-ipv4:
enable-session-affinity:false
container-ip-local-reserved-ports:auto
hubble-export-file-max-backups:5
enable-masquerade-to-route-source:false
enable-ipv4:true
k8s-client-connection-timeout:30s
mesh-auth-signal-backoff-duration:1s
enable-high-scale-ipcache:false
kvstore-periodic-sync:5m0s
hubble-export-denylist:
labels:
join-cluster:false
enable-ipv4-masquerade:true
mesh-auth-queue-size:1024
identity-heartbeat-timeout:30m0s
monitor-aggregation-flags:all
http-idle-timeout:0
bpf-lb-service-backend-map-max:0
bpf-ct-timeout-regular-tcp:2h13m20s
clustermesh-ip-identities-sync-timeout:1m0s
enable-ipsec-key-watcher:true
ipv4-node:auto
cmdref:
hubble-redact-enabled:false
bpf-lb-service-map-max:0
enable-mke:false
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
hubble-export-file-path:
cflags:
hubble-export-fieldmask:
bpf-lb-maglev-map-max:0
enable-svc-source-range-check:true
endpoint-queue-size:25
kube-proxy-replacement:false
hubble-drop-events-interval:2m0s
debug-verbose:
enable-wireguard-userspace-fallback:false
enable-nat46x64-gateway:false
bpf-ct-timeout-regular-tcp-syn:1m0s
node-port-mode:snat
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
hubble-redact-http-urlquery:false
enable-ingress-controller:false
state-dir:/var/run/cilium
monitor-aggregation:medium
enable-ipsec:false
k8s-client-qps:10
dnsproxy-socket-linger-timeout:10
dns-policy-unload-on-shutdown:false
ipv6-mcast-device:
multicast-enabled:false
fqdn-regex-compile-lru-size:1024
bpf-neigh-global-max:524288
k8s-namespace:kube-system
enable-ipv4-big-tcp:false
hubble-prefer-ipv6:false
enable-cilium-health-api-server-access:
routing-mode:tunnel
direct-routing-device:
gateway-api-secrets-namespace:
ipv4-native-routing-cidr:
bpf-sock-rev-map-max:262144
enable-wireguard:false
crd-wait-timeout:5m0s
clustermesh-enable-endpoint-sync:false
node-labels:
bpf-events-policy-verdict-enabled:true
disable-iptables-feeder-rules:
http-max-grpc-timeout:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-l7-proxy:true
bpf-ct-timeout-regular-any:1m0s
tofqdns-proxy-response-max-delay:100ms
clustermesh-sync-timeout:1m0s
prepend-iptables-chains:true
metrics:
kvstore-max-consecutive-quorum-errors:2
bpf-events-drop-enabled:true
enable-ipsec-encrypted-overlay:false
ingress-secrets-namespace:
socket-path:/var/run/cilium/cilium.sock
enable-tcx:true
enable-local-redirect-policy:false
enable-route-mtu-for-cni-chaining:false
bpf-lb-sock-hostns-only:false
direct-routing-skip-unreachable:false
tofqdns-proxy-port:0
enable-pmtu-discovery:false
vtep-cidr:
install-no-conntrack-iptables-rules:false
enable-node-port:false
hubble-drop-events:false
cni-exclusive:true
operator-prometheus-serve-addr::9963
iptables-random-fully:false
ipam-default-ip-pool:default
use-full-tls-context:false
ipv6-range:auto
node-port-range:
bpf-lb-external-clusterip:false
ipsec-key-file:
enable-hubble-recorder-api:true
kube-proxy-replacement-healthz-bind-address:
enable-sctp:false
nodes-gc-interval:5m0s
static-cnp-path:
local-max-addr-scope:252
use-cilium-internal-ip-for-ipsec:false
wireguard-persistent-keepalive:0s
encrypt-node:false
route-metric:0
endpoint-bpf-prog-watchdog-interval:30s
l2-announcements-retry-period:2s
enable-encryption-strict-mode:false
enable-xt-socket-fallback:true
bpf-lb-dsr-dispatch:opt
log-opt:
hubble-export-file-compress:false
bpf-lb-rev-nat-map-max:0
enable-hubble:true
bpf-ct-global-any-max:262144
ipam-cilium-node-update-rate:15s
controller-group-metrics:
nodeport-addresses:
cluster-name:cmesh2
hubble-metrics-server:
enable-metrics:true
dnsproxy-enable-transparent-mode:true
trace-payloadlen:128
tunnel-protocol:vxlan
allow-localhost:auto
enable-health-checking:true
cgroup-root:/run/cilium/cgroupv2
dnsproxy-insecure-skip-transparent-mode-check:false
bpf-ct-timeout-service-tcp-grace:1m0s
iptables-lock-timeout:5s
node-port-bind-protection:true
auto-direct-node-routes:false
ipam:cluster-pool
enable-endpoint-health-checking:true
set-cilium-is-up-condition:true
monitor-aggregation-interval:5s
endpoint-gc-interval:5m0s
prometheus-serve-addr:
annotate-k8s-node:false
hubble-redact-http-headers-allow:
cni-chaining-mode:none
enable-runtime-device-detection:true
ipv4-service-range:auto
force-device-detection:false
enable-health-check-nodeport:true
kvstore-lease-ttl:15m0s
ipam-multi-pool-pre-allocation:
derive-masq-ip-addr-from-device:
fixed-identity-mapping:
k8s-client-burst:20
config-sources:config-map:kube-system/cilium-config
hubble-recorder-storage-path:/var/run/cilium/pcaps
hubble-socket-path:/var/run/cilium/hubble.sock
cluster-id:2
conntrack-gc-interval:0s
http-request-timeout:3600
proxy-max-connection-duration-seconds:0
node-port-algorithm:random
enable-monitor:true
ipv4-pod-subnets:
envoy-config-timeout:2m0s
egress-multi-home-ip-rule-compat:false
encryption-strict-mode-allow-remote-node-identities:false
proxy-xff-num-trusted-hops-egress:0
certificates-directory:/var/run/cilium/certs
vlan-bpf-bypass:
log-system-load:false
proxy-gid:1337
hubble-event-buffer-capacity:4095
agent-labels:
agent-health-port:9879
hubble-event-queue-size:0
set-cilium-node-taints:true
hubble-redact-kafka-apikey:false
envoy-log:
cni-chaining-target:
enable-endpoint-routes:false
kvstore:
mesh-auth-gc-interval:5m0s
identity-allocation-mode:crd
remove-cilium-node-taints:true
bpf-lb-affinity-map-max:0
label-prefix-file:
preallocate-bpf-maps:false
enable-bpf-tproxy:false
bpf-fragments-map-max:8192
tofqdns-dns-reject-response-code:refused
envoy-secrets-namespace:
enable-bandwidth-manager:false
bpf-ct-global-tcp-max:524288
k8s-service-proxy-name:
clustermesh-enable-mcs-api:false
enable-service-topology:false
enable-cilium-endpoint-slice:false
policy-trigger-interval:1s
ipsec-key-rotation-duration:5m0s
k8s-heartbeat-timeout:30s
mesh-auth-rotated-identities-queue-size:1024
srv6-encap-mode:reduced
disable-endpoint-crd:false
enable-external-ips:false
enable-l2-neigh-discovery:true
vtep-endpoint:
hubble-flowlogs-config-path:
bpf-policy-map-full-reconciliation-interval:15m0s
cluster-pool-ipv4-cidr:10.1.0.0/16
dnsproxy-lock-count:131
arping-refresh-period:30s
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
l2-announcements-lease-duration:15s
clustermesh-config:/var/lib/cilium/clustermesh/
enable-tracing:false
ipv6-native-routing-cidr:
bpf-lb-algorithm:random
enable-unreachable-routes:false
k8s-client-connection-keep-alive:30s
enable-l2-announcements:false
enable-srv6:false
operator-api-serve-addr:127.0.0.1:9234
encryption-strict-mode-cidr:
keep-config:false
bpf-nat-global-max:524288
proxy-connect-timeout:2
external-envoy-proxy:true
mesh-auth-mutual-listener-port:0
ipv6-pod-subnets:
k8s-service-cache-size:128
bpf-lb-sock-terminate-pod-connections:false
enable-ip-masq-agent:false
devices:
```


#### Policy get

```
:
 []
Revision: 157

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37764746                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37764746                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37764746                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006400000 rw-p 00000000 00:00 0 
4006400000-4008000000 ---p 00000000 00:00 0 
ffff69425000-ffff69536000 rw-p 00000000 00:00 0 
ffff69536000-ffff69577000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff69577000-ffff695b8000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff695b8000-ffff695ba000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff695ba000-ffff695bc000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff695bc000-ffff69bc3000 rw-p 00000000 00:00 0 
ffff69bc3000-ffff69cc3000 rw-p 00000000 00:00 0 
ffff69cc3000-ffff69cd4000 rw-p 00000000 00:00 0 
ffff69cd4000-ffff6bcd4000 rw-p 00000000 00:00 0 
ffff6bcd4000-ffff6bd54000 ---p 00000000 00:00 0 
ffff6bd54000-ffff6bd55000 rw-p 00000000 00:00 0 
ffff6bd55000-ffff8bd54000 ---p 00000000 00:00 0 
ffff8bd54000-ffff8bd55000 rw-p 00000000 00:00 0 
ffff8bd55000-ffffabce4000 ---p 00000000 00:00 0 
ffffabce4000-ffffabce5000 rw-p 00000000 00:00 0 
ffffabce5000-ffffafcd6000 ---p 00000000 00:00 0 
ffffafcd6000-ffffafcd7000 rw-p 00000000 00:00 0 
ffffafcd7000-ffffb04d4000 ---p 00000000 00:00 0 
ffffb04d4000-ffffb04d5000 rw-p 00000000 00:00 0 
ffffb04d5000-ffffb05d4000 ---p 00000000 00:00 0 
ffffb05d4000-ffffb0634000 rw-p 00000000 00:00 0 
ffffb0634000-ffffb0636000 r--p 00000000 00:00 0                          [vvar]
ffffb0636000-ffffb0637000 r-xp 00000000 00:00 0                          [vdso]
ffffff537000-ffffff558000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.1.0.0/24, 
Allocated addresses:
  10.1.0.16 (cilium-test-1/echo-same-node-86d9cc975c-p9lln)
  10.1.0.196 (kube-system/coredns-586b798467-qbnzz)
  10.1.0.21 (cilium-test-1/client2-57cf4468f-z8v9j)
  10.1.0.252 (cilium-test-1/client-974f6c69d-2cghr)
  10.1.0.39 (health)
  10.1.0.5 (router)
  10.1.0.56 (kube-system/clustermesh-apiserver-6c945c9c98-gw6dk)
  10.1.0.64 (kube-system/coredns-586b798467-q2jt9)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 446817dd4098122e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    11s ago        never        0       no error   
  ct-map-pressure                                                     12s ago        never        0       no error   
  daemon-validate-config                                              1m4s ago       never        0       no error   
  dns-garbage-collector-job                                           15s ago        never        0       no error   
  endpoint-1341-regeneration-recovery                                 never          never        0       no error   
  endpoint-1376-regeneration-recovery                                 never          never        0       no error   
  endpoint-1730-regeneration-recovery                                 never          never        0       no error   
  endpoint-1997-regeneration-recovery                                 never          never        0       no error   
  endpoint-216-regeneration-recovery                                  never          never        0       no error   
  endpoint-303-regeneration-recovery                                  never          never        0       no error   
  endpoint-3112-regeneration-recovery                                 never          never        0       no error   
  endpoint-359-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m15s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                12s ago        never        0       no error   
  ipcache-inject-labels                                               12s ago        never        0       no error   
  k8s-heartbeat                                                       15s ago        never        0       no error   
  link-cache                                                          12s ago        never        0       no error   
  local-identity-checkpoint                                           32s ago        never        0       no error   
  node-neighbor-link-updater                                          12s ago        never        0       no error   
  remote-etcd-cmesh1                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m32s ago      never        0       no error   
  resolve-identity-1341                                               4m11s ago      never        0       no error   
  resolve-identity-1376                                               11s ago        never        0       no error   
  resolve-identity-1730                                               1m51s ago      never        0       no error   
  resolve-identity-1997                                               4m11s ago      never        0       no error   
  resolve-identity-216                                                13s ago        never        0       no error   
  resolve-identity-303                                                4m11s ago      never        0       no error   
  resolve-identity-3112                                               13s ago        never        0       no error   
  resolve-identity-359                                                4m12s ago      never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-2cghr                 5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-z8v9j                5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-p9lln        5m11s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-6c945c9c98-gw6dk   6m51s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-q2jt9                 9m11s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-qbnzz                 9m11s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      9m12s ago      never        0       no error   
  sync-policymap-1341                                                 9m7s ago       never        0       no error   
  sync-policymap-1376                                                 5m11s ago      never        0       no error   
  sync-policymap-1730                                                 6m51s ago      never        0       no error   
  sync-policymap-1997                                                 9m7s ago       never        0       no error   
  sync-policymap-216                                                  5m13s ago      never        0       no error   
  sync-policymap-303                                                  9m7s ago       never        0       no error   
  sync-policymap-3112                                                 5m13s ago      never        0       no error   
  sync-policymap-359                                                  9m11s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1341)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1376)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1730)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (216)                                    13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (303)                                    11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (3112)                                   13s ago        never        0       no error   
  sync-utime                                                          12s ago        never        0       no error   
  write-cni-file                                                      9m15s ago      never        0       no error   
Proxy Status:            OK, ip 10.1.0.5, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 131072, max 196607
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 22.78   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```
