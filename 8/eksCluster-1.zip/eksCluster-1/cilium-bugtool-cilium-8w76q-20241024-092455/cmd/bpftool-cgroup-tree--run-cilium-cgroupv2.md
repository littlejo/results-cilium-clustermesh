CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0438a68_fb54_4604_8bbb_efa8d9d5ffae.slice/cri-containerd-c295f1795badc9aca30b598eb6dba6981a59bfc7c60423e28f41505dd05d9767.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0438a68_fb54_4604_8bbb_efa8d9d5ffae.slice/cri-containerd-76e0e4c36d04c7ca1f8c9b76016287ff27662e19937bdcb66f87096b802c44ec.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a3d9c4f_2f68_4b4c_8cf8_1278449b33cd.slice/cri-containerd-49ecf0e19ba9d8fbc24a2c2829de8e8289f02f4654c59ccd5ec7be2ca82ff5d2.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a3d9c4f_2f68_4b4c_8cf8_1278449b33cd.slice/cri-containerd-27302399e81d8d980af842a06e1143d4534a045be4395f3c9394f9f57fd4e07e.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd911ef3d_6a5e_44f1_8ea7_73d6b4a81b4f.slice/cri-containerd-817c4505cfbe67ee8fd3667d45eac66a63364f0c1884be11f7330f21bceceaef.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd911ef3d_6a5e_44f1_8ea7_73d6b4a81b4f.slice/cri-containerd-8c64457522907d34e5f2137139854794df118c6fde355819ec9ace86e2c87119.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac1a60a9_17a1_429a_b345_603afe6f0dff.slice/cri-containerd-0cf01e3699c4d073614f56d84b5b956025c99c71859799149c51034a1e9ad5c8.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac1a60a9_17a1_429a_b345_603afe6f0dff.slice/cri-containerd-7bf033aa5d29f7e293a1c0a7fff876d01a43e8f0d693edec4f7ee877bbae796d.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb9e7fe3_e1d7_4cd2_bc6e_7908c487d43c.slice/cri-containerd-4b263b80037fb36b8dd96b2ac9c1af5ed2bee1407d41f1212a7658768f0a3223.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb9e7fe3_e1d7_4cd2_bc6e_7908c487d43c.slice/cri-containerd-f4e924df41225d2aa6d16f0cb77b661118d8e5f90e51e6b8de3b3c67e1261623.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-b969c58c0769dced069a1a763a6bbf0e4995266110d8a333af826f82090b413b.scope
    624      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-72a37bbfbb9c624d90e89036a14eaeecc0d2b0285ccab915f97411068c7d68c5.scope
    616      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-32900b64d042b63e98455ffca2b57bcbfed4ff106b9fba92a7d13ea7ba2a7c61.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50592fd5_0aed_4440_9dcf_95111a910aeb.slice/cri-containerd-5a2a75c42c9f503c9e33450b5e1b0f7bc2d10ff73da328274daeb2161d644896.scope
    620      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cd1ea81_8bcc_4c54_85bd_3393df102ed4.slice/cri-containerd-7d070ce3487e19843762dfda4f27be66fb88d1c95f69af36ef4a25dfd439a631.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cd1ea81_8bcc_4c54_85bd_3393df102ed4.slice/cri-containerd-c5e4aaf1b66158e28f40e22355a23b8d240f418212b69e9f3e1d6ff68655d365.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41b574b1_ab9f_4691_b8bd_aeb666fe89cd.slice/cri-containerd-760aa2780654ab54bc0c6c7341ce6732e5d811a1a2ebeb5d6ecf4d3e581dba43.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41b574b1_ab9f_4691_b8bd_aeb666fe89cd.slice/cri-containerd-0dfa8c2d048f08a4b5a0f114043e5057c074c26a84106a66b90c4cf81ebb6c63.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc426254a_18e4_4c67_b5db_3b9b7542a43f.slice/cri-containerd-47f6e244fd36216cded0718d9b6d0fdc226107c9db69089f882ffcba5e221da4.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc426254a_18e4_4c67_b5db_3b9b7542a43f.slice/cri-containerd-dbc58d1d8282b12ecacff0b0d9d4171fef706fe9325e20b78f345b0161ec4f85.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8d4d6a0_d63a_420a_ae21_b75b5d4da315.slice/cri-containerd-881b35508da7f12c964a3d6cca48ae090979ea23a9534ce05e911a488c0220a3.scope
    685      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8d4d6a0_d63a_420a_ae21_b75b5d4da315.slice/cri-containerd-91bc2ad1f4a6cb3f525daa89ba0c09dfd11f8eb2bee7beb1fa240a373fde76b1.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf8d4d6a0_d63a_420a_ae21_b75b5d4da315.slice/cri-containerd-760a46b0301ce4fd18d83361b00438c6638ec1fafb173127fb2c5f0236bbb024.scope
    681      cgroup_device   multi                                          
