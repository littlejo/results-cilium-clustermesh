{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.820Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.846Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.862Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.891Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.286Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.313Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.326Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.363Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.379Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.625Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.650Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.668Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.703Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.706Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.054Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.102Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.105Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.144Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.159Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.228Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.416Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.422Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.461Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.495Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:43.506Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.908Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.921Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.978Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:46.000Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:46.024Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.179Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.200Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.225Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.264Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.265Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.620Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.661Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.674Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.715Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.726Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.750Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.979Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:49.989Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.043Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.062Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.092Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.374Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.425Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.430Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.484Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.512Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.525Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.710Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.764Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.795Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.809Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.833Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.127Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.180Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.200Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.219Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.244Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.257Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.508Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.512Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.513Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.543Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.896Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.916Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.969Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.987Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:59.012Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.463Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.471Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.473Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.483Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:00.518Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.173Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.174Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.220Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.231Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.257Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.504Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:05.506Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:14.090Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:14.094Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:15.478Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:22.213Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:22.507Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.239Z",
  "value": "id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.540Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.543Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.552Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.360Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.415Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.433Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.664Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.678Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.679Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.464Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.515Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.525Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.783Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.788Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:43.789Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:56.710Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:56.765Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:56.767Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:57.069Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:57.076Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:57.077Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:09.957Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:10.004Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:10.018Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:10.325Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:10.333Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:10.334Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:23.199Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:23.245Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:23.258Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:23.542Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:23.548Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:40.537Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:40.540Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:40.836Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:40.843Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:53.828Z",
  "value": "id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:53.837Z",
  "value": "id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50"
}

