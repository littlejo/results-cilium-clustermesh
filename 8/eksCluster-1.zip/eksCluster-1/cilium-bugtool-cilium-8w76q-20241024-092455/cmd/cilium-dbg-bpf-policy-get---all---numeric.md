Endpoint ID: 216
Path: /sys/fs/bpf/tc/globals/cilium_policy_00216

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 303
Path: /sys/fs/bpf/tc/globals/cilium_policy_00303

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4138    46        0        
Allow    Ingress     1          ANY          NONE         disabled    50245   576       0        
Allow    Egress      0          ANY          NONE         disabled    12495   126       0        


Endpoint ID: 359
Path: /sys/fs/bpf/tc/globals/cilium_policy_00359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1341
Path: /sys/fs/bpf/tc/globals/cilium_policy_01341

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    7238    78        0        
Allow    Ingress     1          ANY          NONE         disabled    50602   583       0        
Allow    Egress      0          ANY          NONE         disabled    12335   125       0        


Endpoint ID: 1376
Path: /sys/fs/bpf/tc/globals/cilium_policy_01376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4605     36        0        
Allow    Ingress     1          ANY          NONE         disabled    298904   3484      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1730
Path: /sys/fs/bpf/tc/globals/cilium_policy_01730

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    210657   1985      0        
Allow    Ingress     1          ANY          NONE         disabled    219058   2283      0        
Allow    Egress      0          ANY          NONE         disabled    282044   2549      0        


Endpoint ID: 1997
Path: /sys/fs/bpf/tc/globals/cilium_policy_01997

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23016   286       0        
Allow    Ingress     1          ANY          NONE         disabled    7240    82        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3112
Path: /sys/fs/bpf/tc/globals/cilium_policy_03112

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


