alloc: 64.08MB (67196368 bytes)
total-alloc: 1.43GB (1537129960 bytes)
sys: 108.55MB (113823028 bytes)
lookups: 0
mallocs: 46576625
frees: 46064952
heap-alloc: 64.08MB (67196368 bytes)
heap-sys: 93.27MB (97796096 bytes)
heap-idle: 14.30MB (14999552 bytes)
heap-in-use: 78.96MB (82796544 bytes)
heap-released: 1.39MB (1458176 bytes)
heap-objects: 511673
stack-in-use: 6.69MB (7012352 bytes)
stack-sys: 6.69MB (7012352 bytes)
stack-mspan-inuse: 1.14MB (1193280 bytes)
stack-mspan-sys: 1.23MB (1289280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 729.31KB (746817 bytes)
gc-sys: 4.72MB (4944360 bytes)
next-gc: when heap-alloc >= 81.59MB (85556520 bytes)
last-gc: 2024-10-24 09:24:53.446111084 +0000 UTC
gc-pause-total: 12.116572ms
gc-pause: 543623
gc-pause-end: 1729761893446111084
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0006429358954569035
enable-gc: true
debug-gc: false
