[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.1.0.39"
      },
      "ipv6": {}
    },
    "name": "cmesh2/ip-172-31-234-224.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.1.0.0/24",
        "enabled": true,
        "ip": "172.31.234.224"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.1.0.5"
      }
    ],
    "source": "local"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.7.0.123"
      },
      "ipv6": {}
    },
    "name": "cmesh8/ip-172-31-208-9.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.7.0.0/24",
        "enabled": true,
        "ip": "172.31.208.9"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.7.0.95"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.2.0.34"
      },
      "ipv6": {}
    },
    "name": "cmesh3/ip-172-31-140-200.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.2.0.0/24",
        "enabled": true,
        "ip": "172.31.140.200"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.2.0.161"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.4.0.105"
      },
      "ipv6": {}
    },
    "name": "cmesh5/ip-172-31-167-173.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.4.0.0/24",
        "enabled": true,
        "ip": "172.31.167.173"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.4.0.230"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.3.0.83"
      },
      "ipv6": {}
    },
    "name": "cmesh4/ip-172-31-224-68.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.3.0.0/24",
        "enabled": true,
        "ip": "172.31.224.68"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.3.0.17"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.0.0.193"
      },
      "ipv6": {}
    },
    "name": "cmesh1/ip-172-31-190-177.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.0.0.0/24",
        "enabled": true,
        "ip": "172.31.190.177"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.0.0.119"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.6.0.250"
      },
      "ipv6": {}
    },
    "name": "cmesh7/ip-172-31-162-53.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.6.0.0/24",
        "enabled": true,
        "ip": "172.31.162.53"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.6.0.102"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.5.0.80"
      },
      "ipv6": {}
    },
    "name": "cmesh6/ip-172-31-249-188.ec2.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.5.0.0/24",
        "enabled": true,
        "ip": "172.31.249.188"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.5.0.219"
      }
    ],
    "source": "clustermesh"
  }
]

