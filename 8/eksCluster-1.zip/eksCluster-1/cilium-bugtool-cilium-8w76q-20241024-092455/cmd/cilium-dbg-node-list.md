Name                                    IPv4 Address     Endpoint CIDR   IPv6 Address   Endpoint CIDR   Source
cmesh1/ip-172-31-190-177.ec2.internal   172.31.190.177   10.0.0.0/24                                    clustermesh
cmesh2/ip-172-31-234-224.ec2.internal   172.31.234.224   10.1.0.0/24                                    local
cmesh3/ip-172-31-140-200.ec2.internal   172.31.140.200   10.2.0.0/24                                    clustermesh
cmesh4/ip-172-31-224-68.ec2.internal    172.31.224.68    10.3.0.0/24                                    clustermesh
cmesh5/ip-172-31-167-173.ec2.internal   172.31.167.173   10.4.0.0/24                                    clustermesh
cmesh6/ip-172-31-249-188.ec2.internal   172.31.249.188   10.5.0.0/24                                    clustermesh
cmesh7/ip-172-31-162-53.ec2.internal    172.31.162.53    10.6.0.0/24                                    clustermesh
cmesh8/ip-172-31-208-9.ec2.internal     172.31.208.9     10.7.0.0/24                                    clustermesh
