29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:15:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:15:38+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:15:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:16:19+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 112
442: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:16:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 113
443: sched_cls  name tail_handle_ipv4  tag a9097fbac2272d33  gpl
	loaded_at 2024-10-24T09:16:19+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 114
444: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:16:19+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 115
467: sched_cls  name tail_handle_ipv4  tag 3d3c549940394f0a  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,100
	btf_id 142
468: sched_cls  name tail_ipv4_ct_egress  tag 5ddd65c490053496  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 145
472: sched_cls  name tail_ipv4_to_endpoint  tag de8f4561bafbd6c2  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,99,33,74,75,72,97,31,100,32,29,30
	btf_id 146
474: sched_cls  name tail_ipv4_ct_ingress  tag 1fce92a781e53ecd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,100,74,75,99,76
	btf_id 150
475: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,100
	btf_id 152
476: sched_cls  name cil_from_container  tag 14c3869efe7ae32e  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 100,68
	btf_id 153
478: sched_cls  name tail_handle_ipv4_cont  tag b6b148d07292c6e4  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,99,33,97,74,75,31,68,66,69,100,32,29,30,73
	btf_id 155
479: sched_cls  name tail_handle_arp  tag 91cc245db8341987  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,100
	btf_id 156
483: sched_cls  name handle_policy  tag 240b3cecfb292912  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,100,74,75,99,33,72,97,31,76,67,32,29,30
	btf_id 157
484: sched_cls  name __send_drop_notify  tag b82087d76c5d5434  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 161
485: sched_cls  name tail_handle_arp  tag 0eaef39142b4ec9e  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 163
488: sched_cls  name __send_drop_notify  tag 1ccdd6a3513da325  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 165
489: sched_cls  name tail_ipv4_ct_egress  tag 5ddd65c490053496  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 166
491: sched_cls  name cil_from_container  tag 815cb57f6fc95539  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 104,68
	btf_id 168
493: sched_cls  name tail_ipv4_ct_ingress  tag b4f27827b5c24694  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 170
494: sched_cls  name __send_drop_notify  tag 48918ea6b053e0c3  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 173
495: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 174
496: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 171
498: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 176
499: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 178
500: sched_cls  name tail_handle_ipv4_from_host  tag c37c4131bc27a499  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 179
504: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 184
505: sched_cls  name tail_handle_ipv4_from_host  tag c37c4131bc27a499  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,107
	btf_id 185
507: sched_cls  name __send_drop_notify  tag 48918ea6b053e0c3  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 187
508: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,107
	btf_id 188
509: sched_cls  name handle_policy  tag 063e428980752409  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,104,74,75,103,33,72,102,31,76,67,32,29,30
	btf_id 177
510: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,109,67
	btf_id 191
513: sched_cls  name tail_handle_ipv4_from_host  tag c37c4131bc27a499  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 194
515: sched_cls  name __send_drop_notify  tag 48918ea6b053e0c3  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 196
516: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 197
517: sched_cls  name tail_handle_arp  tag eae307cf33515439  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,112
	btf_id 199
518: sched_cls  name tail_handle_ipv4  tag 8c9d5b06e3912e80  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 189
519: sched_cls  name tail_handle_ipv4_cont  tag 84b331d0ea7b126d  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,103,33,102,74,75,31,68,66,69,104,32,29,30,73
	btf_id 201
520: sched_cls  name tail_handle_ipv4_cont  tag 179d57457b37e011  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,111,33,90,74,75,31,68,66,69,112,32,29,30,73
	btf_id 200
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,112
	btf_id 202
522: sched_cls  name tail_ipv4_to_endpoint  tag e539b3dd2f58f8d5  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,103,33,74,75,72,102,31,104,32,29,30
	btf_id 203
523: sched_cls  name tail_ipv4_to_endpoint  tag b1c08cb5710981e0  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,111,33,74,75,72,90,31,112,32,29,30
	btf_id 204
524: sched_cls  name __send_drop_notify  tag c6ddd72c4007d002  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 205
525: sched_cls  name cil_from_container  tag 468211573cb1af45  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,68
	btf_id 206
526: sched_cls  name tail_handle_ipv4  tag c60d048f0e62144f  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,112
	btf_id 207
527: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 208
529: sched_cls  name tail_ipv4_ct_ingress  tag b783f2d7512a8ed9  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,112,74,75,111,76
	btf_id 210
530: sched_cls  name handle_policy  tag bde42cb4019e1914  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,112,74,75,111,33,72,90,31,76,67,32,29,30
	btf_id 211
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
538: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
539: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:16:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
543: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
546: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:16:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
586: sched_cls  name tail_handle_arp  tag dc9e3fb0d9f4dca1  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,128
	btf_id 227
587: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,128
	btf_id 228
588: sched_cls  name tail_ipv4_ct_egress  tag 3bfa0fceee9a7f62  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 229
589: sched_cls  name tail_ipv4_to_endpoint  tag c31c94dd74781ee9  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,129,33,74,75,72,127,31,128,32,29,30
	btf_id 230
590: sched_cls  name tail_ipv4_ct_ingress  tag 18285742daf2b09c  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,128,74,75,129,76
	btf_id 231
591: sched_cls  name __send_drop_notify  tag 5cdf087472099638  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 232
592: sched_cls  name tail_handle_ipv4  tag 0fcd36981caca49f  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,128
	btf_id 233
593: sched_cls  name tail_handle_ipv4_cont  tag da4662fddcab1f9a  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,129,33,127,74,75,31,68,66,69,128,32,29,30,73
	btf_id 234
594: sched_cls  name handle_policy  tag 7a41dfd048c45794  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,128,74,75,129,33,72,127,31,76,67,32,29,30
	btf_id 235
595: sched_cls  name cil_from_container  tag 16f40be105fe52e1  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,68
	btf_id 236
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
613: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
616: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
617: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
620: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
621: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
624: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
666: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
669: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
682: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
685: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3326: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,633
	btf_id 3155
3327: sched_cls  name __send_drop_notify  tag 3aff3f5863fe890e  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3156
3328: sched_cls  name tail_handle_ipv4_cont  tag d8c02427f8a89010  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,634,33,145,74,75,31,68,66,69,633,32,29,30,73
	btf_id 3157
3329: sched_cls  name tail_ipv4_ct_egress  tag beb88bdab81c3b2b  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,633,74,75,634,76
	btf_id 3158
3330: sched_cls  name cil_from_container  tag 611c97934481a777  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,68
	btf_id 3159
3331: sched_cls  name handle_policy  tag aa9e65395770d2ca  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,633,74,75,634,33,72,145,31,76,67,32,29,30
	btf_id 3160
3333: sched_cls  name tail_ipv4_ct_ingress  tag a4e17d947a28cbd3  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,633,74,75,634,76
	btf_id 3162
3334: sched_cls  name tail_ipv4_to_endpoint  tag 18767c386d743af1  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,634,33,74,75,72,145,31,633,32,29,30
	btf_id 3163
3335: sched_cls  name tail_handle_ipv4  tag 02fef779140235f9  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,633
	btf_id 3164
3336: sched_cls  name tail_handle_arp  tag f8b16b216697ed52  gpl
	loaded_at 2024-10-24T09:23:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,633
	btf_id 3165
3623: sched_cls  name __send_drop_notify  tag c3fd09be0567e4ee  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3479
3624: sched_cls  name tail_handle_arp  tag fdf72152ec9103cc  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,687
	btf_id 3480
3625: sched_cls  name tail_handle_arp  tag 97e8425055e469fd  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,690
	btf_id 3483
3626: sched_cls  name tail_ipv4_ct_egress  tag 77b385e884b95a14  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,690,74,75,689,76
	btf_id 3484
3628: sched_cls  name tail_ipv4_to_endpoint  tag 3938173fa1b79561  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,688,33,74,75,72,140,31,687,32,29,30
	btf_id 3481
3630: sched_cls  name tail_ipv4_ct_ingress  tag 08263d58efe5344e  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,690,74,75,689,76
	btf_id 3486
3631: sched_cls  name tail_ipv4_ct_ingress  tag 949f3bac0bd5af5f  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,687,74,75,688,76
	btf_id 3488
3632: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,690
	btf_id 3489
3633: sched_cls  name cil_from_container  tag 95d6ca4b56cc60b9  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 690,68
	btf_id 3491
3634: sched_cls  name tail_ipv4_ct_egress  tag 00defe28154bc6ba  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,687,74,75,688,76
	btf_id 3490
3635: sched_cls  name tail_ipv4_to_endpoint  tag 44fa15e4573f6618  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,689,33,74,75,72,137,31,690,32,29,30
	btf_id 3492
3636: sched_cls  name tail_handle_ipv4  tag 3652576e1cf5a1ca  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,687
	btf_id 3493
3637: sched_cls  name handle_policy  tag 9932ca177c9fef33  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,690,74,75,689,33,72,137,31,76,67,32,29,30
	btf_id 3494
3638: sched_cls  name tail_handle_ipv4  tag d274062b35556d55  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,690
	btf_id 3496
3639: sched_cls  name __send_drop_notify  tag 3fb6b2abec554f2f  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3497
3640: sched_cls  name tail_handle_ipv4_cont  tag 26c150a9433dc8c0  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,689,33,137,74,75,31,68,66,69,690,32,29,30,73
	btf_id 3498
3641: sched_cls  name tail_handle_ipv4_cont  tag 78c8b8cf7dae2615  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,688,33,140,74,75,31,68,66,69,687,32,29,30,73
	btf_id 3495
3642: sched_cls  name cil_from_container  tag a6667409f9fbf9c8  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 687,68
	btf_id 3499
3643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,687
	btf_id 3500
3644: sched_cls  name handle_policy  tag 274c33e83d0cf440  gpl
	loaded_at 2024-10-24T09:24:53+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,687,74,75,688,33,72,140,31,76,67,32,29,30
	btf_id 3501
