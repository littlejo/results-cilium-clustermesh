key: d8 00 00 00  value: 3c 0e 00 00
key: 2f 01 00 00  value: e3 01 00 00
key: 3d 05 00 00  value: fd 01 00 00
key: 60 05 00 00  value: 03 0d 00 00
key: c2 06 00 00  value: 52 02 00 00
key: cd 07 00 00  value: 12 02 00 00
key: 28 0c 00 00  value: 35 0e 00 00
Found 7 elements
