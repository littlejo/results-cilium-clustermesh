goroutine 178 [running]:
runtime/pprof.writeGoroutineStacks({0xffff69444420, 0x4001422030})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6c
runtime/pprof.writeGoroutine({0xffff69444420?, 0x4001422030?}, 0x10?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x2c
runtime/pprof.(*Profile).WriteTo(0x61dd090?, {0xffff69444420?, 0x4001422030?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x148
github.com/google/gops/agent.handle({0xffff694443f8, 0x4001422030}, {0x4001c36938?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x23a0
github.com/google/gops/agent.listen({0x3e0bbf0, 0x40016f6c60})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x188
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x320

goroutine 1 [select, 9 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x40006a8b40, 0x40000274b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x104
github.com/cilium/hive.(*Hive).Run(0x40006a8b40, 0x40000274b0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0xe8
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x40007f2008, {0x377b213?, 0x4?, 0x377b083?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x170
github.com/spf13/cobra.(*Command).execute(0x40007f2008, {0x400013c010, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0x828
github.com/spf13/cobra.(*Command).ExecuteC(0x40007f2008)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x344
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0x40006a8b40?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x1c
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x64

goroutine 33 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000b3af60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 43 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x5c
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x8c

goroutine 56 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40026d0460)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 50 [select, 9 minutes]:
io.(*pipe).read(0x400020bec0, {0x4001a28000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001a28000?, 0x4000094e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000221f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400028a3f0, 0x400020bec0, 0x4000027430)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 51 [select, 9 minutes]:
io.(*pipe).read(0x400020bf20, {0x4001a48000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001a48000?, 0x4000095678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000223f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400028a3f0, 0x400020bf20, 0x4000027450)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 52 [select, 9 minutes]:
io.(*pipe).read(0x4001618000, {0x4001a8c000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001a8c000?, 0x4000095e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000224f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400028a3f0, 0x4001618000, 0x4000027470)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 53 [select, 9 minutes]:
io.(*pipe).read(0x4001618060, {0x4001c0c000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001c0c000?, 0x4000096678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000225f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400028a3f0, 0x4001618060, 0x4000027490)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 54 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40026d0280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1503 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40020db0e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fa780, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40019955c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 57 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x74
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x70

goroutine 58 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40026d0500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 59 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001bfcb50, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001bfcb40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0x4001acc900, {0x3e23828, 0x400216cc30})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xfc
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x10c
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x15c

goroutine 60 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x138
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1523 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1368
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1526 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031faf00, {{{0x3799d7a, 0xd}}, {0x0, 0x0}, 0x4001d53e00, 0x0, 0x40017ec390, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1531 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1512 [select, 4 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x3cc
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa8

goroutine 1502 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40031e2320)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1504 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1499 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fa3c0, {{{0x37b1743, 0x12}}, {0x0, 0x0}, 0x40017d1810, 0x0, 0x40017d1820, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 58
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11666 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4005349548, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4005349538)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4005349530, {0x40018a2001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001e4bcc8?}, {0x40018a2001?, 0x4001e4bcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x400556a140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x400556a140)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x400556a140, {0x30150e0, 0x4005100b58})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4005541590, {0x4001113500, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4005523b80, 0x0, {0x3e02238, 0x400593f640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000acdda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005503800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 179 [select, 5 minutes]:
github.com/cilium/statedb.graveyardWorker(0x4001e78000, {0x3e23828, 0x400217cdc0}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x12c
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x14c

goroutine 182 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003dd040, {{{0x379a274, 0xd}}, {0x0, 0x0}, 0x40016f6e20, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 250 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x2c
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x108

goroutine 167 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f4d78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400218e380?, 0x40026ac000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400218e380, {0x40026ac000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400218e380, {0x40026ac000?, 0x4000c39e78?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001226600, {0x40026ac000?, 0x40021b9868?, 0x1fd48?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003a4b698, {0x40026ac000?, 0x0?, 0x4003a4b698?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4001d33430, {0x3dd1940, 0x4003a4b698})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4001d33188, {0xffff696717b8, 0x400084f668}, 0x40021b99d0?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4001d33188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4001d33188, {0x40020df000, 0x1000, 0x4004c63950?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40020d7ec0, {0x400127a040, 0x9, 0x7?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40020d7ec0}, {0x400127a040, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400127a040, 0x9, 0x2f8ed20?}, {0x3dcc0a0?, 0x40020d7ec0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400127a000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
golang.org/x/net/http2.(*clientConnReadLoop).run(0x40021b9f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xd0
golang.org/x/net/http2.(*ClientConn).readLoop(0x4000c3d500)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x80
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 166
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xae0

goroutine 169 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e54fc0, {0x3e237f0, 0x4001bba720}, {0x3e2b960, 0x4002407aa0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x294
github.com/cilium/hive/job.(*jobOneShot).start(0x4001e76ba0, {0x3e237f0, 0x4001bba720}, 0xba7cf0?, {0x3e2b960, 0x4001e76840}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1402 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x4000f60e10, 0x21)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f60e00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40032864e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4adc0, {0x3e23828, 0x4001d3a5a0}, 0x4003235e60, {0x3e3b3b8, 0x40014677b8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 248 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0x4001e7e340, {0x3e23828?, 0x400096d810?}, 0x400268e1c0)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xa4
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x3c
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x304

goroutine 328 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40022bec80, {{{0x3791109, 0xb}}, {0x3e2b960, 0x4002427e00}, 0x4000ad8860, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 667 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400020a6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 398 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff699f42d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1b?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029c8780)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029c8780)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4002ab5c48?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001ca76b0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x40029b2a00, {0x3e0bc20, 0x4001ca76b0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x19c

goroutine 668 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40015bead0, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015beac0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400020a120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ae40, {0x3e23828, 0x400080aaa0}, 0x40026b6540, {0x3e3b410, 0x4001e16cf0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 395 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff699f4998, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x19?, 0x1fd48?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029c8480)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029c8480)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40021addc8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001ca7380)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x40002eeea0, {0x3e23828, 0x40007fd630}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xbc
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x144

goroutine 396 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0xffff699f47a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x17?, 0x967e0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029c8600)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029c8600)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40021b3d98?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).AcceptUnix(0x4001ca7500)
	/usr/local/go/src/net/unixsock.go:247 +0x2c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x124

goroutine 455 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 400
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 335 [select, 9 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e55100, {0x3e237f0, 0x4001c5fcb0}, {0x3e2b960, 0x400297d320})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x298
github.com/cilium/hive/job.(*jobOneShot).start(0x4001e77f20, {0x3e237f0, 0x4001c5fcb0}, 0x40023db020?, {0x3e2b960, 0x4001e77c80}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 847 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001147d80}, {0xffff696068e8, 0x4000771a20}, {0x3e672a8, 0x36f6aa0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001e7c1c0, {0x0?, 0x0?}, 0x4001a61380, 0x40029f0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001e7c1c0, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002963f40, {0x3ddab60, 0x4000906190}, 0x1, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001e7c1c0, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 842
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 330 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40016f6fc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 208 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 209
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 331 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e70e80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1447 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1433
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 329 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x6441140100baff01?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40023fa000?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1379 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e711c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 2983 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400213e6e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 2994
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 399 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40022aac80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 400 [select, 5 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x40026ecd80, {0x3e237f0, 0x4001cf50b0}, {0x3e2b960, 0x4002a74fc0})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x2d8
github.com/cilium/hive/job.(*jobOneShot).start(0x40024aaea0, {0x3e237f0, 0x4001cf50b0}, 0x4002399260?, {0x3e2b960, 0x40024aaba0}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 834 [select, 9 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x14c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x15c

goroutine 385 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40022aa8c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 397 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x38
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x184

goroutine 678 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400120e620, 0x40026ffe60, 0x4001e439e0, 0x4001afc480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 660
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 428 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x38
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 395
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0x88

goroutine 846 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 842
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1403 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 236 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40021e8a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 248
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 3165 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3f020, {0x3e23828, 0x4002b91ae0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3159
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 9509 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003be4780, 0x4000cd46c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003be4780, 0x8a6d4?, 0x400181d580?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 209 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x4000771208, 0x7)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40007711f8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40007711e0, 0x400181c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400137ba40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40021f0ec0, {0x3ddab40, 0x4001ba36e0}, 0x1, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40021f0ec0, 0x3b9aca00, 0x0, 0x1, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400137ba40, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400147c5c0, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 170
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 210 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 170
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 249 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x4001e26420, 0x40020f59e0, 0x40020f5aa0, 0x40020f5b00)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x1d0
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x4001e26420, {0x3e23828?, 0x40020daff0?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x3d8
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x4001e26420, {0x3e23828, 0x40020daff0})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x70
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x120

goroutine 3190 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3170 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f24ab0, {0x3e23828, 0x4002b0ce10})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 226 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 209
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 227 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005cf8480}, {0xffff696068e8, 0x40007711e0}, {0x3e672a8, 0x371cf40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400120e9a0, {0x0?, 0x0?}, 0x40021d86c0, 0x40020fc900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400120e9a0, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40021c7f40, {0x3ddab60, 0x40021e6140}, 0x1, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400120e9a0, 0x40021d86c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 209
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 213 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400120e9a0, 0x40021d86c0, 0x40020f4900, 0x40020fc900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 9510 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003be47c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003be47b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003be47b0, {0x400133d1ec, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40021dccc8?}, {0x400133d1ec?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4003be4780}, {0x400133d1ec, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400367f5c0, {0x4004ea7400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4001d3bb30, 0x0, {0x3e02238, 0x40047f1680})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001b89080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005cf8480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 227
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 238 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x400195af10, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400195af00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40021e8a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4afc0, {0x3e23828, 0x40021e65f0}, 0x40021d9380, {0x3e3b518, 0x40013a00f0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 248
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1533 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 666 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400020a120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1719 [select]:
github.com/servak/go-fastping.(*Pinger).run(0x4001378a20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x494
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1636
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x1b0

goroutine 390 [select]:
golang.org/x/time/rate.(*Limiter).wait(0x4003d7cc80, {0x3e23828, 0x40022b9ae0}, 0x1, {0x4004029918?, 0x1e301d0?, 0x6279580?}, 0x39bb3e8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:285 +0x320
golang.org/x/time/rate.(*Limiter).WaitN(0x4003d7cc80, {0x3e23828, 0x40022b9ae0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:248 +0x54
golang.org/x/time/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:233
github.com/cilium/cilium/pkg/node/manager.(*manager).singleBackgroundLoop(0x40019c1100, {0x3e23828, 0x40022b9ae0}, 0x1eb1e32e50)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:429 +0x114
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x40019c1100, {0x3e23828, 0x40022b9ae0})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:398 +0x1f8
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x78
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 336
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x50

goroutine 239 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 248
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 237 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40021e8ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 248
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 425 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 251 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x13, 0x400232fdb0, 0x10000, 0x0, 0x40018bc230, 0x400232fd64)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x50?, {0x400232fdb0?, 0x0?, 0x1400000050?}, 0x0?, 0x400391c830?, 0x40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x13, {0x400232fdb0, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x400391c830?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x70
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x30c

goroutine 252 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x2c
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x108

goroutine 253 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x14, 0x400234f940, 0x10000, 0x0, 0x40018bc2a0, 0x400234f8f4)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x74?, {0x400234f940?, 0x0?, 0x600001800000074?}, 0x0?, 0x4000960790?, 0x64?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x14, {0x400234f940, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x15?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x74
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x30c

goroutine 254 [chan receive, 9 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x2c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x100

goroutine 255 [syscall, 5 minutes]:
syscall.Syscall6(0xcf, 0x15, 0x400236fe90, 0x10000, 0x0, 0x4001e3ff10, 0x400236fe44)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x59c?, {0x400236fe90?, 0x0?, 0x100000059c?}, 0x0?, 0x4002bb7210?, 0x58c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x15, {0x400236fe90, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x400237fee8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x70
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 249
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x304

goroutine 256 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff699f4c80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40022a5c20?, 0x40028e3e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40022a5c20, {0x40028e3e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x40012268d8, {0x40028e3e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40017a80c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 257 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40005803c0, {{{0x379eee1, 0xe}}, {0x0, 0x0}, 0x4000ac4e00, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 258 [select, 9 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0x40026a7d40)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0xc0
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x318

goroutine 259 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x3e237f0, 0x4001c26210}, {0x3e62c10, 0x4001e78bd0}, {0x3e2b960, 0x40022a5f20}, 0x1, 0x400018a550, 0x40022cfd50, 0x40022cfd40, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x5c4
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x3e237f0, 0x4001c26210}, {0x3e2b960, 0x40022a5f20})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0xdc
github.com/cilium/hive/job.(*jobOneShot).start(0x4001e776e0, {0x3e237f0, 0x4001c26210}, 0x40021cd080?, {0x3e2b960, 0x4001e77680}, {{{0x400006fec0, 0x1, 0x1}}, 0x40003afb30, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 336 [chan receive, 9 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x40022b9a90, {0x3e23828, 0x40022b9ae0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x60
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x134

goroutine 1532 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 264 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 259
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 551 [select, 5 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x40024c9b00)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x74
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x60

goroutine 3242 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002541208)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3172
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 669 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 456 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 400
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 670 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0x9c
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1d4

goroutine 1376 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400322bb80, {{{0x37b8e08, 0x14}}, {0x3e2b960, 0x400322ed20}, 0x400162f4a0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 689 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400020a8a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 690 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400020aa20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 691 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40015bf050, 0x20)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015bf040)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400020a8a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x400080abe0}, 0x40026b6840, {0x3e3b258, 0x4001e16ed0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 693 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xac
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1fc

goroutine 694 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0x40026ed9e0, {0x3e23828, 0x400086b360}, 0x40015df160)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x2bc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x2ec

goroutine 692 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 697 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x100
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x1d8

goroutine 695 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0x400025dd40, {0x3e23828, 0x400086b360}, 0x40015df160)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x220
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x118

goroutine 1391 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400322bcc0, {{{0x378dd05, 0xa}}, {0x0, 0x0}, 0x4000940780, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 700 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001b925a8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b92598)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b92580, 0x40015bf240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001e85ec0, {0x3ddab40, 0x4001e0a3c0}, 0x1, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001e85ec0, 0x3b9aca00, 0x0, 0x1, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab180, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40008f8100, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 420
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 698 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x40026b6a20)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1495 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40031e0ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1370
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 642 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x40004e09c0, {0x3e237f0, 0x4002730c30}, {0x3e2b960, 0x4002bcf3e0})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x3c4
github.com/cilium/hive/job.(*jobOneShot).start(0x40004e0a20, {0x3e237f0, 0x4002730c30}, 0x4000b3ac00?, {0x3e2b960, 0x4001e765a0}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 560 [select, 4 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x40004e08a0, {0x3e237f0, 0x40027304b0}, 0x2?, {0x3e2b960, 0x40004e05a0}, {{{0x40019c6540, 0x1, 0x1}}, 0x4001934cc0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 641 [syscall]:
syscall.Syscall6(0x16, 0x18, 0x4001958f60, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x6207cb0?, {0x4001958f60?, 0x40001360c0?, 0x4001e079e0?}, 0x4001e07a58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x40005c0a00, {0x4001958f60, 0x2, 0x2}, {0x4001db0f60?, 0x32d640?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4002b99980, 0x4001e07bd8)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(0x4000400690?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x38
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x78
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x128

goroutine 646 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002a08d20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 647 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0x4000955cc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0xd4
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x5c

goroutine 645 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400178cd40?, 0x7a2bb0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x400010b800?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 638 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4001b92188, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b92178)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b92160, 0x400168bf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bf1ec0, {0x3ddab40, 0x400254e810}, 0x1, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002bf1ec0, 0x3b9aca00, 0x0, 0x1, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab040, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000cc6d00, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 235
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1401 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003286660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 639 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 235
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 653 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f4b88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001e23b00?, 0x4000b64200?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x4001e23b00, {0x4000b64200, 0x200, 0x200}, {0x400243f890, 0x2c, 0x2c}, 0x0, 0x4001df7818)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x254
net.(*netFD).readMsgInet4(0x4001e23b00, {0x4000b64200?, 0x4001df7808?, 0x71368?}, {0x400243f890?, 0x71374?, 0x4001df77d8?}, 0x1ea1c?, 0x4001df77f8?)
	/usr/local/go/src/net/fd_posix.go:84 +0x2c
net.(*UDPConn).readMsg(0x31926c0?, {0x4000b64200?, 0x230?, 0x2?}, {0x400243f890?, 0x10?, 0x4001df7918?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x124
net.(*UDPConn).ReadMsgUDPAddrPort(0x4000df6690, {0x4000b64200?, 0xffff699f4b88?, 0x77359168?}, {0x400243f890?, 0x2a69c84?, 0x4002592090?})
	/usr/local/go/src/net/udpsock.go:203 +0x34
net.(*UDPConn).ReadMsgUDP(0x4002592090?, {0x4000b64200?, 0x0?, 0x4000d13910?}, {0x400243f890?, 0x2a098e0?, 0x10?})
	/usr/local/go/src/net/udpsock.go:191 +0x24
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x4000df6690?, 0x4000df6690)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x5c
github.com/cilium/dns.(*Server).readUDP(0x4002bb8d00, 0x4000df6690, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0x140
github.com/cilium/dns.defaultReader.ReadUDP({0x61df4d0?}, 0x318dd00?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x1c
github.com/cilium/dns.(*Server).serveUDP(0x4002bb8d00, {0x3e35e70, 0x4000df6690})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x20c
github.com/cilium/dns.(*Server).ActivateAndServe(0x4002bb8d00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x178
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4002bb8d00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 651 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000955900, {{{0x37ce973, 0x19}}, {0x0, 0x0}, 0x4000a1a370, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 652 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff699f45b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x29?, 0xff01616d65686353?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4001e23a80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4001e23a80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40005c1400)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40005c1400)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
github.com/cilium/dns.(*Server).serveTCP(0x4002bb8c00, {0x3e0bbf0, 0x40005c1400})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0xe4
github.com/cilium/dns.(*Server).ActivateAndServe(0x4002bb8c00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x208
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4002bb8c00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 674 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40027332c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 657 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 638
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 673 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002732fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 10480 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4004819e48, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004819e38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004819e30, {0x4004903801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001addcc8?}, {0x4004903801?, 0x4001addcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4001e68f00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4001e68f00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4001e68f00, {0x30150e0, 0x4004673c50})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003df7650, {0x40045de000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004a7a500, 0x0, {0x3e02238, 0x4005282900})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001b88620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400115c680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 660
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 675 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x4000834c80}, 0x4001e43860, {0x3e3b4c0, 0x4001e16420})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x4dc
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 676 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1380 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 10479 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004819e00, 0x40045d6120, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004819e00, 0x8a6d4?, 0x4001e73408?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 660
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 682 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002406480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 664
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 685 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 664
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 683 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002406780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 664
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 684 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40011c22d0, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40011c22c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002406480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x40008352c0}, 0x4001e43ec0, {0x3e3b570, 0x4001d06b58})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 664
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1604 [select, 9 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x40021e7b30, {0x4001d0cfa0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40021e7b30, {0x4001d0cfa0?, 0x400318e030?, 0x40032b9510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001d0ce70, {0x4001d0cfa0?, 0x40032b9598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001d0ce70}, {0x4001d0cfa0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000fc6c60, {0x4001d0cfa0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001d0cf90, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001d0cf90, 0x4000fc6c60, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40032b97c8?, {0xffff695c2330, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40034f8500}, 0x4001c6ae00?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40032ff0e0, {0x35bf9e0, 0x40034f8500})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0x4001bcde30)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x4000e15f90?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1603
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 686 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000770b28, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000770b18)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4000770b00, 0x40011c2480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4002a092c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000d53ec0, {0x3ddab40, 0x40025e8540}, 0x1, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4000d53ec0, 0x3b9aca00, 0x0, 0x1, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4002a092c0, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005c1ca0, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 687 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 712 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020fc9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 729
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 708 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 686
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 706 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 686
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 709 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001192e40}, {0xffff696068e8, 0x4000770b00}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400127afc0, {0x0?, 0x0?}, 0x40019d44e0, 0x40022a5020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400127afc0, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002241f40, {0x3ddab60, 0x40008354a0}, 0x1, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400127afc0, 0x40019d44e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 686
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 636 [select, 9 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 558
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xc0

goroutine 660 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400115c680}, {0xffff696068e8, 0x4001b92160}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400120e620, {0x0?, 0x0?}, 0x40026ffe60, 0x4001afc480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400120e620, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400221bf40, {0x3ddab60, 0x400080a550}, 0x1, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400120e620, 0x40026ffe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 638
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 946 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x120
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 945
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1494 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40031e0d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1370
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 659 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 638
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 555 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0x400178c640)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xa4
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x20c

goroutine 556 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e726e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 554 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff699f48a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002bcf140?, 0x40023e5e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002bcf140, {0x40023e5e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000df6468, {0x40023e5e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x400178c600)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 558 [chan receive, 9 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c220, {0x3e237f0, 0x40027301e0}, 0x4001064b98, {0x3e2b960?, 0x40004e05a0}, {{{0x40019c6540, 0x1, 0x1}}, 0x4001934cc0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 701 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 420
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 664 [select, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0x4000955cc0, 0x40015df170, 0x400254f680)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x160

goroutine 559 [chan receive, 9 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c1e0, {0x3e237f0, 0x4002730390}, 0x0, {0x3e2b960?, 0x40004e05a0}, {{{0x40019c6540, 0x1, 0x1}}, 0x4001934cc0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 947 [select, 4 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0x4001676c40)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x1d4
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 843
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x68

goroutine 704 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 671
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xcc

goroutine 840 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xc0
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x26c

goroutine 806 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400127afc0, 0x40019d44e0, 0x40015e1da0, 0x40022a5020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 709
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 7787 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002ea6000, 0x4000fe5440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002ea6000, 0x4001d305a0?, 0x4001d304e0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1411
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 724 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001b92658, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b92648)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b92630, 0x40015bf2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400330fec0, {0x3ddab40, 0x40025e8e40}, 0x1, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002ad0ec0, 0x3b9aca00, 0x0, 0x1, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab220, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40008f8180, 0x40019d5140)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 418
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 725 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 418
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 833 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 729 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x130
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 694
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x200

goroutine 730 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x240
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 694
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x274

goroutine 731 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x40026b7860)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 694
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1394 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x400216dc20, {0x3e237f0, 0x400142b560}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x414
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x40012d0580, {0x3e237f0, 0x400142b560}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x74
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x3e237f0, 0x400142b560}, {{{}}, 0x4001e78000, {0x3e5d368, 0x4001e78070}, {0x3e24e30, 0x4002159ef0}, 0x40017891b0}, 0x40017d7480)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:85 +0x244
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x3e237f0?, 0x400142b560?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x40
github.com/cilium/hive/job.(*jobOneShot).start(0x4002406a20, {0x3e237f0, 0x400142b560}, 0x40021e9da0?, {0x3e2b960, 0x40024069c0}, {{{0x40016f6aa0, 0x1, 0x1}}, 0x4000cfda90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 10295 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004abbe00, 0x4003bdcb40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004abbe00, 0x400359ac00?, 0x4000ac5230?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 755
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 733 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020d6420)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 697
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 734 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40015bf390, 0x12)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015bf380)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020d6300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ab40, {0x3e23828, 0x400080b770}, 0x40026b7aa0, {0x3e3b200, 0x4001e170e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 697
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 735 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 697
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 736 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 700
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 778 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 771
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 738 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 700
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 739 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40016d2b80}, {0xffff696068e8, 0x4001b92580}, {0x3e672a8, 0x371cba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400120f6c0, {0x0?, 0x0?}, 0x40026b7c80, 0x40022b1140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400120f6c0, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002531f40, {0x3ddab60, 0x400080b810}, 0x1, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400120f6c0, 0x40026b7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 700
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 797 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400120f6c0, 0x40026b7c80, 0x40019d5d40, 0x40022b1140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 739
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 713 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020fcc60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 729
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 798 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40008a3380, 0x40005a9d40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40008a3380, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 739
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 714 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40011c2750, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40011c2740)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020fc9c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x40008357c0}, 0x40019d4de0, {0x3e3b4c0, 0x4001e172a8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 729
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 715 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 729
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 716 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020fd320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 704
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 717 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020fd560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 704
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 718 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40011c2ad0, 0x66)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40011c2ac0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020fd320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4aec0, {0x3e23828, 0x40008358b0}, 0x40019d4fc0, {0x3e3b468, 0x4001e17350})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 704
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 719 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 704
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 720 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 724
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1433 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40025a1d08, 0xcc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40025a1cf8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40025a1ce0, 0x40014c0000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40025e54a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002535ec0, {0x3ddab40, 0x4000d27950}, 0x1, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002535ec0, 0x3b9aca00, 0x0, 0x1, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40025e54a0, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400002c840, 0x4003299860)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 422
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 754 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 724
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 755 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4003cddc80}, {0xffff696068e8, 0x4001b92630}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400127b880, {0x0?, 0x0?}, 0x40019d5140, 0x40022a5500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400127b880, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002661f40, {0x3ddab60, 0x4000835950}, 0x1, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400127b880, 0x40019d5140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 724
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 810 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400127b880, 0x40019d5140, 0x4000c58f60, 0x40022a5500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 755
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1367 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x100
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb0

goroutine 748 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 744
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 744 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001b92708, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b926f8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b926e0, 0x40015bf600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400290bec0, {0x3ddab40, 0x4001e0a960}, 0x1, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40021abec0, 0x3b9aca00, 0x0, 0x1, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab2c0, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40008f8600, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 333
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 745 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 333
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1421 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 750 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 744
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 751 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4000fd4a00}, {0xffff696068e8, 0x4001b926e0}, {0x3e672a8, 0x36f67e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x400120fc00, {0x0?, 0x0?}, 0x40015e09c0, 0x40022a5920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x400120fc00, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40028f7f40, {0x3ddab60, 0x400080bb80}, 0x1, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x400120fc00, 0x40015e09c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 744
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 814 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x400120fc00, 0x40015e09c0, 0x4000c59b60, 0x40022a5920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 751
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 10370 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 815 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40017c8300, 0x4000879200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40017c8300, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 751
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1400 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40032864e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1500 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fa500, {{{0x37e6ffb, 0x1e}}, {0x0, 0x0}, 0x40016c3260, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1511
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 771 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4001b927b8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b927a8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b92790, 0x40015bf740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40026eeec0, {0x3ddab40, 0x4001e0b050}, 0x1, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40026eeec0, 0x3b9aca00, 0x0, 0x1, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab360, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40008f8a60, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 332
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 772 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 332
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1390 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001afd6e0, {0x3e237f0, 0x400142b0e0}, 0x40022bc960?, {0x3e2b960, 0x4001afd620}, {{{0x4000c777c0, 0x1, 0x1}}, 0x4000859150, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 775 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4001b92868, 0x33)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001b92858)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001b92840, 0x40015bf780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40022ab400)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40024e1ec0, {0x3ddab40, 0x4001e0b380}, 0x1, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40024e1ec0, 0x3b9aca00, 0x0, 0x1, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40022ab400, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40008f8ac0, 0x40015e1620)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 419
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 776 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 419
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 883 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001e7c1c0, 0x4001a61380, 0x4001a61da0, 0x40029f0600)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 847
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1404 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003286720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 780 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 771
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 781 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005057b80}, {0xffff696068e8, 0x4001b92790}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001ba60e0, {0x0?, 0x0?}, 0x40015e11a0, 0x40022a5380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001ba60e0, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002665f40, {0x3ddab60, 0x400096c690}, 0x1, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001ba60e0, 0x40015e11a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 771
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 808 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001ba60e0, 0x40015e11a0, 0x4000c587e0, 0x40022a5380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1382 [select]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x248
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x7c

goroutine 784 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 775
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 800 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40017c8348, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40017c8338)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40017c8330, {0x4001f66001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002b81cc8?}, {0x4001f66001?, 0x4002b81cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40004d5a40)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40004d5a40)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40004d5a40, {0x30150e0, 0x4003824138})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400269a570, {0x4001112000, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400097eb90, 0x0, {0x3e02238, 0x4001107980})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40009515c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4000fd4a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 751
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1378 [select, 4 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001afcc60, {0x3e237f0, 0x400142a8d0}, 0x0?, {0x3e2b960, 0x4001afcc00}, {{{0x40019706e0, 0x1, 0x1}}, 0x40005c3bf0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1377 [select, 9 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x3e23a20, 0x400182fd40}, {0x3dd0840, 0x4000f73dc0}, {0x3e2b960, 0x4001afcae0}, 0x4001e78000, {0x3e5d2a0, 0x40024be2a0}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x688
github.com/cilium/hive/job.(*jobOneShot).start(0x4001afcba0, {0x3e237f0, 0x400142a7e0}, 0x0?, {0x3e2b960, 0x4001afcae0}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 10182 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 1396 [syscall, 9 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x30
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x1c
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x28

goroutine 3162 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3193 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d00a0, {0x3e23828, 0x4002d94910})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3163
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1386 [select, 5 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0x4002131e00, {0x3e237f0, 0x400142adb0})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0x8c
github.com/cilium/hive/job.(*jobTimer).start(0x400322ee40, {0x3e237f0, 0x400142adb0}, 0x0?, {0x3e2b960, 0x4001afd020}, {{{0x0, 0x0, 0x0}}, 0x4000d13f60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x34c
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1385 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1392 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001afd7a0, {0x3e237f0, 0x400142b290}, 0x0?, {0x3e2b960, 0x4001afd740}, {{{0x0, 0x0, 0x0}}, 0x40008c4300, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1393 [select, 4 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x4002155b80, {0x3e237f0, 0x400142b440}, {0x3e0e5f0, 0x4001548ea0}, 0x40031d9da0)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x204
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x4002155b80, {0x3e237f0, 0x400142b440}, {0x671a1060?, 0x400290fd68?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x2d0
github.com/cilium/hive/job.(*jobOneShot).start(0x4001afdaa0, {0x3e237f0, 0x400142b440}, 0x40021e9da0?, {0x3e2b960, 0x4001afda40}, {{{0x40016ecea0, 0x1, 0x1}}, 0x40008c4e90, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1522 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fab40, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001995a10, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2987 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40032a0000, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x400088d980}, 0x40003d81c0, 0x0, 0x4003b390e0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2994
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1525 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0x400164fd70, 0x0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x4ec
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1368
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x210

goroutine 3164 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1530 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1529 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1501 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fa640, {{{0x37a4a9e, 0xf}}, {0x0, 0x0}, 0x400164e960, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1620 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1526
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 802 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 775
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 803 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004ebad80}, {0xffff696068e8, 0x4001b92840}, {0x3e672a8, 0x373c000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001ba67e0, {0x0?, 0x0?}, 0x40015e1620, 0x40022a5740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001ba67e0, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40028fbf40, {0x3ddab60, 0x400096c780}, 0x1, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001ba67e0, 0x40015e1620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 775
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 812 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001ba67e0, 0x40015e1620, 0x4000c59560, 0x40022a5740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 803
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 6967 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003be4948, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003be4938)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003be4930, {0x4001a707c4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003549cc8?}, {0x4001a707c4?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4003be4900}, {0x4001a707c4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40038243a8, {0x4004ea7000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003bc85a0, 0x0, {0x3e02238, 0x4000fe9f40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40008c84a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004ebad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 803
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12029 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003be59c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003be59b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003be59b0, {0x400000edc8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002ad4cc8?}, {0x400000edc8?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4003be5980}, {0x400000edc8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003a4b6b0, {0x400012a400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40049a0fa0, 0x0, {0x3e02238, 0x4001192e80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40008c9b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001192e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 709
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 816 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0e640, {{{0x37be248, 0x15}}, {0x0, 0x0}, 0x4000c9fae0, 0x0, 0x39b9348, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 693
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 12028 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003be5980, 0x40009666c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003be5980, 0x3e237f0?, 0x4001a722a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 709
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 824 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40008a33c8, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40008a33b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40008a33b0, {0x4000c94b90, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002bf3cc8?}, {0x4000c94b90?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x40008a3380}, {0x4000c94b90, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40026bccc0, {0x4001e7a400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000c34370, 0x0, {0x3e02238, 0x4001147f00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000a213e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40016d2b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 739
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11573 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40041c9c80, 0x400521cb40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40041c9c80, 0x0?, 0x400165fd90?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 6966 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003be4900, 0x4002a86a20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003be4900, 0x40033ac960?, 0x40033ac8a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 803
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 842 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x4000771a48, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000771a38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4000771a20, 0x4001856f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4002a09900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400327be00, {0x3ddab40, 0x40008cc2d0}, 0x1, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400295de00, 0x3b9aca00, 0x0, 0x1, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4002a09900, 0x4001a61380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x4000c1cb80, 0x4001a61380)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0xa8
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x40005c6ab0, {0x0?, 0x0?}, {0x3e148d0, 0x4001676cf8}, 0x4001a61380)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x480
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 841
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 1373 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f41d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x2d?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40025f4e00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40025f4e00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4003552db8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x400142a360)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x400214ec30, {0x3e0bc20, 0x400142a360})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3e0bc20?, 0x400142a360?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x70
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x418

goroutine 1219 [select]:
reflect.rselect({0x40010a0fc0, 0x9, 0xffff69785b38?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4001e41000?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001cf4030, {0x3e237f0, 0x40011ec2d0}, 0x40003c8850, {0xffff695c2358, 0x40004243a0}, 0x4001e3dda0, {0x385b1ff?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001cf4030, {0x3e237f0, 0x40011ec2d0}, {0xffff695c2358, 0x40004243a0}, {0x385b1ff, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0x4001cf4030, {0x3e3e7a8, 0x40004243a0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x78
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x365dfc0?, 0x4001cf4030}, {0x3e32818, 0x400214ea50})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40029b2a00, {0x3e237f0, 0x40011ec1e0}, {0x3e42860, 0x4001bef380}, 0x400082c7e0, 0x4001cf4300, 0x62382a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40029b2a00, {0x3e42860, 0x4001bef380}, 0x400082c7e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1218
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1537 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1370 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40004e0c60, {0x3e237f0, 0x400142a1e0}, 0x4002737740?, {0x3e2b960, 0x40004e0b40}, {{{0x40019b1360, 0x1, 0x1}}, 0x40012c9860, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 11950 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003225680, 0x40010c5200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003225680, 0x3e237f0?, 0x40019822d0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 847
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 11665 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4005349500, 0x400538fe60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4005349500, 0x0?, 0x4000d6f3a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1450
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1414 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1341
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1497 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1370
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1496 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40012d1290, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40012d1280)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40031e0d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x40020da730}, 0x40031dd800, {0x3e3b570, 0x40016c20c0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1370
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1476 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001ba7ea0, 0x400318b560, 0x40032bad20, 0x40032beb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1416 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1344 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1338
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10650 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 1417 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40014c0d80}, {0xffff696068e8, 0x400229d3f0}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001ba7ea0, {0x0?, 0x0?}, 0x400318b560, 0x40032beb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001ba7ea0, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d5df40, {0x3ddab60, 0x400216ce10}, 0x1, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001ba7ea0, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1341
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1338 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400229d368, 0x16)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400229d358)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400229d340, 0x40012d01c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400213fcc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d61ec0, {0x3ddab40, 0x4001303a40}, 0x1, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002d61ec0, 0x3b9aca00, 0x0, 0x1, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400213fcc0, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40011d8400, 0x400318b080)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1372
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1468 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1465
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1411 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001175500}, {0xffff696068e8, 0x400229d340}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001ba7b20, {0x0?, 0x0?}, 0x400318b080, 0x40032be840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001ba7b20, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d5ff40, {0x3ddab60, 0x400216cd20}, 0x1, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001ba7b20, 0x400318b080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1338
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1410 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1338
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1474 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001ba7b20, 0x400318b080, 0x40032ba8a0, 0x40032be840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1411
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1342 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 553
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1535 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1534 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 11121 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004819c80, 0x400118a240, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004819c80, 0x0?, 0x4002eadd40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1200 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40013723c0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40003c8a80)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xbc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1199
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x13d0

goroutine 1217 [select, 9 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x4001bef380)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x174
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1199
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1410

goroutine 1218 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f40e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001baeb80?, 0x400304c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001baeb80, {0x400304c000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001baeb80, {0x400304c000?, 0x4004d8a1c0?, 0x800010601?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df7b70, {0x400304c000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
bufio.(*Reader).Read(0x400207c060, {0x4001e7c9e0, 0x9, 0x4000ad1c80?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400207c060}, {0x4001e7c9e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001e7c9e0, 0x9, 0x4005993518?}, {0x3dcc0a0?, 0x400207c060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001e7c9a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x4001bef380, {0x3e237f0, 0x4000ad1e60}, 0x4000ad1e90)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x11c
google.golang.org/grpc.(*Server).serveStreams(0x40029b2a00, {0x3e23698?, 0x680cae0?}, {0x3e42860, 0x4001bef380}, {0x3e3a840?, 0x4000df7b70?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x300
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x5c
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1199
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d4

goroutine 1220 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4001372550, {0x40011ec280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4001372550, {0x40011ec280?, 0x400201ec18?, 0x4002b05510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40011ec0c0, {0x40011ec280?, 0x4002b05598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40011ec0c0}, {0x40011ec280, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400082c7e0, {0x40011ec280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40011ec270, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40011ec270, 0x400082c7e0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002b057c8?, {0xffff695c2330, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40051163c0}, 0x4001695dc0?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x400214ea50, {0x35bf9e0, 0x40051163c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0x40004243a0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x4001bee900?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1219
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1339 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1372
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1603 [select, 9 minutes]:
reflect.rselect({0x400227ad80, 0x9, 0xffff69912a60?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x40029b2200?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001cf4030, {0x3e237f0, 0x4001d0cff0}, 0x4000426150, {0xffff695c6b00, 0x4001bcde30}, 0x40024ce000, {0x3852034?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001cf4030, {0x3e237f0, 0x4001d0cff0}, {0xffff695c6b00, 0x4001bcde30}, {0x3852034, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0x4001cf4030, {0x3e3e6a0, 0x4001bcde30})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x78
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x365dfc0?, 0x4001cf4030}, {0x3e32818, 0x40032ff0e0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40029b2a00, {0x3e237f0, 0x4001d0cf00}, {0x3e42860, 0x4001bef380}, 0x4000fc6c60, 0x4001cf41e0, 0x6238200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40029b2a00, {0x3e42860, 0x4001bef380}, 0x4000fc6c60)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1218
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1341 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x400229d418, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400229d408)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400229d3f0, 0x40012d0200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400213fd60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002aefec0, {0x3ddab40, 0x4001303e60}, 0x1, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002aefec0, 0x3b9aca00, 0x0, 0x1, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400213fd60, 0x400318b560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40011d8420, 0x400318b560)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 553
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1518 [select, 6 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x110
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1588
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x200

goroutine 1536 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 3009 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40032a0280, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x400187b640, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2988
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1371 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40004e0d20, {0x3e237f0, 0x400142a240}, 0x4002736cc0?, {0x3e2b960, 0x40004e0b40}, {{{0x40019b1360, 0x1, 0x1}}, 0x40012c9860, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1538 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1486 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40032bf080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1371
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1405 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40032868a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1406 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4000f61210, 0x18b)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f61200)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003286720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ad40, {0x3e23828, 0x4001d3a690}, 0x4003235f20, {0x3e3b360, 0x40014673e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1407 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1408 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003286960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1425 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003286ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1426 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4000f61690, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f61680)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003286960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4acc0, {0x3e23828, 0x4001d3a780}, 0x4003298000, {0x3e3b308, 0x40014674a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1427 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1428 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4003286ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1429 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4003286d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1382
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1430 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x4000f61e10, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f61e00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4003286ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ac40, {0x3e23828, 0x4001d3a870}, 0x40032980c0, {0x3e3b2b0, 0x4001467548})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1431 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1382
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1434 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 422
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1640 [IO wait, 4 minutes]:
internal/poll.runtime_pollWait(0xffff69617508, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40031f4480)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40031f4480)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40005c1200)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40005c1200)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x4002256e10, {0x3e0bbf0, 0x40005c1200})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
net/http.(*Server).ListenAndServe(0x4002256e10)
	/usr/local/go/src/net/http/server.go:3189 +0x84
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x28
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1635
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x58

goroutine 1453 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1438
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1438 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40025a1db8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40025a1da8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40025a1d90, 0x40014c0040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40025e5540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002292ec0, {0x3ddab40, 0x4000d27dd0}, 0x1, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002292ec0, 0x3b9aca00, 0x0, 0x1, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40025e5540, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400002c8a0, 0x4003299b60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 423
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1439 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 423
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 3263 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40031f6dd0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3270
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 1459 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1443
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1443 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40025a1e68, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40025a1e58)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40025a1e40, 0x40014c0080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40025e55e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40022e5ec0, {0x3ddab40, 0x4001556210}, 0x1, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40022e5ec0, 0x3b9aca00, 0x0, 0x1, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40025e55e0, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400002c900, 0x4003299e60)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1444 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1636 [semacquire, 9 minutes]:
sync.runtime_Semacquire(0x400329d6c0?)
	/usr/local/go/src/runtime/sema.go:62 +0x2c
sync.(*WaitGroup).Wait(0x4003314140)
	/usr/local/go/src/sync/waitgroup.go:116 +0x74
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x4003314000)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0xa8
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x4003314000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x100
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x28
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xd0

goroutine 1619 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40029b02d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035badc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000b66ea0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1526
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1449 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1433
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1450 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005503800}, {0xffff696068e8, 0x40025a1ce0}, {0x3e672a8, 0x370c0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001e7da40, {0x0?, 0x0?}, 0x4003299860, 0x40031e0840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001e7da40, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400298bf40, {0x3ddab60, 0x4001d3b540}, 0x1, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001e7da40, 0x4003299860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1433
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1423 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001e7da40, 0x4003299860, 0x40031dcf00, 0x40031e0840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1450
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 11346 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003164f48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003164f38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003164f30, {0x4003d3d400, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003567cc8?}, {0x4003d3d400?, 0x2?, 0x4000159200?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4000311e00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4000311e00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4000311e00, {0x30150e0, 0x40011cb7b8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4004c76630, {0x4003f3c000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40048c3590, 0x0, {0x3e02238, 0x4004eba780})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000a20f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004eba740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1466 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 421
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1455 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1438
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1456 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004eba740}, {0xffff696068e8, 0x40025a1d90}, {0x3e672a8, 0x3703740}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001e7dea0, {0x0?, 0x0?}, 0x4003299b60, 0x40032bef00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001e7dea0, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032cdf40, {0x3ddab60, 0x4001d3b630}, 0x1, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001e7dea0, 0x4003299b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1438
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1482 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001e7dea0, 0x4003299b60, 0x40032bb6e0, 0x40032bef00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 11345 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003164f00, 0x4005148900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003164f00, 0x0?, 0x4001465af0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1456
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1465 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x40032bc028, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40032bc018)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40032bc000, 0x40014c03c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40025e5680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032a5ec0, {0x3ddab40, 0x4001556720}, 0x1, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40032a5ec0, 0x3b9aca00, 0x0, 0x1, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40025e5680, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x400002d440, 0x40032ba300)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 421
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1461 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1443
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1462 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4000cec180}, {0xffff696068e8, 0x40025a1e40}, {0x3e672a8, 0x36f2b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4000891dc0, {0x0?, 0x0?}, 0x4003299e60, 0x40031e0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4000891dc0, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032e1f40, {0x3ddab60, 0x4001d3b720}, 0x1, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4000891dc0, 0x4003299e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1443
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1490 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4000891dc0, 0x4003299e60, 0x40031dd3e0, 0x40031e0c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1487 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40032bf1a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1371
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1477 [select, 9 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003225500, 0x4000e95560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003225500, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1417
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1470 [chan receive, 9 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1465
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1471 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400593e180}, {0xffff696068e8, 0x40032bc000}, {0x3e672a8, 0x3722640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40012ec460, {0x0?, 0x0?}, 0x40032ba300, 0x40032bed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40012ec460, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032b3f40, {0x3ddab60, 0x4001d3be50}, 0x1, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40012ec460, 0x40032ba300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1465
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1478 [select, 9 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40012ec460, 0x40032ba300, 0x40032bb0e0, 0x40032bed20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1471
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1480 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003225548, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003225538)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003225530, {0x400180334c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002af9cc8?}, {0x400180334c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4003225500}, {0x400180334c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40014679e0, {0x4003942000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x400217c460, 0x0, {0x3e02238, 0x4000f734c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001458260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40014c0d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1417
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11691 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400593c180, 0x400581b680, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400593c180, 0x8a6d4?, 0x40014c0e80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1471
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1488 [sync.Cond.Wait, 5 minutes]:
sync.runtime_notifyListWait(0x40014c12d0, 0x27)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40014c12c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40032bf080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x400217ca00}, 0x40032bbb00, {0x3e3b258, 0x40016c2060})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1371
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1505 [select, 9 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1371
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1539 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1540 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1541 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1542 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1543 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1544 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f43c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x32?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40031f4d00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40031f4d00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40019ba860)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40019ba860)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x4002256f00, {0x3e0bbf0, 0x40019ba860})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0x40016ffaf0, 0xe}, {0x3e0bbf0, 0x40019ba860})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xa0
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1368
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x560

goroutine 1545 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fb040, {{{0x37bdc75, 0x15}}, {0x0, 0x0}, 0x400086d530, 0x0, 0x39b9348, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1613 [select, 9 minutes]:
net/http.(*persistConn).writeLoop(0x4001e6a900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1611
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1547 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fb180, {{{0x37c1af7, 0x16}}, {0x3e2b960, 0x4001e765a0}, 0x4001bccd40, 0x0, 0x39b9348, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3246 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002542008)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3219
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1760 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b14640, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400207d7a0}, 0x40018f8fa0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1667
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1635 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x40017ec348)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xd4
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x2c
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x80

goroutine 1634 [chan receive, 9 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x4003314000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xe0
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x5c
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 1525
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1d8

goroutine 3188 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3197 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3159
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3157 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fb680, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x40019948b0, 0x1, 0x40019948d0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3168 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3fa30, {0x3e23828, 0x4002d94050})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3161
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3175 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3155
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3159 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fb7c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001995810, 0x1, 0x4001995820, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3167 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3f080, {0x3e23828, 0x4002b91cc0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3159
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3287 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e23828, 0x4002e851d0}, 0x4000de4880)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3286
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3269 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000ded200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3179
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 1669 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0f680, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400087f770, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1647
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1668 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0f540, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002a75e00}, 0x4001e79880, 0x0, 0x4000d272f0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1647
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1667 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1647
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1666 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400087f4a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0f2c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000d133c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1647
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3191 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d0040, {0x3e23828, 0x4002d94730})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3163
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1632 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002a08b40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1647
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 2305 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4da8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001d1b900?, 0x40023c7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001d1b900, {0x40023c7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001d1b900, {0x40023c7000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df77f8, {0x40023c7000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40009defc0, {0x40023c7000?, 0x4001ec9d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40023f8720)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40023f8720, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40009defc0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 2286
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3186 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3fab0, {0x3e23828, 0x4002d94190})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3161
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1625 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff696177f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4000c0f100?, 0x4001e29000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4000c0f100, {0x4001e29000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4000c0f100, {0x4001e29000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40015cc1a0, {0x4001e29000?, 0x72?, 0x4000dc62d8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000dc62d0, {0x4001e29000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40034a7740)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40034a7740, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40010de750, {0x3e237f0, 0x4001303320})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1373
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1622 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035bb180, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000b67220, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1526
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3291 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40014b57c0, {0x3e23828, 0x4002fd90e0}, 0x4af692bdd22a0fa2, 0x4003427bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3211
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 1612 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff699f3fe8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003295700?, 0x400198d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003295700, {0x400198d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003295700, {0x400198d000?, 0x1?, 0x4003591dc0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fec4a8, {0x400198d000?, 0xc?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001e6a900, {0x400198d000?, 0x18550?, 0x40020f57a0?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40024ab560)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40024ab560, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001e6a900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1611
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1610 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40009557c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4001e77620}, 0x4000cc8050, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1597 [sync.Cond.Wait, 9 minutes]:
sync.runtime_notifyListWait(0x40017a9750, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40017a9740)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40017a9700, {0x3e23828, 0x400217c6e0}, {0x40029df100, 0x33}, 0x1, {0x4001bf6065, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1603
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 1595 [syscall, 9 minutes]:
syscall.Syscall6(0x5f, 0x1, 0x19c, 0x40034e9ca8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
os.(*Process).blockUntilWaitable(0x4001738720)
	/usr/local/go/src/os/wait_waitid.go:32 +0x6c
os.(*Process).wait(0x4001738720)
	/usr/local/go/src/os/exec_unix.go:22 +0x2c
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0x40034ee600)
	/usr/local/go/src/os/exec/exec.go:901 +0x38
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 1594
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x3bc

goroutine 1596 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40034f83c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1526
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1579 [chan receive, 9 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1546
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1580 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035832c0, {{{0x378d189, 0xa}}, {0x0, 0x0}, 0x39b9e78, 0x0, 0x39b9348, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1546
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1581 [select, 4 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x4001982ab0, {0x3e23828, 0x400086b360})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xec
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x20f0

goroutine 1582 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x4003583400)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x78
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x216c

goroutine 1583 [syscall]:
syscall.Syscall6(0x16, 0x3a, 0x4001bf6980, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x4000074001?, {0x4001bf6980?, 0x40032eb918?, 0x1ea7078?}, 0x3ddd880?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x40012b2080, {0x4001bf6980, 0x2, 0x2}, {0x74?, 0x74?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4003492d80, 0x40032ebaf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x40024be070, {0x3e23828, 0x40021e6c30})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x404
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1546
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd4

goroutine 1584 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617bd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x36?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4003514d80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4003514d80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40032a9b28?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001982c60)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x400358c800, {0x3e0bc20, 0x4001982c60})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4c
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x2fc8

goroutine 1585 [chan receive, 9 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x3028

goroutine 1586 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff699f44c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400359eae0?, 0x400343be2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400359eae0, {0x400343be2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000fec100, {0x400343be2b?, 0x0?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4001032940)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1546
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1587 [select, 6 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x4001983260)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0x90
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1546
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1f8

goroutine 1520 [chan receive, 9 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x3adc

goroutine 1519 [IO wait, 9 minutes]:
internal/poll.runtime_pollWait(0xffff696179e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x3f?, 0x40022505b0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40034a5280)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40034a5280)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40012b2340)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40012b2340)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4003283800, {0x3e0bbf0, 0x40012b2340})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x54
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1546
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x3a7c

goroutine 3237 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617600, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40031e4180?, 0x4001b68000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40031e4180, {0x4001b68000, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40031e4180, {0x4001b68000?, 0xffff69507308?, 0x4003bcca80?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6628, {0x4001b68000?, 0x400396f928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003bcca80, {0x4001b68000?, 0x0?, 0x4003bcca80?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016af0b0, {0x3dd1940, 0x4003bcca80})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016aee08, {0x3dcbd80, 0x4000df6628}, 0x400396fa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016aee08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016aee08, {0x4002aa6000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400299eba0, {0x40011d1d20, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400299eba0}, {0x40011d1d20, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x40011d1d20, 0x9, 0x807562668d?}, {0x3dcc0a0?, 0x400299eba0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x40011d1ce0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40025406c8, 0x400299ec00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3198
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3239 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617410, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003295900?, 0x4001b68700?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003295900, {0x4001b68700, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003295900, {0x4001b68700?, 0xffff6968bf68?, 0x4003a4a630?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6618, {0x4001b68700?, 0x4001def928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003a4a630, {0x4001b68700?, 0x0?, 0x4003a4a630?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016ae9b0, {0x3dd1940, 0x4003a4a630})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016ae708, {0x3dcbd80, 0x4000df6618}, 0x4001defa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016ae708, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016ae708, {0x4002b88000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002a7d1a0, {0x400120e820, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002a7d1a0}, {0x400120e820, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400120e820, 0x9, 0x80785c0a06?}, {0x3dcc0a0?, 0x4002a7d1a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400120e7e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002540b48, 0x4002a7d200)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3194
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3158 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1657 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000581680, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000940870, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1669
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3136 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f242a0, {0x3e23828, 0x4002b0ccd0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3155
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1766 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40037a0a00, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40029ea480}, 0x4001935910, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1697
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1662 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40022ab4a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3254 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002f00780, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028aee0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3213
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1664 [select, 9 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000c358b0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e69400, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40002ec3e0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1697 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4001bcd5e0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40018dca38?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1698 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e69540, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40029f0360}, 0x40003731f0, 0x0, 0x400164f500, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1699 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e69680, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4000c35ae0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1694 [IO wait]:
internal/poll.runtime_pollWait(0xffff69616e40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001f7a900?, 0x4004186200?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0x4001f7a900, {0x4004186200, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x214
net.(*netFD).readFrom(0x4001f7a900, {0x4004186200?, 0x72?, 0xffffb05f45e0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x28
net.(*IPConn).readFrom(0x4001f7a900?, {0x4004186200, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0x40015cd3e8, {0x4004186200?, 0x4002653ea8?, 0x4002653e70?})
	/usr/local/go/src/net/iprawsock.go:129 +0x2c
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1bea281a8ec54ee?, {0x4004186200?, 0x6279580?, 0x6279580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x34
github.com/servak/go-fastping.(*Pinger).recvICMP(0x4001378a20, 0x40008f98c0, 0x4001a75560, 0x40008f98e0, 0x4000fb1fc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x114
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1719
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x2d8

goroutine 1714 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617030, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001f7a880?, 0x4001fba000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001f7a880, {0x4001fba000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001f7a880, {0x4001fba000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fed928, {0x4001fba000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4000fde240, {0x4001fba000?, 0x4001ecad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4001b14e40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4001b14e40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4000fde240)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1692
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1713 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617318, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001f99300?, 0x4001f9a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001f99300, {0x4001f9a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001f99300, {0x4001f9a000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fed920, {0x4001f9a000?, 0x72?, 0x4001a42e18?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001a42e10, {0x4001f9a000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4001b141e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4001b141e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001378240, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 3251 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x400294b8c8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3176
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1704 [select, 4 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e697c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40002eca10, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1699
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3179 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3157
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 1720 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x80
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1636
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x68

goroutine 1721 [IO wait]:
internal/poll.runtime_pollWait(0xffff69616f38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x46?, 0x294ec?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4001f99500)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4001f99500)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001eccdb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001a72120)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x400214eff0, {0x3e0bc20, 0x4001a72120})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3e0bc20?, 0x4001a72120?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x70
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1636
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x3f0

goroutine 1759 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b14500, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400207d6e0}, 0x40018f8ea0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1620
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1715 [select]:
net/http.(*persistConn).writeLoop(0x4000fde240)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1692
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3192 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d0070, {0x3e23828, 0x4002d94820})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3163
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3189 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400322a780, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001b8c880, 0x1, 0x4001b8c890, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2985 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400087f0e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003a71e00, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400187b030, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2994
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3169 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f24a80, {0x3e23828, 0x4002b0cdc0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3303 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000ef46c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3222
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3222 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3163
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3171 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f24ae0, {0x3e23828, 0x4002b0ce60})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3157
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3134 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f241f0, {0x3e23828, 0x4002b0cc30})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3155
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3135 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000f24220, {0x3e23828, 0x4002b0cc80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3155
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3256 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3265
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2306 [select]:
net/http.(*persistConn).writeLoop(0x40009defc0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 2286
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3236 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40025406c8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3198
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3161 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fbb80, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001c3e1b0, 0x1, 0x4001c3e1c0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3163 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fbcc0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001c3e690, 0x1, 0x4001c3e6a0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3155 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031fb540, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001994380, 0x1, 0x40019943b0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3285 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002f00d70, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40002807e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3209
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3001 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035823c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4001065500}, 0x4000265e20, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2986
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3286 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40031f4a00, {0x3e23828, 0x4002e851d0}, {0xffff695ea460, 0x4000ded200}, {0x4002972dc8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002baad80, {0x3e23828, 0x4002e851d0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001ba7a40, {0x3e23828, 0x4002e851d0}, {0x3e5f080, 0x4000ded200}, {0x8, {0x1, 0x1, 0xff}}, 0x4003427200)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3157
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2988 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40032a0140, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400087f400, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2994
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3166 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3f050, {0x3e23828, 0x4002b91bd0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3159
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3436 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000decb40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3175
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3312 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000e95d40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3197
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3187 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400322a640, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4001c3fec0, 0x1, 0x4001c3fed0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3278 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000dfe6c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3201
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3156 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3201 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3161
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3262 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3270
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2986 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40004c6901?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000ace260?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 2994
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3160 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 555
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3185 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001c3fa80, {0x3e23828, 0x4002d940a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3161
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3238 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002540b48)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3194
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3202 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d1be0, {0x3e23828, 0x4002d95950})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3187
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3203 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d1c10, {0x3e23828, 0x4002d959a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3187
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3204 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40017d1c70, {0x3e23828, 0x4002d959f0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3187
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3205 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001b1a700, {0x3e23828, 0x4002d95b30})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3189
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3206 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001b1a730, {0x3e23828, 0x4002d95b80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3189
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3207 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4001b1a760, {0x3e23828, 0x4002d95bd0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3189
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3257 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400137b7c0, {0x3e3fa98, 0x4001998d40})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3265
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3258 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x4001649a40?, {0x3e23828, 0x4002e851d0}, {0x3e5f080?, 0x4000ded200?}, 0x4001995890)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3157
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3296 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3313
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3212 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3187
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3255 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002dcfd10, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028b030)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3198
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3235 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002e842d0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400057a620)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3176
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3321 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000f8f320)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3216
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3216 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3189
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3445 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4001fd9d00, {0x3e23828, 0x400304b950}, {0xffff695ea460, 0x4000dfe6c0}, {0x4002b19818?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003105620, {0x3e23828, 0x400304b950})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001ba7ce0, {0x3e23828, 0x400304b950}, {0x3e5f080, 0x4000dfe6c0}, {0x5, {0x1, 0x1, 0xff}}, 0x4003163bc0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3161
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3240 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002540fc8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3213
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3244 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002541448)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3209
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3252 [IO wait]:
internal/poll.runtime_pollWait(0xffff696176f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001baed00?, 0x400021c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001baed00, {0x400021c000, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001baed00, {0x400021c000?, 0xffff6950e538?, 0x4003d69c68?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6358, {0x400021c000?, 0x4001ecb928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003d69c68, {0x400021c000?, 0x0?, 0x4003d69c68?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400184fb30, {0x3dd1940, 0x4003d69c68})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400184f888, {0x3dcbd80, 0x4000df6358}, 0x4001ecba00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400184f888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400184f888, {0x4002772000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400262f4a0, {0x400139b9a0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400262f4a0}, {0x400139b9a0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400139b9a0, 0x9, 0x8075617252?}, {0x3dcc0a0?, 0x400262f4a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400139b960)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x400294b8c8, 0x400262f500)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3176
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3241 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617128, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40031e5080?, 0x40036e5400?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40031e5080, {0x40036e5400, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40031e5080, {0x40036e5400?, 0xffff6968bf68?, 0x4003a4a600?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6638, {0x40036e5400?, 0x4000220928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003a4a600, {0x40036e5400?, 0x0?, 0x4003a4a600?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016af430, {0x3dd1940, 0x4003a4a600})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016af188, {0x3dcbd80, 0x4000df6638}, 0x4000220a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016af188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016af188, {0x4002bd8000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002b0a540, {0x400120ec80, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002b0a540}, {0x400120ec80, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400120ec80, 0x9, 0x80785be5bd?}, {0x3dcc0a0?, 0x4002b0a540?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400120ec40)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002540fc8, 0x4002b0a5a0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3213
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3243 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4ea0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001baeb00?, 0x4001b69500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001baeb00, {0x4001b69500, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001baeb00, {0x4001b69500?, 0xffff6968bf68?, 0x4003a4a5e8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6380, {0x4001b69500?, 0x400238c928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003a4a5e8, {0x4001b69500?, 0x0?, 0x4003a4a5e8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016ae2b0, {0x3dd1940, 0x4003a4a5e8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016ae008, {0x3dcbd80, 0x4000df6380}, 0x400238ca00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016ae008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016ae008, {0x4002d54000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002b6a2a0, {0x400120f620, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002b6a2a0}, {0x400120f620, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400120f620, 0x9, 0x80785c0589?}, {0x3dcc0a0?, 0x4002b6a2a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400120f5e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002541208, 0x4002b6a300)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3172
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3245 [IO wait]:
internal/poll.runtime_pollWait(0xffff69616d48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40031e4e00?, 0x4001b69c00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40031e4e00, {0x4001b69c00, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40031e4e00, {0x4001b69c00?, 0xffff6968bf68?, 0x4003a4a618?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df6648, {0x4001b69c00?, 0x400354a928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003a4a618, {0x4001b69c00?, 0x0?, 0x4003a4a618?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016af7b0, {0x3dd1940, 0x4003a4a618})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016af508, {0x3dcbd80, 0x4000df6648}, 0x400354aa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016af508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016af508, {0x4002dda000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002af60c0, {0x4001e7c2e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002af60c0}, {0x4001e7c2e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001e7c2e0, 0x9, 0x80785d7409?}, {0x3dcc0a0?, 0x4002af60c0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001e7c2a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002541448, 0x4002af6120)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3209
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3247 [IO wait]:
internal/poll.runtime_pollWait(0xffff69617220, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003295980?, 0x400259d500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003295980, {0x400259d500, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003295980, {0x400259d500?, 0xffff6950e538?, 0x4003d69d58?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000df65f8, {0x400259d500?, 0x4003a4d928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003d69d58, {0x400259d500?, 0x0?, 0x4003d69d58?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40016ae630, {0x3dd1940, 0x4003d69d58})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40016ae388, {0x3dcbd80, 0x4000df65f8}, 0x4003a4da00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40016ae388, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40016ae388, {0x4002df0000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002af7d40, {0x4001e7c580, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002af7d40}, {0x4001e7c580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001e7c580, 0x9, 0x80756178f5?}, {0x3dcc0a0?, 0x4002af7d40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001e7c540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002542008, 0x4002af7da0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3219
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3248 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400137b7c0, {0x3e23828, 0x4002f012c0}, 0x4af692bdd22a0f96, 0x40036d4120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3178
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3265 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4002e85040, {0x4001acd8d0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002e85040, {0x4001acd8d0?, 0x40029729f0?, 0x4002b07930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001acd890, {0x4001acd8d0?, 0x4002b079b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001acd890}, {0x4001acd8d0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000f510e0, {0x4001acd8d0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001acd8c0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001acd8c0, 0x4000f510e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4000f510e0?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f73d40}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400229ba00, {0x3612420, 0x4000f73d40}, 0x4000f73f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002b07d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4000f50c60, 0x4002b07e10, 0x4002b07e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4000f50c60, {0x3612420?, 0x4000f73d40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4001bdee70, {0x3612420, 0x4000f73d40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4001998d40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400137b7c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3178
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3266 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400137b7c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3178
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3267 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3178
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3268 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4001bae980, 0x4001ac8870)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3178
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3270 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e23828, 0x4002b915e0}, 0x4000b52b00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3179
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3253 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002f00140, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028ae00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3194
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3261 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002f00fa0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028bb20)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3219
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3273 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40014b4c80, {0x3e23828, 0x400304a550}, 0x4af692bdd22a0f98, 0x40036d4660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3200
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3274 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400304b810, {0x4001b31960, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400304b810, {0x4001b31960?, 0x4002a81f08?, 0x4002903930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b31920, {0x4001b31960?, 0x40029039b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b31920}, {0x4001b31960, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400107fc20, {0x4001b31960, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b31950, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b31950, 0x400107fc20, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400107fc20?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001032240}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5c9c0, {0x3612420, 0x4001032240}, 0x4001033f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002903d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400107f8c0, 0x4002903e10, 0x4002903e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400107f8c0, {0x3612420?, 0x4001032240?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40013a1290, {0x3612420, 0x4001032240})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4001297220)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40014b4c80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3200
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3282 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4002fd8370, {0x4001af11e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002fd8370, {0x4001af11e0?, 0x4002972bd0?, 0x4003313950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001af11a0, {0x4001af11e0?, 0x40033139d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001af11a0}, {0x4001af11e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000fdf200, {0x4001af11e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001af11d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001af11d0, 0x4000fdf200, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4000fdf200?, {0xffff695c2330, 0x680cae0}, 0x2f4d90?, {0x0?, 0x0?}, {0x368b2c0, 0x400502e850}, 0x4?, 0x400133b880?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40031f7040, {0x368b2c0, 0x400502e850}, 0x400502ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003313d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4000fdefc0, 0x4003313e30, 0x4003313e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4000fdefc0, {0x368b2c0?, 0x400502e850?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4001bdfb48, {0x368b2c0, 0x400502e850})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001999bd0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40031f6dd0, {0x3e3faf0, 0x4001999bd0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3281 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3283 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001e26dc0, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3284 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4002f00a50, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000266a10)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3172
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3275 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40014b4c80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3200
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3276 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3200
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3277 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40025f5380, 0x4001b300c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3200
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3279 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e23828, 0x4002b91720}, 0x4000b53780)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3201
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3298 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400137bae0, {0x3e23828, 0x400304ab90}, 0x4af692bdd22a0f9f, 0x40036d4ae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3221
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3299 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400304bb80, {0x4001b31c90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400304bb80, {0x4001b31c90?, 0x4002a81fb0?, 0x4002217930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b31c50, {0x4001b31c90?, 0x40022179b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b31c50}, {0x4001b31c90, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40010da240, {0x4001b31c90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b31c80, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b31c80, 0x40010da240, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40010da240?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f73e00}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5ca90, {0x3612420, 0x4000f73e00}, 0x4000f73f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002217d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40010da000, 0x4002217e10, 0x4002217e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40010da000, {0x3612420?, 0x4000f73e00?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40013a1398, {0x3612420, 0x4000f73e00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40012973b0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400137bae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3221
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3300 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400137bae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3221
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3301 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3221
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3302 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003295780, 0x4001b30630)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3221
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3304 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e23828, 0x4002b917c0}, 0x4000b53940)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3222
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3307 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40014b4a00, {0x3e23828, 0x400304af50}, 0x4af692bdd22a0f9d, 0x40036d4f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3196
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3308 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400304bef0, {0x4001b52010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400304bef0, {0x4001b52010?, 0x4002a81fc8?, 0x4002219930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b31f50, {0x4001b52010?, 0x40022199b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b31f50}, {0x4001b52010, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40010da7e0, {0x4001b52010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b52000, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b52000, 0x40010da7e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40010da7e0?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001033500}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5cb60, {0x3612420, 0x4001033500}, 0x4001033f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002219d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40010da5a0, 0x4002219e10, 0x4002219e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40010da5a0, {0x3612420?, 0x4001033500?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40013a14a0, {0x3612420, 0x4001033500})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40012974f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40014b4a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3196
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3309 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40014b4a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3196
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3310 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3196
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3311 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40025f5180, 0x4001b30ba0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3196
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3313 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e23828, 0x4002b91630}, 0x4000b53b80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3197
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3316 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40014b5a40, {0x3e23828, 0x400304b310}, 0x4af692bdd22a0f9a, 0x40036d53e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3215
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3317 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40030e2320, {0x4001b52340, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40030e2320, {0x4001b52340?, 0x4002a81fe0?, 0x4002229930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b52300, {0x4001b52340?, 0x40022299b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b52300}, {0x4001b52340, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40010dad80, {0x4001b52340, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b52330, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b52330, 0x40010dad80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40010dad80?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001033580}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5cc30, {0x3612420, 0x4001033580}, 0x4001033f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002229d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40010dab40, 0x4002229e10, 0x4002229e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40010dab40, {0x3612420?, 0x4001033580?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40013a15a8, {0x3612420, 0x4001033580})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4001297650)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40014b5a40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3215
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3318 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40014b5a40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3215
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3319 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3215
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3320 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40031e4d00, 0x4001b31110)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3215
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3322 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e23828, 0x4002d94370}, 0x4000b53dc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3216
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3325 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3274
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3326 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40014b4c80, {0x3e3fa98, 0x4001297220})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3274
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3327 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40036d5380?, {0x3e23828, 0x400304b950}, {0x3e5f080?, 0x4000dfe6c0?}, 0x4001c3f0a0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3161
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3329 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3299
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3330 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400137bae0, {0x3e3fa98, 0x40012973b0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3299
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3331 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x400304bcc0}, {0x3e5f080?, 0x4000ef46c0?}, 0x4001b8c8f0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3163
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3333 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3308
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3334 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40014b4a00, {0x3e3fa98, 0x40012974f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3308
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3335 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x40030e20f0}, {0x3e5f080?, 0x4000e95d40?}, 0x4001c3e710)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3159
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3337 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3317
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3338 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40014b5a40, {0x3e3fa98, 0x4001297650})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3317
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3339 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x40030e2460}, {0x3e5f080?, 0x4000f8f320?}, 0x40017d1ca0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3189
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3341 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x4002e851d0}, 0x4001b08840, 0x40012979e0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4002e851d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3286
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3342 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0c00, {0x3e23828, 0x4002e851d0}, {0xffff695ea460, 0x4000ded200}, {0x4001961300?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fe3140, {0x3e23828, 0x4002e851d0}, {0xffff695ea460, 0x4000ded200}, {0x40015cc1a8, 0x1, 0x40022a8540?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4002e851d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3286
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3343 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0b00, {0x3e23828, 0x4002e851d0}, {0xffff695ea460, 0x4000ded200}, {0x4001961460?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4002e851d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3286
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3344 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0b80, {0x3e23828, 0x4002e851d0}, {0xffff695ea460, 0x4000ded200}, {0x40019613c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4002e851d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3286
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3345 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001b93810, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3417 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002ba3600, {0x3e23828, 0x400304bcc0}, {0xffff695ea460, 0x4000ef46c0}, {0x4002973cf8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002ef6f60, {0x3e23828, 0x400304bcc0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001ba7dc0, {0x3e23828, 0x400304bcc0}, {0x3e5f080, 0x4000ef46c0}, {0x4, {0x1, 0x1, 0xff}}, 0x4003049b60)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3163
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3421 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e23828, 0x400304b950}, 0x40010f5dc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3445
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3413 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400253ce00, {0x3e23828, 0x40030e2460}, {0xffff695ea460, 0x4000f8f320}, {0x4002973b48?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002ef6a80, {0x3e23828, 0x40030e2460})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40011d0a80, {0x3e23828, 0x40030e2460}, {0x3e5f080, 0x4000f8f320}, {0x7, {0x1, 0x1, 0xff}}, 0x4003049440)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3189
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3349 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e23828, 0x4002e851d0}, 0x4000e8d280)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3342
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3352 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000280af0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400205f238}, 0x40034272c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3341
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3353 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e236d0, 0x680cae0}, 0x4000e8d3c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3352
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3356 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e23828, 0x4002e851d0}, 0x4000e8d540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3344
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3359 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ded200, {0x3e23828, 0x4002e851d0}, 0x4000e8d700)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3343
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3362 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3279
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3363 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4001f5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3279
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3366 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40030e3ef0, {0x4001b6c010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40030e3ef0, {0x4001b6c010?, 0x4002b184c8?, 0x400396e950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b25f20, {0x4001b6c010?, 0x400396e9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b25f20}, {0x4001b6c010, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40010e4d80, {0x4001b6c010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b6c000, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b6c000, 0x40010e4d80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40010e4d80?, {0xffff695c2330, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40051ac460}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5d520, {0x368b2c0, 0x40051ac460}, 0x40051adf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400396ed98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40010e4b40, 0x400396ee30, 0x400396ee78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40010e4b40, {0x368b2c0?, 0x40051ac460?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40016c2870, {0x368b2c0, 0x40051ac460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40019340b0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4001f5d380, {0x3e3faf0, 0x40019340b0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3365 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3367 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x4001b938c0, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3368 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3304
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3369 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4001f5d5f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3304
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3372 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003102230, {0x4001b6d180, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003102230, {0x4001b6d180?, 0x4002b18648?, 0x400276d950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b6d0e0, {0x4001b6d180?, 0x400276d9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b6d0e0}, {0x4001b6d180, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40010e58c0, {0x4001b6d180, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b6d170, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b6d170, 0x40010e58c0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40010e58c0?, {0xffff695c2330, 0x680cae0}, 0x1?, {0x0?, 0x0?}, {0x368b2c0, 0x400502e9a0}, 0x6227c40?, 0xffff697651d0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5d790, {0x368b2c0, 0x400502e9a0}, 0x400502ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400276dd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40010e5680, 0x400276de30, 0x400276de78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40010e5680, {0x368b2c0?, 0x400502e9a0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40016c2c90, {0x368b2c0, 0x400502e9a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001934b50)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4001f5d5f0, {0x3e3faf0, 0x4001934b50})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3371 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3373 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x4001b93970, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3374 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3322
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3375 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4001f5d860)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3322
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3292 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4002fd94f0, {0x4001a7c3a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002fd94f0, {0x4001a7c3a0?, 0x40029732c0?, 0x4002617930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001a7c360, {0x4001a7c3a0?, 0x40026179b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001a7c360}, {0x4001a7c3a0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40011b8b40, {0x4001a7c3a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001a7c390, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001a7c390, 0x40011b8b40, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40011b8b40?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001033600}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001c2dba0, {0x3612420, 0x4001033600}, 0x4001033f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002617d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40011b8900, 0x4002617e10, 0x4002617e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40011b8900, {0x3612420?, 0x4001033600?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40013332c0, {0x3612420, 0x4001033600})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40018f95f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40014b57c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3211
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3293 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40014b57c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3211
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3294 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3211
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3295 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40031e4700, 0x4001b09680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3211
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3378 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40031024b0, {0x4001b6ddb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40031024b0, {0x4001b6ddb0?, 0x4002b187e0?, 0x4002f84950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001b6dd10, {0x4001b6ddb0?, 0x4002f849d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001b6dd10}, {0x4001b6ddb0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400118a360, {0x4001b6ddb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001b6dda0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001b6dda0, 0x400118a360, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400118a360?, {0xffff695c2330, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40051ac070}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001f5da00, {0x368b2c0, 0x40051ac070}, 0x40051adf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002f84d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400118a120, 0x4002f84e30, 0x4002f84e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400118a120, {0x368b2c0?, 0x40051ac070?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40016c2fc0, {0x368b2c0, 0x40051ac070})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001935240)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4001f5d860, {0x3e3faf0, 0x4001935240})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3377 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3393 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4001c2d860)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3313
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3398 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4002fd9310, {0x4001a7c130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002fd9310, {0x4001a7c130?, 0x40029732a8?, 0x4003a53950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001a7c0f0, {0x4001a7c130?, 0x4003a539d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001a7c0f0}, {0x4001a7c130, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40011b87e0, {0x4001a7c130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001a7c120, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001a7c120, 0x40011b87e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40011b87e0?, {0xffff695c2330, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40051ac1c0}, 0x4003a53958?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001c2dad0, {0x368b2c0, 0x40051ac1c0}, 0x40051adf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003a53d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40011b85a0, 0x4003a53e30, 0x4003a53e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40011b85a0, {0x368b2c0?, 0x40051ac1c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4001333218, {0x368b2c0, 0x40051ac1c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40018f9550)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4001c2d860, {0x3e3faf0, 0x40018f9550})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3395 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3396 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3292
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3397 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40014b57c0, {0x3e3fa98, 0x40018f95f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3292
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3399 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4001e27340, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3379 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x4001b93a20, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3380 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000e97d40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3212
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3381 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e23828, 0x4002d94280}, 0x40010564c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3212
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3384 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003102f00}, {0x3e5f080?, 0x4000e97d40?}, 0x40017d11f0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3187
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3386 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001b93ad0, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3387 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001b93b80, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3388 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001b93c30, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3418 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e23828, 0x400304bcc0}, 0x40010f5c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3417
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3429 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40031b8c80, {0x4001cf4d60, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40031b8c80, {0x4001cf4d60?, 0x4002b19500?, 0x4002f81950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001cf4cf0, {0x4001cf4d60?, 0x4002f819d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001cf4cf0}, {0x4001cf4d60, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40026667e0, {0x4001cf4d60, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001cf4d50, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001cf4d50, 0x40026667e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40026667e0?, {0xffff695c2330, 0x680cae0}, 0x40018bc540?, {0x0?, 0x0?}, {0x368b2c0, 0x400502eaf0}, 0x4002f0d500?, 0x40018f9bd0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400208d110, {0x368b2c0, 0x400502eaf0}, 0x400502ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002f81d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40026665a0, 0x4002f81e30, 0x4002f81e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40026665a0, {0x368b2c0?, 0x400502eaf0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40018cf128, {0x368b2c0, 0x400502eaf0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400182a3d0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400208cea0, {0x3e3faf0, 0x400182a3d0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3425 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3381
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3461 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1080, {0x3e23828, 0x40030e20f0}, {0xffff695ea460, 0x4000e95d40}, {0x4001ab26c0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fe3320, {0x3e23828, 0x40030e20f0}, {0xffff695ea460, 0x4000e95d40}, {0x4000df7978, 0x1, 0x400207aa80?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40030e20f0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3424
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3414 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e23828, 0x40030e2460}, 0x40010f5880)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3413
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3457 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e23828, 0x40030e20f0}, 0x40013000c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3424
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3463 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4580, {0x3e23828, 0x4003102f00}, {0xffff695ea460, 0x4000e97d40}, {0x4001ab27c0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fff740, {0x3e23828, 0x4003102f00}, {0xffff695ea460, 0x4000e97d40}, {0x4000df7988, 0x1, 0x1a?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003102f00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3446
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3428 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3426 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400208cea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3381
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3462 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x4003102f00}, 0x40024fb470, 0x400183beb0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003102f00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3446
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3424 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002ba3900, {0x3e23828, 0x40030e20f0}, {0xffff695ea460, 0x4000e95d40}, {0x4002973f68?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002ef73e0, {0x3e23828, 0x40030e20f0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001ba7c00, {0x3e23828, 0x40030e20f0}, {0x3e5f080, 0x4000e95d40}, {0x1, {0x1, 0x1, 0xff}}, 0x40033a6360)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3159
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3460 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x40030e20f0}, 0x4001c97e90, 0x4001816d40)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40030e20f0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3424
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3392 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40031f6dd0, 0x4001b93ce0, 0x4003426840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3263
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3430 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x4001b93d90, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3431 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400137b680, {0x3e23828, 0x40031b90e0}, 0x4af692bdd22a0fa4, 0x4003162fc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3174
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3432 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40031b95e0, {0x40024fa340, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40031b95e0, {0x40024fa340?, 0x4002b19698?, 0x4001adb930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40024fa300, {0x40024fa340?, 0x4001adb9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40024fa300}, {0x40024fa340, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40026678c0, {0x40024fa340, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40024fa330, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40024fa330, 0x40026678c0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40026678c0?, {0xffff695c2330, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001033400}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400208dd40, {0x3612420, 0x4001033400}, 0x4001033f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4001adbd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002667680, 0x4001adbe10, 0x4001adbe58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002667680, {0x3612420?, 0x4001033400?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4001860000, {0x3612420, 0x4001033400})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x400182af70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400137b680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3174
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3433 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400137b680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3174
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3434 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3174
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3435 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4001bae780, 0x4001cf5b90)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3174
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3437 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e23828, 0x4002b91590}, 0x40011f4180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3175
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3440 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3432
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3441 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400137b680, {0x3e3fa98, 0x400182af70})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3432
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3442 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x1945910?, {0x3e23828, 0x40031b9720}, {0x3e5f080?, 0x4000decb40?}, 0x4000940030)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3155
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3477 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40036a9f00, {0x3e23828, 0x40031b9720}, {0xffff695ea460, 0x4000decb40}, {0x4002b19cc8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003110ea0, {0x3e23828, 0x40031b9720})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001ba7880, {0x3e23828, 0x40031b9720}, {0x3e5f080, 0x4000decb40}, {0x6, {0x1, 0x1, 0xff}}, 0x40033e2b40)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3155
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3446 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4001fd9f00, {0x3e23828, 0x4003102f00}, {0xffff695ea460, 0x4000e97d40}, {0x4002b19908?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40031057a0, {0x3e23828, 0x4003102f00})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x40011d08c0, {0x3e23828, 0x4003102f00}, {0x3e5f080, 0x4000e97d40}, {0x3, {0x1, 0x1, 0xff}}, 0x4003163ce0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3187
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3447 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e23828, 0x4003102f00}, 0x40011f4a40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3446
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3450 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3437
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3451 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40024e4c30)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3437
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3454 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40031c8550, {0x40024febb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40031c8550, {0x40024febb0?, 0x4002b19b00?, 0x4002fcf950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40024feb70, {0x40024febb0?, 0x4002fcf9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40024feb70}, {0x40024febb0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40020a59e0, {0x40024febb0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40024feba0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40024feba0, 0x40020a59e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40020a59e0?, {0xffff695c2330, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40051ac310}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40024e4dd0, {0x368b2c0, 0x40051ac310}, 0x40051adf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002fcfd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40020a57a0, 0x4002fcfe30, 0x4002fcfe78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40020a57a0, {0x368b2c0?, 0x40051ac310?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4001860a38, {0x368b2c0, 0x40051ac310})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400180a5c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40024e4c30, {0x3e3faf0, 0x400180a5c0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3453 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3455 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4001b93e40, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3456 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x40030e2460}, 0x40022a0c30, 0x400180b270)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40030e2460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3413
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3473 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4b00, {0x3e23828, 0x40030e2460}, {0xffff695ea460, 0x4000f8f320}, {0x400128ac40?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fff920, {0x3e23828, 0x40030e2460}, {0xffff695ea460, 0x4000f8f320}, {0x4001b8a330, 0x1, 0x206bc?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40030e2460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3413
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3474 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e23828, 0x40030e2460}, 0x40011f5c40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3473
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3478 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e23828, 0x40031b9720}, 0x40011f5ec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3477
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3481 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400047f260, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400207baf8}, 0x4003049500)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3456
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3482 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e236d0, 0x680cae0}, 0x400135e040)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3481
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3485 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4a00, {0x3e23828, 0x40030e2460}, {0xffff695ea460, 0x4000f8f320}, {0x400128b000?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40030e2460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3413
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3486 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4a80, {0x3e23828, 0x40030e2460}, {0xffff695ea460, 0x4000f8f320}, {0x400128ae80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40030e2460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3413
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3487 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e23828, 0x40030e2460}, 0x400135e340)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3486
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3490 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000f8f320, {0x3e23828, 0x40030e2460}, 0x400135e540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3485
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3493 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x40000ec0b0, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3494 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x400304b950}, 0x40024faf30, 0x400183a130)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400304b950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3445
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3495 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1580, {0x3e23828, 0x400304b950}, {0xffff695ea460, 0x4000dfe6c0}, {0x400128b2c0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fe3800, {0x3e23828, 0x400304b950}, {0xffff695ea460, 0x4000dfe6c0}, {0x4001b8a430, 0x1, 0x400254bdc0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400304b950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3445
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3496 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e23828, 0x400304b950}, 0x400135e940)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3495
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3464 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0f80, {0x3e23828, 0x40030e20f0}, {0xffff695ea460, 0x4000e95d40}, {0x4001ab29a0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40030e20f0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3424
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3465 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1000, {0x3e23828, 0x40030e20f0}, {0xffff695ea460, 0x4000e95d40}, {0x4001ab28c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40030e20f0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3424
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3499 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x400304bcc0}, 0x4001c971a0, 0x400183a270)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400304bcc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3417
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3500 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1b80, {0x3e23828, 0x400304bcc0}, {0xffff695ea460, 0x4000ef46c0}, {0x400128b500?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fe3a40, {0x3e23828, 0x400304bcc0}, {0xffff695ea460, 0x4000ef46c0}, {0x4001b8a468, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400304bcc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3417
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3501 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1480, {0x3e23828, 0x400304b950}, {0xffff695ea460, 0x4000dfe6c0}, {0x400128b820?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400304b950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3445
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3502 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1500, {0x3e23828, 0x400304b950}, {0xffff695ea460, 0x4000dfe6c0}, {0x400128b600?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400304b950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3445
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3503 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1a80, {0x3e23828, 0x400304bcc0}, {0xffff695ea460, 0x4000ef46c0}, {0x400128b900?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400304bcc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3417
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3504 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e1b00, {0x3e23828, 0x400304bcc0}, {0xffff695ea460, 0x4000ef46c0}, {0x400128b780?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400304bcc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3417
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3505 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x400045e000, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3506 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x400045e0b0, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3507 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e23828, 0x40030e20f0}, 0x40014d4180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3465
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3510 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e23828, 0x400304bcc0}, 0x40014d42c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3500
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3513 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e23828, 0x4003102f00}, 0x40014d43c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3463
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3516 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400027ca80, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400207be78}, 0x40033a6420)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3460
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3517 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e236d0, 0x680cae0}, 0x40014d4500)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3516
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3520 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400027f340, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40022b5af8}, 0x4003163c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3494
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3521 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e236d0, 0x680cae0}, 0x40014d4600)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3520
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3524 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e23828, 0x400304b950}, 0x40014d4740)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3502
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3527 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e23828, 0x40030e20f0}, 0x40014d4840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3461
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3530 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400027c000, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400207bcb8}, 0x4003049c20)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3499
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3531 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e236d0, 0x680cae0}, 0x40014d49c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3530
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3534 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e23828, 0x400304bcc0}, 0x40014d4b80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3504
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3537 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000dfe6c0, {0x3e23828, 0x400304b950}, 0x40014d4c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3501
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3540 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000ef46c0, {0x3e23828, 0x400304bcc0}, 0x40014d4d80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3503
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3543 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4480, {0x3e23828, 0x4003102f00}, {0xffff695ea460, 0x4000e97d40}, {0x40016ac620?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003102f00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3446
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3544 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025f4500, {0x3e23828, 0x4003102f00}, {0xffff695ea460, 0x4000e97d40}, {0x40016ac4c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003102f00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3446
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3545 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e23828, 0x4003102f00}, 0x40014d54c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3544
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3548 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400027f5e0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40022b5cb8}, 0x4003163da0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3462
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3549 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e236d0, 0x680cae0}, 0x40014d5700)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3548
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3552 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x400045e160, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3569 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x400045e210, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3466 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e95d40, {0x3e23828, 0x40030e20f0}, 0x4001301480)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3464
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3469 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4001e273f0, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3470 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000e97d40, {0x3e23828, 0x4003102f00}, 0x4001301740)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3543
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3553 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x4001e274a0, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3554 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x4001e27760, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3555 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4001e27810, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3556 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x4001e278c0, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3570 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x400045e420, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3571 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x400045e4d0, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3572 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400208cea0, 0x400045e580, 0x4003162a20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3426
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3557 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x4001e27970, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3573 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x400045e630, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3574 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x4000a376b0, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3575 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d5f0, 0x4000a37760, 0x4003978c60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3369
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3576 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4000a37810, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3577 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4000a378c0, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3558 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d380, 0x4001e27a20, 0x4003978600)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3363
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3578 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001676c40, {0x3e23828, 0x40031b9720}, 0x40024ff7d0, 0x40019728a0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40031b9720})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3477
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3579 [chan receive, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0200, {0x3e23828, 0x40031b9720}, {0xffff695ea460, 0x4000decb40}, {0x40016ad360?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4001fe2f60, {0x3e23828, 0x40031b9720}, {0xffff695ea460, 0x4000decb40}, {0x4001b8a978, 0x1, 0x4002597500?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40031b9720})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3477
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3580 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e23828, 0x40031b9720}, 0x4000d9d080)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3579
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3583 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400029b2d0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400254b238}, 0x40033e2c00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3578
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3584 [select, 5 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e236d0, 0x680cae0}, 0x4000d9d180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3583
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3587 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400229ff00, {0x3e23828, 0x40031b9720}, {0xffff695ea460, 0x4000decb40}, {0x40016ad760?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40031b9720})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3477
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3588 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40025e0180, {0x3e23828, 0x40031b9720}, {0xffff695ea460, 0x4000decb40}, {0x40016ad600?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40031b9720})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3477
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3589 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e23828, 0x40031b9720}, 0x4000d9d480)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3588
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3592 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000decb40, {0x3e23828, 0x40031b9720}, 0x4000d9d680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3587
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3595 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4000a37970, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3596 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x4000a37a20, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3597 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x4000a37ad0, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3598 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x4000a37d90, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3559 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001c2d860, 0x4001e27ad0, 0x4003427f20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3393
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3599 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4001f5d860, 0x4000c666e0, 0x4003979260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3375
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3560 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4001e27b80, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3561 [select, 5 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4001e27c30, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3562 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4001e27ce0, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3600 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40024e4c30, 0x4000c673f0, 0x40033e23c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3451
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4590 [IO wait, 5 minutes]:
internal/poll.runtime_pollWait(0xffff6951d560, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40038c9b80?, 0x4001ee6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40038c9b80, {0x4001ee6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40038c9b80, {0x4001ee6000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40011deb30, {0x4001ee6000?, 0x72?, 0x40038c3118?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40038c3110, {0x4001ee6000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400299f320)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400299f320, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40038f7c20, {0x3e237f0, 0x4001a722a0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1721
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5212 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4cb0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004c75c80?, 0x40042b0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004c75c80, {0x40042b0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004c75c80, {0x40042b0000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000ca27f8, {0x40042b0000?, 0x72?, 0x40057c34d8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40057c34d0, {0x40042b0000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003a0c840)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003a0c840, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40057ca480, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10628 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10937 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10296 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4004abbe48, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004abbe38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004abbe30, {0x4005099c04, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40034c1cc8?}, {0x4005099c04?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4004abbe00}, {0x4005099c04, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003e53b30, {0x4003685000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003a43220, 0x0, {0x3e02238, 0x40051078c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000671ca0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4003cddc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 755
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 4440 [select]:
net/http.(*persistConn).writeLoop(0x4002667320)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4363
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4237 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002b90230})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0e140, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000863690, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4221
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10934 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4572 [select, 5 minutes]:
net/http.(*persistConn).writeLoop(0x40021e5b00)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4570
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 10627 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4289 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40022be000, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002dcfbd0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4277
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4482 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951da38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bf00?, 0x40036a6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bf00, {0x40036a6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bf00, {0x40036a6000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8adc8, {0x40036a6000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f98c0, {0x40036a6000?, 0x400004dd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40030a6360)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40030a6360, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f98c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4480
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 9782 [select]:
reflect.rselect({0x40010a1680, 0x9, 0xffff69785b38?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x400481f200?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001cf4030, {0x3e237f0, 0x4005017230}, 0x40002f99d0, {0xffff69439d90, 0x40008585d0}, 0x40023d5800, {0x381b81a?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001cf4030, {0x3e237f0, 0x4005017230}, {0xffff69439d90, 0x40008585d0}, {0x381b81a, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0x4001cf4030, {0x3e3e378, 0x40008585d0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:144 +0x78
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x365dfc0?, 0x4001cf4030}, {0x3e32818, 0x400211bb30})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1711 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40029b2a00, {0x3e237f0, 0x4005017020}, {0x3e42860, 0x4001bef380}, 0x400484b560, 0x4001cf4390, 0x6217f00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40029b2a00, {0x3e42860, 0x4001bef380}, 0x400484b560)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1218
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 4455 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4300, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bb80?, 0x4003670000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bb80, {0x4003670000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bb80, {0x4003670000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8abe0, {0x4003670000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002127320, {0x4003670000?, 0x4003b81d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e547e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e547e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002127320)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4453
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4468 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4018, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bd00?, 0x400367a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bd00, {0x400367a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bd00, {0x400367a000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8acc8, {0x400367a000?, 0x12?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f8a20, {0x400367a000?, 0x40031e8d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e557a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e557a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f8a20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4466
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10652 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4438 [select]:
net/http.(*persistConn).writeLoop(0x4000de2c60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4417
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4268 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002131a40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4277
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4459 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4208, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bc00?, 0x4003672000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bc00, {0x4003672000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bc00, {0x4003672000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8ac20, {0x4003672000?, 0x12?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002127680, {0x4003672000?, 0x400313ad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e54b40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e54b40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002127680)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4457
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4456 [select]:
net/http.(*persistConn).writeLoop(0x4002127320)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4453
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4437 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d45e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003cd9e80?, 0x40035ac000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003cd9e80, {0x40035ac000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003cd9e80, {0x40035ac000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8aa98, {0x40035ac000?, 0x13?, 0x40031ecd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4000de2c60, {0x40035ac000?, 0x40031ecd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002eed4a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002eed4a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4000de2c60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4417
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4448 [select]:
net/http.(*persistConn).writeLoop(0x400211c360)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4445
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4443 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d46e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0ba00?, 0x40035f4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0ba00, {0x40035f4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0ba00, {0x40035f4000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8ab20, {0x40035f4000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4000de3c20, {0x40035f4000?, 0x40031e9d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002eedb00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002eedb00, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4000de3c20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4441
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4444 [select]:
net/http.(*persistConn).writeLoop(0x4000de3c20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4441
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4483 [select]:
net/http.(*persistConn).writeLoop(0x40010f98c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4480
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4514 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4bb8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003778c00?, 0x4001fee000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003778c00, {0x4001fee000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003778c00, {0x4001fee000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000cdf4b0, {0x4001fee000?, 0x72?, 0x40034cfb98?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40034cfb90, {0x4001fee000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4001bc86c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4001bc86c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003d1dd40, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 11220 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4447 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d44f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0ba80?, 0x400366a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0ba80, {0x400366a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0ba80, {0x400366a000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8ab70, {0x400366a000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400211c360, {0x400366a000?, 0x4003219d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e541e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e541e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400211c360)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4445
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4240 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0e3c0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002b90370, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4221
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11498 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10648 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4614 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff695d49c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003c98380?, 0x4002000000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003c98380, {0x4002000000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003c98380, {0x4002000000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000ca3058, {0x4002000000?, 0x72?, 0x4003c74278?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003c74270, {0x4002000000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4001a74c00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4001a74c00, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003c9a870, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4486 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951d940, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40036d8000?, 0x40036e6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40036d8000, {0x40036e6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40036d8000, {0x40036e6000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8af88, {0x40036e6000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f9e60, {0x40036e6000?, 0x40034b8d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40030a6600)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40030a6600, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f9e60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4484
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10183 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4295 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40022bea00, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40012967f0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4289
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4336 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40014b5ea0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4329
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4451 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d43f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bb00?, 0x400366e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bb00, {0x400366e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bb00, {0x400366e000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8abb0, {0x400366e000?, 0x11?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002126fc0, {0x400366e000?, 0x40031ead18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e544e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e544e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002126fc0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4449
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4365 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951dc28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0be00?, 0x4003702000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0be00, {0x4003702000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0be00, {0x4003702000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000cdf3b8, {0x4003702000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f9200, {0x4003702000?, 0x40034b6d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400345fe00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400345fe00, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f9200)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4474
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4197 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d48d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003b31380?, 0x4003ce9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003b31380, {0x4003ce9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003b31380, {0x4003ce9000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400107be40, {0x4003ce9000?, 0x72?, 0x4000cce338?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000cce330, {0x4003ce9000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003d9b2c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d9b2c0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001fb8870, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4472 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951dd20, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bd80?, 0x4003690000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bd80, {0x4003690000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bd80, {0x4003690000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8acf8, {0x4003690000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f8d80, {0x4003690000?, 0x4003811d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e55a40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e55a40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f8d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4470
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4473 [select]:
net/http.(*persistConn).writeLoop(0x40010f8d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4470
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4452 [select]:
net/http.(*persistConn).writeLoop(0x4002126fc0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4449
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4469 [select]:
net/http.(*persistConn).writeLoop(0x40010f8a20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4466
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4272 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035bbe00, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002a8f5c0}, 0x400044d650, 0x0, 0x40015482d0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4277
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4239 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001a0e280, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002980720}, 0x40003077a0, 0x0, 0x4000e31860, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4221
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4235 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002131040)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4221
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 10377 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4479 [select]:
net/http.(*persistConn).writeLoop(0x40010f9560)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4476
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4270 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002dcf9f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035bbcc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001923000, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4277
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4487 [select]:
net/http.(*persistConn).writeLoop(0x40010f9e60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4484
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4478 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951db30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0be80?, 0x40036a2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0be80, {0x40036a2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0be80, {0x40036a2000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8ad78, {0x40036a2000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010f9560, {0x40036a2000?, 0x4003817d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40030a6120)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40030a6120, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010f9560)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4476
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4273 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003112c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000f24ed0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4240
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4271 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400274af01?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000e37800?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4277
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4238 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4001bc7ec0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000c93dd0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4221
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4265 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035ba780, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002a7c4e0}, 0x4001998f80, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10939 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4463 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d4110, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d0bc80?, 0x4003676000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d0bc80, {0x4003676000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d0bc80, {0x4003676000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8ac50, {0x4003676000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002127d40, {0x4003676000?, 0x4003b82d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002e54de0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e54de0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002127d40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4461
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4299 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40022bf180, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002b6b980}, 0x40018f8040, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4460 [select]:
net/http.(*persistConn).writeLoop(0x4002127680)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4457
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4354 [select, 5 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40031b9220})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b14dc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40018728c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4329
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4355 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000d97c40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4329
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4356 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b14f00, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40031bd5c0}, 0x4000314700, 0x0, 0x4001bbba10, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4329
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4357 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b15040, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40031b9360, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4329
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4372 [select, 5 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039d5b80, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002ef7140}, 0x4000c61ee0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4355
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4439 [IO wait]:
internal/poll.runtime_pollWait(0xffff695d47d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40023b1600?, 0x40035ca000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40023b1600, {0x40035ca000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40023b1600, {0x40035ca000?, 0x4001fa8000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001b8aac0, {0x40035ca000?, 0xf?, 0x4003043c00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4002667320, {0x40035ca000?, 0x4000053d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002eed620)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002eed620, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4002667320)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4363
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4352 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039d5540, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001797710, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4357
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4464 [select]:
net/http.(*persistConn).writeLoop(0x4002127d40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4461
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4366 [select]:
net/http.(*persistConn).writeLoop(0x40010f9200)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4474
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 11496 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11253 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11258 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4571 [IO wait, 5 minutes]:
internal/poll.runtime_pollWait(0xffff6951d848, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003ae2480?, 0x4003b74000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003ae2480, {0x4003b74000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003ae2480, {0x4003b74000?, 0x1?, 0x40035c08c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000ca2a28, {0x4003b74000?, 0xc?, 0x40037edd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40021e5b00, {0x4003b74000?, 0x18550?, 0x4002e57d40?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40038f3140)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40038f3140, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40021e5b00)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4570
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10180 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10625 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10372 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10380 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10379 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9870 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:117 +0x68
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn in goroutine 9869
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:116 +0xb4

goroutine 7788 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002ea6048, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002ea6038)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002ea6030, {0x4005537e7c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40037ebcc8?}, {0x4005537e7c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x4002ea6000}, {0x4005537e7c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400367fe60, {0x4003c97000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003102c80, 0x0, {0x3e02238, 0x4005166e40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400147d880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001175500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1411
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10191 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10190 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10189 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5018 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6951d658, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40023b0400?, 0x400177f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40023b0400, {0x400177f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40023b0400, {0x400177f000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000eefdd0, {0x400177f000?, 0x72?, 0x4003b98878?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003b98870, {0x400177f000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40035bd260)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40035bd260, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003b7bef0, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10626 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11761 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11497 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11499 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10936 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10204 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10369 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11122 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4004819cc8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004819cb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004819cb0, {0x4003701201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40030abcc8?}, {0x4003701201?, 0x40030abcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40031faa00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40031faa00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40031faa00, {0x30150e0, 0x4003825020})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40030c8d20, {0x400394d400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003aee460, 0x0, {0x3e02238, 0x4000ed1b40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40019c6ae0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4000cec180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1462
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5530 [IO wait]:
internal/poll.runtime_pollWait(0xffff6951d278, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40044aeb00?, 0x4004774000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40044aeb00, {0x4004774000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40044aeb00, {0x4004774000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014225b0, {0x4004774000?, 0x72?, 0x4004136938?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4004136930, {0x4004774000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002af6060)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002af6060, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40048f1dd0, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 11759 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5027 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6951d750, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003786c80?, 0x4001966000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003786c80, {0x4001966000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003786c80, {0x4001966000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001186758, {0x4001966000?, 0x72?, 0x4003a7e998?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003a7e990, {0x4001966000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003fa5b00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003fa5b00, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40039f2ab0, {0x3e237f0, 0x4001004630})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1640
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10044 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4355
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10181 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10935 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9924 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4355
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10651 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11753 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40017a9650, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40017a9640)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40017a9600, {0x3e23828, 0x4005404050}, {0x4005952c40, 0x35}, 0x11, {0x4000397225, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1219
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 11493 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11492 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 7077 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400160e7d0, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400160e7c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0x4001e78d90)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:159 +0x134
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 816
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:176 +0x60

goroutine 10649 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9784 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4004da0460, {0x4005017180, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4004da0460, {0x4005017180?, 0x400443d188?, 0x400261b510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4005016900, {0x4005017180?, 0x400261b598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4005016900}, {0x4005017180, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400484b560, {0x4005017180, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4005017170, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4005017170, 0x400484b560, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400261b7c8?, {0xffff695c2330, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x4005116460}, 0x4002adc1c0?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x400211bb30, {0x35bf9e0, 0x4005116460})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0x40008585d0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1730 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x3e31c48?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 9782
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 10376 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10940 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10192 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10371 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11494 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10647 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9869 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff695d4ac0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004bc7e80?, 0x4004bf5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0x4004bc7e80, {0x4004bf5000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x40000000)
	/usr/local/go/src/internal/poll/fd_unix.go:301 +0x284
net.(*netFD).readMsg(0x4004bc7e80, {0x4004bf5000?, 0x400528b470?, 0x400528b440?}, {0x0?, 0x40052a8cf0?, 0x4002027b88?}, 0x25809a0?)
	/usr/local/go/src/net/fd_posix.go:78 +0x30
net.(*UnixConn).readMsg(0x4000fed4a0, {0x4004bf5000?, 0x4002027be8?, 0x2577428?}, {0x0?, 0x40026095c0?, 0x4005d7c787?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x38
net.(*UnixConn).ReadMsgUnix(0x4000fed4a0, {0x4004bf5000?, 0x5?, 0x377a3b0?}, {0x0?, 0x20270?, 0x3788a53?})
	/usr/local/go/src/net/unixsock.go:143 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0x4002609860, {0x3e23828, 0x40029b0a00}, 0x4000fed4a0)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:132 +0x12c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1 in goroutine 396
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x138

goroutine 10378 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10896 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10938 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10933 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11257 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11221 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10913 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11222 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11256 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11495 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11254 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11223 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11574 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40041c9cc8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40041c9cb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40041c9cb0, {0x4005226a00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40030becc8?}, {0x4005226a00?, 0x40030bec88?, 0x5a7bc?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4004a75cc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4004a75cc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4004a75cc0, {0x30150e0, 0x4004a76828})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400522a480, {0x4004c29400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4005228370, 0x0, {0x3e02238, 0x4005057bc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40012c58e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005057b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11762 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11255 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11951 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40032256c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40032256b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40032256b0, {0x4005226000, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40021e3cc8?}, {0x4005226000?, 0x40021e3c68?, 0x102628?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003582a00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003582a00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003582a00, {0x30150e0, 0x4001bab3c8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4000ae4120, {0x40020d8c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004a94a00, 0x0, {0x3e02238, 0x4001147dc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400002d760)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001147d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 847
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11766 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11758 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11760 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11756 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40017a9550, 0x1a)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40017a9540)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40017a9500, {0x3e23828, 0x4005404140}, {0x400594de90, 0x28}, 0x12d, {0x400128b2c5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 9782
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 11757 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4238
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11765 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11692 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400593c1c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400593c1b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400593c1b0, {0x4005928e00, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40046becc8?}, {0x4005928e00?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69606758, 0x400593c180}, {0x4005928e00, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4004bdbe90, {0x40050d7800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4005936ff0, 0x0, {0x3e02238, 0x400593e1c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000a73e20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400593e180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1471
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11764 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11763 [sleep]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4271
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4
