IP ADDRESS         LOCAL ENDPOINT INFO
10.1.0.252:0       id=3112  sec_id=151863 flags=0x0000 ifindex=17  mac=A2:9E:BD:F8:FD:03 nodemac=AA:72:7D:A9:64:2B   
10.1.0.16:0        id=1376  sec_id=157096 flags=0x0000 ifindex=21  mac=3A:D2:94:F0:73:39 nodemac=EE:33:02:84:4C:4A   
10.1.0.39:0        id=1997  sec_id=4     flags=0x0000 ifindex=7   mac=7A:83:71:9F:4D:AF nodemac=36:4B:E0:4E:C1:79    
10.1.0.21:0        id=216   sec_id=148646 flags=0x0000 ifindex=19  mac=DE:87:D2:A0:F3:6B nodemac=4A:DB:14:06:1C:50   
172.31.234.224:0   (localhost)                                                                                       
10.1.0.64:0        id=1341  sec_id=135727 flags=0x0000 ifindex=11  mac=EE:13:1E:19:4D:CE nodemac=1A:A4:32:94:DB:86   
10.1.0.56:0        id=1730  sec_id=147144 flags=0x0000 ifindex=15  mac=62:D9:C0:B3:AB:0A nodemac=52:02:C3:E2:71:BD   
10.1.0.196:0       id=303   sec_id=135727 flags=0x0000 ifindex=9   mac=8E:0A:60:A7:4E:19 nodemac=26:27:71:5A:89:11   
10.1.0.5:0         (localhost)                                                                                       
