Found 7 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.199.121
     ✅ TCP connection successfully established to 10.100.199.121:2379
     ✅ TLS connection successfully established to 10.100.199.121:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       e9:e5:f8:72:10:95:fb:5c:cb:c1:02:1f:bd:b0:c6:fa
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:15:36 +0000 UTC
          Not after:   2027-10-24 09:15:36 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       60:79:29:1d:de:7e:42:91:7a:fd:0f:c7:9b:fc:ac:6b:35:95:64:71
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 446817dd4098122e
