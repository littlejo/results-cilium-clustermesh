172.31.249.188 dev ens5 lladdr 12:cf:9a:37:81:39 REACHABLE
172.31.208.9 dev ens5 lladdr 12:92:ce:3b:56:0b REACHABLE
172.31.224.68 dev ens5 lladdr 12:8e:8d:ec:57:b3 REACHABLE
172.31.248.255 dev ens5 lladdr 12:41:ed:c8:6b:69 REACHABLE
172.31.192.1 dev ens5 lladdr 12:77:39:73:55:d5 REACHABLE
