1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 02:0b:f9:02:e9:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.167.173/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2987sec preferred_lft 2987sec
    inet6 fe80::b:f9ff:fe02:e94b/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:fe:dc:3a:85:2c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::64fe:dcff:fe3a:852c/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:a5:12:fe:c3:13 brd ff:ff:ff:ff:ff:ff
    inet 10.4.0.230/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b8a5:12ff:fefe:c313/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:63:70:ee:bd:ce brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c63:70ff:feee:bdce/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:62:bd:f5:03:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4c62:bdff:fef5:331/64 scope link 
       valid_lft forever preferred_lft forever
9: lxceb65690dfaed@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:dd:38:52:88:bc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d0dd:38ff:fe52:88bc/64 scope link 
       valid_lft forever preferred_lft forever
11: lxcad13466e51ce@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:fc:78:3a:2c:81 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c8fc:78ff:fe3a:2c81/64 scope link 
       valid_lft forever preferred_lft forever
15: lxc99a47c4a39e2@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:53:00:2b:e4:9b brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f853:ff:fe2b:e49b/64 scope link 
       valid_lft forever preferred_lft forever
17: lxc1f40b3fd9411@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:fe:93:e0:9b:26 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::f0fe:93ff:fee0:9b26/64 scope link 
       valid_lft forever preferred_lft forever
19: lxc142ae6a3e494@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:14:39:e4:98:ca brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::7c14:39ff:fee4:98ca/64 scope link 
       valid_lft forever preferred_lft forever
21: lxccd75ea23b396@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:07:0b:a8:c5:8f brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d407:bff:fea8:c58f/64 scope link 
       valid_lft forever preferred_lft forever
