29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:14:35+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:14:36+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:14:36+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:14:36+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:37+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:14:41+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
55: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
58: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
59: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
62: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:14:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
70: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
73: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
97: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
100: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
441: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:15:21+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 112
442: sched_cls  name tail_handle_ipv4  tag 983bb453aeb608f8  gpl
	loaded_at 2024-10-24T09:15:21+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,89
	btf_id 113
443: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:15:21+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,89
	btf_id 114
444: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:15:21+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 115
467: sched_cls  name tail_ipv4_to_endpoint  tag 63af7b0558d0a68e  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,98,33,74,75,72,96,31,97,32,29,30
	btf_id 141
468: sched_cls  name tail_handle_arp  tag 5eadff6b3f47a32a  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,97
	btf_id 142
470: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 144
471: sched_cls  name handle_policy  tag 79d97f5fab7044de  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,97,74,75,98,33,72,96,31,76,67,32,29,30
	btf_id 145
472: sched_cls  name tail_handle_ipv4_cont  tag 247128506e85d10b  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,98,33,96,74,75,31,68,66,69,97,32,29,30,73
	btf_id 146
473: sched_cls  name cil_from_container  tag bfcb5a357dd58c24  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 97,68
	btf_id 147
474: sched_cls  name tail_handle_ipv4  tag 8d902d2299ad4b89  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,97
	btf_id 148
475: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,97
	btf_id 149
476: sched_cls  name tail_ipv4_ct_ingress  tag 7676305d62da34b5  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,97,74,75,98,76
	btf_id 150
477: sched_cls  name __send_drop_notify  tag 611d64fe29f2c8dd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 151
478: sched_cls  name tail_handle_arp  tag 726a0de374afdc25  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,99
	btf_id 153
479: sched_cls  name tail_ipv4_ct_ingress  tag 432c444aa1e143d1  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 154
480: sched_cls  name tail_handle_ipv4  tag a56789627257a448  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,99
	btf_id 155
481: sched_cls  name __send_drop_notify  tag c59d6e6e676146f1  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 156
482: sched_cls  name tail_ipv4_to_endpoint  tag 1fcb9689bf8433af  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,100,33,74,75,72,91,31,99,32,29,30
	btf_id 157
483: sched_cls  name handle_policy  tag 85b413a29d86f200  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,99,74,75,100,33,72,91,31,76,67,32,29,30
	btf_id 158
484: sched_cls  name tail_handle_ipv4_cont  tag 083414fe5fba0a68  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,100,33,91,74,75,31,68,66,69,99,32,29,30,73
	btf_id 159
485: sched_cls  name tail_ipv4_ct_egress  tag fa9b1d413515eb71  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,99,74,75,100,76
	btf_id 160
486: sched_cls  name cil_from_container  tag 30debf2aa53700f2  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 99,68
	btf_id 161
488: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,99
	btf_id 163
489: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 165
490: sched_cls  name cil_from_container  tag d9f94bc40e6d7a6d  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 166
491: sched_cls  name tail_ipv4_ct_ingress  tag 7f26b4a399df223a  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 167
492: sched_cls  name __send_drop_notify  tag 181956a274a9e322  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 168
493: sched_cls  name tail_handle_arp  tag 883c0019625550e8  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 169
494: sched_cls  name tail_handle_ipv4  tag c84e978fc408a42f  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 170
495: sched_cls  name tail_ipv4_to_endpoint  tag 32e1e8527c388ec1  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,102,33,74,75,72,90,31,101,32,29,30
	btf_id 171
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
503: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
504: sched_cls  name tail_handle_ipv4_cont  tag c2d529156c919f20  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,102,33,90,74,75,31,68,66,69,101,32,29,30,73
	btf_id 172
505: sched_cls  name tail_ipv4_ct_egress  tag fa9b1d413515eb71  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 173
507: sched_cls  name handle_policy  tag ad928cff068c230c  gpl
	loaded_at 2024-10-24T09:15:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,102,33,72,90,31,76,67,32,29,30
	btf_id 175
508: sched_cls  name __send_drop_notify  tag 69fafe51e40665cd  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 177
509: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,106
	btf_id 178
511: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 180
513: sched_cls  name tail_handle_ipv4_from_host  tag 2e2cfd47e27499ec  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,106
	btf_id 182
514: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,106
	btf_id 183
516: sched_cls  name tail_handle_ipv4_from_host  tag 2e2cfd47e27499ec  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,108
	btf_id 186
517: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,108
	btf_id 187
518: sched_cls  name __send_drop_notify  tag 69fafe51e40665cd  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 188
521: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 191
522: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,110,67
	btf_id 193
523: sched_cls  name tail_handle_ipv4_from_host  tag 2e2cfd47e27499ec  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 194
524: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 195
525: sched_cls  name __send_drop_notify  tag 69fafe51e40665cd  gpl
	loaded_at 2024-10-24T09:15:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 196
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
536: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
576: sched_cls  name handle_policy  tag b3bba3aa9d5c9ece  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,124,74,75,125,33,72,123,31,76,67,32,29,30
	btf_id 215
577: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,124
	btf_id 216
578: sched_cls  name cil_from_container  tag 2ebfb134bbe94506  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 124,68
	btf_id 217
579: sched_cls  name tail_handle_ipv4  tag be86af1568ad6cb4  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,124
	btf_id 218
581: sched_cls  name tail_ipv4_ct_egress  tag 4504e6e8fe7dcf7e  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 220
582: sched_cls  name tail_ipv4_ct_ingress  tag f766cefc1b231e9b  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,124,74,75,125,76
	btf_id 221
583: sched_cls  name tail_ipv4_to_endpoint  tag e89013c755e0f3c3  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,125,33,74,75,72,123,31,124,32,29,30
	btf_id 222
584: sched_cls  name __send_drop_notify  tag 70831b30a811b70b  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 223
585: sched_cls  name tail_handle_arp  tag fa18630e3fc5fa8f  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,124
	btf_id 224
586: sched_cls  name tail_handle_ipv4_cont  tag 61fdd2caa421680f  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,125,33,123,74,75,31,68,66,69,124,32,29,30,73
	btf_id 225
587: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
590: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
603: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
606: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
607: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
610: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
641: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
644: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
656: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
659: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
660: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
663: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3339: sched_cls  name tail_ipv4_to_endpoint  tag 100d5a3119f660a5  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,634,33,74,75,72,141,31,633,32,29,30
	btf_id 3168
3340: sched_cls  name tail_handle_ipv4  tag 9f9f63b4ab278ab2  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,633
	btf_id 3169
3341: sched_cls  name tail_handle_ipv4_cont  tag 7880d4bb60c84b68  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,634,33,141,74,75,31,68,66,69,633,32,29,30,73
	btf_id 3170
3342: sched_cls  name tail_ipv4_ct_egress  tag afc3553b8a180448  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,633,74,75,634,76
	btf_id 3171
3343: sched_cls  name cil_from_container  tag 23c4295fa2005826  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 633,68
	btf_id 3172
3344: sched_cls  name __send_drop_notify  tag d2dcd76902cbe6ec  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3173
3345: sched_cls  name tail_handle_arp  tag 4a504393d1473fda  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,633
	btf_id 3174
3346: sched_cls  name handle_policy  tag 357278963384ce07  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,633,74,75,634,33,72,141,31,76,67,32,29,30
	btf_id 3175
3347: sched_cls  name tail_ipv4_ct_ingress  tag 1d0493509ae558fe  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,633,74,75,634,76
	btf_id 3176
3348: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:20+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,633
	btf_id 3177
3635: sched_cls  name __send_drop_notify  tag cea5bde720f1720c  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3493
3636: sched_cls  name cil_from_container  tag 5ad052f0ce15a3b5  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 689,68
	btf_id 3494
3637: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,688
	btf_id 3491
3638: sched_cls  name __send_drop_notify  tag 6272e48d07eddcb7  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3496
3640: sched_cls  name tail_handle_ipv4_cont  tag 0e6f1a5e39343d2b  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,690,33,133,74,75,31,68,66,69,689,32,29,30,73
	btf_id 3495
3641: sched_cls  name tail_handle_ipv4  tag 798fd17d0d9993e4  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,688
	btf_id 3498
3642: sched_cls  name tail_handle_ipv4  tag 0b0bf999891f51b4  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,689
	btf_id 3499
3643: sched_cls  name tail_ipv4_ct_ingress  tag 78f6b3c499ad5122  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,688,74,75,687,76
	btf_id 3500
3644: sched_cls  name tail_ipv4_ct_ingress  tag fb7c036afd4d7c7d  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,689,74,75,690,76
	btf_id 3501
3645: sched_cls  name tail_handle_arp  tag 046fa74fab679589  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,689
	btf_id 3503
3646: sched_cls  name tail_handle_ipv4_cont  tag ac2bb2172efb1d4f  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,687,33,136,74,75,31,68,66,69,688,32,29,30,73
	btf_id 3502
3647: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,689
	btf_id 3504
3649: sched_cls  name handle_policy  tag b08328949f692810  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,689,74,75,690,33,72,133,31,76,67,32,29,30
	btf_id 3507
3650: sched_cls  name handle_policy  tag f11f2a56ac625484  gpl
	loaded_at 2024-10-24T09:24:44+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,688,74,75,687,33,72,136,31,76,67,32,29,30
	btf_id 3505
3651: sched_cls  name tail_handle_arp  tag f683eb76e8737a04  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,688
	btf_id 3509
3652: sched_cls  name tail_ipv4_ct_egress  tag 0d239d1d19e4bb0e  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,688,74,75,687,76
	btf_id 3510
3653: sched_cls  name cil_from_container  tag df13add086815eb1  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 688,68
	btf_id 3511
3654: sched_cls  name tail_ipv4_to_endpoint  tag 77d81a671a9cc6e3  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,690,33,74,75,72,133,31,689,32,29,30
	btf_id 3508
3655: sched_cls  name tail_ipv4_to_endpoint  tag 66016923b06086f0  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,687,33,74,75,72,136,31,688,32,29,30
	btf_id 3512
3656: sched_cls  name tail_ipv4_ct_egress  tag 623ec15fa4de90ef  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,689,74,75,690,76
	btf_id 3513
