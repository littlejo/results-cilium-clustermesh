key: 05 00 00 00  value: 0a 04 00 a3 00 35 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 04 00 c8 1f 90 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b1 96 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f a7 ad 10 94 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 04 00 e0 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 04 00 a3 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 04 00 5d 09 4b 00 00  00 00 00 00
key: 03 00 00 00  value: 0a 04 00 e0 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: ac 1f d9 c6 01 bb 00 00  00 00 00 00
Found 9 elements
