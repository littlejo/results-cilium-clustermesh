KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.4.0.0/24, 
Allocated addresses:
  10.4.0.105 (health)
  10.4.0.163 (kube-system/coredns-586b798467-2zsn8)
  10.4.0.200 (cilium-test-1/echo-same-node-86d9cc975c-28tnz)
  10.4.0.224 (kube-system/coredns-586b798467-bngqp)
  10.4.0.230 (router)
  10.4.0.239 (cilium-test-1/client-974f6c69d-z648w)
  10.4.0.75 (cilium-test-1/client2-57cf4468f-tmdnj)
  10.4.0.93 (kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    8s ago         never        0       no error   
  ct-map-pressure                                                     10s ago        never        0       no error   
  daemon-validate-config                                              0s ago         never        0       no error   
  dns-garbage-collector-job                                           12s ago        never        0       no error   
  endpoint-1461-regeneration-recovery                                 never          never        0       no error   
  endpoint-198-regeneration-recovery                                  never          never        0       no error   
  endpoint-2244-regeneration-recovery                                 never          never        0       no error   
  endpoint-244-regeneration-recovery                                  never          never        0       no error   
  endpoint-2951-regeneration-recovery                                 never          never        0       no error   
  endpoint-3262-regeneration-recovery                                 never          never        0       no error   
  endpoint-751-regeneration-recovery                                  never          never        0       no error   
  endpoint-839-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         12s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                10s ago        never        0       no error   
  ipcache-inject-labels                                               10s ago        never        0       no error   
  k8s-heartbeat                                                       13s ago        never        0       no error   
  link-cache                                                          10s ago        never        0       no error   
  local-identity-checkpoint                                           41s ago        never        0       no error   
  node-neighbor-link-updater                                          0s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m35s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m35s ago      never        0       no error   
  resolve-identity-1461                                               10s ago        never        0       no error   
  resolve-identity-198                                                13s ago        never        0       no error   
  resolve-identity-2244                                               12s ago        never        0       no error   
  resolve-identity-244                                                13s ago        never        0       no error   
  resolve-identity-2951                                               1m42s ago      never        0       no error   
  resolve-identity-3262                                               9s ago         never        0       no error   
  resolve-identity-751                                                9s ago         never        0       no error   
  resolve-identity-839                                                9s ago         never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-z648w                 5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-tmdnj                5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-28tnz        5m12s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd   6m42s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-2zsn8                 10m9s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-bngqp                 10m9s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      10m10s ago     never        0       no error   
  sync-policymap-1461                                                 10m9s ago      never        0       no error   
  sync-policymap-198                                                  5m13s ago      never        0       no error   
  sync-policymap-2244                                                 5m12s ago      never        0       no error   
  sync-policymap-244                                                  5m13s ago      never        0       no error   
  sync-policymap-2951                                                 6m42s ago      never        0       no error   
  sync-policymap-3262                                                 10m5s ago      never        0       no error   
  sync-policymap-751                                                  10m5s ago      never        0       no error   
  sync-policymap-839                                                  10m5s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (198)                                    3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2244)                                   2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (244)                                    3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2951)                                   2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (751)                                    9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (839)                                    9s ago         never        0       no error   
  sync-utime                                                          10s ago        never        0       no error   
  write-cni-file                                                      10m12s ago     never        0       no error   
Proxy Status:            OK, ip 10.4.0.230, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 327680, max 393215
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 21.15   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                                           Disabled         
Cluster health:                                       8/8 reachable    (2024-10-24T09:25:21Z)
  Name                                                IP               Node        Endpoints
  cmesh5/ip-172-31-167-173.ec2.internal (localhost)   172.31.167.173   reachable   reachable
  cmesh1/ip-172-31-190-177.ec2.internal               172.31.190.177   reachable   reachable
  cmesh2/ip-172-31-234-224.ec2.internal               172.31.234.224   reachable   reachable
  cmesh3/ip-172-31-140-200.ec2.internal               172.31.140.200   reachable   reachable
  cmesh4/ip-172-31-224-68.ec2.internal                172.31.224.68    reachable   reachable
  cmesh6/ip-172-31-249-188.ec2.internal               172.31.249.188   reachable   reachable
  cmesh7/ip-172-31-162-53.ec2.internal                172.31.162.53    reachable   reachable
  cmesh8/ip-172-31-208-9.ec2.internal                 172.31.208.9     reachable   reachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] OK (1.255µs) [6] (5m12s, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (10m, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (17.305µs) (12s, x1)
      │   ├── bgp-control-plane
      │   │   └── job-diffstore-events                            [OK] Running (10m, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (10m, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (10m, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (0s, x11)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (10s, x21)
      │   │   └── job-sync-hostips                                [OK] Synchronized (10s, x11)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-1461 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x12)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1461 (10m, x1)
      │   │   ├── cilium-endpoint-198 (cilium-test-1/client2-57cf4468f-tmdnj)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (198) (3s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (44s, x121)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-198 (5m13s, x1)
      │   │   ├── cilium-endpoint-2244 (cilium-test-1/echo-same-node-86d9cc975c-28tnz)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2244) (2s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (2m9s, x75)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2244 (5m12s, x1)
      │   │   ├── cilium-endpoint-244 (cilium-test-1/client-974f6c69d-z648w)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (244) (3s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (44s, x113)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-244 (5m13s, x1)
      │   │   ├── cilium-endpoint-2951 (kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2951) (2s, x42)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x9)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2951 (6m42s, x1)
      │   │   ├── cilium-endpoint-3262 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3262 (10m, x1)
      │   │   ├── cilium-endpoint-751 (kube-system/coredns-586b798467-2zsn8)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (751) (9s, x62)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x12)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-751 (10m, x1)
      │   │   ├── cilium-endpoint-839 (kube-system/coredns-586b798467-bngqp)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (839) (9s, x62)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x12)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-839 (10m, x1)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (12s, x3)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (2.549872ms) (10s, x1)
      │   ├── l2-announcer
      │   │   └── job-l2-announcer lease-gc                       [OK] Running (10m, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (2m2s, x7)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (4m35s, x4)
      │   │   └── nodes-add                                       [OK] Node adds successful (6m35s, x8)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 1 NodePort frontend addresses (10m, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Synchronized (6m35s, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (10m, x1)
      │   └── timer-job-device-reloader                           [OK] OK (7.433µs) (5m10s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (32.335µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (10m, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 0 objects (10m, x1)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (10m, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (10m, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (1.428µs) (10s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] 10.4.0.230 (primary), fe80::b8a5:12ff:fefe:c313 (primary) (10m, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 20 objects (13s, x18)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (10m, x1)
      
