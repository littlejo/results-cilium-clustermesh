filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccd75ea23b396 direct-action not_in_hw id 3343 tag 23c4295fa2005826 jited 
