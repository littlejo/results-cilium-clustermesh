CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c9c7a7f_25a5_4224_b83c_24155c3c9c6d.slice/cri-containerd-b092568b56cb86b003ed3a43af735c195b794c6b7519ea64db04e884a107e64b.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c9c7a7f_25a5_4224_b83c_24155c3c9c6d.slice/cri-containerd-0d755163031148b83ce49d9a10424a23bf05d7cac4c0109bf8aa720aab2d090d.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3cc9a380_e0bb_4796_abba_7f628fb2d5eb.slice/cri-containerd-f4e1c624117f245714a19aef2c358be0ccb8adb0ff5f557f87f4af15938ee4af.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3cc9a380_e0bb_4796_abba_7f628fb2d5eb.slice/cri-containerd-9f48323e0325411a0086373e250267f0a8e2e1a25eda97c6507a3c395344a757.scope
    503      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a3978d5_b930_4338_a9fc_1649c3555287.slice/cri-containerd-6ee9345e9eacca5f60cb1d50d0101606d4c6b1b7eaa30f7f5d1d6fd1389f3761.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a3978d5_b930_4338_a9fc_1649c3555287.slice/cri-containerd-f5ae861c3c2de62768c68a6761e6efc6597e76fae144f86dfb56d07fbaa13ee6.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3d13079_17c2_4db9_ae07_ed0b7cc36a3c.slice/cri-containerd-cb5d023943fc1966162386d1b83a2a35f1c9324733b0b76497cdbdb982dcf716.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3d13079_17c2_4db9_ae07_ed0b7cc36a3c.slice/cri-containerd-552dd6c5b9e0379770490d8e40bb070daae48c20001ed8b227ac8b0ec483d698.scope
    100      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod235b1821_01ad_4f13_b113_b446531f46b3.slice/cri-containerd-7a03600cc05b480b3d8441a43d6186628dae915efcb55a6c9360ab74c3e48a1d.scope
    659      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod235b1821_01ad_4f13_b113_b446531f46b3.slice/cri-containerd-fee32a58d7e7333b8c3946ceaeca5f47b85b8a923e14063e2115643f3768b539.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod235b1821_01ad_4f13_b113_b446531f46b3.slice/cri-containerd-517ce09348f4d5ab60c271e3ee5a40fcc35b2d3c30bc179c56d5c1fd9e1abc78.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a030603_fde5_4a67_833d_7e63de624935.slice/cri-containerd-bf8bd1820b706e1bed920b398720e0b511fae62fa809a3654b3a068d01a7173f.scope
    62       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a030603_fde5_4a67_833d_7e63de624935.slice/cri-containerd-0de1cd4821c843a22933433f4d61bb289b598e2fed5c3ad694174ae9529a6012.scope
    73       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-81e5335af1e773f9aaa9f55d0e6b612e02b1c26031aa17ad5f08ea3640039180.scope
    590      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-559ff91e8164a10457bb69ca7d5819ecf2c5e0b95f3cab08a40ccebebe93f143.scope
    610      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-9a7510ba9b9610e88324e4db6d7449a47a616b4490baa8127883cbca6f70b40a.scope
    606      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-888c0006749c7fe9b1510acb6745086a2aa59e70fdbdbe6489a14c468e520da6.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf55fa26b_9aba_4179_a988_f10afe44e784.slice/cri-containerd-b944366bddfd3d359d06eb11bdef864e2272dfc3e70ae8fb651f66b13baadbf5.scope
    644      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf55fa26b_9aba_4179_a988_f10afe44e784.slice/cri-containerd-53895a9ebf32844c251693c3e3f2f256433a398de26b975eda935714d0f0fd79.scope
    663      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbffecd11_5c0c_4c02_b96f_244fc1da752c.slice/cri-containerd-b5581f5fcd689a801afaa7d2c5a86ac4edebef10d62d8b1ae06c3a2656d06a53.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbffecd11_5c0c_4c02_b96f_244fc1da752c.slice/cri-containerd-ce611f6f2c4c0dab38276824e914b163ec6ee7a6f1acef3bfad4fa2008e53a99.scope
    58       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab51031_4cd5_4082_8071_6c623094bb5f.slice/cri-containerd-8a95d5ef92b305343ba8e5e800957a3ca528ad024163106ad6699b361f52777a.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab51031_4cd5_4082_8071_6c623094bb5f.slice/cri-containerd-7c08034991fab9697687bf0f6d4ccebdaac6ffd1ec42af04d18a6317b5484bb4.scope
    667      cgroup_device   multi                                          
