{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:17.186Z",
  "value": "ANY://172.31.177.150"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:19.780Z",
  "value": "ANY://172.31.167.173"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:26.668Z",
  "value": "ANY://10.4.0.224"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:26.668Z",
  "value": "ANY://10.4.0.224"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:26.685Z",
  "value": "ANY://10.4.0.163"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:26.685Z",
  "value": "ANY://10.4.0.163"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:47.719Z",
  "value": "ANY://10.4.0.56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:15:58.414Z",
  "value": "ANY://172.31.217.198"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:18:51.133Z",
  "value": "ANY://10.4.0.93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:18:51.185Z",
  "value": "ANY://10.4.0.56"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:18:51.491Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:20:23.326Z",
  "value": "ANY://10.4.0.200"
}

