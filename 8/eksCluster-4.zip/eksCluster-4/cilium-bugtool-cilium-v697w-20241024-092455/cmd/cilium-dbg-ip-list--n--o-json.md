[
  {
    "cidr": "0.0.0.0/0",
    "identity": 2
  },
  {
    "cidr": "10.0.0.58/32",
    "hostIP": "172.31.190.177",
    "identity": 86420,
    "metadata": {
      "name": "clustermesh-apiserver-787d76979f-bbgd4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.115/32",
    "hostIP": "172.31.190.177",
    "identity": 82485,
    "metadata": {
      "name": "coredns-586b798467-shdm8",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.119/32",
    "hostIP": "172.31.190.177",
    "identity": 6
  },
  {
    "cidr": "10.0.0.133/32",
    "hostIP": "172.31.190.177",
    "identity": 90675,
    "metadata": {
      "name": "client2-57cf4468f-n4msm",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.146/32",
    "hostIP": "172.31.190.177",
    "identity": 73336,
    "metadata": {
      "name": "client-974f6c69d-d6w4f",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.193/32",
    "hostIP": "172.31.190.177",
    "identity": 4
  },
  {
    "cidr": "10.0.0.239/32",
    "hostIP": "172.31.190.177",
    "identity": 67854,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-tsm52",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.0.0.242/32",
    "hostIP": "172.31.190.177",
    "identity": 82485,
    "metadata": {
      "name": "coredns-586b798467-rnt5q",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.5/32",
    "hostIP": "172.31.234.224",
    "identity": 6
  },
  {
    "cidr": "10.1.0.16/32",
    "hostIP": "172.31.234.224",
    "identity": 157096,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-p9lln",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.21/32",
    "hostIP": "172.31.234.224",
    "identity": 148646,
    "metadata": {
      "name": "client2-57cf4468f-z8v9j",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.39/32",
    "hostIP": "172.31.234.224",
    "identity": 4
  },
  {
    "cidr": "10.1.0.56/32",
    "hostIP": "172.31.234.224",
    "identity": 147144,
    "metadata": {
      "name": "clustermesh-apiserver-6c945c9c98-gw6dk",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.64/32",
    "hostIP": "172.31.234.224",
    "identity": 135727,
    "metadata": {
      "name": "coredns-586b798467-q2jt9",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.196/32",
    "hostIP": "172.31.234.224",
    "identity": 135727,
    "metadata": {
      "name": "coredns-586b798467-qbnzz",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.1.0.252/32",
    "hostIP": "172.31.234.224",
    "identity": 151863,
    "metadata": {
      "name": "client-974f6c69d-2cghr",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.25/32",
    "hostIP": "172.31.140.200",
    "identity": 221974,
    "metadata": {
      "name": "client2-57cf4468f-hbsf4",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.34/32",
    "hostIP": "172.31.140.200",
    "identity": 4
  },
  {
    "cidr": "10.2.0.36/32",
    "hostIP": "172.31.140.200",
    "identity": 200572,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-2mcww",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.154/32",
    "hostIP": "172.31.140.200",
    "identity": 220496,
    "metadata": {
      "name": "coredns-586b798467-lllk4",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.161/32",
    "hostIP": "172.31.140.200",
    "identity": 6
  },
  {
    "cidr": "10.2.0.168/32",
    "hostIP": "172.31.140.200",
    "identity": 225266,
    "metadata": {
      "name": "clustermesh-apiserver-bb44565f9-727ls",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.185/32",
    "hostIP": "172.31.140.200",
    "identity": 220496,
    "metadata": {
      "name": "coredns-586b798467-n67ss",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.2.0.242/32",
    "hostIP": "172.31.140.200",
    "identity": 207272,
    "metadata": {
      "name": "client-974f6c69d-zr62r",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.17/32",
    "hostIP": "172.31.224.68",
    "identity": 6
  },
  {
    "cidr": "10.3.0.36/32",
    "hostIP": "172.31.224.68",
    "identity": 286632,
    "metadata": {
      "name": "clustermesh-apiserver-5754b9869c-g52pg",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.83/32",
    "hostIP": "172.31.224.68",
    "identity": 4
  },
  {
    "cidr": "10.3.0.86/32",
    "hostIP": "172.31.224.68",
    "identity": 292468,
    "metadata": {
      "name": "coredns-586b798467-rkx67",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.104/32",
    "hostIP": "172.31.224.68",
    "identity": 268163,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-nld2x",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.112/32",
    "hostIP": "172.31.224.68",
    "identity": 281016,
    "metadata": {
      "name": "client-974f6c69d-jchj9",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.118/32",
    "hostIP": "172.31.224.68",
    "identity": 296497,
    "metadata": {
      "name": "client2-57cf4468f-fj8rc",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.3.0.201/32",
    "hostIP": "172.31.224.68",
    "identity": 292468,
    "metadata": {
      "name": "coredns-586b798467-s6stj",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.4.0.75/32",
    "hostIP": "172.31.167.173",
    "identity": 361562,
    "metadata": {
      "name": "client2-57cf4468f-tmdnj",
      "namespace": "cilium-test-1",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.4.0.93/32",
    "hostIP": "172.31.167.173",
    "identity": 350710,
    "metadata": {
      "name": "clustermesh-apiserver-7b4f4f4459-bw7kd",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.4.0.105/32",
    "hostIP": "172.31.167.173",
    "identity": 4
  },
  {
    "cidr": "10.4.0.163/32",
    "hostIP": "172.31.167.173",
    "identity": 336619,
    "metadata": {
      "name": "coredns-586b798467-2zsn8",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.4.0.200/32",
    "hostIP": "172.31.167.173",
    "identity": 359982,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-28tnz",
      "namespace": "cilium-test-1",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.4.0.224/32",
    "hostIP": "172.31.167.173",
    "identity": 336619,
    "metadata": {
      "name": "coredns-586b798467-bngqp",
      "namespace": "kube-system",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.4.0.230/32",
    "hostIP": "172.31.167.173",
    "identity": 1
  },
  {
    "cidr": "10.4.0.239/32",
    "hostIP": "172.31.167.173",
    "identity": 332688,
    "metadata": {
      "name": "client-974f6c69d-z648w",
      "namespace": "cilium-test-1",
      "source": "custom-resource"
    }
  },
  {
    "cidr": "10.5.0.38/32",
    "hostIP": "172.31.249.188",
    "identity": 406305,
    "metadata": {
      "name": "client-974f6c69d-ngz88",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.80/32",
    "hostIP": "172.31.249.188",
    "identity": 4
  },
  {
    "cidr": "10.5.0.83/32",
    "hostIP": "172.31.249.188",
    "identity": 400535,
    "metadata": {
      "name": "clustermesh-apiserver-5f7c67789-2td27",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.160/32",
    "hostIP": "172.31.249.188",
    "identity": 397076,
    "metadata": {
      "name": "client2-57cf4468f-wqh2h",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.187/32",
    "hostIP": "172.31.249.188",
    "identity": 409754,
    "metadata": {
      "name": "coredns-586b798467-t5p4l",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.219/32",
    "hostIP": "172.31.249.188",
    "identity": 6
  },
  {
    "cidr": "10.5.0.226/32",
    "hostIP": "172.31.249.188",
    "identity": 409754,
    "metadata": {
      "name": "coredns-586b798467-p2mr5",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.5.0.244/32",
    "hostIP": "172.31.249.188",
    "identity": 395399,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-x4t7h",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.85/32",
    "hostIP": "172.31.162.53",
    "identity": 505656,
    "metadata": {
      "name": "client2-57cf4468f-5khv7",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.91/32",
    "hostIP": "172.31.162.53",
    "identity": 507362,
    "metadata": {
      "name": "coredns-586b798467-jj4x6",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.93/32",
    "hostIP": "172.31.162.53",
    "identity": 516201,
    "metadata": {
      "name": "clustermesh-apiserver-78c75dc487-zhf52",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.102/32",
    "hostIP": "172.31.162.53",
    "identity": 6
  },
  {
    "cidr": "10.6.0.112/32",
    "hostIP": "172.31.162.53",
    "identity": 465367,
    "metadata": {
      "name": "client-974f6c69d-7zqtx",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.115/32",
    "hostIP": "172.31.162.53",
    "identity": 507362,
    "metadata": {
      "name": "coredns-586b798467-zw6mq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.145/32",
    "hostIP": "172.31.162.53",
    "identity": 514866,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-h4csn",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.6.0.250/32",
    "hostIP": "172.31.162.53",
    "identity": 4
  },
  {
    "cidr": "10.7.0.6/32",
    "hostIP": "172.31.208.9",
    "identity": 528627,
    "metadata": {
      "name": "client2-57cf4468f-gwqrv",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.78/32",
    "hostIP": "172.31.208.9",
    "identity": 580057,
    "metadata": {
      "name": "clustermesh-apiserver-64fff5c868-86dnl",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.95/32",
    "hostIP": "172.31.208.9",
    "identity": 6
  },
  {
    "cidr": "10.7.0.104/32",
    "hostIP": "172.31.208.9",
    "identity": 585156,
    "metadata": {
      "name": "coredns-586b798467-dqsrq",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.123/32",
    "hostIP": "172.31.208.9",
    "identity": 4
  },
  {
    "cidr": "10.7.0.141/32",
    "hostIP": "172.31.208.9",
    "identity": 536794,
    "metadata": {
      "name": "client-974f6c69d-c7cc6",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.201/32",
    "hostIP": "172.31.208.9",
    "identity": 556252,
    "metadata": {
      "name": "echo-same-node-86d9cc975c-49kk9",
      "namespace": "cilium-test-1",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "10.7.0.228/32",
    "hostIP": "172.31.208.9",
    "identity": 585156,
    "metadata": {
      "name": "coredns-586b798467-hlzgr",
      "namespace": "kube-system",
      "source": "clustermesh"
    }
  },
  {
    "cidr": "172.31.140.200/32",
    "identity": 6
  },
  {
    "cidr": "172.31.162.53/32",
    "identity": 6
  },
  {
    "cidr": "172.31.167.173/32",
    "identity": 1
  },
  {
    "cidr": "172.31.177.150/32",
    "identity": 16777217
  },
  {
    "cidr": "172.31.190.177/32",
    "identity": 6
  },
  {
    "cidr": "172.31.208.9/32",
    "identity": 6
  },
  {
    "cidr": "172.31.217.198/32",
    "identity": 16777218
  },
  {
    "cidr": "172.31.224.68/32",
    "identity": 6
  },
  {
    "cidr": "172.31.234.224/32",
    "identity": 6
  },
  {
    "cidr": "172.31.249.188/32",
    "identity": 6
  }
]

