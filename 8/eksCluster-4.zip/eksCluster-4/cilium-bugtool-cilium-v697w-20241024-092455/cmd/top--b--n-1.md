top - 09:24:57 up 10 min,  0 users,  load average: 0.22, 0.35, 0.26
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 29.0 us, 12.9 sy,  0.0 ni, 58.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   3836.2 total,    996.0 free,    737.6 used,   2102.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2921.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   2789 root      20   0 1240432  16164  10768 S  13.3   0.4   0:00.03 cilium-+
      1 root      20   0 1405340 187596  78060 S   0.0   4.8   0:22.91 cilium-+
    411 root      20   0 1228848   4716   3844 S   0.0   0.1   0:00.00 cilium-+
   2778 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2783 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   2811 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   2817 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
   2825 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   2858 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2876 root      20   0 1228744   3780   3104 S   0.0   0.1   0:00.00 gops
   2881 root      20   0 1616520   8764   6260 S   0.0   0.2   0:00.00 runc:[2+
