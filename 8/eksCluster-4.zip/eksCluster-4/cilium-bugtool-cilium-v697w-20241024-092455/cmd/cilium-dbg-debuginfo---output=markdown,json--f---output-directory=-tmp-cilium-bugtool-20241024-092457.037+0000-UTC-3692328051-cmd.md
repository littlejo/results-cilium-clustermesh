markdown output at /tmp/cilium-bugtool-20241024-092457.037+0000-UTC-3692328051/cmd/cilium-debuginfo-20241024-092527.411+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-092457.037+0000-UTC-3692328051/cmd/cilium-debuginfo-20241024-092527.411+0000-UTC.json
