alloc: 54.03MB (56656736 bytes)
total-alloc: 1.44GB (1546202768 bytes)
sys: 108.77MB (114052404 bytes)
lookups: 0
mallocs: 46658615
frees: 46215344
heap-alloc: 54.03MB (56656736 bytes)
heap-sys: 93.36MB (97894400 bytes)
heap-idle: 21.86MB (22921216 bytes)
heap-in-use: 71.50MB (74973184 bytes)
heap-released: 240.00KB (245760 bytes)
heap-objects: 443271
stack-in-use: 6.59MB (6914048 bytes)
stack-sys: 6.59MB (6914048 bytes)
stack-mspan-inuse: 1.07MB (1118080 bytes)
stack-mspan-sys: 1.28MB (1338240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 931.55KB (953905 bytes)
gc-sys: 4.70MB (4932288 bytes)
next-gc: when heap-alloc >= 85.41MB (89559496 bytes)
last-gc: 2024-10-24 09:24:58.06378228 +0000 UTC
gc-pause-total: 8.252193ms
gc-pause: 130935
gc-pause-end: 1729761898063782280
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0005908586439115612
enable-gc: true
debug-gc: false
