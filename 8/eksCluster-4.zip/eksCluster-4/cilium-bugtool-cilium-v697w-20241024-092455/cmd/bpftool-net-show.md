xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 522
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 521
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 511
cilium_host(4) clsact/egress cil_from_host-cilium_host id 509
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 443
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 444
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 473
lxceb65690dfaed(9) clsact/ingress cil_from_container-lxceb65690dfaed id 486
lxcad13466e51ce(11) clsact/ingress cil_from_container-lxcad13466e51ce id 490
lxc99a47c4a39e2(15) clsact/ingress cil_from_container-lxc99a47c4a39e2 id 578
lxc1f40b3fd9411(17) clsact/ingress cil_from_container-lxc1f40b3fd9411 id 3636
lxc142ae6a3e494(19) clsact/ingress cil_from_container-lxc142ae6a3e494 id 3653
lxccd75ea23b396(21) clsact/ingress cil_from_container-lxccd75ea23b396 id 3343

flow_dissector:

netfilter:

