key: c6 00 00 00  value: 42 0e 00 00
key: f4 00 00 00  value: 41 0e 00 00
key: ef 02 00 00  value: e3 01 00 00
key: 47 03 00 00  value: fb 01 00 00
key: c4 08 00 00  value: 12 0d 00 00
key: 87 0b 00 00  value: 40 02 00 00
key: be 0c 00 00  value: d7 01 00 00
Found 7 elements
