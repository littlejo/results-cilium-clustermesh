 09:24:57 up 10 min,  0 users,  load average: 0.22, 0.35, 0.26
