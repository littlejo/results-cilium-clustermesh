filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1f40b3fd9411 direct-action not_in_hw id 3636 tag 5ad052f0ce15a3b5 jited 
