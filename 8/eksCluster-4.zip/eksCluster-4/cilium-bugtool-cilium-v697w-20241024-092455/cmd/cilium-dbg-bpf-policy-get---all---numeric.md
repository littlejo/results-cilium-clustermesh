Endpoint ID: 198
Path: /sys/fs/bpf/tc/globals/cilium_policy_00198

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 244
Path: /sys/fs/bpf/tc/globals/cilium_policy_00244

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 751
Path: /sys/fs/bpf/tc/globals/cilium_policy_00751

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5956    65        0        
Allow    Ingress     1          ANY          NONE         disabled    55238   634       0        
Allow    Egress      0          ANY          NONE         disabled    13381   137       0        


Endpoint ID: 839
Path: /sys/fs/bpf/tc/globals/cilium_policy_00839

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5420    59        0        
Allow    Ingress     1          ANY          NONE         disabled    54908   629       0        
Allow    Egress      0          ANY          NONE         disabled    13445   138       0        


Endpoint ID: 1461
Path: /sys/fs/bpf/tc/globals/cilium_policy_01461

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2244
Path: /sys/fs/bpf/tc/globals/cilium_policy_02244

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4408     33        0        
Allow    Ingress     1          ANY          NONE         disabled    302669   3530      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 2951
Path: /sys/fs/bpf/tc/globals/cilium_policy_02951

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    218100   2050      0        
Allow    Ingress     1          ANY          NONE         disabled    217157   2262      0        
Allow    Egress      0          ANY          NONE         disabled    259717   2378      0        


Endpoint ID: 3262
Path: /sys/fs/bpf/tc/globals/cilium_policy_03262

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23193   288       0        
Allow    Ingress     1          ANY          NONE         disabled    7981    90        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


