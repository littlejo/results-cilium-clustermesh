# Cilium debug information

#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.177.150:443 (active)    
                                         2 => 172.31.217.198:443 (active)    
2    10.100.85.225:443    ClusterIP      1 => 172.31.167.173:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.4.0.224:9153 (active)       
                                         2 => 10.4.0.163:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.4.0.224:53 (active)         
                                         2 => 10.4.0.163:53 (active)         
5    10.100.96.109:2379   ClusterIP      1 => 10.4.0.93:2379 (active)        
6    10.100.88.52:8080    ClusterIP      1 => 10.4.0.200:8080 (active)       
```

#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40024704d0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x400249d680,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x400249d680,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=6) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002530f20)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002530fd0)(frontends:[10.100.85.225]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002531080)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001deabb0)(frontends:[]/ports=[kvmesh-metrics etcd-metrics apiserv-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40037b0f20)(frontends:[10.100.96.109]/ports=[]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.Service)(0x400187adc0)(frontends:[10.100.88.52]/ports=[http]/selector=map[name:echo-same-node])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=5) {
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000d3d7f8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-7bf5x": (*k8s.Endpoints)(0x40035ca680)(10.4.0.163:53/TCP[us-east-1a],10.4.0.163:53/UDP[us-east-1a],10.4.0.163:9153/TCP[us-east-1a],10.4.0.224:53/TCP[us-east-1a],10.4.0.224:53/UDP[us-east-1a],10.4.0.224:9153/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40012207f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-98qpm": (*k8s.Endpoints)(0x40023e2820)(10.4.0.93:2379/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) cilium-test-1/echo-same-node: (*k8s.EndpointSlices)(0x400175dee8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=20) "echo-same-node-48nss": (*k8s.Endpoints)(0x4003dd5380)(10.4.0.200:8080/TCP[us-east-1a])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000d3d7e8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x40029bf450)(172.31.177.150:443/TCP,172.31.217.198:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000d3d7f0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-sqrz6": (*k8s.Endpoints)(0x4001be4000)(172.31.167.173:4244/TCP[us-east-1a])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001b5fab0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4001ea7770)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4003ece288
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001ebaa20,
  gcExited: (chan struct {}) 0x4001ebaa80,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001baea00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400149af50)({
      MetricVec: (*prometheus.MetricVec)(0x400246e000)({
       metricMap: (*prometheus.metricMap)(0x400246e030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b74f00)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001baea80)({
     ObserverVec: (*prometheus.HistogramVec)(0x400149af58)({
      MetricVec: (*prometheus.MetricVec)(0x400246e090)({
       metricMap: (*prometheus.metricMap)(0x400246e0c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b74f60)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001baeb00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af60)({
      MetricVec: (*prometheus.MetricVec)(0x400246e120)({
       metricMap: (*prometheus.metricMap)(0x400246e150)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b74fc0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001baeb80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af68)({
      MetricVec: (*prometheus.MetricVec)(0x400246e1b0)({
       metricMap: (*prometheus.metricMap)(0x400246e1e0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b75020)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001baec00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af70)({
      MetricVec: (*prometheus.MetricVec)(0x400246e240)({
       metricMap: (*prometheus.metricMap)(0x400246e270)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b75080)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001baec80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af78)({
      MetricVec: (*prometheus.MetricVec)(0x400246e2d0)({
       metricMap: (*prometheus.metricMap)(0x400246e300)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b750e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001baed00)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af80)({
      MetricVec: (*prometheus.MetricVec)(0x400246e360)({
       metricMap: (*prometheus.metricMap)(0x400246e390)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b75140)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001baed80)({
     GaugeVec: (*prometheus.GaugeVec)(0x400149af88)({
      MetricVec: (*prometheus.MetricVec)(0x400246e3f0)({
       metricMap: (*prometheus.metricMap)(0x400246e420)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b751a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001baee00)({
     ObserverVec: (*prometheus.HistogramVec)(0x400149af90)({
      MetricVec: (*prometheus.MetricVec)(0x400246e480)({
       metricMap: (*prometheus.metricMap)(0x400246e4b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001b75200)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001b5fab0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x400248ccb0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40019a5350)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 509ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=8) {
  (string) (len=10) "10.4.0.230": (string) (len=6) "router",
  (string) (len=10) "10.4.0.105": (string) (len=6) "health",
  (string) (len=10) "10.4.0.163": (string) (len=36) "kube-system/coredns-586b798467-2zsn8",
  (string) (len=10) "10.4.0.224": (string) (len=36) "kube-system/coredns-586b798467-bngqp",
  (string) (len=10) "10.4.0.239": (string) (len=36) "cilium-test-1/client-974f6c69d-z648w",
  (string) (len=9) "10.4.0.93": (string) (len=50) "kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd",
  (string) (len=9) "10.4.0.75": (string) (len=37) "cilium-test-1/client2-57cf4468f-tmdnj",
  (string) (len=10) "10.4.0.200": (string) (len=45) "cilium-test-1/echo-same-node-86d9cc975c-28tnz"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.167.173": (string) (len=7) "node-ip"
}

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37786885                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37786885                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37786885                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4006800000 rw-p 00000000 00:00 0 
4006800000-4008000000 ---p 00000000 00:00 0 
ffff51fc5000-ffff5216e000 rw-p 00000000 00:00 0 
ffff5216e000-ffff521af000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff521af000-ffff521f0000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff521f0000-ffff521f2000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff521f2000-ffff521f4000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff521f4000-ffff5279b000 rw-p 00000000 00:00 0 
ffff527ab000-ffff528ab000 rw-p 00000000 00:00 0 
ffff528ab000-ffff528bc000 rw-p 00000000 00:00 0 
ffff528bc000-ffff548bc000 rw-p 00000000 00:00 0 
ffff548bc000-ffff5493c000 ---p 00000000 00:00 0 
ffff5493c000-ffff5493d000 rw-p 00000000 00:00 0 
ffff5493d000-ffff7493c000 ---p 00000000 00:00 0 
ffff7493c000-ffff7493d000 rw-p 00000000 00:00 0 
ffff7493d000-ffff948cc000 ---p 00000000 00:00 0 
ffff948cc000-ffff948cd000 rw-p 00000000 00:00 0 
ffff948cd000-ffff988be000 ---p 00000000 00:00 0 
ffff988be000-ffff988bf000 rw-p 00000000 00:00 0 
ffff988bf000-ffff990bc000 ---p 00000000 00:00 0 
ffff990bc000-ffff990bd000 rw-p 00000000 00:00 0 
ffff990bd000-ffff991bc000 ---p 00000000 00:00 0 
ffff991bc000-ffff9921c000 rw-p 00000000 00:00 0 
ffff9921c000-ffff9921e000 r--p 00000000 00:00 0                          [vvar]
ffff9921e000-ffff9921f000 r-xp 00000000 00:00 0                          [vdso]
fffffc8b8000-fffffc8d9000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.4.0.0/24, 
Allocated addresses:
  10.4.0.105 (health)
  10.4.0.163 (kube-system/coredns-586b798467-2zsn8)
  10.4.0.200 (cilium-test-1/echo-same-node-86d9cc975c-28tnz)
  10.4.0.224 (kube-system/coredns-586b798467-bngqp)
  10.4.0.230 (router)
  10.4.0.239 (cilium-test-1/client-974f6c69d-z648w)
  10.4.0.75 (cilium-test-1/client2-57cf4468f-tmdnj)
  10.4.0.93 (kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 1dbd52b2832d1c57
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    5s ago         never        0       no error   
  ct-map-pressure                                                     7s ago         never        0       no error   
  daemon-validate-config                                              58s ago        never        0       no error   
  dns-garbage-collector-job                                           10s ago        never        0       no error   
  endpoint-1461-regeneration-recovery                                 never          never        0       no error   
  endpoint-198-regeneration-recovery                                  never          never        0       no error   
  endpoint-2244-regeneration-recovery                                 never          never        0       no error   
  endpoint-244-regeneration-recovery                                  never          never        0       no error   
  endpoint-2951-regeneration-recovery                                 never          never        0       no error   
  endpoint-3262-regeneration-recovery                                 never          never        0       no error   
  endpoint-751-regeneration-recovery                                  never          never        0       no error   
  endpoint-839-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         10s ago        never        0       no error   
  ep-bpf-prog-watchdog                                                7s ago         never        0       no error   
  ipcache-inject-labels                                               8s ago         never        0       no error   
  k8s-heartbeat                                                       10s ago        never        0       no error   
  link-cache                                                          7s ago         never        0       no error   
  local-identity-checkpoint                                           39s ago        never        0       no error   
  node-neighbor-link-updater                                          7s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh4                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m32s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m32s ago      never        0       no error   
  resolve-identity-1461                                               7s ago         never        0       no error   
  resolve-identity-198                                                11s ago        never        0       no error   
  resolve-identity-2244                                               9s ago         never        0       no error   
  resolve-identity-244                                                11s ago        never        0       no error   
  resolve-identity-2951                                               1m40s ago      never        0       no error   
  resolve-identity-3262                                               6s ago         never        0       no error   
  resolve-identity-751                                                7s ago         never        0       no error   
  resolve-identity-839                                                6s ago         never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-z648w                 5m11s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-tmdnj                5m11s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-28tnz        5m9s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd   6m40s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-2zsn8                 10m7s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-bngqp                 10m6s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      10m7s ago      never        0       no error   
  sync-policymap-1461                                                 10m6s ago      never        0       no error   
  sync-policymap-198                                                  5m11s ago      never        0       no error   
  sync-policymap-2244                                                 5m9s ago       never        0       no error   
  sync-policymap-244                                                  5m11s ago      never        0       no error   
  sync-policymap-2951                                                 6m40s ago      never        0       no error   
  sync-policymap-3262                                                 10m3s ago      never        0       no error   
  sync-policymap-751                                                  10m3s ago      never        0       no error   
  sync-policymap-839                                                  10m3s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (198)                                    11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2244)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (244)                                    11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2951)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (751)                                    7s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (839)                                    6s ago         never        0       no error   
  sync-utime                                                          8s ago         never        0       no error   
  write-cni-file                                                      10m10s ago     never        0       no error   
Proxy Status:            OK, ip 10.4.0.230, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 327680, max 393215
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 21.13   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
nat-map-stats-entries:32
log-system-load:false
clustermesh-enable-mcs-api:false
direct-routing-skip-unreachable:false
bpf-lb-maglev-table-size:16381
endpoint-bpf-prog-watchdog-interval:30s
controller-group-metrics:
tofqdns-pre-cache:
bpf-lb-acceleration:disabled
enable-ipv6-masquerade:true
ipv6-cluster-alloc-cidr:f00d::/64
nodeport-addresses:
exclude-local-address:
proxy-gid:1337
tofqdns-endpoint-max-ip-per-hostname:50
bpf-lb-maglev-map-max:0
gateway-api-secrets-namespace:
node-labels:
hubble-monitor-events:
tofqdns-dns-reject-response-code:refused
ipam-cilium-node-update-rate:15s
bpf-ct-timeout-regular-tcp-fin:10s
monitor-aggregation-interval:5s
enable-sctp:false
bgp-announce-lb-ip:false
clustermesh-sync-timeout:1m0s
enable-bpf-tproxy:false
bpf-ct-global-tcp-max:524288
mke-cgroup-mount:
keep-config:false
policy-cidr-match-mode:
proxy-xff-num-trusted-hops-ingress:0
install-iptables-rules:true
max-controller-interval:0
enable-health-check-nodeport:true
node-port-bind-protection:true
enable-host-port:false
kube-proxy-replacement-healthz-bind-address:
cni-chaining-target:
nodes-gc-interval:5m0s
proxy-admin-port:0
hubble-socket-path:/var/run/cilium/hubble.sock
iptables-random-fully:false
nat-map-stats-interval:30s
lib-dir:/var/lib/cilium
ipv4-pod-subnets:
enable-monitor:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-vtep:false
enable-ipv4-masquerade:true
vtep-endpoint:
enable-service-topology:false
enable-wireguard-userspace-fallback:false
bpf-ct-global-any-max:262144
enable-k8s-endpoint-slice:true
hubble-listen-address::4244
egress-gateway-policy-map-max:16384
identity-restore-grace-period:30s
envoy-config-timeout:2m0s
proxy-portrange-max:20000
kvstore-connectivity-timeout:2m0s
bpf-lb-mode:snat
enable-ipv4-fragment-tracking:true
k8s-client-connection-timeout:30s
identity-heartbeat-timeout:30m0s
dns-policy-unload-on-shutdown:false
gops-port:9890
l2-announcements-renew-deadline:5s
l2-pod-announcements-interface:
hubble-export-file-path:
ipv4-service-loopback-address:169.254.42.1
cni-exclusive:true
k8s-sync-timeout:3m0s
cluster-id:5
k8s-namespace:kube-system
dnsproxy-socket-linger-timeout:10
derive-masq-ip-addr-from-device:
dnsproxy-lock-timeout:500ms
enable-hubble:true
ipv4-node:auto
hubble-redact-http-urlquery:false
kvstore-max-consecutive-quorum-errors:2
bpf-lb-source-range-map-max:0
api-rate-limit:
hubble-export-file-compress:false
vlan-bpf-bypass:
hubble-redact-enabled:false
policy-accounting:true
bpf-lb-rss-ipv4-src-cidr:
cni-external-routing:false
read-cni-conf:
conntrack-gc-max-interval:0s
bpf-ct-timeout-service-tcp:2h13m20s
hubble-redact-http-headers-deny:
dnsproxy-concurrency-processing-grace-period:0s
enable-srv6:false
bgp-announce-pod-cidr:false
enable-ipsec-key-watcher:true
identity-change-grace-period:5s
static-cnp-path:
enable-unreachable-routes:false
hubble-skip-unknown-cgroup-ids:true
node-port-mode:snat
config-sources:config-map:kube-system/cilium-config
ipsec-key-file:
ipv6-range:auto
envoy-keep-cap-netbindservice:false
disable-external-ip-mitigation:false
bpf-policy-map-full-reconciliation-interval:15m0s
bpf-ct-timeout-regular-tcp:2h13m20s
fqdn-regex-compile-lru-size:1024
dnsproxy-insecure-skip-transparent-mode-check:false
agent-labels:
mesh-auth-mutual-connect-timeout:5s
use-cilium-internal-ip-for-ipsec:false
kvstore-periodic-sync:5m0s
ipv6-native-routing-cidr:
ipam:cluster-pool
cilium-endpoint-gc-interval:5m0s
enable-icmp-rules:true
bgp-config-path:/var/lib/cilium/bgp/config.yaml
local-router-ipv4:
enable-hubble-recorder-api:true
encryption-strict-mode-allow-remote-node-identities:false
bypass-ip-availability-upon-restore:false
ipv4-service-range:auto
trace-payloadlen:128
enable-route-mtu-for-cni-chaining:false
config:
trace-sock:true
ipv4-range:auto
certificates-directory:/var/run/cilium/certs
bpf-lb-service-map-max:0
cni-chaining-mode:none
monitor-aggregation:medium
enable-l7-proxy:true
enable-k8s-terminating-endpoint:true
pprof:false
enable-active-connection-tracking:false
bpf-filter-priority:1
hubble-drop-events-reasons:auth_required,policy_denied
bpf-events-trace-enabled:true
agent-liveness-update-interval:1s
prometheus-serve-addr:
enable-encryption-strict-mode:false
unmanaged-pod-watcher-interval:15
fixed-identity-mapping:
version:false
bpf-lb-algorithm:random
k8s-client-burst:20
ipv6-pod-subnets:
config-dir:/tmp/cilium/config-map
join-cluster:false
enable-auto-protect-node-port-range:true
enable-ipsec-xfrm-state-caching:true
datapath-mode:veth
auto-direct-node-routes:false
endpoint-queue-size:25
hubble-recorder-storage-path:/var/run/cilium/pcaps
envoy-config-retry-interval:15s
ipam-default-ip-pool:default
node-port-acceleration:disabled
enable-tracing:false
cluster-pool-ipv4-mask-size:24
use-full-tls-context:false
proxy-max-requests-per-connection:0
hubble-export-file-max-backups:5
bpf-auth-map-max:524288
mesh-auth-gc-interval:5m0s
k8s-heartbeat-timeout:30s
enable-ipv6-ndp:false
enable-endpoint-health-checking:true
bpf-fragments-map-max:8192
bpf-ct-timeout-regular-any:1m0s
tofqdns-enable-dns-compression:true
node-port-algorithm:random
synchronize-k8s-nodes:true
enable-bbr:false
hubble-export-file-max-size-mb:10
tofqdns-max-deferred-connection-deletes:10000
wireguard-persistent-keepalive:0s
enable-host-firewall:false
bpf-root:/sys/fs/bpf
ipam-multi-pool-pre-allocation:
prepend-iptables-chains:true
clustermesh-enable-endpoint-sync:false
srv6-encap-mode:reduced
dnsproxy-concurrency-limit:0
force-device-detection:false
endpoint-gc-interval:5m0s
identity-gc-interval:15m0s
ipv6-mcast-device:
label-prefix-file:
service-no-backend-response:reject
bpf-lb-sock:false
ingress-secrets-namespace:
enable-wireguard:false
http-retry-count:3
enable-svc-source-range-check:true
proxy-max-connection-duration-seconds:0
identity-allocation-mode:crd
clustermesh-ip-identities-sync-timeout:1m0s
ipv4-native-routing-cidr:
conntrack-gc-interval:0s
bpf-lb-external-clusterip:false
enable-ipv4-big-tcp:false
k8s-api-server:
set-cilium-is-up-condition:true
hubble-drop-events-interval:2m0s
encrypt-node:false
egress-gateway-reconciliation-trigger-interval:1s
k8s-client-connection-keep-alive:30s
dnsproxy-lock-count:131
bpf-nat-global-max:524288
enable-identity-mark:true
http-idle-timeout:0
bpf-lb-rev-nat-map-max:0
mesh-auth-signal-backoff-duration:1s
hubble-metrics:
dns-max-ips-per-restored-rule:1000
enable-bgp-control-plane:false
enable-ipsec-encrypted-overlay:false
mesh-auth-rotated-identities-queue-size:1024
multicast-enabled:false
allow-icmp-frag-needed:true
enable-high-scale-ipcache:false
disable-envoy-version-check:false
hubble-disable-tls:false
tofqdns-min-ttl:0
bpf-node-map-max:16384
local-max-addr-scope:252
bpf-policy-map-max:16384
enable-k8s-networkpolicy:true
max-internal-timer-delay:0s
enable-nat46x64-gateway:false
enable-host-legacy-routing:false
external-envoy-proxy:true
disable-iptables-feeder-rules:
vtep-mask:
container-ip-local-reserved-ports:auto
devices:
http-retry-timeout:0
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
kvstore-lease-ttl:15m0s
dnsproxy-enable-transparent-mode:true
policy-queue-size:100
bpf-sock-rev-map-max:262144
enable-policy:default
bpf-lb-map-max:65536
enable-ipsec:false
enable-endpoint-routes:false
ipv6-service-range:auto
enable-envoy-config:false
enable-session-affinity:false
preallocate-bpf-maps:false
enable-external-ips:false
metrics:
hubble-event-queue-size:0
tofqdns-proxy-response-max-delay:100ms
tunnel-protocol:vxlan
enable-health-check-loadbalancer-ip:false
bpf-lb-dsr-dispatch:opt
enable-health-checking:true
bpf-map-event-buffers:
enable-bpf-clock-probe:false
http-normalize-path:true
debug:false
envoy-log:
policy-audit-mode:false
enable-ipv6:false
enable-ipv4:true
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-masquerade-to-route-source:false
enable-cilium-endpoint-slice:false
auto-create-cilium-node-resource:true
mesh-auth-mutual-listener-port:0
ipv6-node:auto
egress-multi-home-ip-rule-compat:false
enable-ip-masq-agent:false
enable-bandwidth-manager:false
tofqdns-idle-connection-grace-period:0s
cluster-name:cmesh5
node-port-range:
hubble-export-fieldmask:
enable-runtime-device-detection:true
routing-mode:tunnel
encrypt-interface:
bpf-ct-timeout-regular-tcp-syn:1m0s
agent-health-port:9879
enable-l2-neigh-discovery:true
labels:
enable-ipv6-big-tcp:false
restore:true
hubble-prefer-ipv6:false
bpf-map-dynamic-size-ratio:0.0025
local-router-ipv6:
l2-announcements-lease-duration:15s
k8s-client-qps:10
cmdref:
hubble-event-buffer-capacity:4095
hubble-drop-events:false
policy-trigger-interval:1s
k8s-service-cache-size:128
proxy-xff-num-trusted-hops-egress:0
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-metrics-server:
cflags:
remove-cilium-node-taints:true
hubble-redact-http-userinfo:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-events-policy-verdict-enabled:true
proxy-connect-timeout:2
enable-pmtu-discovery:false
kvstore-opt:
procfs:/host/proc
cni-log-file:/var/run/cilium/cilium-cni.log
vtep-cidr:
monitor-queue-size:0
cluster-pool-ipv4-cidr:10.4.0.0/16
annotate-k8s-node:false
cgroup-root:/run/cilium/cgroupv2
debug-verbose:
enable-l2-pod-announcements:false
custom-cni-conf:false
egress-masquerade-interfaces:ens+
enable-k8s-api-discovery:false
kube-proxy-replacement:false
proxy-portrange-min:10000
bpf-lb-dsr-l4-xlate:frontend
enable-gateway-api:false
enable-k8s:true
enable-metrics:true
proxy-prometheus-port:0
hubble-flowlogs-config-path:
bpf-lb-rss-ipv6-src-cidr:
k8s-require-ipv6-pod-cidr:false
pprof-port:6060
iptables-lock-timeout:5s
vtep-mac:
exclude-node-label-patterns:
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
proxy-idle-timeout-seconds:60
cluster-health-port:4240
l2-announcements-retry-period:2s
envoy-secrets-namespace:
operator-prometheus-serve-addr::9963
mtu:0
max-connected-clusters:255
enable-ipv4-egress-gateway:false
hubble-recorder-sink-queue-size:1024
bpf-ct-timeout-service-tcp-grace:1m0s
hubble-redact-http-headers-allow:
log-driver:
enable-recorder:false
enable-well-known-identities:false
k8s-service-proxy-name:
hubble-export-denylist:
bpf-lb-sock-terminate-pod-connections:false
arping-refresh-period:30s
tofqdns-proxy-port:0
enable-cilium-api-server-access:
enable-l2-announcements:false
enable-xt-socket-fallback:true
set-cilium-node-taints:true
envoy-base-id:0
bpf-lb-service-backend-map-max:0
direct-routing-device:
enable-bpf-masquerade:false
k8s-kubeconfig-path:
allocator-list-timeout:3m0s
encryption-strict-mode-cidr:
bpf-neigh-global-max:524288
route-metric:0
mesh-auth-spire-admin-socket:
operator-api-serve-addr:127.0.0.1:9234
bpf-lb-sock-hostns-only:false
enable-mke:false
enable-cilium-health-api-server-access:
enable-local-redirect-policy:false
mesh-auth-queue-size:1024
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-node-selector-labels:false
ip-masq-agent-config-path:/etc/config/ip-masq-agent
crd-wait-timeout:5m0s
monitor-aggregation-flags:all
install-no-conntrack-iptables-rules:false
tunnel-port:0
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-ingress-controller:false
bpf-events-drop-enabled:true
bpf-lb-affinity-map-max:0
enable-stale-cilium-endpoint-cleanup:true
enable-xdp-prefilter:false
ipsec-key-rotation-duration:5m0s
mesh-auth-enabled:true
http-max-grpc-timeout:0
pprof-address:localhost
mesh-auth-spiffe-trust-domain:spiffe.cilium
hubble-export-allowlist:
http-request-timeout:3600
enable-node-port:false
k8s-require-ipv4-pod-cidr:false
disable-endpoint-crd:false
allow-localhost:auto
bpf-ct-timeout-service-any:1m0s
state-dir:/var/run/cilium
hubble-redact-kafka-apikey:false
log-opt:
kvstore:
clustermesh-config:/var/lib/cilium/clustermesh/
enable-custom-calls:false
enable-tcx:true
enable-local-node-route:true
socket-path:/var/run/cilium/cilium.sock
enable-ipip-termination:false
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                    IPv6   IPv4         STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
198        Disabled           Disabled          361562     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.4.0.75    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client2                                                            
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client2                                                                                           
                                                           k8s:other=client                                                                                           
244        Disabled           Disabled          332688     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.4.0.239   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=client                                                             
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=client                                                                                            
                                                           k8s:name=client                                                                                            
751        Disabled           Disabled          336619     k8s:eks.amazonaws.com/component=coredns                                               10.4.0.163   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
839        Disabled           Disabled          336619     k8s:eks.amazonaws.com/component=coredns                                               10.4.0.224   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
1461       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=use1-az1                                                                      
                                                           k8s:topology.kubernetes.io/region=us-east-1                                                                
                                                           k8s:topology.kubernetes.io/zone=us-east-1a                                                                 
                                                           reserved:host                                                                                              
2244       Disabled           Disabled          359982     k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli                  10.4.0.200   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1                               
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node                                                     
                                                           k8s:io.kubernetes.pod.namespace=cilium-test-1                                                              
                                                           k8s:kind=echo                                                                                              
                                                           k8s:name=echo-same-node                                                                                    
                                                           k8s:other=echo                                                                                             
2951       Disabled           Disabled          350710     k8s:app.kubernetes.io/name=clustermesh-apiserver                                      10.4.0.93    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh5                                                                    
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
3262       Disabled           Disabled          4          reserved:health                                                                       10.4.0.105   ready   
```

#### BPF Policy Get 198

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 198

```
Invalid argument: unknown type 198
```


#### Endpoint Get 198

```
[
  {
    "id": 198,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-198-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "f5057760-47e7-49fe-ac4d-fc8447bfeec9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-198",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.908Z",
            "success-count": 2
          },
          "uuid": "17003661-d118-4714-a8ef-619dc302dfd7"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client2-57cf4468f-tmdnj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.906Z",
            "success-count": 1
          },
          "uuid": "99aa0849-31ea-444c-a67f-63567d95a676"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-198",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.958Z",
            "success-count": 1
          },
          "uuid": "b0407331-215b-4954-9953-a647f367fec9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (198)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.941Z",
            "success-count": 33
          },
          "uuid": "7985b9e0-cdc3-480c-9bf5-2e8303cf118d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b944366bddfd3d359d06eb11bdef864e2272dfc3e70ae8fb651f66b13baadbf5:eth0",
        "container-id": "b944366bddfd3d359d06eb11bdef864e2272dfc3e70ae8fb651f66b13baadbf5",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client2-57cf4468f-tmdnj",
        "pod-name": "cilium-test-1/client2-57cf4468f-tmdnj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 361562,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=57cf4468f"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=client2",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client2",
          "k8s:other=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:45Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.75",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7e:14:39:e4:98:ca",
        "interface-index": 19,
        "interface-name": "lxc142ae6a3e494",
        "mac": "22:b4:5e:58:86:e4"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 64,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 4,
                "received": 4
              },
              "responses": {
                "forwarded": 4,
                "received": 4
              }
            }
          },
          {
            "location": "egress",
            "port": 4096,
            "protocol": "http",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 9,
                "received": 9
              },
              "responses": {
                "forwarded": 9,
                "received": 9
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 361562,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 361562,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 198

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 198

```
Timestamp              Status   State                   Message
2024-10-24T09:24:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:28Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:28Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 361562

```
ID       LABELS
361562   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=client2
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client2
         k8s:other=client

```


#### BPF Policy Get 244

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 244

```
Invalid argument: unknown type 244
```


#### Endpoint Get 244

```
[
  {
    "id": 244,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-244-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "d7848787-2d0a-4c18-a28e-638b96dd5a7e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-244",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:15.837Z",
            "success-count": 2
          },
          "uuid": "bc931c82-d7b1-45a8-a3ed-c93cb5fc4dd6"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/client-974f6c69d-z648w",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.835Z",
            "success-count": 1
          },
          "uuid": "8b349839-a3a4-43c7-98e8-42f3cdd368f3"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-244",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:15.899Z",
            "success-count": 1
          },
          "uuid": "2b244d58-6a10-4120-beb9-049bfde4f2bb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (244)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:25.868Z",
            "success-count": 33
          },
          "uuid": "5f712e79-064e-4c25-8613-b0e1e6c54559"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "8a95d5ef92b305343ba8e5e800957a3ca528ad024163106ad6699b361f52777a:eth0",
        "container-id": "8a95d5ef92b305343ba8e5e800957a3ca528ad024163106ad6699b361f52777a",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "client-974f6c69d-z648w",
        "pod-name": "cilium-test-1/client-974f6c69d-z648w"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 332688,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=974f6c69d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=client",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=client",
          "k8s:name=client"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:24:45Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.239",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:fe:93:e0:9b:26",
        "interface-index": 17,
        "interface-name": "lxc1f40b3fd9411",
        "mac": "d2:f9:e1:b7:e0:ff"
      },
      "policy": {
        "proxy-policy-revision": 157,
        "proxy-statistics": [
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 53,
            "protocol": "dns",
            "statistics": {
              "requests": {
                "forwarded": 32,
                "received": 32
              },
              "responses": {
                "forwarded": 32,
                "received": 32
              }
            }
          },
          {
            "location": "egress",
            "port": 80,
            "protocol": "http",
            "statistics": {
              "requests": {
                "forwarded": 1,
                "received": 1
              },
              "responses": {
                "forwarded": 1,
                "received": 1
              }
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          },
          {
            "location": "egress",
            "port": 5353,
            "protocol": "dns",
            "statistics": {
              "requests": {},
              "responses": {}
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 332688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 332688,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 244

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 244

```
Timestamp              Status   State                   Message
2024-10-24T09:24:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:14Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:24:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:24:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:24:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:24:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:28Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:28Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:05Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:05Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added

```


#### Identity get 332688

```
ID       LABELS
332688   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=client
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=client
         k8s:name=client

```


#### BPF Policy Get 751

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5956    65        0        
Allow    Ingress     1          ANY          NONE         disabled    55238   634       0        
Allow    Egress      0          ANY          NONE         disabled    13381   137       0        

```


#### BPF CT List 751

```
Invalid argument: unknown type 751
```


#### Endpoint Get 751

```
[
  {
    "id": 751,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-751-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7603ad99-104f-450b-8f88-7e52d158df8e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-751",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.351Z",
            "success-count": 3
          },
          "uuid": "e2b9fccc-24e5-4b46-b471-8dc329765229"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-2zsn8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:20.348Z",
            "success-count": 1
          },
          "uuid": "1debdf7f-918f-422d-89c6-13674a109262"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-751",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:24.105Z",
            "success-count": 1
          },
          "uuid": "6e2785e8-c3aa-42ab-bd21-0391a2eba98f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (751)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.401Z",
            "success-count": 62
          },
          "uuid": "f1335b17-3899-4916-92be-af5d4d134057"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0d755163031148b83ce49d9a10424a23bf05d7cac4c0109bf8aa720aab2d090d:eth0",
        "container-id": "0d755163031148b83ce49d9a10424a23bf05d7cac4c0109bf8aa720aab2d090d",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-2zsn8",
        "pod-name": "kube-system/coredns-586b798467-2zsn8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 336619,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.163",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d2:dd:38:52:88:bc",
        "interface-index": 9,
        "interface-name": "lxceb65690dfaed",
        "mac": "fe:a2:00:8e:d2:f2"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 336619,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 336619,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 751

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 751

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:20Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:20Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:20Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 336619

```
ID       LABELS
336619   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 839

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5420    59        0        
Allow    Ingress     1          ANY          NONE         disabled    54908   629       0        
Allow    Egress      0          ANY          NONE         disabled    13445   138       0        

```


#### BPF CT List 839

```
Invalid argument: unknown type 839
```


#### Endpoint Get 839

```
[
  {
    "id": 839,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-839-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "22eb6047-2206-4e5c-8d9c-2cf191bfc9c6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-839",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.460Z",
            "success-count": 3
          },
          "uuid": "90094f3f-68ba-4a55-9fb1-680ca5a76b5a"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-586b798467-bngqp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:20.459Z",
            "success-count": 1
          },
          "uuid": "5658b04b-f363-42a0-962c-ad9ed3b6ac3e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-839",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:24.113Z",
            "success-count": 1
          },
          "uuid": "c479d4de-7208-4335-9e60-6890773c5460"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (839)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.508Z",
            "success-count": 62
          },
          "uuid": "1620032a-55b0-416b-a1aa-7342adf77363"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "9f48323e0325411a0086373e250267f0a8e2e1a25eda97c6507a3c395344a757:eth0",
        "container-id": "9f48323e0325411a0086373e250267f0a8e2e1a25eda97c6507a3c395344a757",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-586b798467-bngqp",
        "pod-name": "kube-system/coredns-586b798467-bngqp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 336619,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=586b798467"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.224",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:fc:78:3a:2c:81",
        "interface-index": 11,
        "interface-name": "lxcad13466e51ce",
        "mac": "7a:9f:10:fe:fa:05"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 336619,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 336619,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 839

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 839

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:20Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:20Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:20Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 336619

```
ID       LABELS
336619   k8s:eks.amazonaws.com/component=coredns
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=coredns
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=kube-dns

```


#### BPF Policy Get 1461

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1461

```
Invalid argument: unknown type 1461
```


#### Endpoint Get 1461

```
[
  {
    "id": 1461,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1461-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "54804564-d84f-4adb-9ef1-5ab294ed81ef"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1461",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:19.435Z",
            "success-count": 3
          },
          "uuid": "eb17982b-316f-4b18-8f24-5469b78a376a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1461",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:20.609Z",
            "success-count": 1
          },
          "uuid": "a5ee5a44-c899-4a52-9fb5-404dfa09e028"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=use1-az1",
          "k8s:topology.kubernetes.io/region=us-east-1",
          "k8s:topology.kubernetes.io/zone=us-east-1a",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "ba:a5:12:fe:c3:13",
        "interface-name": "cilium_host",
        "mac": "ba:a5:12:fe:c3:13"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1461

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1461

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:24Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:19Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:19Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 2244

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4408     33        0        
Allow    Ingress     1          ANY          NONE         disabled    302669   3530      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 2244

```
Invalid argument: unknown type 2244
```


#### Endpoint Get 2244

```
[
  {
    "id": 2244,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2244-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "82e59e75-91e5-4247-a3ff-15bb7bd879bb"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2244",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:17.768Z",
            "success-count": 2
          },
          "uuid": "ccc328a4-e893-4711-8c81-be28a8cd3a34"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-28tnz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.767Z",
            "success-count": 1
          },
          "uuid": "684e8df9-3471-421e-bcee-9af35da8ab1b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2244",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:20:17.802Z",
            "success-count": 1
          },
          "uuid": "bfb7297f-7d23-439b-8099-b3fe53643934"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2244)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:27.801Z",
            "success-count": 33
          },
          "uuid": "c9c1c9f3-5330-480c-9132-6cbf0d2e8e8f"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7a03600cc05b480b3d8441a43d6186628dae915efcb55a6c9360ab74c3e48a1d:eth0",
        "container-id": "7a03600cc05b480b3d8441a43d6186628dae915efcb55a6c9360ab74c3e48a1d",
        "k8s-namespace": "cilium-test-1",
        "k8s-pod-name": "echo-same-node-86d9cc975c-28tnz",
        "pod-name": "cilium-test-1/echo-same-node-86d9cc975c-28tnz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 359982,
        "labels": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=86d9cc975c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node",
          "k8s:io.kubernetes.pod.namespace=cilium-test-1",
          "k8s:kind=echo",
          "k8s:name=echo-same-node",
          "k8s:other=echo"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: policy rules added)",
          "state": "ready",
          "timestamp": "2024-10-24T09:23:20Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns-53",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "dns-udp-53",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "http-8080",
          "port": 8080,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.200",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "d6:07:0b:a8:c5:8f",
        "interface-index": 21,
        "interface-name": "lxccd75ea23b396",
        "mac": "3a:6a:78:18:55:66"
      },
      "policy": {
        "proxy-policy-revision": 133,
        "proxy-statistics": [
          {
            "location": "ingress",
            "port": 8080,
            "protocol": "http",
            "statistics": {
              "requests": {
                "denied": 2,
                "forwarded": 4,
                "received": 6
              },
              "responses": {
                "forwarded": 6,
                "received": 6
              }
            }
          }
        ],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 359982,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 133,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 359982,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 133
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2244

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2244

```
Timestamp              Status   State                   Message
2024-10-24T09:23:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:13Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:23:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:23:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:23:06Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:23:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:56Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:51Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:51Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:49Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:49Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:49Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:49Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:48Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:48Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:40Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:38Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:37Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:35Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:27Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:22Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:20Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:22:17Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:22:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:46Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:46Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:45Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:45Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:44Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:44Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:44Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:43Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:43Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:43Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:43Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:39Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:39Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:39Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:39Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:36Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:34Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:34Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:34Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:34Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:33Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:33Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:33Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:33Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:32Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:31Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:19Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:18Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:21:01Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)
2024-10-24T09:21:01Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:21:01Z   OK       regenerating            Regenerating endpoint: policy rules added
2024-10-24T09:21:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to policy rules added
2024-10-24T09:20:44Z   OK       ready                   Successfully regenerated endpoint program (Reason: policy rules added)

```


#### Identity get 359982

```
ID       LABELS
359982   k8s:io.cilium.k8s.namespace.labels.app.kubernetes.io/name=cilium-cli
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=cilium-test-1
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=echo-same-node
         k8s:io.kubernetes.pod.namespace=cilium-test-1
         k8s:kind=echo
         k8s:name=echo-same-node
         k8s:other=echo

```


#### BPF Policy Get 2951

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    218100   2050      0        
Allow    Ingress     1          ANY          NONE         disabled    217157   2262      0        
Allow    Egress      0          ANY          NONE         disabled    259717   2378      0        

```


#### BPF CT List 2951

```
Invalid argument: unknown type 2951
```


#### Endpoint Get 2951

```
[
  {
    "id": 2951,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2951-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "10c17c16-248d-4f7d-bb5d-3225845b512f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2951",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:23:47.009Z",
            "success-count": 2
          },
          "uuid": "c55a711d-831d-429a-9840-673fb530d90b"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:47.008Z",
            "success-count": 1
          },
          "uuid": "fbe1b146-883c-44f2-a8ae-c0e6837531b1"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2951",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:18:47.039Z",
            "success-count": 1
          },
          "uuid": "ae7873d3-59b6-40e1-a10f-27cb36549349"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2951)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:27.049Z",
            "success-count": 42
          },
          "uuid": "8e5a8791-3c06-4d3e-95b0-6062060ee672"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "81e5335af1e773f9aaa9f55d0e6b612e02b1c26031aa17ad5f08ea3640039180:eth0",
        "container-id": "81e5335af1e773f9aaa9f55d0e6b612e02b1c26031aa17ad5f08ea3640039180",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7b4f4f4459-bw7kd",
        "pod-name": "kube-system/clustermesh-apiserver-7b4f4f4459-bw7kd"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 350710,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7b4f4f4459"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh5",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.93",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "fa:53:00:2b:e4:9b",
        "interface-index": 15,
        "interface-name": "lxc99a47c4a39e2",
        "mac": "5e:b3:20:7b:7e:30"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 350710,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 350710,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2951

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2951

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:47Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:18:47Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:47Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:18:47Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:18:47Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:18:47Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 350710

```
ID       LABELS
350710   k8s:app.kubernetes.io/name=clustermesh-apiserver
         k8s:app.kubernetes.io/part-of=cilium
         k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
         k8s:io.cilium.k8s.policy.cluster=cmesh5
         k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
         k8s:io.kubernetes.pod.namespace=kube-system
         k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 3262

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23325   290       0        
Allow    Ingress     1          ANY          NONE         disabled    7981    90        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3262

```
Invalid argument: unknown type 3262
```


#### Endpoint Get 3262

```
[
  {
    "id": 3262,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3262-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "1668fb3b-4ed7-46c5-b859-124dc0b25bab"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3262",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:25:20.494Z",
            "success-count": 3
          },
          "uuid": "d96b6c40-7040-46bc-9e09-ed8214fe2d68"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3262",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-24T09:15:24.179Z",
            "success-count": 1
          },
          "uuid": "81547462-f82b-4c06-95be-323bcdbc7e4c"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-24T09:20:19Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.4.0.105",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "4e:62:bd:f5:03:31",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "de:cc:09:f0:de:e0"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 157,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 157
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3262

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3262

```
Timestamp              Status   State                   Message
2024-10-24T09:20:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:20:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:19Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:20:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:20:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:16Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:20:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:20:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:20:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:20:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-24T09:18:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:56Z   OK       regenerating            Regenerating endpoint: 
2024-10-24T09:18:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-24T09:18:55Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:55Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:55Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:55Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:18:54Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:18:54Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:18:54Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:18:54Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-24T09:15:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-24T09:15:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-24T09:15:24Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-24T09:15:24Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-24T09:15:24Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-24T09:15:21Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-24T09:15:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-24T09:15:20Z   OK       ready                   Set identity for this endpoint
2024-10-24T09:15:19Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Policy get

```
:
 []
Revision: 157

```

