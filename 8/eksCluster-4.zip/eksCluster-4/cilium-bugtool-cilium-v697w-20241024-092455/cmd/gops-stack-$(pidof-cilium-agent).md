goroutine 155 [running]:
runtime/pprof.writeGoroutineStacks({0xffff51fdec48, 0x400136e000})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6c
runtime/pprof.writeGoroutine({0xffff51fdec48?, 0x400136e000?}, 0x10?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x2c
runtime/pprof.(*Profile).WriteTo(0x61dd090?, {0xffff51fdec48?, 0x400136e000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x148
github.com/google/gops/agent.handle({0xffff51fdec20, 0x400136e000}, {0x400199cdb8?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x23a0
github.com/google/gops/agent.listen({0x3e0bbf0, 0x40004f68c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x188
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x320

goroutine 1 [select, 10 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x400019c5a0, 0x4000e61390)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x104
github.com/cilium/hive.(*Hive).Run(0x400019c5a0, 0x4000e61390)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0xe8
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x400017db08, {0x377b213?, 0x4?, 0x377b083?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x170
github.com/spf13/cobra.(*Command).execute(0x400017db08, {0x400014c010, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0x828
github.com/spf13/cobra.(*Command).ExecuteC(0x400017db08)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x344
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0x400019c5a0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x1c
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x64

goroutine 21 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40007f71a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 31 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x5c
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x8c

goroutine 162 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40024897c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 46 [select, 10 minutes]:
io.(*pipe).read(0x40007f69c0, {0x400159c000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x400159c000?, 0x4000095e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000095f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e380, 0x40007f69c0, 0x4000e61310)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 47 [select, 10 minutes]:
io.(*pipe).read(0x40007f6a80, {0x40016de000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x40016de000?, 0x4000096678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000096718)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e380, 0x40007f6a80, 0x4000e61330)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 48 [select, 10 minutes]:
io.(*pipe).read(0x40007f6ae0, {0x40016f0000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x40016f0000?, 0x4000096e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x40009cbf18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e380, 0x40007f6ae0, 0x4000e61350)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 49 [select, 10 minutes]:
io.(*pipe).read(0x40007f7740, {0x40017a0000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x40017a0000?, 0x4000097678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x40009cdf18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e380, 0x40007f7740, 0x4000e61370)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 32 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40024895e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1494 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000bf4dc0, {{{0x37b1743, 0x12}}, {0x0, 0x0}, 0x400153f740, 0x0, 0x400153f750, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 164
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 163 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x74
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x70

goroutine 164 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002489860)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 165 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4000e6ae10, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000e6ae00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0x40018f3bc0, {0x3e23828, 0x400252d220})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xfc
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x10c
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x15c

goroutine 166 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x138
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1509 [select, 6 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x3cc
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa8

goroutine 1512 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40026c99f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004dd180, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400080c000, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1629 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ca9a40, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40005b7ae0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1640 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1624 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000fe2dc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3732 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4001bdb8c8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3713
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1626 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40005b79a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ca97c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000c73e70, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1413 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1409
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 156 [select, 8 minutes]:
github.com/cilium/statedb.graveyardWorker(0x4001b5fab0, {0x3e23828, 0x4001ea7770}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x12c
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x14c

goroutine 176 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004dd400, {{{0x379a274, 0xd}}, {0x0, 0x0}, 0x40006b40e0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 178 [select]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e54fc0, {0x3e237f0, 0x4001ed1b60}, {0x3e2b960, 0x4002555560})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x294
github.com/cilium/hive/job.(*jobOneShot).start(0x4001b75aa0, {0x3e237f0, 0x4001ed1b60}, 0xba7cf0?, {0x3e2b960, 0x4001b75740}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 174 [IO wait]:
internal/poll.runtime_pollWait(0xffff525dcd78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40000dcf80?, 0x40029a8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40000dcf80, {0x40029a8000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40000dcf80, {0x40029a8000?, 0x40005d3f40?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d3ca90, {0x40029a8000?, 0x40021d3868?, 0x1fd48?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003cf8768, {0x40029a8000?, 0x0?, 0x4003cf8768?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4000df37b0, {0x3dd1940, 0x4003cf8768})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4000df3508, {0xffff522550d0, 0x4000deabe8}, 0x40021d39d0?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4000df3508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4000df3508, {0x400255b000, 0x1000, 0x400259e000?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40025551a0, {0x4000c1c040, 0x9, 0x6d?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40025551a0}, {0x4000c1c040, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000c1c040, 0x9, 0x21d3da8?}, {0x3dcc0a0?, 0x40025551a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000c1c000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
golang.org/x/net/http2.(*clientConnReadLoop).run(0x40021d3f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xd0
golang.org/x/net/http2.(*ClientConn).readLoop(0x4001c4ed80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x80
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 173
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xae0

goroutine 1325 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 431
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1327 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1324
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 244 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x40024702c0, 0x40025f4120, 0x40025f41e0, 0x40025f4240)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x1d0
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x40024702c0, {0x3e23828?, 0x400257ee10?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x3d8
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x40024702c0, {0x3e23828, 0x400257ee10})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x70
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x120

goroutine 816 [select, 1 minutes]:
reflect.rselect({0x40043c05a0, 0x9, 0xffff523c8f98?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4002130400?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4002382ff0, {0x3e237f0, 0x4000ca6570}, 0x40004cf880, {0xffff5220d950, 0x40004574f0}, 0x4002573200, {0x385b1ff?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4002382ff0, {0x3e237f0, 0x4000ca6570}, {0xffff5220d950, 0x40004574f0}, {0x385b1ff, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0x4002382ff0, {0x3e3e7a8, 0x40004574f0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x78
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x365dfc0?, 0x4002382ff0}, {0x3e32818, 0x4000e3e960})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4000a5b400, {0x3e237f0, 0x4000ca6480}, {0x3e42860, 0x4002184a80}, 0x4000daf440, 0x40023832c0, 0x62382a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4000a5b400, {0x3e42860, 0x4002184a80}, 0x4000daf440)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 815
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 245 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x2c
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x108

goroutine 1513 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0xffffffffffffffff?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40009727e0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 424 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 396
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 260 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 243
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 198 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x400187abd8, 0x7)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400187abc8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400187abb0, 0x4001336440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe2f00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002560ec0, {0x3ddab40, 0x4001cb6c60}, 0x1, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002560ec0, 0x3b9aca00, 0x0, 0x1, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe2f00, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40004f7380, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 159
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 199 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 159
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1324 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40025300d8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40025300c8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40025300b0, 0x400002a280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40033a9ec0, {0x3ddab40, 0x4000dcd5c0}, 0x1, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40033a9ec0, 0x3b9aca00, 0x0, 0x1, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe2000, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40019fa240, 0x40031d4780)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 431
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 262 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff525dcc80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400262a2a0?, 0x400276fe2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400262a2a0, {0x400276fe2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x40012211f8, {0x400276fe2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40013f80c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1523 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1425 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400249db00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1430 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x400002b650, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400002b640)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400249dbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ac40, {0x3e23828, 0x4001ea7e50}, 0x4002601920, {0x3e3b2b0, 0x4001095218})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1388 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400249cf60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 202 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 198
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 738 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002103980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 248 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x14, 0x400272f940, 0x10000, 0x0, 0x400141d340, 0x400272f8f4)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x74?, {0x400272f940?, 0x0?, 0x600001800000074?}, 0x0?, 0x4003b3d010?, 0x64?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x14, {0x400272f940, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x15?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x74
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x30c

goroutine 250 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x15, 0x400274fe90, 0x10000, 0x0, 0x40018a9500, 0x400274fe44)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x59c?, {0x400274fe90?, 0x0?, 0x100000059c?}, 0x0?, 0x40035e8010?, 0x58c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x15, {0x400274fe90, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x400275fee8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x70
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x304

goroutine 1362 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x100
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb0

goroutine 813 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4000778500, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40004cfa40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xbc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 831
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x13d0

goroutine 204 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 198
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 264 [select, 10 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0x40023e92b0)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0xc0
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x318

goroutine 745 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4001611850, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001611840)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400212a240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x4000801720}, 0x400230c1e0, {0x3e3b4c0, 0x40005e5e48})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 726
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 746 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 726
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 205 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004139f40}, {0xffff52204428, 0x400187abb0}, {0x3e672a8, 0x371cf40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001cbc700, {0x0?, 0x0?}, 0x4001ebb620, 0x40021cf200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001cbc700, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40021d9f40, {0x3ddab60, 0x4001ea7ef0}, 0x1, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001cbc700, 0x4001ebb620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 198
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 360 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40008b4640, {{{0x3791109, 0xb}}, {0x3e2b960, 0x400022c480}, 0x4000d1e950, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 208 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001cbc700, 0x4001ebb620, 0x4001ebbaa0, 0x40021cf200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 205
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 5025 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003ca84c8, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003ca84b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003ca84b0, {0x40003aa27c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40021e6cc8?}, {0x40003aa27c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x4003ca8480}, {0x40003aa27c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003cf9050, {0x4004006f00, 0x2000, 0x2500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004148f50, 0x0, {0x3e02238, 0x4004331340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001998800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004139f40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 205
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1495 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000bf4f00, {{{0x37e6ffb, 0x1e}}, {0x0, 0x0}, 0x4001095b60, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1508
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 265 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x3e237f0, 0x4002628d20}, {0x3e62c10, 0x400248c700}, {0x3e2b960, 0x40026a4240}, 0x1, 0x400019c910, 0x400264bd50, 0x400264bd40, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x5c4
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x3e237f0, 0x4002628d20}, {0x3e2b960, 0x40026a4240})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0xdc
github.com/cilium/hive/job.(*jobOneShot).start(0x400249c660, {0x3e237f0, 0x4002628d20}, 0x16f179c?, {0x3e2b960, 0x400249c600}, {{{0x40018b81a0, 0x1, 0x1}}, 0x4000fba900, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 258 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400262a1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 243
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 257 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400262a0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 243
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1732 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220be90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40029d2e00?, 0x4002c24000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40029d2e00, {0x4002c24000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40029d2e00, {0x4002c24000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001220868, {0x4002c24000?, 0x72?, 0x4002d8a158?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4002d8a150, {0x4002c24000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002d79920)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002d79920, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4000e31560, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 841 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xc0
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x26c

goroutine 1429 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400249dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 3652 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd030, {0x3e23828, 0x400315b090})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3630
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 247 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x2c
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x108

goroutine 249 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x2c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x100

goroutine 259 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x4001337e10, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001337e00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400262a0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4afc0, {0x3e23828, 0x40021ea7d0}, 0x4002600cc0, {0x3e3b518, 0x4000c085a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 243
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 268 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 265
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 5008 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003ca8480, 0x4003ab6360, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003ca8480, 0x8a6d4?, 0x4001336a40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 205
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 246 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x13, 0x400270fdb0, 0x10000, 0x0, 0x40011f2b60, 0x400270fd64)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x50?, {0x400270fdb0?, 0x0?, 0x1400000050?}, 0x0?, 0x4003aa68d0?, 0x40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x13, {0x400270fdb0, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x4003aa68d0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x70
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 244
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x30c

goroutine 263 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40008b52c0, {{{0x379eee1, 0xe}}, {0x0, 0x0}, 0x4000d19a80, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 243 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0x400247e1a0, {0x3e23828?, 0x40008f5e00?}, 0x40017d8000)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xa4
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x3c
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x304

goroutine 423 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 396
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 421 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 422 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x38
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 391
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0x88

goroutine 1378 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40043c74c0}, {0xffff52204428, 0x40025300b0}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40011367e0, {0x0?, 0x0?}, 0x40031d4780, 0x40005e98c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40011367e0, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40009c5f40, {0x3ddab60, 0x4001ea6460}, 0x1, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40011367e0, 0x40031d4780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1324
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 3708 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc28e0, {0x3e23828, 0x40032c65a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3641
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1670 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff5220bca0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002398400?, 0x4000d43000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002398400, {0x4000d43000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002398400, {0x4000d43000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000845858, {0x4000d43000?, 0x72?, 0x4000fa1178?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000fa1170, {0x4000d43000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002091440)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002091440, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4000ce8750, {0x3e237f0, 0x4000dcdd70})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1368
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1730 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220b7c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40029d2d80?, 0x40029ff000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40029d2d80, {0x40029ff000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40029d2d80, {0x40029ff000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001220860, {0x40029ff000?, 0x13?, 0x4001b8dd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400118fe60, {0x40029ff000?, 0x40033a7d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003194780)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003194780, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400118fe60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1712
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 836 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1377 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1324
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 740 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1365 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x4001ed30e0, {0x3e237f0, 0x400199f770}, 0x0?, {0x3e2b960, 0x4001ed2f60}, {{{0x40012f7040, 0x1, 0x1}}, 0x40018731d0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 396 [select, 6 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x4000c2a480, {0x3e237f0, 0x40023a8000}, {0x3e2b960, 0x4002540d80})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x2d8
github.com/cilium/hive/job.(*jobOneShot).start(0x400249d5c0, {0x3e237f0, 0x40023a8000}, 0x656863532e636570?, {0x3e2b960, 0x400249d2c0}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 394 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff525dc4c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1d?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002616280)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002616280)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001cefc48?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4002382990)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4000a5b400, {0x3e0bc20, 0x4002382990})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x19c

goroutine 395 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400253a820)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 393 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x38
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x184

goroutine 390 [select]:
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x4000b5b400, {0x3e23828, 0x40026c85a0})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:401 +0x368
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x78
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 368
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x50

goroutine 392 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0xffff525dca90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x19?, 0x967e0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002616100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002616100)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40009bfd98?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).AcceptUnix(0x40023827b0)
	/usr/local/go/src/net/unixsock.go:247 +0x2c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x124

goroutine 744 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400212a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 726
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 737 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002103800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 361 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x400261a480?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 385 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400253a500)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 391 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff525dc998, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x17?, 0x100a88?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40021dbf00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40021dbf00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001dfddc8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4002382600)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x40006b4e60, {0x3e23828, 0x4000768410}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xbc
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x144

goroutine 368 [chan receive, 10 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x40026c8550, {0x3e23828, 0x40026c85a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x60
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x134

goroutine 739 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40016115d0, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40016115c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002103800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x40008013b0}, 0x400148f440, {0x3e3b570, 0x4001d4b728})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 367 [select, 10 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e55100, {0x3e237f0, 0x40026c31a0}, {0x3e2b960, 0x400022dda0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x298
github.com/cilium/hive/job.(*jobOneShot).start(0x400249cea0, {0x3e237f0, 0x40026c31a0}, 0x4000f988a0?, {0x3e2b960, 0x400249cc00}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 363 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e70e80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 846 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019677a0, 0x40022e62a0, 0x4002386120, 0x4002176cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 854
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1428 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400249dbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 362 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x5555555555555555?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001c4e900?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 628 [select, 10 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 644
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xc0

goroutine 429 [select, 6 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x4001ef1e80)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x74
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x60

goroutine 9427 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042db380, 0x40057fed80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042db380, 0x3e237f0?, 0x4000dcdd70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 702
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 802 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4000c1d0a0, 0x400148fc80, 0x400230cea0, 0x400212b0e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 702
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 701 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 685
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 702 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400170cbc0}, {0xffff52204428, 0x40025308f0}, {0x3e672a8, 0x371cba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4000c1d0a0, {0x0?, 0x0?}, 0x400148fc80, 0x400212b0e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4000c1d0a0, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400295bf40, {0x3ddab60, 0x40008014f0}, 0x1, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4000c1d0a0, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 685
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 743 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400212a240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 726
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 817 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4000c1c7e0, 0x400148f6e0, 0x4001ebad20, 0x40021f4840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 696
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 12211 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40041a1cc8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40041a1cb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40041a1cb0, {0x40050c41f8, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003364cc8?}, {0x40050c41f8?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x40041a1c80}, {0x40050c41f8, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4004c6caf8, {0x40045ed400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40049d8280, 0x0, {0x3e02238, 0x40049796c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40000305a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004979680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 696
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 696 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004979680}, {0xffff52204428, 0x400187a370}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4000c1c7e0, {0x0?, 0x0?}, 0x400148f6e0, 0x40021f4840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4000c1c7e0, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002949f40, {0x3ddab60, 0x40008014a0}, 0x1, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4000c1c7e0, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 690
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 699 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 685
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 695 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 690
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 693 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 690
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 668 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40016485c0}, {0xffff52204428, 0x4002530580}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001cbc7e0, {0x0?, 0x0?}, 0x4000db6ba0, 0x4002102540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001cbc7e0, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002687f40, {0x3ddab60, 0x40000e37c0}, 0x1, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001cbc7e0, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 661
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 652 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400253abe0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 647 [syscall, 10 minutes]:
syscall.Syscall6(0x16, 0x1b, 0x4001c4a3a0, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x0?, {0x4001c4a3a0?, 0x40001480c0?, 0x40026859e0?}, 0x4002685a58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x40006b5600, {0x4001c4a3a0, 0x2, 0x2}, {0x40006bbb30?, 0x32d640?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4001783b00, 0x4002685bd8)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(0x4000413a40?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x38
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x78
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x128

goroutine 1593 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4000f58a10, 0x26)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f58a00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40026a5d40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x4000377cc0}, 0x4001ebb800, {0x3e3b258, 0x4000fcae70})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1366
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 654 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001cbc7e0, 0x4000db6ba0, 0x400148ef60, 0x4002102540)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 667 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 661
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 665 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 661
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 3644 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 662 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 240
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 657 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020a9500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 661 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x40025305a8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530598)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002530580, 0x4001383780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40025dbec0, {0x3ddab40, 0x4000c941e0}, 0x1, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40025dbec0, 0x3b9aca00, 0x0, 0x1, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556b40, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005ed000, 0x4000db6ba0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 240
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 659 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 637 [IO wait]:
internal/poll.runtime_pollWait(0xffff525dc3c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001bafe80?, 0x4003c4cc00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x4001bafe80, {0x4003c4cc00, 0x200, 0x200}, {0x4003f975c0, 0x2c, 0x2c}, 0x0, 0x40025c3818)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x254
net.(*netFD).readMsgInet4(0x4001bafe80, {0x4003c4cc00?, 0x40025c3808?, 0x71368?}, {0x4003f975c0?, 0x71374?, 0x40025c37d8?}, 0x1ea1c?, 0x40025c37f8?)
	/usr/local/go/src/net/fd_posix.go:84 +0x2c
net.(*UDPConn).readMsg(0x31926c0?, {0x4003c4cc00?, 0x1fa?, 0x2?}, {0x4003f975c0?, 0x10?, 0x40025c3918?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x124
net.(*UDPConn).ReadMsgUDPAddrPort(0x40012219f0, {0x4003c4cc00?, 0xffff525dc3c8?, 0x77359157?}, {0x4003f975c0?, 0x2a69c84?, 0x400246e510?})
	/usr/local/go/src/net/udpsock.go:203 +0x34
net.(*UDPConn).ReadMsgUDP(0x400246e510?, {0x4003c4cc00?, 0x0?, 0x4000851490?}, {0x4003f975c0?, 0x2a098e0?, 0x10?})
	/usr/local/go/src/net/udpsock.go:191 +0x24
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x40012219f0?, 0x40012219f0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x5c
github.com/cilium/dns.(*Server).readUDP(0x4002618900, 0x40012219f0, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0x140
github.com/cilium/dns.defaultReader.ReadUDP({0x61df4d0?}, 0x318dd00?, 0x77359400?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x1c
github.com/cilium/dns.(*Server).serveUDP(0x4002618900, {0x3e35e70, 0x40012219f0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x20c
github.com/cilium/dns.(*Server).ActivateAndServe(0x4002618900)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x178
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4002618900)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 658 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x4000769360}, 0x4000db63c0, {0x3e3b4c0, 0x40005e4d50})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x4dc
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 640 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020a93e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 5273 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40042dac48, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042dac38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042dac30, {0x40035e8c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40050f1cc8?}, {0x40035e8c01?, 0x40050f1cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40018e1e00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40018e1e00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40018e1e00, {0x30150e0, 0x400013f8d8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400319a090, {0x4003e63400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40028391d0, 0x0, {0x3e02238, 0x40012d7e40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018fcb80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004410e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 854
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5980 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042da180, 0x400246aea0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042da180, 0x400440ce40?, 0x400440cde0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 636 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff525dc1d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x29?, 0x0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4001bafe00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4001bafe00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40005ecd80)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40005ecd80)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
github.com/cilium/dns.(*Server).serveTCP(0x4002618800, {0x3e0bbf0, 0x40005ecd80})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0xe4
github.com/cilium/dns.(*Server).ActivateAndServe(0x4002618800)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x208
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4002618800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 953 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x120
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 952
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 635 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003e63c0, {{{0x37ce973, 0x19}}, {0x0, 0x0}, 0x4000c79c30, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 690 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400187a398, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400187a388)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400187a370, 0x40016109c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400253b040)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002505ec0, {0x3ddab40, 0x4000c68690}, 0x1, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002505ec0, 0x3b9aca00, 0x0, 0x1, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400253b040, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40007cec80, 0x400148f6e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 691 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 397
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 631 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0x4000bf5180)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0xd4
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x5c

goroutine 3754 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3703
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 432 [IO wait, 8 minutes]:
internal/poll.runtime_pollWait(0xffff525dc6b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40025548a0?, 0x40028fde2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40025548a0, {0x40028fde2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000d3cae0, {0x40028fde2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4001393dc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 641 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0x4001393e00)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xa4
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x20c

goroutine 1489 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400022db00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1365
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 642 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e726e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1518 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0x4002438660, 0x0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x4ec
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1363
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x210

goroutine 644 [chan receive, 10 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c220, {0x3e237f0, 0x40023a9920}, 0x4001d63d98, {0x3e2b960?, 0x4001ed2a20}, {{{0x400194e180, 0x1, 0x1}}, 0x400185a720, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 672 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0x4000bf5180, 0x40011a5d20, 0x4000c92450)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x160

goroutine 645 [chan receive, 10 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c1e0, {0x3e237f0, 0x40023a9980}, 0x4001d63df8, {0x3e2b960?, 0x4001ed2a20}, {{{0x400194e180, 0x1, 0x1}}, 0x400185a720, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 651 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40013d63c0?, 0x7a2bb0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001d0af00?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 10257 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:117 +0x68
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn in goroutine 10240
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:116 +0xb4

goroutine 648 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x4001ed2e40, {0x3e237f0, 0x40023a9ec0}, {0x3e2b960, 0x4002555140})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x3c4
github.com/cilium/hive/job.(*jobOneShot).start(0x4001ed2ea0, {0x3e237f0, 0x40023a9ec0}, 0x4001d63a40?, {0x3e2b960, 0x4001b754a0}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 646 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001ed2d20, {0x3e237f0, 0x40023a99e0}, 0x4001b2f260?, {0x3e2b960, 0x4001ed2a20}, {{{0x400194e180, 0x1, 0x1}}, 0x400185a720, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1480 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40011367e0, 0x40031d4780, 0x4001ee51a0, 0x40005e98c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 674 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020f0120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 675 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020f02a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 676 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400004a490, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400004a480)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020f0120)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ae40, {0x3e23828, 0x4000114e60}, 0x4000db6fc0, {0x3e3b410, 0x40005e57e8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 677 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 678 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0x9c
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1d4

goroutine 1433 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 5239 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042dac00, 0x40011e0240, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042dac00, 0x2c87f00?, 0x40019e1870?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 854
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 681 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002530868, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530858)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002530840, 0x400004a780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556be0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002ca3ec0, {0x3ddab40, 0x40004553b0}, 0x1, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40021e0ec0, 0x3b9aca00, 0x0, 0x1, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556be0, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005ed700, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 398
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 682 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 398
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 954 [select]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0x40021dd340)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x1d4
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 850
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x68

goroutine 1599 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40030a99a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1519
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 685 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002530918, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530908)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40025308f0, 0x400004a7c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002609ec0, {0x3ddab40, 0x4000c698c0}, 0x1, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002609ec0, 0x3b9aca00, 0x0, 0x1, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556c80, 0x400148fc80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005ed720, 0x400148fc80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 400
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 686 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 400
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 3630 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400314a780, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000c987e0, 0x1, 0x4000c987f0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 688 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020f0780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 705 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020f0900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 706 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400004aa50, 0x22)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400004aa40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020f0780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40001151d0}, 0x4000db7260, {0x3e3b258, 0x40005e5728})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 707 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 708 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xac
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1fc

goroutine 709 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0x4000972ea0, {0x3e23828, 0x40007786e0}, 0x40011a5d10)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x2bc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x2ec

goroutine 710 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0x400017a6c0, {0x3e23828, 0x40007786e0}, 0x40011a5d10)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x220
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x118

goroutine 1415 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1409
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 712 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x100
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 710
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x1d8

goroutine 713 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4000db7860)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 710
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 715 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 679
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xcc

goroutine 1437 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002471368, 0xce)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002471358)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002471340, 0x400002b900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe2140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001b8fec0, {0x3ddab40, 0x4002382390}, 0x1, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001b8fec0, 0x3b9aca00, 0x0, 0x1, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe2140, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40019fac80, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 418
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 849 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002470ff8, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002470fe8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002470fd0, 0x40010ebac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40018dfa40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4004127e00, {0x3ddab40, 0x4000d1a9c0}, 0x1, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400298fe00, 0x3b9aca00, 0x0, 0x1, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40018dfa40, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x4001b492c0, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0xa8
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x4000d1a540, {0x40019669a0?, 0x0?}, {0x3e148d0, 0x40021dd3f8}, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x480
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 842
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 719 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 681
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1392 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400249d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 721 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 681
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 722 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400170cb40}, {0xffff52204428, 0x4002530840}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001cbd420, {0x0?, 0x0?}, 0x4000db7bc0, 0x400212b5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001cbd420, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029d9f40, {0x3ddab60, 0x4000376aa0}, 0x1, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001cbd420, 0x4000db7bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 681
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 808 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001cbd420, 0x4000db7bc0, 0x4002572360, 0x400212b5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 9430 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40042db3c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042db3b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042db3b0, {0x400541c600, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003415cc8?}, {0x400541c600?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x40042db380}, {0x400541c600, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4000f5aac8, {0x40058b3400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40027b8460, 0x0, {0x3e02238, 0x4005564840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001867e80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400170cbc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 702
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1431 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 726 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x130
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 709
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x200

goroutine 727 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x240
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 709
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x274

goroutine 728 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4002542120)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 709
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1391 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 730 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40020f1bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 712
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 731 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400004b210, 0x12)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400004b200)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020f1aa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ab40, {0x3e23828, 0x4000377360}, 0x4002542360, {0x3e3b200, 0x40005e5cc8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 712
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 732 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 712
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 733 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40020f1e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 715
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 734 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002196000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 715
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 735 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400004b710, 0x6b)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400004b700)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40020f1e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4aec0, {0x3e23828, 0x4000377450}, 0x4002542840, {0x3e3b468, 0x40005e5d88})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 715
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 736 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 715
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 837 [select, 10 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x14c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x15c

goroutine 767 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 755
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 755 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002530c88, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530c78)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002530c60, 0x400004b880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556d20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029e1ec0, {0x3ddab40, 0x400045c870}, 0x1, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002960ec0, 0x3b9aca00, 0x0, 0x1, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556d20, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005edbe0, 0x4002543440)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 365
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 756 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 365
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 759 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002530d38, 0x35)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530d28)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002530d10, 0x400004b8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002971ec0, {0x3ddab40, 0x400045d050}, 0x1, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002971ec0, 0x3b9aca00, 0x0, 0x1, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556dc0, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005edc60, 0x4002543c20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 399
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 760 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 399
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 853 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 849
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 779 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 764
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 764 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4002530de8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002530dd8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002530dc0, 0x400004b900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001556e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400297dec0, {0x3ddab40, 0x400045dad0}, 0x1, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400297dec0, 0x3b9aca00, 0x0, 0x1, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001556e60, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40005edce0, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 364
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 765 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 364
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 854 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004410e40}, {0xffff52204428, 0x4002470fd0}, {0x3e672a8, 0x36f6aa0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019677a0, {0x0?, 0x0?}, 0x40022e62a0, 0x4002176cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019677a0, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029ddf40, {0x3ddab60, 0x4000789db0}, 0x1, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019677a0, 0x40022e62a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 849
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 7526 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042db080, 0x40021e9560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042db080, 0x3e237f0?, 0x4000dcdd70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 782
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 769 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 755
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 770 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40051de700}, {0xffff52204428, 0x4002530c60}, {0x3e672a8, 0x36f67e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001cbdce0, {0x0?, 0x0?}, 0x4002543440, 0x400212b320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001cbdce0, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029a5f40, {0x3ddab60, 0x4000377e00}, 0x1, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001cbdce0, 0x4002543440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 755
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 804 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001cbdce0, 0x4002543440, 0x400230d440, 0x400212b320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 770
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 773 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 759
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 814 [select, 10 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x4002184a80)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x174
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 831
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1410

goroutine 775 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 759
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 776 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400146ae80}, {0xffff52204428, 0x4002530d10}, {0x3e672a8, 0x373c000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001966460, {0x0?, 0x0?}, 0x4002543c20, 0x40021f4c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001966460, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029d5f40, {0x3ddab60, 0x40005b6730}, 0x1, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001966460, 0x4002543c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 759
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 819 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001966460, 0x4002543c20, 0x4001ebb2c0, 0x40021f4c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 11592 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12210 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40041a1c80, 0x400486b560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40041a1c80, 0x3e237f0?, 0x4000dcdd70?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 696
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 781 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 782 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40052fe240}, {0xffff52204428, 0x4002530dc0}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019669a0, {0x0?, 0x0?}, 0x4001eba1e0, 0x400212b440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019669a0, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029a1f40, {0x3ddab60, 0x40005b6780}, 0x1, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019669a0, 0x4001eba1e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 806 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019669a0, 0x4001eba1e0, 0x400230dc80, 0x400212b440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 782
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1390 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400002ab90, 0x19a)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400002ab80)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400249cf60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ad40, {0x3e23828, 0x4001ea7c70}, 0x40026017a0, {0x3e3b360, 0x40010950c8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1668 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff5220c368, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40030e5f00?, 0x40023a0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40030e5f00, {0x40023a0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40030e5f00, {0x40023a0000?, 0x1?, 0x40021381c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000845830, {0x40023a0000?, 0xc?, 0x40021e4d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40010a45a0, {0x40023a0000?, 0x18550?, 0x40026a7a40?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002176960)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002176960, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40010a45a0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1667
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1673 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x400209c400)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xe0
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x5c
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 1518
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1d8

goroutine 1511 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40030a8dc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1510 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004dd040, {{{0x37a4a9e, 0xf}}, {0x0, 0x0}, 0x40023a93e0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1628 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ca9900, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40020a8300}, 0x40004e8e70, 0x0, 0x4000d8a270, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1627 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x6e45120101000100?, 0x4000d1f600?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x3e23828?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1639 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000963c70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002112500, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001a1b9c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1637 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000fe3040)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 9429 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40042db9c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042db9b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042db9b0, {0x400541c5cc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40021e1cc8?}, {0x400541c5cc?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x40042db980}, {0x400541c5cc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4000f5aa98, {0x40058b3000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40027b8370, 0x0, {0x3e02238, 0x4005564800})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001867e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400170cb40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 810 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000571180, {{{0x37be248, 0x15}}, {0x0, 0x0}, 0x40001f7c60, 0x0, 0x39b9348, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 708
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 6564 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042da480, 0x4001c186c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042da480, 0x400280a360?, 0x400280a300?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 770
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 9428 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042db980, 0x40057ff200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042db980, 0x8a6d4?, 0x400107e3c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 6068 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c22c00, 0x4000d82120, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c22c00, 0x8a6d4?, 0x400107e4c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 815 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff525dcb88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002522b80?, 0x40029e4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002522b80, {0x40029e4000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002522b80, {0x40029e4000?, 0x4003ab5a40?, 0x800010601?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001221d20, {0x40029e4000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
bufio.(*Reader).Read(0x40021f5b60, {0x4001967460, 0x9, 0x4000aeb110?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40021f5b60}, {0x4001967460, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001967460, 0x9, 0x40052951d0?}, {0x3dcc0a0?, 0x40021f5b60?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001967420)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x4002184a80, {0x3e237f0, 0x4000ca61e0}, 0x4000ca6210)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x11c
google.golang.org/grpc.(*Server).serveStreams(0x4000a5b400, {0x3e23698?, 0x680cae0?}, {0x3e42860, 0x4002184a80}, {0x3e3a840?, 0x4001221d20?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x300
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x5c
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 831
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d4

goroutine 833 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x40009634f0, {0x4000ca6520, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40009634f0, {0x4000ca6520?, 0x4001a61ce0?, 0x40029d7510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4000ca6390, {0x4000ca6520?, 0x40029d7598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4000ca6390}, {0x4000ca6520, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000daf440, {0x4000ca6520, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4000ca6510, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4000ca6510, 0x4000daf440, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40029d77c8?, {0xffff5220d928, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400452f040}, 0x40007fe380?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4000e3e960, {0x35bf9e0, 0x400452f040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0x40004574f0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x40004cf880?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 816
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1592 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40026a5e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1516 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1363
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1366 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x4001ed31a0, {0x3e237f0, 0x400199f800}, 0x0?, {0x3e2b960, 0x4001ed2f60}, {{{0x40012f7040, 0x1, 0x1}}, 0x40018731d0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 3653 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd0a0, {0x3e23828, 0x400315b0e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3630
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1368 [IO wait]:
internal/poll.runtime_pollWait(0xffff525dc5b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x18?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4003186700)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4003186700)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40033afdb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x400199f8f0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x40022e0000, {0x3e0bc20, 0x400199f8f0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3e0bc20?, 0x400199f8f0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x70
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x418

goroutine 1740 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220b5d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x49?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029d3080)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029d3080)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4000aaddb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4002d8b3e0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x4002d880f0, {0x3e0bc20, 0x4002d8b3e0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3e0bc20?, 0x4002d8b3e0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x70
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1675
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x3f0

goroutine 1372 [select, 10 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x3e23a20, 0x4000031560}, {0x3dd0840, 0x40016107c0}, {0x3e2b960, 0x40017e0fc0}, 0x4001b5fab0, {0x3e5d2a0, 0x400248ccb0}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x688
github.com/cilium/hive/job.(*jobOneShot).start(0x40017e1080, {0x3e237f0, 0x400199fd70}, 0x0?, {0x3e2b960, 0x40017e0fc0}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1371 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40032d8f00, {{{0x37b8e08, 0x14}}, {0x3e2b960, 0x400327f7a0}, 0x400257ea50, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1373 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x40017e1140, {0x3e237f0, 0x400199fe30}, 0x0?, {0x3e2b960, 0x40017e10e0}, {{{0x4000031de0, 0x1, 0x1}}, 0x4000c8e0f0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1375 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1384 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400249c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1374 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e711c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1393 [select, 1 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x248
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x7c

goroutine 1397 [select, 6 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0x400253a640, {0x3e237f0, 0x40026285d0})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0x8c
github.com/cilium/hive/job.(*jobTimer).start(0x400327f8c0, {0x3e237f0, 0x40026285d0}, 0x0?, {0x3e2b960, 0x40017e1500}, {{{0x0, 0x0, 0x0}}, 0x40004b8060, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x34c
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1432 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x40024712b8, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40024712a8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002471290, 0x400002b8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe20a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001619ec0, {0x3ddab40, 0x40023827e0}, 0x1, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001619ec0, 0x3b9aca00, 0x0, 0x1, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe20a0, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40019fac00, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 417
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1416 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40009e1d00}, {0xffff52204428, 0x400187a580}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001966000, {0x0?, 0x0?}, 0x40026c78c0, 0x40026cbe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001966000, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002cabf40, {0x3ddab60, 0x40026c8410}, 0x1, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001966000, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1409
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1405 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x40026c83c0, {0x3e237f0, 0x4002628f60}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x414
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x4000fa8a40, {0x3e237f0, 0x4002628f60}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x74
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x3e237f0, 0x4002628f60}, {{{}}, 0x4001b5fab0, {0x3e5d368, 0x4001b5fb20}, {0x3e24e30, 0x40025462d0}, 0x4001154bd0}, 0x4001122380)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:85 +0x244
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x3e237f0?, 0x4002628f60?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x40
github.com/cilium/hive/job.(*jobOneShot).start(0x4002541020, {0x3e237f0, 0x4002628f60}, 0x0?, {0x3e2b960, 0x4002540fc0}, {{{0x40005d3ca0, 0x1, 0x1}}, 0x40001f6c10, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1419 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1437
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1396 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1387 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 5686 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40042da7c8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042da7b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042da7b0, {0x4005f3cf2c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400339acc8?}, {0x4005f3cf2c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x40042da780}, {0x4005f3cf2c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400167a5a0, {0x4003a49c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002dde1e0, 0x0, {0x3e02238, 0x4005437240})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40008ac360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40043c74c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 3722 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400358e960, {0x400375fc90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400358e960, {0x400375fc90?, 0x4003283d10?, 0x40025d7930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400375fc50, {0x400375fc90?, 0x40025d79b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400375fc50}, {0x400375fc90, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001b2de60, {0x400375fc90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400375fc80, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400375fc80, 0x4001b2de60, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001b2de60?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000d1c940}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002c7f380, {0x3612420, 0x4000d1c940}, 0x4000d1df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40025d7d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001b2dc20, 0x40025d7e10, 0x40025d7e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001b2dc20, {0x3612420?, 0x4000d1c940?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40034df398, {0x3612420, 0x4000d1c940})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000d872e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ac48c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3699
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 1404 [select]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x4002523c00, {0x3e237f0, 0x4002628ea0}, {0x3e0e5f0, 0x4002629b30}, 0x400262b320)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x204
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x4002523c00, {0x3e237f0, 0x4002628ea0}, {0x671a1027?, 0x4002e93d68?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x2d0
github.com/cilium/hive/job.(*jobOneShot).start(0x40025406c0, {0x3e237f0, 0x4002628ea0}, 0x0?, {0x3e2b960, 0x4002540660}, {{{0x40005d2220, 0x1, 0x1}}, 0x4000cab880, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1594 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1366
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1412 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1405
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1389 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400249d8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1385 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400249cc60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1393
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1438 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 418
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1427 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1426 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x400002afd0, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400002afc0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400249d980)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4acc0, {0x3e23828, 0x4001ea7d60}, 0x4002601860, {0x3e3b308, 0x4001095170})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1450 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1442
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1403 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x40025403c0, {0x3e237f0, 0x4002628c90}, 0x0?, {0x3e2b960, 0x4002540360}, {{{0x0, 0x0, 0x0}}, 0x4000caa760, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1731 [select]:
net/http.(*persistConn).writeLoop(0x400118fe60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1712
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1443 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 419
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1401 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4002540300, {0x3e237f0, 0x4002628a20}, 0x0?, {0x3e2b960, 0x4002540240}, {{{0x4000210ca0, 0x1, 0x1}}, 0x4000ca3650, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1442 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4002471418, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002471408)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40024713f0, 0x400002b940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe21e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001b8bec0, {0x3ddab40, 0x40026c3d70}, 0x1, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001b8bec0, 0x3b9aca00, 0x0, 0x1, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe21e0, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40019face0, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 419
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1456 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1447
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1448 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 420
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1447 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x40024714c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40024714b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40024714a0, 0x400002ba00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000fe2280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001bc7ec0, {0x3ddab40, 0x400249e210}, 0x1, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001bc7ec0, 0x3b9aca00, 0x0, 0x1, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000fe2280, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40019fad80, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 420
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 3641 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031988c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ca2ac0, 0x1, 0x4000ca2ad0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1402 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40032d9040, {{{0x378dd05, 0xa}}, {0x0, 0x0}, 0x4001ac3630, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1386 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x400002a650, 0x22)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400002a640)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400249c840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4adc0, {0x3e23828, 0x4001ea7b30}, 0x40026016e0, {0x3e3b3b8, 0x4001095020})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1393
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1407 [syscall, 10 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x30
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x1c
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x28

goroutine 1591 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40026a5d40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1409 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400187a5a8, 0x15)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400187a598)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400187a580, 0x4000fa8800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40030a86e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d87ec0, {0x3ddab40, 0x4002629f20}, 0x1, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001613ec0, 0x3b9aca00, 0x0, 0x1, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40030a86e0, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018ac9a0, 0x40026c78c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1367
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1410 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1367
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1515 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004dd680, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x400080c710, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1462 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001966000, 0x40026c78c0, 0x4000117500, 0x40026cbe60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1416
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 5012 [select]:
net/http.(*persistConn).writeLoop(0x400395e480)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5009
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1724 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002d17b80, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003145c80}, 0x400185b8f0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1640
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1522 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1421 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1437
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1422 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40011c9800}, {0xffff52204428, 0x4002471340}, {0x3e672a8, 0x370c0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019667e0, {0x0?, 0x0?}, 0x40026c7f20, 0x400022cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019667e0, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002cc7f40, {0x3ddab60, 0x40026c8690}, 0x1, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019667e0, 0x40026c7f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1437
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 10840 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c23500, 0x4003898900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c23500, 0x4002fb3500?, 0x4002fb34a0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1453
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1452 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1442
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1467 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019667e0, 0x40026c7f20, 0x4000b48b40, 0x400022cd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1422
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1453 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004a355c0}, {0xffff52204428, 0x40024713f0}, {0x3e672a8, 0x3703740}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40011376c0, {0x0?, 0x0?}, 0x4001a36c00, 0x40005e9bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40011376c0, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c59f40, {0x3ddab60, 0x40021eaf00}, 0x1, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40011376c0, 0x4001a36c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1442
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1484 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40011376c0, 0x4001a36c00, 0x4001ee5e60, 0x40005e9bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1453
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 10841 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003c23548, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c23538)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c23530, {0x4003d80601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001cf9cc8?}, {0x4003d80601?, 0x4001cf9cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002944140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002944140)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002944140, {0x30150e0, 0x400167bb48})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400375ef60, {0x4003c86800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40031af2c0, 0x0, {0x3e02238, 0x4005689580})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000dc12a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004a355c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1453
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5685 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40042da780, 0x4001071320, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40042da780, 0x8a6d4?, 0x40013f8540?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 4858 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c22000, 0x40037a99e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c22000, 0x8a6d4?, 0x4000fa9840?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1416
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1458 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1447
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1459 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004388740}, {0xffff52204428, 0x40024714a0}, {0x3e672a8, 0x36f2b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001137b20, {0x0?, 0x0?}, 0x4001a370e0, 0x40005e9b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001137b20, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bbff40, {0x3ddab60, 0x40021eaff0}, 0x1, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001137b20, 0x4001a370e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1447
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1482 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001137b20, 0x4001a370e0, 0x4001ee56e0, 0x40005e9b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1459
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1474 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1432
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1519 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004dda40, {{{0x3799d7a, 0xd}}, {0x0, 0x0}, 0x4000c95dd0, 0x0, 0x4000e434e8, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1476 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1477 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40019acd80}, {0xffff52204428, 0x4002471290}, {0x3e672a8, 0x3722640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001966fc0, {0x0?, 0x0?}, 0x4001ee4960, 0x400022cc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001966fc0, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002c57f40, {0x3ddab60, 0x40026c8870}, 0x1, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001966fc0, 0x4001ee4960)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1464 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001966fc0, 0x4001ee4960, 0x4000b486c0, 0x400022cc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1477
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 5073 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003c22648, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c22638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c22630, {0x4002413201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40050e7cc8?}, {0x4002413201?, 0x40050e7cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003ef48c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003ef48c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003ef48c0, {0x30150e0, 0x400078af60})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4004382e70, {0x4003d62800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40041fda40, 0x0, {0x3e02238, 0x4001158640})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001875dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004388740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1459
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 7316 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003c227c8, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c227b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c227b0, {0x40050c404c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001cdccc8?}, {0x40050c404c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x4003c22780}, {0x40050c404c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4000fca3a8, {0x400396fc00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002cd1ea0, 0x0, {0x3e02238, 0x4004979480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40019f5b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40019acd80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1477
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5472 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff52163c98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002424200?, 0x4000a61000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002424200, {0x4000a61000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002424200, {0x4000a61000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001576e50, {0x4000a61000?, 0x72?, 0x4000e389c8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000e389c0, {0x4000a61000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400262a5a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400262a5a0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400215b200, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5072 [select, 6 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c22600, 0x400395fb00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c22600, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1459
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 7315 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c22780, 0x4000e370e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c22780, 0x8a6d4?, 0x40013f8940?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1477
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 5483 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003c22180, 0x4000f88120, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003c22180, 0x40043b7a00?, 0x4001e5afe8?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1422
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1490 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400022dc20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1365
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1491 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40013f8b50, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40013f8b40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400022db00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x40021eba40}, 0x4000b49560, {0x3e3b570, 0x4001094330})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1365
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1492 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1365
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 3735 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220b9b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d33400?, 0x40020ae300?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d33400, {0x40020ae300, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d33400, {0x40020ae300?, 0xffff521490f8?, 0x40039c7518?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008456d8, {0x40020ae300?, 0x4001d5e928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c7518, {0x40020ae300?, 0x0?, 0x40039c7518?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40031717b0, {0x3dd1940, 0x40039c7518})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003171508, {0x3dcbd80, 0x40008456d8}, 0x4001d5ea00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003171508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003171508, {0x40034c6000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400342df20, {0x4000e25e00, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400342df20}, {0x4000e25e00, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e25e00, 0x9, 0x8f497e907b?}, {0x3dcc0a0?, 0x400342df20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e25dc0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4001bdbd48, 0x40034d0000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3663
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 1524 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1525 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1526 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1527 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1528 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1529 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1530 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1531 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1532 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1533 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1534 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1535 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1536 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1537 [IO wait]:
internal/poll.runtime_pollWait(0xffff525dc8a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x31?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40000dd680)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40000dd680)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4000781a60)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4000781a60)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x40022e11d0, {0x3e0bbf0, 0x4000781a60})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0x4000faa230, 0xe}, {0x3e0bbf0, 0x4000781a60})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xa0
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1363
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x560

goroutine 1538 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004ddb80, {{{0x37bdc75, 0x15}}, {0x0, 0x0}, 0x40023d6e40, 0x0, 0x39b9348, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1598 [syscall, 10 minutes]:
syscall.Syscall6(0x5f, 0x1, 0x19b, 0x40033a8ca8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
os.(*Process).blockUntilWaitable(0x4000ed00f0)
	/usr/local/go/src/os/wait_waitid.go:32 +0x6c
os.(*Process).wait(0x4000ed00f0)
	/usr/local/go/src/os/exec_unix.go:22 +0x2c
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0x40032f5b00)
	/usr/local/go/src/os/exec/exec.go:901 +0x38
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 1597
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x3bc

goroutine 1540 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40004ddcc0, {{{0x37c1af7, 0x16}}, {0x3e2b960, 0x4001b754a0}, 0x4000795500, 0x0, 0x39b9348, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1679 [IO wait, 4 minutes]:
internal/poll.runtime_pollWait(0xffff5220b8c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x46?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002398c00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002398c00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40005ed9c0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40005ed9c0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x40022e0ff0, {0x3e0bbf0, 0x40005ed9c0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
net/http.(*Server).ListenAndServe(0x40022e0ff0)
	/usr/local/go/src/net/http/server.go:3189 +0x84
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x28
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1674
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x58

goroutine 1675 [semacquire, 10 minutes]:
sync.runtime_Semacquire(0x4000c281c0?)
	/usr/local/go/src/runtime/sema.go:62 +0x2c
sync.(*WaitGroup).Wait(0x400209c540)
	/usr/local/go/src/sync/waitgroup.go:116 +0x74
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x400209c400)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0xa8
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x400209c400)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x100
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x28
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1673
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xd0

goroutine 1650 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001c79cc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40021f4b40}, 0x40004ff420, 0x0, 0x4000e11920, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3677 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d18980, {0x3e23828, 0x400328b680})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3643
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 10170 [select, 1 minutes]:
reflect.rselect({0x40043c0000, 0x9, 0xffff523c8f98?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x40042c3c00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4002382ff0, {0x3e237f0, 0x4003e7aa80}, 0x4000317d50, {0xffff520d2bc0, 0x4001a93290}, 0x400317bf20, {0x381b81a?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4002382ff0, {0x3e237f0, 0x4003e7aa80}, {0xffff520d2bc0, 0x4001a93290}, {0x381b81a, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0x4002382ff0, {0x3e3e378, 0x4001a93290})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:144 +0x78
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x365dfc0?, 0x4002382ff0}, {0x3e32818, 0x4003dfd1d0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1711 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4000a5b400, {0x3e237f0, 0x4003e7a990}, {0x3e42860, 0x4002184a80}, 0x4003951560, 0x4002383350, 0x6217f00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4000a5b400, {0x3e42860, 0x4002184a80}, 0x4003951560)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 815
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1674 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x4000e434a0)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xd4
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x2c
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1673
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x80

goroutine 1669 [select, 10 minutes]:
net/http.(*persistConn).writeLoop(0x40010a45a0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1667
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3707 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc28b0, {0x3e23828, 0x40032c6550})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3641
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3749 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ac48c0, {0x3e3fa98, 0x4000d872e0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3722
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 1664 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400223cf00, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40019f7890, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1519
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3676 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d18930, {0x3e23828, 0x400328b630})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3643
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1662 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1519
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1642 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002113b80, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002265e60}, 0x40018ae4e0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1513
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3836 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40011e1e60)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3662
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 1656 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400223c000, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40019f6d90, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1651
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3752 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400358f220, {0x40037bca30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400358f220, {0x40037bca30?, 0x4003283e90?, 0x400294f930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40037bc9f0, {0x40037bca30?, 0x400294f9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40037bc9f0}, {0x40037bca30, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400231f560, {0x40037bca30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40037bca20, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40037bca20, 0x400231f560, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400231f560?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000d1c8c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002c7f790, {0x3612420, 0x4000d1c8c0}, 0x4000d1df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400294fd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40023157a0, 0x400294fe10, 0x400294fe58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40023157a0, {0x3612420?, 0x4000d1c8c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40034df710, {0x3612420, 0x4000d1c8c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000d87950)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400253b9a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3703
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 1661 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40007cddb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400223cb40, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40019f7510, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1519
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1738 [select]:
github.com/servak/go-fastping.(*Pinger).run(0x4000e5c510, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x494
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1675
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x1b0

goroutine 3738 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002404488)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3671
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1651 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001c79e00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40007cce10, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1634
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3740 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002404908)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3701
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1613 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001c783c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001b4cdd0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1763 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002df7680, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40032455c0}, 0x4001872db0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1662
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3731 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220b4e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d33180?, 0x40020ad500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d33180, {0x40020ad500, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d33180, {0x40020ad500?, 0xffff521490f8?, 0x40039c7968?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008456c8, {0x40020ad500?, 0x4001d5f928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c7968, {0x40020ad500?, 0x0?, 0x40039c7968?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003171430, {0x3dd1940, 0x40039c7968})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003171188, {0x3dcbd80, 0x40008456c8}, 0x4001d5fa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003171188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003171188, {0x40034a0000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40032ec6c0, {0x4000e257e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40032ec6c0}, {0x4000e257e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e257e0, 0x9, 0x8f4a390834?}, {0x3dcc0a0?, 0x40032ec6c0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e257a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4001bdb448, 0x40032ec720)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3657
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3756 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4002229200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3704
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3769 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000de05a0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3682
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3733 [IO wait]:
internal/poll.runtime_pollWait(0xffff52272ca0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d33680?, 0x40020adc00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d33680, {0x40020adc00, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d33680, {0x40020adc00?, 0xffff521490f8?, 0x40039c74e8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d3c140, {0x40020adc00?, 0x4002469928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c74e8, {0x40020adc00?, 0x0?, 0x40039c74e8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4002dd7b30, {0x3dd1940, 0x40039c74e8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4002dd7888, {0x3dcbd80, 0x4000d3c140}, 0x4002469a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4002dd7888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4002dd7888, {0x40034b2000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400342c360, {0x4000e259a0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400342c360}, {0x4000e259a0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e259a0, 0x9, 0x8f497d79ee?}, {0x3dcc0a0?, 0x400342c360?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e25960)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4001bdb8c8, 0x400342c3c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3713
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3629 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1586 [select, 8 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x110
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1581
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x200

goroutine 1572 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1539
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1573 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000571400, {{{0x378d189, 0xa}}, {0x0, 0x0}, 0x39b9e78, 0x0, 0x39b9348, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1539
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1574 [select]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x40005de240, {0x3e23828, 0x40007786e0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xec
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x20f0

goroutine 1575 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x4000571680)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x78
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x216c

goroutine 1576 [syscall]:
syscall.Syscall6(0x16, 0x39, 0x4001c4a440, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x4000074001?, {0x4001c4a440?, 0x4002ca5918?, 0x1ea7078?}, 0x3ddd880?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x4000c774e0, {0x4001c4a440, 0x2, 0x2}, {0x74?, 0x74?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4001676fc0, 0x4002ca5af0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x400248cb60, {0x3e23828, 0x4000768c30})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x404
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1539
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd4

goroutine 1577 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff5220c270, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x34?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40022d9900)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40022d9900)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4002ca1b28?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40005de690)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4000c0a600, {0x3e0bc20, 0x40005de690})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4c
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x2fc8

goroutine 1578 [chan receive, 10 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x3028

goroutine 1579 [IO wait, 8 minutes]:
internal/poll.runtime_pollWait(0xffff525dbfe8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40026a1d40?, 0x400278fe2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40026a1d40, {0x400278fe2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000844ff0, {0x400278fe2b?, 0x0?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40014ff9c0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1539
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1580 [select, 8 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x40005df830)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0x90
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1539
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1f8

goroutine 1588 [chan receive, 10 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x3adc

goroutine 1587 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff5220c178, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x3e?, 0x40008c7520?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002302100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002302100)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x400086b2e0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x400086b2e0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4000c0ae00, {0x3e0bbf0, 0x400086b2e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x54
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1539
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x3a7c

goroutine 3648 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1739 [select]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x80
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1675
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x68

goroutine 3721 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ac48c0, {0x3e23828, 0x40033fa0f0}, 0x3ba092bdd24d818a, 0x40033f2180)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3699
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3538 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000fe3720)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3531
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1715 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220b6d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d08700?, 0x4002402e00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0x4002d08700, {0x4002402e00, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x214
net.(*netFD).readFrom(0x4002d08700, {0x4002402e00?, 0x72?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x28
net.(*IPConn).readFrom(0x4002d08700?, {0x4002402e00, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0x400149b908, {0x4002402e00?, 0x4002465ea8?, 0x4002465e70?})
	/usr/local/go/src/net/iprawsock.go:129 +0x2c
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1bea281c51fdc58?, {0x4002402e00?, 0x6279580?, 0x6279580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x34
github.com/servak/go-fastping.(*Pinger).recvICMP(0x4000e5c510, 0x40019f48c0, 0x4002ef0480, 0x40019f48e0, 0x4000c96930)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x114
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1738
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x2d8

goroutine 3704 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3643
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3548 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002980780, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40005d57a0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3543
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3743 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c6c80, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044c070)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3657
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1758 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002df6780, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40032b93e0}, 0x4001864410, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1627
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3669 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007855a0, {0x3e23828, 0x400328b0e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3647
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3645 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198c80, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ca3810, 0x1, 0x4000ca3820, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3642 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3543 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002980640, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40028cea50, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3531
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3809 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40022287e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3697
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3748 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3722
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3706 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc2880, {0x3e23828, 0x40032c6500})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3641
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3751 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400253b9a0, {0x3e23828, 0x400358ed20}, 0x3ba092bdd24d8194, 0x40034f3b60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3703
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3697 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3647
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3639 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198780, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ca2620, 0x1, 0x4000ca2630, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3541 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40002e9401?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001865140?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3531
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3726 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40011e18c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3700
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3540 [select, 8 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40028ce910})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40029803c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40005d5140, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3531
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3650 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdc510, {0x3e23828, 0x400315af00})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3628
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3632 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdc4b0, {0x3e23828, 0x400315ae60})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3628
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3655 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd7a0, {0x3e23828, 0x400315b220})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3639
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3631 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3670 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007855d0, {0x3e23828, 0x400328b130})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3647
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3649 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdc4e0, {0x3e23828, 0x400315aeb0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3628
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3822 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40004c3440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3674
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3747 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c7400, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044d3b0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3678
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3640 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3647 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198dc0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ca3dd0, 0x1, 0x4000ca3de0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3668 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000785560, {0x3e23828, 0x400328b090})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3647
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3665 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007848b0, {0x3e23828, 0x400328aeb0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3645
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3674 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3645
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3666 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007848e0, {0x3e23828, 0x400328af00})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3645
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1993 [select, 10 minutes]:
reflect.rselect({0x4001071440, 0x9, 0xffff523e6788?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x400262ea00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4002382ff0, {0x3e237f0, 0x400190e750}, 0x40004e9730, {0xffff520fa318, 0x400157e030}, 0x4002939aa0, {0x3852034?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4002382ff0, {0x3e237f0, 0x400190e750}, {0xffff520fa318, 0x400157e030}, {0x3852034, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0x4002382ff0, {0x3e3e6a0, 0x400157e030})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x78
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x365dfc0?, 0x4002382ff0}, {0x3e32818, 0x4000e3e690})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4000a5b400, {0x3e237f0, 0x400190e600}, {0x3e42860, 0x4002184a80}, 0x400106c360, 0x40023831a0, 0x6238200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4000a5b400, {0x3e42860, 0x4002184a80}, 0x400106c360)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 815
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1994 [select, 10 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x400280d0e0, {0x400190e700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400280d0e0, {0x400190e700?, 0x4002810210?, 0x4002c5b510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400190e570, {0x400190e700?, 0x4002c5b598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400190e570}, {0x400190e700, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400106c360, {0x400190e700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400190e6f0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400190e6f0, 0x400106c360, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002c5b7c8?, {0xffff5220d928, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40030a9900}, 0x4003821340?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4000e3e690, {0x35bf9e0, 0x40030a9900})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0x400157e030)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x40018bfd70?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1993
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 3651 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd000, {0x3e23828, 0x400315b040})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3630
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3744 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c7130, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044c1c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3663
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3700 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3628
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3542 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002980500, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002982300}, 0x400059a700, 0x0, 0x4002d8bc80, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3531
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3755 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002dabc80, 0x40037bc2d0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3703
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3737 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220bd98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002dabd00?, 0x40020af100?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002dabd00, {0x40020af100, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002dabd00, {0x40020af100?, 0xffff521490f8?, 0x40039c7500?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008456f8, {0x40020af100?, 0x4002d39928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c7500, {0x40020af100?, 0x0?, 0x40039c7500?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003171eb0, {0x3dd1940, 0x40039c7500})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003171c08, {0x3dcbd80, 0x40008456f8}, 0x4002d39a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003171c08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003171c08, {0x4003500000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40034d1c20, {0x4000c1c9e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40034d1c20}, {0x4000c1c9e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000c1c9e0, 0x9, 0x8f497d73a6?}, {0x3dcc0a0?, 0x40034d1c20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000c1c9a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002404008, 0x40034d1c80)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3678
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 1975 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4001393610, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001393600)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40013935c0, {0x3e23828, 0x40026c5090}, {0x40014a52c0, 0x33}, 0x1, {0x400186e2e5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1993
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 3736 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002404008)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3678
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3730 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4001bdb448)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3657
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3628 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400314a640, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000c98320, 0x1, 0x4000c98330, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3643 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198b40, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000ca33b0, 0x1, 0x4000ca33c0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3682 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3639
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3654 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd770, {0x3e23828, 0x400315b1d0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3639
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3797 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4000de1680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3717
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3646 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3662 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3630
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3753 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400253b9a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3703
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2283 [select]:
net/http.(*persistConn).writeLoop(0x4001139e60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 2280
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 2282 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220bab0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002dabe80?, 0x4002eda000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002dabe80, {0x4002eda000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002dabe80, {0x4002eda000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d3c070, {0x4002eda000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001139e60, {0x4002eda000?, 0x40027d3d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002ed6120)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002ed6120, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001139e60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 2280
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3718 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x400240bb08)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3659
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3667 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000784910, {0x3e23828, 0x400328af50})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3645
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3734 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4001bdbd48)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3663
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3745 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c7900, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044cbd0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3701
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3656 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000cdd810, {0x3e23828, 0x400315b270})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3639
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3675 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d18870, {0x3e23828, 0x400328b5e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3643
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3510 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002c22500, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002c424e0}, 0x40019a8ee0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3541
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3746 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c7630, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044d260)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3671
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3739 [IO wait]:
internal/poll.runtime_pollWait(0xffff52272d98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002dab900?, 0x4002ec6c00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002dab900, {0x4002ec6c00, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002dab900, {0x4002ec6c00?, 0xffff52115900?, 0x4003cf89d8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008456e8, {0x4002ec6c00?, 0x40031ed928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003cf89d8, {0x4002ec6c00?, 0x0?, 0x4003cf89d8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003171b30, {0x3dd1940, 0x4003cf89d8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003171888, {0x3dcbd80, 0x40008456e8}, 0x40031eda00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003171888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003171888, {0x400352c000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40034f5860, {0x4000c1d1c0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40034f5860}, {0x4000c1d1c0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000c1d1c0, 0x9, 0x8f482a70d6?}, {0x3dcc0a0?, 0x40034f5860?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000c1d180)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002404488, 0x40034f58c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3671
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3741 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220bba8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002e0e280?, 0x400384b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002e0e280, {0x400384b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002e0e280, {0x400384b000?, 0xffff521490f8?, 0x40039c7938?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d3c130, {0x400384b000?, 0x4001e6c928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c7938, {0x400384b000?, 0x0?, 0x40039c7938?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4002dd77b0, {0x3dd1940, 0x40039c7938})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4002dd7508, {0x3dcbd80, 0x4000d3c130}, 0x4001e6ca00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4002dd7508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4002dd7508, {0x4003540000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400350d560, {0x4000c1d7e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400350d560}, {0x4000c1d7e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000c1d7e0, 0x9, 0x8f4a381cf4?}, {0x3dcc0a0?, 0x400350d560?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000c1d7a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002404908, 0x400350d5c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3701
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3742 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40032c6f00, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40003e3ea0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3713
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3717 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3641
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3719 [IO wait]:
internal/poll.runtime_pollWait(0xffff5220bf88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d33200?, 0x4003800000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d33200, {0x4003800000, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d33200, {0x4003800000?, 0xffff521490f8?, 0x40039c7920?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000845680, {0x4003800000?, 0x40033a3928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039c7920, {0x4003800000?, 0x0?, 0x40039c7920?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40031710b0, {0x3dd1940, 0x40039c7920})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003170e08, {0x3dcbd80, 0x4000845680}, 0x40033a3a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003170e08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003170e08, {0x40033de000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40033b7c20, {0x4001966580, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40033b7c20}, {0x4001966580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001966580, 0x9, 0x8f4a38168b?}, {0x3dcc0a0?, 0x40033b7c20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001966540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x400240bb08, 0x40033b7c80)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3659
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3720 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4003393b30, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400042f1f0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3659
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3723 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ac48c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3699
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3724 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3699
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3725 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002daba80, 0x40036ec2a0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3699
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3727 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e23828, 0x400315acd0}, 0x4001017740)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3700
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3762 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40019b1980?, {0x3e23828, 0x40033faa00}, {0x3e5f080?, 0x40011e18c0?}, 0x4000c98850)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3628
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3855 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003727580, {0x3e23828, 0x40033faa00}, {0xffff5214eea8, 0x40011e18c0}, {0x40035dc6c0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x400371b260, {0x3e23828, 0x40033faa00})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001137180, {0x3e23828, 0x40033faa00}, {0x3e5f080, 0x40011e18c0}, {0x4, {0x1, 0x1, 0xff}}, 0x400373c0c0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3628
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3764 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ac4b40, {0x3e23828, 0x40033fad70}, 0x3ba092bdd24d818c, 0x40033f2ae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3681
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3765 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40033fb450, {0x40039a27c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40033fb450, {0x40039a27c0?, 0x4003395248?, 0x400294b930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a2780, {0x40039a27c0?, 0x400294b9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a2780}, {0x40039a27c0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40022bf0e0, {0x40039a27c0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a27b0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a27b0, 0x40022bf0e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40022bf0e0?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40011e6040}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eec680, {0x3612420, 0x40011e6040}, 0x40011e7f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400294bd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40022bec60, 0x400294be10, 0x400294be58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40022bec60, {0x3612420?, 0x40011e6040?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40033bd938, {0x3612420, 0x40011e6040})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000dd6520)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ac4b40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3681
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3766 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ac4b40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3681
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3767 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3681
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3768 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002d32f00, 0x40036ed5f0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3681
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3770 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e23828, 0x400328aaa0}, 0x4001017c40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3682
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3773 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3774 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ac4b40, {0x3e3fa98, 0x4000dd6520})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3757 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e23828, 0x400328ac30}, 0x40012534c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3704
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3760 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3752
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3793 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400253b9a0, {0x3e3fa98, 0x4000d87950})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3752
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3775 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x1945910?, {0x3e23828, 0x40033fb590}, {0x3e5f080?, 0x4000de05a0?}, 0x4000ca2b50)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3639
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3917 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e23828, 0x4003678dc0}, 0x400166bb40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3778 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ac4e60, {0x3e23828, 0x40033fb9a0}, 0x3ba092bdd24d8192, 0x40033f3680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3716
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3794 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40034f3b00?, {0x3e23828, 0x400358f360}, {0x3e5f080?, 0x4002229200?}, 0x4000ca3960)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3643
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3779 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003678000, {0x40039a3870, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003678000, {0x40039a3870?, 0x40033953e0?, 0x4002999930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a3830, {0x40039a3870?, 0x40029999b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a3830}, {0x40039a3870, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002528ea0, {0x40039a3870, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a3860, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a3860, 0x4002528ea0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002528ea0?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001753f40}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eec9c0, {0x3612420, 0x4001753f40}, 0x4001753f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002999d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40025287e0, 0x4002999e10, 0x4002999e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40025287e0, {0x3612420?, 0x4001753f40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40033bdd28, {0x3612420, 0x4001753f40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000dd6ca0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ac4e60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3716
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3780 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ac4e60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3716
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3781 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3716
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3782 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002d33780, 0x40039a2de0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3716
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3783 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400253b540, {0x3e23828, 0x40033fb9f0}, 0x3ba092bdd24d8190, 0x40033f3800)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3673
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3784 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003678280, {0x40039a3ae0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003678280, {0x40039a3ae0?, 0x40033953f8?, 0x40024fb930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a3aa0, {0x40039a3ae0?, 0x40024fb9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a3aa0}, {0x40039a3ae0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002529440, {0x40039a3ae0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a3ad0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a3ad0, 0x4002529440, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002529440?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001753540}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eeca90, {0x3612420, 0x4001753540}, 0x4001753f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40024fbd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002528fc0, 0x40024fbe10, 0x40024fbe58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002528fc0, {0x3612420?, 0x4001753540?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40033bde18, {0x3612420, 0x4001753540})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000dd6d60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400253b540)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3673
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3785 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400253b540)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3673
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3786 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3673
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3787 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002dab400, 0x40039a3050)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3673
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3788 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400253b7c0, {0x3e23828, 0x40033fba40}, 0x3ba092bdd24d818e, 0x40033f3980)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3680
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3789 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003678500, {0x40039a3d50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003678500, {0x40039a3d50?, 0x4003395410?, 0x4001e91930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039a3d10, {0x40039a3d50?, 0x4001e919b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039a3d10}, {0x40039a3d50, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40025297a0, {0x40039a3d50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039a3d40, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039a3d40, 0x40025297a0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40025297a0?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4001753dc0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eecb60, {0x3612420, 0x4001753dc0}, 0x4001753f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4001e91d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002529560, 0x4001e91e10, 0x4001e91e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002529560, {0x3612420?, 0x4001753dc0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40033bdf50, {0x3612420, 0x4001753dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000dd6e20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400253b7c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3680
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3790 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400253b7c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3680
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3791 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3680
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3792 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002dab880, 0x40039a31d0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3680
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3894 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003798280, {0x3e23828, 0x400358f360}, {0xffff5214eea8, 0x4002229200}, {0x4003790438?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003794660, {0x3e23828, 0x400358f360})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4000e249a0, {0x3e23828, 0x400358f360}, {0x3e5f080, 0x4002229200}, {0x2, {0x1, 0x1, 0xff}}, 0x400378eb40)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3643
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3810 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e23828, 0x400328ad70}, 0x4001762440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3697
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3813 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3779
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3814 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ac4e60, {0x3e3fa98, 0x4000dd6ca0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3779
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3798 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e23828, 0x400328ab40}, 0x4001253a00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3717
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3815 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3784
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3816 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400253b540, {0x3e3fa98, 0x4000dd6d60})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3784
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3817 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3789
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3818 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400253b7c0, {0x3e3fa98, 0x4000dd6e20})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3789
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3819 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003678640}, {0x3e5f080?, 0x40022287e0?}, 0x4000784930)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3647
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3843 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003726200, {0x3e23828, 0x4003678640}, {0xffff5214eea8, 0x40022287e0}, {0x40035dc300?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x400371a900, {0x3e23828, 0x4003678640})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4000e24c40, {0x3e23828, 0x4003678640}, {0x3e5f080, 0x40022287e0}, {0x7, {0x1, 0x1, 0xff}}, 0x400359f320)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3647
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3801 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x3e3ec78?, {0x3e23828, 0x400358fae0}, {0x3e5f080?, 0x4000de1680?}, 0x4000ca3880)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3847 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003726b00, {0x3e23828, 0x400358fae0}, {0xffff5214eea8, 0x4000de1680}, {0x40035dc4c8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x400371ac60, {0x3e23828, 0x400358fae0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4000e248c0, {0x3e23828, 0x400358fae0}, {0x3e5f080, 0x4000de1680}, {0x8, {0x1, 0x1, 0xff}}, 0x400359f800)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3641
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3823 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e23828, 0x400328ac80}, 0x4001763080)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3674
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3826 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003678dc0}, {0x3e5f080?, 0x40004c3440?}, 0x4000ca3e80)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3645
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3916 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40037b6e00, {0x3e23828, 0x4003678dc0}, {0xffff5214eea8, 0x40004c3440}, {0x40037908a0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40037b46c0, {0x3e23828, 0x4003678dc0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4000e24a80, {0x3e23828, 0x4003678dc0}, {0x3e5f080, 0x40004c3440}, {0x3, {0x1, 0x1, 0xff}}, 0x400378fec0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3645
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3830 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3727
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3831 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4002eecf70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3727
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3834 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003679680, {0x4003687570, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003679680, {0x4003687570?, 0x4003395740?, 0x4002d37950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003687530, {0x4003687570?, 0x4002d379d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003687530}, {0x4003687570, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400259a7e0, {0x4003687570, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003687560, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003687560, 0x400259a7e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400259a7e0?, {0xffff5220d928, 0x680cae0}, 0x1?, {0x0?, 0x0?}, {0x368b2c0, 0x400475fe30}, 0x6227c40?, 0xffff52385f10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eed110, {0x368b2c0, 0x400475fe30}, 0x400475ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002d37d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400259a5a0, 0x4002d37e30, 0x4002d37e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400259a5a0, {0x368b2c0?, 0x400475fe30?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003554a68, {0x368b2c0, 0x400475fe30})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000dd7e00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4002eecf70, {0x3e3faf0, 0x4000dd7e00})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3833 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3835 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x400369e2c0, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3803 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ac4a00, {0x3e23828, 0x4003718000}, 0x3ba092bdd24d8196, 0x400359ee40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3661
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3804 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40037181e0, {0x40035de670, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40037181e0, {0x40035de670?, 0x40035dc120?, 0x4002959930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40035de630, {0x40035de670?, 0x40029599b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40035de630}, {0x40035de670, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4002620900, {0x40035de670, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40035de660, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40035de660, 0x4002620900, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002620900?, {0xffff5220d928, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000d1c840}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002c7fd40, {0x3612420, 0x4000d1c840}, 0x4000d1df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002959d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40026205a0, 0x4002959e10, 0x4002959e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40026205a0, {0x3612420?, 0x4000d1c840?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40034dfd28, {0x3612420, 0x4000d1c840})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000dce2f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ac4a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3661
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3805 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ac4a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3661
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3806 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3661
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3807 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4002d32d00, 0x40035de3c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3661
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3837 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e23828, 0x400315ad20}, 0x400130aa00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3662
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3808 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3841 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ac4a00, {0x3e3fa98, 0x4000dce2f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3804
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3840 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40003b0d01?, {0x3e23828, 0x4003679ef0}, {0x3e5f080?, 0x40011e1e60?}, 0x4000cdc530)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3630
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3886 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40036ef100, {0x3e23828, 0x4003679ef0}, {0xffff5214eea8, 0x40011e1e60}, {0x4003790150?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003794000, {0x3e23828, 0x4003679ef0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001137420, {0x3e23828, 0x4003679ef0}, {0x3e5f080, 0x40011e1e60}, {0x6, {0x1, 0x1, 0xff}}, 0x400378e0c0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3630
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3844 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e23828, 0x4003678640}, 0x400133aec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3858 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3810
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3859 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4002eed930)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3810
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3866 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b8500, {0x40036b30f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b8500, {0x40036b30f0?, 0x4003395a28?, 0x400295d950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40036b30b0, {0x40036b30f0?, 0x400295d9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40036b30b0}, {0x40036b30f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40036c6360, {0x40036b30f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40036b30e0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40036b30e0, 0x40036c6360, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40036c6360?, {0xffff5220d928, 0x680cae0}, 0x35dd8a0?, {0x0?, 0x0?}, {0x368b2c0, 0x4004e32000}, 0x400295dc88?, 0x2a200?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4002eedad0, {0x368b2c0, 0x4004e32000}, 0x4004e33f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400295dd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40036c6120, 0x400295de30, 0x400295de78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40036c6120, {0x368b2c0?, 0x4004e32000?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40035554b8, {0x368b2c0, 0x4004e32000})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e1ed10)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4002eed930, {0x3e3faf0, 0x4000e1ed10})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3861 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3862 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3770
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3863 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40036ca000)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3770
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3876 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b8780, {0x40036b3b10, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b8780, {0x40036b3b10?, 0x4003395b60?, 0x40022a2950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40036b3ad0, {0x40036b3b10?, 0x40022a29d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40036b3ad0}, {0x40036b3b10, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40036c6d80, {0x40036b3b10, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40036b3b00, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40036b3b00, 0x40036c6d80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40036c6d80?, {0xffff5220d928, 0x680cae0}, 0x20270?, {0x0?, 0x0?}, {0x368b2c0, 0x400475fb90}, 0x40022a2c68?, 0x1fd48?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40036ca1a0, {0x368b2c0, 0x400475fb90}, 0x400475ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40022a2d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40036c6b40, 0x40022a2e30, 0x40022a2e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40036c6b40, {0x368b2c0?, 0x400475fb90?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003555890, {0x368b2c0, 0x400475fb90})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e1f350)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40036ca000, {0x3e3faf0, 0x4000e1f350})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3865 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3867 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x400369e9a0, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3868 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3798
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3869 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40036ca270)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3798
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3878 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b8960, {0x40036da2e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b8960, {0x40036da2e0?, 0x4003395cc8?, 0x4001e70950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40036da2a0, {0x40036da2e0?, 0x4001e709d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40036da2a0}, {0x40036da2e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40036c77a0, {0x40036da2e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40036da2d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40036da2d0, 0x40036c77a0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40036c77a0?, {0xffff5220d928, 0x680cae0}, 0x8?, {0x0?, 0x0?}, {0x368b2c0, 0x400475fa40}, 0x6811ec0?, 0xffff991dc130?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40036ca410, {0x368b2c0, 0x400475fa40}, 0x400475ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4001e70d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40036c7560, 0x4001e70e30, 0x4001e70e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40036c7560, {0x368b2c0?, 0x400475fa40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003555b00, {0x368b2c0, 0x400475fa40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e0a020)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40036ca270, {0x3e3faf0, 0x4000e0a020})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3871 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3872 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3823
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3873 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40036ca4e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3823
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3880 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b8b40, {0x40036daa00, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b8b40, {0x40036daa00?, 0x4003395e00?, 0x4001e6e950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40036da9c0, {0x40036daa00?, 0x4001e6e9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40036da9c0}, {0x40036daa00, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40036f2120, {0x40036daa00, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40036da9f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40036da9f0, 0x40036f2120, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40036f2120?, {0xffff5220d928, 0x680cae0}, 0x1?, {0x0?, 0x0?}, {0x368b2c0, 0x400475fce0}, 0x6227c40?, 0xffff52385f10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40036ca680, {0x368b2c0, 0x400475fce0}, 0x400475ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4001e6ed98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40036c7e60, 0x4001e6ee30, 0x4001e6ee78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40036c7e60, {0x368b2c0?, 0x400475fce0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003555e48, {0x368b2c0, 0x400475fce0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e0a580)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40036ca4e0, {0x3e3faf0, 0x4000e0a580})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3875 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3877 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x400369ea50, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3879 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x400369eb00, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3881 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x400369ebb0, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3882 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3757
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3883 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40036ca750)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3757
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3898 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b8eb0, {0x40036db990, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b8eb0, {0x40036db990?, 0x4003395fe0?, 0x40027d4950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40036db950, {0x40036db990?, 0x40027d49d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40036db950}, {0x40036db990, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40036f2b40, {0x40036db990, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40036db980, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40036db980, 0x40036f2b40, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40036f2b40?, {0xffff5220d928, 0x680cae0}, 0x63690000000000?, {0x0?, 0x0?}, {0x368b2c0, 0x400475f8f0}, 0x40027d4900?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40036ca8f0, {0x368b2c0, 0x400475f8f0}, 0x400475ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40027d4d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40036f2900, 0x40027d4e30, 0x40027d4e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40036f2900, {0x368b2c0?, 0x400475f8f0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40036b03c0, {0x368b2c0, 0x400475f8f0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e0add0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40036ca750, {0x3e3faf0, 0x4000e0add0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3885 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3887 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e23828, 0x4003679ef0}, 0x400166a340)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3886
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3890 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3837
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3891 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40036caea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3837
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3900 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40036b94f0, {0x4003792cd0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40036b94f0, {0x4003792cd0?, 0x4003790360?, 0x400181c950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003792c90, {0x4003792cd0?, 0x400181c9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003792c90}, {0x4003792cd0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003796900, {0x4003792cd0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003792cc0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003792cc0, 0x4003796900, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003796900?, {0xffff5220d928, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x4004e322a0}, 0x400181c958?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40036cb040, {0x368b2c0, 0x4004e322a0}, 0x4004e33f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400181cd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40037966c0, 0x400181ce30, 0x400181ce78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40037966c0, {0x368b2c0?, 0x4004e322a0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40036b0828, {0x368b2c0, 0x4004e322a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000e0b980)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40036caea0, {0x3e3faf0, 0x4000e0b980})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3893 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3895 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e23828, 0x400358f360}, 0x400166a840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3894
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3899 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x400369ec60, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3901 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x400369ed10, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3902 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x4003679ef0}, 0x4003792210, 0x4000ea6490)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003679ef0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3886
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3903 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002d32180, {0x3e23828, 0x4003679ef0}, {0xffff5214eea8, 0x40011e1e60}, {0x400355f120?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x40031491a0, {0x3e23828, 0x4003679ef0}, {0xffff5214eea8, 0x40011e1e60}, {0x4001790738, 0x1, 0x4000201000000?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003679ef0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3886
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3904 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e23828, 0x4003679ef0}, 0x400166b040)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3903
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3907 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002d32080, {0x3e23828, 0x4003679ef0}, {0xffff5214eea8, 0x40011e1e60}, {0x400355f3a0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003679ef0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3886
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3908 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002d32100, {0x3e23828, 0x4003679ef0}, {0xffff5214eea8, 0x40011e1e60}, {0x400355f280?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003679ef0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3886
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3909 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e23828, 0x4003679ef0}, 0x400166b540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3908
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3912 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e23828, 0x4003679ef0}, 0x400166b740)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3907
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3915 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x400369edc0, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3848 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e23828, 0x400358fae0}, 0x400133b180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3847
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3851 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004c4f50, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40036f1078}, 0x400378e180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3902
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3920 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x400358f360}, 0x4003793080, 0x4000ea7750)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400358f360})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3894
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3852 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e1e60, {0x3e236d0, 0x680cae0}, 0x400133b2c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3851
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3856 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa180, {0x3e23828, 0x400358f360}, {0xffff5214eea8, 0x4002229200}, {0x400355f780?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400358f360})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3894
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3937 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa200, {0x3e23828, 0x400358f360}, {0xffff5214eea8, 0x4002229200}, {0x4001b72e80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400358f360})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3894
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3921 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa280, {0x3e23828, 0x400358f360}, {0xffff5214eea8, 0x4002229200}, {0x400355f640?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400328cea0, {0x3e23828, 0x400358f360}, {0xffff5214eea8, 0x4002229200}, {0x4001790810, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400358f360})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3894
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3922 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e23828, 0x400358f360}, 0x400166bec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3921
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3925 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004c5c00, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40036f1af8}, 0x400378ec00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3926 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e236d0, 0x680cae0}, 0x4000de2080)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3925
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3929 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x400369ee70, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3930 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e23828, 0x400358f360}, 0x4000de2340)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3856
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3938 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e23828, 0x40033faa00}, 0x400133b7c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3941 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002229200, {0x3e23828, 0x400358f360}, 0x400133b900)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3937
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3944 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003727b80, {0x3e23828, 0x40033fb590}, {0xffff5214eea8, 0x4000de05a0}, {0x40035dc8e8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003764000, {0x3e23828, 0x40033fb590})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4000e247e0, {0x3e23828, 0x40033fb590}, {0x3e5f080, 0x4000de05a0}, {0x1, {0x1, 0x1, 0xff}}, 0x400373ca20)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3639
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3945 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e23828, 0x40033fb590}, 0x400133bd80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3944
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3933 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x400369ef20, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3934 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x400369efd0, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3948 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x40037b0d10, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3991 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003361c80, {0x3e23828, 0x40033faa00}, {0xffff5214eea8, 0x40011e18c0}, {0x4001b73ca0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003148fc0, {0x3e23828, 0x40033faa00}, {0xffff5214eea8, 0x40011e18c0}, {0x40016ee128, 0x1, 0x4003733180?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40033faa00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3951 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036caea0, 0x40037b0dc0, 0x400378e780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3891
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3968 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400056e0e0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003732eb8}, 0x400373cae0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3963
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3985 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x400358fae0}, 0x40037287e0, 0x4000ee9760)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400358fae0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3847
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3963 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x40033fb590}, 0x4003758540, 0x4000efe8f0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40033fb590})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3944
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3987 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e23828, 0x400358fae0}, 0x4001176440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3986
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3986 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292dd00, {0x3e23828, 0x400358fae0}, {0xffff5214eea8, 0x4000de1680}, {0x4001b73aa0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400328c960, {0x3e23828, 0x400358fae0}, {0xffff5214eea8, 0x4000de1680}, {0x40016ee0f8, 0x1, 0x6d617069222c7d30?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400358fae0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3847
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3972 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292d780, {0x3e23828, 0x40033fb590}, {0xffff5214eea8, 0x4000de05a0}, {0x40038561a0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40033fb590})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3944
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3969 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e236d0, 0x680cae0}, 0x40013c3040)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3968
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3965 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e23828, 0x40033fb590}, 0x40013c2f40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3964
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3964 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292d880, {0x3e23828, 0x40033fb590}, {0xffff5214eea8, 0x4000de05a0}, {0x400355ff40?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400328c780, {0x3e23828, 0x40033fb590}, {0xffff5214eea8, 0x4000de05a0}, {0x4001790b80, 0x1, 0x8a6d4?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40033fb590})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3944
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3990 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x40033faa00}, 0x40037294a0, 0x4000ee9b20)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40033faa00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3973 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292d800, {0x3e23828, 0x40033fb590}, {0xffff5214eea8, 0x4000de05a0}, {0x4003856080?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40033fb590})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3944
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3974 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e23828, 0x40033fb590}, 0x40013c3340)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3973
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3977 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de05a0, {0x3e23828, 0x40033fb590}, 0x40013c3540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3972
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3980 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x400369f080, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3981 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x400369f130, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3992 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e23828, 0x40033faa00}, 0x4001176940)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3991
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3995 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004ca7e0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003597e78}, 0x400359f8c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3985
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3996 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e236d0, 0x680cae0}, 0x4001176b00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3995
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3999 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292dc00, {0x3e23828, 0x400358fae0}, {0xffff5214eea8, 0x4000de1680}, {0x4003990080?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400358fae0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3847
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4000 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400292dc80, {0x3e23828, 0x400358fae0}, {0xffff5214eea8, 0x4000de1680}, {0x4001b73e20?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400358fae0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3847
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4001 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e23828, 0x400358fae0}, 0x4001176e00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4000
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4004 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004cb1f0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40037325f8}, 0x400373c180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3990
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4005 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e236d0, 0x680cae0}, 0x4001176f80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4004
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4008 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003361a80, {0x3e23828, 0x40033faa00}, {0xffff5214eea8, 0x40011e18c0}, {0x40039901a0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40033faa00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4009 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003361b00, {0x3e23828, 0x40033faa00}, {0xffff5214eea8, 0x40011e18c0}, {0x4001b73f60?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40033faa00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3855
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4010 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e23828, 0x40033faa00}, 0x40011772c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4009
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4013 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4000de1680, {0x3e23828, 0x400358fae0}, 0x40011775c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3999
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4016 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x40037b0e70, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4017 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40011e18c0, {0x3e23828, 0x40033faa00}, 0x4001177840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4008
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4020 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x40037b1130, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4021 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x40037b11e0, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4022 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x40037b1290, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3982 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x4003678dc0}, 0x40037a5110, 0x4000eff7f0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003678dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3983 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa700, {0x3e23828, 0x4003678dc0}, {0xffff5214eea8, 0x40004c3440}, {0x4003856540?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400328d0e0, {0x3e23828, 0x4003678dc0}, {0xffff5214eea8, 0x40004c3440}, {0x4001790d08, 0x1, 0x40037f3a40?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003678dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3984 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e23828, 0x4003678dc0}, 0x400164ed00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4035 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40005688c0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400379b238}, 0x400378ff80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3982
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4036 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e236d0, 0x680cae0}, 0x400164ef00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4035
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4023 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x40021dd340, {0x3e23828, 0x4003678640}, 0x40035dfd70, 0x4000f9abb0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003678640})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4024 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daac00, {0x3e23828, 0x4003678640}, {0xffff5214eea8, 0x40022287e0}, {0x40039903a0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400328d500, {0x3e23828, 0x4003678640}, {0xffff5214eea8, 0x40022287e0}, {0x40016ee2b0, 0x1, 0x40038b2a80?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003678640})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4039 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa600, {0x3e23828, 0x4003678dc0}, {0xffff5214eea8, 0x40004c3440}, {0x4003990660?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003678dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4040 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daa680, {0x3e23828, 0x4003678dc0}, {0xffff5214eea8, 0x40004c3440}, {0x4003856680?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003678dc0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4025 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca750, 0x40037b1340, 0x40036bbc20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3883
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4026 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40004ca000, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003597938}, 0x400359f3e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4027 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e236d0, 0x680cae0}, 0x4000e70740)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4026
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4030 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daab00, {0x3e23828, 0x4003678640}, {0xffff5214eea8, 0x40022287e0}, {0x40039905e0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003678640})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4031 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4002daab80, {0x3e23828, 0x4003678640}, {0xffff5214eea8, 0x40022287e0}, {0x40039904c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003678640})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3843
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4041 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e23828, 0x4003678dc0}, 0x400164f280)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4040
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4044 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e23828, 0x4003678640}, 0x400164f380)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4024
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4047 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e23828, 0x4003678640}, 0x400164f4c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4030
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4032 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40022287e0, {0x3e23828, 0x4003678640}, 0x4000e70a80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4031
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4051 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x40037b13f0, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4052 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x40037b14a0, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4053 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40004c3440, {0x3e23828, 0x4003678dc0}, 0x4000e71340)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4039
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4056 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x40037b1550, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4057 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x40037b1600, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4066 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x400369f1e0, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4067 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x400369f290, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4058 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x40037b16b0, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4068 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x400369f340, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4069 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x400369f3f0, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4070 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x400369f4a0, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4071 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x400369f550, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4072 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x400369f600, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4073 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca270, 0x400369f6b0, 0x40036baea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3869
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4074 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x400369f760, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4075 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x400369f810, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4059 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x40037b1760, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4060 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca000, 0x40037b1810, 0x40036ba8a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3863
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4061 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x40037b18c0, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4062 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x40037b1970, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4063 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eed930, 0x40037b1a20, 0x40036ba300)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3859
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4076 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40036ca4e0, 0x400369f8c0, 0x40036bb3e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3873
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4064 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4002eecf70, 0x40037b1ad0, 0x4003685560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3831
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 10779 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4734 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001557540)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4754 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198f00, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40033839e0}, 0x400038f0a0, 0x0, 0x4003267170, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 6051 [IO wait]:
internal/poll.runtime_pollWait(0xffff521638b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40028d9d80?, 0x4004e18000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40028d9d80, {0x4004e18000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40028d9d80, {0x4004e18000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001357e20, {0x4004e18000?, 0x72?, 0x4001ed1dd8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001ed1dd0, {0x4004e18000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002928780)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002928780, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400215bef0, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4965 [select]:
net/http.(*persistConn).writeLoop(0x40039d18c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4962
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5677 [IO wait]:
internal/poll.runtime_pollWait(0xffff522728c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40037b6c80?, 0x4002d9c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40037b6c80, {0x4002d9c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40037b6c80, {0x4002d9c000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790330, {0x4002d9c000?, 0x72?, 0x4003793358?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003793350, {0x4002d9c000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003195bc0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003195bc0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4002e477a0, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4997 [select]:
net/http.(*persistConn).writeLoop(0x4003a56b40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4994
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 12104 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 6565 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40042da4c8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042da4b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042da4b0, {0x4002d44001, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002975cc8?}, {0x4002d44001?, 0x4002975cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4003ef5b80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4003ef5b80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4003ef5b80, {0x30150e0, 0x4001805080})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400389ce40, {0x4004649000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002f61b30, 0x0, {0x3e02238, 0x400439de00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000ae5820)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40051de700)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 770
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 4959 [IO wait]:
internal/poll.runtime_pollWait(0xffff522722f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a000?, 0x4003ea4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a000, {0x4003ea4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a000, {0x4003ea4000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790a30, {0x4003ea4000?, 0x13?, 0x4003c62d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40039d1c20, {0x4003ea4000?, 0x400288dd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ce1980)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ce1980, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40039d1c20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4966
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4982 [select]:
net/http.(*persistConn).writeLoop(0x4003a57200)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5000
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4972 [IO wait]:
internal/poll.runtime_pollWait(0xffff52272100, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a100?, 0x4003f15000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a100, {0x4003f15000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a100, {0x4003f15000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163ea28, {0x4003f15000?, 0xf?, 0x400288fd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a56360, {0x4003f15000?, 0x4003e2ad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003d748a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d748a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a56360)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4970
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4973 [select]:
net/http.(*persistConn).writeLoop(0x4003a56360)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4970
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4779 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40033b9e00, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40034f58c0}, 0x4000dc3310, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4958 [select]:
net/http.(*persistConn).writeLoop(0x40039d0d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4944
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4996 [IO wait]:
internal/poll.runtime_pollWait(0xffff52271f10, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a200?, 0x4003f21000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a200, {0x4003f21000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a200, {0x4003f21000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163eaa0, {0x4003f21000?, 0xe?, 0x400288fd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a56b40, {0x4003f21000?, 0x4003b47d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003d75800)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d75800, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a56b40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4994
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4978 [select]:
net/http.(*persistConn).writeLoop(0x4003a56000)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4968
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5546 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff52163d90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d09b80?, 0x40041a6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d09b80, {0x40041a6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d09b80, {0x40041a6000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001577948, {0x40041a6000?, 0x72?, 0x400334bc58?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400334bc50, {0x40041a6000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40031fd980)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40031fd980, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4002d1d290, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5037 [select, 6 minutes]:
net/http.(*persistConn).writeLoop(0x4003ab78c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5035
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4957 [IO wait]:
internal/poll.runtime_pollWait(0xffff522724e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e2de80?, 0x4003ea2000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e2de80, {0x4003ea2000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e2de80, {0x4003ea2000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790a20, {0x4003ea2000?, 0xf?, 0x4003c5ed00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40039d0d80, {0x4003ea2000?, 0x4003c64d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ce1860)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ce1860, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40039d0d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4944
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10999 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11869 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5117 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff52272ba8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40047f9e80?, 0x4002c60000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40047f9e80, {0x4002c60000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40047f9e80, {0x4002c60000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001576660, {0x4002c60000?, 0x72?, 0x400389e248?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400389e240, {0x4002c60000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003383560)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003383560, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40047fb3b0, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5002 [IO wait]:
internal/poll.runtime_pollWait(0xffff52164170, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d56480?, 0x4003f23000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d56480, {0x4003f23000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d56480, {0x4003f23000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163eb00, {0x4003f23000?, 0x12?, 0x4003de3d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40039938c0, {0x4003f23000?, 0x40024b9d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003e0a480)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003e0a480, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40039938c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4983
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 11593 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4979 [IO wait]:
internal/poll.runtime_pollWait(0xffff52164360, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a280?, 0x4003eaa000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a280, {0x4003eaa000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a280, {0x4003eaa000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790a50, {0x4003eaa000?, 0x13?, 0x400288fd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a56ea0, {0x4003eaa000?, 0x400288ed18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ce1bc0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ce1bc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a56ea0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4998
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10761 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4753 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x1?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000399600?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 11031 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10997 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4964 [IO wait]:
internal/poll.runtime_pollWait(0xffff522723e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e2df00?, 0x4003f07000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e2df00, {0x4003f07000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e2df00, {0x4003f07000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163e9a0, {0x4003f07000?, 0xe?, 0x4003c62d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40039d18c0, {0x4003f07000?, 0x40024b6d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003d74240)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d74240, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40039d18c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4962
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4755 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003199040, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4003afc370, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11029 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4736 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4003afc230})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003198a00, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000ada360, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4672
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11875 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 7542 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4000f59a10, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f59a00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0x400248c8c0)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:159 +0x134
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 810
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:176 +0x60

goroutine 4993 [select]:
net/http.(*persistConn).writeLoop(0x4003a567e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4974
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4976 [IO wait]:
internal/poll.runtime_pollWait(0xffff52272008, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a180?, 0x4003f1d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a180, {0x4003f1d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a180, {0x4003f1d000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163ea70, {0x4003f1d000?, 0x13?, 0x400288fd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a567e0, {0x4003f1d000?, 0x4003de2d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003d750e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d750e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a567e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4974
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4943 [select]:
net/http.(*persistConn).writeLoop(0x40039d0900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4940
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4977 [IO wait]:
internal/poll.runtime_pollWait(0xffff522721f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a080?, 0x4003ea6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a080, {0x4003ea6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a080, {0x4003ea6000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790a38, {0x4003ea6000?, 0x12?, 0x4003de3d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a56000, {0x4003ea6000?, 0x40024b7d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ce1a40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ce1a40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a56000)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4968
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10781 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4745 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400314b540, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000d0e160, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4774
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4684 [IO wait]:
internal/poll.runtime_pollWait(0xffff522727c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40028d8780?, 0x4002cee000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40028d8780, {0x4002cee000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40028d8780, {0x4002cee000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000e9bee8, {0x4002cee000?, 0x72?, 0x4002f30788?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4002f30780, {0x4002cee000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40032b9020)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40032b9020, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40029cc120, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4980 [select]:
net/http.(*persistConn).writeLoop(0x4003a56ea0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4998
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4743 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400314a000, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40032ed740}, 0x4000d196a0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4763 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40031992c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40007845a0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4755
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4836 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003b01900, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40037b5e60}, 0x4000450540, 0x0, 0x40037291a0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4793
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4769 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40018dfe00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4759
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4800 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400253b5e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4793
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4771 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4003b78be0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003199a40, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000cab6c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4772 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400029ec01?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000040270?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4759
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4773 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003199b80, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x400342ccc0}, 0x40003ce540, 0x0, 0x40031dfbf0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4774 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003199e00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4003b78d20, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4759
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4981 [IO wait]:
internal/poll.runtime_pollWait(0xffff52164268, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f1a300?, 0x4003eae000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f1a300, {0x4003eae000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f1a300, {0x4003eae000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790a68, {0x4003eae000?, 0xf?, 0x4003c01d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003a57200, {0x4003eae000?, 0x4003a77d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ce1d40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ce1d40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003a57200)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5000
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5948 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40042da1c8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042da1b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042da1b0, {0x4002c97801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40029e3cc8?}, {0x4002c97801?, 0x40029e3cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002171180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002171180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002171180, {0x30150e0, 0x4003ded6f8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40015ea690, {0x4003a48400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003f8ed70, 0x0, {0x3e02238, 0x400164e080})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000210d60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40016485c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 4987 [IO wait]:
internal/poll.runtime_pollWait(0xffff52164078, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d56500?, 0x4003eb0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d56500, {0x4003eb0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d56500, {0x4003eb0000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790ac0, {0x4003eb0000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003993c20, {0x4003eb0000?, 0x4003f64d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003cf6840)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003cf6840, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003993c20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4985
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4841 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003784280, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000ee9eb0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4837
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4834 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4003d5b4f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003b017c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000ee9540, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4793
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4988 [select]:
net/http.(*persistConn).writeLoop(0x4003993c20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4985
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4835 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400340cf90?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4003793260?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4793
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4837 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003b01a40, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4003d5b630, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4793
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4849 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40037177c0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003b39ec0}, 0x40012d0a70, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4835
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5003 [select]:
net/http.(*persistConn).writeLoop(0x40039938c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4983
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 11873 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4853 [IO wait]:
internal/poll.runtime_pollWait(0xffff522725d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003b7e780?, 0x40029d0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003b7e780, {0x40029d0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003b7e780, {0x40029d0000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790628, {0x40029d0000?, 0x72?, 0x4003ac8db8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003ac8db0, {0x40029d0000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400318c1e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400318c1e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003b31950, {0x3e237f0, 0x400177aed0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1679
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4942 [IO wait]:
internal/poll.runtime_pollWait(0xffff522726d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e2de00?, 0x4003e33000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e2de00, {0x4003e33000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e2de00, {0x4003e33000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163e908, {0x4003e33000?, 0x11?, 0x4003c5ed00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40039d0900, {0x4003e33000?, 0x4003c5fd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003d6fbc0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003d6fbc0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40039d0900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4940
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 6069 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003c22c48, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c22c38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c22c30, {0x4001980b54, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003c65cc8?}, {0x4001980b54?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x4003c22c00}, {0x4001980b54, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40005e5170, {0x4003a48800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002819590, 0x0, {0x3e02238, 0x4001753200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018672e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400146ae80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 776
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 4960 [select]:
net/http.(*persistConn).writeLoop(0x40039d1c20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4966
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 10783 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10782 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12141 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4001393790, 0x1b)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001393780)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x4001393740, {0x3e23828, 0x400431ec80}, {0x400437a870, 0x28}, 0x12f, {0x400109af65, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 10170
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 4992 [select]:
net/http.(*persistConn).writeLoop(0x400395e000)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4989
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4880 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4003c22048, 0x7)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c22038)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c22030, {0x4001a18a4c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003cf1cc8?}, {0x4001a18a4c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff52255228, 0x4003c22000}, {0x4001a18a4c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003c14f78, {0x40024cb400, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003e49ae0, 0x0, {0x3e02238, 0x4001371840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400194e320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40009e1d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1416
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5011 [IO wait]:
internal/poll.runtime_pollWait(0xffff52163e88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d56600?, 0x4003eb6000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d56600, {0x4003eb6000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d56600, {0x4003eb6000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790b40, {0x4003eb6000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400395e480, {0x4003eb6000?, 0x4002205d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003cf6f00)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003cf6f00, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400395e480)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5009
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4991 [IO wait]:
internal/poll.runtime_pollWait(0xffff52163f80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003d56580?, 0x4003eb4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003d56580, {0x4003eb4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003d56580, {0x4003eb4000?, 0x4001bee8c0?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001790b00, {0x4003eb4000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400395e000, {0x4003eb4000?, 0x40024bad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003cf6ba0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003cf6ba0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400395e000)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4989
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10563 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10271 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4835
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11000 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11306 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5038 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff52163ba0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004223580?, 0x4002bc7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004223580, {0x4002bc7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004223580, {0x4002bc7000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163f848, {0x4002bc7000?, 0x72?, 0x40042622d8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40042622d0, {0x4002bc7000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002d78780)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002d78780, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400425f3b0, {0x3e237f0, 0x4002d8b560})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1740
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 5036 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff522729b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004223300?, 0x4004264000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004223300, {0x4004264000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004223300, {0x4004264000?, 0x1?, 0x4003ee8380?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400163f840, {0x4004264000?, 0xc?, 0x40041b2d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003ab78c0, {0x4004264000?, 0x18550?, 0x4003cd2a80?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4004259080)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4004259080, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003ab78c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5035
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 11030 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10240 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff521637c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004808980?, 0x4004815000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0x4004808980, {0x4004815000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x40000000)
	/usr/local/go/src/internal/poll/fd_unix.go:301 +0x284
net.(*netFD).readMsg(0x4004808980, {0x4004815000?, 0x4003e7a8d0?, 0x4003e7a8a0?}, {0x0?, 0x4003f83170?, 0x40039e3b88?}, 0x25809a0?)
	/usr/local/go/src/net/fd_posix.go:78 +0x30
net.(*UnixConn).readMsg(0x40016ef200, {0x4004815000?, 0x40039e3be8?, 0x2577428?}, {0x0?, 0x400045d380?, 0x4004729950?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x38
net.(*UnixConn).ReadMsgUnix(0x40016ef200, {0x4004815000?, 0x5?, 0x377a3b0?}, {0x0?, 0x0?, 0x3788a53?})
	/usr/local/go/src/net/unixsock.go:143 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0x400045d740, {0x3e23828, 0x40026c94f0}, 0x40016ef200)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:132 +0x12c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1 in goroutine 392
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x138

goroutine 10565 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10583 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10172 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4003e39360, {0x4003e7aa30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003e39360, {0x4003e7aa30?, 0x4003790288?, 0x40050e3510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003e7a750, {0x4003e7aa30?, 0x40050e3598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003e7a750}, {0x4003e7aa30, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003951560, {0x4003e7aa30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003e7aa20, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003e7aa20, 0x4003951560, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40050e37c8?, {0xffff5220d928, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400452efa0}, 0x4000c28700?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4003dfd1d0, {0x35bf9e0, 0x400452efa0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0x4001a93290)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1730 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x3e31c48?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 10170
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 5484 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003c221c8, 0xc9)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003c221b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003c221b0, {0x4004ca5001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40026bdcc8?}, {0x4004ca5001?, 0x40026bdcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x400047ec80)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x400047ec80)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x400047ec80, {0x30150e0, 0x40018a5ad0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40013989f0, {0x400564b500, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40008f4a50, 0x0, {0x3e02238, 0x4004deff00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40005d34e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40011c9800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1422
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12109 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11871 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10596 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 7507 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40042db0c8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40042db0b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40042db0b0, {0x4002937201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001e33cc8?}, {0x4002937201?, 0x4001e33cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40032d8640)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40032d8640)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40032d8640, {0x30150e0, 0x400396b0c8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003f18ae0, {0x40047e2400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003c5bd10, 0x0, {0x3e02238, 0x4004347940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018acde0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40052fe240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 782
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10597 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10760 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12142 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4001393890, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001393880)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x4001393840, {0x3e23828, 0x400431ecd0}, {0x4001c65540, 0x35}, 0x11, {0x40008cb205, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 816
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 10758 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10562 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10598 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10998 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10595 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11594 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10759 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11591 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10564 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12110 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10995 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10394 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4835
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10780 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12102 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11870 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11868 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12111 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11028 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12107 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10996 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11292 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11295 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11308 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11326 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12103 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11327 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11293 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11623 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12106 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11305 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11307 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11624 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11294 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11602 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11603 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11872 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11874 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11625 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12105 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12108 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4753
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11626 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4772
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4
