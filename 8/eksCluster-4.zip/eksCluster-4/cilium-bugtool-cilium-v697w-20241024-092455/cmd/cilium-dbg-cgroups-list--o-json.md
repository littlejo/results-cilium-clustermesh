[
  {
    "containers": [
      {
        "cgroup-id": 9005,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod235b1821_01ad_4f13_b113_b446531f46b3.slice/cri-containerd-fee32a58d7e7333b8c3946ceaeca5f47b85b8a923e14063e2115643f3768b539.scope"
      },
      {
        "cgroup-id": 9089,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod235b1821_01ad_4f13_b113_b446531f46b3.slice/cri-containerd-517ce09348f4d5ab60c271e3ee5a40fcc35b2d3c30bc179c56d5c1fd9e1abc78.scope"
      }
    ],
    "ips": [
      "10.4.0.200"
    ],
    "name": "echo-same-node-86d9cc975c-28tnz",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6653,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4c9c7a7f_25a5_4224_b83c_24155c3c9c6d.slice/cri-containerd-b092568b56cb86b003ed3a43af735c195b794c6b7519ea64db04e884a107e64b.scope"
      }
    ],
    "ips": [
      "10.4.0.163"
    ],
    "name": "coredns-586b798467-2zsn8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8837,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf55fa26b_9aba_4179_a988_f10afe44e784.slice/cri-containerd-53895a9ebf32844c251693c3e3f2f256433a398de26b975eda935714d0f0fd79.scope"
      }
    ],
    "ips": [
      "10.4.0.75"
    ],
    "name": "client2-57cf4468f-tmdnj",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8165,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-559ff91e8164a10457bb69ca7d5819ecf2c5e0b95f3cab08a40ccebebe93f143.scope"
      },
      {
        "cgroup-id": 8081,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-9a7510ba9b9610e88324e4db6d7449a47a616b4490baa8127883cbca6f70b40a.scope"
      },
      {
        "cgroup-id": 8249,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f75c674_7009_4ea9_b9ce_ffd151bc3e9f.slice/cri-containerd-888c0006749c7fe9b1510acb6745086a2aa59e70fdbdbe6489a14c468e520da6.scope"
      }
    ],
    "ips": [
      "10.4.0.93"
    ],
    "name": "clustermesh-apiserver-7b4f4f4459-bw7kd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6737,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3cc9a380_e0bb_4796_abba_7f628fb2d5eb.slice/cri-containerd-f4e1c624117f245714a19aef2c358be0ccb8adb0ff5f557f87f4af15938ee4af.scope"
      }
    ],
    "ips": [
      "10.4.0.224"
    ],
    "name": "coredns-586b798467-bngqp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8921,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab51031_4cd5_4082_8071_6c623094bb5f.slice/cri-containerd-7c08034991fab9697687bf0f6d4ccebdaac6ffd1ec42af04d18a6317b5484bb4.scope"
      }
    ],
    "ips": [
      "10.4.0.239"
    ],
    "name": "client-974f6c69d-z648w",
    "namespace": "cilium-test-1"
  }
]

