KEY             VALUE
AgentLiveness   655825268982
UTimeOffset     3378439982421875
