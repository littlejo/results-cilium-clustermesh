IP ADDRESS         LOCAL ENDPOINT INFO
10.4.0.93:0        id=2951  sec_id=350710 flags=0x0000 ifindex=15  mac=5E:B3:20:7B:7E:30 nodemac=FA:53:00:2B:E4:9B   
10.4.0.224:0       id=839   sec_id=336619 flags=0x0000 ifindex=11  mac=7A:9F:10:FE:FA:05 nodemac=CA:FC:78:3A:2C:81   
10.4.0.105:0       id=3262  sec_id=4     flags=0x0000 ifindex=7   mac=DE:CC:09:F0:DE:E0 nodemac=4E:62:BD:F5:03:31    
10.4.0.163:0       id=751   sec_id=336619 flags=0x0000 ifindex=9   mac=FE:A2:00:8E:D2:F2 nodemac=D2:DD:38:52:88:BC   
10.4.0.230:0       (localhost)                                                                                       
10.4.0.239:0       id=244   sec_id=332688 flags=0x0000 ifindex=17  mac=D2:F9:E1:B7:E0:FF nodemac=F2:FE:93:E0:9B:26   
10.4.0.200:0       id=2244  sec_id=359982 flags=0x0000 ifindex=21  mac=3A:6A:78:18:55:66 nodemac=D6:07:0B:A8:C5:8F   
172.31.167.173:0   (localhost)                                                                                       
10.4.0.75:0        id=198   sec_id=361562 flags=0x0000 ifindex=19  mac=22:B4:5E:58:86:E4 nodemac=7E:14:39:E4:98:CA   
