qdisc noqueue 0: dev lo root refcnt 2 
qdisc mq 0: dev ens5 root 
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev ens5 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc_health root refcnt 2 
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
qdisc noqueue 0: dev lxceb65690dfaed root refcnt 2 
qdisc clsact ffff: dev lxceb65690dfaed parent ffff:fff1 
qdisc noqueue 0: dev lxcad13466e51ce root refcnt 2 
qdisc clsact ffff: dev lxcad13466e51ce parent ffff:fff1 
qdisc noqueue 0: dev lxc99a47c4a39e2 root refcnt 2 
qdisc clsact ffff: dev lxc99a47c4a39e2 parent ffff:fff1 
qdisc noqueue 0: dev lxc1f40b3fd9411 root refcnt 2 
qdisc clsact ffff: dev lxc1f40b3fd9411 parent ffff:fff1 
qdisc noqueue 0: dev lxc142ae6a3e494 root refcnt 2 
qdisc clsact ffff: dev lxc142ae6a3e494 parent ffff:fff1 
qdisc noqueue 0: dev lxccd75ea23b396 root refcnt 2 
qdisc clsact ffff: dev lxccd75ea23b396 parent ffff:fff1 
