CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdf657ba_8dc6_4b2b_8d4d_d726a4ad0fa3.slice/cri-containerd-ae11f1f5c4e34331ef4ee5e6da04c9c49d4a4cdef93310b5278015612553c9c1.scope
    466      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdf657ba_8dc6_4b2b_8d4d_d726a4ad0fa3.slice/cri-containerd-dc6b7d8bfe9d946b3fdb4efa01062fae11b8b852bc0d7429f02723a2be237ef9.scope
    458      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d01fd30_8e6b_4f92_bf5a_35417fd91b96.slice/cri-containerd-c886d2d4a8041498c9923802da94dae1c6ecf1c60f5a07a69d0317c1d242a402.scope
    61       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9d01fd30_8e6b_4f92_bf5a_35417fd91b96.slice/cri-containerd-7d51688f5e9d0140b190d5f32100389d6f78cdf4010e7775170994d0e5839b5f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51141781_c82e_4e4b_bdfd_04577357a57a.slice/cri-containerd-cff0e6642f50e503fb16240a80a9ab3a0ede19c62e524eba75e91cbfa30b1012.scope
    556      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51141781_c82e_4e4b_bdfd_04577357a57a.slice/cri-containerd-1e344be07bfd20d0b67d14ba306259d952237f1dd7b778ee060fe86bc6434c48.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19112fa6_c415_4aad_93e9_cfe3f70688bb.slice/cri-containerd-81ca980d75873c50b493b14c77a89dfb898cbd76461801d98748e24e559b4178.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19112fa6_c415_4aad_93e9_cfe3f70688bb.slice/cri-containerd-484eaaa5acc740120e2d128221c45c8028f0eab2e181cb7de73b966bf1bdee75.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75c22ead_11ce_4a39_8254_141f60f9c136.slice/cri-containerd-b62c374cdf65ffce6d8efc2f99462ea8a94c95125f660306f473e13b1e7cee7d.scope
    65       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75c22ead_11ce_4a39_8254_141f60f9c136.slice/cri-containerd-fad8ca4d9a3b9e7d766df023869aa11d911d07bacf79d493fb169bc8f77b6fc3.scope
    69       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb54c44e_b33a_43cc_8612_425f00173094.slice/cri-containerd-ab6c474c47d1056ab8f436fcf1440a46c6a98ac0ce40c2b599f38289994037a9.scope
    691      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb54c44e_b33a_43cc_8612_425f00173094.slice/cri-containerd-33bb62d6476801ca6f23516f68130678cf6102def244a162eddf60fa90fd773e.scope
    699      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb54c44e_b33a_43cc_8612_425f00173094.slice/cri-containerd-317076ba3451759fe58b894f27f5bffb861712eb1137558c85bf5a3ebbdcb317.scope
    695      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5380b96_865f_426a_8e0c_9d6c80948034.slice/cri-containerd-78dfa39b33b348abe33fe823a70df3809161427a90c47e696187fe700dabdc7e.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5380b96_865f_426a_8e0c_9d6c80948034.slice/cri-containerd-1f8a32bf3a626d2b0d87c5ac7f0e75958e37027b5ab2621094f81234ac3896fd.scope
    683      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8180d33_6322_4c4c_82df_5df346458361.slice/cri-containerd-c8cc99c558d7be4c7843400eebb45201538e19f1facabda66f6e6a44458ce4cb.scope
    76       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd8180d33_6322_4c4c_82df_5df346458361.slice/cri-containerd-3226b8fb75cba7e948058ae5d731e9b5987d7ee8f55eed6036bd90670c64c87e.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-76233038d2ee4fbfc555f9b33924aa620f8ee341b5295cc346db860c72589138.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-84f7814306c30269e0f0f2fb4c8378f045d877c5025526815954adfa10f69cb1.scope
    638      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-60c64b1331fbca921e2e113955b12a45a2b2a8462884eaabd0866ae3d2bb1040.scope
    630      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-398bce231c03fc120f6fc64ac98466d795327e4b237057fcd623ac709016bfb1.scope
    614      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2a6ed49_0cd6_4760_8aec_91b44ce6bf82.slice/cri-containerd-d60a38e3e0b105612a847328714a25c276a249a00f53c11f3253aeda7997601c.scope
    687      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2a6ed49_0cd6_4760_8aec_91b44ce6bf82.slice/cri-containerd-b24e63a751408d1b030caa0073036f5ba40e5d4369c905db5f9a49ed1a0fc6d7.scope
    664      cgroup_device   multi                                          
