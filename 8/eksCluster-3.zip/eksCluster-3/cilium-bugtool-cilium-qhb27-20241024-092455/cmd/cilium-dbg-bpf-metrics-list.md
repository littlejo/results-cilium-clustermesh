REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     516       41102       677    bpf_overlay.c
Interface                   INGRESS     56260     194154150   1132   bpf_host.c
Policy denied               EGRESS      136       10064       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      511       40704       53     encap.h
Success                     EGRESS      708       170259      86     l3.h
Success                     EGRESS      871       61364       1694   bpf_host.c
Success                     EGRESS      9562      1880451     1308   bpf_lxc.c
Success                     INGRESS     11469     1683958     86     l3.h
Success                     INGRESS     12337     1862147     235    trace.h
Unsupported L3 protocol     EGRESS      64        4880        1492   bpf_lxc.c
