Endpoint ID: 490
Path: /sys/fs/bpf/tc/globals/cilium_policy_00490

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 535
Path: /sys/fs/bpf/tc/globals/cilium_policy_00535

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5968    67        0        
Allow    Ingress     1          ANY          NONE         disabled    41579   480       0        
Allow    Egress      0          ANY          NONE         disabled    11288   112       0        


Endpoint ID: 671
Path: /sys/fs/bpf/tc/globals/cilium_policy_00671

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 679
Path: /sys/fs/bpf/tc/globals/cilium_policy_00679

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4408     33        0        
Allow    Ingress     1          ANY          NONE         disabled    302838   3536      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 830
Path: /sys/fs/bpf/tc/globals/cilium_policy_00830

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1013
Path: /sys/fs/bpf/tc/globals/cilium_policy_01013

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23570   293       0        
Allow    Ingress     1          ANY          NONE         disabled    5734    65        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1768
Path: /sys/fs/bpf/tc/globals/cilium_policy_01768

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5408    57        0        
Allow    Ingress     1          ANY          NONE         disabled    39877   459       0        
Allow    Egress      0          ANY          NONE         disabled    11703   117       0        


Endpoint ID: 2870
Path: /sys/fs/bpf/tc/globals/cilium_policy_02870

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    217675   2039      0        
Allow    Ingress     1          ANY          NONE         disabled    206707   2142      0        
Allow    Egress      0          ANY          NONE         disabled    262288   2410      0        


