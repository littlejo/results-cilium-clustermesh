KEY             VALUE
AgentLiveness   516607337526
UTimeOffset     3378440255859375
