key: ea 01 00 00  value: 5b 0e 00 00
key: 17 02 00 00  value: 19 02 00 00
key: a7 02 00 00  value: 36 0d 00 00
key: 3e 03 00 00  value: 59 0e 00 00
key: f5 03 00 00  value: ed 01 00 00
key: e8 06 00 00  value: 25 02 00 00
key: 36 0b 00 00  value: 5e 02 00 00
Found 7 elements
