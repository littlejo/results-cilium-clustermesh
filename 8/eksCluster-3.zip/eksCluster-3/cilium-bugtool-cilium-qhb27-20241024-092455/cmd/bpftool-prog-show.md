32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:16:55+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:55+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:16:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:16:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:17:02+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
58: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
61: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
62: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
65: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
69: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
72: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:17:21+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
73: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
76: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
455: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:17:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
458: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:17:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
459: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:17:59+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
460: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:17:59+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 125
461: sched_cls  name tail_handle_ipv4  tag e4208bc9e81a5a49  gpl
	loaded_at 2024-10-24T09:17:59+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 126
462: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:17:59+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 127
463: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
466: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: sched_cls  name handle_policy  tag 4e71ab2b78cdf730  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,105,74,75,106,33,72,102,31,76,67,32,29,30
	btf_id 159
494: sched_cls  name tail_handle_arp  tag c6ca170bb27fa8dc  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 162
496: sched_cls  name tail_ipv4_to_endpoint  tag b61659ecdb6350c6  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,106,33,74,75,72,102,31,105,32,29,30
	btf_id 163
498: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 165
501: sched_cls  name tail_handle_ipv4_cont  tag 825598ffed7afd9b  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,106,33,102,74,75,31,68,66,69,105,32,29,30,73
	btf_id 167
502: sched_cls  name __send_drop_notify  tag 861d09b2379a521f  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 169
503: sched_cls  name tail_ipv4_ct_ingress  tag 25bcf79ffc4d683a  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 171
506: sched_cls  name tail_handle_ipv4  tag d2ceb753dc5ffea8  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 172
508: sched_cls  name cil_from_container  tag e43bb844eb8bbc85  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 105,68
	btf_id 175
509: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 176
510: sched_cls  name tail_ipv4_ct_ingress  tag 49e59a499500040f  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,108,76
	btf_id 178
511: sched_cls  name cil_from_container  tag 8c3d1c2969e848d8  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,68
	btf_id 179
512: sched_cls  name __send_drop_notify  tag 7637c5c7312146fa  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 180
513: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,110
	btf_id 183
514: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,110
	btf_id 184
516: sched_cls  name __send_drop_notify  tag 7695f010b1de1d2d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 186
517: sched_cls  name tail_handle_ipv4_from_host  tag 9d3bf6d270fbfdae  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,110
	btf_id 187
519: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 189
521: sched_cls  name __send_drop_notify  tag 7695f010b1de1d2d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 192
522: sched_cls  name tail_handle_ipv4_from_host  tag 9d3bf6d270fbfdae  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,111
	btf_id 193
524: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 195
525: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,111
	btf_id 196
527: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 199
530: sched_cls  name __send_drop_notify  tag 7695f010b1de1d2d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 202
531: sched_cls  name tail_handle_ipv4_from_host  tag 9d3bf6d270fbfdae  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 203
532: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 204
534: sched_cls  name tail_ipv4_to_endpoint  tag 1b982498cd668ff1  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,108,33,74,75,72,83,31,107,32,29,30
	btf_id 181
535: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,107
	btf_id 206
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,116
	btf_id 208
537: sched_cls  name handle_policy  tag 578ea4e996f82170  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,107,74,75,108,33,72,83,31,76,67,32,29,30
	btf_id 209
539: sched_cls  name tail_ipv4_to_endpoint  tag edf461564a079929  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,115,33,74,75,72,94,31,116,32,29,30
	btf_id 210
540: sched_cls  name tail_handle_ipv4  tag d25be147177ad857  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,107
	btf_id 212
541: sched_cls  name tail_ipv4_ct_egress  tag d7258ae9dee4f8b9  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,107,74,75,108,76
	btf_id 214
542: sched_cls  name tail_handle_arp  tag 0cfc69b9c78b301e  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,107
	btf_id 215
543: sched_cls  name tail_ipv4_ct_egress  tag d7258ae9dee4f8b9  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,116,74,75,115,76
	btf_id 213
544: sched_cls  name tail_handle_arp  tag 49351194facdefc7  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,116
	btf_id 217
545: sched_cls  name tail_handle_ipv4_cont  tag 097f73417dbb112e  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,108,33,83,74,75,31,68,66,69,107,32,29,30,73
	btf_id 216
547: sched_cls  name tail_handle_ipv4  tag d7fb2263e75c7f36  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,116
	btf_id 219
548: sched_cls  name __send_drop_notify  tag fd1bcd0379f55c41  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 220
549: sched_cls  name handle_policy  tag 0d18b3625559f897  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,116,74,75,115,33,72,94,31,76,67,32,29,30
	btf_id 221
550: sched_cls  name tail_ipv4_ct_ingress  tag b08592711235e775  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,116,74,75,115,76
	btf_id 222
551: sched_cls  name cil_from_container  tag 42d50b95cfcf3efe  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,68
	btf_id 223
552: sched_cls  name tail_handle_ipv4_cont  tag 15665c494040cd9d  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,115,33,94,74,75,31,68,66,69,116,32,29,30,73
	btf_id 224
553: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
556: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
601: sched_cls  name cil_from_container  tag 48b87c6844cabfbc  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 130,68
	btf_id 240
602: sched_cls  name tail_handle_ipv4_cont  tag 41c4c25baf819e42  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,131,33,129,74,75,31,68,66,69,130,32,29,30,73
	btf_id 241
603: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,130
	btf_id 242
604: sched_cls  name __send_drop_notify  tag b76e3981714b7307  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 243
605: sched_cls  name tail_handle_arp  tag dbeb9fc70cb7040d  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,130
	btf_id 244
606: sched_cls  name handle_policy  tag a9d8621bbf686e4c  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,130,74,75,131,33,72,129,31,76,67,32,29,30
	btf_id 245
607: sched_cls  name tail_ipv4_ct_egress  tag 2cad7e73f6e90a00  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,130,74,75,131,76
	btf_id 246
608: sched_cls  name tail_handle_ipv4  tag 56ef494229f7e573  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,130
	btf_id 247
609: sched_cls  name tail_ipv4_ct_ingress  tag 748283aff72ac60f  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,130,74,75,131,76
	btf_id 248
610: sched_cls  name tail_ipv4_to_endpoint  tag e81e0d63b61b3214  gpl
	loaded_at 2024-10-24T09:18:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,131,33,74,75,72,129,31,130,32,29,30
	btf_id 249
611: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
614: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
627: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
630: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
635: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
638: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
680: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
683: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
684: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
687: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
688: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
691: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
692: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
695: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
696: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
699: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3373: sched_cls  name __send_drop_notify  tag 6d514551cff019a7  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3203
3374: sched_cls  name tail_ipv4_to_endpoint  tag 667e2dae7f6f485e  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,641,33,74,75,72,147,31,642,32,29,30
	btf_id 3204
3376: sched_cls  name tail_handle_ipv4  tag 36a9f9798445d5a3  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,642
	btf_id 3206
3377: sched_cls  name tail_handle_ipv4_cont  tag a7def09f5d7273bc  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,641,33,147,74,75,31,68,66,69,642,32,29,30,73
	btf_id 3207
3378: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,642
	btf_id 3208
3379: sched_cls  name tail_ipv4_ct_ingress  tag 50841f3137f6509b  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,642,74,75,641,76
	btf_id 3209
3380: sched_cls  name tail_handle_arp  tag 768fa016968b5973  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,642
	btf_id 3210
3381: sched_cls  name cil_from_container  tag 958af439c666cace  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 642,68
	btf_id 3211
3382: sched_cls  name handle_policy  tag 13131e7ac4e6767b  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,642,74,75,641,33,72,147,31,76,67,32,29,30
	btf_id 3212
3383: sched_cls  name tail_ipv4_ct_egress  tag 1369501d7034dba4  gpl
	loaded_at 2024-10-24T09:23:21+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,642,74,75,641,76
	btf_id 3213
3670: sched_cls  name __send_drop_notify  tag 9b1ba62ffb04e539  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3528
3671: sched_cls  name tail_handle_ipv4  tag 694e7514060cd1ed  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,697
	btf_id 3530
3672: sched_cls  name cil_from_container  tag 1c49d17012099026  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 697,68
	btf_id 3531
3673: sched_cls  name handle_policy  tag e77c49cd10183a3f  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,695,74,75,698,33,72,139,31,76,67,32,29,30
	btf_id 3529
3674: sched_cls  name tail_handle_arp  tag 82b1f49f4ff4f0da  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,695
	btf_id 3533
3675: sched_cls  name handle_policy  tag 27bdd176252ed908  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,697,74,75,696,33,72,142,31,76,67,32,29,30
	btf_id 3532
3676: sched_cls  name tail_handle_ipv4_cont  tag c75ef0d9d3532022  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,698,33,139,74,75,31,68,66,69,695,32,29,30,73
	btf_id 3534
3677: sched_cls  name tail_ipv4_ct_egress  tag 50fe1f0796609195  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,695,74,75,698,76
	btf_id 3536
3678: sched_cls  name cil_from_container  tag 51e7bc954b178e17  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 695,68
	btf_id 3537
3679: sched_cls  name __send_drop_notify  tag b1efbf84017e326c  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3538
3680: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,695
	btf_id 3539
3681: sched_cls  name tail_ipv4_ct_egress  tag 1c95f451356c0975  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,697,74,75,696,76
	btf_id 3535
3682: sched_cls  name tail_ipv4_to_endpoint  tag 431c0cd8fbf39fe3  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,696,33,74,75,72,142,31,697,32,29,30
	btf_id 3541
3684: sched_cls  name tail_ipv4_ct_ingress  tag 07f60adb72b6f587  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,695,74,75,698,76
	btf_id 3540
3685: sched_cls  name tail_handle_ipv4_cont  tag 60ba1122ed2c2e13  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,696,33,142,74,75,31,68,66,69,697,32,29,30,73
	btf_id 3543
3686: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,697
	btf_id 3544
3687: sched_cls  name tail_handle_ipv4  tag 6e6679e48290145e  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,695
	btf_id 3545
3689: sched_cls  name tail_ipv4_ct_ingress  tag 5e4c3a59aa578a51  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,697,74,75,696,76
	btf_id 3546
3690: sched_cls  name tail_handle_arp  tag 908e09a8465c712e  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,697
	btf_id 3549
3691: sched_cls  name tail_ipv4_to_endpoint  tag a738776465cd3d90  gpl
	loaded_at 2024-10-24T09:24:45+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,698,33,74,75,72,139,31,695,32,29,30
	btf_id 3548
