USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root        2945  0.0  0.0 1228744 3596 ?        Ssl  09:24   0:00 /bin/gops stack 1
root        2944  0.0  0.4 1240432 16468 ?       Ssl  09:24   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root        2968  0.0  0.0   6408  1652 ?        R    09:24   0:00  \_ ps auxfw
root        2970  0.0  0.0    368     4 ?        R    09:24   0:00  \_ hostname
root        2930  0.0  0.0 1228744 3596 ?        Ssl  09:24   0:00 /bin/gops stats 1
root        2915  0.0  0.0 1228744 3600 ?        Ssl  09:24   0:00 /bin/gops pprof-cpu 1
root           1  4.7  4.7 1404828 188316 ?      Ssl  09:17   0:21 cilium-agent --config-dir=/tmp/cilium/config-map
root         544  0.0  0.1 1228848 4720 ?        Sl   09:17   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
