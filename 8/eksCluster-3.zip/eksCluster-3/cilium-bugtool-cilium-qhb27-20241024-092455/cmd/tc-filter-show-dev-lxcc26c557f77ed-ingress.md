filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc26c557f77ed direct-action not_in_hw id 3672 tag 1c49d17012099026 jited 
