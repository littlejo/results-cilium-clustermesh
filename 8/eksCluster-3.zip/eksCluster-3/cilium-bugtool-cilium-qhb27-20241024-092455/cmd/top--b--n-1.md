top - 09:24:57 up 8 min,  0 users,  load average: 0.29, 0.49, 0.35
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.8 us, 30.8 sy,  0.0 ni, 61.5 id,  0.0 wa,  0.0 hi,  3.8 si,  0.0 st
MiB Mem :   3836.2 total,   1010.0 free,    722.0 used,   2104.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2937.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   2944 root      20   0 1240432  16468  11228 S   6.7   0.4   0:00.02 cilium-+
      1 root      20   0 1404828 188316  78772 S   0.0   4.8   0:21.02 cilium-+
    544 root      20   0 1228848   4720   3844 S   0.0   0.1   0:00.01 cilium-+
   2915 root      20   0 1228744   3600   2912 S   0.0   0.1   0:00.00 gops
   2930 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2945 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   2980 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2998 root      20   0 1228744   3596   2912 S   0.0   0.1   0:00.00 gops
   3010 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
   3016 root      20   0 1242420   6916   6188 R   0.0   0.2   0:00.00 hubble
