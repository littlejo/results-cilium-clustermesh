{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:34.136Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:34.164Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.521Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.526Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.560Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.568Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.600Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.796Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.798Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.830Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.861Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.894Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.215Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.252Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.265Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.293Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.304Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.327Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.548Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.560Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.592Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.638Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.641Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.950Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:41.990Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.007Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.030Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.045Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.067Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.305Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.315Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.353Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.363Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.392Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.731Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.802Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.806Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.841Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.855Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.875Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.096Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.112Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.152Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.162Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.190Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.492Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.536Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.537Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.576Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.589Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.621Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.804Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.825Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.847Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.860Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.892Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.150Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.190Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.206Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.265Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.303Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.316Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.512Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.523Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.562Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.565Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.602Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.892Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.895Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.936Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.939Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:52.966Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.161Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.188Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.190Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.191Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.198Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.812Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.813Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.850Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.880Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:57.888Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.149Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:58.151Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:06.738Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:06.749Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:08.110Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:14.805Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:15.065Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:21.881Z",
  "value": "id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:22.135Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:22.142Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:22.144Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:28.873Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:28.917Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:28.925Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.173Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.178Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:29.180Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:35.880Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:35.972Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:35.977Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.197Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.213Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:36.214Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.095Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.144Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.149Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.418Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.419Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:49.435Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.339Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.375Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.398Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.655Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.656Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:02.667Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:15.562Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:15.611Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:15.613Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:15.926Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:15.927Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:32.808Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:32.808Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:33.077Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:33.083Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:45.998Z",
  "value": "id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.3.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:46.004Z",
  "value": "id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED"
}

