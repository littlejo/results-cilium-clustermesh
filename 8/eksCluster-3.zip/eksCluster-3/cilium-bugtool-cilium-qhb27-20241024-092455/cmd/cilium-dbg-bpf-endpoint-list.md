IP ADDRESS        LOCAL ENDPOINT INFO
172.31.224.68:0   (localhost)                                                                                       
10.3.0.83:0       id=1013  sec_id=4     flags=0x0000 ifindex=7   mac=B6:F1:4B:E4:FC:14 nodemac=DA:0E:3B:EB:13:74    
10.3.0.118:0      id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7   
10.3.0.112:0      id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED   
10.3.0.201:0      id=535   sec_id=292468 flags=0x0000 ifindex=9   mac=32:6E:39:99:63:62 nodemac=FA:49:CD:E7:F2:87   
10.3.0.86:0       id=1768  sec_id=292468 flags=0x0000 ifindex=11  mac=5E:22:A1:7B:D7:51 nodemac=96:57:40:CF:8E:3A   
10.3.0.17:0       (localhost)                                                                                       
10.3.0.36:0       id=2870  sec_id=286632 flags=0x0000 ifindex=15  mac=62:1D:9C:67:6F:5A nodemac=B6:50:D6:81:C5:52   
10.3.0.104:0      id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9   
