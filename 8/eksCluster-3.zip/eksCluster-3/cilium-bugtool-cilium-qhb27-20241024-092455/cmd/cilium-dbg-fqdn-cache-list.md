Endpoint   Source   FQDN               TTL   ExpirationTime             IPs                                         
830        lookup   cilium.io.         28    2024-10-24T09:25:11.807Z   104.198.14.52                               
830        lookup   one.one.one.one.   20    2024-10-24T09:24:53.280Z   2606:4700:4700::1001,2606:4700:4700::1111   
830        lookup   one.one.one.one.   20    2024-10-24T09:24:53.279Z   1.1.1.1,1.0.0.1                             
490        lookup   one.one.one.one.   13    2024-10-24T09:24:52.627Z   1.0.0.1,1.1.1.1                             
490        lookup   one.one.one.one.   13    2024-10-24T09:24:52.627Z   2606:4700:4700::1111,2606:4700:4700::1001   
490        lookup   cilium.io.         30    2024-10-24T09:25:11.759Z   104.198.14.52                               
