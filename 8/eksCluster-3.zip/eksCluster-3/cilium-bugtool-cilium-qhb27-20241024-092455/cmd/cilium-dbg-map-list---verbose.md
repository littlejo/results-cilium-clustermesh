## Map: cilium_policy_02870
Key              Value           State   Error
Ingress: 0 ANY   0 2039 217675           
Egress: 0 ANY    0 2410 262288           
Ingress: 1 ANY   0 2142 206707           

## Map: cilium_policy_00679
Key              Value           State   Error
Ingress: 0 ANY   0 33 4408               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3536 302838           

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
10.3.0.17/32        identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.168.34/32    identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.6.0.102/32       identity=6 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
172.31.249.58/32    identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
172.31.224.68/32    identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
172.31.162.53/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>         sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=172.31.162.53, flags=<none>    sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    

## Map: cilium_tunnel_map
Key        Value              State   Error
10.0.0.0   172.31.190.177:0   sync    
10.2.0.0   172.31.140.200:0   sync    
10.6.0.0   172.31.162.53:0    sync    
10.4.0.0   172.31.167.173:0   sync    
10.7.0.0   172.31.208.9:0     sync    
10.5.0.0   172.31.249.188:0   sync    
10.1.0.0   172.31.234.224:0   sync    

## Map: cilium_policy_00671
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_00535
Key              Value         State   Error
Ingress: 0 ANY   0 67 5968             
Egress: 0 ANY    0 112 11288           
Ingress: 1 ANY   0 480 41579           

## Map: cilium_policy_00490
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378440255859375           
AgentLiveness   517607341319               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_lxc
Key               Value                                                                                             State   Error
10.3.0.17:0       (localhost)                                                                                       sync    
172.31.224.68:0   (localhost)                                                                                       sync    
10.3.0.118:0      id=490   sec_id=296497 flags=0x0000 ifindex=19  mac=52:82:FC:5E:0F:95 nodemac=EE:CF:34:D3:54:B7   sync    
10.3.0.104:0      id=679   sec_id=268163 flags=0x0000 ifindex=21  mac=52:C0:E9:B7:5B:6B nodemac=6E:D0:F5:E5:FF:C9   sync    
10.3.0.201:0      id=535   sec_id=292468 flags=0x0000 ifindex=9   mac=32:6E:39:99:63:62 nodemac=FA:49:CD:E7:F2:87   sync    
10.3.0.86:0       id=1768  sec_id=292468 flags=0x0000 ifindex=11  mac=5E:22:A1:7B:D7:51 nodemac=96:57:40:CF:8E:3A   sync    
10.3.0.83:0       id=1013  sec_id=4     flags=0x0000 ifindex=7   mac=B6:F1:4B:E4:FC:14 nodemac=DA:0E:3B:EB:13:74    sync    
10.3.0.112:0      id=830   sec_id=281016 flags=0x0000 ifindex=17  mac=FA:FB:B1:FF:1C:B2 nodemac=3A:E8:65:32:D4:ED   sync    
10.3.0.36:0       id=2870  sec_id=286632 flags=0x0000 ifindex=15  mac=62:1D:9C:67:6F:5A nodemac=B6:50:D6:81:C5:52   sync    

## Map: cilium_lb4_services_v2
Key                       Value                State   Error
10.100.0.10:9153 (1)      4 0 (3) [0x0 0x0]    sync    
10.100.37.13:8080 (0)     0 1 (6) [0x0 0x0]    sync    
10.100.37.13:8080 (1)     10 0 (6) [0x0 0x0]   sync    
10.100.0.1:443 (0)        0 2 (1) [0x0 0x0]    sync    
10.100.229.85:443 (0)     0 1 (2) [0x0 0x10]   sync    
10.100.0.10:53 (0)        0 2 (4) [0x0 0x0]    sync    
10.100.244.114:2379 (1)   9 0 (5) [0x0 0x0]    sync    
10.100.229.85:443 (1)     2 0 (2) [0x0 0x0]    sync    
10.100.0.10:53 (1)        3 0 (4) [0x0 0x0]    sync    
10.100.0.10:9153 (2)      6 0 (3) [0x0 0x0]    sync    
10.100.0.1:443 (2)        7 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (1)        1 0 (1) [0x0 0x0]    sync    
10.100.0.10:9153 (0)      0 2 (3) [0x0 0x0]    sync    
10.100.0.10:53 (2)        5 0 (4) [0x0 0x0]    sync    
10.100.244.114:2379 (0)   0 1 (5) [0x0 0x0]    sync    

## Map: cilium_policy_01768
Key              Value         State   Error
Ingress: 0 ANY   0 57 5408             
Egress: 0 ANY    0 117 11703           
Ingress: 1 ANY   0 459 39877           

## Map: cilium_lb4_backends_v3
Key   Value                 State   Error
7     ANY://172.31.168.34   sync    
9     ANY://10.3.0.36       sync    
4     ANY://10.3.0.201      sync    
5     ANY://10.3.0.86       sync    
6     ANY://10.3.0.86       sync    
10    ANY://10.3.0.104      sync    
1     ANY://172.31.249.58   sync    
2     ANY://172.31.224.68   sync    
3     ANY://10.3.0.201      sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_policy_01013
Key              Value         State   Error
Ingress: 0 ANY   0 293 23570           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 67 5866             

## Map: cilium_lb4_reverse_nat
Key   Value                 State   Error
1     10.100.0.1:443        sync    
2     10.100.229.85:443     sync    
3     10.100.0.10:9153      sync    
4     10.100.0.10:53        sync    
5     10.100.244.114:2379   sync    
6     10.100.37.13:8080     sync    

## Map: cilium_policy_00830
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


