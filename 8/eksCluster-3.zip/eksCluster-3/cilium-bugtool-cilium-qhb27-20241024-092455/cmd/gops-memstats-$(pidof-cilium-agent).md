alloc: 45.80MB (48020840 bytes)
total-alloc: 1.43GB (1533248144 bytes)
sys: 108.49MB (113757492 bytes)
lookups: 0
mallocs: 46499604
frees: 46119256
heap-alloc: 45.80MB (48020840 bytes)
heap-sys: 93.41MB (97951744 bytes)
heap-idle: 28.05MB (29417472 bytes)
heap-in-use: 65.36MB (68534272 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 380348
stack-in-use: 6.56MB (6881280 bytes)
stack-sys: 6.56MB (6881280 bytes)
stack-mspan-inuse: 1.02MB (1064800 bytes)
stack-mspan-sys: 1.23MB (1289280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 723.73KB (741097 bytes)
gc-sys: 4.65MB (4872800 bytes)
next-gc: when heap-alloc >= 84.74MB (88860856 bytes)
last-gc: 2024-10-24 09:25:04.721410681 +0000 UTC
gc-pause-total: 6.96462ms
gc-pause: 57806
gc-pause-end: 1729761904721410681
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0006921841115070704
enable-gc: true
debug-gc: false
