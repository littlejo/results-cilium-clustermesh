 09:24:57 up 8 min,  0 users,  load average: 0.29, 0.49, 0.35
