172.31.234.224 dev ens5 lladdr 12:32:69:1c:56:3b REACHABLE
172.31.192.1 dev ens5 lladdr 12:77:39:73:55:d5 REACHABLE
172.31.208.9 dev ens5 lladdr 12:92:ce:3b:56:0b REACHABLE
172.31.249.58 dev ens5 lladdr 12:ea:97:c6:0c:b5 REACHABLE
172.31.249.188 dev ens5 lladdr 12:cf:9a:37:81:39 REACHABLE
