goroutine 163 [running]:
runtime/pprof.writeGoroutineStacks({0xffff6fd44000, 0x4000fa4000})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6c
runtime/pprof.writeGoroutine({0xffff6fd44000?, 0x4000fa4000?}, 0x10?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x2c
runtime/pprof.(*Profile).WriteTo(0x61dd090?, {0xffff6fd44000?, 0x4000fa4000?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x148
github.com/google/gops/agent.handle({0xffff6fd437a8, 0x4000fa4000}, {0x400182c8ed?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x23a0
github.com/google/gops/agent.listen({0x3e0bbf0, 0x40007ce5c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x188
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x320

goroutine 1 [select, 7 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x40001b4d20, 0x40017b9c50)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x104
github.com/cilium/hive.(*Hive).Run(0x40001b4d20, 0x40017b9c50)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0xe8
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x4000152608, {0x377b213?, 0x4?, 0x377b083?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x170
github.com/spf13/cobra.(*Command).execute(0x4000152608, {0x400006e050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0x828
github.com/spf13/cobra.(*Command).ExecuteC(0x4000152608)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x344
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0x40001b4d20?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x1c
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x64

goroutine 44 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40009a9560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 12 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4000f8c9d0, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000f8c9c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0x4002335f20, {0x3e23828, 0x40028203c0})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xfc
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x10c
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x15c

goroutine 13 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x138
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 7 [select, 7 minutes]:
io.(*pipe).read(0x40007fa120, {0x4001d2e000, 0x10000, 0x0?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001d2e000?, 0x400009b678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000c03f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e540, 0x40007fa120, 0x40017b9bd0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 8 [select, 7 minutes]:
io.(*pipe).read(0x40007fa240, {0x4001d3e000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001d3e000?, 0x4000095678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000c05f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e540, 0x40007fa240, 0x40017b9bf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 9 [select, 7 minutes]:
io.(*pipe).read(0x40007fa2a0, {0x4001d4e000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001d4e000?, 0x4000c06e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000c06f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e540, 0x40007fa2a0, 0x40017b9c10)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 10 [select, 7 minutes]:
io.(*pipe).read(0x40007fa300, {0x4001d5e000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001d5e000?, 0x4000096678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000c07f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x400029e540, 0x40007fa300, 0x40017b9c30)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 11 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x5c
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x8c

goroutine 155 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001cb19a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 157 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001cb1b80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 158 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x74
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x70

goroutine 159 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001cb1c20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1502 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40004a62d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000ce9540, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40015bcec0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1499 [select, 2 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x3cc
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa8

goroutine 1603 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001959e50?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1452
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1584 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002824960)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1452
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1447 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40008bfa40, {{{0x37b1743, 0x12}}, {0x0, 0x0}, 0x4001b06830, 0x0, 0x4001b06840, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 159
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2513 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076db50, {0x3e23828, 0x4003e6c1e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2503
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1604 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002385cc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40026cd500}, 0x400029efc0, 0x0, 0x4000a41170, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1452
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1641 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002431040, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4000801360, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1599
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1411 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1390
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 164 [select, 6 minutes]:
github.com/cilium/statedb.graveyardWorker(0x400250f490, {0x3e23828, 0x4002836550}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x12c
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x14c

goroutine 184 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400055b680, {{{0x379a274, 0xd}}, {0x0, 0x0}, 0x40007ce9a0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 260 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x15, 0x400204fe90, 0x10000, 0x0, 0x4002345c70, 0x400204fe44)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x59c?, {0x400204fe90?, 0x0?, 0x100000059c?}, 0x0?, 0x4003b28010?, 0x58c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x15, {0x400204fe90, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x400205fee8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x70
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x304

goroutine 182 [IO wait]:
internal/poll.runtime_pollWait(0xffff70202db8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400281d200?, 0x4002ab4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400281d200, {0x4002ab4000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400281d200, {0x4002ab4000?, 0x40007ce8a0?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400132ab90, {0x4002ab4000?, 0x4002877868?, 0x1fd48?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4002352bd0, {0x4002ab4000?, 0x0?, 0x4002352bd0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40018609b0, {0x3dd1940, 0x4002352bd0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4001860708, {0xffff6fe6fa00, 0x40018c4030}, 0x40028779d0?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4001860708, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4001860708, {0x40022fe000, 0x1000, 0x4002704000?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4002517d40, {0x4001866200, 0x9, 0x80?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4002517d40}, {0x4001866200, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001866200, 0x9, 0x2877da8?}, {0x3dcc0a0?, 0x4002517d40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x40018661c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
golang.org/x/net/http2.(*clientConnReadLoop).run(0x4002877f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xd0
golang.org/x/net/http2.(*ClientConn).readLoop(0x40000cd680)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x80
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 181
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xae0

goroutine 186 [select, 7 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e54fc0, {0x3e237f0, 0x4002851b00}, {0x3e2b960, 0x40025d0240})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x294
github.com/cilium/hive/job.(*jobOneShot).start(0x40025d1260, {0x3e237f0, 0x4002851b00}, 0xba7cf0?, {0x3e2b960, 0x40025d0f00}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 236 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 264
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 253 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0x4001a51860, {0x3e23828?, 0x4000801d60?}, 0x4000ab9880)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xa4
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x3c
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x304

goroutine 255 [chan receive, 7 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x2c
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x108

goroutine 232 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400177a4e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 253
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 423 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e70e80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 257 [chan receive, 7 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x2c
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x108

goroutine 1568 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff70202bc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x34?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40026b3080)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40026b3080)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001233b28?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40004a0db0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4002f29200, {0x3e0bc20, 0x40004a0db0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4c
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x2fc8

goroutine 1581 [chan receive, 7 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x3adc

goroutine 1503 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x13d4900?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40032e4f90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 467 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 457
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1362 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40004fe3c0, {0x3e237f0, 0x40019ece70}, 0x0?, {0x3e2b960, 0x40004fe240}, {{{0x4000cca960, 0x1, 0x1}}, 0x40017a9ec0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 958 [select, 2 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0x4001513dc0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x1d4
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 866
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x68

goroutine 258 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x14, 0x4002023940, 0x10000, 0x0, 0x4003ba0d90, 0x40020238f4)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x74?, {0x4002023940?, 0x0?, 0x600001800000074?}, 0x0?, 0x4003f86510?, 0x64?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x14, {0x4002023940, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x15?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x74
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x30c

goroutine 254 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x40019e8420, 0x4000e196e0, 0x4000e197a0, 0x4000e19800)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x1d0
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x40019e8420, {0x3e23828?, 0x4000789090?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x3d8
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x40019e8420, {0x3e23828, 0x4000789090})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x70
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x120

goroutine 421 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40010cf800?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 429 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000ceb680)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 468 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 457
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1407 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1419 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 231 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400177a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 253
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1363 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x40007faba0, {0x3e237f0, 0x40019ecf00}, 0x0?, {0x3e2b960, 0x40004fe240}, {{{0x4000cca960, 0x1, 0x1}}, 0x40017a9ec0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 234 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 253
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1480 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002362b60, 0x4000bb3260, 0x4001932660, 0x40013b73e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1461
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 855 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002740a80, 0x40013e3440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002740a80, 0x8a6d4?, 0x4001a15360?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 870
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 256 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x13, 0x4002003db0, 0x10000, 0x0, 0x40022bae70, 0x4002003d64)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x50?, {0x4002003db0?, 0x0?, 0x1400000050?}, 0x0?, 0x4004066290?, 0x40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x13, {0x4002003db0, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x4004066290?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x70
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x30c

goroutine 427 [select, 7 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e55100, {0x3e237f0, 0x4001c1daa0}, {0x3e2b960, 0x40014403c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x298
github.com/cilium/hive/job.(*jobOneShot).start(0x4002370660, {0x3e237f0, 0x4001c1daa0}, 0x4001363c20?, {0x3e2b960, 0x40023703c0}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 175 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x40019e84f8, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019e84e8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40019e84d0, 0x400109e340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40018b0320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000db4ec0, {0x3ddab40, 0x40019ed5f0}, 0x1, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4000db4ec0, 0x3b9aca00, 0x0, 0x1, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40018b0320, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000c623e0, 0x400203eea0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 167
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 176 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 167
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 259 [chan receive, 7 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x2c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 254
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x100

goroutine 466 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x38
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 452
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0x88

goroutine 210 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 175
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 668 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0x40003ed040, 0x4001455c80, 0x4000a41380)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x160

goroutine 212 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 175
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 213 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400562b680}, {0xffff6fe6fe08, 0x40019e84d0}, {0x3e672a8, 0x371cf40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40015f20e0, {0x0?, 0x0?}, 0x400203eea0, 0x400120ec00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40015f20e0, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000c3df40, {0x3ddab60, 0x40021019f0}, 0x1, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40015f20e0, 0x400203eea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 175
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1424 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 481
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 226 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40015f20e0, 0x400203eea0, 0x40011919e0, 0x400120ec00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 213
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1444 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400151c648, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400151c638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400151c630, {0x400476c5cc, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40032edcc8?}, {0x400476c5cc?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x400151c600}, {0x400476c5cc, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40018c4348, {0x4000f02800, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000cacf00, 0x0, {0x3e02238, 0x4005150180})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000c62c20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400164f500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1359
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 422 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000c32480?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 233 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x400164fa10, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400164fa00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400177a360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4afc0, {0x3e23828, 0x4000798460}, 0x400259a480, {0x3e3b518, 0x400186ac30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 253
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 428 [chan receive, 7 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x400012fea0, {0x3e23828, 0x40004f4280})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x60
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x134

goroutine 10872 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40030aac00, 0x400164ca20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40030aac00, 0x8a6d4?, 0x400164f580?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 213
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 261 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff70202cc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4000af91a0?, 0x4002087e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4000af91a0, {0x4002087e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4001938a60, {0x4002087e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4001543300)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 262 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003eda40, {{{0x379eee1, 0xe}}, {0x0, 0x0}, 0x40015bc0c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 263 [select, 7 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0x4001c53d40)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0xc0
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x318

goroutine 264 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x3e237f0, 0x400245f6b0}, {0x3e62c10, 0x400244b490}, {0x3e2b960, 0x4000af94a0}, 0x1, 0x40001b4640, 0x400206bd50, 0x400206bd40, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x5c4
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x3e237f0, 0x400245f6b0}, {0x3e2b960, 0x4000af94a0})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0xdc
github.com/cilium/hive/job.(*jobOneShot).start(0x40025d1da0, {0x3e237f0, 0x400245f6b0}, 0x4?, {0x3e2b960, 0x40025d1d40}, {{{0x4001abaf00, 0x1, 0x1}}, 0x4001a3e6d0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1423 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x40019e8bd8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019e8bc8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40019e8bb0, 0x40019dd780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40030daf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032e2ec0, {0x3ddab40, 0x400243b650}, 0x1, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40032e2ec0, 0x3b9aca00, 0x0, 0x1, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40030daf00, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001afbc00, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 481
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1479 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400151c780, 0x4002419d40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400151c780, 0x8a6d4?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1414
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1414 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40015429c0}, {0xffff6fe6fe08, 0x40019e8a50}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40023621c0, {0x0?, 0x0?}, 0x4000bb2000, 0x40013b70e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40023621c0, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002211f40, {0x3ddab60, 0x4000798280}, 0x1, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40023621c0, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1390
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1359 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400164f500}, {0xffff6fe6fe08, 0x4002646210}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40015f2a80, {0x0?, 0x0?}, 0x400203e900, 0x40013b6d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40015f2a80, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029ebf40, {0x3ddab60, 0x4002836f00}, 0x1, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40015f2a80, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1353
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 10663 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002e3af48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002e3af38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002e3af30, {0x4002d53400, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40032e5cc8?}, {0x4002d53400?, 0x2?, 0x18f3c?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002b3dcc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002b3dcc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002b3dcc0, {0x30150e0, 0x40043e95c0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40022caf00, {0x40023fe800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003651900, 0x0, {0x3e02238, 0x400145bc40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001c305e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400145bc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1461
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1441 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005575840}, {0xffff6fe6fe08, 0x40026469a0}, {0x3e672a8, 0x3722640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001866fc0, {0x0?, 0x0?}, 0x4001baa660, 0x40013b76e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001866fc0, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400220bf40, {0x3ddab60, 0x4000cacd20}, 0x1, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001866fc0, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1428
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1472 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1433
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1577 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40016eee50, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40016eee40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x400238bb00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x4000762230}, 0x40023462a0, {0x3e3b570, 0x400186b260})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1362
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1383 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400030c3c0, {{{0x378dd05, 0xa}}, {0x0, 0x0}, 0x40015ecbc0, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 420 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000ce9a40, {{{0x3791109, 0xb}}, {0x3e2b960, 0x40012ea960}, 0x4001c34540, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1410 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1386
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 451 [select]:
golang.org/x/time/rate.(*Limiter).wait(0x40042f42d0, {0x3e23828, 0x40004f4280}, 0x1, {0x400224d918?, 0x1e301d0?, 0x6279580?}, 0x39bb3e8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:285 +0x320
golang.org/x/time/rate.(*Limiter).WaitN(0x40042f42d0, {0x3e23828, 0x40004f4280}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:248 +0x54
golang.org/x/time/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:233
github.com/cilium/cilium/pkg/node/manager.(*manager).singleBackgroundLoop(0x4000370600, {0x3e23828, 0x40004f4280}, 0x1eb1e32e50)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:429 +0x114
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x4000370600, {0x3e23828, 0x40004f4280})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:398 +0x1f8
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x78
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 428
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x50

goroutine 1418 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x40019e8b28, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019e8b18)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40019e8b00, 0x40019dd740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40030dae60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40032e0ec0, {0x3ddab40, 0x400243acf0}, 0x1, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40032e0ec0, 0x3b9aca00, 0x0, 0x1, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40030dae60, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001afbba0, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 452 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff702028e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x18?, 0x2be7f19?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400011aa80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400011aa80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001ce6dc8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001c4fc20)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x400199a300, {0x3e23828, 0x4000890e10}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xbc
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x144

goroutine 453 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0xffff70202500, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1b?, 0x967e0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400011ac00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400011ac00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4001235d98?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).AcceptUnix(0x4001c4fdd0)
	/usr/local/go/src/net/unixsock.go:247 +0x2c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x124

goroutine 454 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x38
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x184

goroutine 455 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff702027e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1d?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400011ad80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400011ad80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x400287bc48?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001d86000)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4001484800, {0x3e0bc20, 0x4001d86000})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x19c

goroutine 456 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40018b19a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 457 [select, 6 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x4001767320, {0x3e237f0, 0x4001d876b0}, {0x3e2b960, 0x40012eb980})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x2d8
github.com/cilium/hive/job.(*jobOneShot).start(0x40023710e0, {0x3e237f0, 0x4001d876b0}, 0x4001362ea0?, {0x3e2b960, 0x4002370de0}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 865 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4000ab5ba8, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4000ab5b98)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4000ab5b80, 0x40018563c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad3220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4000c3fe00, {0x3ddab40, 0x400137fce0}, 0x1, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a58e00, 0x3b9aca00, 0x0, 0x1, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad3220, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x400186ee80, 0x4002413440)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0xa8
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x40011a9c80, {0x0?, 0x0?}, {0x3e148d0, 0x4001513e78}, 0x4002413440)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x480
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 839
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 1461 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400145bc00}, {0xffff6fe6fe08, 0x40019e8b00}, {0x3e672a8, 0x3703740}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002362b60, {0x0?, 0x0?}, 0x4000bb3260, 0x40013b73e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002362b60, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002213f40, {0x3ddab60, 0x4000798c80}, 0x1, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002362b60, 0x4000bb3260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1418
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 680 [select, 7 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x14c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x15c

goroutine 1397 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000d23380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1580 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff6fec1ec8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x3a?, 0x4001a33d40?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40026b3c00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40026b3c00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001c31060)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001c31060)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4002f29600, {0x3e0bbf0, 0x4001c31060})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x54
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x3a7c

goroutine 1570 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff702029d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400238afc0?, 0x4002969e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400238afc0, {0x4002969e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x40010ab5c8, {0x4002969e2b?, 0x0?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40016eedc0)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1529
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1579 [select, 6 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x110
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1572
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x200

goroutine 1506 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1344
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 482 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 625 [select, 6 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x40014fd600)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x74
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x60

goroutine 653 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 649
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1391 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1478 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40023621c0, 0x4000bb2000, 0x40004fbbc0, 0x40013b70e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 8899 [select, 1 minutes]:
reflect.rselect({0x4001553560, 0x9, 0xffff6fede148?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4002d43200?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001d86660, {0x3e237f0, 0x40010c6a20}, 0x40003c1b90, {0xffff6fd3d2c8, 0x4001709210}, 0x4002d35560, {0x381b81a?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001d86660, {0x3e237f0, 0x40010c6a20}, {0xffff6fd3d2c8, 0x4001709210}, {0x381b81a, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0x4001d86660, {0x3e3e378, 0x4001709210})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:144 +0x78
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x365dfc0?, 0x4001d86660}, {0x3e32818, 0x4004ac73b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1711 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001484800, {0x3e237f0, 0x40010c6930}, {0x3e42860, 0x40033ba180}, 0x40016d58c0, 0x4001d869c0, 0x6217f00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001484800, {0x3e42860, 0x40033ba180}, 0x40016d58c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1390 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40019e8a78, 0x16)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019e8a68)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40019e8a50, 0x40019dd4c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40030dac80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029a5ec0, {0x3ddab40, 0x4002409e90}, 0x1, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40032fbec0, 0x3b9aca00, 0x0, 0x1, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40030dac80, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001afb780, 0x4000bb2000)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1672 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000bbc550})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002dc68c0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001845180, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1509
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2514 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076db80, {0x3e23828, 0x4003e6c230})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2503
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1388 [syscall, 7 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x30
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x1c
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x28

goroutine 1386 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x40007980f0, {0x3e237f0, 0x4002408750}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x414
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x40019dd600, {0x3e237f0, 0x4002408750}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x74
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x3e237f0, 0x4002408750}, {{{}}, 0x400250f490, {0x3e5d368, 0x400250f500}, {0x3e24e30, 0x40027ff9e0}, 0x400118dce0}, 0x40013037c0)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:85 +0x244
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x3e237f0?, 0x4002408750?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x40
github.com/cilium/hive/job.(*jobOneShot).start(0x4002832f60, {0x3e237f0, 0x4002408750}, 0x0?, {0x3e2b960, 0x4002832f00}, {{{0x40007ce440, 0x1, 0x1}}, 0x40018fafa0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1576 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400238bc20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1362
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1405 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000d23800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 629 [select, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0x4001625ac0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xa4
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x20c

goroutine 630 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e726e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 645 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x400238bf20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1571 [select, 7 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x4000e39b00)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0x90
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1529
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1f8

goroutine 628 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff70202ad0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40022b7500?, 0x40029d5e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40022b7500, {0x40029d5e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4000d260c8, {0x40029d5e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4001625a80)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 646 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x4000c39900}, 0x400203d9e0, {0x3e3b4c0, 0x4000da8d20})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x4dc
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 957 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x120
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 956
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 2606 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e23828, 0x4003e37c70}, 0x400122ca80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2554
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 657 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0x40003ed040)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0xd4
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x5c

goroutine 649 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x40019e9e68, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019e9e58)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40019e9e40, 0x40014acc00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001cb17c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400260bec0, {0x3ddab40, 0x4000a3c030}, 0x1, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400260bec0, 0x3b9aca00, 0x0, 0x1, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001cb17c0, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001aac380, 0x400203dd40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 230
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 642 [select, 7 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 632
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xc0

goroutine 640 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000ce7a40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 650 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 230
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1673 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4000bb3701?, 0x39bbdc8?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001a7ef40?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1509
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 639 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4001392b40?, 0x7a2bb0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x40017a4780?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 656 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40013116c0}, {0xffff6fe6fe08, 0x40019e9e40}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40015f3500, {0x0?, 0x0?}, 0x400203dd40, 0x40023e8a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40015f3500, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029f1f40, {0x3ddab60, 0x4000c39b30}, 0x1, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40015f3500, 0x400203dd40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 649
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 676 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400151d800, 0x400127c7e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400151d800, 0x8a6d4?, 0x40017a5980?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 656
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 636 [select, 1 minutes]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x40004fe120, {0x3e237f0, 0x4000c0f080}, {0x3e2b960, 0x400238aa20})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x3c4
github.com/cilium/hive/job.(*jobOneShot).start(0x40004fe180, {0x3e237f0, 0x4000c0f080}, 0x0?, {0x3e2b960, 0x40025d0c60}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 655 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 649
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 675 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40015f3500, 0x400203dd40, 0x400203df80, 0x40023e8a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 656
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 635 [syscall]:
syscall.Syscall6(0x16, 0x1a, 0x4001c44fc0, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x6207cb0?, {0x4001c44fc0?, 0x40000ba120?, 0x40029f59e0?}, 0x40029f5a58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x4001a5e080, {0x4001c44fc0, 0x2, 0x2}, {0x4002850030?, 0x32d640?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4002108f00, 0x40029f5bd8)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(0x4000419810?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x38
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x78
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x128

goroutine 1426 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x400164e690, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400164e680)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000d238c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ac40, {0x3e23828, 0x40028379f0}, 0x40000c7140, {0x3e3b2b0, 0x4001a12168})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 666 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400151d848, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400151d838)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400151d830, {0x4002366001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400329fcc8?}, {0x4002366001?, 0x400329fcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x400162f400)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x400162f400)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x400162f400, {0x30150e0, 0x40011d5608})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40008e5950, {0x40025f3500, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40008015e0, 0x0, {0x3e02238, 0x4005575900})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a5ed40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40013116c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 656
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 634 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001995e60, {0x3e237f0, 0x40004a08d0}, 0x40016a54a0?, {0x3e2b960, 0x4001995b60}, {{{0x4001b78be0, 0x1, 0x1}}, 0x40016cc690, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1398 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x400109f110, 0x22)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400109f100)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000d23200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4adc0, {0x3e23828, 0x4002837720}, 0x40000c6b40, {0x3e3b3b8, 0x400186be48})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 677 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40026924c8, 0x17)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40026924b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40026924b0, {0x40038b5df4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002a92cc8?}, {0x40038b5df4?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x4002692480}, {0x40038b5df4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4000da92c0, {0x4002775400, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000c39d60, 0x0, {0x3e02238, 0x4004541dc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001aacd20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40014ad480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 746
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 633 [chan receive, 7 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c1e0, {0x3e237f0, 0x40004a0780}, 0x3ddaba0, {0x3e2b960?, 0x4001995b60}, {{{0x4001b78be0, 0x1, 0x1}}, 0x40016cc690, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1460 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1418
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1413 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1390
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 632 [chan receive, 7 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c220, {0x3e237f0, 0x40002466c0}, 0x3dcc2c0, {0x3e2b960?, 0x4001995b60}, {{{0x4001b78be0, 0x1, 0x1}}, 0x40016cc690, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 644 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400238be00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 895 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002740ac8, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002740ab8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002740ab0, {0x4002e12001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003f33cc8?}, {0x4002e12001?, 0x4003f33cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002b3d040)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002b3d040)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002b3d040, {0x30150e0, 0x4001b0d4d0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4001388c90, {0x4002773000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000bbd0e0, 0x0, {0x3e02238, 0x4004540680})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x400186fd20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001856b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 870
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 647 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 661 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400162edc0, {{{0x37ce973, 0x19}}, {0x0, 0x0}, 0x4001dba860, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 662 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff70202218, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x29?, 0x577a34?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400031c500)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400031c500)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001a5ebe0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001a5ebe0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
github.com/cilium/dns.(*Server).serveTCP(0x400272f900, {0x3e0bbf0, 0x4001a5ebe0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0xe4
github.com/cilium/dns.(*Server).ActivateAndServe(0x400272f900)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x208
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x400272f900)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 663 [IO wait]:
internal/poll.runtime_pollWait(0xffff70202310, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400031c600?, 0x4001771000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x400031c600, {0x4001771000, 0x200, 0x200}, {0x400240b920, 0x2c, 0x2c}, 0x0, 0x400217d818)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x254
net.(*netFD).readMsgInet4(0x400031c600, {0x4001771000?, 0x400217d808?, 0x71368?}, {0x400240b920?, 0x71374?, 0x400217d7d8?}, 0x1ea1c?, 0x400217d7f8?)
	/usr/local/go/src/net/fd_posix.go:84 +0x2c
net.(*UDPConn).readMsg(0x31926c0?, {0x4001771000?, 0x1a7?, 0x2?}, {0x400240b920?, 0x10?, 0x400217d918?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x124
net.(*UDPConn).ReadMsgUDPAddrPort(0x4000d262b8, {0x4001771000?, 0xffff70202310?, 0x77359136?}, {0x400240b920?, 0x2a69c84?, 0x4000c11c20?})
	/usr/local/go/src/net/udpsock.go:203 +0x34
net.(*UDPConn).ReadMsgUDP(0x4000c11c20?, {0x4001771000?, 0x0?, 0x40018442c0?}, {0x400240b920?, 0x2a098e0?, 0x10?})
	/usr/local/go/src/net/udpsock.go:191 +0x24
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x4000d262b8?, 0x4000d262b8)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x5c
github.com/cilium/dns.(*Server).readUDP(0x400272fa00, 0x4000d262b8, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0x140
github.com/cilium/dns.defaultReader.ReadUDP({0x61df4d0?}, 0x318dd00?, 0x40022faab8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x1c
github.com/cilium/dns.(*Server).serveUDP(0x400272fa00, {0x3e35e70, 0x4000d262b8})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x20c
github.com/cilium/dns.(*Server).ActivateAndServe(0x400272fa00)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x178
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x400272fa00)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 1396 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000d23200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1477 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400151c600, 0x4002418ea0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400151c600, 0x8a6d4?, 0x40030c3200?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1359
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 670 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002316900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 671 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002316a80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 672 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400123e590, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400123e580)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002316900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ae40, {0x3e23828, 0x4000801770}, 0x4002346540, {0x3e3b410, 0x4001834c60})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 689 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 690 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0x9c
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1d4

goroutine 1370 [select, 2 minutes]:
github.com/cilium/hive/job.(*jobTimer).start(0x4002751740, {0x3e237f0, 0x40019ed590}, 0x0?, {0x3e2b960, 0x40027516e0}, {{{0x4000c9f640, 0x1, 0x1}}, 0x4000cd9330, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1368 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400030c280, {{{0x37b8e08, 0x14}}, {0x3e2b960, 0x4000c81b60}, 0x4001c419a0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 693 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002316b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 694 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002316cc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 695 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400123e9d0, 0x24)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400123e9c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002316b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40008018b0}, 0x4002346780, {0x3e3b258, 0x4001834d80})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 696 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 697 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xac
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1fc

goroutine 698 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0x4001816000, {0x3e23828, 0x40019040f0}, 0x4001455c70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x2bc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x2ec

goroutine 699 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0x4001816a20, {0x3e23828, 0x40019040f0}, 0x4001455c70)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x220
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x118

goroutine 1402 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400109f510, 0x19e)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400109f500)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000d23440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ad40, {0x3e23828, 0x4002837810}, 0x40000c6cc0, {0x3e3b360, 0x400186bef0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 701 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x100
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 699
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x1d8

goroutine 702 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4002346960)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 699
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1505 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000ce9900, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40015bd390, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 704 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002316ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 705 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002317020)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 668
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 706 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400123ee90, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400123ee80)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002316ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x4000801c20}, 0x4002346a80, {0x3e3b570, 0x4001834ee8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 668
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 707 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 668
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1428 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x40026469c8, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40026469b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40026469a0, 0x400164efc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4002824280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40021ffec0, {0x3ddab40, 0x4002423500}, 0x1, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40021ffec0, 0x3b9aca00, 0x0, 0x1, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4002824280, 0x4001baa660)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000c626a0, 0x4001baa660)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 709 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002647578, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002647568)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002647550, 0x400123f000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad2280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a4eec0, {0x3ddab40, 0x4000b95800}, 0x1, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a4eec0, 0x3b9aca00, 0x0, 0x1, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad2280, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a5f000, 0x40023479e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 461
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 710 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 461
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 869 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 865
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 713 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 691
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xcc

goroutine 1343 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x100
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb0

goroutine 1429 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 717 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002647628, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002647618)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002647600, 0x400123f080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad2320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002ad7ec0, {0x3ddab40, 0x4000d9a1b0}, 0x1, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a39ec0, 0x3b9aca00, 0x0, 0x1, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad2320, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a5f080, 0x4002347f20)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 718 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1853 [select, 7 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x40007c8320, {0x40015eb9f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40007c8320, {0x40015eb9f0?, 0x40026e0f90?, 0x4002ad3510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40015eb8c0, {0x40015eb9f0?, 0x4002ad3598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40015eb8c0}, {0x40015eb9f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40007fdd40, {0x40015eb9f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40015eb9e0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40015eb9e0, 0x40007fdd40, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002ad37c8?, {0xffff6fe9d6d0, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400341d540}, 0x4002decfc0?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40001b4960, {0x35bf9e0, 0x400341d540})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0x4001d23b60)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x4001d233c0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1852
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1374 [select, 1 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x248
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x7c

goroutine 722 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x130
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 698
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x200

goroutine 723 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x240
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 698
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x274

goroutine 724 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4002347500)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 698
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1365 [IO wait]:
internal/poll.runtime_pollWait(0xffff702025f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x17?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40030fc980)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40030fc980)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40021fcdb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40019ecff0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x40001b4690, {0x3e0bc20, 0x40019ecff0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3e0bc20?, 0x40019ecff0?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x70
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x418

goroutine 726 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40025f8840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 701
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 727 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400123f150, 0x12)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400123f140)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40025f8720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ab40, {0x3e23828, 0x4000633a40}, 0x4002347620, {0x3e3b200, 0x4001835800})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 701
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 728 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 701
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 729 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40026476d8, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40026476c8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40026476b0, 0x400123f440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad23c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a5bec0, {0x3ddab40, 0x4000de85a0}, 0x1, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a5bec0, 0x3b9aca00, 0x0, 0x1, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad23c0, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a5f160, 0x400265aa80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 458
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 730 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 458
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 838 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xc0
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x26c

goroutine 733 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 709
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 768 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 735 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 709
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 736 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005587dc0}, {0xffff6fe6fe08, 0x4002647550}, {0x3e672a8, 0x371cba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001867dc0, {0x0?, 0x0?}, 0x40023479e0, 0x4002673b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001867dc0, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a57f40, {0x3ddab60, 0x4000633cc0}, 0x1, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001867dc0, 0x40023479e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 709
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 802 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001867dc0, 0x40023479e0, 0x400265baa0, 0x4002673b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 736
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 767 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002647998, 0x31)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002647988)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002647970, 0x40016ee8c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad25a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a86ec0, {0x3ddab40, 0x4000deb4a0}, 0x1, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a86ec0, 0x3b9aca00, 0x0, 0x1, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad25a0, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001aba180, 0x400265bda0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 739 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40025f92c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 713
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 740 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40025f9440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 713
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 741 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400123f950, 0x63)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400123f940)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40025f92c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4aec0, {0x3e23828, 0x4000633d60}, 0x4002347da0, {0x3e3b468, 0x40018359c8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 713
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 742 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 713
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 743 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 717
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1575 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x400238bb00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1362
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 745 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 717
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 746 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40014ad480}, {0xffff6fe6fe08, 0x4002647600}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019f48c0, {0x0?, 0x0?}, 0x4002347f20, 0x40026a7860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019f48c0, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a53f40, {0x3ddab60, 0x4000633e50}, 0x1, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019f48c0, 0x4002347f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 717
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 816 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019f48c0, 0x4002347f20, 0x40026a23c0, 0x40026a7860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 746
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 817 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002692480, 0x40012ef680, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002692480, 0x4001924160?, 0x4001924170?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 746
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1354 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 627
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1448 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40008bfb80, {{{0x37e6ffb, 0x1e}}, {0x0, 0x0}, 0x40018c4948, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1498
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 751 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40025f9e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 752 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40025f9f20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 753 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x40016ee390, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40016ee380)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40025f9e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x40007ccb90}, 0x400265a660, {0x3e3b4c0, 0x4001835cf8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 722
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 754 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 722
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 2511 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076d280, {0x3e23828, 0x4003e6c050})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 796 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 757
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 757 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40026478e8, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40026478d8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x40026478c0, 0x40016ee480)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad2460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029a9ec0, {0x3ddab40, 0x4000dea330}, 0x1, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a63ec0, 0x3b9aca00, 0x0, 0x1, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad2460, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a5fd40, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 425
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 758 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 425
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 679 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 761 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 729
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10955 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40056d8048, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40056d8038)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40056d8030, {0x4004f67b20, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002a4fcc8?}, {0x4004f67b20?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x40056d8000}, {0x4004f67b20, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4005547890, {0x40039c3000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40056cf3b0, 0x0, {0x3e02238, 0x4005587e00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001b47e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005587dc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 736
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 763 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 729
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 764 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001a7eec0}, {0xffff6fe6fe08, 0x40026476b0}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019f4ee0, {0x0?, 0x0?}, 0x400265aa80, 0x40026cc0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019f4ee0, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a55f40, {0x3ddab60, 0x40007cce10}, 0x1, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019f4ee0, 0x400265aa80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 729
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 820 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019f4ee0, 0x400265aa80, 0x40026a2b40, 0x40026cc0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 821 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002692600, 0x40013b38c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002692600, 0x8a600?, 0x3e23828?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 870 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001856b80}, {0xffff6fe6fe08, 0x4000ab5b80}, {0x3e672a8, 0x36f6aa0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002363340, {0x0?, 0x0?}, 0x4002413440, 0x40027625a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002363340, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002875f40, {0x3ddab60, 0x4000bbc820}, 0x1, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002363340, 0x4002413440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 865
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1406 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x400109fed0, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400109fec0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000d23680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4acc0, {0x3e23828, 0x4002837900}, 0x40000c6fc0, {0x3e3b308, 0x4001a120c0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1631 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002b3c8c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001898080, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1641
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1476 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40015f2a80, 0x400203e900, 0x40004fa360, 0x40013b6d80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1359
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1377 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1353 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4002646238, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002646228)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002646210, 0x400109ebc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x40028241e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002177ec0, {0x3ddab40, 0x4002851140}, 0x1, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002177ec0, 0x3b9aca00, 0x0, 0x1, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x40028241e0, 0x400203e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000123a80, 0x400203e900)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 627
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1486 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001866fc0, 0x4001baa660, 0x4001cc4780, 0x40013b76e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1358 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1353
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1369 [select, 7 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x3e23a20, 0x4000c9ed80}, {0x3dd0840, 0x400123f500}, {0x3e2b960, 0x40027515c0}, 0x400250f490, {0x3e5d2a0, 0x400244ba40}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x688
github.com/cilium/hive/job.(*jobOneShot).start(0x4002751680, {0x3e237f0, 0x40019ed3e0}, 0x0?, {0x3e2b960, 0x40027515c0}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1371 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e711c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1438 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1428
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10486 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400235dc80, 0x400396ad80, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400235dc80, 0x8a6d4?, 0x4000ce9b80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1467
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1501 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40030db5e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1500 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000ce9400, {{{0x37a4a9e, 0xf}}, {0x0, 0x0}, 0x4001c1c2d0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1655 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff6fec1be0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d46980?, 0x400174c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d46980, {0x400174c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d46980, {0x400174c000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40010abd08, {0x400174c000?, 0x72?, 0x4001b00e48?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001b00e40, {0x400174c000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002762540)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002762540, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001da6510, {0x3e237f0, 0x4002408cc0})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1365
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 2483 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000765270, {0x3e23828, 0x4003e99a90})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2499
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1638 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000801220})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002430dc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400164b5b0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1599
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1639 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4002a3ae28?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4002408cc0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1599
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 2315 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fec1800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003bcc300?, 0x4003bd0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003bcc300, {0x4003bd0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003bcc300, {0x4003bd0000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40010abc00, {0x4003bd0000?, 0xe?, 0x61d4600?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400185f8c0, {0x4003bd0000?, 0x4002954d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003bc7140)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003bc7140, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400185f8c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 2313
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1602 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40007b0140})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002385b80, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001ac2ae0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1452
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 810 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 792
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 792 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x4002647a48, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002647a38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002647a20, 0x40016ee940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000ad2640)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a8cec0, {0x3ddab40, 0x4000ce41b0}, 0x1, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a8cec0, 0x3b9aca00, 0x0, 0x1, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000ad2640, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001aba380, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 793 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 424
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 854 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002363340, 0x4002413440, 0x4002413560, 0x40027625a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 870
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 10741 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003040480, 0x40014fbd40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003040480, 0x8a6d4?, 0x4000ce9b80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 813
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 798 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 757
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 799 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001a7ef40}, {0xffff6fe6fe08, 0x40026478c0}, {0x3e672a8, 0x36f67e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019f5420, {0x0?, 0x0?}, 0x400265b6e0, 0x40026ccba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019f5420, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a51f40, {0x3ddab60, 0x40007cd400}, 0x1, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019f5420, 0x400265b6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 757
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 828 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019f5420, 0x400265b6e0, 0x40026a3200, 0x40026ccba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 799
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 829 [select, 7 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002692780, 0x40013c70e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002692780, 0x0?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 799
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 804 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 767
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 10954 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40056d8000, 0x4001b04c60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40056d8000, 0x8a6d4?, 0x4001424400?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 736
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 806 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 807 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001998180}, {0xffff6fe6fe08, 0x4002647970}, {0x3e672a8, 0x373c000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40019f5a40, {0x0?, 0x0?}, 0x400265bda0, 0x40026ccde0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40019f5a40, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a6bf40, {0x3ddab60, 0x40007cd5e0}, 0x1, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40019f5a40, 0x400265bda0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 767
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 832 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40019f5a40, 0x400265bda0, 0x40026a3920, 0x40026ccde0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 10669 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002e3b0c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002e3b0b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002e3b0b0, {0x4000d3c608, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002a87cc8?}, {0x4000d3c608?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x4002e3b080}, {0x4000d3c608, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40031a80f0, {0x40023fec00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003e98e10, 0x0, {0x3e02238, 0x4001998400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001c30f80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001998180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 818 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400162fe00, {{{0x37be248, 0x15}}, {0x0, 0x0}, 0x4001925210, 0x0, 0x39b9348, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 697
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 812 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 792
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 813 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400153bf00}, {0xffff6fe6fe08, 0x4002647a20}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002362000, {0x0?, 0x0?}, 0x40026a20c0, 0x40026ccc60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002362000, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002a6df40, {0x3ddab60, 0x40007cd900}, 0x1, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002362000, 0x40026a20c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 792
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 830 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002362000, 0x40026a20c0, 0x40026a3500, 0x40026ccc60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 813
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 835 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40026927c8, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40026927b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40026927b0, {0x4001684001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003eefcc8?}, {0x4001684001?, 0x4003eefcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40026bea00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40026bea00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40026bea00, {0x30150e0, 0x40011d54e8})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4001103c80, {0x4003250a00, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000890ff0, 0x0, {0x3e02238, 0x40055758c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40019fb260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001a7ef40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 799
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 834 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002692648, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002692638)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002692630, {0x4003e7329c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002a96cc8?}, {0x4003e7329c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x4002692600}, {0x4003e7329c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4001887c38, {0x4000f01c00, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000890f00, 0x0, {0x3e02238, 0x40055f9940})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40019fb240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001a7eec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 764
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10668 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002e3b080, 0x40013c6c60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002e3b080, 0x8a6d4?, 0x4001a7f2c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1356 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1353
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1401 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000d235c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1569 [chan receive, 7 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x3028

goroutine 1640 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002430f00, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002b3e5a0}, 0x400028efc0, 0x0, 0x40012bc960, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1599
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1425 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000d23a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1403 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1567 [syscall]:
syscall.Syscall6(0x16, 0x37, 0x4001a7c320, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x4000074001?, {0x4001a7c320?, 0x400220d918?, 0x1ea7078?}, 0x3ddd880?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x4001c30de0, {0x4001a7c320, 0x2, 0x2}, {0x74?, 0x74?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4000c89380, 0x400220daf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x400244b8f0, {0x3e23828, 0x40007754f0})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x404
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1529
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd4

goroutine 1399 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1470 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1433
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1427 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1374
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1464 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1423
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1433 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4002646a78, 0xd0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002646a68)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4002646a50, 0x400164f080)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4002824460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40022f6ec0, {0x3ddab40, 0x40023ee2a0}, 0x1, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40022f6ec0, 0x3b9aca00, 0x0, 0x1, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4002824460, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000c62700, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 463
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1408 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000d238c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1578 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1362
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 8759 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4003ff1500, 0x4003b9b440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4003ff1500, 0x3e237f0?, 0x40022a8c00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1473
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10918 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400323c7c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400323c7b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400323c7b0, {0x4003f56a38, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40032f8cc8?}, {0x4003f56a38?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x400323c780}, {0x4003f56a38, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40011d5038, {0x40039c2400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40044d3400, 0x0, {0x3e02238, 0x4005575880})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000ccab40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005575840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1384 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4002832300, {0x3e237f0, 0x40024084b0}, 0x40023713e0?, {0x3e2b960, 0x40028322a0}, {{{0x0, 0x0, 0x0}}, 0x40003bebc0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1400 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000d23440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1696 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fec1708, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002e28780?, 0x4002e3e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002e28780, {0x4002e3e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002e28780, {0x4002e3e000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400132ade8, {0x4002e3e000?, 0x12?, 0x4000c01d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001552d80, {0x4002e3e000?, 0x4002174d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002d5a2a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002d5a2a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001552d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1694
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1458 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1418
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1385 [select, 2 minutes]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x400281ca00, {0x3e237f0, 0x4002408660}, {0x3e0e5f0, 0x40024098f0}, 0x400177bc80)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x204
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x400281ca00, {0x3e237f0, 0x4002408660}, {0x671a10c4?, 0x4002215d68?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x2d0
github.com/cilium/hive/job.(*jobOneShot).start(0x4002832600, {0x3e237f0, 0x4002408660}, 0x4001deb740?, {0x3e2b960, 0x40028325a0}, {{{0x4000355ec0, 0x1, 0x1}}, 0x40003bfaf0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1404 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000d23680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1374
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1590 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4001424090, 0x28)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001424080)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4002317320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40007eb9a0}, 0x4001da3740, {0x3e3b258, 0x4001a8d860})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1382 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4002832240, {0x3e237f0, 0x40024082a0}, 0x4001debc20?, {0x3e2b960, 0x4002832180}, {{{0x4000354460, 0x1, 0x1}}, 0x40003638a0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1372 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1440 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1428
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1434 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 463
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1378 [select, 6 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0x40028243c0, {0x3e237f0, 0x40019edb90})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0x8c
github.com/cilium/hive/job.(*jobTimer).start(0x4000c81c80, {0x3e237f0, 0x40019edb90}, 0x0?, {0x3e2b960, 0x4002751b00}, {{{0x0, 0x0, 0x0}}, 0x4001925950, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x34c
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1466 [chan receive, 7 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1423
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1467 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40048b9940}, {0xffff6fe6fe08, 0x40019e8bb0}, {0x3e672a8, 0x36f2b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002363500, {0x0?, 0x0?}, 0x4000bb3920, 0x40013b7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002363500, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400221df40, {0x3ddab60, 0x4000798fa0}, 0x1, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002363500, 0x4000bb3920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1423
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1489 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002363500, 0x4000bb3920, 0x4001cc5980, 0x40013b7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1467
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1473 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400047f900}, {0xffff6fe6fe08, 0x4002646a50}, {0x3e672a8, 0x370c0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002363a40, {0x0?, 0x0?}, 0x4000bb3e00, 0x40013b7560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002363a40, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400220ff40, {0x3ddab60, 0x40007990e0}, 0x1, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002363a40, 0x4000bb3e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1433
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1483 [select, 7 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002363a40, 0x4000bb3e00, 0x4001933980, 0x40013b7560)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1473
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 8760 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4003ff1548, 0x2d)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4003ff1538)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4003ff1530, {0x4003a7f001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4005aadcc8?}, {0x4003a7f001?, 0x4005aadcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002384f00)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002384f00)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002384f00, {0x30150e0, 0x4005459350})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40058aa540, {0x400324e000, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4005618280, 0x0, {0x3e02238, 0x40056036c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000d6c380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400047f900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1473
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1482 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400151c7c8, 0x1c)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400151c7b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400151c7b0, {0x4004220144, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40032e7cc8?}, {0x4004220144?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x400151c780}, {0x4004220144, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4001a126c0, {0x4002a2a000, 0x800, 0xc00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4000799c20, 0x0, {0x3e02238, 0x4004599a80})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40007cf5c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40015429c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10662 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002e3af00, 0x40004a99e0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002e3af00, 0x2060000024d?, 0x15a806000013d3?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1461
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10892 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400323c780, 0x4001716a20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400323c780, 0x8a6d4?, 0x40015436c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1441
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 2506 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 1591 [select, 7 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1363
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 2500 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2507 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2a640, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x400076c7f0, 0x1, 0x400076c800, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1508 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0x4001c1d290, 0x40013c18c0?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x4ec
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1344
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x210

goroutine 1509 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000ce9e00, {{{0x3799d7a, 0xd}}, {0x0, 0x0}, 0x4001d14450, 0x0, 0x400080b440, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1512 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1513 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1514 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1515 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1516 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1517 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1518 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1519 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1520 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1521 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1522 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1523 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1524 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1525 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1526 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1527 [IO wait]:
internal/poll.runtime_pollWait(0xffff70202120, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x35?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40019f3600)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40019f3600)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40017ce6a0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40017ce6a0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x40031dd680, {0x3e0bbf0, 0x40017ce6a0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0x4000d3a5d0, 0xe}, {0x3e0bbf0, 0x40017ce6a0})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xa0
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1344
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x560

goroutine 1528 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000b7e000, {{{0x37bdc75, 0x15}}, {0x0, 0x0}, 0x4001d148a0, 0x0, 0x39b9348, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1806 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400352a280, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40035a55c0}, 0x4001897820, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1673
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1530 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000b7e140, {{{0x37c1af7, 0x16}}, {0x3e2b960, 0x40025d0c60}, 0x4001c649a0, 0x0, 0x39b9348, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1344
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1589 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4002317c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1588 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4002317320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1363
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1566 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x40008bfe00)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x78
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x216c

goroutine 1565 [select, 2 minutes]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x4000d9fe90, {0x3e23828, 0x40019040f0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xec
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1529
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x20f0

goroutine 1564 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40008bfcc0, {{{0x378d189, 0xa}}, {0x0, 0x0}, 0x39b9e78, 0x0, 0x39b9348, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1529
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1563 [chan receive, 7 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1529
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1636 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40018b0280)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1599
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1605 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002385e00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40007b0320, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1452
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1612 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400162e640, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001ac3b90, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1605
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1731 [select, 1 minutes]:
reflect.rselect({0x4001553b00, 0x9, 0xffff6fede148?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4003215a00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001d86660, {0x3e237f0, 0x40033d2240}, 0x40002908c0, {0xffff6fe9d6f8, 0x4001b28200}, 0x40030b78c0, {0x385b1ff?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001d86660, {0x3e237f0, 0x40033d2240}, {0xffff6fe9d6f8, 0x4001b28200}, {0x385b1ff, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0x4001d86660, {0x3e3e7a8, 0x4001b28200})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x78
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x365dfc0?, 0x4001d86660}, {0x3e32818, 0x40033b05a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001484800, {0x3e237f0, 0x40033d2150}, {0x3e42860, 0x40033ba180}, 0x400162aa20, 0x4001d86930, 0x62382a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001484800, {0x3e42860, 0x40033ba180}, 0x400162aa20)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 2545 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9e500, {0x3e23828, 0x4003e6cbe0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2518
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1706 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002de7900, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400317d380}, 0x4001ada410, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1603
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2595 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4003f7ed20, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046ce70)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2486
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1624 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002824e60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1509
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1623 [syscall, 7 minutes]:
syscall.Syscall6(0x5f, 0x1, 0x220, 0x400009b4a8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
os.(*Process).blockUntilWaitable(0x4001c789f0)
	/usr/local/go/src/os/wait_waitid.go:32 +0x6c
os.(*Process).wait(0x4001c789f0)
	/usr/local/go/src/os/exec_unix.go:22 +0x2c
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0x4002692f00)
	/usr/local/go/src/os/exec/exec.go:901 +0x38
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 1622
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x3bc

goroutine 2516 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077a5a0, {0x3e23828, 0x4003e6c410})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2505
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2228 [select, 7 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400334e6e0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400327fa40, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000c42ff0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2219
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1668 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002dc6140, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002b3fb00}, 0x4001844900, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1503
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1653 [IO wait, 7 minutes]:
internal/poll.runtime_pollWait(0xffff70202028, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002d46700?, 0x4002b7f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002d46700, {0x4002b7f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002d46700, {0x4002b7f000?, 0x1?, 0x4001433180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40010abd00, {0x4002b7f000?, 0xc?, 0x400267cc00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40014ff320, {0x4002b7f000?, 0x18550?, 0x4002de2420?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002d33440)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002d33440, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40014ff320)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1652
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1654 [select, 7 minutes]:
net/http.(*persistConn).writeLoop(0x40014ff320)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1652
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1658 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x4000dc4000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xe0
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x5c
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 1508
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1d8

goroutine 1659 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x400080b3f8)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xd4
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x2c
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1658
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x80

goroutine 1660 [semacquire, 7 minutes]:
sync.runtime_Semacquire(0x4001433a40?)
	/usr/local/go/src/runtime/sema.go:62 +0x2c
sync.(*WaitGroup).Wait(0x4000dc4140)
	/usr/local/go/src/sync/waitgroup.go:116 +0x74
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x4000dc4000)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0xa8
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x4000dc4000)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x100
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x28
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1658
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xd0

goroutine 1664 [IO wait, 4 minutes]:
internal/poll.runtime_pollWait(0xffff6fec18f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x94?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002d47100)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002d47100)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001a5e860)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001a5e860)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x40001b5b30, {0x3e0bbf0, 0x4001a5e860})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
net/http.(*Server).ListenAndServe(0x40001b5b30)
	/usr/local/go/src/net/http/server.go:3189 +0x84
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x28
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1659
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x58

goroutine 2508 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2517 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077a5d0, {0x3e23828, 0x4003e6c460})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2505
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2576 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017c8488)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2486
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1714 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1420, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002e28800?, 0x40033e1e00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0x4002e28800, {0x40033e1e00, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x214
net.(*netFD).readFrom(0x4002e28800, {0x40033e1e00?, 0x72?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x28
net.(*IPConn).readFrom(0x4002e28800?, {0x40033e1e00, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0x400132adf0, {0x40033e1e00?, 0x4002a58ea8?, 0x4002a58e70?})
	/usr/local/go/src/net/iprawsock.go:129 +0x2c
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1bea281c538c94d?, {0x40033e1e00?, 0x6279580?, 0x6279580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x34
github.com/servak/go-fastping.(*Pinger).recvICMP(0x4001dce000, 0x4001a5f7e0, 0x4002d5a360, 0x4001a5f800, 0x4001843d90)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x114
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1703
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x2d8

goroutine 2484 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007652a0, {0x3e23828, 0x4003e99ae0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2499
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2489 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2499
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 1675 [select, 2 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002dc6c80, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001845530, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1509
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1697 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fec1610, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002dea280?, 0x400182e000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002dea280, {0x400182e000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002dea280, {0x400182e000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001151d98, {0x400182e000?, 0x72?, 0x4001c47568?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001c47560, {0x400182e000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002b3eb40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b3eb40, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001265320, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1703 [select]:
github.com/servak/go-fastping.(*Pinger).run(0x4001dce000, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x494
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1660
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x1b0

goroutine 2236 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400327fe00, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000c43590, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2231
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1713 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4001552d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1694
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1704 [select, 1 minutes]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x80
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1660
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x68

goroutine 1705 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1518, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x31?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002dea500)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002dea500)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x4002959db8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40022a8a80)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x4002728a50, {0x3e0bc20, 0x40022a8a80})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3e0bc20?, 0x40022a8a80?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x70
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1660
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x3f0

goroutine 1712 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4001a3dea0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400028cc40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xbc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x13d0

goroutine 1729 [select, 7 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x40033ba180)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x174
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 1711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1410

goroutine 1730 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fec20b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400338df00?, 0x40033be000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400338df00, {0x40033be000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400338df00, {0x40033be000?, 0x4004292e00?, 0x800010601?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001938060, {0x40033be000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
bufio.(*Reader).Read(0x40030cb020, {0x40018f0900, 0x9, 0x40033afce0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40030cb020}, {0x40018f0900, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x40018f0900, 0x9, 0x400459efc0?}, {0x3dcc0a0?, 0x40030cb020?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x40018f08c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x40033ba180, {0x3e237f0, 0x40033afe90}, 0x40033afec0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x11c
google.golang.org/grpc.(*Server).serveStreams(0x4001484800, {0x3e23698?, 0x680cae0?}, {0x3e42860, 0x40033ba180}, {0x3e3a840?, 0x4001938060?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x300
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x5c
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 1711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d4

goroutine 1732 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x40033d00f0, {0x40033d21f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40033d00f0, {0x40033d21f0?, 0x40033a4618?, 0x4002ae7510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40033d2090, {0x40033d21f0?, 0x4002ae7598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40033d2090}, {0x40033d21f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400162aa20, {0x40033d21f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40033d21e0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40033d21e0, 0x400162aa20, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002ae77c8?, {0xffff6fe9d6d0, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40033ce320}, 0x4001081880?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40033b05a0, {0x35bf9e0, 0x40033ce320})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0x4001b28200)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x40002908c0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1731
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 2600 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4001cb12c0, {0x3e23828, 0x4003f7e4b0}, 0x521092bdd24d08af, 0x4003f6e0c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2553
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2504 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2503 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2a3c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x400076c040, 0x1, 0x400076c050, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1852 [select, 7 minutes]:
reflect.rselect({0x40007d0000, 0x9, 0xffff6ff9c380?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4002d42800?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4001d86660, {0x3e237f0, 0x40015eba70}, 0x40002ab500, {0xffff6fd6f218, 0x4001d23b60}, 0x400281bf20, {0x3852034?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4001d86660, {0x3e237f0, 0x40015eba70}, {0xffff6fd6f218, 0x4001d23b60}, {0x3852034, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0x4001d86660, {0x3e3e6a0, 0x4001d23b60})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x78
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x365dfc0?, 0x4001d86660}, {0x3e32818, 0x40001b4960})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x4001484800, {0x3e237f0, 0x40015eb950}, {0x3e42860, 0x40033ba180}, 0x40007fdd40, 0x4001d86810, 0x6238200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x4001484800, {0x3e42860, 0x40033ba180}, 0x40007fdd40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 1730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1855 [sync.Cond.Wait, 7 minutes]:
sync.runtime_notifyListWait(0x40015af1d0, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015af1c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40015af180, {0x3e23828, 0x40007c83c0}, {0x400284d640, 0x33}, 0x1, {0x40012d1cc5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1852
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 2570 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017a0908)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2530
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2596 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4004014d20, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046d110)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2548
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1762 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035a8000, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400370e0c0}, 0x40015cacc0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1639
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2599 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4003f55e00, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046d650)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2530
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 2528 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2526 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2501
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2671 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x400187ac60)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2526
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2605 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4002341680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2554
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2527 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2b7c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x400077bb80, 0x1, 0x400077bb90, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2522 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077b2d0, {0x3e23828, 0x4003e6c690})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2507
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2521 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077b2a0, {0x3e23828, 0x4003e6c640})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2507
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2502 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2239 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003450780, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003478780}, 0x4000c73320, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2229
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2229 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40004d7401?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001553560?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 2219
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 2485 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x40007652d0, {0x3e23828, 0x4003e99b30})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2499
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2509 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076d220, {0x3e23828, 0x4003e37ef0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2515 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077a570, {0x3e23828, 0x4003e6c3c0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2505
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2316 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400185f8c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 2313
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 2510 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076d250, {0x3e23828, 0x4003e6c000})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2512 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400076db20, {0x3e23828, 0x4003e6c190})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2503
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2231 [select, 7 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400327fcc0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400334e820, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2219
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2226 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000ceba40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 2219
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 2678 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40023410e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2529
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2519 [chan receive, 7 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 2520 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x400077b270, {0x3e23828, 0x4003e6c5f0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2507
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2626 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003f0b520)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2606
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2518 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2b2c0, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x400077a980, 0x1, 0x400077a990, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2529 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2505
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2230 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400327fb80, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40033471a0}, 0x400028a460, 0x0, 0x4002348a20, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 2219
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2505 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2a500, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x400076c420, 0x1, 0x400076c430, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2501 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2a280, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x40005d9bf0, 0x1, 0x40005d9c00, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2619 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40023407e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2489
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2601 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40040152c0, {0x400407cd30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40040152c0, {0x400407cd30?, 0x4003eb2078?, 0x4003f77930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400407ccf0, {0x400407cd30?, 0x4003f779b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400407ccf0}, {0x400407cd30, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40027266c0, {0x400407cd30, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400407cd20, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400407cd20, 0x40027266c0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40027266c0?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f19180}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003eccea0, {0x3612420, 0x4000f19180}, 0x4000f19f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003f77d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4002726480, 0x4003f77e10, 0x4003f77e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4002726480, {0x3612420?, 0x4000f19180?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003ec20a8, {0x3612420, 0x4000f19180})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000a440c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4001cb12c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2553
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2499 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003e2a140, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x40005d97f0, 0x1, 0x40005d9800, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 629
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2546 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9e530, {0x3e23828, 0x4003e6cc30})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2518
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2547 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9e560, {0x3e23828, 0x4003e6cc80})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2518
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2597 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4004014370, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046d260)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2558
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 2603 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2553
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2610 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x400210aa20)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2551
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2551 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2507
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2602 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4001cb12c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2553
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2554 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2503
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2541 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017c2488)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2494
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2555 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9f730, {0x3e23828, 0x4003e6d450})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2527
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2556 [select, 7 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9f760, {0x3e23828, 0x4003e6d4a0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2527
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2557 [select, 6 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000a9f790, {0x3e23828, 0x4003e6d4f0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 2527
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 2598 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4004014b90, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046d3b0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2523
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 2584 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2601
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2577 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017c3208)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2523
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2644 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40026f6000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2561
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2561 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2518
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2604 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003e71800, 0x40040b0ea0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2553
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2581 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017dc6c8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2563
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2654 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x40026f6ea0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 2566
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 2566 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 2527
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 2585 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4001cb12c0, {0x3e3fa98, 0x4000a440c0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2601
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2571 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1ae8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003eaec00?, 0x40036c6a00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003eaec00, {0x40036c6a00, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003eaec00, {0x40036c6a00?, 0xffff6fec9d98?, 0x4003b8dda0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d27718, {0x40036c6a00?, 0x4002955928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003b8dda0, {0x40036c6a00?, 0x0?, 0x4003b8dda0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003ed29b0, {0x3dd1940, 0x4003b8dda0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003ed2708, {0x3dcbd80, 0x4000d27718}, 0x4002955a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003ed2708, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003ed2708, {0x4003f90000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003f7c060, {0x4001a94120, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003f7c060}, {0x4001a94120, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001a94120, 0x9, 0x6cb94315bc?}, {0x3dcc0a0?, 0x4003f7c060?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001a940e0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017a0908, 0x4003f7c0c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2530
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2543 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017c2908)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2558
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2578 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1328, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e71680?, 0x40002e5500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e71680, {0x40002e5500, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e71680, {0x40002e5500?, 0xffff6ffff8f8?, 0x4001c87368?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d27738, {0x40002e5500?, 0x40038dd928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c87368, {0x40002e5500?, 0x0?, 0x4001c87368?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003ed30b0, {0x3dd1940, 0x4001c87368})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003ed2e08, {0x3dcbd80, 0x4000d27738}, 0x40038dda00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003ed2e08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003ed2e08, {0x4004090000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40040552c0, {0x4000e729e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40040552c0}, {0x4000e729e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e729e0, 0x9, 0x6cb9d09f3b?}, {0x3dcc0a0?, 0x40040552c0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e729a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017c3208, 0x4004055320)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2523
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2542 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1230, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003eaeb00?, 0x4000c32000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003eaeb00, {0x4000c32000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003eaeb00, {0x4000c32000?, 0xffff6ffff8f8?, 0x4001c87608?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d27728, {0x4000c32000?, 0x4002a63928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c87608, {0x4000c32000?, 0x0?, 0x4001c87608?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003ed2d30, {0x3dd1940, 0x4001c87608})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003ed2a88, {0x3dcbd80, 0x4000d27728}, 0x4002a63a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003ed2a88, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003ed2a88, {0x4004016000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003efbc80, {0x4000e72580, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003efbc80}, {0x4000e72580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e72580, 0x9, 0x6cb9d79739?}, {0x3dcc0a0?, 0x4003efbc80?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e72540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017c2488, 0x4003efbce0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2494
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2544 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda12c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e71e80?, 0x4004008700?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e71e80, {0x4004008700, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e71e80, {0x4004008700?, 0xffff6ffff8f8?, 0x4001c87380?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fa4708, {0x4004008700?, 0x40032fa928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c87380, {0x4004008700?, 0x0?, 0x4001c87380?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003dd57b0, {0x3dd1940, 0x4001c87380})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003dd5508, {0x3dcbd80, 0x4000fa4708}, 0x40032faa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003dd5508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003dd5508, {0x4004034000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4004029980, {0x4000e72740, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4004029980}, {0x4000e72740, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e72740, 0x9, 0x6cb9d1a517?}, {0x3dcc0a0?, 0x4004029980?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e72700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017c2908, 0x40040299e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2558
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2579 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40017c3b08)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2548
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 2580 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec1dd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003e71d00?, 0x4004008e00?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003e71d00, {0x4004008e00, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003e71d00, {0x4004008e00?, 0xffff6ffff8f8?, 0x4001c875a8?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fa4718, {0x4004008e00?, 0x40038da928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c875a8, {0x4004008e00?, 0x0?, 0x4001c875a8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003dd5b30, {0x3dd1940, 0x4001c875a8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003dd5888, {0x3dcbd80, 0x4000fa4718}, 0x40038daa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003dd5888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003dd5888, {0x40040a0000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40040553e0, {0x4000e72ac0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40040553e0}, {0x4000e72ac0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e72ac0, 0x9, 0x6cb9d65273?}, {0x3dcc0a0?, 0x40040553e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e72a80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017c3b08, 0x4004055440)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2548
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2593 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fec19f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003eae700?, 0x4000d83000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003eae700, {0x4000d83000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003eae700, {0x4000d83000?, 0xffff6ffff8f8?, 0x4001c875f0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000d275e0, {0x4000d83000?, 0x4002205928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c875f0, {0x4000d83000?, 0x0?, 0x4001c875f0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003ed2630, {0x3dd1940, 0x4001c875f0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003ed2388, {0x3dcbd80, 0x4000d275e0}, 0x4002205a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003ed2388, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003ed2388, {0x4003fca000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003faf4a0, {0x4001a942e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003faf4a0}, {0x4001a942e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4001a942e0, 0x9, 0x6cb9d8572d?}, {0x3dcc0a0?, 0x4003faf4a0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4001a942a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017c8488, 0x4003faf500)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2486
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2594 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40040140f0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400046caf0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2494
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 2582 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda11c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003f6c200?, 0x40002e4a80?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003f6c200, {0x40002e4a80, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003f6c200, {0x40002e4a80?, 0xffff6ffff8f8?, 0x4001c875c0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000fa46b8, {0x40002e4a80?, 0x4002b63928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001c875c0, {0x40002e4a80?, 0x0?, 0x4001c875c0?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x4003dd5430, {0x3dd1940, 0x4001c875c0})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x4003dd5188, {0x3dcbd80, 0x4000fa46b8}, 0x4002b63a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x4003dd5188, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x4003dd5188, {0x4004122000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40041007e0, {0x4000e72c80, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40041007e0}, {0x4000e72c80, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4000e72c80, 0x9, 0x6cb9d791e7?}, {0x3dcc0a0?, 0x40041007e0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4000e72c40)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40017dc6c8, 0x4004100840)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2563
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 2583 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4004014fa0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000479ab0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 2563
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 2629 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a62d0, {0x4003932b50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a62d0, {0x4003932b50?, 0x4003f444c8?, 0x400411b950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003932b10, {0x4003932b50?, 0x400411b9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003932b10}, {0x4003932b50, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40014470e0, {0x4003932b50, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003932b40, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003932b40, 0x40014470e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40014470e0?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40002fc460}, 0x400411bc88?, 0x2a200?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003f0b6c0, {0x368b2c0, 0x40002fc460}, 0x40002fdf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x400411bd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001446a20, 0x400411be30, 0x400411be78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001446a20, {0x368b2c0?, 0x40002fc460?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cca80, {0x368b2c0, 0x40002fc460})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000d93ee0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003f0b520, {0x3e3faf0, 0x4000d93ee0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2586 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x10?, {0x3e23828, 0x40040154a0}, {0x3e5f080?, 0x4002341680?}, 0x400076d2a0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2503
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2625 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2606
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2589 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ce7e00, {0x3e23828, 0x4004015d60}, 0x521092bdd24d08b3, 0x400404b620)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2550
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2590 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a6e60, {0x4003933840, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a6e60, {0x4003933840?, 0x4003f445b8?, 0x4003f4d930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003933800, {0x4003933840?, 0x4003f4d9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003933800}, {0x4003933840, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001456900, {0x4003933840, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003933830, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003933830, 0x4001456900, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001456900?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e03c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003f0bd40, {0x3612420, 0x40018e03c0}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003f4dd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40014566c0, 0x4003f4de10, 0x4003f4de58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40014566c0, {0x3612420?, 0x40018e03c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040ccf78, {0x3612420, 0x40018e03c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015ca250)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ce7e00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2550
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2591 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ce7e00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2550
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2592 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2550
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2609 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003e71600, 0x400407df50)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2550
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2611 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e23828, 0x4003e37db0}, 0x400125cb80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2551
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2614 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40018b1cc0, {0x3e23828, 0x4001c88280}, 0x521092bdd24d08b9, 0x400404baa0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2488
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2615 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a75e0, {0x4000369e10, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a75e0, {0x4000369e10?, 0x4003f44630?, 0x4003f2f930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003933f50, {0x4000369e10?, 0x4003f2f9b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003933f50}, {0x4000369e10, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001457680, {0x4000369e10, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4000369e00, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4000369e00, 0x4001457680, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001457680?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e0a00}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358c0d0, {0x3612420, 0x40018e0a00}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003f2fd78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001457440, 0x4003f2fe10, 0x4003f2fe58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001457440, {0x3612420?, 0x40018e0a00?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cd2a8, {0x3612420, 0x40018e0a00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015ca500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40018b1cc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2488
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2616 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40018b1cc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2488
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2617 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2488
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2618 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003eae580, 0x40038981e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2488
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2628 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2630 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x400358b1e0, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2620 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e23828, 0x4003e37bd0}, 0x400125cdc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2489
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2623 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ad2780, {0x3e23828, 0x4001c886e0}, 0x521092bdd24d08b7, 0x400404bf20)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2560
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2624 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a7a40, {0x40019c42e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a7a40, {0x40019c42e0?, 0x4003f44660?, 0x4004121930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40019c42a0, {0x40019c42e0?, 0x40041219b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40019c42a0}, {0x40019c42e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001457e60, {0x40019c42e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40019c42d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40019c42d0, 0x4001457e60, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001457e60?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e0340}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358c1a0, {0x3612420, 0x40018e0340}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4004121d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001457c20, 0x4004121e10, 0x4004121e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001457c20, {0x3612420?, 0x40018e0340?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cd3b0, {0x3612420, 0x40018e0340})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015ca660)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ad2780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2560
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2631 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x40035a6870}, {0x3e5f080?, 0x400210aa20?}, 0x400077a9f0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2507
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2745 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4000bdfd00, {0x3e23828, 0x40035a6870}, {0xffff6fdbd820, 0x400210aa20}, {0x4003f456e0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002370cc0, {0x3e23828, 0x40035a6870})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197cfc0, {0x3e23828, 0x40035a6870}, {0x3e5f080, 0x400210aa20}, {0x6, {0x1, 0x1, 0xff}}, 0x400203f500)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2507
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2641 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ad2780)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2560
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2642 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2560
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2643 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003e71c80, 0x4003898750)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2560
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2633 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x40018b1ea0, {0x3e23828, 0x40035a6c80}, 0x521092bdd24d08bb, 0x40035989c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2496
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2634 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a70e0, {0x4003933ab0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a70e0, {0x4003933ab0?, 0x4003f445e8?, 0x4003ef3930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003933a70, {0x4003933ab0?, 0x4003ef39b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003933a70}, {0x4003933ab0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001456c60, {0x4003933ab0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003933aa0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003933aa0, 0x4001456c60, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001456c60?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e0700}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003f0be10, {0x3612420, 0x40018e0700}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003ef3d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001456a20, 0x4003ef3e10, 0x4003ef3e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001456a20, {0x3612420?, 0x40018e0700?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cd068, {0x3612420, 0x40018e0700})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015ca310)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x40018b1ea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2496
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2635 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x40018b1ea0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2496
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2636 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2496
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2637 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003eae980, 0x4003933410)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2496
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2638 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ce7540, {0x3e23828, 0x40035a6cd0}, 0x521092bdd24d08b5, 0x4003598b40)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2525
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2639 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40035a7360, {0x4003933d20, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40035a7360, {0x4003933d20?, 0x4003f44600?, 0x4002217930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003933ce0, {0x4003933d20?, 0x40022179b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003933ce0}, {0x4003933d20, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001457320, {0x4003933d20, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003933d10, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003933d10, 0x4001457320, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4001457320?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e02c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358c000, {0x3612420, 0x40018e02c0}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002217d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4001456d80, 0x4002217e10, 0x4002217e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4001456d80, {0x3612420?, 0x40018e02c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cd158, {0x3612420, 0x40018e02c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015ca3d0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ce7540)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2525
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2640 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ce7540)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2525
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2657 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2525
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2658 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003e70c80, 0x4003933590)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2525
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2659 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2590
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2660 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ce7e00, {0x3e3fa98, 0x40015ca250})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2590
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2645 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e23828, 0x4003e6c4b0}, 0x400125d000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2561
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2649 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4000ad2a00, {0x3e23828, 0x4001c88cd0}, 0x521092bdd24d08b1, 0x4002e544e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 2565
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 2650 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4002101590, {0x40019c5900, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4002101590, {0x40019c5900?, 0x4003f448d0?, 0x4002ad5930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40019c57d0, {0x40019c5900?, 0x4002ad59b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40019c57d0}, {0x40019c5900, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400034d680, {0x40019c5900, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40019c58f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40019c58f0, 0x400034d680, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400034d680?, {0xffff6fe9d6d0, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40018e0640}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358c4e0, {0x3612420, 0x40018e0640}, 0x40018e1f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002ad5d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400034d440, 0x4002ad5e10, 0x4002ad5e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400034d440, {0x3612420?, 0x40018e0640?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40040cd6b0, {0x3612420, 0x40018e0640})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x40015cadc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4000ad2a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2565
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 2661 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2634
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2662 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40018b1ea0, {0x3e3fa98, 0x40015ca310})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2634
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2663 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2639
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2664 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ce7540, {0x3e3fa98, 0x40015ca3d0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2639
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2651 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4000ad2a00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 2565
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 2652 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 2565
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 2653 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003f6c180, 0x4003898cf0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 2565
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 2655 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e23828, 0x4003e6caa0}, 0x400125d1c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2566
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2781 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40031add80, {0x3e23828, 0x40035a77c0}, {0xffff6fdbd820, 0x40023407e0}, {0x4003f45f08?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40025178c0, {0x3e23828, 0x40035a77c0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197cc40, {0x3e23828, 0x40035a77c0}, {0x3e5f080, 0x40023407e0}, {0x7, {0x1, 0x1, 0xff}}, 0x4000169380)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2499
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2675 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4001c89540}, {0x3e5f080?, 0x40026f6ea0?}, 0x4000a9ecb0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2527
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2665 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2615
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2666 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x40018b1cc0, {0x3e3fa98, 0x40015ca500})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2615
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2667 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x40035a77c0}, {0x3e5f080?, 0x40023407e0?}, 0x4000d73cd0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2499
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2669 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2624
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2670 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ad2780, {0x3e3fa98, 0x40015ca660})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2624
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2672 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e23828, 0x4003e37c20}, 0x4000d88880)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2526
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2691 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x4003598ae0?, {0x3e23828, 0x4002100e10}, {0x3e5f080?, 0x40026f6000?}, 0x400077bc00)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2518
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2749 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400274b900, {0x3e23828, 0x4002100e10}, {0xffff6fdbd820, 0x40026f6000}, {0x4003f458a8?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002516360, {0x3e23828, 0x4002100e10})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197d6c0, {0x3e23828, 0x4002100e10}, {0x3e5f080, 0x40026f6000}, {0x5, {0x1, 0x1, 0xff}}, 0x400203fb60)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2518
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2769 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40031ac600, {0x3e23828, 0x4001c89540}, {0xffff6fdbd820, 0x40026f6ea0}, {0x4003f45a70?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002516c00, {0x3e23828, 0x4001c89540})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197d960, {0x3e23828, 0x4001c89540}, {0x3e5f080, 0x40026f6ea0}, {0x8, {0x1, 0x1, 0xff}}, 0x40013c1380)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2527
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2694 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2650
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2679 [select, 1 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e23828, 0x4003e37d10}, 0x400125d840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2529
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2695 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4000ad2a00, {0x3e3fa98, 0x40015cadc0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 2650
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 2696 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4002101680}, {0x3e5f080?, 0x400187ac60?}, 0x400076c860)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2501
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2698 [select, 6 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4002101770}, {0x3e5f080?, 0x40023410e0?}, 0x400076dba0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2505
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2683 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40002ab030, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003f37938}, 0x40028431a0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2705
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2684 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e236d0, 0x680cae0}, 0x400125dbc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2683
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2741 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40030fdb00, {0x3e23828, 0x4002101770}, {0xffff6fdbd820, 0x40023410e0}, {0x4003f45518?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40025d1b00, {0x3e23828, 0x4002101770})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197cee0, {0x3e23828, 0x4002101770}, {0x3e5f080, 0x40023410e0}, {0x3, {0x1, 0x1, 0xff}}, 0x400203eb40)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2505
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2700 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003841480, {0x3e23828, 0x40040154a0}, {0xffff6fdbd820, 0x4002341680}, {0x4003f44a50?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40035a5b00, {0x3e23828, 0x40040154a0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197ce00, {0x3e23828, 0x40040154a0}, {0x3e5f080, 0x4002341680}, {0x1, {0x1, 0x1, 0xff}}, 0x40028430e0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2503
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2701 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e23828, 0x40040154a0}, 0x4000d890c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2700
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2773 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40031acf80, {0x3e23828, 0x4002101680}, {0xffff6fdbd820, 0x400187ac60}, {0x4003f45c20?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4002516f60, {0x3e23828, 0x4002101680})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x400197cd20, {0x3e23828, 0x4002101680}, {0x3e5f080, 0x400187ac60}, {0x2, {0x1, 0x1, 0xff}}, 0x40000c6600)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 2501
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 2705 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x40040154a0}, 0x40023a8420, 0x400192b4d0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40040154a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2700
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2706 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f180, {0x3e23828, 0x40040154a0}, {0xffff6fdbd820, 0x4002341680}, {0x4001a0aee0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003e3c8a0, {0x3e23828, 0x40040154a0}, {0xffff6fdbd820, 0x4002341680}, {0x4000fa46f8, 0x1, 0x40002ab510?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40040154a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2700
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2707 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e23828, 0x40040154a0}, 0x4000d89bc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2706
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2710 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e23828, 0x40040154a0}, 0x4000d89e40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2687
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2713 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2655
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2687 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f080, {0x3e23828, 0x40040154a0}, {0xffff6fdbd820, 0x4002341680}, {0x4001a0b000?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40040154a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2700
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2688 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f100, {0x3e23828, 0x40040154a0}, {0xffff6fdbd820, 0x4002341680}, {0x4004049c80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40040154a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2700
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2721 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002341680, {0x3e23828, 0x40040154a0}, 0x400125dec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2688
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2724 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x4003be6840, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2725 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2679
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2714 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400358cf70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2655
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2737 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003711590, {0x4001a3aee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003711590, {0x4001a3aee0?, 0x4003f45020?, 0x4004178950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001a3ae40, {0x4001a3aee0?, 0x40041789d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001a3ae40}, {0x4001a3aee0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000cbfb00, {0x4001a3aee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001a3aed0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001a3aed0, 0x4000cbfb00, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4000cbfb00?, {0xffff6fe9d6d0, 0x680cae0}, 0x1ea1c?, {0x0?, 0x0?}, {0x368b2c0, 0x400029ff10}, 0x4004178c88?, 0x2a200?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358d110, {0x368b2c0, 0x400029ff10}, 0x400029ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4004178d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4000cbf8c0, 0x4004178e30, 0x4004178e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4000cbf8c0, {0x368b2c0?, 0x400029ff10?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400230e150, {0x368b2c0, 0x400029ff10})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400080f3d0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400358cf70, {0x3e3faf0, 0x400080f3d0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2716 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2717 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2611
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2718 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400358d1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2611
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2739 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003711810, {0x4001a3b6f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003711810, {0x4001a3b6f0?, 0x4003f45218?, 0x40040fe950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001a3b6b0, {0x4001a3b6f0?, 0x40040fe9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001a3b6b0}, {0x4001a3b6f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000454ea0, {0x4001a3b6f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001a3b6e0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001a3b6e0, 0x4000454ea0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4000454ea0?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40002fc310}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358d380, {0x368b2c0, 0x40002fc310}, 0x40002fdf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40040fed98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4000454b40, 0x40040fee30, 0x40040fee78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4000454b40, {0x368b2c0?, 0x40002fc310?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400230e378, {0x368b2c0, 0x40002fc310})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001aaa1c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400358d1e0, {0x3e3faf0, 0x4001aaa1c0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2720 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2738 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x400358bce0, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2740 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x400358bd90, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2726 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400383e680)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2679
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2733 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4001c41360, {0x4001ba0520, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4001c41360, {0x4001ba0520?, 0x4003eb3d58?, 0x40040f9950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001ba0480, {0x4001ba0520?, 0x40040f99d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001ba0480}, {0x4001ba0520, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40022f3d40, {0x4001ba0520, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001ba0510, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001ba0510, 0x40022f3d40, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40022f3d40?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40002fc700}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400383e820, {0x368b2c0, 0x40002fc700}, 0x40002fdf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40040f9d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40022f3b00, 0x40040f9e30, 0x40040f9e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40022f3b00, {0x368b2c0?, 0x40002fc700?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40022c63d8, {0x368b2c0, 0x40002fc700})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x400192be60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400383e680, {0x3e3faf0, 0x400192be60})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2728 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2742 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e23828, 0x4002101770}, 0x40019ddc00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2741
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2746 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e23828, 0x40035a6870}, 0x4001974680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2745
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2750 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e23828, 0x4002100e10}, 0x40016efc00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2749
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2729 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2672
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2730 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400383e8f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2672
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2735 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4001c41ea0, {0x4001ba0ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4001c41ea0, {0x4001ba0ee0?, 0x4003eb3e90?, 0x40040fb950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001ba0e70, {0x4001ba0ee0?, 0x40040fb9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001ba0e70}, {0x4001ba0ee0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40004a8360, {0x4001ba0ee0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001ba0ed0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001ba0ed0, 0x40004a8360, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40004a8360?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40004d75e0}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400383ea90, {0x368b2c0, 0x40004d75e0}, 0x40004d7f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40040fbd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40004a8000, 0x40040fbe30, 0x40040fbe78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40004a8000, {0x368b2c0?, 0x40004d75e0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40022c6660, {0x368b2c0, 0x40004d75e0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001709630)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400383e8f0, {0x3e3faf0, 0x4001709630})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2732 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2734 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be68f0, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2736 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x4003be69a0, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2770 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e23828, 0x4001c89540}, 0x4001625640)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2769
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2753 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2620
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2754 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400383eb60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2620
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2757 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40007982d0, {0x400243abe0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40007982d0, {0x400243abe0?, 0x4003464048?, 0x4000efb950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400243aba0, {0x400243abe0?, 0x4000efb9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400243aba0}, {0x400243abe0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40004a9680, {0x400243abe0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400243abd0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400243abd0, 0x40004a9680, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40004a9680?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x40004d7b20}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400383ed00, {0x368b2c0, 0x40004d7b20}, 0x40004d7f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4000efbd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40004a9440, 0x4000efbe30, 0x4000efbe78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40004a9440, {0x368b2c0?, 0x40004d7b20?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40022c6b40, {0x368b2c0, 0x40004d7b20})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4001897430)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400383eb60, {0x3e3faf0, 0x4001897430})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2756 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2758 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x4003be6a50, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2774 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e23828, 0x4002101680}, 0x4001625a00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2773
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2759 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x4002101770}, 0x40019ed0b0, 0x4001897a80)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4002101770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2741
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2760 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f600, {0x3e23828, 0x4002101770}, {0xffff6fdbd820, 0x40023410e0}, {0x4004049ea0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003e3cae0, {0x3e23828, 0x4002101770}, {0xffff6fdbd820, 0x40023410e0}, {0x4000d27110, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4002101770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2741
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2761 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e23828, 0x4002101770}, 0x40014ac0c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2760
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2764 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4001a742a0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40040dfcb8}, 0x400203ec60)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2759
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2765 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e236d0, 0x680cae0}, 0x40014acd00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2764
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2777 [select, 6 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 2645
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 2768 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f500, {0x3e23828, 0x4002101770}, {0xffff6fdbd820, 0x40023410e0}, {0x40016941c0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4002101770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2741
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2785 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f580, {0x3e23828, 0x4002101770}, {0xffff6fdbd820, 0x40023410e0}, {0x4004049fe0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4002101770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2741
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2778 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x400358dc70)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 2645
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 2793 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40004a6aa0, {0x4001a5c8e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40004a6aa0, {0x4001a5c8e0?, 0x4003f45e30?, 0x4001985950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001a5c8a0, {0x4001a5c8e0?, 0x40019859d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001a5c8a0}, {0x4001a5c8e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40013b25a0, {0x4001a5c8e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001a5c8d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001a5c8d0, 0x40013b25a0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40013b25a0?, {0xffff6fe9d6d0, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x400029fa40}, 0x4001985c88?, 0x2a200?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x400358de10, {0x368b2c0, 0x400029fa40}, 0x400029ff80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4001985d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40013b2360, 0x4001985e30, 0x4001985e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40013b2360, {0x368b2c0?, 0x400029fa40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x400230f710, {0x368b2c0, 0x400029fa40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x40015edb30)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x400358dc70, {0x3e3faf0, 0x40015edb30})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 2780 [select, 6 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 2786 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e23828, 0x4002101770}, 0x40014ad5c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2785
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2782 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e23828, 0x40035a77c0}, 0x4001a7e080)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2781
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2801 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x400358be40, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2802 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x40026460b0, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2789 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023410e0, {0x3e23828, 0x4002101770}, 0x40014ad980)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2768
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2792 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be6b00, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2794 [select, 1 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x4003be6bb0, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2795 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x4003be6c60, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2826 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x40035a6870}, 0x4002850720, 0x4001c346d0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40035a6870})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2745
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2825 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be6d10, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2834 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x4002101680}, 0x40024235c0, 0x4001c34970)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4002101680})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2773
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2832 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be6e70, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2828 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e23828, 0x40035a6870}, 0x4001258780)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2827
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2839 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x4001c89540}, 0x40023efef0, 0x4001c34a70)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4001c89540})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2769
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2827 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0fa80, {0x3e23828, 0x40035a6870}, {0xffff6fdbd820, 0x400210aa20}, {0x40016950e0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003e3cd20, {0x3e23828, 0x40035a6870}, {0xffff6fdbd820, 0x400210aa20}, {0x4000d27c18, 0x1, 0x8a6d4?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40035a6870})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2745
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2836 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e23828, 0x4002101680}, 0x400192e780)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2835
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2835 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0ed00, {0x3e23828, 0x4002101680}, {0xffff6fdbd820, 0x400187ac60}, {0x4001695580?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003e3c6c0, {0x3e23828, 0x4002101680}, {0xffff6fdbd820, 0x400187ac60}, {0x4000d27cf8, 0x1, 0x40035fd500?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4002101680})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2773
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2833 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be6f20, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2831 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e680, 0x4003be6dc0, 0x4003712f60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2726
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2806 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x4002100e10}, 0x40023ee600, 0x4001c0d6a0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4002100e10})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2749
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2805 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003f0b520, 0x4002646d10, 0x4003598120)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2626
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2807 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e70700, {0x3e23828, 0x4002100e10}, {0xffff6fdbd820, 0x40026f6000}, {0x4001a0bc60?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003f026c0, {0x3e23828, 0x4002100e10}, {0xffff6fdbd820, 0x40026f6000}, {0x4000fa4ce0, 0x1, 0x400027e470?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4002100e10})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2749
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2808 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e23828, 0x4002100e10}, 0x40019c90c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2807
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2811 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4001a75650, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400001c7b8}, 0x400203fc20)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2806
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2812 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e236d0, 0x680cae0}, 0x40019c9380)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2811
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2840 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e71080, {0x3e23828, 0x4001c89540}, {0xffff6fdbd820, 0x40026f6ea0}, {0x4001695700?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003f030e0, {0x3e23828, 0x4001c89540}, {0xffff6fdbd820, 0x40026f6ea0}, {0x4000d27d30, 0x1, 0x8?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4001c89540})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2769
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2815 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e70600, {0x3e23828, 0x4002100e10}, {0xffff6fdbd820, 0x40026f6000}, {0x4001a0bfe0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4002100e10})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2749
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2816 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e70680, {0x3e23828, 0x4002100e10}, {0xffff6fdbd820, 0x40026f6000}, {0x4001a0be80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4002100e10})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2749
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2841 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e23828, 0x4001c89540}, 0x400192eb00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2840
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2844 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4001513dc0, {0x3e23828, 0x40035a77c0}, 0x4001a5ce70, 0x4001c34bb0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40035a77c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2781
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2845 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0e880, {0x3e23828, 0x40035a77c0}, {0xffff6fdbd820, 0x40023407e0}, {0x4001695960?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x4003e3c3c0, {0x3e23828, 0x40035a77c0}, {0xffff6fdbd820, 0x40023407e0}, {0x4000d27d68, 0x1, 0x1?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40035a77c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2781
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2849 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e23828, 0x4002100e10}, 0x40018e0680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2816
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2852 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6000, {0x3e23828, 0x4002100e10}, 0x40018e09c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2815
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2855 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x4002646dc0, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2846 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e23828, 0x40035a77c0}, 0x400192eec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2845
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2865 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0f980, {0x3e23828, 0x40035a6870}, {0xffff6fdbd820, 0x400210aa20}, {0x4001695ec0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40035a6870})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2745
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2866 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0fa00, {0x3e23828, 0x40035a6870}, {0xffff6fdbd820, 0x400210aa20}, {0x4001695ae0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40035a6870})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2745
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2867 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0ec00, {0x3e23828, 0x4002101680}, {0xffff6fdbd820, 0x400187ac60}, {0x4001695f80?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4002101680})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2773
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2868 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0ec80, {0x3e23828, 0x4002101680}, {0xffff6fdbd820, 0x400187ac60}, {0x4001695bc0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4002101680})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2773
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2869 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e70f80, {0x3e23828, 0x4001c89540}, {0xffff6fdbd820, 0x40026f6ea0}, {0x4000bdc020?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4001c89540})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2769
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2870 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e71000, {0x3e23828, 0x4001c89540}, {0xffff6fdbd820, 0x40026f6ea0}, {0x4001695c60?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4001c89540})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2769
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2871 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0e780, {0x3e23828, 0x40035a77c0}, {0xffff6fdbd820, 0x40023407e0}, {0x4000bdc0a0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40035a77c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2781
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2872 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003e0e800, {0x3e23828, 0x40035a77c0}, {0xffff6fdbd820, 0x40023407e0}, {0x4001695d80?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40035a77c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 2781
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 2873 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x4003be6fd0, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2874 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x4003be7080, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2875 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x4003be7130, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2876 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x4003be71e0, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2856 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4001a74cb0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400001c438}, 0x400203f5c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2826
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2857 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e236d0, 0x680cae0}, 0x40018e0b80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2856
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2860 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e23828, 0x40035a6870}, 0x40018e0c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2866
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2863 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400029f1f0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400001ceb8}, 0x40000c75c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2834
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2864 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e236d0, 0x680cae0}, 0x40018e0d80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2863
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2883 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e23828, 0x4002101680}, 0x40018e0e80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2868
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2886 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400029e460, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400001cb38}, 0x40013c16e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2839
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2887 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e236d0, 0x680cae0}, 0x40018e0f80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2886
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2890 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e23828, 0x4001c89540}, 0x40018e10c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2870
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2893 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400027e070, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x400001d5b8}, 0x4000169440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 2844
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 2894 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e236d0, 0x680cae0}, 0x40018e1c80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2893
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2897 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e23828, 0x40035a77c0}, 0x40018e1d80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2872
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2900 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400210aa20, {0x3e23828, 0x40035a6870}, 0x4001ab4240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2865
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2903 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x400187ac60, {0x3e23828, 0x4002101680}, 0x4001ab45c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2867
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2906 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40026f6ea0, {0x3e23828, 0x4001c89540}, 0x4001ab46c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2869
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2909 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x40023407e0, {0x3e23828, 0x40035a77c0}, 0x4001ab47c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 2871
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 2912 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x4002646f20, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2913 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x4002646fd0, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2914 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x4002647080, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2915 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x4002647e40, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2916 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x400012c0b0, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2917 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x400032bb80, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2918 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x40006ec790, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2919 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x40006ec840, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2920 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383eb60, 0x40006ec8f0, 0x4003713bc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2754
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2921 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358dc70, 0x40006ec9a0, 0x4000168f00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2778
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2922 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x40006eca50, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2923 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x40006ecb00, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2924 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x40006ecd10, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2925 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x40006ecdc0, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2926 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358cf70, 0x40006ece70, 0x4000e18a80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2714
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2927 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400358d1e0, 0x40036f2000, 0x400203e1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2718
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2928 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x40036f20b0, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2929 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x40036f2160, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2930 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x40036f2210, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 2931 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x400383e8f0, 0x40036f22c0, 0x4003713560)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 2730
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3648 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda0fd8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400421f280?, 0x4002e07000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400421f280, {0x4002e07000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400421f280, {0x4002e07000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001af03f8, {0x4002e07000?, 0x72?, 0x4004232908?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4004232900, {0x4002e07000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002d9c960)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002d9c960, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4004200c60, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4406 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4001686a20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4403
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4370 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400168f440)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4367
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3569 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x400114c600?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3542
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4378 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd13a0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7380?, 0x4004919000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7380, {0x4004919000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7380, {0x4004919000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014daf10, {0x4004919000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155c360, {0x4004919000?, 0x40024d9d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2c840)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2c840, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155c360)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4376
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3486 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003743680, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400374cae0}, 0x4000d99b20, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3413 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda0cf0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40030f9880?, 0x4002e22000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40030f9880, {0x4002e22000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40030f9880, {0x4002e22000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014da0f8, {0x4002e22000?, 0x72?, 0x40037a70e8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40037a70e0, {0x4002e22000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4002e9b440)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002e9b440, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400318dd40, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4382 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd12a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7400?, 0x400491f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7400, {0x400491f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7400, {0x400491f000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014daf48, {0x400491f000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155c7e0, {0x400491f000?, 0x40024d4d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2cae0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2cae0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155c7e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4380
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4379 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155c360)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4376
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3435 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40033cebe0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3425
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3473 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003337900, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x400346ea80}, 0x4000a9fbd0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10304 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3577 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003b3e280, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40012b49d0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3730 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0de8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4002598f00?, 0x400447f000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4002598f00, {0x400447f000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4002598f00, {0x400447f000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001af1020, {0x400447f000?, 0x72?, 0x4001ba01e8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001ba01e0, {0x400447f000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003fafda0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003fafda0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4001c275f0, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 9754 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9155 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3569
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3566 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003af5cc0, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003bac480}, 0x40012071b0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3569
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10591 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4141 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0818, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003aab300?, 0x40031b7000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003aab300, {0x40031b7000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003aab300, {0x40031b7000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001af0ef8, {0x40031b7000?, 0x72?, 0x4003351598?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003351590, {0x40031b7000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003049260)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003049260, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4002dbc090, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4374 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400168f7a0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4371
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 9447 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10835 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4402 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155d320)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4392
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4405 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd0cd8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003a4f480?, 0x400489c000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003a4f480, {0x400489c000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003a4f480, {0x400489c000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40017b6700, {0x400489c000?, 0x13?, 0x3201c00000c00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001686a20, {0x400489c000?, 0x40024d6d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b4b440)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b4b440, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001686a20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4403
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 9291 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4365 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0438, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7200?, 0x4004911000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7200, {0x4004911000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7200, {0x4004911000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dae08, {0x4004911000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400168f0e0, {0x4004911000?, 0x4002d97d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003f7dce0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003f7dce0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400168f0e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4363
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3480 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003742c80, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x400346ff20}, 0x400354bd50, 0x0, 0x4003f60bd0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3408
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 9442 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3437 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40031f1c70})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40033dc780, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400077a130, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3425
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4362 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400168ec60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4359
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3570 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039f9cc0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4003b264e0}, 0x40039e5110, 0x0, 0x4003b2e1b0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3542
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3552 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4003b1ea50})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039f9b80, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400114d860, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3542
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3478 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400373eb40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003742b40, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000d98b00, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3408
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3479 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40031eb801?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4003d03560?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3408
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3571 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039f9e00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4003b1eb90, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3542
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4383 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155c7e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4380
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3550 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4003825720)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3542
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3440 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40033dca00, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x40031f1db0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3425
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3699 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0bf8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40043c2800?, 0x4004397000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40043c2800, {0x4004397000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40043c2800, {0x4004397000?, 0x1?, 0x4002dda380?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000a92e18, {0x4004397000?, 0xc?, 0x40032ead00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042c0d80, {0x4004397000?, 0x18550?, 0x4004252ae0?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043d1f20)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043d1f20, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042c0d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 3698
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3462 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40033dcc80, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x400077b1d0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3440
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3438 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40031a3c20?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001bf3a70?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3425
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3481 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003742dc0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400373ec80, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3408
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3476 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40034325a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3408
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3439 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40033dc8c0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40033de3c0}, 0x40031bfc70, 0x0, 0x4003d4a8a0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3425
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3467 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036c3040, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000de0040, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3481
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 9475 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10070 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3700 [select, 6 minutes]:
net/http.(*persistConn).writeLoop(0x40042c0d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 3698
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3677 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0a08, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004333400?, 0x400434a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004333400, {0x400434a000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004333400, {0x400434a000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001af0d50, {0x400434a000?, 0x72?, 0x400437a3c8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400437a3c0, {0x400434a000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4004329e60)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4004329e60, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4004400000, {0x3e237f0, 0x40022a8c00})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1705
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10036 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3603 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda0b00, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004006f00?, 0x40010bf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004006f00, {0x40010bf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004006f00, {0x40010bf000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014db9e8, {0x40010bf000?, 0x72?, 0x4004064518?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4004064510, {0x40010bf000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400170ad20)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400170ad20, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003c45cb0, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4366 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400168f0e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4363
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4148 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda10d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40033bdf00?, 0x40031b4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40033bdf00, {0x40031b4000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40033bdf00, {0x40031b4000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000a929f0, {0x40031b4000?, 0x72?, 0x4001cc0e18?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001cc0e10, {0x40031b4000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40031a2960)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40031a2960, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40026b8a20, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4353 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0628, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003a4f400?, 0x4004435000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003a4f400, {0x4004435000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003a4f400, {0x4004435000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dad58, {0x4004435000?, 0xf?, 0x400228ed00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40016866c0, {0x4004435000?, 0x4002f9ed18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003f7d020)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003f7d020, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40016866c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4319
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 9474 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4369 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd1590, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7280?, 0x4004913000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7280, {0x4004913000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7280, {0x4004913000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dae50, {0x4004913000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400168f440, {0x4004913000?, 0x4002d9bd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2c180)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2c180, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400168f440)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4367
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10067 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4373 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd1498, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7300?, 0x4004917000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7300, {0x4004917000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7300, {0x4004917000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dae80, {0x4004917000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400168f7a0, {0x4004917000?, 0x4001041d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2c420)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2c420, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400168f7a0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4371
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 9293 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10339 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9738 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 8901 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x400327b5e0, {0x40010c69d0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400327b5e0, {0x40010c69d0?, 0x40030dea08?, 0x4004515510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40010c6750, {0x40010c69d0?, 0x4004515598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40010c6750}, {0x40010c69d0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40016d58c0, {0x40010c69d0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40010c69c0, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40010c69c0, 0x40016d58c0, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40045157c8?, {0xffff6fe9d6d0, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40033ce140}, 0x4001513180?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4004ac73b0, {0x35bf9e0, 0x40033ce140})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0x4001709210)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1730 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x3e31c48?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 8899
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 10068 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4361 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0530, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7180?, 0x400490d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7180, {0x400490d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7180, {0x400490d000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dadd0, {0x400490d000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400168ec60, {0x400490d000?, 0x4004436d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003f7da40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003f7da40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400168ec60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4359
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4358 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400168e900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4355
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4357 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fda0ee0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7100?, 0x4004909000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7100, {0x4004909000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7100, {0x4004909000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dada0, {0x4004909000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400168e900, {0x4004909000?, 0x4003005d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003f7d380)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003f7d380, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400168e900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4355
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4354 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40016866c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4319
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4386 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd11b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7480?, 0x4004923000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7480, {0x4004923000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7480, {0x4004923000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014daf90, {0x4004923000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155cb40, {0x4004923000?, 0x4002f9fd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2cea0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2cea0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155cb40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4384
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4387 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155cb40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4384
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4390 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd10b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7500?, 0x4004927000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7500, {0x4004927000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7500, {0x4004927000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014dafd0, {0x4004927000?, 0x12?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155cfc0, {0x4004927000?, 0x4005051d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2d200)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2d200, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155cfc0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4388
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4391 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155cfc0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4388
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4401 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd0fc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7580?, 0x4004898000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7580, {0x4004898000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7580, {0x4004898000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40017b66b8, {0x4004898000?, 0x11?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155d320, {0x4004898000?, 0x400228ed18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4003ef99e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003ef99e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155d320)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4392
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4396 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd0ec8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7600?, 0x400492b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7600, {0x400492b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7600, {0x400492b000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014db020, {0x400492b000?, 0xf?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155d680, {0x400492b000?, 0x400504ed18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002b2d680)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002b2d680, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155d680)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4394
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4397 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155d680)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4394
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4400 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd0dd0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40039b7680?, 0x400492d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40039b7680, {0x400492d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40039b7680, {0x400492d000?, 0x4002dec000?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40014db070, {0x400492d000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400155d9e0, {0x400492d000?, 0x4005050d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4002ab2060)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4002ab2060, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400155d9e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4398
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4417 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400155d9e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4398
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 9477 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10038 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9294 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9303 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10342 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10037 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9314 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9018 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3569
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10873 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40030aac48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40030aac38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40030aac30, {0x400108c228, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400290acc8?}, {0x400108c228?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff6fe6fb58, 0x40030aac00}, {0x400108c228, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400199db18, {0x40039c2000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40036d6d20, 0x0, {0x3e02238, 0x400562b6c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40015d80e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400562b680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 213
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 9476 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10305 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 6340 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40019c9290, 0xc)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40019c9280)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0x400244b650)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:159 +0x134
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 818
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:176 +0x60

goroutine 10288 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 8975 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:117 +0x68
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn in goroutine 8974
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:116 +0xb4

goroutine 4744 [IO wait]:
internal/poll.runtime_pollWait(0xffff6fda0720, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40030f8b00?, 0x40031e0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40030f8b00, {0x40031e0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40030f8b00, {0x40031e0000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40012362c8, {0x40031e0000?, 0x72?, 0x4003c618f8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003c618f0, {0x40031e0000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003049560)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003049560, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400429b7a0, {0x3e237f0, 0x4001b97830})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1664
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10343 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9305 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10286 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9753 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 8974 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff6fcd0800, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400304bf00?, 0x4002e2d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0x400304bf00, {0x4002e2d000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x40000000)
	/usr/local/go/src/internal/poll/fd_unix.go:301 +0x284
net.(*netFD).readMsg(0x400304bf00, {0x4002e2d000?, 0x4002378900?, 0x40023788d0?}, {0x0?, 0x4003797ef0?, 0x4005975b88?}, 0x25809a0?)
	/usr/local/go/src/net/fd_posix.go:78 +0x30
net.(*UnixConn).readMsg(0x4000a92718, {0x4002e2d000?, 0x4005975be8?, 0x2577428?}, {0x0?, 0x4000fb8d80?, 0x400194a7f0?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x38
net.(*UnixConn).ReadMsgUnix(0x4000a92718, {0x4002e2d000?, 0x5?, 0x377a3b0?}, {0x0?, 0x1fd48?, 0x3788a53?})
	/usr/local/go/src/net/unixsock.go:143 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0x4000fb90b0, {0x3e23828, 0x4000762280}, 0x4000a92718)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:132 +0x12c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1 in goroutine 453
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x138

goroutine 10287 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9304 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9448 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9446 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9445 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10337 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9306 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9292 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10072 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10558 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10589 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9716 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10039 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9741 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10559 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10071 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9719 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10590 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9718 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9717 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9739 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10338 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10837 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 9740 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10069 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10560 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10588 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10593 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10487 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400235dcc8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400235dcb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400235dcb0, {0x40014f5801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4004f47cc8?}, {0x40014f5801?, 0xffffb6e46108?, 0x18706?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002385180)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002385180)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002385180, {0x30150e0, 0x4002352c00})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x40040114a0, {0x40027b0800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4001d25310, 0x0, {0x3e02238, 0x4000c7f3c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000354e40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40048b9940)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1467
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10840 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10834 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10823 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40015af350, 0x1c)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015af340)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40015af300, {0x3e23828, 0x4004dec8c0}, {0x4003b80090, 0x28}, 0x12f, {0x4004353225, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 8899
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 10833 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10742 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40030404c8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40030404b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40030404b0, {0x4003028c00, 0x200, 0x200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4003220cc8?}, {0x4003028c00?, 0x4003220cd8?, 0x696b0?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x400162fcc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x400162fcc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x400162fcc0, {0x30150e0, 0x4001a8d788})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003592960, {0x40023ff400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40031440f0, 0x0, {0x3e02238, 0x4001b3a000})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a4dce0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400153bf00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 813
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10799 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10839 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10836 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10824 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40015af0d0, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40015af0c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40015af080, {0x3e23828, 0x4004dec910}, {0x4004b5f3c0, 0x35}, 0x11, {0x4001c8bc85, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1731
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 10838 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3438
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10800 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 3479
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4
