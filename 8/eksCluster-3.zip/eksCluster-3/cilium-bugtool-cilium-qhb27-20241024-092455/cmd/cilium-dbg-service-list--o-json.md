[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.3.0.201",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.3.0.86",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.3.0.201",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.3.0.86",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.3.0.36",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 2379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "clustermesh-apiserver",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.244.114",
        "port": 2379,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.3.0.36",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 2379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "clustermesh-apiserver",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.244.114",
          "port": 2379,
          "scope": "external"
        },
        "id": 5
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.3.0.104",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 8080,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "echo-same-node",
        "namespace": "cilium-test-1",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.37.13",
        "port": 8080,
        "scope": "external"
      },
      "id": 6
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.3.0.104",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 8080,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "echo-same-node",
          "namespace": "cilium-test-1",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.37.13",
          "port": 8080,
          "scope": "external"
        },
        "id": 6
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.249.58",
          "port": 443,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "172.31.168.34",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.249.58",
            "port": 443,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "172.31.168.34",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.224.68",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.229.85",
        "port": 443,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.224.68",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.229.85",
          "port": 443,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.3.0.201",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.3.0.86",
          "nodeName": "ip-172-31-224-68.ec2.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.3.0.201",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.3.0.86",
            "nodeName": "ip-172-31-224-68.ec2.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 3
      }
    }
  }
]

