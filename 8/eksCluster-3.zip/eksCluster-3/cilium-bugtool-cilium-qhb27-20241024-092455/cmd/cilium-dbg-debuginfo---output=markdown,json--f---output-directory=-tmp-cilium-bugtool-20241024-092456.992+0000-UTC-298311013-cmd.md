markdown output at /tmp/cilium-bugtool-20241024-092456.992+0000-UTC-298311013/cmd/cilium-debuginfo-20241024-092527.318+0000-UTC.md
json output at /tmp/cilium-bugtool-20241024-092456.992+0000-UTC-298311013/cmd/cilium-debuginfo-20241024-092527.318+0000-UTC.json
