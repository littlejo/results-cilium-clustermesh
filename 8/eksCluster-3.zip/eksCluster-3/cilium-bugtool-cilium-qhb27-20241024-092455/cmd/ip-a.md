1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 12:8e:8d:ec:57:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.224.68/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3128sec preferred_lft 3128sec
    inet6 fe80::108e:8dff:feec:57b3/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:b9:ca:81:07:c1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::20b9:caff:fe81:7c1/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:4b:26:a1:59:9d brd ff:ff:ff:ff:ff:ff
    inet 10.3.0.17/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::484b:26ff:fea1:599d/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether fa:ec:07:5f:ce:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f8ec:7ff:fe5f:ce00/64 scope link 
       valid_lft forever preferred_lft forever
7: lxc_health@if6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:0e:3b:eb:13:74 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d80e:3bff:feeb:1374/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc422e86ee6938@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:49:cd:e7:f2:87 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f849:cdff:fee7:f287/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc8dc60a0ee3a4@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:57:40:cf:8e:3a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9457:40ff:fecf:8e3a/64 scope link 
       valid_lft forever preferred_lft forever
15: lxcc8004aec05c5@if14: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:50:d6:81:c5:52 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b450:d6ff:fe81:c552/64 scope link 
       valid_lft forever preferred_lft forever
17: lxccc43534951d1@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:e8:65:32:d4:ed brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::38e8:65ff:fe32:d4ed/64 scope link 
       valid_lft forever preferred_lft forever
19: lxcc26c557f77ed@if18: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:cf:34:d3:54:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::eccf:34ff:fed3:54b7/64 scope link 
       valid_lft forever preferred_lft forever
21: lxc8291c229ab50@if20: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:d0:f5:e5:ff:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::6cd0:f5ff:fee5:ffc9/64 scope link 
       valid_lft forever preferred_lft forever
