KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 8/254 allocated from 10.3.0.0/24, 
Allocated addresses:
  10.3.0.104 (cilium-test-1/echo-same-node-86d9cc975c-nld2x)
  10.3.0.112 (cilium-test-1/client-974f6c69d-jchj9)
  10.3.0.118 (cilium-test-1/client2-57cf4468f-fj8rc)
  10.3.0.17 (router)
  10.3.0.201 (kube-system/coredns-586b798467-s6stj)
  10.3.0.36 (kube-system/clustermesh-apiserver-5754b9869c-g52pg)
  10.3.0.83 (health)
  10.3.0.86 (kube-system/coredns-586b798467-rkx67)
ClusterMesh:   7/7 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 6 endpoints, 5 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 6185da4bad1b3291
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      57/57 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    32s ago        never        0       no error   
  ct-map-pressure                                                     3s ago         never        0       no error   
  daemon-validate-config                                              26s ago        never        0       no error   
  dns-garbage-collector-job                                           38s ago        never        0       no error   
  endpoint-1013-regeneration-recovery                                 never          never        0       no error   
  endpoint-1768-regeneration-recovery                                 never          never        0       no error   
  endpoint-2870-regeneration-recovery                                 never          never        0       no error   
  endpoint-490-regeneration-recovery                                  never          never        0       no error   
  endpoint-535-regeneration-recovery                                  never          never        0       no error   
  endpoint-671-regeneration-recovery                                  never          never        0       no error   
  endpoint-679-regeneration-recovery                                  never          never        0       no error   
  endpoint-830-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         2m38s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                3s ago         never        0       no error   
  ipcache-inject-labels                                               33s ago        never        0       no error   
  k8s-heartbeat                                                       20s ago        never        0       no error   
  link-cache                                                          3s ago         never        0       no error   
  local-identity-checkpoint                                           40s ago        never        0       no error   
  node-neighbor-link-updater                                          3s ago         never        0       no error   
  remote-etcd-cmesh1                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh2                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh3                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh5                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh6                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh7                                                  6m14s ago      never        0       no error   
  remote-etcd-cmesh8                                                  6m14s ago      never        0       no error   
  resolve-identity-1013                                               2m32s ago      never        0       no error   
  resolve-identity-1768                                               2m33s ago      never        0       no error   
  resolve-identity-2870                                               1m42s ago      never        0       no error   
  resolve-identity-490                                                13s ago        never        0       no error   
  resolve-identity-535                                                2m33s ago      never        0       no error   
  resolve-identity-671                                                2m33s ago      never        0       no error   
  resolve-identity-679                                                12s ago        never        0       no error   
  resolve-identity-830                                                14s ago        never        0       no error   
  resolve-labels-cilium-test-1/client-974f6c69d-jchj9                 5m14s ago      never        0       no error   
  resolve-labels-cilium-test-1/client2-57cf4468f-fj8rc                5m13s ago      never        0       no error   
  resolve-labels-cilium-test-1/echo-same-node-86d9cc975c-nld2x        5m12s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-5754b9869c-g52pg   6m42s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-rkx67                 7m33s ago      never        0       no error   
  resolve-labels-kube-system/coredns-586b798467-s6stj                 7m33s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                      7m33s ago      never        0       no error   
  sync-policymap-1013                                                 7m27s ago      never        0       no error   
  sync-policymap-1768                                                 7m27s ago      never        0       no error   
  sync-policymap-2870                                                 6m42s ago      never        0       no error   
  sync-policymap-490                                                  5m13s ago      never        0       no error   
  sync-policymap-535                                                  7m31s ago      never        0       no error   
  sync-policymap-671                                                  7m32s ago      never        0       no error   
  sync-policymap-679                                                  5m12s ago      never        0       no error   
  sync-policymap-830                                                  5m13s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1768)                                   13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (2870)                                   12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (490)                                    3s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (535)                                    13s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (679)                                    12s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (830)                                    4s ago         never        0       no error   
  sync-utime                                                          33s ago        never        0       no error   
  write-cni-file                                                      7m38s ago      never        0       no error   
Proxy Status:            OK, ip 10.3.0.17, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 262144, max 327679
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 26.68   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                                          Disabled         
Cluster health:                                      8/8 reachable    (2024-10-24T09:24:58Z)
  Name                                               IP               Node        Endpoints
  cmesh4/ip-172-31-224-68.ec2.internal (localhost)   172.31.224.68    reachable   reachable
  cmesh1/ip-172-31-190-177.ec2.internal              172.31.190.177   reachable   reachable
  cmesh2/ip-172-31-234-224.ec2.internal              172.31.234.224   reachable   reachable
  cmesh3/ip-172-31-140-200.ec2.internal              172.31.140.200   reachable   reachable
  cmesh5/ip-172-31-167-173.ec2.internal              172.31.167.173   reachable   reachable
  cmesh6/ip-172-31-249-188.ec2.internal              172.31.249.188   reachable   reachable
  cmesh7/ip-172-31-162-53.ec2.internal               172.31.162.53    reachable   reachable
  cmesh8/ip-172-31-208-9.ec2.internal                172.31.208.9     reachable   reachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] OK (4.956µs) [4] (5m14s, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (7m38s, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (19.938µs) (2m38s, x1)
      │   ├── bgp-control-plane
      │   │   └── job-diffstore-events                            [OK] Running (7m33s, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (7m33s, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (7m33s, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (26s, x8)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (3s, x16)
      │   │   └── job-sync-hostips                                [OK] Synchronized (33s, x8)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-1013 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x11)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1013 (7m27s, x1)
      │   │   ├── cilium-endpoint-1768 (kube-system/coredns-586b798467-rkx67)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (1768) (3s, x47)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x12)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-1768 (7m27s, x1)
      │   │   ├── cilium-endpoint-2870 (kube-system/clustermesh-apiserver-5754b9869c-g52pg)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2870) (2s, x42)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x9)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2870 (6m42s, x1)
      │   │   ├── cilium-endpoint-490 (cilium-test-1/client2-57cf4468f-fj8rc)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (490) (3s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (43s, x123)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-490 (5m13s, x1)
      │   │   ├── cilium-endpoint-535 (kube-system/coredns-586b798467-s6stj)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (535) (3s, x47)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x12)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-535 (7m31s, x1)
      │   │   ├── cilium-endpoint-671 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (5m10s, x13)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-671 (7m32s, x1)
      │   │   ├── cilium-endpoint-679 (cilium-test-1/echo-same-node-86d9cc975c-nld2x)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (679) (2s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (2m7s, x75)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-679 (5m12s, x1)
      │   │   ├── cilium-endpoint-830 (cilium-test-1/client-974f6c69d-jchj9)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (830) (4s, x33)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (43s, x112)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-830 (5m13s, x1)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (2m38s, x2)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (2.651708ms) (2m33s, x1)
      │   ├── l2-announcer
      │   │   └── job-l2-announcer lease-gc                       [OK] Running (7m38s, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (93s, x4)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (4m14s, x4)
      │   │   └── nodes-add                                       [OK] Node adds successful (6m14s, x8)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 1 NodePort frontend addresses (7m33s, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Synchronized (6m14s, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (7m33s, x1)
      │   └── timer-job-device-reloader                           [OK] OK (391.175442ms) (5m10s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (34.592µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (7m38s, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 0 objects (7m38s, x1)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (7m33s, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (7m33s, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (1.756µs) (3s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] 10.3.0.17 (primary), fe80::484b:26ff:fea1:599d (primary) (7m35s, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 20 objects (7m31s, x15)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (7m50s, x1)
      
