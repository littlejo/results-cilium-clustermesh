Found 7 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh7":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh7

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.244.114
     ✅ TCP connection successfully established to 10.100.244.114:2379
     ✅ TLS connection successfully established to 10.100.244.114:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       45:c4:e6:69:0a:5a:7d:62:71:8b:70:02:28:ff:70:a8
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:16:57 +0000 UTC
          Not after:   2027-10-24 09:16:57 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       7f:d6:5b:8d:2b:43:b3:9e:43:b2:94:51:d9:c3:22:05:ff:a6:22:32
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: 6185da4bad1b3291
