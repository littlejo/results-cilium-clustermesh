[
  {
    "containers": [
      {
        "cgroup-id": 9099,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb54c44e_b33a_43cc_8612_425f00173094.slice/cri-containerd-33bb62d6476801ca6f23516f68130678cf6102def244a162eddf60fa90fd773e.scope"
      },
      {
        "cgroup-id": 9015,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb54c44e_b33a_43cc_8612_425f00173094.slice/cri-containerd-317076ba3451759fe58b894f27f5bffb861712eb1137558c85bf5a3ebbdcb317.scope"
      }
    ],
    "ips": [
      "10.3.0.104"
    ],
    "name": "echo-same-node-86d9cc975c-nld2x",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8091,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-60c64b1331fbca921e2e113955b12a45a2b2a8462884eaabd0866ae3d2bb1040.scope"
      },
      {
        "cgroup-id": 8175,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-76233038d2ee4fbfc555f9b33924aa620f8ee341b5295cc346db860c72589138.scope"
      },
      {
        "cgroup-id": 8259,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef70bb7_9330_4bb3_83fb_747939728510.slice/cri-containerd-84f7814306c30269e0f0f2fb4c8378f045d877c5025526815954adfa10f69cb1.scope"
      }
    ],
    "ips": [
      "10.3.0.36"
    ],
    "name": "clustermesh-apiserver-5754b9869c-g52pg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8847,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2a6ed49_0cd6_4760_8aec_91b44ce6bf82.slice/cri-containerd-d60a38e3e0b105612a847328714a25c276a249a00f53c11f3253aeda7997601c.scope"
      }
    ],
    "ips": [
      "10.3.0.112"
    ],
    "name": "client-974f6c69d-jchj9",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6579,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcdf657ba_8dc6_4b2b_8d4d_d726a4ad0fa3.slice/cri-containerd-ae11f1f5c4e34331ef4ee5e6da04c9c49d4a4cdef93310b5278015612553c9c1.scope"
      }
    ],
    "ips": [
      "10.3.0.201"
    ],
    "name": "coredns-586b798467-s6stj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6747,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51141781_c82e_4e4b_bdfd_04577357a57a.slice/cri-containerd-1e344be07bfd20d0b67d14ba306259d952237f1dd7b778ee060fe86bc6434c48.scope"
      }
    ],
    "ips": [
      "10.3.0.86"
    ],
    "name": "coredns-586b798467-rkx67",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8763,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5380b96_865f_426a_8e0c_9d6c80948034.slice/cri-containerd-1f8a32bf3a626d2b0d87c5ac7f0e75958e37027b5ab2621094f81234ac3896fd.scope"
      }
    ],
    "ips": [
      "10.3.0.118"
    ],
    "name": "client2-57cf4468f-fj8rc",
    "namespace": "cilium-test-1"
  }
]

