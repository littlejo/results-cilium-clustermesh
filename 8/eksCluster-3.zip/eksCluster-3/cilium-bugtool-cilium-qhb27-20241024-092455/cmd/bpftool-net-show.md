xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 532
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 524
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 519
cilium_host(4) clsact/egress cil_from_host-cilium_host id 514
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 462
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 459
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 508
lxc422e86ee6938(9) clsact/ingress cil_from_container-lxc422e86ee6938 id 511
lxc8dc60a0ee3a4(11) clsact/ingress cil_from_container-lxc8dc60a0ee3a4 id 551
lxcc8004aec05c5(15) clsact/ingress cil_from_container-lxcc8004aec05c5 id 601
lxccc43534951d1(17) clsact/ingress cil_from_container-lxccc43534951d1 id 3678
lxcc26c557f77ed(19) clsact/ingress cil_from_container-lxcc26c557f77ed id 3672
lxc8291c229ab50(21) clsact/ingress cil_from_container-lxc8291c229ab50 id 3381

flow_dissector:

netfilter:

