## Map: cilium_tunnel_map
Key        Value              State   Error
10.2.0.0   172.31.140.200:0   sync    
10.3.0.0   172.31.224.68:0    sync    
10.5.0.0   172.31.249.188:0   sync    
10.4.0.0   172.31.167.173:0   sync    
10.0.0.0   172.31.190.177:0   sync    
10.7.0.0   172.31.208.9:0     sync    
10.1.0.0   172.31.234.224:0   sync    

## Map: cilium_lb4_backends_v3
Key   Value                  State   Error
1     ANY://172.31.225.5     sync    
2     ANY://172.31.162.53    sync    
3     ANY://10.6.0.91        sync    
4     ANY://10.6.0.91        sync    
5     ANY://10.6.0.115       sync    
8     ANY://172.31.133.199   sync    
10    ANY://10.6.0.145       sync    
6     ANY://10.6.0.115       sync    
9     ANY://10.6.0.93        sync    

## Map: cilium_policy_01670
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           

## Map: cilium_policy_01296
Key              Value         State   Error
Ingress: 0 ANY   0 58 5318             
Egress: 0 ANY    0 132 12916           
Ingress: 1 ANY   0 626 54477           

## Map: cilium_policy_00192
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_lxc
Key               Value                                                                                             State   Error
172.31.162.53:0   (localhost)                                                                                       sync    
10.6.0.91:0       id=2405  sec_id=507362 flags=0x0000 ifindex=11  mac=BA:AB:53:ED:75:6B nodemac=1E:5F:F4:10:4D:33   sync    
10.6.0.93:0       id=1263  sec_id=516201 flags=0x0000 ifindex=15  mac=AE:DA:C9:ED:25:F0 nodemac=2A:3E:5F:E0:86:41   sync    
10.6.0.145:0      id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52   sync    
10.6.0.102:0      (localhost)                                                                                       sync    
10.6.0.250:0      id=2501  sec_id=4     flags=0x0000 ifindex=7   mac=A6:E1:08:4B:B6:2C nodemac=82:7A:40:B0:1F:D5    sync    
10.6.0.115:0      id=1296  sec_id=507362 flags=0x0000 ifindex=9   mac=CA:AD:9B:58:01:84 nodemac=0E:DA:1C:10:07:D7   sync    
10.6.0.112:0      id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D   sync    
10.6.0.85:0       id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E   sync    

## Map: cilium_lb4_source_range
Cache is empty


## Map: cilium_runtime_config
Key             Value              State   Error
UTimeOffset     3378439957031250           
AgentLiveness   670580879043               
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          
Unknown         0                          

## Map: cilium_ipcache
Key                 Value                                                                      State   Error
172.31.225.5/32     identity=16777217 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.6.0.93/32        identity=516201 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
172.31.208.9/32     identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.7.0.95/32        identity=6 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
172.31.234.224/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.36/32        identity=200572 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.1.0.16/32        identity=157096 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.1.0.39/32        identity=4 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.2.0.154/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.4.0.75/32        identity=361562 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.93/32        identity=350710 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.3.0.86/32        identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.7.0.6/32         identity=528627 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.0.0.239/32       identity=67854 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.58/32        identity=86420 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
172.31.249.188/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.244/32       identity=395399 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.4.0.200/32       identity=359982 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.4.0.224/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.1.0.56/32        identity=147144 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.2.0.168/32       identity=225266 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.7.0.201/32       identity=556252 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.6.0.102/32       identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.190.177/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.2.0.161/32       identity=6 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.5.0.80/32        identity=4 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.3.0.112/32       identity=281016 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.5.0.38/32        identity=406305 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.6.0.250/32       identity=4 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
172.31.162.53/32    identity=1 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.1.0.252/32       identity=151863 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.6.0.85/32        identity=505656 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.1.0.196/32       identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
10.1.0.64/32        identity=135727 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.140.200/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.3.0.118/32       identity=296497 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.4.0.230/32       identity=6 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.4.0.105/32       identity=4 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>        sync    
10.1.0.5/32         identity=6 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>        sync    
10.2.0.242/32       identity=207272 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.7.0.141/32       identity=536794 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.25/32        identity=221974 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
0.0.0.0/0           identity=2 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.6.0.115/32       identity=507362 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.3.0.201/32       identity=292468 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.3.0.83/32        identity=4 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.4.0.239/32       identity=332688 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.0.0.133/32       identity=90675 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.6.0.91/32        identity=507362 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.7.0.123/32       identity=4 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>          sync    
10.7.0.104/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.6.0.145/32       identity=514866 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.1.0.21/32        identity=148646 encryptkey=0 tunnelendpoint=172.31.234.224, flags=<none>   sync    
172.31.133.199/32   identity=16777218 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>        sync    
10.4.0.163/32       identity=336619 encryptkey=0 tunnelendpoint=172.31.167.173, flags=<none>   sync    
10.7.0.228/32       identity=585156 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.34/32        identity=4 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>        sync    
10.3.0.36/32        identity=286632 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
10.5.0.83/32        identity=400535 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.6.0.112/32       identity=465367 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>          sync    
10.0.0.115/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.193/32       identity=4 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.7.0.78/32        identity=580057 encryptkey=0 tunnelendpoint=172.31.208.9, flags=<none>     sync    
10.2.0.185/32       identity=220496 encryptkey=0 tunnelendpoint=172.31.140.200, flags=<none>   sync    
10.3.0.17/32        identity=6 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>         sync    
10.0.0.242/32       identity=82485 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.0.0.119/32       identity=6 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>        sync    
10.5.0.187/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.5.0.219/32       identity=6 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>        sync    
10.0.0.146/32       identity=73336 encryptkey=0 tunnelendpoint=172.31.190.177, flags=<none>    sync    
10.5.0.160/32       identity=397076 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
172.31.167.173/32   identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    
10.5.0.226/32       identity=409754 encryptkey=0 tunnelendpoint=172.31.249.188, flags=<none>   sync    
10.3.0.104/32       identity=268163 encryptkey=0 tunnelendpoint=172.31.224.68, flags=<none>    sync    
172.31.224.68/32    identity=6 encryptkey=0 tunnelendpoint=0.0.0.0, flags=<none>               sync    

## Map: cilium_lb4_services_v2
Key                     Value                State   Error
10.100.0.10:53 (2)      6 0 (3) [0x0 0x0]    sync    
10.100.28.6:8080 (1)    10 0 (6) [0x0 0x0]   sync    
10.100.0.10:53 (0)      0 2 (3) [0x0 0x0]    sync    
10.100.0.10:9153 (1)    4 0 (4) [0x0 0x0]    sync    
10.100.0.10:9153 (2)    5 0 (4) [0x0 0x0]    sync    
10.100.0.10:53 (1)      3 0 (3) [0x0 0x0]    sync    
10.100.0.1:443 (2)      8 0 (1) [0x0 0x0]    sync    
10.100.28.6:8080 (0)    0 1 (6) [0x0 0x0]    sync    
10.100.0.1:443 (1)      1 0 (1) [0x0 0x0]    sync    
10.100.0.1:443 (0)      0 2 (1) [0x0 0x0]    sync    
10.100.0.10:9153 (0)    0 2 (4) [0x0 0x0]    sync    
10.100.3.251:2379 (1)   9 0 (5) [0x0 0x0]    sync    
10.100.36.34:443 (0)    0 1 (2) [0x0 0x10]   sync    
10.100.36.34:443 (1)    2 0 (2) [0x0 0x0]    sync    
10.100.3.251:2379 (0)   0 1 (5) [0x0 0x0]    sync    

## Map: cilium_policy_02405
Key              Value         State   Error
Ingress: 0 ANY   0 66 6058             
Egress: 0 ANY    0 135 13223           
Ingress: 1 ANY   0 634 55123           

## Map: cilium_policy_00760
Key              Value           State   Error
Ingress: 0 ANY   0 36 4614               
Egress: 0 ANY    0 0 0                   
Ingress: 1 ANY   0 3512 300911           

## Map: cilium_lb4_reverse_nat
Key   Value               State   Error
3     10.100.0.10:53      sync    
4     10.100.0.10:9153    sync    
5     10.100.3.251:2379   sync    
6     10.100.28.6:8080    sync    
1     10.100.0.1:443      sync    
2     10.100.36.34:443    sync    

## Map: cilium_policy_02501
Key              Value         State   Error
Ingress: 0 ANY   0 289 23259           
Egress: 0 ANY    0 0 0                 
Ingress: 1 ANY   0 91 8047             

## Map: cilium_policy_03187
Key              Value   State   Error
Ingress: 0 ANY   0 0 0           
Egress: 0 ANY    0 0 0           
Ingress: 1 ANY   0 0 0           

## Map: cilium_policy_01263
Key              Value           State   Error
Ingress: 0 ANY   0 2046 218926           
Egress: 0 ANY    0 2210 235959           
Ingress: 1 ANY   0 2177 209777           

## Map: cilium_node_map
Cache is disabled


## Map: cilium_auth_map
Cache is disabled


## Map: cilium_node_map_v2
Cache is disabled


## Map: cilium_metrics
Cache is disabled


## Map: cilium_l2_responder_v4
Cache is disabled


