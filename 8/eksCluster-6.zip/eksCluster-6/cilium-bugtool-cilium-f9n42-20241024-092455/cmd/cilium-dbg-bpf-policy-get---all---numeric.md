Endpoint ID: 192
Path: /sys/fs/bpf/tc/globals/cilium_policy_00192

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 760
Path: /sys/fs/bpf/tc/globals/cilium_policy_00760

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    4614     36        0        
Allow    Ingress     1          ANY          NONE         disabled    300911   3512      0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1263
Path: /sys/fs/bpf/tc/globals/cilium_policy_01263

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    218926   2046      0        
Allow    Ingress     1          ANY          NONE         disabled    209777   2177      0        
Allow    Egress      0          ANY          NONE         disabled    235959   2210      0        


Endpoint ID: 1296
Path: /sys/fs/bpf/tc/globals/cilium_policy_01296

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5318    58        0        
Allow    Ingress     1          ANY          NONE         disabled    54477   626       0        
Allow    Egress      0          ANY          NONE         disabled    12916   132       0        


Endpoint ID: 1670
Path: /sys/fs/bpf/tc/globals/cilium_policy_01670

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2405
Path: /sys/fs/bpf/tc/globals/cilium_policy_02405

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    6058    66        0        
Allow    Ingress     1          ANY          NONE         disabled    55123   634       0        
Allow    Egress      0          ANY          NONE         disabled    13223   135       0        


Endpoint ID: 2501
Path: /sys/fs/bpf/tc/globals/cilium_policy_02501

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    23193   288       0        
Allow    Ingress     1          ANY          NONE         disabled    8047    91        0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3187
Path: /sys/fs/bpf/tc/globals/cilium_policy_03187

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


