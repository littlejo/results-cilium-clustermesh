[
  {
    "containers": [
      {
        "cgroup-id": 9094,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod414261e0_d90b_41a3_9fcd_a30bb38d481b.slice/cri-containerd-a42353abb385fd03ff8b473b6f99b733c4824606560d60f8c00dfb6d7dd46ad6.scope"
      },
      {
        "cgroup-id": 9010,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod414261e0_d90b_41a3_9fcd_a30bb38d481b.slice/cri-containerd-dd793dd16cc8610e6444279ee755df6805f12cd02aeddf62981018a8202a2e3b.scope"
      }
    ],
    "ips": [
      "10.6.0.145"
    ],
    "name": "echo-same-node-86d9cc975c-h4csn",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8926,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18da6df0_97dc_4afc_8894_b5d66cd77f47.slice/cri-containerd-9f045a814ad784414c2e8b6cf1190f687ed67e04685df167761e44b9441cb220.scope"
      }
    ],
    "ips": [
      "10.6.0.112"
    ],
    "name": "client-974f6c69d-7zqtx",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 6742,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podceeb59d6_f846_4dae_9d99_3acf47532e55.slice/cri-containerd-9978af32e81431e34e13bb671b2f19e5f5166eeed91b02ed69cf21a133eb0afa.scope"
      }
    ],
    "ips": [
      "10.6.0.115"
    ],
    "name": "coredns-586b798467-zw6mq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 8842,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod474ce03d_9849_4385_9510_a09682b6094d.slice/cri-containerd-4c43ffcd4941828915527d1ee6139eedcefc6a761d29c77c01e6b93603f7695c.scope"
      }
    ],
    "ips": [
      "10.6.0.85"
    ],
    "name": "client2-57cf4468f-5khv7",
    "namespace": "cilium-test-1"
  },
  {
    "containers": [
      {
        "cgroup-id": 8086,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-06cb8ba2de88b95e85e1a232b6b951d693942530625f82b7a30add3a54f74e67.scope"
      },
      {
        "cgroup-id": 8170,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-13614f20b9b5045f43b0614f5c53708ccf5f225a5d039f4143579fa91900627e.scope"
      },
      {
        "cgroup-id": 8254,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-4ee546f0bd422d977766c689aa0e07d6a0e43489f45922de17fb40faed707edc.scope"
      }
    ],
    "ips": [
      "10.6.0.93"
    ],
    "name": "clustermesh-apiserver-78c75dc487-zhf52",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 6574,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f54240f_6f81_4d1d_9282_6779d6a631b8.slice/cri-containerd-cb446894beddcbb42bbbe2be6eecd7e8727b8cbe9220b65ed9bedf88ae662d33.scope"
      }
    ],
    "ips": [
      "10.6.0.91"
    ],
    "name": "coredns-586b798467-jj4x6",
    "namespace": "kube-system"
  }
]

