IP ADDRESS        LOCAL ENDPOINT INFO
10.6.0.145:0      id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52   
10.6.0.250:0      id=2501  sec_id=4     flags=0x0000 ifindex=7   mac=A6:E1:08:4B:B6:2C nodemac=82:7A:40:B0:1F:D5    
172.31.162.53:0   (localhost)                                                                                       
10.6.0.85:0       id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E   
10.6.0.91:0       id=2405  sec_id=507362 flags=0x0000 ifindex=11  mac=BA:AB:53:ED:75:6B nodemac=1E:5F:F4:10:4D:33   
10.6.0.102:0      (localhost)                                                                                       
10.6.0.93:0       id=1263  sec_id=516201 flags=0x0000 ifindex=15  mac=AE:DA:C9:ED:25:F0 nodemac=2A:3E:5F:E0:86:41   
10.6.0.112:0      id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D   
10.6.0.115:0      id=1296  sec_id=507362 flags=0x0000 ifindex=9   mac=CA:AD:9B:58:01:84 nodemac=0E:DA:1C:10:07:D7   
