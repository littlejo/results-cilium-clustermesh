Total: 335
TCP:   340 (estab 53, closed 268, orphaned 0, timewait 209)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  72        62        10       
INET	  82        68        14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                  172.31.162.53%ens5:68         0.0.0.0:*    uid:192 ino:15913 sk:101a cgroup:unreachable:bd0 <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:23802 sk:101b cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15722 sk:101c cgroup:unreachable:e8e <->                                    
UNCONN 0      0                           127.0.0.1:36409      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=43)) ino:21448 sk:101d fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                [::]:8472          [::]:*    ino:23801 sk:101e cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15723 sk:101f cgroup:unreachable:e8e v6only:1 <->                           
UNCONN 0      0      [fe80::4e:27ff:fee1:f215]%ens5:546           [::]:*    uid:192 ino:15909 sk:1020 cgroup:unreachable:bd0 v6only:1 <->                   
