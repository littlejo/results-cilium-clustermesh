top - 09:24:57 up 10 min,  0 users,  load average: 0.37, 0.34, 0.22
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 24.1 us, 27.6 sy,  0.0 ni, 44.8 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   3836.2 total,   1008.0 free,    722.9 used,   2105.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   2936.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
   2945 root      20   0 1240432  16676  11356 S   6.2   0.4   0:00.03 cilium-+
   3017 root      20   0 1243764  19156  13636 S   6.2   0.5   0:00.01 hubble
      1 root      20   0 1405020 188616  80280 S   0.0   4.8   0:23.85 cilium-+
    538 root      20   0 1228848   4292   3396 S   0.0   0.1   0:00.01 cilium-+
   2939 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
   2981 root      20   0    6576   2428   2104 R   0.0   0.1   0:00.00 top
   2992 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
   3011 root      20   0 1228744   3712   3040 S   0.0   0.1   0:00.00 gops
