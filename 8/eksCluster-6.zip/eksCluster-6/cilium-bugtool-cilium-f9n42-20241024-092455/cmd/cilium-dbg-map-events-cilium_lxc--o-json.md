{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.905Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.934Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.940Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:36.975Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.357Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.376Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.402Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.415Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.444Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.681Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.697Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.729Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.741Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:39.767Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.128Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.187Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.206Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.243Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.260Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.285Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.502Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.520Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.551Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.562Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:42.588Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.900Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.940Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.954Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:44.988Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.035Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.057Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.337Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.344Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.414Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.430Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:45.456Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.746Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.791Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.801Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.823Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.851Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:47.859Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.110Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.121Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.152Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.159Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:48.192Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.540Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.593Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.593Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.631Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.639Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.669Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.877Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.938Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.956Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.983Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:50.996Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.305Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.316Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.347Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.358Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.380Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.599Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.610Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.650Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.655Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:53.686Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.026Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.053Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.065Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.092Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.104Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.332Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.334Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.336Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:22:56.367Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.020Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.023Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.095Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.103Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.133Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.368Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:01.372Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:09.963Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:09.966Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:11.371Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:18.171Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:18.410Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:25.208Z",
  "value": "id=760   sec_id=514866 flags=0x0000 ifindex=21  mac=1E:FD:DE:11:7A:10 nodemac=7A:AF:A3:03:73:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:25.485Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:25.490Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:25.493Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.250Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.297Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.302Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.583Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.594Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:32.596Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.343Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.395Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.422Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.709Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.713Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:39.714Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.575Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.616Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.630Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.878Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.885Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:23:52.888Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.840Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.892Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:05.899Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:06.172Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:06.173Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:06.195Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:19.087Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:19.165Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:19.172Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:19.488Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:19.499Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.509Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.513Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.788Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:36.794Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:49.788Z",
  "value": "id=192   sec_id=505656 flags=0x0000 ifindex=19  mac=F2:61:8F:63:F2:9C nodemac=B2:77:2F:D0:B5:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.6.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-24T09:24:49.806Z",
  "value": "id=3187  sec_id=465367 flags=0x0000 ifindex=17  mac=D2:2D:25:0C:C5:21 nodemac=F2:18:31:F3:72:6D"
}

