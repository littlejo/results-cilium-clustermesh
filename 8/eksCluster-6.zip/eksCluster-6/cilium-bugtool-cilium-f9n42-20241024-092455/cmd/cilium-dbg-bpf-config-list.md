KEY             VALUE
AgentLiveness   669580973640
UTimeOffset     3378439957031250
