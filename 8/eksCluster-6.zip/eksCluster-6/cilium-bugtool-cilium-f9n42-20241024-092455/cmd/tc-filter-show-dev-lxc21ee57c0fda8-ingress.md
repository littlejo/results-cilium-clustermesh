filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc21ee57c0fda8 direct-action not_in_hw id 3682 tag a28b9206a72cb3ac jited 
