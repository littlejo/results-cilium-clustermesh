alloc: 49.62MB (52029384 bytes)
total-alloc: 1.44GB (1550863912 bytes)
sys: 108.43MB (113691956 bytes)
lookups: 0
mallocs: 46701880
frees: 46267938
heap-alloc: 49.62MB (52029384 bytes)
heap-sys: 93.38MB (97918976 bytes)
heap-idle: 27.53MB (28868608 bytes)
heap-in-use: 65.85MB (69050368 bytes)
heap-released: 3.58MB (3751936 bytes)
heap-objects: 433942
stack-in-use: 6.59MB (6914048 bytes)
stack-sys: 6.59MB (6914048 bytes)
stack-mspan-inuse: 1.01MB (1059680 bytes)
stack-mspan-sys: 1.21MB (1272960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 726.80KB (744241 bytes)
gc-sys: 4.60MB (4827816 bytes)
next-gc: when heap-alloc >= 85.47MB (89617000 bytes)
last-gc: 2024-10-24 09:24:58.112007509 +0000 UTC
gc-pause-total: 9.23895ms
gc-pause: 84765
gc-pause-end: 1729761898112007509
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0006076511386398348
enable-gc: true
debug-gc: false
