Found 7 cluster configurations

Cluster "cmesh1":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh1

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh2":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh2

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh3":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh3

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh4":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh4

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh5":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh5

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh6":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh6

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d

Cluster "cmesh8":
📄 Configuration path: /var/lib/cilium/clustermesh/cmesh8

🔌 Endpoints:
   - https://clustermesh-apiserver.kube-system.svc:2379
     ✅ Hostname resolved to: 10.100.3.251
     ✅ TCP connection successfully established to 10.100.3.251:2379
     ✅ TLS connection successfully established to 10.100.3.251:2379
     ℹ️  Negotiated TLS version: TLS 1.3, ciphersuite TLS_AES_128_GCM_SHA256
     ℹ️  Etcd server version: 3.5.14

🔑 Digital certificates:
   ✅ TLS Root CA certificates:
      - Serial number:       51:b1:eb:62:af:21:4f:80:62:76:96:b9:35:00:c0:b5
        Subject:             CN=Cilium CA
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:25 +0000 UTC
          Not after:   2027-10-24 09:14:25 +0000 UTC
   ✅ TLS client certificates:
      - Serial number:       20:99:40:a9:bb:2d:64:b7:62:af:de:a3:c8:96:cb:aa:b0:09:ee:fe
        Subject:             CN=remote
        Issuer:              CN=Cilium CA
        Validity:
          Not before:  2024-10-24 09:14:00 +0000 UTC
          Not after:   2027-10-24 09:14:00 +0000 UTC
        ⚠️ Cannot verify certificate with the configured root CAs

⚙️ Etcd client:
   ✅ Etcd connection successfully established
   ℹ️  Etcd cluster ID: f314d48ce753332d
