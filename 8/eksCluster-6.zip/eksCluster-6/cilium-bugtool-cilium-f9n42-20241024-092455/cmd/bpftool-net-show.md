xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 552
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 533
cilium_host(4) clsact/egress cil_from_host-cilium_host id 535
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 465
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 462
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 509
lxcdca7cc2c0dcb(9) clsact/ingress cil_from_container-lxcdca7cc2c0dcb id 524
lxcfdabdc3df928(11) clsact/ingress cil_from_container-lxcfdabdc3df928 id 500
lxc9037ae74cb02(15) clsact/ingress cil_from_container-lxc9037ae74cb02 id 597
lxc21ee57c0fda8(17) clsact/ingress cil_from_container-lxc21ee57c0fda8 id 3682
lxcf447f6378717(19) clsact/ingress cil_from_container-lxcf447f6378717 id 3675
lxc8471e19d2b0e(21) clsact/ingress cil_from_container-lxc8471e19d2b0e id 3373

flow_dissector:

netfilter:

