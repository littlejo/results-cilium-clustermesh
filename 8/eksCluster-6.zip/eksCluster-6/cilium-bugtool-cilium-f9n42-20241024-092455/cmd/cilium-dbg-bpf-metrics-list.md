REASON                      DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                   INGRESS     543       43322       677    bpf_overlay.c
Interface                   INGRESS     58721     194684304   1132   bpf_host.c
Policy denied               EGRESS      136       10064       1325   bpf_lxc.c
Policy denied               INGRESS     27        2070        2063   bpf_lxc.c
Policy denied by denylist   EGRESS      40        2960        1325   bpf_lxc.c
Policy denied by denylist   INGRESS     5         394         2063   bpf_lxc.c
Success                     EGRESS      549       43778       53     encap.h
Success                     EGRESS      708       170259      86     l3.h
Success                     EGRESS      906       64167       1694   bpf_host.c
Success                     EGRESS      9994      1914221     1308   bpf_lxc.c
Success                     INGRESS     12005     1724776     86     l3.h
Success                     INGRESS     12867     1902522     235    trace.h
Unsupported L3 protocol     EGRESS      68        5144        1492   bpf_lxc.c
