filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdca7cc2c0dcb direct-action not_in_hw id 524 tag e27e0a6eac48a6e0 jited 
