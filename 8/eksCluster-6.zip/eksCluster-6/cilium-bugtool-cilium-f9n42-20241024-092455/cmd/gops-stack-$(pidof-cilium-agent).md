goroutine 165 [running]:
runtime/pprof.writeGoroutineStacks({0xffff694b1838, 0x400190c0d8})
	/usr/local/go/src/runtime/pprof/pprof.go:743 +0x6c
runtime/pprof.writeGoroutine({0xffff694b1838?, 0x400190c0d8?}, 0x10?)
	/usr/local/go/src/runtime/pprof/pprof.go:732 +0x2c
runtime/pprof.(*Profile).WriteTo(0x61dd090?, {0xffff694b1838?, 0x400190c0d8?}, 0xd?)
	/usr/local/go/src/runtime/pprof/pprof.go:369 +0x148
github.com/google/gops/agent.handle({0xffff694b1810, 0x400190c0d8}, {0x400144a000?, 0x1?, 0x1?})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:200 +0x23a0
github.com/google/gops/agent.listen({0x3e0bbf0, 0x4001caf4a0})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:144 +0x188
created by github.com/google/gops/agent.Listen in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:122 +0x320

goroutine 1 [select, 10 minutes]:
github.com/cilium/hive.(*Hive).waitForSignalOrShutdown(0x40001345a0, 0x40011e2cf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:251 +0x104
github.com/cilium/hive.(*Hive).Run(0x40001345a0, 0x40011e2cf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/hive.go:235 +0xe8
github.com/cilium/cilium/daemon/cmd.NewAgentCmd.func1(0x40003aa008, {0x377b213?, 0x4?, 0x377b083?})
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:40 +0x170
github.com/spf13/cobra.(*Command).execute(0x40003aa008, {0x400006e050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:989 +0x828
github.com/spf13/cobra.(*Command).ExecuteC(0x40003aa008)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1117 +0x344
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:1041
github.com/cilium/cilium/daemon/cmd.Execute(0x40001345a0?)
	/go/src/github.com/cilium/cilium/daemon/cmd/root.go:80 +0x1c
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:14 +0x64

goroutine 46 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400141c490, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400141c480)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy/k8s.(*serviceQueue).dequeue(0x40023dcde0, {0x3e23828, 0x40008293b0})
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:361 +0xfc
github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:398 +0x10c
created by github.com/cilium/cilium/pkg/policy/k8s.serviceNotificationsQueue in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/service.go:387 +0x15c

goroutine 38 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40008a5920)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 47 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x138
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 41 [select, 10 minutes]:
io.(*pipe).read(0x4000195560, {0x4001044000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001044000?, 0x4000b2de78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b2df18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x40007385b0, 0x4000195560, 0x40011e2c70)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 42 [select, 10 minutes]:
io.(*pipe).read(0x40001955c0, {0x4001806000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x28?, {0x4001806000?, 0x4000095678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b2ff18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x40007385b0, 0x40001955c0, 0x40011e2c90)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 43 [select, 10 minutes]:
io.(*pipe).read(0x4000195620, {0x4001828000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001828000?, 0x4000095e78?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b30f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x40007385b0, 0x4000195620, 0x40011e2cb0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 44 [select, 10 minutes]:
io.(*pipe).read(0x4000195680, {0x4001a44000, 0x10000, 0x1fd48?})
	/usr/local/go/src/io/pipe.go:57 +0x84
io.(*PipeReader).Read(0x6811ec0?, {0x4001a44000?, 0x4000096678?, 0x206bc?})
	/usr/local/go/src/io/pipe.go:134 +0x24
bufio.(*Scanner).Scan(0x4000b31f18)
	/usr/local/go/src/bufio/scan.go:219 +0x7d0
github.com/sirupsen/logrus.(*Entry).writerScanner(0x40007385b0, 0x4000195680, 0x40011e2cd0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:86 +0xec
created by github.com/sirupsen/logrus.(*Entry).WriterLevel in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:57 +0x34c

goroutine 45 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x5c
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0x8c

goroutine 153 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000dcb900)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 155 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000dcbcc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 156 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch.func1()
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:147 +0x74
created by github.com/cilium/cilium/pkg/identity/cache.(*identityWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/identity/cache/cache.go:141 +0x70

goroutine 157 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000dcbe00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1505 [select, 6 minutes]:
github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable.func1()
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:189 +0x3cc
created by github.com/cilium/cilium/pkg/maps/ctmap/gc.(*GC).Enable in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/maps/ctmap/gc/gc.go:104 +0xa8

goroutine 1508 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4000763950})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400043f900, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x40011ae3d0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1619 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400081e2d0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef2000, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001cbc6b0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1613
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1622 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef2280, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400081e460, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1613
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1483 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000f96000, {{{0x37b1743, 0x12}}, {0x0, 0x0}, 0x400094c6c0, 0x0, 0x400094c6d0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 157
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1797 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4001b0c5f0, {0x4002882670, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4001b0c5f0, {0x4002882670?, 0x400346b200?, 0x4002ac9510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4002882510, {0x4002882670?, 0x4002ac9598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4002882510}, {0x4002882670, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4000b1c900, {0x4002882670, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4002882660, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4002882660, 0x4000b1c900, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002ac97c8?, {0xffff69693090, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400396f180}, 0x40017b7c00?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x4000ce12c0, {0x35bf9e0, 0x400396f180})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/listener/v3.(*listenerDiscoveryServiceStreamListenersServer).Recv(0x4000f27ac0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:378 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x40025986c0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 1796
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 3675 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003458f00, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000d55420, 0x1, 0x4000d55430, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1631 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000dcab40)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1598
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1609 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x40011a2a50, 0x2e)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40011a2a40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001f56de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x40006c24b0}, 0x40025a37a0, {0x3e3b258, 0x40025b4408})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1367
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 166 [select, 8 minutes]:
github.com/cilium/statedb.graveyardWorker(0x400163e8c0, {0x3e23828, 0x40009e5a90}, 0x3b9aca00?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/graveyard.go:24 +0x12c
created by github.com/cilium/statedb.(*DB).Start in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/db.go:201 +0x14c

goroutine 169 [select]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e54fc0, {0x3e237f0, 0x4000b4a9c0}, {0x3e2b960, 0x4001a05800})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x294
github.com/cilium/hive/job.(*jobOneShot).start(0x40019862a0, {0x3e237f0, 0x4000b4a9c0}, 0x0?, {0x3e2b960, 0x4001f89ec0}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 182 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400073ba40, {{{0x379a274, 0xd}}, {0x0, 0x0}, 0x40018a4280, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 180 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f2db8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4000734300?, 0x4002d8a000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4000734300, {0x4002d8a000, 0xa000, 0xa000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4000734300, {0x4002d8a000?, 0x40018a4180?, 0x2?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400190c000, {0x4002d8a000?, 0x40027d3868?, 0x1fd48?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4003e242e8, {0x4002d8a000?, 0x0?, 0x4003e242e8?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40023e22b0, {0x3dd1940, 0x4003e242e8})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40023e2008, {0xffff69627b00, 0x40019e4060}, 0x40027d39d0?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40023e2008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40023e2008, {0x4001bb7000, 0x1000, 0x40023ac000?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4001a05500, {0x40023242e0, 0x9, 0x68?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4001a05500}, {0x40023242e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x40023242e0, 0x9, 0x27d3da8?}, {0x3dcc0a0?, 0x4001a05500?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x40023242a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
golang.org/x/net/http2.(*clientConnReadLoop).run(0x40027d3f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2358 +0xd0
golang.org/x/net/http2.(*ClientConn).readLoop(0x4000c08300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2254 +0x80
created by golang.org/x/net/http2.(*Transport).newClientConn in goroutine 179
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:869 +0xae0

goroutine 257 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.linkSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2419 +0x2c
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2418 +0x100

goroutine 1728 [select]:
github.com/servak/go-fastping.(*Pinger).run(0x400296d440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:439 +0x494
created by github.com/servak/go-fastping.(*Pinger).RunLoop in goroutine 1684
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:362 +0x1b0

goroutine 251 [chan receive, 4 minutes]:
github.com/cilium/cilium/daemon/cmd.(*localNodeSynchronizer).SyncLocalNode(0x40017e8b60, {0x3e23828?, 0x4000920370?}, 0x40010e0c40)
	/go/src/github.com/cilium/cilium/daemon/cmd/local_node_sync.go:76 +0xa4
github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1.1()
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:134 +0x3c
created by github.com/cilium/cilium/pkg/node.NewLocalNodeStore.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/node/local_node_store.go:133 +0x304

goroutine 644 [select]:
github.com/cilium/cilium/daemon/cmd.(*syncHostIPs).loop(0x4001d44d20, {0x3e237f0, 0x4001081f20}, {0x3e2b960, 0x4001e98180})
	/go/src/github.com/cilium/cilium/daemon/cmd/hostips-sync.go:109 +0x3c4
github.com/cilium/hive/job.(*jobOneShot).start(0x4001d44d80, {0x3e237f0, 0x4001081f20}, 0x4001c5a780?, {0x3e2b960, 0x4001f89c20}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 254 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x13, 0x400219fdb0, 0x10000, 0x0, 0x40040f8070, 0x400219fd64)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x50?, {0x400219fdb0?, 0x0?, 0x1400000050?}, 0x0?, 0x4003f250f0?, 0x40?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x13, {0x400219fdb0, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x4003f250f0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.addrSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:368 +0x70
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:365 +0x30c

goroutine 505 [select, 10 minutes]:
reflect.rselect({0x4001bc9e60, 0x9, 0xffff69790588?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4001295a00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4000f1e840, {0x3e237f0, 0x4000e597a0}, 0x40007695e0, {0xffff696930b8, 0x4001a90ac0}, 0x400217f620, {0x3852034?, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4000f1e840, {0x3e237f0, 0x4000e597a0}, {0xffff696930b8, 0x4001a90ac0}, {0x3852034, 0x33})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamClusters(0x4000f1e840, {0x3e3e6a0, 0x4001a90ac0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:106 +0x78
github.com/cilium/proxy/go/envoy/service/cluster/v3._ClusterDiscoveryService_StreamClusters_Handler({0x365dfc0?, 0x4000f1e840}, {0x3e32818, 0x40027b0870})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:332 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40017ee200, {0x3e237f0, 0x4000e596b0}, {0x3e42860, 0x4001779500}, 0x4001ca9d40, 0x4000f1ea50, 0x6238200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40017ee200, {0x3e42860, 0x4001779500}, 0x4001ca9d40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 504
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 502 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x400081fa90, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000769730)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.NewServerTransport.func2()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:334 +0xbc
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:332 +0x13d0

goroutine 467 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71360)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 543 [select, 10 minutes]:
github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:108 +0xb0
created by github.com/cilium/cilium/pkg/auth.registerSignalAuthenticationJob.FromChannel[...].func2 in goroutine 640
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:105 +0xc0

goroutine 472 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 458
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 642 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001d44c00, {0x3e237f0, 0x40010819b0}, 0x400194f6e0?, {0x3e2b960, 0x4001d44900}, {{{0x4000d51d00, 0x1, 0x1}}, 0x4000d905a0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 3803 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002893208)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3763
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 504 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff699f2ad0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40012d8100?, 0x4002ab8000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40012d8100, {0x4002ab8000, 0x8000, 0x8000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40012d8100, {0x4002ab8000?, 0x400176b180?, 0x800010601?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40015b7248, {0x4002ab8000?, 0x0?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
bufio.(*Reader).Read(0x4001884d20, {0x4002390580, 0x9, 0x4000e59200?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4001884d20}, {0x4002390580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x4002390580, 0x9, 0x40040f3f50?}, {0x3dcc0a0?, 0x4001884d20?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x4002390540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Server).HandleStreams(0x4001779500, {0x3e237f0, 0x4000e59410}, 0x4000e59440)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:644 +0x11c
google.golang.org/grpc.(*Server).serveStreams(0x40017ee200, {0x3e23698?, 0x680cae0?}, {0x3e42860, 0x4001779500}, {0x3e3a840?, 0x40015b7248?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1023 +0x300
google.golang.org/grpc.(*Server).handleRawConn.func1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:959 +0x5c
created by google.golang.org/grpc.(*Server).handleRawConn in goroutine 501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:958 +0x1d4

goroutine 1514 [sleep]:
time.Sleep(0x12a05f200)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer(0x4002395740, 0x3e71d20?)
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:126 +0x4ec
created by github.com/cilium/cilium/cilium-health/launch.Launch in goroutine 1364
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:68 +0x210

goroutine 236 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 251
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 658 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).k8sServiceHandler(0x40005143c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:190 +0xd4
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).RunK8sServiceHandler in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:203 +0x5c

goroutine 255 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.routeSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1642 +0x2c
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1641 +0x108

goroutine 234 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x40023ed320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 251
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 252 [select]:
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).processUpdates(0x4001a3e160, 0x4000ae51a0, 0x4000ae5260, 0x4000ae52c0)
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:356 +0x1d0
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).subscribeAndProcess(0x4001a3e160, {0x3e23828?, 0x4000517d60?})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:248 +0x3d8
github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).run(0x4001a3e160, {0x3e23828, 0x4000517d60})
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:183 +0x70
created by github.com/cilium/cilium/pkg/datapath/linux.(*devicesController).Start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/datapath/linux/devices_controller.go:163 +0x120

goroutine 706 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 682
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 253 [chan receive, 10 minutes]:
github.com/vishvananda/netlink.addrSubscribeAt.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:352 +0x2c
created by github.com/vishvananda/netlink.addrSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/addr_linux.go:351 +0x108

goroutine 191 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x400217c398, 0xa)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217c388)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217c370, 0x4001666d00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000dca6e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40029dfec0, {0x3ddab40, 0x40009f6270}, 0x1, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40029dfec0, 0x3b9aca00, 0x0, 0x1, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000dca6e0, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018a4480, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 184
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 192 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 184
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 647 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x40012e40c0?, 0x7a2bb0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001b89800?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 256 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x14, 0x40021bf940, 0x10000, 0x0, 0x40040f8000, 0x40021bf8f4)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x74?, {0x40021bf940?, 0x0?, 0x600001800000074?}, 0x0?, 0x40040d8f90?, 0x64?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x14, {0x40021bf940, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x15?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.routeSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1658 +0x74
created by github.com/vishvananda/netlink.routeSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/route_linux.go:1655 +0x30c

goroutine 211 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 191
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 11738 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004a66300, 0x4001bcc480, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004a66300, 0x8a6d4?, 0x40011a94c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 213 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 191
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 214 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40051ffb80}, {0xffff6968f080, 0x400217c370}, {0x3e672a8, 0x371cf40}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40023248c0, {0x0?, 0x0?}, 0x40000c7da0, 0x4001f89da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40023248c0, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40027cff40, {0x3ddab60, 0x4000762730}, 0x1, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40023248c0, 0x40000c7da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 191
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 217 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40023248c0, 0x40000c7da0, 0x4000ae4180, 0x4001f89da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 233 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x40023ed200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 251
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 238 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 262
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 503 [select, 10 minutes]:
google.golang.org/grpc/internal/transport.(*http2Server).keepalive(0x4001779500)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:1168 +0x174
created by google.golang.org/grpc/internal/transport.NewServerTransport in goroutine 501
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_server.go:355 +0x1410

goroutine 456 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff699f28e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1e?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000958b00)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000958b00)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40027ddc48?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4000e91ec0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x40017ee200, {0x3e0bc20, 0x4000e91ec0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:55 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*xdsServer).startXDSGRPCServer in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:53 +0x19c

goroutine 633 [select, 6 minutes]:
github.com/cilium/cilium/pkg/cgroups/manager.(*cgroupManager).processPodEvents(0x4001b34180)
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/manager.go:218 +0x74
created by github.com/cilium/cilium/pkg/cgroups/manager.newCGroupManager.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/cgroups/manager/cell.go:48 +0x60

goroutine 641 [chan receive, 10 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c1e0, {0x3e237f0, 0x40010818f0}, 0x4001c5ab98, {0x3e2b960?, 0x4001d44900}, {{{0x4000d51d00, 0x1, 0x1}}, 0x4000d905a0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 506 [select, 10 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x400081fe00, {0x4000e59750, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400081fe00, {0x4000e59750?, 0x40016d9410?, 0x4002ce9510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4000e59590, {0x4000e59750?, 0x4002ce9598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4000e59590}, {0x4000e59750, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001ca9d40, {0x4000e59750, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4000e59740, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4000e59740, 0x4001ca9d40, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002ce97c8?, {0xffff69693090, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x40024095e0}, 0x40010e1c00?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40027b0870, {0x35bf9e0, 0x40024095e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/envoy/service/cluster/v3.(*clusterDiscoveryServiceStreamClustersServer).Recv(0x4001a90ac0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/cluster/v3/cds.pb.go:351 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x0?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 505
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 1605 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x40018a0f90, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018a0f80)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40018a0f40, {0x3e23828, 0x40006c22d0}, {0x4001cdb580, 0x33}, 0x1, {0x40023375a5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 505
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 1635 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40023a2a00, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40006a51e0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1622
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11886 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 715 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 708
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 651 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002325a40, 0x4001e919e0, 0x4001f06f00, 0x4001d29ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 678
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 235 [sync.Cond.Wait, 4 minutes]:
sync.runtime_notifyListWait(0x4001242410, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001242400)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x40023ed200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4afc0, {0x3e23828, 0x400039f590}, 0x4000d8be60, {0x3e3b518, 0x40019e4888})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 251
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 643 [syscall, 10 minutes]:
syscall.Syscall6(0x16, 0x19, 0x40023b3b40, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x0?, {0x40023b3b40?, 0x40000ba120?, 0x4002cf59e0?}, 0x4002cf5a58?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x40018b3100, {0x40023b3b40, 0x2, 0x2}, {0x4001b33020?, 0x32d640?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4001cff140, 0x4002cf5bd8)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(0x4000426070?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336 +0x38
github.com/cilium/cilium/pkg/signal.(*signalManager).start.func1()
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:266 +0x78
created by github.com/cilium/cilium/pkg/signal.(*signalManager).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/signal/signal.go:263 +0x128

goroutine 258 [syscall, 6 minutes]:
syscall.Syscall6(0xcf, 0x15, 0x40021dfe90, 0x10000, 0x0, 0x40023b5d50, 0x40021dfe44)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.recvfrom(0x59c?, {0x40021dfe90?, 0x0?, 0x100000059c?}, 0x0?, 0x4003739810?, 0x58c?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:472 +0x64
golang.org/x/sys/unix.Recvfrom(0x15, {0x40021dfe90, 0x10000, 0x10000}, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/syscall_unix.go:332 +0x64
github.com/vishvananda/netlink/nl.(*NetlinkSocket).Receive(0x40021efee8?)
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/nl/nl_linux.go:786 +0x64
github.com/vishvananda/netlink.linkSubscribeAt.func2()
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2435 +0x70
created by github.com/vishvananda/netlink.linkSubscribeAt in goroutine 252
	/go/src/github.com/cilium/cilium/vendor/github.com/vishvananda/netlink/link_linux.go:2432 +0x304

goroutine 259 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff699f2cc0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4000e98ea0?, 0x40021ffe2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4000e98ea0, {0x40021ffe2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x400190c330, {0x40021ffe2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4000eb9080)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 260 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000932640, {{{0x379eee1, 0xe}}, {0x0, 0x0}, 0x40019e7470, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 261 [select, 10 minutes]:
github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).watchForDirectoryChanges(0x4001a79930)
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:254 +0xc0
created by github.com/cilium/cilium/daemon/cmd/cni.(*cniConfigManager).Start in goroutine 1
	/go/src/github.com/cilium/cilium/daemon/cmd/cni/config.go:228 +0x318

goroutine 262 [select]:
github.com/cilium/cilium/pkg/datapath/iptables.reconciliationLoop({0x3e237f0, 0x4000e0aa80}, {0x3e62c10, 0x400163f490}, {0x3e2b960, 0x40023ed620}, 0x1, 0x4000134910, 0x4001e17d50, 0x4001e17d40, ...)
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/reconciler.go:163 +0x5c4
github.com/cilium/cilium/pkg/datapath/iptables.newIptablesManager.func2({0x3e237f0, 0x4000e0aa80}, {0x3e2b960, 0x40023ed620})
	/go/src/github.com/cilium/cilium/pkg/datapath/iptables/iptables.go:345 +0xdc
github.com/cilium/hive/job.(*jobOneShot).start(0x4001a82300, {0x3e237f0, 0x4000e0aa80}, 0x3e038f8?, {0x3e2b960, 0x4001a822a0}, {{{0x40004763e0, 0x1, 0x1}}, 0x4000c662d0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 640 [chan receive, 10 minutes]:
github.com/cilium/hive/job.(*jobObserver[...]).start(0x3e0c220, {0x3e237f0, 0x4001081890}, 0x4001c5ab38, {0x3e2b960?, 0x4001d44900}, {{{0x4000d51d00, 0x1, 0x1}}, 0x4000d905a0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/observer.go:121 +0x440
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 471 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 458
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1515 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000966280, {{{0x3799d7a, 0xd}}, {0x0, 0x0}, 0x40023ce390, 0x0, 0x40019e42b8, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1412 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 11542 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004f96300, 0x4004f21200, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004f96300, 0x0?, 0x4000b6d440?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 930 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1437 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1427
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 457 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400165ca00)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 458 [select, 6 minutes]:
github.com/cilium/cilium/pkg/datapath/tables.(*nodeAddressController).run(0x4001ab7d40, {0x3e237f0, 0x4000f1fa40}, {0x3e2b960, 0x40017f9680})
	/go/src/github.com/cilium/cilium/pkg/datapath/tables/node_address.go:316 +0x2d8
github.com/cilium/hive/job.(*jobOneShot).start(0x4001a83260, {0x3e237f0, 0x4000f1fa40}, 0x400119bec0?, {0x3e2b960, 0x4001a82f60}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 637 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).loop(0x4000fb3a80)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:158 +0xa4
created by github.com/cilium/cilium/pkg/clustermesh/common.(*configDirectoryWatcher).watch in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/config.go:152 +0x20c

goroutine 454 [IO wait, 2 minutes]:
internal/poll.runtime_pollWait(0xffff699f26f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1c?, 0x967e0?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000958900)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000958900)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40027dfd98?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).AcceptUnix(0x4000e91ce0)
	/usr/local/go/src/net/unixsock.go:247 +0x2c
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:59 +0x90
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:54 +0x124

goroutine 452 [select]:
golang.org/x/time/rate.(*Limiter).wait(0x4005523ae0, {0x3e23828, 0x40006c3130}, 0x1, {0x400271d918?, 0x1e301d0?, 0x6279580?}, 0x39bb3e8)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:285 +0x320
golang.org/x/time/rate.(*Limiter).WaitN(0x4005523ae0, {0x3e23828, 0x40006c3130}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:248 +0x54
golang.org/x/time/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/time/rate/rate.go:233
github.com/cilium/cilium/pkg/node/manager.(*manager).singleBackgroundLoop(0x4001071700, {0x3e23828, 0x40006c3130}, 0x1eb1e32e50)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:429 +0x114
github.com/cilium/cilium/pkg/node/manager.(*manager).backgroundSync(0x4001071700, {0x3e23828, 0x40006c3130})
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:398 +0x1f8
github.com/cilium/workerpool.(*WorkerPool).run.func1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:181 +0x78
created by github.com/cilium/workerpool.(*WorkerPool).run in goroutine 450
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:178 +0x50

goroutine 455 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func2()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:77 +0x38
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:76 +0x184

goroutine 453 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff699f2500, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x1b?, 0x1fd48?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000958700)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000958700)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40022f6dc8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4000e91b60)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2(0x4001a93a20, {0x3e23828, 0x4001b0c280}, 0x800)
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:83 +0xbc
created by github.com/cilium/cilium/pkg/monitor/agent.ServeMonitorAPI in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:69 +0x144

goroutine 451 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x400165c780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 450 [chan receive, 10 minutes]:
github.com/cilium/workerpool.(*WorkerPool).run(0x40006c30e0, {0x3e23828, 0x40006c3130})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:173 +0x60
created by github.com/cilium/workerpool.NewWithContext in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/workerpool/workerpool.go:68 +0x134

goroutine 638 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e726e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 449 [select, 10 minutes]:
github.com/cilium/statedb/reconciler.(*reconciler[...]).loop(0x3e55100, {0x3e237f0, 0x4000e908a0}, {0x3e2b960, 0x40017bd320})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/statedb/reconciler/reconciler.go:140 +0x298
github.com/cilium/hive/job.(*jobOneShot).start(0x4001a82b40, {0x3e237f0, 0x4000e908a0}, 0x400172ec00?, {0x3e2b960, 0x4001a828a0}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 445 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e70e80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 950 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 946
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 444 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0xc4ff0173706f72?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x657478450c0100c6?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 443 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x1?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x3e23828?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3808 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003828e60, {0x400386f5a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003828e60, {0x400386f5a0?, 0x40037fe330?, 0x4003711930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400386f560, {0x400386f5a0?, 0x40037119b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400386f560}, {0x400386f5a0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003793d40, {0x400386f5a0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400386f590, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400386f590, 0x4003793d40, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003793d40?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f2cd00}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003592ea0, {0x3612420, 0x4000f2cd00}, 0x4000f2df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003711d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003793b00, 0x4003711e10, 0x4003711e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003793b00, {0x3612420?, 0x4000f2cd00?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003814bd0, {0x3612420, 0x4000f2cd00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x400060ed60)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400165d5e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3732
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 470 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2.func1()
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:78 +0x38
created by github.com/cilium/cilium/pkg/monitor/agent.(*server).connectionHandler1_2 in goroutine 453
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/server.go:77 +0x88

goroutine 656 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f564e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 682
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 442 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000f96c80, {{{0x3791109, 0xb}}, {0x3e2b960, 0x40017bcb40}, 0x4001a3bbd0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3580 [select, 8 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002db1400})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002e09400, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x400033d3c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 636 [IO wait, 8 minutes]:
internal/poll.runtime_pollWait(0xffff699f2408, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001d28b40?, 0x4002cd7e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001d28b40, {0x4002cd7e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x40015b7b20, {0x4002cd7e2b?, 0x3dbb988?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x4000fb3a40)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 979 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x120
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 978
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 655 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001f56360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 682
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 705 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4001794090, 0xb)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001794080)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001f56360)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x4002184cd0}, 0x4001f073e0, {0x3e3b570, 0x400036b488})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 682
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 931 [select, 10 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:281 +0x14c
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.Debounce[...].func4 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/operators.go:271 +0x15c

goroutine 675 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 672
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 662 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e89680, {{{0x37ce973, 0x19}}, {0x0, 0x0}, 0x4001930cf0, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 663 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff699f29d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x2a?, 0x8746c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000959c80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000959c80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001887440)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001887440)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
github.com/cilium/dns.(*Server).serveTCP(0x4000db9700, {0x3e0bbf0, 0x4001887440})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:454 +0xe4
github.com/cilium/dns.(*Server).ActivateAndServe(0x4000db9700)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:372 +0x208
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4000db9700)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 664 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f27e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4000959d00?, 0x4001f12000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsgInet4(0x4000959d00, {0x4001f12000, 0x200, 0x200}, {0x40023a7020, 0x2c, 0x2c}, 0x0, 0x4004603818)
	/usr/local/go/src/internal/poll/fd_unix.go:328 +0x254
net.(*netFD).readMsgInet4(0x4000959d00, {0x4001f12000?, 0x4004603808?, 0x71368?}, {0x40023a7020?, 0x71374?, 0x40046037d8?}, 0x1ea1c?, 0x40046037f8?)
	/usr/local/go/src/net/fd_posix.go:84 +0x2c
net.(*UDPConn).readMsg(0x31926c0?, {0x4001f12000?, 0x253?, 0x2?}, {0x40023a7020?, 0x10?, 0x4004603918?})
	/usr/local/go/src/net/udpsock_posix.go:101 +0x124
net.(*UDPConn).ReadMsgUDPAddrPort(0x400190d360, {0x4001f12000?, 0xffff699f27e8?, 0x77359058?}, {0x40023a7020?, 0x2a69c84?, 0x40012684b0?})
	/usr/local/go/src/net/udpsock.go:203 +0x34
net.(*UDPConn).ReadMsgUDP(0x40012684b0?, {0x4001f12000?, 0x0?, 0x4000d62130?}, {0x40023a7020?, 0x2a098e0?, 0x10?})
	/usr/local/go/src/net/udpsock.go:191 +0x24
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0x400190d360?, 0x400190d360)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:158 +0x5c
github.com/cilium/dns.(*Server).readUDP(0x4000db9800, 0x400190d360, 0x77359400)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:688 +0x140
github.com/cilium/dns.defaultReader.ReadUDP({0x61df4d0?}, 0x318dd00?, 0x0?)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:174 +0x1c
github.com/cilium/dns.(*Server).serveUDP(0x4000db9800, {0x3e35e70, 0x400190d360})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:510 +0x20c
github.com/cilium/dns.(*Server).ActivateAndServe(0x4000db9800)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/dns/server.go:367 +0x178
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0x4000db9800)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:712 +0x1cc
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:704 +0x760

goroutine 667 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001e99380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 668 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001e994a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 669 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x400240a190}, 0x4001e916e0, {0x3e3b4c0, 0x4001bb8a80})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:677 +0x4dc
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 672 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x400217d998, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217d988)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217d970, 0x400150e900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400165d900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400278aec0, {0x3ddab40, 0x40012693e0}, 0x1, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400278aec0, 0x3b9aca00, 0x0, 0x1, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400165d900, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001887700, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 232
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 670 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 5850 [select, 4 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400465af00, 0x4000ac9c20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400465af00, 0x3e237f0?, 0x40017f6930?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 678
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 648 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001be5cc0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 939 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery.func3()
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:194 +0xc0
created by github.com/cilium/cilium/pkg/nodediscovery.(*NodeDiscovery).StartDiscovery in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/nodediscovery/nodediscovery.go:192 +0x26c

goroutine 682 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).serviceEventLoop(0x40005143c0, 0x4000d20f40, 0x40011d61b0)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:111 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sServiceWatcher).servicesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/service.go:95 +0x160

goroutine 684 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001e99bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 685 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001e99d40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 3811 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4003622320)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3760
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 687 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 688 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:86 +0x9c
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sNamespaceWatcher).namespacesInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/namespace.go:84 +0x1d4

goroutine 686 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400150f650, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400150f640)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001e99bc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ae40, {0x3e23828, 0x400240a5f0}, 0x4001e91da0, {0x3e3b410, 0x400036b428})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1373 [select, 10 minutes]:
github.com/cilium/cilium/pkg/service.serviceReconciler.reconcileLoop({{{}}, {0x3e23a20, 0x4001947940}, {0x3dd0840, 0x4000f2e140}, {0x3e2b960, 0x4001c67320}, 0x400163e8c0, {0x3e5d2a0, 0x400163fa40}, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/service/reconciler.go:104 +0x688
github.com/cilium/hive/job.(*jobOneShot).start(0x4001c673e0, {0x3e237f0, 0x4001ff1230}, 0x4001f84660?, {0x3e2b960, 0x4001c67320}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 691 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001e99e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1649 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x40008785f0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef3680, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001d08790, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1598
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 692 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f84000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 694 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 693 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400150fc10, 0x24)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400150fc00)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001e99e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4abc0, {0x3e23828, 0x400240a730}, 0x4001efa000, {0x3e3b258, 0x4001bb91d0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 696 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit(0x4001b26a20, {0x3e23828, 0x400240a3c0}, 0x4000d20f10)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:146 +0x2bc
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).enableK8sWatchers in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:344 +0x2ec

goroutine 697 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit(0x40023f6120, {0x3e23828, 0x400240a3c0}, 0x4000d20f10)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:134 +0x220
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).initCiliumEndpointOrSlices in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:82 +0x118

goroutine 695 [select, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:88 +0xac
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sEndpointsWatcher).endpointsInit in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/endpoints.go:86 +0x1fc

goroutine 699 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:115 +0x100
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumEndpointsWatcher).ciliumEndpointsInit in goroutine 697
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_endpoint.go:110 +0x1d8

goroutine 700 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4001efa1e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 697
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1415 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 702 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1.1()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:212 +0xe8
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sPodWatcher).podsInit.func1 in goroutine 689
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/pod.go:210 +0xcc

goroutine 722 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400217ddb8, 0x11)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217dda8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217dd90, 0x40015901c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400165d9a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002cebec0, {0x3ddab40, 0x40011d6fc0}, 0x1, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002b40ec0, 0x3b9aca00, 0x0, 0x1, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400165d9a0, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001887d60, 0x4001efad80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 3823 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40038282d0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40004f6d90)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1375 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e711c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 727 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:101 +0x130
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 696
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:95 +0x200

goroutine 1403 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000556000, {{{0x378dd05, 0xa}}, {0x0, 0x0}, 0x4000f3c1b0, 0x0, 0x39b9348, 0xdf8475800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 723 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 460
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1374 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001c674a0, {0x3e237f0, 0x4001ff12f0}, 0x400316f860?, {0x3e2b960, 0x4001c67440}, {{{0x4001932320, 0x1, 0x1}}, 0x40008d6d20, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 673 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 232
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1465 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1428 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 463
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 677 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 678 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400533aac0}, {0xffff6968f080, 0x400217d970}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002325a40, {0x0?, 0x0?}, 0x4001e919e0, 0x4001d29ec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002325a40, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002cf1f40, {0x3ddab60, 0x400240a320}, 0x1, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002325a40, 0x4001e919e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 672
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 708 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400101e2e8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101e2d8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101e2c0, 0x4001794200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001f0a3c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bbdec0, {0x3ddab40, 0x4001107b90}, 0x1, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002bbdec0, 0x3b9aca00, 0x0, 0x1, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001f0a3c0, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018b3f40, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 709 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 462
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 980 [select]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync.func1(0x4002e2e700)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:903 +0x1d4
created by github.com/cilium/cilium/pkg/allocator.(*Allocator).startLocalKeySync in goroutine 947
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:895 +0x68

goroutine 711 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400101e398, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101e388)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101e370, 0x4001794240)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001f0a460)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001fe3ec0, {0x3ddab40, 0x4001107f20}, 0x1, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4001fe3ec0, 0x3b9aca00, 0x0, 0x1, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001f0a460, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018b3f60, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 712 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 459
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1411 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x40012fed50, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40012fed40)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000e991a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ac40, {0x3e23828, 0x400347dcc0}, 0x40026f2960, {0x3e3b2b0, 0x40025b45e8})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 728 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit.func3()
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:140 +0x240
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sCiliumNodeWatcher).ciliumNodeInit in goroutine 696
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/cilium_node.go:127 +0x274

goroutine 729 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/kvstore.Connected.func1(0x4001efa900)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:96 +0x5c
created by github.com/cilium/cilium/pkg/kvstore.Connected in goroutine 696
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:94 +0x78

goroutine 1729 [select, 1 minutes]:
github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:400 +0x80
created by github.com/cilium/cilium/pkg/health/server.(*prober).RunLoop in goroutine 1684
	/go/src/github.com/cilium/cilium/pkg/health/server/prober.go:395 +0x68

goroutine 731 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f85380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 699
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 732 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4001590290, 0x12)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001590280)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001f85260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ab40, {0x3e23828, 0x400240ad70}, 0x4001efaa20, {0x3e3b200, 0x400036b7a0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 699
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 733 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 699
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 760 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 461
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 717 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 708
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 718 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004fc6000}, {0xffff6968f080, 0x400101e2c0}, {0x3e672a8, 0x371cba0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002390ee0, {0x0?, 0x0?}, 0x4001f079e0, 0x4001f7cea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002390ee0, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001c79f40, {0x3ddab60, 0x4002185090}, 0x1, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002390ee0, 0x4001f079e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 708
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 784 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002390ee0, 0x4001f079e0, 0x4001f72f00, 0x4001f7cea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 718
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 734 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001f855c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 702
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 735 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f85740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 702
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 736 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x4001591150, 0x63)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001591140)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001f855c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4aec0, {0x3e23828, 0x400240ae60}, 0x4001efac00, {0x3e3b468, 0x400036b6e0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 702
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 737 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 702
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 738 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 722
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 946 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400101ea78, 0x5)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101ea68)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101ea50, 0x40012bc2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001f0b860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002675e00, {0x3ddab40, 0x400164f560}, 0x1, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002a42e00, 0x3b9aca00, 0x0, 0x1, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001f0b860, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/informer.(*privateRunner).Run(0x40012cac80, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/informer/informer.go:46 +0xa8
github.com/cilium/cilium/pkg/k8s/identitybackend.(*crdBackend).ListAndWatch(0x400164ef00, {0x4001efb401?, 0x0?}, {0x3e148d0, 0x4002e2e7b8}, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/pkg/k8s/identitybackend/identity.go:407 +0x480
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 940
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 740 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 741 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004d35100}, {0xffff6968f080, 0x400217dd90}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x40023509a0, {0x0?, 0x0?}, 0x4001efad80, 0x4001f7d140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x40023509a0, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d39f40, {0x3ddab60, 0x400240af00}, 0x1, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x40023509a0, 0x4001efad80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 722
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 818 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x40023509a0, 0x4001efad80, 0x4001f732c0, 0x4001f7d140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 741
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1608 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f573e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1367
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 753 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 711
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 759 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400101e448, 0x31)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101e438)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101e420, 0x4001794740)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001f0a500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400231aec0, {0x3ddab40, 0x400122aa80}, 0x1, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400231aec0, 0x3b9aca00, 0x0, 0x1, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001f0a500, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018ce720, 0x4001f72840)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 461
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 755 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 711
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 756 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40055bb7c0}, {0xffff6968f080, 0x400101e370}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002391420, {0x0?, 0x0?}, 0x4001f07da0, 0x4001fbdec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002391420, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4001c7bf40, {0x3ddab60, 0x40021850e0}, 0x1, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002391420, 0x4001f07da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 711
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 12372 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400464ac48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400464ac38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400464ac30, {0x40013baa10, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001aaecc8?}, {0x40013baa10?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x400464ac00}, {0x40013baa10, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4004128b28, {0x40043f3000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003c595e0, 0x0, {0x3e02238, 0x4004d35140})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000b5eaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004d35100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 741
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 810 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002391420, 0x4001f07da0, 0x4001ffc000, 0x4001fbdec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 756
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1427 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x4001a3e658, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001a3e648)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001a3e630, 0x4000035780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4000de8b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002bc1ec0, {0x3ddab40, 0x400232f170}, 0x1, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002bc1ec0, 0x3b9aca00, 0x0, 0x1, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4000de8b40, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000f34f80, 0x40000c7500)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 463
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1484 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000f96140, {{{0x37e6ffb, 0x1e}}, {0x0, 0x0}, 0x40025b5620, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1504
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 11576 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 951 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004f74c40}, {0xffff6968f080, 0x400101ea50}, {0x3e672a8, 0x36f6aa0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001b9a460, {0x0?, 0x0?}, 0x4002e543c0, 0x4003185da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001b9a460, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d55f40, {0x3ddab60, 0x4002526870}, 0x1, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001b9a460, 0x4002e543c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 946
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 762 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001f57a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 727
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 763 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001f57b60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 727
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 764 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4001794790, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001794780)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001f57a40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4af40, {0x3e23828, 0x4002185220}, 0x4001f72420, {0x3e3b4c0, 0x4001bb9ad0})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 727
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 765 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 727
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1402 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x4001c67f20, {0x3e237f0, 0x4001ff1a40}, 0x400315fb60?, {0x3e2b960, 0x4001c67e60}, {{{0x4000f6f200, 0x1, 0x1}}, 0x4001ce07c0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 804 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 800
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 768 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400101e4f8, 0x8)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101e4e8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101e4d0, 0x4001794880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001f0a5a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002685ec0, {0x3ddab40, 0x400122aed0}, 0x1, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002d43ec0, 0x3b9aca00, 0x0, 0x1, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001f0a5a0, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40018ce7c0, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 447
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 769 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 447
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 955 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001b9a460, 0x4002e543c0, 0x4003183ce0, 0x4003185da0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 772 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 759
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1405 [select]:
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).cycle(0x400038f900, {0x3e237f0, 0x4001ff1d10}, {0x3e0e5f0, 0x400233e660}, 0x40015f94a0)
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:166 +0x204
github.com/cilium/cilium/pkg/datapath/l2responder.(*l2ResponderReconciler).run(0x400038f900, {0x3e237f0, 0x4001ff1d10}, {0x671a102d?, 0x4002679d68?})
	/go/src/github.com/cilium/cilium/pkg/datapath/l2responder/l2responder.go:106 +0x2d0
github.com/cilium/hive/job.(*jobOneShot).start(0x40018b0480, {0x3e237f0, 0x4001ff1d10}, 0x40031cdc80?, {0x3e2b960, 0x40018b0420}, {{{0x4001b82880, 0x1, 0x1}}, 0x4001d084e0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1452 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1420
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 774 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 759
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 775 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40054179c0}, {0xffff6968f080, 0x400101e420}, {0x3e672a8, 0x373c000}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002391a40, {0x0?, 0x0?}, 0x4001f72840, 0x40023266c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002391a40, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d57f40, {0x3ddab60, 0x40021854a0}, 0x1, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002391a40, 0x4001f72840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 759
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 815 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002391a40, 0x4001f72840, 0x4001ffc960, 0x40023266c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 775
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1359 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1356
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1512 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1364
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1367 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x4001d45020, {0x3e237f0, 0x4001ff0d50}, 0x4001a83620?, {0x3e2b960, 0x4001d44e40}, {{{0x4000df4920, 0x1, 0x1}}, 0x4000df9660, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1369 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f2310, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0xd?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4000734480)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4000734480)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x400329edb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x4001ff0e70)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x4000134b40, {0x3e0bc20, 0x4001ff0e70})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/server.(*Server).Start.func1({0x3e0bc20?, 0x4001ff0e70?})
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:467 +0x70
created by github.com/cilium/cilium/api/v1/server.(*Server).Start in goroutine 1
	/go/src/github.com/cilium/cilium/api/v1/server/server.go:465 +0x418

goroutine 1730 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629190, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x35?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029bba80)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029bba80)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x40027ecdb8?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40017f67b0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
net/http.(*Server).Serve(0x40027551d0, {0x3e0bc20, 0x40017f67b0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/api/v1/health/server.(*Server).Start.func1({0x3e0bc20?, 0x40017f67b0?})
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:357 +0x70
created by github.com/cilium/cilium/api/v1/health/server.(*Server).Start in goroutine 1684
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:355 +0x3f0

goroutine 1372 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40003bfe00, {{{0x37b8e08, 0x14}}, {0x3e2b960, 0x4000ebb9e0}, 0x400275dae0, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1376 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded(0x3e71020)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:354 +0xa8
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).start in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:334 +0xa4

goroutine 1394 [select, 1 minutes]:
github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources.func1()
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:68 +0x248
created by github.com/cilium/cilium/pkg/policy/k8s.(*policyWatcher).watchResources in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/policy/k8s/watcher.go:57 +0x7c

goroutine 1414 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400217d8e8, 0x18)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217d8d8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217d8c0, 0x40012fef40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001ad1720)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002695ec0, {0x3ddab40, 0x4002321e90}, 0x1, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002b19ec0, 0x3b9aca00, 0x0, 0x1, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001ad1720, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40010b94a0, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 1368
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1466 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4001040100}, {0xffff6968f080, 0x400101e0b0}, {0x3e672a8, 0x36f2b80}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001fd1180, {0x0?, 0x0?}, 0x40000c7c80, 0x4001884b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001fd1180, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400267ff40, {0x3ddab60, 0x4000829720}, 0x1, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001fd1180, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1441
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1679 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff69629668, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400287fa00?, 0x4001d15000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400287fa00, {0x4001d15000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400287fa00, {0x4001d15000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001a023c0, {0x4001d15000?, 0x72?, 0x4001f9ad88?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001f9ad80, {0x4001d15000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400319a840)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400319a840, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40029178c0, {0x3e237f0, 0x4002321740})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1369
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1663 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002f73b80, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003192f00}, 0x40019423a0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1509
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1507 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40024088c0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1506 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400043f7c0, {{{0x37a4a9e, 0xf}}, {0x0, 0x0}, 0x4002394960, 0x0, 0x39b9348, 0x6fc23ac00, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 2298 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x400150aa20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 2295
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1617 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4000dca5a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1613
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1621 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef2140, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40023c29c0}, 0x4000212070, 0x0, 0x4000d5c150, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1613
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1620 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1613
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 11331 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 800 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x4001bb4188, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001bb4178)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001bb4160, 0x400142a700)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x400165da40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d63ec0, {0x3ddab40, 0x40012a4510}, 0x1, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002d63ec0, 0x3b9aca00, 0x0, 0x1, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x400165da40, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4001a18780, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 801 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 446
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1410 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000e99320)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 11352 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 806 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 800
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 807 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005820100}, {0xffff6968f080, 0x4001bb4160}, {0x3e672a8, 0x36fe960}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002350ee0, {0x0?, 0x0?}, 0x4001efbaa0, 0x40023263c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002350ee0, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d35f40, {0x3ddab60, 0x400240bae0}, 0x1, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002350ee0, 0x4001efbaa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 800
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 813 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002350ee0, 0x4001efbaa0, 0x4001ffc540, 0x40023263c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 778 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 768
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 820 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40018d17c0, {{{0x37be248, 0x15}}, {0x0, 0x0}, 0x4000f72c70, 0x0, 0x39b9348, 0x0, 0xdf8475800, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 695
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 780 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 768
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 781 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x40014fa2c0}, {0xffff6968f080, 0x400101e4d0}, {0x3e672a8, 0x36f67e0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4002391ea0, {0x0?, 0x0?}, 0x4001f72b40, 0x4001f7de60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4002391ea0, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002d59f40, {0x3ddab60, 0x40021854f0}, 0x1, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4002391ea0, 0x4001f72b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 768
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 828 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4002391ea0, 0x4001f72b40, 0x4001f73b60, 0x4001f7de60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 10723 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004a66d80, 0x400554ac60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004a66d80, 0x8a6d4?, 0x4001c44680?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 756
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10358 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400340bc80, 0x4000ac9560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400340bc80, 0x8a6d4?, 0x400142be80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 718
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10383 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4002c513c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4002c513b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4002c513b0, {0x400173abc4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002d62cc8?}, {0x400173abc4?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x4002c51380}, {0x400173abc4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40023efba8, {0x4003b7f400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40040f7bd0, 0x0, {0x3e02238, 0x40014eea40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a92260)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40054179c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 775
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12371 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400464ac00, 0x4001c22900, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400464ac00, 0x8a6d4?, 0x4001c44a80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 741
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 7928 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400006ac00, 0x400234f320, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400006ac00, 0x3e237f0?, 0x4002321740?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10032 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x40037dd680, 0x40044117a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x40037dd680, 0x3e237f0?, 0x4000b5d5c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 10382 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4002c51380, 0x4001d49e60, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4002c51380, 0x8a6d4?, 0x4001c45ac0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 775
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1722 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69629760, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40029bb800?, 0x40029cf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40029bb800, {0x40029cf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40029bb800, {0x40029cf000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001a03348, {0x40029cf000?, 0x72?, 0x4001783448?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001783440, {0x40029cf000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x400315e240)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400315e240, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400296cbd0, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 1651 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef37c0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40023c3b00}, 0x4000218a80, 0x0, 0x40023eb110, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1598
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1650 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4002b79e28?, 0x0?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000d20fcc?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1598
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 7336 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400006aac8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400006aab8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400006aab0, {0x4004d5b904, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002eb0cc8?}, {0x4004d5b904?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x400006aa80}, {0x4004d5b904, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003cff6f8, {0x40000e4c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002956230, 0x0, {0x3e02238, 0x400471a9c0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40010b9620)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005b41780)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1448
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 7335 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400006aa80, 0x4000b1d440, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400006aa80, 0x8a6d4?, 0x40012ffb00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1448
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 8979 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400006b200, 0x400396ca20, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400006b200, 0x3e237f0?, 0x4002321740?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1460
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1455 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004ff5200}, {0xffff6968f080, 0x400217da20}, {0x3e672a8, 0x3703740}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001b9bdc0, {0x0?, 0x0?}, 0x4000d8b380, 0x40017f8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001b9bdc0, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002689f40, {0x3ddab60, 0x40009e4b40}, 0x1, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001b9bdc0, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1420
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 11616 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 1474 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001b9bdc0, 0x4000d8b380, 0x4001659080, 0x40017f8300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1451 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1406
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1454 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1420
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 10385 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40040841c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40040841b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40040841b0, {0x400188da0c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x400329acc8?}, {0x400188da0c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x4004084180}, {0x400188da0c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003d799b0, {0x4003b7f800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40042bc4b0, 0x0, {0x3e02238, 0x4000f8d340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a92b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004080a00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1438
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1448 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4005b41780}, {0xffff6968f080, 0x400217d8c0}, {0x3e672a8, 0x3723120}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001b9b960, {0x0?, 0x0?}, 0x40026f3b00, 0x40018845a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001b9b960, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400266ff40, {0x3ddab60, 0x4000663ef0}, 0x1, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001b9b960, 0x40026f3b00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 11471 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004ccb200, 0x4004cdf560, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004ccb200, 0x8a6d4?, 0x400043fe00?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1455
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1489 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001b9b960, 0x40026f3b00, 0x4000ae4d20, 0x40018845a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1448
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1445 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1414
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1447 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1414
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 10384 [select, 2 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x4004084180, 0x4001d42fc0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x4004084180, 0x8a6d4?, 0x400139e9c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1438
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1441 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x400101e0d8, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400101e0c8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400101e0b0, 0x40012ff0c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001ad1900)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x40022f4ec0, {0x3ddab40, 0x400232fb30}, 0x1, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x40022f4ec0, 0x3b9aca00, 0x0, 0x1, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001ad1900, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40010b9560, 0x40000c7c80)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 466
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1511 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x400043fcc0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x40011ae8c0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1442 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 466
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1421 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 465
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1463 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1441
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1509 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x13d4900?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4002b3bf90?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 1457 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1432
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1420 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x400217da48, 0x0)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217da38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217da20, 0x40012ff000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001ad1860)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400329fec0, {0x3ddab40, 0x400233eb10}, 0x1, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x400329fec0, 0x3b9aca00, 0x0, 0x1, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001ad1860, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40010b9500, 0x4000d8b380)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 465
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1363 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/kvstore.Client(...)
	/go/src/github.com/cilium/cilium/pkg/kvstore/client.go:53
github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1.1()
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:417 +0x100
created by github.com/cilium/cilium/pkg/ipcache.(*IPCache).InitIPIdentityWatcher.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:413 +0xb0

goroutine 1721 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4000ac8fc0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1718
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 1366 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/bgpv1/manager/store.NewDiffStore[...].func1({0x7, 0xfffffffffffffffc})
	/go/src/github.com/cilium/cilium/pkg/bgpv1/manager/store/diffstore.go:83 +0x164
github.com/cilium/hive/job.(*jobOneShot).start(0x4001d44f60, {0x3e237f0, 0x4001ff0cf0}, 0x4001a83620?, {0x3e2b960, 0x4001d44e40}, {{{0x4000df4920, 0x1, 0x1}}, 0x4000df9660, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1469 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001b9a7e0, 0x40026f24e0, 0x4000ae41e0, 0x4001884180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 3679 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003459180, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000d55c90, 0x1, 0x4000d55ca0, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1433 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1610 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1367
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1408 [syscall, 10 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:152 +0x30
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:23 +0x1c
created by os/signal.Notify.func1.1 in goroutine 1
	/usr/local/go/src/os/signal/signal.go:151 +0x28

goroutine 1357 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 635
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1406 [select]:
golang.org/x/sync/semaphore.(*Weighted).Acquire(0x40009e4af0, {0x3e237f0, 0x4001ff1dd0}, 0x1)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sync/semaphore/semaphore.go:74 +0x414
github.com/cilium/cilium/pkg/rate.(*Limiter).WaitN(0x40012ff180, {0x3e237f0, 0x4001ff1dd0}, 0x1)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:104 +0x74
github.com/cilium/cilium/pkg/rate.(*Limiter).Wait(...)
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:91
github.com/cilium/cilium/pkg/hive/health.publishJob({0x3e237f0, 0x4001ff1dd0}, {{{}}, 0x400163e8c0, {0x3e5d368, 0x400163e930}, {0x3e24e30, 0x4001bda7e0}, 0x4001c37430}, 0x40011a8040)
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:85 +0x244
github.com/cilium/cilium/pkg/hive/health.metricPublisher.func2({0x3e237f0?, 0x4001ff1dd0?}, {0x7?, 0xfffffffffffffffc?})
	/go/src/github.com/cilium/cilium/pkg/hive/health/metrics.go:59 +0x40
github.com/cilium/hive/job.(*jobOneShot).start(0x40018b1200, {0x3e237f0, 0x4001ff1dd0}, 0x4002e0ede0?, {0x3e2b960, 0x40018b11a0}, {{{0x4001caf140, 0x1, 0x1}}, 0x4000385940, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/oneshot.go:136 +0x3f4
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1404 [select]:
github.com/cilium/hive/job.(*jobTimer).start(0x40018b0060, {0x3e237f0, 0x4001ff1b90}, 0x400316e840?, {0x3e2b960, 0x40018b0000}, {{{0x0, 0x0, 0x0}}, 0x4001ce18b0, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:120 +0x2e0
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 1377 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1356
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1397 [select]:
github.com/cilium/cilium/pkg/rate.NewLimiter.func1()
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:47 +0x88
created by github.com/cilium/cilium/pkg/rate.NewLimiter in goroutine 1
	/go/src/github.com/cilium/cilium/pkg/rate/limiter.go:45 +0x120

goroutine 1398 [select, 6 minutes]:
github.com/cilium/cilium/daemon/cmd.(*deviceReloader).reload(0x4002408460, {0x3e237f0, 0x4001ff1770})
	/go/src/github.com/cilium/cilium/daemon/cmd/device-reloader.go:84 +0x8c
github.com/cilium/hive/job.(*jobTimer).start(0x4000ebbb00, {0x3e237f0, 0x4001ff1770}, 0x40031cc1e0?, {0x3e2b960, 0x4001c67860}, {{{0x0, 0x0, 0x0}}, 0x400029ab60, ...})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/timer.go:131 +0x34c
created by github.com/cilium/hive/job.(*group).Start.func1 in goroutine 1
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/hive/job/job.go:159 +0x148

goroutine 11622 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 1432 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4001a3e708, 0xca)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4001a3e6f8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x4001a3e6e0, 0x4000035840)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4002408000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002b74ec0, {0x3ddab40, 0x400232f560}, 0x1, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002b74ec0, 0x3b9aca00, 0x0, 0x1, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4002408000, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x4000f34fe0, 0x40000c7800)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 464
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 1392 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1378 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004bf4580}, {0xffff6968f080, 0x400217d130}, {0x3e672a8, 0x371d680}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001b9a7e0, {0x0?, 0x0?}, 0x40026f24e0, 0x4001884180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001b9a7e0, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400266df40, {0x3ddab60, 0x400347d950}, 0x1, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001b9a7e0, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1356
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1409 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000e991a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1391 [sync.Cond.Wait, 10 minutes]:
sync.runtime_notifyListWait(0x40012fe850, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40012fe840)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000e98f60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4acc0, {0x3e23828, 0x400347dbd0}, 0x40026f28a0, {0x3e3b308, 0x40025b4540})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1356 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400217d158, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400217d148)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0x400217d130, 0x4001683c00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:575 +0x1dc
k8s.io/client-go/tools/cache.(*controller).processLoop(0x4001ad1680)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:188 +0x3c
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x30?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002f09ec0, {0x3ddab40, 0x4002320630}, 0x1, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0x4002f09ec0, 0x3b9aca00, 0x0, 0x1, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:204 +0x80
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:161
k8s.io/client-go/tools/cache.(*controller).Run(0x4001ad1680, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:159 +0x2ac
github.com/cilium/cilium/pkg/k8s/resource.(*wrapperController).Run(0x40010b8fa0, 0x40026f24e0)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:821 +0xa8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:379 +0xc0
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).startWhenNeeded in goroutine 635
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:377 +0x240

goroutine 3752 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e4e750, {0x3e23828, 0x40035af5e0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3739
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1390 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000e990e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1388 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 1557 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001bd4ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1389 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000e98f60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1386 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000e98de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1381 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000e98a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1383 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0x40012fe050, 0x21)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40012fe040)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000e98a20)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4adc0, {0x3e23828, 0x400347d9f0}, 0x40026f2720, {0x3e3b3b8, 0x4001affa88})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1385 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4000e98c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 1476 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001fd0620, 0x40000c7500, 0x4001659620, 0x40017f83c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1438
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1387 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40012fe450, 0x186)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40012fe440)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4000e98c60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4ad40, {0x3e23828, 0x400347dae0}, 0x40026f27e0, {0x3e3b360, 0x4001affb30})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1382 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4000e98ba0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1394
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 1435 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.merge[...].func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:918 +0x54
created by github.com/cilium/cilium/pkg/k8s/resource.merge[...] in goroutine 1427
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:917 +0xa8

goroutine 1384 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1394
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 3812 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3760
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 1438 [select]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x4004080a00}, {0xffff6968f080, 0x4001a3e630}, {0x3e672a8, 0x3722640}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001fd0620, {0x0?, 0x0?}, 0x40000c7500, 0x40017f83c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001fd0620, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x4002683f40, {0x3ddab60, 0x40008294a0}, 0x1, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001fd0620, 0x40000c7500)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1427
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 6562 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400465a780, 0x4001bff8c0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400465a780, 0x8a6d4?, 0x400139e7c0?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1459 [chan receive, 10 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:132 +0x2c
created by k8s.io/client-go/tools/cache.(*controller).Run in goroutine 1432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:131 +0x94

goroutine 1460 [select, 1 minutes]:
k8s.io/client-go/tools/cache.watchHandler({0x0?, 0x0?, 0x6279580?}, {0x3e03b50, 0x400130bb80}, {0xffff6968f080, 0x4001a3e6e0}, {0x3e672a8, 0x370c0c0}, 0x0, ...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:732 +0x120
k8s.io/client-go/tools/cache.(*Reflector).watch(0x4001fd0b60, {0x0?, 0x0?}, 0x40000c7800, 0x40018843c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:445 +0x3e0
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0x4001fd0b60, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:365 +0x404
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:298 +0x28
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x10?)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:226 +0x40
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0x400268df40, {0x3ddab60, 0x4000829630}, 0x1, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/backoff.go:227 +0x90
k8s.io/client-go/tools/cache.(*Reflector).Run(0x4001fd0b60, 0x40000c7800)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:297 +0x184
k8s.io/client-go/tools/cache.(*controller).Run.(*Group).StartWithChannel.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:55 +0x28
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:72 +0x5c
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start in goroutine 1432
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:70 +0x7c

goroutine 1471 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001fd0b60, 0x40000c7800, 0x4000ae4720, 0x40018843c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1460
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 11472 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4004ccb248, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004ccb238)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004ccb230, {0x40019dd201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002693cc8?}, {0x40019dd201?, 0x4002693cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002e09900)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002e09900)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002e09900, {0x30150e0, 0x4004129038})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400541bd10, {0x4004bf2400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004e85d60, 0x0, {0x3e02238, 0x4004d35980})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a93e60)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004ff5200)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1455
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 1493 [select, 10 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).startResync(0x4001fd1180, 0x40000c7c80, 0x4001a5c1e0, 0x4001884b40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:377 +0xbc
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch in goroutine 1466
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:364 +0x3ec

goroutine 1558 [select]:
k8s.io/client-go/util/workqueue.(*delayingType).waitingLoop(0x4001bd4fc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:276 +0x254
created by k8s.io/client-go/util/workqueue.newDelayingQueue in goroutine 1366
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/delaying_queue.go:113 +0x1e0

goroutine 11007 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11009 [select, 1 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0x400340a300, 0x4001bfab40, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1536 +0x87c
golang.org/x/net/http2.(*clientStream).doRequest(0x400340a300, 0x4003cb4b40?, 0x4000c89c80?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1414 +0x58
created by golang.org/x/net/http2.(*ClientConn).roundTrip in goroutine 1466
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1319 +0x374

goroutine 1731 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40029f6b40, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40032ea2a0}, 0x4001a3ad70, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1620
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1607 [chan receive]:
k8s.io/client-go/util/workqueue.(*Type).updateUnfinishedWorkLoop(0x4001f56de0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:281 +0x94
created by k8s.io/client-go/util/workqueue.newQueue in goroutine 1367
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:106 +0x1a8

goroutine 3818 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3810
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 1720 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69629288, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40029bb780?, 0x4002ae1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40029bb780, {0x4002ae1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40029bb780, {0x4002ae1000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001a03340, {0x4002ae1000?, 0x12?, 0x40029e2d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4000ac8fc0, {0x4002ae1000?, 0x4002b3bd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400315fb60)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400315fb60, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4000ac8fc0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1718
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 1518 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1519 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1520 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1521 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1522 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1523 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1524 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1525 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1526 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1527 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1528 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1529 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1530 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1531 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1532 [select]:
github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe.func1()
	/go/src/github.com/cilium/cilium/pkg/status/status.go:151 +0xfc
created by github.com/cilium/cilium/pkg/status.(*Collector).spawnProbe in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/status/status.go:141 +0x70

goroutine 1533 [IO wait]:
internal/poll.runtime_pollWait(0xffff699f25f8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x31?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4002399200)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4002399200)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40019c2320)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40019c2320)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x4000135e00, {0x3e0bbf0, 0x40019c2320})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService.func2({0x400128a9c0, 0xe}, {0x3e0bbf0, 0x40019c2320})
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:75 +0xa0
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).startAgentHealthHTTPService in goroutine 1364
	/go/src/github.com/cilium/cilium/daemon/cmd/agenthealth.go:70 +0x560

goroutine 1534 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40009663c0, {{{0x37bdc75, 0x15}}, {0x0, 0x0}, 0x40023ce7b0, 0x0, 0x39b9348, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3863 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 1536 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000966500, {{{0x37c1af7, 0x16}}, {0x3e2b960, 0x4001f89c20}, 0x40011afe10, 0x0, 0x39b9348, 0xe33e22200, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1364
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1559 [sync.Cond.Wait, 6 minutes]:
sync.runtime_notifyListWait(0x400106a4d0, 0x6)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400106a4c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
k8s.io/client-go/util/workqueue.(*Type).Get(0x4001bd4ea0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/util/workqueue/queue.go:200 +0x90
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).getWorkItem(...)
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:698
github.com/cilium/cilium/pkg/k8s/resource.(*subscriber[...]).processLoop(0x3e4b040, {0x3e23828, 0x400039f090}, 0x4002598240, {0x3e3b570, 0x4002377b90})
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:622 +0xf8
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func1()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:511 +0x29c
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1366
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:477 +0x478

goroutine 1565 [syscall, 10 minutes]:
syscall.Syscall6(0x5f, 0x1, 0x21a, 0x4002aa1ca8, 0x1000004, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
os.(*Process).blockUntilWaitable(0x4002354180)
	/usr/local/go/src/os/wait_waitid.go:32 +0x6c
os.(*Process).wait(0x4002354180)
	/usr/local/go/src/os/exec_unix.go:22 +0x2c
os.(*Process).Wait(...)
	/usr/local/go/src/os/exec.go:134
os/exec.(*Cmd).Wait(0x4001ee8000)
	/usr/local/go/src/os/exec/exec.go:901 +0x38
github.com/cilium/cilium/pkg/launcher.(*Launcher).Run.func1()
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:48 +0x38
created by github.com/cilium/cilium/pkg/launcher.(*Launcher).Run in goroutine 1564
	/go/src/github.com/cilium/cilium/pkg/launcher/launcher.go:47 +0x3bc

goroutine 1560 [select, 10 minutes]:
github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events.func2()
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:523 +0xf4
created by github.com/cilium/cilium/pkg/k8s/resource.(*resource[...]).Events in goroutine 1366
	/go/src/github.com/cilium/cilium/pkg/k8s/resource/resource.go:521 +0x50c

goroutine 3741 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e15360, {0x3e23828, 0x40035aea50})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3721
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1688 [IO wait, 4 minutes]:
internal/poll.runtime_pollWait(0xffff69629478, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x94?, 0x8?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x40029ba200)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x40029ba200)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x4001b93ca0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x4001b93ca0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
net/http.(*Server).Serve(0x4000135d10, {0x3e0bbf0, 0x4001b93ca0})
	/usr/local/go/src/net/http/server.go:3260 +0x2a8
net/http.(*Server).ListenAndServe(0x4000135d10)
	/usr/local/go/src/net/http/server.go:3189 +0x84
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:50 +0x28
created by github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve in goroutine 1683
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:49 +0x58

goroutine 1684 [semacquire, 10 minutes]:
sync.runtime_Semacquire(0x40017896c0?)
	/usr/local/go/src/runtime/sema.go:62 +0x2c
sync.(*WaitGroup).Wait(0x40017ee940)
	/usr/local/go/src/sync/waitgroup.go:116 +0x74
github.com/cilium/cilium/api/v1/health/server.(*Server).Serve(0x40017ee800)
	/go/src/github.com/cilium/cilium/api/v1/health/server/server.go:310 +0xa8
github.com/cilium/cilium/pkg/health/server.(*Server).runActiveServices(0x40017ee800)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:370 +0x100
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func2()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:388 +0x28
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1682
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:387 +0xd0

goroutine 1683 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/health/probe/responder.(*Server).Serve(0x40019e4228)
	/go/src/github.com/cilium/cilium/pkg/health/probe/responder/responder.go:55 +0xd4
github.com/cilium/cilium/pkg/health/server.(*Server).Serve.func1()
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:384 +0x2c
created by github.com/cilium/cilium/pkg/health/server.(*Server).Serve in goroutine 1682
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:383 +0x80

goroutine 1682 [chan receive, 10 minutes]:
github.com/cilium/cilium/pkg/health/server.(*Server).Serve(0x40017ee800)
	/go/src/github.com/cilium/cilium/pkg/health/server/server.go:392 +0xe0
github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer.func1()
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:94 +0x5c
created by github.com/cilium/cilium/cilium-health/launch.(*CiliumHealth).runServer in goroutine 1514
	/go/src/github.com/cilium/cilium/cilium-health/launch/launcher.go:92 +0x1d8

goroutine 1678 [select, 10 minutes]:
net/http.(*persistConn).writeLoop(0x4001d667e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 1676
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 3805 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002893688)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 1677 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff699f2028, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400287f780?, 0x40028f0000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400287f780, {0x40028f0000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400287f780, {0x40028f0000?, 0x1?, 0x40017b6000?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001a023b8, {0x40028f0000?, 0xc?, 0x4001fb7600?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4001d667e0, {0x40028f0000?, 0x18550?, 0x4003182b40?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400319b9e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400319b9e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4001d667e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 1676
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3733 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3677
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3792 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002892908)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3880 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001d79680)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3766
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 1699 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629098, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400294cb80?, 0x400285e400?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadFrom(0x400294cb80, {0x400285e400, 0x200, 0x200})
	/usr/local/go/src/internal/poll/fd_unix.go:220 +0x214
net.(*netFD).readFrom(0x400294cb80, {0x400285e400?, 0x72?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:61 +0x28
net.(*IPConn).readFrom(0x400294cb80?, {0x400285e400, 0x200, 0x200})
	/usr/local/go/src/net/iprawsock_posix.go:49 +0x2c
net.(*IPConn).ReadFrom(0x4000db6210, {0x400285e400?, 0x4002e88ea8?, 0x4002e88e70?})
	/usr/local/go/src/net/iprawsock.go:129 +0x2c
golang.org/x/net/icmp.(*PacketConn).ReadFrom(0xc1bea281cb1d0d21?, {0x400285e400?, 0x6279580?, 0x6279580?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/icmp/endpoint.go:58 +0x34
github.com/servak/go-fastping.(*Pinger).recvICMP(0x400296d440, 0x400198b580, 0x40031cd980, 0x400198b5c0, 0x40011ac870)
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:570 +0x114
created by github.com/servak/go-fastping.(*Pinger).run in goroutine 1728
	/go/src/github.com/cilium/cilium/vendor/github.com/servak/go-fastping/fastping.go:425 +0x2d8

goroutine 1667 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e9f180, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001ce1900, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1515
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3776 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x4003828050, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x400044dab0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3763
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 1665 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x39bbdc8?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001923280?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 1515
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3810 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038e2fa0, {0x40038f6700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038e2fa0, {0x40038f6700?, 0x40034cafa8?, 0x4003703930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40038f66c0, {0x40038f6700?, 0x40037039b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40038f66c0}, {0x40038f6700, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40034f7320, {0x40038f6700, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40038f66f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40038f66f0, 0x40034f7320, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40034f7320?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f2c940}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4001c81c70, {0x3612420, 0x4000f2c940}, 0x4000f2df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003703d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40034f70e0, 0x4003703e10, 0x4003703e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40034f70e0, {0x3612420?, 0x4000f2c940?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40038e46a8, {0x3612420, 0x4000f2c940})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000a7bae0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4003622320)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3760
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 1771 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003600000, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003602300}, 0x40018a72d0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1665
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3826 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3732
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3719 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003459a40, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000dc2b10, 0x1, 0x4000dc2b20, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10757 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 3710 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d23d10, {0x3e23828, 0x40034d62d0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3737
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 1601 [select, 6 minutes]:
github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch.func2()
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:138 +0x110
created by github.com/cilium/cilium/pkg/crypto/certloader.(*Watcher).Watch in goroutine 1593
	/go/src/github.com/cilium/cilium/pkg/crypto/certloader/watcher.go:135 +0x200

goroutine 1566 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001ad1d60)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 1515
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 1796 [select, 1 minutes]:
reflect.rselect({0x4003793c20, 0x9, 0xffff697e3570?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4001b60e00?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4000f1e840, {0x3e237f0, 0x40028826c0}, 0x4000310ee0, {0xffff6960c8c0, 0x4000f27ac0}, 0x40034bea20, {0x385b1ff?, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4000f1e840, {0x3e237f0, 0x40028826c0}, {0xffff6960c8c0, 0x4000f27ac0}, {0x385b1ff, 0x35})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamListeners(0x4000f1e840, {0x3e3e7a8, 0x4000f27ac0})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:78 +0x78
github.com/cilium/proxy/go/envoy/service/listener/v3._ListenerDiscoveryService_StreamListeners_Handler({0x365dfc0?, 0x4000f1e840}, {0x3e32818, 0x4000ce12c0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/envoy/service/listener/v3/lds.pb.go:359 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40017ee200, {0x3e237f0, 0x40028825a0}, {0x3e42860, 0x4001779500}, 0x4000b1c900, 0x4000f1eb70, 0x62382a0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40017ee200, {0x3e42860, 0x4001779500}, 0x4000b1c900)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 504
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 1584 [chan receive, 10 minutes]:
github.com/cilium/stream.Multicast[...].func3.1()
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:245 +0x13c
created by github.com/cilium/stream.Multicast[...].func3 in goroutine 1535
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/stream/sources.go:238 +0x348

goroutine 1585 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e888c0, {{{0x378d189, 0xa}}, {0x0, 0x0}, 0x39b9e78, 0x0, 0x39b9348, 0x37e11d600, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1535
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1586 [select]:
github.com/cilium/cilium/pkg/hubble/observer.(*namespaceManager).Run(0x4000b5de30, {0x3e23828, 0x400240a3c0})
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/namespace_manager.go:49 +0xec
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:273 +0x20f0

goroutine 1587 [chan receive]:
github.com/cilium/cilium/pkg/hubble/observer.(*LocalObserverServer).Start(0x4001e88a00)
	/go/src/github.com/cilium/cilium/pkg/hubble/observer/local_observer.go:122 +0x78
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:285 +0x216c

goroutine 1588 [syscall]:
syscall.Syscall6(0x16, 0x2d, 0x40023d4020, 0x2, 0xffffffffffffffff, 0x0, 0x0)
	/usr/local/go/src/syscall/syscall_linux.go:91 +0x2c
golang.org/x/sys/unix.EpollWait(0x4000074001?, {0x40023d4020?, 0x4002687918?, 0x1ea7078?}, 0x3ddd880?)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/sys/unix/zsyscall_linux_arm64.go:55 +0x4c
github.com/cilium/ebpf/internal/unix.EpollWait(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/unix/types_linux.go:131
github.com/cilium/ebpf/internal/epoll.(*Poller).Wait(0x40019337a0, {0x40023d4020, 0x2, 0x2}, {0x74?, 0x74?, 0x0?})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/internal/epoll/poller.go:145 +0x220
github.com/cilium/ebpf/perf.(*Reader).ReadInto(0x4001b70780, 0x4002687af0)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:362 +0x2dc
github.com/cilium/ebpf/perf.(*Reader).Read(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/ebpf/perf/reader.go:336
github.com/cilium/cilium/pkg/monitor/agent.(*agent).handleEvents(0x400163f8f0, {0x3e23828, 0x400046a320})
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:340 +0x404
created by github.com/cilium/cilium/pkg/monitor/agent.(*agent).startPerfReaderLocked in goroutine 1535
	/go/src/github.com/cilium/cilium/pkg/monitor/agent/agent.go:209 +0xd4

goroutine 1589 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69629e28, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x34?, 0x2911c?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x4003187800)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x4003187800)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*UnixListener).accept(0x400268fb28?)
	/usr/local/go/src/net/unixsock_posix.go:172 +0x20
net.(*UnixListener).Accept(0x40000d0db0)
	/usr/local/go/src/net/unixsock.go:260 +0x2c
google.golang.org/grpc.(*Server).Serve(0x40031d1200, {0x3e0bc20, 0x40000d0db0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func4()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:337 +0x4c
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:336 +0x2fc8

goroutine 1590 [chan receive, 10 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func5()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:342 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:341 +0x3028

goroutine 1591 [IO wait, 8 minutes]:
internal/poll.runtime_pollWait(0xffff69629d30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001d283c0?, 0x4002af9e2b?, 0x1)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001d283c0, {0x4002af9e2b, 0x10000, 0x10000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
os.(*File).read(...)
	/usr/local/go/src/os/file_posix.go:29
os.(*File).Read(0x4001237cc0, {0x4002af9e2b?, 0x0?, 0x1?})
	/usr/local/go/src/os/file.go:118 +0x70
github.com/fsnotify/fsnotify.(*Watcher).readEvents(0x40014aff00)
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:483 +0xe8
created by github.com/fsnotify/fsnotify.NewBufferedWatcher in goroutine 1535
	/go/src/github.com/cilium/cilium/vendor/github.com/fsnotify/fsnotify/backend_inotify.go:270 +0x1b4

goroutine 1592 [select, 8 minutes]:
github.com/cilium/cilium/pkg/fswatcher.(*Watcher).loop(0x4000ad0b40)
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:210 +0x90
created by github.com/cilium/cilium/pkg/fswatcher.New in goroutine 1535
	/go/src/github.com/cilium/cilium/pkg/fswatcher/fswatcher.go:98 +0x1f8

goroutine 1603 [chan receive, 10 minutes]:
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func7()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:412 +0x44
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:411 +0x3adc

goroutine 1602 [IO wait, 10 minutes]:
internal/poll.runtime_pollWait(0xffff69629b40, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x3e?, 0x4002186340?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0x400236c500)
	/usr/local/go/src/internal/poll/fd_unix.go:611 +0x250
net.(*netFD).accept(0x400236c500)
	/usr/local/go/src/net/fd_unix.go:172 +0x28
net.(*TCPListener).accept(0x40019c3ca0)
	/usr/local/go/src/net/tcpsock_posix.go:159 +0x28
net.(*TCPListener).Accept(0x40019c3ca0)
	/usr/local/go/src/net/tcpsock.go:327 +0x2c
google.golang.org/grpc.(*Server).Serve(0x4001820000, {0x3e0bbf0, 0x40019c3ca0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:885 +0x43c
github.com/cilium/cilium/pkg/hubble/server.(*Server).Serve(...)
	/go/src/github.com/cilium/cilium/pkg/hubble/server/server.go:104
github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble.func6()
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:403 +0x54
created by github.com/cilium/cilium/daemon/cmd.(*Daemon).launchHubble in goroutine 1535
	/go/src/github.com/cilium/cilium/daemon/cmd/hubble.go:402 +0x3a7c

goroutine 3865 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038e3ae0, {0x4003990130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038e3ae0, {0x4003990130?, 0x40034cb1e8?, 0x40026bd950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039900f0, {0x4003990130?, 0x40026bd9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039900f0}, {0x4003990130, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400398cd80, {0x4003990130, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003990120, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003990120, 0x400398cd80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400398cd80?, {0xffff69693090, 0x680cae0}, 0xffffb05f65b8?, {0x0?, 0x0?}, {0x368b2c0, 0x400547aaf0}, 0x4002d66c68?, 0x47350?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003988750, {0x368b2c0, 0x400547aaf0}, 0x400547bf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40026bdd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400398cb40, 0x40026bde30, 0x40026bde78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400398cb40, {0x368b2c0?, 0x400547aaf0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40038e4eb8, {0x368b2c0, 0x400547aaf0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000aa6cc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40039885b0, {0x3e3faf0, 0x4000aa6cc0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 1652 [select, 10 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef3900, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4000878730, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1598
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3860 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4001f0b360, {0x3e23828, 0x40038e3b80}, 0x766e92bdd26fb39f, 0x40038feba0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 1657 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001ef3cc0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4001d08df0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1652
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 1648 [select, 10 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4001ae00a0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4001e9edc0, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4001ce1480, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1515
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3861 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038e3e50, {0x40039908e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038e3e50, {0x40039908e0?, 0x40034cb230?, 0x4003707930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039908a0, {0x40039908e0?, 0x40037079b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039908a0}, {0x40039908e0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400398d440, {0x40039908e0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039908d0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039908d0, 0x400398d440, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400398d440?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40013d7b00}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003988d00, {0x3612420, 0x40013d7b00}, 0x40013d7f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003707d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400398d200, 0x4003707e10, 0x4003707e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400398d200, {0x3612420?, 0x40013d7b00?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40038e5200, {0x3612420, 0x40013d7b00})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000aa6ff0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4001f0b360)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3862 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4001f0b360)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3765
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3766 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3737
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3729 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3675
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3581 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x400027ac01?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4002321740?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 3756 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3721
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3722 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3800 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40036d4aa0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40007389a0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3726
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3796 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002892fc8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3758
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3870 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4002172900)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3756
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3799 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40036d4820, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40007388c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3744
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3857 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40039885b0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3815
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3750 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e4e6f0, {0x3e23828, 0x40035af540})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3739
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3824 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3815
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3680 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3678 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3859 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3713 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d91550, {0x3e23828, 0x40035078b0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3675
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3802 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40036d51d0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000738e00)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3758
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3715 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d915b0, {0x3e23828, 0x4003507950})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3675
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3720 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3676 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3578 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002409b80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 3716 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc2600, {0x3e23828, 0x4003507a90})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3677
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3717 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc2630, {0x3e23828, 0x4003507ae0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3677
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3735 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000df94e0, {0x3e23828, 0x40035ae820})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3719
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3709 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d23c80, {0x3e23828, 0x40034d6280})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3737
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3819 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4003622320, {0x3e3fa98, 0x4000a7bae0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3810
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 1794 [select, 9 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4000514000, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003430480}, 0x40015504d0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 1650
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3582 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002e09540, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4002e072c0}, 0x400039cd90, 0x0, 0x4001edced0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3724 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc3a70, {0x3e23828, 0x4003507e00})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3679
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3737 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035aa500, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000df9920, 0x1, 0x4000df9930, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3813 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40034d1400, 0x4003e89800)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3760
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3820 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x400041d601?, {0x3e23828, 0x40038e3180}, {0x3e5f080?, 0x4001b26ea0?}, 0x4000e15c70)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3739
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 2297 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69628fa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40034d1780?, 0x4003764000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40034d1780, {0x4003764000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40034d1780, {0x4003764000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000db7c38, {0x4003764000?, 0xf?, 0x4002d5dd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x400150aa20, {0x4003764000?, 0x4002dbfd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x400371ff20)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x400371ff20, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x400150aa20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 2295
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 3721 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003459b80, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000dc2f60, 0x1, 0x4000dc2f70, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3806 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629c38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003255a00?, 0x400026d500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003255a00, {0x400026d500, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003255a00, {0x400026d500?, 0xffff696d0788?, 0x4001ffe180?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400190cbc0, {0x400026d500?, 0x4002a42928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001ffe180, {0x400026d500?, 0x0?, 0x4001ffe180?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40034fa2b0, {0x3dd1940, 0x4001ffe180})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40034fa008, {0x3dcbd80, 0x400190cbc0}, 0x4002a42a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40034fa008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40034fa008, {0x4003904000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400386d860, {0x400236ad60, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400386d860}, {0x400236ad60, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236ad60, 0x9, 0x90eb0e7103?}, {0x3dcc0a0?, 0x400386d860?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236ad20)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002893688, 0x400386d8c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3711
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3751 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e4e720, {0x3e23828, 0x40035af590})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3739
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3801 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40036d4fa0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x4000738af0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3753
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3738 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3815 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e23828, 0x40035ae910}, 0x4000edaa00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3777
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3828 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001c137a0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3733
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 4001 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001d78b40)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3762
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3591 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002e83680, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4002eab2c0}, 0x400046d020, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3581
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3723 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc3a40, {0x3e23828, 0x4003507db0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3679
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3718 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc2660, {0x3e23828, 0x4003507b30})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3677
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3736 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000df9510, {0x3e23828, 0x40035ae870})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3719
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3708 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d23c50, {0x3e23828, 0x40034d6230})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3737
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3725 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000dc3aa0, {0x3e23828, 0x4003507e50})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3679
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3739 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035aa640, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000df9d50, 0x1, 0x4000df9d60, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3740 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert.func1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:363 +0x8c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).onInsert in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:361 +0x128

goroutine 3743 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e153c0, {0x3e23828, 0x40035aeaf0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3721
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3804 [IO wait]:
internal/poll.runtime_pollWait(0xffff69601e80, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003255b00?, 0x4003727500?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003255b00, {0x4003727500, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003255b00, {0x4003727500?, 0xffff694e0298?, 0x40039e7b60?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400190cb80, {0x4003727500?, 0x4002d11928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039e7b60, {0x4003727500?, 0x0?, 0x40039e7b60?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40032fdb30, {0x3dd1940, 0x40039e7b60})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40032fd888, {0x3dcbd80, 0x400190cb80}, 0x4002d11a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40032fd888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40032fd888, {0x40038d2000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003811b60, {0x400236aba0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003811b60}, {0x400236aba0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236aba0, 0x9, 0x90ea21207f?}, {0x3dcc0a0?, 0x4003811b60?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236ab60)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002893208, 0x4003811bc0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3763
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3747 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3679
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3742 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000e15390, {0x3e23828, 0x40035aeaa0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3721
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3891 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001ce3200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3747
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3583 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002e09680, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002db1540, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3571
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3734 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000df94b0, {0x3e23828, 0x40035ae7d0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3719
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3825 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400165d5e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3732
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3677 [select, 8 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003459040, {{{0x37d54f3, 0x1a}}, {0x0, 0x0}, 0x4000d557f0, 0x1, 0x4000d55800, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 637
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3809 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4003622320, {0x3e23828, 0x40038e2550}, 0x766e92bdd26fb39d, 0x40034f3620)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3760
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3884 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001c13200)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3729
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3604 [select, 1 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4002e097c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x400033d990, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 3583
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 3714 [select, 8 minutes]:
google.golang.org/grpc/internal/grpcsync.(*CallbackSerializer).run(0x4000d91580, {0x3e23828, 0x4003507900})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:76 +0xc8
created by google.golang.org/grpc/internal/grpcsync.NewCallbackSerializer in goroutine 3675
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/grpcsync/callback_serializer.go:52 +0x118

goroutine 3762 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3719
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3814 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).statusChecker(0x4001b26ea0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1096 +0x820
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4 in goroutine 3777
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:670 +0xa8

goroutine 3777 [select]:
github.com/cilium/cilium/pkg/kvstore.connectEtcdClient.func4()
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:675 +0x1c0
created by github.com/cilium/cilium/pkg/kvstore.connectEtcdClient in goroutine 3739
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:643 +0xa94

goroutine 3807 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400165d5e0, {0x3e23828, 0x4003828960}, 0x766e92bdd26fb3a7, 0x40037fd2c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3732
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3794 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002892b48)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3753
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3788 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x4002892248)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3744
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3790 [select]:
google.golang.org/grpc/internal/transport.(*http2Client).keepalive(0x40028926c8)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1694 +0x100
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3726
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:399 +0x1658

goroutine 3789 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629570, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40034d1180?, 0x400025e400?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40034d1180, {0x400025e400, 0xc00, 0xc00})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40034d1180, {0x400025e400?, 0xffff694e0298?, 0x40039e7d58?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001781610, {0x400025e400?, 0x40026ae928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039e7d58, {0x400025e400?, 0x0?, 0x40039e7d58?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400356deb0, {0x3dd1940, 0x40039e7d58})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400356dc08, {0x3dcbd80, 0x4001781610}, 0x40026aea00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400356dc08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400356dc08, {0x4003746000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40036d9560, {0x400236a200, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40036d9560}, {0x400236a200, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236a200, 0x9, 0x90ea2342d4?}, {0x3dcc0a0?, 0x40036d9560?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236a1c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002892248, 0x40036d95c0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3744
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3791 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629a48, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40034d0c80?, 0x4003945800?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40034d0c80, {0x4003945800, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40034d0c80, {0x4003945800?, 0xffff694e0298?, 0x40039e7d70?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001781620, {0x4003945800?, 0x40026af928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039e7d70, {0x4003945800?, 0x0?, 0x40039e7d70?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40036bc2b0, {0x3dd1940, 0x40039e7d70})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40036bc008, {0x3dcbd80, 0x4001781620}, 0x40026afa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40036bc008, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40036bc008, {0x4003780000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x40036f5200, {0x400236a3c0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x40036f5200}, {0x400236a3c0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236a3c0, 0x9, 0x90ea282754?}, {0x3dcc0a0?, 0x40036f5200?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236a380)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x40028926c8, 0x40036f5260)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3726
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3793 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629858, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003255500?, 0x400026ca80?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003255500, {0x400026ca80, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003255500, {0x400026ca80?, 0xffff696d0788?, 0x4001ffe198?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400190cba8, {0x400026ca80?, 0x40015f7928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x4001ffe198, {0x400026ca80?, 0x0?, 0x4001ffe198?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x40032fdeb0, {0x3dd1940, 0x4001ffe198})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x40032fdc08, {0x3dcbd80, 0x400190cba8}, 0x40015f7a00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x40032fdc08, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x40032fdc08, {0x40037a2000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003722e40, {0x400236a580, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003722e40}, {0x400236a580, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236a580, 0x9, 0x90eb0e6a40?}, {0x3dcc0a0?, 0x4003722e40?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236a540)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002892908, 0x4003722ea0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3795 [IO wait]:
internal/poll.runtime_pollWait(0xffff69629380, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40034d1480?, 0x4003726700?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40034d1480, {0x4003726700, 0x700, 0x700})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40034d1480, {0x4003726700?, 0xffff694e0298?, 0x40039e7b90?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4001781600, {0x4003726700?, 0x400329b928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039e7b90, {0x4003726700?, 0x0?, 0x40039e7b90?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400356db30, {0x3dd1940, 0x40039e7b90})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400356d888, {0x3dcbd80, 0x4001781600}, 0x400329ba00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400356d888, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400356d888, {0x40037c4000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x400373ac00, {0x400236a740, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x400373ac00}, {0x400236a740, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236a740, 0x9, 0x90ea2039fd?}, {0x3dcc0a0?, 0x400373ac00?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236a700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002892b48, 0x400373ac60)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3753
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3797 [IO wait]:
internal/poll.runtime_pollWait(0xffff69601f78, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40034d1580?, 0x40001c4000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40034d1580, {0x40001c4000, 0xa80, 0xa80})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40034d1580, {0x40001c4000?, 0xffff694e0298?, 0x40039e7d88?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40017815f0, {0x40001c4000?, 0x4002d5f928?, 0x206bc?})
	/usr/local/go/src/net/net.go:185 +0x34
crypto/tls.(*atLeastReader).Read(0x40039e7d88, {0x40001c4000?, 0x0?, 0x40039e7d88?})
	/usr/local/go/src/crypto/tls/conn.go:806 +0x40
bytes.(*Buffer).ReadFrom(0x400356d7b0, {0x3dd1940, 0x40039e7d88})
	/usr/local/go/src/bytes/buffer.go:211 +0x90
crypto/tls.(*Conn).readFromUntil(0x400356d508, {0x3dcbd80, 0x40017815f0}, 0x4002d5fa00?)
	/usr/local/go/src/crypto/tls/conn.go:828 +0xd0
crypto/tls.(*Conn).readRecordOrCCS(0x400356d508, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:626 +0x35c
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:588
crypto/tls.(*Conn).Read(0x400356d508, {0x40037f4000, 0x8000, 0x206bc?})
	/usr/local/go/src/crypto/tls/conn.go:1370 +0x168
bufio.(*Reader).Read(0x4003790840, {0x400236a9e0, 0x9, 0x72ed0?})
	/usr/local/go/src/bufio/bufio.go:241 +0x1b4
io.ReadAtLeast({0x3dcc0a0, 0x4003790840}, {0x400236a9e0, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
golang.org/x/net/http2.readFrameHeader({0x400236a9e0, 0x9, 0x90ea273592?}, {0x3dcc0a0?, 0x4003790840?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x58
golang.org/x/net/http2.(*Framer).ReadFrame(0x400236a9a0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:501 +0x78
google.golang.org/grpc/internal/transport.(*http2Client).reader(0x4002892fc8, 0x40037908a0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:1620 +0x1a8
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3758
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:409 +0x16bc

goroutine 3798 [select]:
google.golang.org/grpc/internal/transport.(*controlBuffer).get(0x40036d4cd0, 0x1)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:418 +0x14c
google.golang.org/grpc/internal/transport.(*loopyWriter).run(0x40007387e0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/controlbuf.go:552 +0x7c
google.golang.org/grpc/internal/transport.newHTTP2Client.func6()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:467 +0xb0
created by google.golang.org/grpc/internal/transport.newHTTP2Client in goroutine 3730
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/http2_client.go:465 +0x1b3c

goroutine 3827 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40032a1980, 0x400386eed0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3732
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3829 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e23828, 0x4003507720}, 0x40014ee140)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3733
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3832 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3808
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3833 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400165d5e0, {0x3e3fa98, 0x400060ed60})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3808
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3834 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40037fd260?, {0x3e23828, 0x4003828fa0}, {0x3e5f080?, 0x4001c137a0?}, 0x4000d915d0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3677
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3836 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4003622140, {0x3e23828, 0x4003829090}, 0x766e92bdd26fb3a1, 0x40037fdb00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3755
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3837 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038292c0, {0x4003926010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038292c0, {0x4003926010?, 0x40037fe378?, 0x4003713930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400386ff50, {0x4003926010?, 0x40037139b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400386ff50}, {0x4003926010, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003920d80, {0x4003926010, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003926000, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003926000, 0x4003920d80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003920d80?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x40013d7940}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003592f70, {0x3612420, 0x40013d7940}, 0x40013d7f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003713d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003920b40, 0x4003713e10, 0x4003713e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003920b40, {0x3612420?, 0x40013d7940?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003814e40, {0x3612420, 0x40013d7940})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x400060f040)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4003622140)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3755
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3838 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4003622140)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3755
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3839 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3755
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3840 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40034d1100, 0x400386f9e0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3755
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3841 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400165dcc0, {0x3e23828, 0x40038290e0}, 0x766e92bdd26fb3a5, 0x40037fdc80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3746
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3842 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003829540, {0x4003926280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003829540, {0x4003926280?, 0x40037fe390?, 0x40036a7930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003926240, {0x4003926280?, 0x40036a79b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003926240}, {0x4003926280, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40039210e0, {0x4003926280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003926270, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003926270, 0x40039210e0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40039210e0?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f2c5c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003593040, {0x3612420, 0x4000f2c5c0}, 0x4000f2df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x40036a7d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003920ea0, 0x40036a7e10, 0x40036a7e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003920ea0, {0x3612420?, 0x4000f2c5c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003814f30, {0x3612420, 0x4000f2c5c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x400060f110)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400165dcc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3746
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3843 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400165dcc0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3746
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3844 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3746
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3845 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40034d0b00, 0x400386fb60)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3746
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3846 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x400165d4a0, {0x3e23828, 0x4003829130}, 0x766e92bdd26fb3a3, 0x40037fde00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3728
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3847 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40038297c0, {0x40039264f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40038297c0, {0x40039264f0?, 0x40037fe3a8?, 0x4003717930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039264b0, {0x40039264f0?, 0x40037179b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039264b0}, {0x40039264f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003921440, {0x40039264f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039264e0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039264e0, 0x4003921440, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003921440?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f2c9c0}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003593110, {0x3612420, 0x4000f2c9c0}, 0x4000f2df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003717d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003921200, 0x4003717e10, 0x4003717e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003921200, {0x3612420?, 0x4000f2c9c0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003815020, {0x3612420, 0x4000f2c9c0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x400060f1e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x400165d4a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3728
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3848 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x400165d4a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3728
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3849 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3728
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 3850 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x40032a1780, 0x400386fce0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3728
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3851 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3837
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3852 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4003622140, {0x3e3fa98, 0x400060f040})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3837
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3853 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3842
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3854 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400165dcc0, {0x3e3fa98, 0x400060f110})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3842
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3864 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003255980, 0x4003990240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3765
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 3866 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x40033d4fd0, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3855 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3847
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3856 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x400165d4a0, {0x3e3fa98, 0x400060f1e0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3847
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3867 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3861
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3868 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4001f0b360, {0x3e3fa98, 0x4000aa6ff0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3861
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 3992 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003acc180, {0x3e23828, 0x4003828fa0}, {0xffff694dd4d0, 0x4001c137a0}, {0x4003ace0c0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40039e3320, {0x3e23828, 0x4003828fa0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001fd0ee0, {0x3e23828, 0x4003828fa0}, {0x3e5f080, 0x4001c137a0}, {0x4, {0x1, 0x1, 0xff}}, 0x4003ac8360)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3677
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3871 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e23828, 0x4003507c70}, 0x4001532940)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3756
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3875 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x400398e400, {0x3e23828, 0x40038e3180}, {0xffff694dd4d0, 0x4001b26ea0}, {0x40034cb458?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003996ba0, {0x3e23828, 0x40038e3180})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4002325260, {0x3e23828, 0x40038e3180}, {0x3e5f080, 0x4001b26ea0}, {0x5, {0x1, 0x1, 0xff}}, 0x40038ff7a0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3739
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3876 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e23828, 0x40038e3180}, 0x4001532cc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3875
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3889 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x0?, {0x3e23828, 0x4003829950}, {0x3e5f080?, 0x4002172900?}, 0x4000df9dc0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3721
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3988 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40039e9780, {0x3e23828, 0x4003829950}, {0xffff694dd4d0, 0x4002172900}, {0x40034cbf08?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40039e3020, {0x3e23828, 0x4003829950})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001fd1dc0, {0x3e23828, 0x4003829950}, {0x3e5f080, 0x4002172900}, {0x1, {0x1, 0x1, 0xff}}, 0x40039cbe00)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3721
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3879 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40038e3180?, {0x3e23828, 0x4003998b40}, {0x3e5f080?, 0x4001ce3200?}, 0x4000dc2fd0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3679
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3881 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e23828, 0x40035ae8c0}, 0x4001532e80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3766
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3892 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e23828, 0x4003507770}, 0x40014ef180)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3747
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3920 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40039e8e80, {0x3e23828, 0x4003998b40}, {0xffff694dd4d0, 0x4001ce3200}, {0x40034cbd40?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40039e2cc0, {0x3e23828, 0x4003998b40})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001fd1260, {0x3e23828, 0x4003998b40}, {0x3e5f080, 0x4001ce3200}, {0x8, {0x1, 0x1, 0xff}}, 0x40039cb8c0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3679
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3897 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x40037fdc00?, {0x3e23828, 0x400392e4b0}, {0x3e5f080?, 0x4001d79680?}, 0x4000d232e0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3737
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3885 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e23828, 0x40035076d0}, 0x4001533000)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3729
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3974 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003a4fe80, {0x3e23828, 0x400392e4b0}, {0xffff694dd4d0, 0x4001d79680}, {0x40037ffec0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003a56ea0, {0x3e23828, 0x400392e4b0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4002324e00, {0x3e23828, 0x400392e4b0}, {0x3e5f080, 0x4001d79680}, {0x2, {0x1, 0x1, 0xff}}, 0x4003a5c600)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3737
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3899 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x400358e498?, {0x3e23828, 0x400392e5a0}, {0x3e5f080?, 0x4001c13200?}, 0x4000d55d00)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3675
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3906 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3885
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3916 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40039e8580, {0x3e23828, 0x400392e5a0}, {0xffff694dd4d0, 0x4001c13200}, {0x40034cbb90?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x40039e2960, {0x3e23828, 0x400392e5a0})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001fd0e00, {0x3e23828, 0x400392e5a0}, {0x3e5f080, 0x4001c13200}, {0x3, {0x1, 0x1, 0xff}}, 0x40039cb380)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3675
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 3901 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3871
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3902 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003940000)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3871
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3921 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400392ef50, {0x400393e280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400392ef50, {0x400393e280?, 0x40037fe798?, 0x4002d66950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400393e240, {0x400393e280?, 0x4002d669d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400393e240}, {0x400393e280, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003936360, {0x400393e280, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400393e270, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400393e270, 0x4003936360, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003936360?, {0xffff69693090, 0x680cae0}, 0xffffb05f65b8?, {0x0?, 0x0?}, {0x368b2c0, 0x40005319d0}, 0x4002d66c68?, 0x47350?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x40039401a0, {0x368b2c0, 0x40005319d0}, 0x4000531f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002d66d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003936120, 0x4002d66e30, 0x4002d66e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003936120, {0x368b2c0?, 0x40005319d0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003815aa0, {0x368b2c0, 0x40005319d0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000b7c2c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003940000, {0x3e3faf0, 0x4000b7c2c0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3904 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3922 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x400233c420, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3923 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3829
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3924 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003940270)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3829
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3927 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x400392f130, {0x400393ea90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x400392f130, {0x400393ea90?, 0x40037fe900?, 0x4002dc3950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x400393ea50, {0x400393ea90?, 0x4002dc39d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x400393ea50}, {0x400393ea90, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003936c60, {0x400393ea90, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x400393ea80, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x400393ea80, 0x4003936c60, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003936c60?, {0xffff69693090, 0x680cae0}, 0x35dd8a0?, {0x0?, 0x0?}, {0x368b2c0, 0x4000531d50}, 0x30?, 0x3314d60?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003940410, {0x368b2c0, 0x4000531d50}, 0x4000531f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002dc3d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003936a20, 0x4002dc3e30, 0x4002dc3e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003936a20, {0x368b2c0?, 0x4000531d50?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003815d28, {0x368b2c0, 0x4000531d50})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000b7c840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003940270, {0x3e3faf0, 0x4000b7c840})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3926 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3928 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x400233c4d0, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3929 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x40038e3180}, 0x4003991320, 0x4000b7ccd0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40038e3180})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3875
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3930 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40034d0580, {0x3e23828, 0x40038e3180}, {0xffff694dd4d0, 0x4001b26ea0}, {0x4001ba03a0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400357dec0, {0x3e23828, 0x40038e3180}, {0xffff694dd4d0, 0x4001b26ea0}, {0x4000cbc028, 0x1, 0x206bc?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40038e3180})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3875
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3931 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e23828, 0x40038e3180}, 0x4001549780)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3930
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3934 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000506150, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4001cadcb8}, 0x40038ff860)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3929
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 3935 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e236d0, 0x680cae0}, 0x4001549880)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3934
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3938 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40034d0480, {0x3e23828, 0x40038e3180}, {0xffff694dd4d0, 0x4001b26ea0}, {0x4001ba0600?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40038e3180})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3875
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3939 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40034d0500, {0x3e23828, 0x40038e3180}, {0xffff694dd4d0, 0x4001b26ea0}, {0x4001ba04e0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40038e3180})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3875
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3940 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e23828, 0x40038e3180}, 0x4001549bc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3939
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3943 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001b26ea0, {0x3e23828, 0x40038e3180}, 0x4001549e00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3938
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3946 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x400233c580, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3947 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3892
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3948 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40039408f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3892
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3951 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40039701e0, {0x4003968f70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40039701e0, {0x4003968f70?, 0x40037fed50?, 0x4003474950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003968f30, {0x4003968f70?, 0x40034749d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003968f30}, {0x4003968f70, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x400396cd80, {0x4003968f70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003968f60, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003968f60, 0x400396cd80, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x400396cd80?, {0xffff69693090, 0x680cae0}, 0x35dd8a0?, {0x0?, 0x0?}, {0x368b2c0, 0x400547ac40}, 0x30?, 0x3314d60?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003940a90, {0x368b2c0, 0x400547ac40}, 0x400547bf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003474d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x400396cb40, 0x4003474e30, 0x4003474e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x400396cb40, {0x368b2c0?, 0x400547ac40?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003954810, {0x368b2c0, 0x400547ac40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000b7da30)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40039408f0, {0x3e3faf0, 0x4000b7da30})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3907 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x40039895f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3885
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3953 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003999810, {0x40039d4f70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003999810, {0x40039d4f70?, 0x40034cb950?, 0x4003ef6950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039d4f30, {0x40039d4f70?, 0x4003ef69d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039d4f30}, {0x40039d4f70, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40039c17a0, {0x40039d4f70, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039d4f60, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039d4f60, 0x40039c17a0, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40039c17a0?, {0xffff69693090, 0x680cae0}, 0x0?, {0x0?, 0x0?}, {0x368b2c0, 0x400547a770}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003989790, {0x368b2c0, 0x400547a770}, 0x400547bf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003ef6d98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40039c1560, 0x4003ef6e30, 0x4003ef6e78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40039c1560, {0x368b2c0?, 0x400547a770?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40038e5ba8, {0x368b2c0, 0x400547a770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000bf65f0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x40039895f0, {0x3e3faf0, 0x4000bf65f0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3950 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3952 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x400233c630, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3909 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3910 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 3881
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3911 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003989860)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 3881
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3954 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x400233c9a0, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3914 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40039999f0, {0x40039d5690, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40039999f0, {0x40039d5690?, 0x40034cba88?, 0x4002dbe950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x40039d5650, {0x40039d5690?, 0x4002dbe9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x40039d5650}, {0x40039d5690, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x40039e4120, {0x40039d5690, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x40039d5680, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x40039d5680, 0x40039e4120, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x40039e4120?, {0xffff69693090, 0x680cae0}, 0x6d72657473756c63?, {0x0?, 0x0?}, {0x368b2c0, 0x400547a9a0}, 0x2273656c75646f?, 0x74780c0a274a0032?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003989a00, {0x368b2c0, 0x400547a9a0}, 0x400547bf80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002dbed98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x40039c1e60, 0x4002dbee30, 0x4002dbee78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x40039c1e60, {0x368b2c0?, 0x400547a9a0?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40038e5dd0, {0x368b2c0, 0x400547a9a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000bf6b90)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003989860, {0x3e3faf0, 0x4000bf6b90})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 3913 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3915 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x40033d5600, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3955 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x400233ca50, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3956 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x400233cb00, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4038 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 3959 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x400233cbb0, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3960 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039885b0, 0x400233cc60, 0x40038fe840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3857
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 3975 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e23828, 0x400392e4b0}, 0x400160c640)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3974
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4035 [select, 8 minutes]:
context.(*cancelCtx).propagateCancel.func2()
	/usr/local/go/src/context/context.go:510 +0x88
created by context.(*cancelCtx).propagateCancel in goroutine 4002
	/usr/local/go/src/context/context.go:509 +0x4b4

goroutine 3980 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e23828, 0x4003829950}, 0x400160c980)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3979
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3978 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x4003829950}, 0x40039fb920, 0x4000cf66c0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003829950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3988
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4041 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x400392e5a0}, 0x40039fa240, 0x4000d04550)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400392e5a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4040 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x400233cd10, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4039 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x4003a590e0, {0x4003a61600, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003a590e0, {0x4003a61600?, 0x4003a642a0?, 0x4002a9f950?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003a615c0, {0x4003a61600?, 0x4002a9f9d8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003a615c0}, {0x4003a61600, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003a63b00, {0x4003a61600, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003a615f0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003a615f0, 0x4003a63b00, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003a63b00?, {0xffff69693090, 0x680cae0}, 0x636940003ce8c0?, {0x0?, 0x0?}, {0x368b2c0, 0x4000531b20}, 0x0?, 0x0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003a42ea0, {0x368b2c0, 0x4000531b20}, 0x4000531f80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4002a9fd98?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003a638c0, 0x4002a9fe30, 0x4002a9fe78)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003a638c0, {0x368b2c0?, 0x4000531b20?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x4003a3d350, {0x368b2c0, 0x4000531b20})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*watchWatchClient).Recv(0x4000d041a0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6714 +0x58
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveWatchClient(0x4003a42d00, {0x3e3faf0, 0x4000d041a0})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:766 +0x48
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).newWatchClient in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:921 +0x4c8

goroutine 4036 [select]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).run(0x4003a42d00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:545 +0x240
created by go.etcd.io/etcd/client/v3.(*watcher).newWatcherGrpcStream in goroutine 4002
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:292 +0x2a8

goroutine 3984 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e23828, 0x40039fd770}, 0x400160d540)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3979 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a1200, {0x3e23828, 0x4003829950}, {0xffff694dd4d0, 0x4002172900}, {0x4001ba1640?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400357ca20, {0x3e23828, 0x4003829950}, {0xffff694dd4d0, 0x4002172900}, {0x4000cbc690, 0x1, 0x4003a1b180?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003829950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3988
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 3917 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e23828, 0x400392e5a0}, 0x40016d7240)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3985 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e23828, 0x4003998b40}, 0x40016d7640)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3989 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e23828, 0x4003829950}, 0x40016d79c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3988
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3993 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e23828, 0x4003828fa0}, 0x40016d7d00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3992
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 3996 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*lessor).keepAliveCtxCloser(0x4001f0b220, {0x3e23828, 0x40039fd090}, 0x766e92bdd26fb3ab, 0x4003ac8840)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:332 +0x88
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive in goroutine 3761
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:298 +0x54c

goroutine 3997 [select]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).readClient(0x40039fd630, {0x4003acb0f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:193 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x40039fd630, {0x4003acb0f0?, 0x4003ace2e8?, 0x4003ad5930?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:173 +0x140
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4003acb0b0, {0x4003acb0f0?, 0x4003ad59b8?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4003acb0b0}, {0x4003acb0f0, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4003ad8c60, {0x4003acb0f0, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4003acb0e0, 0x7fffffff)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4003acb0e0, 0x4003ad8c60, {0x0, 0x0}, 0x7fffffff, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4003ad8c60?, {0xffff69693090, 0x680cae0}, 0x18770?, {0x0?, 0x0?}, {0x3612420, 0x4000f2cd80}, 0x10?, 0x10?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*csAttempt).recvMsg(0x4003ac64e0, {0x3612420, 0x4000f2cd80}, 0x4000f2df80?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1086 +0x208
google.golang.org/grpc.(*clientStream).RecvMsg.func1(0x4003ad5d78?)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:929 +0x28
google.golang.org/grpc.(*clientStream).withRetry(0x4003ad8a20, 0x4003ad5e10, 0x4003ad5e58)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:762 +0x4e8
google.golang.org/grpc.(*clientStream).RecvMsg(0x4003ad8a20, {0x3612420?, 0x4000f2cd80?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:928 +0xbc
github.com/cilium/cilium/pkg/clustermesh/common.(*wrappedClientStream).RecvMsg(0x40039e6ac8, {0x3612420, 0x4000f2cd80})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/interceptor.go:56 +0x38
go.etcd.io/etcd/api/v3/etcdserverpb.(*leaseLeaseKeepAliveClient).Recv(0x4000cf6260)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/api/v3/etcdserverpb/rpc.pb.go:6853 +0x58
go.etcd.io/etcd/client/v3.(*lessor).recvKeepAliveLoop(0x4001f0b220)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:458 +0x20c
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3761
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:301 +0x60

goroutine 3998 [select]:
go.etcd.io/etcd/client/v3.(*lessor).deadlineLoop(0x4001f0b220)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:550 +0x68
created by go.etcd.io/etcd/client/v3.(*lessor).KeepAlive.func1 in goroutine 3761
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:302 +0xa0

goroutine 3999 [chan receive]:
go.etcd.io/etcd/client/v3/concurrency.NewSession.func1()
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:66 +0x68
created by go.etcd.io/etcd/client/v3/concurrency.NewSession in goroutine 3761
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/concurrency/session.go:64 +0x23c

goroutine 4000 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).waitForExpiration(0x4003255780, 0x4003acaa50)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:269 +0x6c
created by github.com/cilium/cilium/pkg/kvstore.(*etcdLeaseManager).newSession in goroutine 3761
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd_lease.go:255 +0x22c

goroutine 4002 [select]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e23828, 0x4003507bd0}, 0x400162e080)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 3762
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4005 [select, 8 minutes]:
google.golang.org/grpc.newClientStreamWithParams.func4()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:392 +0x8c
created by google.golang.org/grpc.newClientStreamWithParams in goroutine 3997
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:391 +0xb2c

goroutine 4006 [select]:
go.etcd.io/etcd/client/v3.(*lessor).sendKeepAliveLoop(0x4001f0b220, {0x3e3fa98, 0x4000cf6260})
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:590 +0x1d4
created by go.etcd.io/etcd/client/v3.(*lessor).resetRecv in goroutine 3997
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/lease.go:500 +0x278

goroutine 4007 [select, 8 minutes]:
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).watchdog(0x4003ac87e0?, {0x3e23828, 0x40039fd770}, {0x3e5f080?, 0x4001d78b40?}, 0x4000df8ae0)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:243 +0xc4
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.1()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:176 +0x40
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3719
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:175 +0x5fc

goroutine 3983 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003a5ef00, {0x3e23828, 0x40039fd770}, {0xffff694dd4d0, 0x4001d78b40}, {0x4003a640c0?, 0x14?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/kvstore/store.(*wsmSync).Run(0x4003a57320, {0x3e23828, 0x40039fd770})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:117 +0x110
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run(0x4001fd1c00, {0x3e23828, 0x40039fd770}, {0x3e5f080, 0x4001d78b40}, {0x6, {0x1, 0x1, 0xff}}, 0x4003a5cd20)
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:131 +0x4bc
github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1.2()
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:206 +0x5c
created by github.com/cilium/cilium/pkg/clustermesh/common.(*remoteCluster).restartRemoteConnection.func1 in goroutine 3719
	/go/src/github.com/cilium/cilium/pkg/clustermesh/common/remote_cluster.go:205 +0x8b8

goroutine 4010 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a1100, {0x3e23828, 0x4003829950}, {0xffff694dd4d0, 0x4002172900}, {0x4001cdc3c0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003829950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3988
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4011 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a1180, {0x3e23828, 0x4003829950}, {0xffff694dd4d0, 0x4002172900}, {0x4001cdc340?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003829950})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3988
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4012 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x40033d56b0, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4013 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000555b90, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003ac40b8}, 0x40039cbec0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 3978
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4014 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e236d0, 0x680cae0}, 0x400162ecc0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4013
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4017 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e23828, 0x4003829950}, 0x400162ee00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4011
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4020 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4002172900, {0x3e23828, 0x4003829950}, 0x400162ef00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4010
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4023 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x4003828fa0}, 0x4003aca300, 0x4000cf7410)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003828fa0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3992
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4024 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221f00, {0x3e23828, 0x4003828fa0}, {0xffff694dd4d0, 0x4001c137a0}, {0x4001cdc620?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400346f4a0, {0x3e23828, 0x4003828fa0}, {0xffff694dd4d0, 0x4001c137a0}, {0x400190d230, 0x1, 0x4001fd1dc0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003828fa0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3992
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4042 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221a80, {0x3e23828, 0x400392e5a0}, {0xffff694dd4d0, 0x4001c13200}, {0x4001ba1900?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400346f2c0, {0x3e23828, 0x400392e5a0}, {0xffff694dd4d0, 0x4001c13200}, {0x4000cbc758, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400392e5a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4025 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e23828, 0x4003828fa0}, 0x400162f840)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4024
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4028 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x4003998b40}, 0x40039fae10, 0x4000cf7500)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x4003998b40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4029 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0400, {0x3e23828, 0x4003998b40}, {0xffff694dd4d0, 0x4001ce3200}, {0x4001cdc780?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400346f680, {0x3e23828, 0x4003998b40}, {0xffff694dd4d0, 0x4001ce3200}, {0x400190d270, 0x1, 0x0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x4003998b40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4030 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221e00, {0x3e23828, 0x4003828fa0}, {0xffff694dd4d0, 0x4001c137a0}, {0x4001cdc940?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003828fa0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3992
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4031 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221e80, {0x3e23828, 0x4003828fa0}, {0xffff694dd4d0, 0x4001c137a0}, {0x4001cdc820?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003828fa0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3992
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4043 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e23828, 0x400392e5a0}, 0x400160dac0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4042
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4046 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x4000554af0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40039af5b8}, 0x40039cb440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4041
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4032 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40005553b0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x40039afcb8}, 0x40039cb980)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4028
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4049 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e236d0, 0x680cae0}, 0x400162fd80)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4032
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4052 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0300, {0x3e23828, 0x4003998b40}, {0xffff694dd4d0, 0x4001ce3200}, {0x4001cdc9c0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x4003998b40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4053 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0380, {0x3e23828, 0x4003998b40}, {0xffff694dd4d0, 0x4001ce3200}, {0x4001cdc8c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x4003998b40})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3920
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4047 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e236d0, 0x680cae0}, 0x400160dc00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4046
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4054 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x40033d5760, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4066 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221980, {0x3e23828, 0x400392e5a0}, {0xffff694dd4d0, 0x4001c13200}, {0x4001ba1b60?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400392e5a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4055 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e23828, 0x4003998b40}, 0x40010ba3c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4052
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4067 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x4003221a00, {0x3e23828, 0x400392e5a0}, {0xffff694dd4d0, 0x4001c13200}, {0x4001ba1a40?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400392e5a0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3916
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4058 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x40033d5810, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4059 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e23828, 0x4003998b40}, 0x40010ba5c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4053
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4068 [select, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e23828, 0x400392e5a0}, 0x400160df00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4067
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4071 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c13200, {0x3e23828, 0x400392e5a0}, 0x4000f841c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4066
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4074 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e23828, 0x4003828fa0}, 0x4000f84300)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4031
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4062 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001ce3200, {0x3e23828, 0x4003998b40}, 0x40010ba700)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4029
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4081 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40005644d0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003ac4438}, 0x4003ac8420)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4023
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4082 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e236d0, 0x680cae0}, 0x40010ba800)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4081
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4085 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x40033d58c0, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4086 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001c137a0, {0x3e23828, 0x4003828fa0}, 0x40010baa00)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4030
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4077 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x400233cdc0, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4078 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x400392e4b0}, 0x4003a47890, 0x4000d053e0)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x400392e4b0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3974
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4089 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x40033d5970, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4090 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x40033d5a20, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4079 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40034d0080, {0x3e23828, 0x400392e4b0}, {0xffff694dd4d0, 0x4001d79680}, {0x4001ba1f80?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400357dce0, {0x3e23828, 0x400392e4b0}, {0xffff694dd4d0, 0x4001d79680}, {0x4000cbc8b8, 0x1, 0x4003a6e8c0?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x400392e4b0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3974
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4080 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e23828, 0x400392e4b0}, 0x4000f85040)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4079
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4099 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x400055f570, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003a1b3f8}, 0x4003a5c6c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4078
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4100 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e236d0, 0x680cae0}, 0x4000f85140)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4099
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4103 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a1f00, {0x3e23828, 0x400392e4b0}, {0xffff694dd4d0, 0x4001d79680}, {0x4001d521e0?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x400392e4b0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3974
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4104 [chan receive, 8 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40034d0000, {0x3e23828, 0x400392e4b0}, {0xffff694dd4d0, 0x4001d79680}, {0x4001d520c0?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x400392e4b0})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3974
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4105 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e23828, 0x400392e4b0}, 0x4000f85440)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4104
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4108 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d79680, {0x3e23828, 0x400392e4b0}, 0x4000f85640)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4103
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4111 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x400233ce70, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4112 [select, 8 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x400233cf20, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4091 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940000, 0x40033d5ad0, 0x40039259e0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3902
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4092 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x40033d5b80, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4093 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x40033d5c30, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4094 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x40033d5ce0, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4095 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x40033d5d90, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4096 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x40033d5e40, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4113 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039408f0, 0x40028bc160, 0x4003949500)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3948
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4114 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x40028bc210, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4115 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x40028bc2c0, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4116 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x40028bc420, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4117 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003989860, 0x40028bc4d0, 0x40039caf00)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3911
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4118 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x40028bc580, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4119 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x40028bc630, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4129 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003940270, 0x400233cfd0, 0x4003925f80)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3924
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4120 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x40028bc6e0, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4130 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/allocator.(*Allocator).WatchRemoteKVStore(0x4002e2e700, {0x3e23828, 0x40039fd770}, 0x4003a60b70, 0x4000f03290)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1019 +0x38c
github.com/cilium/cilium/pkg/allocator.(*RemoteCache).Watch(...)
	/go/src/github.com/cilium/cilium/pkg/allocator/allocator.go:1041
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func5({0x3e23828, 0x40039fd770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:127 +0x88
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4131 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0d80, {0x3e23828, 0x40039fd770}, {0xffff694dd4d0, 0x4001d78b40}, {0x4001d525a0?, 0x19?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/ipcache.(*IPIdentityWatcher).Watch(0x400357c7e0, {0x3e23828, 0x40039fd770}, {0xffff694dd4d0, 0x4001d78b40}, {0x4000cbca88, 0x1, 0x4003a6f340?})
	/go/src/github.com/cilium/cilium/pkg/ipcache/kvstore.go:258 +0x270
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func4({0x3e23828, 0x40039fd770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:123 +0x94
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4121 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x40039895f0, 0x40028bc790, 0x40039ca9c0)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 3907
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4132 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e23828, 0x40039fd770}, 0x4000fb9300)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4131
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4135 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x400233d080, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 5010 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696014d0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004372a80?, 0x40042ed000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004372a80, {0x40042ed000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004372a80, {0x40042ed000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000819470, {0x40042ed000?, 0x13?, 0x40035f6d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003bef560, {0x40042ed000?, 0x4002834d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40042ea6c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40042ea6c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003bef560)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4997
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4122 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0c80, {0x3e23828, 0x40039fd770}, {0xffff694dd4d0, 0x4001d78b40}, {0x4001cddc80?, 0x1c?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func2({0x3e23828, 0x40039fd770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:115 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4123 [chan receive, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/store.(*restartableWatchStore).Watch(0x40032a0d00, {0x3e23828, 0x40039fd770}, {0xffff694dd4d0, 0x4001d78b40}, {0x4001cddb40?, 0x1f?})
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstore.go:156 +0x3d8
github.com/cilium/cilium/pkg/clustermesh.(*remoteCluster).Run.func3({0x3e23828, 0x40039fd770})
	/go/src/github.com/cilium/cilium/pkg/clustermesh/remote_cluster.go:119 +0xec
github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready.func1()
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:67 +0x80
created by github.com/cilium/cilium/pkg/kvstore/store.(*wsmCommon).ready in goroutine 3983
	/go/src/github.com/cilium/cilium/pkg/kvstore/store/watchstoremgr.go:65 +0x1f0

goroutine 4124 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e23828, 0x40039fd770}, 0x40016692c0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4123
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4127 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore/allocator.(*kvstoreBackend).ListAndWatch(0x40005723f0, {0x3e236d0?, 0x680cae0?}, {0x3e148d0, 0x4003a1b5b8}, 0x4003a5cde0)
	/go/src/github.com/cilium/cilium/pkg/kvstore/allocator/allocator.go:561 +0xc8
github.com/cilium/cilium/pkg/allocator.(*cache).start.func1()
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:248 +0x50
created by github.com/cilium/cilium/pkg/allocator.(*cache).start in goroutine 4130
	/go/src/github.com/cilium/cilium/pkg/allocator/cache.go:247 +0x118

goroutine 4128 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e236d0, 0x680cae0}, 0x4001669400)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4127
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4147 [select, 6 minutes]:
github.com/cilium/cilium/pkg/kvstore.(*etcdClient).watch(0x4001d78b40, {0x3e23828, 0x40039fd770}, 0x4001669600)
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:897 +0xc80
created by github.com/cilium/cilium/pkg/kvstore.(*etcdClient).ListAndWatch in goroutine 4122
	/go/src/github.com/cilium/cilium/pkg/kvstore/etcd.go:1557 +0x12c

goroutine 4150 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x40028bc840, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4151 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x40028bc8f0, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4152 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x40028bc9a0, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 4153 [select, 6 minutes]:
go.etcd.io/etcd/client/v3.(*watchGrpcStream).serveSubstream(0x4003a42d00, 0x40028bca50, 0x4003a5d380)
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:812 +0x198
created by go.etcd.io/etcd/client/v3.(*watchGrpcStream).run in goroutine 4036
	/go/src/github.com/cilium/cilium/vendor/go.etcd.io/etcd/client/v3/watch.go:562 +0x984

goroutine 5002 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696011e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3780?, 0x40043ff000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3780, {0x40043ff000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3780, {0x40043ff000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c268, {0x40043ff000?, 0xe?, 0x4003cfbd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f6000, {0x40043ff000?, 0x40035f6d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f67e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f67e0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f6000)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5018
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5005 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f6360)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5019
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5007 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f66c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5021
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5040 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff694eff30, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004491b80?, 0x4004528000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004491b80, {0x4004528000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004491b80, {0x4004528000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40019c4390, {0x4004528000?, 0x72?, 0x40044efef8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40044efef0, {0x4004528000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4004522420)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4004522420, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x400451f5f0, {0x3e237f0, 0x40017f6930})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1730
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4996 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003bef200)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4993
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4639 [IO wait]:
internal/poll.runtime_pollWait(0xffff696019a8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003429700?, 0x40035cb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003429700, {0x40035cb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003429700, {0x40035cb000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40015b61e0, {0x40035cb000?, 0x72?, 0x4001f015f8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4001f015f0, {0x40035cb000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40034b93e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40034b93e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4002b90000, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4754 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40034eef00, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x40039e2780}, 0x4000dc3a20, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4928 [IO wait]:
internal/poll.runtime_pollWait(0xffff696018b0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004102b00?, 0x40019ad000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004102b00, {0x40019ad000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004102b00, {0x40019ad000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000818a88, {0x40019ad000?, 0x72?, 0x400411c548?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x400411c540, {0x40019ad000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4003b08ba0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4003b08ba0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4004122090, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4828 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40039dc280, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003b52480}, 0x4001030710, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4834
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5014 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696013d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3680?, 0x40042f1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3680, {0x40042f1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3680, {0x40042f1000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008194d0, {0x40042f1000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003d4a900, {0x40042f1000?, 0x4003f69d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40042ea960)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40042ea960, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003d4a900)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5012
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4718 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40035ab2c0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000d547d0, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4743
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4774 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003a52280, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4003a27500}, 0x40004ae690, 0x0, 0x4003ca9140, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4712
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4836 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40036137c0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x400388aff0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4757
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5026 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f6a20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5023
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4738 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4002408be0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4733
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 11579 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5011 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003bef560)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4997
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4742 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x40038268c0, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x40034ff680}, 0x400047bf10, 0x0, 0x4001895320, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4733
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4999 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696012e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3700?, 0x40043fb000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3700, {0x40043fb000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3700, {0x40043fb000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c258, {0x40043fb000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003d4ac60, {0x40043fb000?, 0x4004031d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f66c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f66c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003d4ac60)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5016
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 7572 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40013d79d0, 0xf)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40013d79c0)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0x400163f650)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:159 +0x134
created by github.com/cilium/cilium/pkg/policy.(*SelectorCache).queueUserNotification.func1 in goroutine 820
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:176 +0x60

goroutine 4960 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003d3bc20)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4991
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4772 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002f32780})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003a52140, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000d55db0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4712
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4989 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69601b98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004372980?, 0x40042df000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004372980, {0x40042df000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004372980, {0x40042df000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008193d8, {0x40042df000?, 0xf?, 0x40035f6d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003beeea0, {0x40042df000?, 0x4001dcdd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40042ea300)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40042ea300, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003beeea0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4957
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4785 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003c54140, {{{0x379eff9, 0xe}}, {0x3e2b960, 0x4003b00120}, 0x4000d233c0, 0x0, 0x39b9348, 0xd18c2e2800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5000 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003d4ac60)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5016
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4995 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696015c8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004372a00?, 0x40043f9000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004372a00, {0x40043f9000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004372a00, {0x40043f9000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c228, {0x40043f9000?, 0x13?, 0x40035f6d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003bef200, {0x40043f9000?, 0x4001dc4d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f6420)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f6420, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003bef200)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4993
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5042 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694f08e0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004372b00?, 0x4004409000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004372b00, {0x4004409000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004372b00, {0x4004409000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c2d0, {0x4004409000?, 0x12?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003bef8c0, {0x4004409000?, 0x4003cf7d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f6d80)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f6d80, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003bef8c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5008
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5468 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69601c90, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001f61380?, 0x40044ec000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001f61380, {0x40044ec000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001f61380, {0x40044ec000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40016dea30, {0x40044ec000?, 0x72?, 0x4000808098?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4000808090, {0x40044ec000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40044df140)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40044df140, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4000b34900, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4956 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003d3b560)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4968
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5038 [IO wait, 6 minutes]:
internal/poll.runtime_pollWait(0xffff694f0500, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004491900?, 0x4004526000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004491900, {0x4004526000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004491900, {0x4004526000?, 0x1?, 0x4003c97c00?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40019c4368, {0x4004526000?, 0xc?, 0x4002743d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f7d40, {0x4004526000?, 0x18550?, 0x4004524180?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40045222a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40045222a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f7d40)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5037
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4743 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003826b40, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002c55b80, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4733
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5003 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f6000)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5018
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4852 [IO wait]:
internal/poll.runtime_pollWait(0xffff696017b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4004102180?, 0x4002bdf000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4004102180, {0x4002bdf000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4004102180, {0x4002bdf000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000818938, {0x4002bdf000?, 0x72?, 0x4003a7b748?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003a7b740, {0x4002bdf000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40036f41e0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40036f41e0, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003c92fc0, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 4773 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4000407001?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4001e8d170?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4712
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4815 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x4001f0a780)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4757
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 4781 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003a52dc0, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000d22210, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4775
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4834 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x4001dc2fa8?, 0x258f874?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4002321740?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4757
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4775 [select, 6 minutes]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003a523c0, {{{0x379f007, 0xe}}, {0x0, 0x0}, 0x4002f328c0, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4712
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4824 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003967b80, {{{0x37a86e6, 0x10}}, {0x0, 0x0}, 0x4000d05450, 0x0, 0x39b9348, 0x45d964b800, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4836
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 5015 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003d4a900)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5012
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 12136 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 4770 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0x40034d94a0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:209 +0x2f4
created by github.com/cilium/cilium/pkg/trigger.NewTrigger in goroutine 4712
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:122 +0x1b4

goroutine 5043 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003bef8c0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5008
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 4835 [select]:
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003613680, {{{0x37d3b0d, 0x1a}}, {0x3e2b960, 0x4003a38780}, 0x4000513e30, 0x0, 0x4003a350e0, 0x2540be400, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:322 +0x79c
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4757
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4741 [chan receive, 1 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:234 +0x6c
sync.(*Once).doSlow(0x0?, 0x8a6d4?)
	/usr/local/go/src/sync/once.go:74 +0x100
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:65
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x4000acc8c0?)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:232 +0x48
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run in goroutine 4733
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:228 +0x78

goroutine 4740 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x4002c55a40})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003826640, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000b44b90, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4733
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 4833 [select, 6 minutes]:
github.com/cilium/cilium/pkg/endpoint.(*Endpoint).startRegenerationFailureHandler.func1({0x3e23828, 0x400388aeb0})
	/go/src/github.com/cilium/cilium/pkg/endpoint/policy.go:735 +0x70
github.com/cilium/cilium/pkg/controller.(*controller).runController(0x4003613540, {{{0x37e7901, 0x1e}}, {0x0, 0x0}, 0x4000cf7b60, 0x0, 0x39b9348, 0x0, 0x0, ...})
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:254 +0x108
created by github.com/cilium/cilium/pkg/controller.(*Manager).createControllerLocked in goroutine 4757
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0x3d0

goroutine 10605 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11332 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 7941 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400006ac48, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400006ac38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400006ac30, {0x4003738c01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4005a87cc8?}, {0x4003738c01?, 0x4005a87cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40032c5400)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40032c5400)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40032c5400, {0x30150e0, 0x40040faa50})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4000f1f9e0, {0x4004f67400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40021857c0, 0x0, {0x3e02238, 0x4004496f40})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40010b8280)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4005820100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 807
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11036 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11353 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5851 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400465af48, 0x4)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400465af38)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400465af30, {0x400488b201, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4005a83cc8?}, {0x400488b201?, 0x4005a83cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4002e82140)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4002e82140)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4002e82140, {0x30150e0, 0x4003b54708})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4005319d70, {0x4005080800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40042ab4f0, 0x0, {0x3e02238, 0x4004543200})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a1ccc0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400533aac0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 678
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5004 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696010f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3800?, 0x4004401000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3800, {0x4004401000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3800, {0x4004401000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c278, {0x4004401000?, 0xf?, 0x4004037d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f6360, {0x4004401000?, 0x4001dced18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f6900)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f6900, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f6360)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5019
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5045 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f6d80)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5027
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5006 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694f0ad0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3880?, 0x4004405000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3880, {0x4004405000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3880, {0x4004405000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c288, {0x4004405000?, 0x13?, 0x4001dcfd00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f66c0, {0x4004405000?, 0x4002307d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f6a20)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f6a20, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f66c0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5021
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5030 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694f06f0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3a00?, 0x40042ff000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3a00, {0x40042ff000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3a00, {0x40042ff000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40008196b8, {0x40042ff000?, 0xf?, 0x4001dc0d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f70e0, {0x40042ff000?, 0x4004032d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40042eb860)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40042eb860, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f70e0)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5029
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 5025 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694f09d8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3900?, 0x40042f3000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3900, {0x40042f3000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3900, {0x40042f3000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x4000819660, {0x40042f3000?, 0xe?, 0x4001dc0d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f6a20, {0x40042f3000?, 0x4004030d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40042eb4a0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40042eb4a0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f6a20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5023
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 8980 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400006b248, 0x57)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400006b238)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400006b230, {0x4004365001, 0xdff, 0xdff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40026f7cc8?}, {0x4004365001?, 0x40026f7cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40036008c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40036008c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40036008c0, {0x30150e0, 0x4000d25ce0})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4003c63050, {0x4002d0ea00, 0x1000, 0x1500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003c05450, 0x0, {0x3e02238, 0x400170e340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001b1f880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x400130bb80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1460
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5044 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694f07e8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3980?, 0x400440b000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3980, {0x400440b000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3980, {0x400440b000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c2d8, {0x400440b000?, 0x11?, 0x4001dc0d00?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x40042f6d80, {0x400440b000?, 0x4001dc3d18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f6e40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f6e40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x40042f6d80)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 5027
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4955 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69601d88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042b5a80?, 0x400437d000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042b5a80, {0x400437d000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042b5a80, {0x400437d000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c1b0, {0x400437d000?, 0x13?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003d3b560, {0x400437d000?, 0x4000b2cd18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x4004363d40)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4004363d40, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003d3b560)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4968
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 10244 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff694efe38, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003bd4080?, 0x40033fc000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0x4003bd4080, {0x40033fc000, 0x1000, 0x1000}, {0x0, 0x0, 0x0}, 0x40000000)
	/usr/local/go/src/internal/poll/fd_unix.go:301 +0x284
net.(*netFD).readMsg(0x4003bd4080, {0x40033fc000?, 0x4003e00420?, 0x4003e003f0?}, {0x0?, 0x4001433830?, 0x40058e1b88?}, 0x25809a0?)
	/usr/local/go/src/net/fd_posix.go:78 +0x30
net.(*UnixConn).readMsg(0x4001a2ef68, {0x40033fc000?, 0x40058e1be8?, 0x2577428?}, {0x0?, 0x4001ae7b30?, 0x40051c3680?})
	/usr/local/go/src/net/unixsock_posix.go:115 +0x38
net.(*UnixConn).ReadMsgUnix(0x4001a2ef68, {0x40033fc000?, 0x5?, 0x377a3b0?}, {0x0?, 0x1fd48?, 0x3788a53?})
	/usr/local/go/src/net/unixsock.go:143 +0x30
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn(0x4001ae7dd0, {0x3e23828, 0x400088de50}, 0x4001a2ef68)
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:132 +0x12c
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).start.func1 in goroutine 454
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:72 +0x138

goroutine 4959 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff696016c0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x40042e3600?, 0x40043f1000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x40042e3600, {0x40043f1000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x40042e3600, {0x40043f1000?, 0x40019b8700?, 0x3?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x400123c1e8, {0x40043f1000?, 0xe?, 0x0?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*persistConn).Read(0x4003d3bc20, {0x40043f1000?, 0x400224ad18?, 0x64800?})
	/usr/local/go/src/net/http/transport.go:1977 +0x50
bufio.(*Reader).fill(0x40043f60c0)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40043f60c0, 0x1)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*persistConn).readLoop(0x4003d3bc20)
	/usr/local/go/src/net/http/transport.go:2141 +0x158
created by net/http.(*Transport).dialConn in goroutine 4991
	/usr/local/go/src/net/http/transport.go:1799 +0x1018

goroutine 4990 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x4003beeea0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 4957
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5031 [select, 1 minutes]:
net/http.(*persistConn).writeLoop(0x40042f70e0)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5029
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 5039 [select, 6 minutes]:
net/http.(*persistConn).writeLoop(0x40042f7d40)
	/usr/local/go/src/net/http/transport.go:2458 +0xa0
created by net/http.(*Transport).dialConn in goroutine 5037
	/usr/local/go/src/net/http/transport.go:1800 +0x1060

goroutine 10754 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10245 [select, 2 minutes]:
github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:117 +0x68
created by github.com/cilium/cilium/pkg/envoy.(*AccessLogServer).handleConn in goroutine 10244
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:116 +0xb4

goroutine 11010 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400340a348, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400340a338)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400340a330, {0x4004412601, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40058dfcc8?}, {0x4004412601?, 0x40058dfcb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x4001e88640)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x4001e88640)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x4001e88640, {0x30150e0, 0x4001cdef30})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4001f9b620, {0x4003213800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003b0acd0, 0x0, {0x3e02238, 0x4005386840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40008ceec0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4001040100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1466
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 12126 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11621 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11005 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11614 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10407 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4834
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12138 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10201 [select, 1 minutes]:
reflect.rselect({0x4003a62360, 0x9, 0xffff697e3570?})
	/usr/local/go/src/runtime/select.go:589 +0x280
reflect.Select({0x4002ea0600?, 0x9, 0x37e99ef?})
	/usr/local/go/src/reflect/value.go:3169 +0x494
github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream(0x4000f1e840, {0x3e237f0, 0x4001d0e870}, 0x400041db90, {0xffff69453cb0, 0x4000d63f20}, 0x4003cb5020, {0x381b81a?, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:286 +0x784
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream(0x4000f1e840, {0x3e237f0, 0x4001d0e870}, {0xffff69453cb0, 0x4000d63f20}, {0x381b81a, 0x28})
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:179 +0x298
github.com/cilium/cilium/pkg/envoy.(*xdsGRPCServer).StreamNetworkPolicies(0x4000f1e840, {0x3e3e378, 0x4000d63f20})
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:144 +0x78
github.com/cilium/proxy/go/cilium/api._NetworkPolicyDiscoveryService_StreamNetworkPolicies_Handler({0x365dfc0?, 0x4000f1e840}, {0x3e32818, 0x40027b13b0})
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1711 +0xdc
google.golang.org/grpc.(*Server).processStreamingRPC(0x40017ee200, {0x3e237f0, 0x4001d0e780}, {0x3e42860, 0x4001779500}, 0x4001bc8b40, 0x4000f1ec30, 0x6217f00, 0x0)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1673 +0xe60
google.golang.org/grpc.(*Server).handleStream(0x40017ee200, {0x3e42860, 0x4001779500}, 0x4001bc8b40)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1794 +0xaec
google.golang.org/grpc.(*Server).serveStreams.func2.1()
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1029 +0x8c
created by google.golang.org/grpc.(*Server).serveStreams.func2 in goroutine 504
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:1040 +0x13c

goroutine 10202 [select, 1 minutes]:
google.golang.org/grpc/internal/transport.(*recvBufferReader).read(0x4003b4b220, {0x4001d0e820, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:181 +0x74
google.golang.org/grpc/internal/transport.(*recvBufferReader).Read(0x4003b4b220, {0x4001d0e820?, 0x40034dc678?, 0x4002d37510?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:175 +0x170
google.golang.org/grpc/internal/transport.(*transportReader).Read(0x4001d0e660, {0x4001d0e820?, 0x4002d37598?, 0x17b0a74?})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:525 +0x34
io.ReadAtLeast({0x3dde580, 0x4001d0e660}, {0x4001d0e820, 0x5, 0x5}, 0x5)
	/usr/local/go/src/io/io.go:335 +0xa0
io.ReadFull(...)
	/usr/local/go/src/io/io.go:354
google.golang.org/grpc/internal/transport.(*Stream).Read(0x4001bc8b40, {0x4001d0e820, 0x5, 0x5})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/internal/transport/transport.go:509 +0x94
google.golang.org/grpc.(*parser).recvMsg(0x4001d0e810, 0x400000)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:614 +0x48
google.golang.org/grpc.recvAndDecompress(0x4001d0e810, 0x4001bc8b40, {0x0, 0x0}, 0x400000, 0x0, {0x0, 0x0})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:753 +0x58
google.golang.org/grpc.recv(0x4002d377c8?, {0xffff69693090, 0x680cae0}, 0x98?, {0x0?, 0x0?}, {0x35bf9e0, 0x400396f220}, 0x4003c96a80?, 0x186f0?, ...)
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/rpc_util.go:833 +0x64
google.golang.org/grpc.(*serverStream).RecvMsg(0x40027b13b0, {0x35bf9e0, 0x400396f220})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/stream.go:1718 +0xf4
github.com/cilium/proxy/go/cilium/api.(*networkPolicyDiscoveryServiceStreamNetworkPoliciesServer).Recv(0x4000d63f20)
	/go/src/github.com/cilium/cilium/vendor/github.com/cilium/proxy/go/cilium/api/npds.pb.go:1730 +0x58
github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream.func1(0x3e31c48?)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:146 +0xac
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).HandleRequestStream in goroutine 10201
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:143 +0x270

goroutine 12140 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11356 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11357 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11577 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11578 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11006 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 5656 [IO wait]:
internal/poll.runtime_pollWait(0xffff694f0218, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x400396b580?, 0x4003f37000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x400396b580, {0x4003f37000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x400396b580, {0x4003f37000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40012365e0, {0x4003f37000?, 0x72?, 0x4003426548?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x4003426540, {0x4003f37000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40034b8900)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40034b8900, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4003872630, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 11543 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4004f96348, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004f96338)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004f96330, {0x40019dd801, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4005a85cc8?}, {0x40019dd801?, 0x4005a85cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x40034592c0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x40034592c0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x40034592c0, {0x30150e0, 0x4003edaf60})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x4005537f50, {0x4004bf2800, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4004f7d4a0, 0x0, {0x3e02238, 0x4004498500})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018985a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004f74c40)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 951
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11739 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x4004a66348, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004a66338)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004a66330, {0x40011967c4, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002be5cc8?}, {0x40011967c4?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x4004a66300}, {0x40011967c4, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4003a3c2b8, {0x40000e5400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002efca50, 0x0, {0x3e02238, 0x4001219740})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x40018b27a0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40051ffb80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 214
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 6007 [IO wait]:
internal/poll.runtime_pollWait(0xffff694f0120, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4003ea0600?, 0x40010b5000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4003ea0600, {0x40010b5000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4003ea0600, {0x40010b5000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40019db148, {0x40010b5000?, 0x72?, 0x40023ea5a8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40023ea5a0, {0x40010b5000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x40017f8900)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x40017f8900, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x40028410e0, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10777 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11034 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 6555 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x400465a7c8, 0x3)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400465a7b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400465a7b0, {0x400451a150, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x40052c8cc8?}, {0x400451a150?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x400465a780}, {0x400451a150, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x400036b920, {0x4004f67c00, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4003b0aaa0, 0x0, {0x3e02238, 0x40052d3480})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000806100)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004bf4580)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 1378
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 5466 [IO wait, 1 minutes]:
internal/poll.runtime_pollWait(0xffff69601aa0, 0x72)
	/usr/local/go/src/runtime/netpoll.go:345 +0xa0
internal/poll.(*pollDesc).wait(0x4001f60e80?, 0x4001817000?, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x28
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0x4001f60e80, {0x4001817000, 0x1000, 0x1000})
	/usr/local/go/src/internal/poll/fd_unix.go:164 +0x200
net.(*netFD).Read(0x4001f60e80, {0x4001817000?, 0x0?, 0x0?})
	/usr/local/go/src/net/fd_posix.go:55 +0x28
net.(*conn).Read(0x40016de9c8, {0x4001817000?, 0x72?, 0x40006170b8?})
	/usr/local/go/src/net/net.go:185 +0x34
net/http.(*connReader).Read(0x40006170b0, {0x4001817000, 0x1000, 0x1000})
	/usr/local/go/src/net/http/server.go:789 +0x224
bufio.(*Reader).fill(0x4001fbd500)
	/usr/local/go/src/bufio/bufio.go:110 +0xf8
bufio.(*Reader).Peek(0x4001fbd500, 0x4)
	/usr/local/go/src/bufio/bufio.go:148 +0x60
net/http.(*conn).serve(0x4000add9e0, {0x3e237f0, 0x4001fe0330})
	/usr/local/go/src/net/http/server.go:2079 +0x63c
created by net/http.(*Server).Serve in goroutine 1688
	/usr/local/go/src/net/http/server.go:3290 +0x3f0

goroutine 10755 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11035 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12122 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40018a0d90, 0x1b)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018a0d80)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40018a0d40, {0x3e23828, 0x4004482820}, {0x4002f05920, 0x28}, 0x12c, {0x400114a7a5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 10201
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 12119 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x40018a0e90, 0x10)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40018a0e80)
	/usr/local/go/src/sync/cond.go:70 +0xcc
github.com/cilium/cilium/pkg/envoy/xds.(*ResourceWatcher).WatchResources(0x40018a0e40, {0x3e23828, 0x40044827d0}, {0x400538e480, 0x35}, 0x11, {0x4001c9d9e5, 0x9}, {0x0, 0x0, ...}, ...)
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/watcher.go:127 +0x750
created by github.com/cilium/cilium/pkg/envoy/xds.(*Server).processRequestStream in goroutine 1796
	/go/src/github.com/cilium/cilium/pkg/envoy/xds/server.go:398 +0x1160

goroutine 10038 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x40037dd6c8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x40037dd6b8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x40037dd6b0, {0x400409ac01, 0x5ff, 0x5ff})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001db9cc8?}, {0x400409ac01?, 0x4001db9cb8?, 0x18770?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
encoding/json.(*Decoder).refill(0x400073bcc0)
	/usr/local/go/src/encoding/json/stream.go:165 +0x164
encoding/json.(*Decoder).readValue(0x400073bcc0)
	/usr/local/go/src/encoding/json/stream.go:140 +0x74
encoding/json.(*Decoder).Decode(0x400073bcc0, {0x30150e0, 0x400116fc20})
	/usr/local/go/src/encoding/json/stream.go:63 +0x5c
k8s.io/apimachinery/pkg/util/framer.(*jsonFrameReader).Read(0x400465c5d0, {0x4003212000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:152 +0x19c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002e1d630, 0x0, {0x3e02238, 0x4000fcce00})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001887880)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40014fa2c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 781
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 11354 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10740 [sync.Cond.Wait, 1 minutes]:
sync.runtime_notifyListWait(0x4004a66dc8, 0x1)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x4004a66db8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x4004a66db0, {0x4001c3b17c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4002e9ccc8?}, {0x4001c3b17c?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x4004a66d80}, {0x4001c3b17c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x40055c0648, {0x400522f400, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x40055bfae0, 0x0, {0x3e02238, 0x4000fc0cc0})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4000b5e6c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x40055bb7c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 756
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10756 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10575 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11008 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12139 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11037 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10779 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11355 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10778 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11613 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10373 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0x400340bcc8, 0x2)
	/usr/local/go/src/runtime/sema.go:569 +0x154
sync.(*Cond).Wait(0x400340bcb8)
	/usr/local/go/src/sync/cond.go:70 +0xcc
golang.org/x/net/http2.(*pipe).Read(0x400340bcb0, {0x40011bdba0, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0x108
golang.org/x/net/http2.transportResponseBody.Read({0x4001db6cc8?}, {0x40011bdba0?, 0x3014560?, 0x3233040?})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2641 +0x50
io.ReadAtLeast({0xffff69627c58, 0x400340bc80}, {0x40011bdba0, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:335 +0xa0
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0x4001341878, {0x4003b7f000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x8c
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0x4002c93a90, 0x0, {0x3e02238, 0x400459a140})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0x88
k8s.io/client-go/rest/watch.(*Decoder).Decode(0x4001a19220)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x5c
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0x4004fc6000)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0xb0
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher in goroutine 718
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x104

goroutine 10780 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11905 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11058 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10274 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4834
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12137 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10781 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10606 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10607 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10608 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10574 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10613 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10576 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 10593 [sleep, 2 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11334 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11059 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11333 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11615 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11887 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11885 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11907 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11888 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4773
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11908 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 11906 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12127 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12125 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12124 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4

goroutine 12123 [sleep, 1 minutes]:
time.Sleep(0x45d964b800)
	/usr/local/go/src/runtime/time.go:195 +0xfc
github.com/cilium/cilium/pkg/time.Sleep(...)
	/go/src/github.com/cilium/cilium/pkg/time/time.go:89
github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1.1()
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:876 +0x84
created by github.com/cilium/cilium/pkg/proxy.(*Proxy).removeRedirect.func1 in goroutine 4741
	/go/src/github.com/cilium/cilium/pkg/proxy/proxy.go:875 +0xe4
