35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:22+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:22+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:23+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-24T09:14:23+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-24T09:14:24+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-24T09:14:30+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
61: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
64: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
75: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-24T09:14:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:14:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
458: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
461: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
462: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 124
463: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 125
464: sched_cls  name tail_handle_ipv4  tag f2fdf1257e0558a2  gpl
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 67,66,73,68,93
	btf_id 126
465: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-24T09:15:28+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 68,93
	btf_id 127
466: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
469: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: sched_cls  name tail_ipv4_ct_ingress  tag e3a2f7d6adb1bb41  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 155
494: sched_cls  name handle_policy  tag 2985975ad0398130  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,101,74,75,102,33,72,83,31,76,67,32,29,30
	btf_id 156
495: sched_cls  name tail_handle_arp  tag ce3ffc14c01f96e6  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,101
	btf_id 157
496: sched_cls  name tail_handle_ipv4  tag 7470e0b2d9bd95d0  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,101
	btf_id 158
497: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,101
	btf_id 159
498: sched_cls  name tail_ipv4_ct_egress  tag b141afdf66212bf4  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,101,74,75,102,76
	btf_id 160
499: sched_cls  name __send_drop_notify  tag 8a8f31fe67844156  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 161
500: sched_cls  name cil_from_container  tag 643bb64e206aca04  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 101,68
	btf_id 162
501: sched_cls  name tail_ipv4_to_endpoint  tag a78b9b348dcca6be  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,102,33,74,75,72,83,31,101,32,29,30
	btf_id 163
502: sched_cls  name tail_handle_ipv4_cont  tag f57dd9815cfcde64  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,102,33,83,74,75,31,68,66,69,101,32,29,30,73
	btf_id 164
503: sched_cls  name __send_drop_notify  tag a431e7079b343ad6  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 166
504: sched_cls  name tail_ipv4_to_endpoint  tag d4b6e5e566dbbbed  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 67,68,103,33,74,75,72,95,31,104,32,29,30
	btf_id 167
505: sched_cls  name tail_handle_arp  tag a215c02d8470f191  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,104
	btf_id 168
507: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,104
	btf_id 170
508: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 171
509: sched_cls  name cil_from_container  tag cb9f94f91b5668de  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 104,68
	btf_id 172
510: sched_cls  name tail_ipv4_ct_ingress  tag 524fb4c1ec638683  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 68,104,74,75,103,76
	btf_id 173
511: sched_cls  name handle_policy  tag a8af0bec461b2c1c  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 68,104,74,75,103,33,72,95,31,76,67,32,29,30
	btf_id 174
512: sched_cls  name tail_handle_ipv4_cont  tag 656c3e956f8d96d8  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 67,103,33,95,74,75,31,68,66,69,104,32,29,30,73
	btf_id 175
513: sched_cls  name tail_handle_ipv4  tag b467ec07b68b5285  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,104
	btf_id 176
514: sched_cls  name tail_handle_ipv4_cont  tag e00164a98d22d727  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,106,33,94,74,75,31,68,66,69,105,32,29,30,73
	btf_id 178
515: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
516: sched_cls  name __send_drop_notify  tag efdefb3a8f349342  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 179
519: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
520: sched_cls  name handle_policy  tag fc54415df56f8df3  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,105,74,75,106,33,72,94,31,76,67,32,29,30
	btf_id 180
521: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,105
	btf_id 181
522: sched_cls  name tail_ipv4_ct_egress  tag b141afdf66212bf4  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 182
523: sched_cls  name tail_ipv4_ct_ingress  tag 1189d70ed612b47b  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,105,74,75,106,76
	btf_id 183
524: sched_cls  name cil_from_container  tag e27e0a6eac48a6e0  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 105,68
	btf_id 184
525: sched_cls  name tail_handle_arp  tag 3c6b2f1b732790f6  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,105
	btf_id 185
527: sched_cls  name tail_ipv4_to_endpoint  tag 7e3e2b91055e293a  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,106,33,74,75,72,94,31,105,32,29,30
	btf_id 187
528: sched_cls  name tail_handle_ipv4  tag 7703aa6c8f53e4b0  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,105
	btf_id 188
529: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
532: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:15:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
533: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 190
535: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 68,67,109
	btf_id 192
537: sched_cls  name tail_handle_ipv4_from_host  tag 6e7c4016eb517eb1  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,109
	btf_id 194
538: sched_cls  name __send_drop_notify  tag 90d52fe82bb97cc4  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 195
539: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,109
	btf_id 196
540: sched_cls  name __send_drop_notify  tag 90d52fe82bb97cc4  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 198
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,112
	btf_id 199
542: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 68
	btf_id 200
546: sched_cls  name tail_handle_ipv4_from_host  tag 6e7c4016eb517eb1  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,112
	btf_id 204
548: sched_cls  name tail_handle_ipv4_from_host  tag 6e7c4016eb517eb1  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 66,67,68,69,33,73,114
	btf_id 207
549: sched_cls  name __send_drop_notify  tag 90d52fe82bb97cc4  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 33
	btf_id 208
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 68,114
	btf_id 209
552: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-24T09:15:32+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 68,114,67
	btf_id 211
593: sched_cls  name tail_handle_ipv4_cont  tag 9ed70859a8f2afe1  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,127,33,125,74,75,31,68,66,69,126,32,29,30,73
	btf_id 227
594: sched_cls  name __send_drop_notify  tag 89ada47fc8107841  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 228
595: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,126
	btf_id 229
596: sched_cls  name tail_ipv4_ct_egress  tag d2c36fe7d035d115  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,126,74,75,127,76
	btf_id 230
597: sched_cls  name cil_from_container  tag f224d101e158c1db  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 126,68
	btf_id 231
599: sched_cls  name handle_policy  tag 451a1a678c86b6c3  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,126,74,75,127,33,72,125,31,76,67,32,29,30
	btf_id 233
600: sched_cls  name tail_ipv4_to_endpoint  tag c35e52e00b21a9a6  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,127,33,74,75,72,125,31,126,32,29,30
	btf_id 234
601: sched_cls  name tail_ipv4_ct_ingress  tag ba7d040b7d931868  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,126,74,75,127,76
	btf_id 235
602: sched_cls  name tail_handle_arp  tag 2ebd8a87ab7be81f  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,126
	btf_id 236
603: sched_cls  name tail_handle_ipv4  tag 52f22a997005eeef  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,126
	btf_id 237
604: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
607: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
624: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
627: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
628: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
631: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:18:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
673: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
676: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
677: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
680: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
681: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
684: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
685: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
688: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
689: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-24T09:20:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
692: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-24T09:20:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
3367: sched_cls  name tail_ipv4_to_endpoint  tag 443d302dc05ae565  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,637,33,74,75,72,143,31,638,32,29,30
	btf_id 3192
3368: sched_cls  name tail_handle_ipv4  tag 0eb0da2da1615d78  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,638
	btf_id 3193
3369: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,638
	btf_id 3194
3370: sched_cls  name tail_handle_ipv4_cont  tag c51a57ebedb8d350  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,637,33,143,74,75,31,68,66,69,638,32,29,30,73
	btf_id 3195
3371: sched_cls  name handle_policy  tag b40106151382f152  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,638,74,75,637,33,72,143,31,76,67,32,29,30
	btf_id 3196
3372: sched_cls  name tail_ipv4_ct_egress  tag f0bc80917339c9f2  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,638,74,75,637,76
	btf_id 3197
3373: sched_cls  name cil_from_container  tag bbc93950f2c6b00f  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 638,68
	btf_id 3198
3374: sched_cls  name tail_handle_arp  tag 98c34608a15e773b  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,638
	btf_id 3199
3375: sched_cls  name __send_drop_notify  tag 6702e164dc3a6ea1  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3200
3376: sched_cls  name tail_ipv4_ct_ingress  tag 4bf8f4e3bfd4b7d6  gpl
	loaded_at 2024-10-24T09:23:25+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,638,74,75,637,76
	btf_id 3201
3663: sched_cls  name tail_handle_ipv4  tag 37f4972af2505c67  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,691
	btf_id 3515
3664: sched_cls  name tail_handle_ipv4  tag 4d9385b02a76030b  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 76,68,70,74,75,71,31,693
	btf_id 3517
3665: sched_cls  name tail_ipv4_ct_ingress  tag 7f959a59d9b33c41  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,692,76
	btf_id 3518
3666: sched_cls  name __send_drop_notify  tag 1b9d1251e14f803a  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3520
3667: sched_cls  name tail_ipv4_to_endpoint  tag 5e0f5c1751526f50  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,694,33,74,75,72,135,31,693,32,29,30
	btf_id 3519
3668: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,693
	btf_id 3522
3669: sched_cls  name __send_drop_notify  tag 9db9a00a247c9c72  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 33
	btf_id 3523
3670: sched_cls  name tail_ipv4_to_endpoint  tag 50edff8fb56f0e37  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 67,68,692,33,74,75,72,138,31,691,32,29,30
	btf_id 3521
3671: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 68,691
	btf_id 3525
3672: sched_cls  name tail_ipv4_ct_ingress  tag eca08edbc9f8b9e7  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 68,693,74,75,694,76
	btf_id 3524
3673: sched_cls  name tail_handle_ipv4_cont  tag 5248303af76c44bd  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,692,33,138,74,75,31,68,66,69,691,32,29,30,73
	btf_id 3526
3674: sched_cls  name tail_ipv4_ct_egress  tag b8b5eee053cc2bcd  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,691,74,75,692,76
	btf_id 3527
3675: sched_cls  name cil_from_container  tag d487586c06e09647  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 691,68
	btf_id 3529
3677: sched_cls  name tail_handle_arp  tag ee1e063628797f81  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,691
	btf_id 3531
3678: sched_cls  name handle_policy  tag 1a3a7daef113216e  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,691,74,75,692,33,72,138,31,76,67,32,29,30
	btf_id 3532
3679: sched_cls  name handle_policy  tag ad3265e5b02e7cab  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 68,693,74,75,694,33,72,135,31,76,67,32,29,30
	btf_id 3528
3680: sched_cls  name tail_ipv4_ct_egress  tag a11d7e16a0bf0dfc  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 68,693,74,75,694,76
	btf_id 3533
3681: sched_cls  name tail_handle_ipv4_cont  tag b63d19575b506da5  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 67,694,33,135,74,75,31,68,66,69,693,32,29,30,73
	btf_id 3534
3682: sched_cls  name cil_from_container  tag a28b9206a72cb3ac  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 693,68
	btf_id 3535
3684: sched_cls  name tail_handle_arp  tag ab0f4479349d7aa4  gpl
	loaded_at 2024-10-24T09:24:49+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 68,693
	btf_id 3537
