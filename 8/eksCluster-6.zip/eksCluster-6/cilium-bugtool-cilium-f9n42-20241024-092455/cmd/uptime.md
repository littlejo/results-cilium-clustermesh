 09:24:57 up 10 min,  0 users,  load average: 0.37, 0.34, 0.22
