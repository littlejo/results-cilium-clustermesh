CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod206c6d1c_1d8c_4ad0_be03_511459124eab.slice/cri-containerd-51be7de17965d484d44add8de7eeccce4e67f2599a606d6b3e62126982116cbb.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod206c6d1c_1d8c_4ad0_be03_511459124eab.slice/cri-containerd-2ceac8f075c117fcb7d2bfb983846459f4dd9b56925446992e4cfb69d746c399.scope
    75       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f54240f_6f81_4d1d_9282_6779d6a631b8.slice/cri-containerd-cb446894beddcbb42bbbe2be6eecd7e8727b8cbe9220b65ed9bedf88ae662d33.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f54240f_6f81_4d1d_9282_6779d6a631b8.slice/cri-containerd-62158599bd3c66c07dd7437495db22de1dfd87bb21b1508b2866a5fda51d83cf.scope
    461      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podceeb59d6_f846_4dae_9d99_3acf47532e55.slice/cri-containerd-61115aca2d27d2fc2ea6b21480b2490387c8fcaa2ca83dc525310be67678f9aa.scope
    519      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podceeb59d6_f846_4dae_9d99_3acf47532e55.slice/cri-containerd-9978af32e81431e34e13bb671b2f19e5f5166eeed91b02ed69cf21a133eb0afa.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod161a6773_b284_451b_9d00_4ee96ddcd175.slice/cri-containerd-712fc3d23ecde71d26aa76ab0ed6bcf1a8b41f97de2f5d48502ff462195c9c7c.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod161a6773_b284_451b_9d00_4ee96ddcd175.slice/cri-containerd-b5126cf8ffdaeb3ec56ddec36e95b56628c6c50940d2e511802fe58372ad5adf.scope
    64       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-06cb8ba2de88b95e85e1a232b6b951d693942530625f82b7a30add3a54f74e67.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-13614f20b9b5045f43b0614f5c53708ccf5f225a5d039f4143579fa91900627e.scope
    627      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-4ee546f0bd422d977766c689aa0e07d6a0e43489f45922de17fb40faed707edc.scope
    631      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f8d3c67_8d58_4ac1_b753_de8292a03bc0.slice/cri-containerd-a555714de1f7cca816fabf30117eba527c287c531fc785e82f05b09a98c22f19.scope
    607      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18da6df0_97dc_4afc_8894_b5d66cd77f47.slice/cri-containerd-c47ffc2c2dcdcc1b9d305639fbe3c31ad906ca5185c533038c47ef1ce9940c2d.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod18da6df0_97dc_4afc_8894_b5d66cd77f47.slice/cri-containerd-9f045a814ad784414c2e8b6cf1190f687ed67e04685df167761e44b9441cb220.scope
    684      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod474ce03d_9849_4385_9510_a09682b6094d.slice/cri-containerd-d16f57c5c93194dc3af67e2a95f17c254cdd2a35ccb74c6c04fe9e883b3fd2e9.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod474ce03d_9849_4385_9510_a09682b6094d.slice/cri-containerd-4c43ffcd4941828915527d1ee6139eedcefc6a761d29c77c01e6b93603f7695c.scope
    680      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eab8303_8839_469e_96bc_d59bdf2f68a7.slice/cri-containerd-52f3a36c5c626c762c22589afe35c09608ac58601cae5247e694f54a24b1b94c.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eab8303_8839_469e_96bc_d59bdf2f68a7.slice/cri-containerd-fbac93e2bd04406122c3903668d45d2f65c2f2a0cb645819bf6ccbd278585feb.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod414261e0_d90b_41a3_9fcd_a30bb38d481b.slice/cri-containerd-a42353abb385fd03ff8b473b6f99b733c4824606560d60f8c00dfb6d7dd46ad6.scope
    692      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod414261e0_d90b_41a3_9fcd_a30bb38d481b.slice/cri-containerd-dd793dd16cc8610e6444279ee755df6805f12cd02aeddf62981018a8202a2e3b.scope
    688      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod414261e0_d90b_41a3_9fcd_a30bb38d481b.slice/cri-containerd-ffbcfac05b630641389fc99b554478bc87d3610feecdf666c9a2806efb2b7a82.scope
    676      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e49a25d_a286_4674_b504_628448916ef9.slice/cri-containerd-d5d60975383af617970db7844ec90fcc42c5d34468da887efc5609243b406681.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e49a25d_a286_4674_b504_628448916ef9.slice/cri-containerd-b3b4a3d53b9003f166098cb92da7a6a060a2ee3c6f81cebc76b8873046688b8a.scope
    79       cgroup_device   multi                                          
