key: c0 00 00 00  value: 5e 0e 00 00
key: f8 02 00 00  value: 2b 0d 00 00
key: ef 04 00 00  value: 57 02 00 00
key: 10 05 00 00  value: 08 02 00 00
key: 65 09 00 00  value: ee 01 00 00
key: c5 09 00 00  value: ff 01 00 00
key: 73 0c 00 00  value: 5f 0e 00 00
Found 7 elements
