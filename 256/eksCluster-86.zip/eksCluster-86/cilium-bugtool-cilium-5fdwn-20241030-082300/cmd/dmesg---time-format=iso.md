2024-10-30T07:46:33,000000+00:00 Booting Linux on physical CPU 0x0000000000 [0x413fd0c1]
2024-10-30T07:46:33,000000+00:00 Linux version 6.1.112-122.189.amzn2023.aarch64 (mockbuild@ip-10-0-39-248) (gcc (GCC) 11.4.1 20230605 (Red Hat 11.4.1-2), GNU ld version 2.39-6.amzn2023.0.10) #1 SMP Tue Oct  8 17:01:34 UTC 2024
2024-10-30T07:46:33,000000+00:00 efi: EFI v2.70 by EDK II
2024-10-30T07:46:33,000000+00:00 efi: SMBIOS=0x7bed0000 SMBIOS 3.0=0x7beb0000 ACPI=0x786e0000 ACPI 2.0=0x786e0014 MEMATTR=0x7aff0a98 RNG=0x74ca0018 MEMRESERVE=0x784d0d98 
2024-10-30T07:46:33,000000+00:00 random: crng init done
2024-10-30T07:46:33,000000+00:00 ACPI: Early table checksum verification disabled
2024-10-30T07:46:33,000000+00:00 ACPI: RSDP 0x00000000786E0014 000024 (v02 AMAZON)
2024-10-30T07:46:33,000000+00:00 ACPI: XSDT 0x00000000786D00E8 000064 (v01 AMAZON AMZNFACP 00000001      01000013)
2024-10-30T07:46:33,000000+00:00 ACPI: FACP 0x00000000786B0000 000114 (v06 AMAZON AMZNFACP 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: DSDT 0x0000000078640000 00159D (v02 AMAZON AMZNDSDT 00000001 INTL 20160527)
2024-10-30T07:46:33,000000+00:00 ACPI: FACS 0x0000000078630000 000040
2024-10-30T07:46:33,000000+00:00 ACPI: APIC 0x00000000786C0000 000108 (v04 AMAZON AMZNAPIC 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: SPCR 0x00000000786A0000 000050 (v02 AMAZON AMZNSPCR 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: GTDT 0x0000000078690000 000060 (v02 AMAZON AMZNGTDT 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: MCFG 0x0000000078680000 00003C (v02 AMAZON AMZNMCFG 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: SLIT 0x0000000078670000 00002D (v01 AMAZON AMZNSLIT 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: IORT 0x0000000078660000 000078 (v01 AMAZON AMZNIORT 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: PPTT 0x0000000078650000 0000D4 (v02 AMAZON AMZNPPTT 00000001 AMZN 00000001)
2024-10-30T07:46:33,000000+00:00 ACPI: SPCR: console: uart,mmio,0x90a0000,115200
2024-10-30T07:46:33,000000+00:00 NUMA: Failed to initialise from firmware
2024-10-30T07:46:33,000000+00:00 NUMA: Faking a node at [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:46:33,000000+00:00 NUMA: NODE_DATA [mem 0x5b802a7c0-0x5b802cfff]
2024-10-30T07:46:33,000000+00:00 Zone ranges:
2024-10-30T07:46:33,000000+00:00   DMA      [mem 0x0000000040000000-0x00000000ffffffff]
2024-10-30T07:46:33,000000+00:00   DMA32    empty
2024-10-30T07:46:33,000000+00:00   Normal   [mem 0x0000000100000000-0x00000005b8ffffff]
2024-10-30T07:46:33,000000+00:00   Device   empty
2024-10-30T07:46:33,000000+00:00 Movable zone start for each node
2024-10-30T07:46:33,000000+00:00 Early memory node ranges
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x0000000040000000-0x000000007862ffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x0000000078630000-0x000000007863ffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x0000000078640000-0x00000000786effff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x00000000786f0000-0x000000007872ffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x0000000078730000-0x000000007bbfffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x000000007bc00000-0x000000007bfdffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x000000007bfe0000-0x000000007fffffff]
2024-10-30T07:46:33,000000+00:00   node   0: [mem 0x0000000400000000-0x00000005b8ffffff]
2024-10-30T07:46:33,000000+00:00 Initmem setup node 0 [mem 0x0000000040000000-0x00000005b8ffffff]
2024-10-30T07:46:33,000000+00:00 On node 0, zone Normal: 28672 pages in unavailable ranges
2024-10-30T07:46:33,000000+00:00 cma: Reserved 64 MiB at 0x000000007c000000 on node -1
2024-10-30T07:46:33,000000+00:00 psci: probing for conduit method from ACPI.
2024-10-30T07:46:33,000000+00:00 psci: PSCIv1.0 detected in firmware.
2024-10-30T07:46:33,000000+00:00 psci: Using standard PSCI v0.2 function IDs
2024-10-30T07:46:33,000000+00:00 psci: Trusted OS migration not required
2024-10-30T07:46:33,000000+00:00 psci: SMC Calling Convention v1.1
2024-10-30T07:46:33,000000+00:00 percpu: Embedded 31 pages/cpu s86440 r8192 d32344 u126976
2024-10-30T07:46:33,000000+00:00 pcpu-alloc: s86440 r8192 d32344 u126976 alloc=31*4096
2024-10-30T07:46:33,000000+00:00 pcpu-alloc: [0] 0 [0] 1 
2024-10-30T07:46:33,000000+00:00 Detected PIPT I-cache on CPU0
2024-10-30T07:46:33,000000+00:00 CPU features: detected: GIC system register CPU interface
2024-10-30T07:46:33,000000+00:00 CPU features: detected: Hardware dirty bit management
2024-10-30T07:46:33,000000+00:00 CPU features: detected: Spectre-v4
2024-10-30T07:46:33,000000+00:00 CPU features: detected: Spectre-BHB
2024-10-30T07:46:33,000000+00:00 CPU features: detected: ARM erratum 1418040
2024-10-30T07:46:33,000000+00:00 CPU features: detected: ARM erratum 1542419 (kernel portion)
2024-10-30T07:46:33,000000+00:00 CPU features: detected: SSBS not fully self-synchronizing
2024-10-30T07:46:33,000000+00:00 alternatives: applying boot alternatives
2024-10-30T07:46:33,000000+00:00 Fallback order for Node 0: 0 
2024-10-30T07:46:33,000000+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 2036160
2024-10-30T07:46:33,000000+00:00 Policy zone: Normal
2024-10-30T07:46:33,000000+00:00 Kernel command line: BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64 root=UUID=b5c7fae5-1de8-4038-8408-06c720e69aff ro console=tty0 console=ttyS0,115200n8 nvme_core.io_timeout=4294967295 rd.emergency=poweroff rd.shell=0 selinux=1 security=selinux quiet numa_cma=1:64M
2024-10-30T07:46:33,000000+00:00 Unknown kernel command line parameters "BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64", will be passed to user space.
2024-10-30T07:46:33,000000+00:00 Dentry cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2024-10-30T07:46:33,000000+00:00 Inode-cache hash table entries: 524288 (order: 10, 4194304 bytes, linear)
2024-10-30T07:46:33,000000+00:00 mem auto-init: stack:off, heap alloc:off, heap free:off
2024-10-30T07:46:33,000000+00:00 software IO TLB: area num 2.
2024-10-30T07:46:33,000000+00:00 software IO TLB: mapped [mem 0x000000006de00000-0x0000000071e00000] (64MB)
2024-10-30T07:46:33,000000+00:00 Memory: 7919828K/8273920K available (12096K kernel code, 8838K rwdata, 8416K rodata, 4480K init, 11359K bss, 288556K reserved, 65536K cma-reserved)
2024-10-30T07:46:33,000000+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=2, Nodes=1
2024-10-30T07:46:33,000000+00:00 ftrace: allocating 40237 entries in 158 pages
2024-10-30T07:46:33,000000+00:00 ftrace: allocated 158 pages with 5 groups
2024-10-30T07:46:33,000000+00:00 trace event string verifier disabled
2024-10-30T07:46:33,000000+00:00 rcu: Hierarchical RCU implementation.
2024-10-30T07:46:33,000000+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=4096 to nr_cpu_ids=2.
2024-10-30T07:46:33,000000+00:00 	Rude variant of Tasks RCU enabled.
2024-10-30T07:46:33,000000+00:00 	Tracing variant of Tasks RCU enabled.
2024-10-30T07:46:33,000000+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 10 jiffies.
2024-10-30T07:46:33,000000+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=2
2024-10-30T07:46:33,000000+00:00 NR_IRQS: 64, nr_irqs: 64, preallocated irqs: 0
2024-10-30T07:46:33,000000+00:00 GICv3: 96 SPIs implemented
2024-10-30T07:46:33,000000+00:00 GICv3: 0 Extended SPIs implemented
2024-10-30T07:46:33,000000+00:00 Root IRQ handler: gic_handle_irq
2024-10-30T07:46:33,000000+00:00 GICv3: GICv3 features: 16 PPIs
2024-10-30T07:46:33,000000+00:00 GICv3: CPU0: found redistributor 0 region 0:0x0000000010200000
2024-10-30T07:46:33,000000+00:00 ITS [mem 0x10080000-0x1009ffff]
2024-10-30T07:46:33,000000+00:00 ITS@0x0000000010080000: allocated 8192 Devices @4001a0000 (indirect, esz 8, psz 64K, shr 1)
2024-10-30T07:46:33,000000+00:00 ITS@0x0000000010080000: allocated 8192 Interrupt Collections @4001b0000 (flat, esz 8, psz 64K, shr 1)
2024-10-30T07:46:33,000000+00:00 GICv3: using LPI property table @0x00000004001c0000
2024-10-30T07:46:33,000000+00:00 ITS: Using hypervisor restricted LPI range [128]
2024-10-30T07:46:33,000000+00:00 GICv3: CPU0: using allocated LPI pending table @0x00000004001d0000
2024-10-30T07:46:33,000000+00:00 rcu: srcu_init: Setting srcu_struct sizes based on contention.
2024-10-30T07:46:33,000000+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:46:33,000000+00:00 arch_timer: cp15 timer(s) running at 121.87MHz (virt).
2024-10-30T07:46:33,000000+00:00 clocksource: arch_sys_counter: mask: 0x3ffffffffffffff max_cycles: 0x383759f8ff, max_idle_ns: 881590415659 ns
2024-10-30T07:46:33,000000+00:00 sched_clock: 58 bits at 122MHz, resolution 8ns, wraps every 4398046511103ns
2024-10-30T07:46:33,000020+00:00 arm-pv: using stolen time PV
2024-10-30T07:46:33,000080+00:00 Console: colour dummy device 80x25
2024-10-30T07:46:33,000096+00:00 printk: console [tty0] enabled
2024-10-30T07:46:33,000114+00:00 ACPI: Core revision 20220331
2024-10-30T07:46:33,000147+00:00 Calibrating delay loop (skipped), value calculated using timer frequency.. 243.75 BogoMIPS (lpj=1218750)
2024-10-30T07:46:33,000150+00:00 pid_max: default: 32768 minimum: 301
2024-10-30T07:46:33,000170+00:00 LSM: Security Framework initializing
2024-10-30T07:46:33,000187+00:00 Yama: becoming mindful.
2024-10-30T07:46:33,000193+00:00 SELinux:  Initializing.
2024-10-30T07:46:33,000207+00:00 LSM support for eBPF active
2024-10-30T07:46:33,000228+00:00 Mount-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:46:33,000233+00:00 Mountpoint-cache hash table entries: 16384 (order: 5, 131072 bytes, linear)
2024-10-30T07:46:33,000564+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:46:33,000567+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:46:33,000580+00:00 cblist_init_generic: Setting adjustable number of callback queues.
2024-10-30T07:46:33,000580+00:00 cblist_init_generic: Setting shift to 1 and lim to 1.
2024-10-30T07:46:33,000622+00:00 rcu: Hierarchical SRCU implementation.
2024-10-30T07:46:33,000623+00:00 rcu: 	Max phase no-delay instances is 1000.
2024-10-30T07:46:33,000817+00:00 Platform MSI: ITS@0x10080000 domain created
2024-10-30T07:46:33,000822+00:00 PCI/MSI: ITS@0x10080000 domain created
2024-10-30T07:46:33,000826+00:00 Remapping and enabling EFI services.
2024-10-30T07:46:33,000932+00:00 smp: Bringing up secondary CPUs ...
2024-10-30T07:46:33,001091+00:00 Detected PIPT I-cache on CPU1
2024-10-30T07:46:33,001120+00:00 GICv3: CPU1: found redistributor 1 region 0:0x0000000010220000
2024-10-30T07:46:33,001150+00:00 GICv3: CPU1: using allocated LPI pending table @0x00000004001e0000
2024-10-30T07:46:33,001164+00:00 arch_timer: Enabling local workaround for ARM erratum 1418040
2024-10-30T07:46:33,001179+00:00 CPU1: Booted secondary processor 0x0000000001 [0x413fd0c1]
2024-10-30T07:46:33,001287+00:00 smp: Brought up 1 node, 2 CPUs
2024-10-30T07:46:33,001292+00:00 SMP: Total of 2 processors activated.
2024-10-30T07:46:33,001294+00:00 CPU features: detected: 32-bit EL0 Support
2024-10-30T07:46:33,001295+00:00 CPU features: detected: Instruction cache invalidation not required for I/D coherence
2024-10-30T07:46:33,001297+00:00 CPU features: detected: Data cache clean to the PoU not required for I/D coherence
2024-10-30T07:46:33,001298+00:00 CPU features: detected: Common not Private translations
2024-10-30T07:46:33,001299+00:00 CPU features: detected: CRC32 instructions
2024-10-30T07:46:33,001300+00:00 CPU features: detected: RCpc load-acquire (LDAPR)
2024-10-30T07:46:33,001301+00:00 CPU features: detected: LSE atomic instructions
2024-10-30T07:46:33,001302+00:00 CPU features: detected: Privileged Access Never
2024-10-30T07:46:33,001303+00:00 CPU features: detected: RAS Extension Support
2024-10-30T07:46:33,001305+00:00 CPU features: detected: Speculative Store Bypassing Safe (SSBS)
2024-10-30T07:46:33,001353+00:00 CPU: All CPU(s) started at EL1
2024-10-30T07:46:33,001357+00:00 alternatives: applying system-wide alternatives
2024-10-30T07:46:33,003533+00:00 devtmpfs: initialized
2024-10-30T07:46:33,004246+00:00 Registered cp15_barrier emulation handler
2024-10-30T07:46:33,004259+00:00 Registered setend emulation handler
2024-10-30T07:46:33,004296+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 19112604462750000 ns
2024-10-30T07:46:33,004300+00:00 futex hash table entries: 512 (order: 3, 32768 bytes, linear)
2024-10-30T07:46:33,004522+00:00 pinctrl core: initialized pinctrl subsystem
2024-10-30T07:46:33,004568+00:00 SMBIOS 3.0.0 present.
2024-10-30T07:46:33,004572+00:00 DMI: Amazon EC2 t4g.large/, BIOS 1.0 11/1/2018
2024-10-30T07:46:33,004674+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2024-10-30T07:46:33,004857+00:00 DMA: preallocated 1024 KiB GFP_KERNEL pool for atomic allocations
2024-10-30T07:46:33,004895+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2024-10-30T07:46:33,004958+00:00 DMA: preallocated 1024 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2024-10-30T07:46:33,004968+00:00 audit: initializing netlink subsys (disabled)
2024-10-30T07:46:33,005026+00:00 audit: type=2000 audit(0.000:1): state=initialized audit_enabled=0 res=1
2024-10-30T07:46:33,005081+00:00 thermal_sys: Registered thermal governor 'fair_share'
2024-10-30T07:46:33,005083+00:00 thermal_sys: Registered thermal governor 'step_wise'
2024-10-30T07:46:33,005084+00:00 thermal_sys: Registered thermal governor 'user_space'
2024-10-30T07:46:33,005092+00:00 cpuidle: using governor ladder
2024-10-30T07:46:33,005096+00:00 cpuidle: using governor menu
2024-10-30T07:46:33,005133+00:00 hw-breakpoint: found 6 breakpoint and 4 watchpoint registers.
2024-10-30T07:46:33,005165+00:00 ASID allocator initialised with 65536 entries
2024-10-30T07:46:33,005171+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2024-10-30T07:46:33,005184+00:00 Serial: AMBA PL011 UART driver
2024-10-30T07:46:33,010205+00:00 HugeTLB: registered 1.00 GiB page size, pre-allocated 0 pages
2024-10-30T07:46:33,010207+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 1.00 GiB page
2024-10-30T07:46:33,010209+00:00 HugeTLB: registered 32.0 MiB page size, pre-allocated 0 pages
2024-10-30T07:46:33,010210+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 32.0 MiB page
2024-10-30T07:46:33,010211+00:00 HugeTLB: registered 2.00 MiB page size, pre-allocated 0 pages
2024-10-30T07:46:33,010212+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 2.00 MiB page
2024-10-30T07:46:33,010213+00:00 HugeTLB: registered 64.0 KiB page size, pre-allocated 0 pages
2024-10-30T07:46:33,010213+00:00 HugeTLB: 0 KiB vmemmap can be freed for a 64.0 KiB page
2024-10-30T07:46:33,010727+00:00 ACPI: Added _OSI(Module Device)
2024-10-30T07:46:33,010730+00:00 ACPI: Added _OSI(Processor Device)
2024-10-30T07:46:33,010730+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2024-10-30T07:46:33,010732+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2024-10-30T07:46:33,011306+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2024-10-30T07:46:33,011614+00:00 ACPI: Interpreter enabled
2024-10-30T07:46:33,011615+00:00 ACPI: Using GIC for interrupt routing
2024-10-30T07:46:33,011626+00:00 ACPI: MCFG table detected, 1 entries
2024-10-30T07:46:33,013085+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-0f])
2024-10-30T07:46:33,013095+00:00 acpi PNP0A08:00: _OSC: OS supports [ExtendedConfig ASPM ClockPM Segments MSI HPX-Type3]
2024-10-30T07:46:33,013135+00:00 acpi PNP0A08:00: _OSC: platform does not support [SHPCHotplug LTR]
2024-10-30T07:46:33,013186+00:00 acpi PNP0A08:00: _OSC: OS now controls [PCIeHotplug PME PCIeCapability]
2024-10-30T07:46:33,013262+00:00 acpi PNP0A08:00: ECAM area [mem 0x20000000-0x20ffffff] reserved by PNP0C02:00
2024-10-30T07:46:33,013268+00:00 acpi PNP0A08:00: ECAM at [mem 0x20000000-0x20ffffff] for [bus 00-0f]
2024-10-30T07:46:33,013282+00:00 ACPI: Remapped I/O 0x000000001fff0000 to [io  0x0000-0xffff window]
2024-10-30T07:46:33,013526+00:00 acpiphp: Slot [1] registered
2024-10-30T07:46:33,013537+00:00 acpiphp: Slot [2] registered
2024-10-30T07:46:33,013547+00:00 acpiphp: Slot [3] registered
2024-10-30T07:46:33,013557+00:00 acpiphp: Slot [4] registered
2024-10-30T07:46:33,013567+00:00 acpiphp: Slot [5] registered
2024-10-30T07:46:33,013577+00:00 acpiphp: Slot [6] registered
2024-10-30T07:46:33,013587+00:00 acpiphp: Slot [7] registered
2024-10-30T07:46:33,013596+00:00 acpiphp: Slot [8] registered
2024-10-30T07:46:33,013606+00:00 acpiphp: Slot [9] registered
2024-10-30T07:46:33,013615+00:00 acpiphp: Slot [10] registered
2024-10-30T07:46:33,013624+00:00 acpiphp: Slot [11] registered
2024-10-30T07:46:33,013633+00:00 acpiphp: Slot [12] registered
2024-10-30T07:46:33,013643+00:00 acpiphp: Slot [13] registered
2024-10-30T07:46:33,013652+00:00 acpiphp: Slot [14] registered
2024-10-30T07:46:33,013663+00:00 acpiphp: Slot [15] registered
2024-10-30T07:46:33,013672+00:00 acpiphp: Slot [16] registered
2024-10-30T07:46:33,013681+00:00 acpiphp: Slot [17] registered
2024-10-30T07:46:33,013691+00:00 acpiphp: Slot [18] registered
2024-10-30T07:46:33,013700+00:00 acpiphp: Slot [19] registered
2024-10-30T07:46:33,013710+00:00 acpiphp: Slot [20] registered
2024-10-30T07:46:33,013719+00:00 acpiphp: Slot [21] registered
2024-10-30T07:46:33,013728+00:00 acpiphp: Slot [22] registered
2024-10-30T07:46:33,013738+00:00 acpiphp: Slot [23] registered
2024-10-30T07:46:33,013747+00:00 acpiphp: Slot [24] registered
2024-10-30T07:46:33,013756+00:00 acpiphp: Slot [25] registered
2024-10-30T07:46:33,013766+00:00 acpiphp: Slot [26] registered
2024-10-30T07:46:33,013776+00:00 acpiphp: Slot [27] registered
2024-10-30T07:46:33,013785+00:00 acpiphp: Slot [28] registered
2024-10-30T07:46:33,013794+00:00 acpiphp: Slot [29] registered
2024-10-30T07:46:33,013803+00:00 acpiphp: Slot [30] registered
2024-10-30T07:46:33,013813+00:00 acpiphp: Slot [31] registered
2024-10-30T07:46:33,013828+00:00 PCI host bridge to bus 0000:00
2024-10-30T07:46:33,013829+00:00 pci_bus 0000:00: root bus resource [mem 0x80000000-0xffffffff window]
2024-10-30T07:46:33,013832+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0xffff window]
2024-10-30T07:46:33,013833+00:00 pci_bus 0000:00: root bus resource [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:46:33,013835+00:00 pci_bus 0000:00: root bus resource [bus 00-0f]
2024-10-30T07:46:33,013870+00:00 pci 0000:00:00.0: [1d0f:0200] type 00 class 0x060000
2024-10-30T07:46:33,014103+00:00 pci 0000:00:01.0: [1d0f:8250] type 00 class 0x070003
2024-10-30T07:46:33,014151+00:00 pci 0000:00:01.0: reg 0x10: [mem 0x80008000-0x80008fff]
2024-10-30T07:46:33,014342+00:00 pci 0000:00:04.0: [1d0f:8061] type 00 class 0x010802
2024-10-30T07:46:33,015668+00:00 pci 0000:00:04.0: reg 0x10: [mem 0x80004000-0x80007fff]
2024-10-30T07:46:33,021237+00:00 pci 0000:00:04.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:46:33,021430+00:00 pci 0000:00:05.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:46:33,021470+00:00 pci 0000:00:05.0: reg 0x10: [mem 0x80000000-0x80003fff]
2024-10-30T07:46:33,021666+00:00 pci 0000:00:05.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:46:33,021826+00:00 pci 0000:00:04.0: BAR 0: assigned [mem 0x80000000-0x80003fff]
2024-10-30T07:46:33,022331+00:00 pci 0000:00:05.0: BAR 0: assigned [mem 0x80004000-0x80007fff]
2024-10-30T07:46:33,022340+00:00 pci 0000:00:01.0: BAR 0: assigned [mem 0x80008000-0x80008fff]
2024-10-30T07:46:33,022349+00:00 pci_bus 0000:00: resource 4 [mem 0x80000000-0xffffffff window]
2024-10-30T07:46:33,022351+00:00 pci_bus 0000:00: resource 5 [io  0x0000-0xffff window]
2024-10-30T07:46:33,022353+00:00 pci_bus 0000:00: resource 6 [mem 0x400000000000-0x407fffffffff window]
2024-10-30T07:46:33,022385+00:00 ACPI: PCI: Interrupt link GSI0 configured for IRQ 35
2024-10-30T07:46:33,022392+00:00 ACPI: PCI: Interrupt link GSI1 configured for IRQ 36
2024-10-30T07:46:33,022397+00:00 ACPI: PCI: Interrupt link GSI2 configured for IRQ 37
2024-10-30T07:46:33,022403+00:00 ACPI: PCI: Interrupt link GSI3 configured for IRQ 38
2024-10-30T07:46:33,022779+00:00 iommu: Default domain type: Translated 
2024-10-30T07:46:33,022781+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2024-10-30T07:46:33,022818+00:00 pps_core: LinuxPPS API ver. 1 registered
2024-10-30T07:46:33,022819+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2024-10-30T07:46:33,022822+00:00 PTP clock support registered
2024-10-30T07:46:33,022851+00:00 EDAC MC: Ver: 3.0.0
2024-10-30T07:46:33,023024+00:00 Registered efivars operations
2024-10-30T07:46:33,023234+00:00 NetLabel: Initializing
2024-10-30T07:46:33,023235+00:00 NetLabel:  domain hash size = 128
2024-10-30T07:46:33,023236+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2024-10-30T07:46:33,023247+00:00 NetLabel:  unlabeled traffic allowed by default
2024-10-30T07:46:33,023293+00:00 vgaarb: loaded
2024-10-30T07:46:33,023381+00:00 clocksource: Switched to clocksource arch_sys_counter
2024-10-30T07:46:33,023462+00:00 VFS: Disk quotas dquot_6.6.0
2024-10-30T07:46:33,023471+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2024-10-30T07:46:33,023526+00:00 pnp: PnP ACPI init
2024-10-30T07:46:33,023603+00:00 system 00:00: [mem 0x20000000-0x2fffffff] could not be reserved
2024-10-30T07:46:33,023614+00:00 pnp: PnP ACPI: found 1 devices
2024-10-30T07:46:33,030944+00:00 NET: Registered PF_INET protocol family
2024-10-30T07:46:33,030999+00:00 IP idents hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2024-10-30T07:46:33,032416+00:00 tcp_listen_portaddr_hash hash table entries: 4096 (order: 4, 65536 bytes, linear)
2024-10-30T07:46:33,032440+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2024-10-30T07:46:33,032443+00:00 TCP established hash table entries: 65536 (order: 7, 524288 bytes, linear)
2024-10-30T07:46:33,032607+00:00 TCP bind hash table entries: 65536 (order: 9, 2097152 bytes, linear)
2024-10-30T07:46:33,033224+00:00 TCP: Hash tables configured (established 65536 bind 65536)
2024-10-30T07:46:33,033264+00:00 MPTCP token hash table entries: 8192 (order: 5, 196608 bytes, linear)
2024-10-30T07:46:33,033290+00:00 UDP hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:46:33,033350+00:00 UDP-Lite hash table entries: 4096 (order: 5, 131072 bytes, linear)
2024-10-30T07:46:33,033441+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2024-10-30T07:46:33,033450+00:00 NET: Registered PF_XDP protocol family
2024-10-30T07:46:33,033493+00:00 PCI: CLS 0 bytes, default 64
2024-10-30T07:46:33,033631+00:00 Trying to unpack rootfs image as initramfs...
2024-10-30T07:46:33,044960+00:00 hw perfevents: enabled with armv8_pmuv3_0 PMU driver, 3 counters available
2024-10-30T07:46:33,044985+00:00 kvm [1]: HYP mode not available
2024-10-30T07:46:33,045200+00:00 Initialise system trusted keyrings
2024-10-30T07:46:33,045206+00:00 Key type blacklist registered
2024-10-30T07:46:33,045420+00:00 workingset: timestamp_bits=44 max_order=21 bucket_order=0
2024-10-30T07:46:33,046400+00:00 zbud: loaded
2024-10-30T07:46:33,046559+00:00 SGI XFS with ACLs, security attributes, quota, no debug enabled
2024-10-30T07:46:33,047076+00:00 integrity: Platform Keyring initialized
2024-10-30T07:46:33,054139+00:00 Key type asymmetric registered
2024-10-30T07:46:33,054143+00:00 Asymmetric key parser 'x509' registered
2024-10-30T07:46:33,054164+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 248)
2024-10-30T07:46:33,054204+00:00 io scheduler mq-deadline registered
2024-10-30T07:46:33,054205+00:00 io scheduler kyber registered
2024-10-30T07:46:33,054230+00:00 io scheduler bfq registered
2024-10-30T07:46:33,056036+00:00 pl061_gpio ARMH0061:00: PL061 GPIO chip registered
2024-10-30T07:46:33,056083+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2024-10-30T07:46:33,057309+00:00 Serial: 8250/16550 driver, 4 ports, IRQ sharing disabled
2024-10-30T07:46:33,057781+00:00 ACPI: \_SB_.PCI0.GSI2: Enabled at IRQ 37
2024-10-30T07:46:33,057808+00:00 serial 0000:00:01.0: enabling device (0010 -> 0012)
2024-10-30T07:46:33,058098+00:00 printk: console [ttyS0] disabled
2024-10-30T07:46:33,058242+00:00 0000:00:01.0: ttyS0 at MMIO 0x80008000 (irq = 14, base_baud = 115200) is a 16550A
2024-10-30T07:46:33,058341+00:00 printk: console [ttyS0] enabled
2024-10-30T07:46:33,059093+00:00 ACPI: \_SB_.PCI0.GSI0: Enabled at IRQ 35
2024-10-30T07:46:33,059178+00:00 nvme nvme0: pci function 0000:00:04.0
2024-10-30T07:46:33,059702+00:00 rtc-efi rtc-efi.0: registered as rtc0
2024-10-30T07:46:33,059731+00:00 rtc-efi rtc-efi.0: setting system clock to 2024-10-30T07:46:33 UTC (1730274393)
2024-10-30T07:46:33,059794+00:00 pstore: Registered efi as persistent store backend
2024-10-30T07:46:33,059805+00:00 hid: raw HID events driver (C) Jiri Kosina
2024-10-30T07:46:33,069555+00:00 NET: Registered PF_INET6 protocol family
2024-10-30T07:46:33,071544+00:00 nvme nvme0: 2/0/0 default/read/poll queues
2024-10-30T07:46:33,076851+00:00  nvme0n1: p1 p128
2024-10-30T07:46:33,142898+00:00 Freeing initrd memory: 11908K
2024-10-30T07:46:33,149309+00:00 Segment Routing with IPv6
2024-10-30T07:46:33,149325+00:00 In-situ OAM (IOAM) with IPv6
2024-10-30T07:46:33,149360+00:00 NET: Registered PF_PACKET protocol family
2024-10-30T07:46:33,149571+00:00 registered taskstats version 1
2024-10-30T07:46:33,149580+00:00 Loading compiled-in X.509 certificates
2024-10-30T07:46:33,161327+00:00 Loaded X.509 cert 'Amazon.com: Amazon Linux Kernel Signing Key: 3c3163dcb84c1049cf8b75ca4bcf01c5583dbccb'
2024-10-30T07:46:33,161462+00:00 zswap: loaded using pool lzo/zbud
2024-10-30T07:46:33,161606+00:00 Key type .fscrypt registered
2024-10-30T07:46:33,161609+00:00 Key type fscrypt-provisioning registered
2024-10-30T07:46:33,161800+00:00 pstore: Using crash dump compression: deflate
2024-10-30T07:46:33,162024+00:00 ima: secureboot mode disabled
2024-10-30T07:46:33,162028+00:00 ima: No TPM chip found, activating TPM-bypass!
2024-10-30T07:46:33,162035+00:00 ima: Allocated hash algorithm: sha256
2024-10-30T07:46:33,162045+00:00 ima: No architecture policies found
2024-10-30T07:46:33,303721+00:00 clk: Disabling unused clocks
2024-10-30T07:46:33,304961+00:00 Freeing unused kernel memory: 4480K
2024-10-30T07:46:33,304979+00:00 Run /init as init process
2024-10-30T07:46:33,304981+00:00   with arguments:
2024-10-30T07:46:33,304982+00:00     /init
2024-10-30T07:46:33,304983+00:00   with environment:
2024-10-30T07:46:33,304984+00:00     HOME=/
2024-10-30T07:46:33,304985+00:00     TERM=linux
2024-10-30T07:46:33,304986+00:00     BOOT_IMAGE=(hd0,gpt1)/boot/vmlinuz-6.1.112-122.189.amzn2023.aarch64
2024-10-30T07:46:33,330734+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:46:33,330741+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:46:33,330744+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:46:33,330746+00:00 systemd[1]: Running in initrd.
2024-10-30T07:46:33,330842+00:00 systemd[1]: No hostname configured, using default hostname.
2024-10-30T07:46:33,330882+00:00 systemd[1]: Hostname set to <localhost>.
2024-10-30T07:46:33,330957+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:46:33,429906+00:00 systemd[1]: Queued start job for default target initrd.target.
2024-10-30T07:46:33,463862+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:46:33,463909+00:00 systemd[1]: Expecting device dev-disk-by\x2duuid-b5c7fae5\x2d1de8\x2d4038\x2d8408\x2d06c720e69aff.device - /dev/disk/by-uuid/b5c7fae5-1de8-4038-8408-06c720e69aff...
2024-10-30T07:46:33,463938+00:00 systemd[1]: Reached target initrd-usr-fs.target - Initrd /usr File System.
2024-10-30T07:46:33,463953+00:00 systemd[1]: Reached target local-fs.target - Local File Systems.
2024-10-30T07:46:33,463964+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:46:33,463981+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:46:33,463994+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:46:33,464006+00:00 systemd[1]: Reached target timers.target - Timer Units.
2024-10-30T07:46:33,464295+00:00 systemd[1]: Listening on systemd-journald-audit.socket - Journal Audit Socket.
2024-10-30T07:46:33,464412+00:00 systemd[1]: Listening on systemd-journald-dev-log.socket - Journal Socket (/dev/log).
2024-10-30T07:46:33,464490+00:00 systemd[1]: Listening on systemd-journald.socket - Journal Socket.
2024-10-30T07:46:33,464573+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:46:33,464631+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:46:33,464646+00:00 systemd[1]: Reached target sockets.target - Socket Units.
2024-10-30T07:46:33,464696+00:00 systemd[1]: kmod-static-nodes.service - Create List of Static Device Nodes was skipped because of an unmet condition check (ConditionFileNotEmpty=/lib/modules/6.1.112-122.189.amzn2023.aarch64/modules.devname).
2024-10-30T07:46:33,465550+00:00 systemd[1]: Started rngd.service - Hardware RNG Entropy Gatherer Daemon.
2024-10-30T07:46:33,466773+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:46:33,466898+00:00 systemd[1]: systemd-modules-load.service - Load Kernel Modules was skipped because no trigger condition checks were met.
2024-10-30T07:46:33,467615+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:46:33,468344+00:00 systemd[1]: Starting systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev...
2024-10-30T07:46:33,469053+00:00 systemd[1]: Starting systemd-vconsole-setup.service - Setup Virtual Console...
2024-10-30T07:46:33,482583+00:00 systemd[1]: Finished systemd-tmpfiles-setup-dev.service - Create Static Device Nodes in /dev.
2024-10-30T07:46:33,493987+00:00 systemd[1]: Finished systemd-vconsole-setup.service - Setup Virtual Console.
2024-10-30T07:46:33,494045+00:00 audit: type=1130 audit(1730274393.929:2): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-vconsole-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,494153+00:00 systemd[1]: dracut-cmdline-ask.service - dracut ask for additional cmdline parameters was skipped because no trigger condition checks were met.
2024-10-30T07:46:33,494964+00:00 systemd[1]: Starting dracut-cmdline.service - dracut cmdline hook...
2024-10-30T07:46:33,495239+00:00 systemd[1]: Finished systemd-sysctl.service - Apply Kernel Variables.
2024-10-30T07:46:33,495301+00:00 audit: type=1130 audit(1730274393.929:3): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-sysctl comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,497526+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:46:33,499876+00:00 audit: type=1130 audit(1730274393.929:4): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-journald comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,507924+00:00 audit: type=1130 audit(1730274393.939:5): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-tmpfiles-setup comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,542156+00:00 audit: type=1130 audit(1730274393.969:6): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=dracut-cmdline comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,542618+00:00 audit: type=1334 audit(1730274393.969:7): prog-id=6 op=LOAD
2024-10-30T07:46:33,542656+00:00 audit: type=1334 audit(1730274393.969:8): prog-id=7 op=LOAD
2024-10-30T07:46:33,558772+00:00 audit: type=1130 audit(1730274393.989:9): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udevd comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:33,626797+00:00 audit: type=1130 audit(1730274394.059:10): pid=1 uid=0 auid=4294967295 ses=4294967295 subj=kernel msg='unit=systemd-udev-trigger comm="systemd" exe="/usr/lib/systemd/systemd" hostname=? addr=? terminal=? res=success'
2024-10-30T07:46:34,565297+00:00 XFS (nvme0n1p1): Mounting V5 Filesystem
2024-10-30T07:46:34,642836+00:00 XFS (nvme0n1p1): Ending clean mount
2024-10-30T07:46:34,945188+00:00 systemd-journald[324]: Received SIGTERM from PID 1 (systemd).
2024-10-30T07:46:35,117116+00:00 SELinux:  Class user_namespace not defined in policy.
2024-10-30T07:46:35,117122+00:00 SELinux: the above unknown classes and permissions will be allowed
2024-10-30T07:46:35,120239+00:00 SELinux:  policy capability network_peer_controls=1
2024-10-30T07:46:35,120244+00:00 SELinux:  policy capability open_perms=1
2024-10-30T07:46:35,120245+00:00 SELinux:  policy capability extended_socket_class=1
2024-10-30T07:46:35,120247+00:00 SELinux:  policy capability always_check_network=0
2024-10-30T07:46:35,120247+00:00 SELinux:  policy capability cgroup_seclabel=1
2024-10-30T07:46:35,120248+00:00 SELinux:  policy capability nnp_nosuid_transition=1
2024-10-30T07:46:35,120249+00:00 SELinux:  policy capability genfs_seclabel_symlinks=1
2024-10-30T07:46:35,120250+00:00 SELinux:  policy capability ioctl_skip_cloexec=0
2024-10-30T07:46:35,219664+00:00 systemd[1]: Successfully loaded SELinux policy in 142.482ms.
2024-10-30T07:46:35,276322+00:00 systemd[1]: Relabelled /dev, /dev/shm, /run, /sys/fs/cgroup in 23.861ms.
2024-10-30T07:46:35,284577+00:00 systemd[1]: systemd 252.23-2.amzn2023 running in system mode (+PAM +AUDIT +SELINUX -APPARMOR +IMA +SMACK +SECCOMP -GCRYPT -GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN -IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 +PWQUALITY +P11KIT +QRENCODE +TPM2 -BZIP2 -LZ4 +XZ -ZLIB -ZSTD +BPF_FRAMEWORK +XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2024-10-30T07:46:35,284583+00:00 systemd[1]: Detected virtualization amazon.
2024-10-30T07:46:35,284598+00:00 systemd[1]: Detected architecture arm64.
2024-10-30T07:46:35,288370+00:00 systemd[1]: Initializing machine ID from VM UUID.
2024-10-30T07:46:35,288452+00:00 systemd[1]: Installed transient /etc/machine-id file.
2024-10-30T07:46:35,351885+00:00 systemd[1]: bpf-lsm: Failed to link program; assuming BPF LSM is not available
2024-10-30T07:46:35,398948+00:00 zram_generator::config[854]: zram0: system has too much memory (7814MB), limit is 800MB, ignoring.
2024-10-30T07:46:35,487376+00:00 systemd[1]: /usr/lib/systemd/system/update-motd.service:40: Invalid CPU quota '25', ignoring.
2024-10-30T07:46:35,646927+00:00 systemd[1]: initrd-switch-root.service: Deactivated successfully.
2024-10-30T07:46:35,647080+00:00 systemd[1]: Stopped initrd-switch-root.service - Switch Root.
2024-10-30T07:46:35,647677+00:00 systemd[1]: systemd-journald.service: Scheduled restart job, restart counter is at 1.
2024-10-30T07:46:35,648109+00:00 systemd[1]: Created slice system-ebs\x2dinitialize\x2dbin.slice - Slice /system/ebs-initialize-bin.
2024-10-30T07:46:35,648482+00:00 systemd[1]: Created slice system-getty.slice - Slice /system/getty.
2024-10-30T07:46:35,648813+00:00 systemd[1]: Created slice system-modprobe.slice - Slice /system/modprobe.
2024-10-30T07:46:35,649140+00:00 systemd[1]: Created slice system-serial\x2dgetty.slice - Slice /system/serial-getty.
2024-10-30T07:46:35,649467+00:00 systemd[1]: Created slice system-sshd\x2dkeygen.slice - Slice /system/sshd-keygen.
2024-10-30T07:46:35,649791+00:00 systemd[1]: Created slice user.slice - User and Session Slice.
2024-10-30T07:46:35,649936+00:00 systemd[1]: Started systemd-ask-password-console.path - Dispatch Password Requests to Console Directory Watch.
2024-10-30T07:46:35,650032+00:00 systemd[1]: Started systemd-ask-password-wall.path - Forward Password Requests to Wall Directory Watch.
2024-10-30T07:46:35,650520+00:00 systemd[1]: Set up automount proc-sys-fs-binfmt_misc.automount - Arbitrary Executable File Formats File System Automount Point.
2024-10-30T07:46:35,650543+00:00 systemd[1]: Expecting device dev-ttyS0.device - /dev/ttyS0...
2024-10-30T07:46:35,650568+00:00 systemd[1]: Reached target cryptsetup.target - Local Encrypted Volumes.
2024-10-30T07:46:35,650605+00:00 systemd[1]: Stopped target initrd-switch-root.target - Switch Root.
2024-10-30T07:46:35,650623+00:00 systemd[1]: Stopped target initrd-fs.target - Initrd File Systems.
2024-10-30T07:46:35,650633+00:00 systemd[1]: Stopped target initrd-root-fs.target - Initrd Root File System.
2024-10-30T07:46:35,650645+00:00 systemd[1]: Reached target integritysetup.target - Local Integrity Protected Volumes.
2024-10-30T07:46:35,650684+00:00 systemd[1]: Reached target paths.target - Path Units.
2024-10-30T07:46:35,650716+00:00 systemd[1]: Reached target slices.target - Slice Units.
2024-10-30T07:46:35,650739+00:00 systemd[1]: Reached target swap.target - Swaps.
2024-10-30T07:46:35,650758+00:00 systemd[1]: Reached target veritysetup.target - Local Verity Protected Volumes.
2024-10-30T07:46:35,651367+00:00 systemd[1]: Listening on dm-event.socket - Device-mapper event daemon FIFOs.
2024-10-30T07:46:35,653090+00:00 systemd[1]: Listening on lvm2-lvmpolld.socket - LVM2 poll daemon socket.
2024-10-30T07:46:35,654910+00:00 systemd[1]: Listening on systemd-coredump.socket - Process Core Dump Socket.
2024-10-30T07:46:35,655053+00:00 systemd[1]: Listening on systemd-initctl.socket - initctl Compatibility Named Pipe.
2024-10-30T07:46:35,655327+00:00 systemd[1]: Listening on systemd-networkd.socket - Network Service Netlink Socket.
2024-10-30T07:46:35,656592+00:00 systemd[1]: Listening on systemd-udevd-control.socket - udev Control Socket.
2024-10-30T07:46:35,656958+00:00 systemd[1]: Listening on systemd-udevd-kernel.socket - udev Kernel Socket.
2024-10-30T07:46:35,657285+00:00 systemd[1]: Listening on systemd-userdbd.socket - User Database Manager Socket.
2024-10-30T07:46:35,658726+00:00 systemd[1]: Mounting dev-hugepages.mount - Huge Pages File System...
2024-10-30T07:46:35,660727+00:00 systemd[1]: Mounting dev-mqueue.mount - POSIX Message Queue File System...
2024-10-30T07:46:35,662729+00:00 systemd[1]: Mounting sys-kernel-debug.mount - Kernel Debug File System...
2024-10-30T07:46:35,666129+00:00 systemd[1]: Mounting sys-kernel-tracing.mount - Kernel Trace File System...
2024-10-30T07:46:35,668075+00:00 systemd[1]: Mounting tmp.mount - Temporary Directory /tmp...
2024-10-30T07:46:35,668186+00:00 systemd[1]: auth-rpcgss-module.service - Kernel Module supporting RPCSEC_GSS was skipped because of an unmet condition check (ConditionPathExists=/etc/krb5.keytab).
2024-10-30T07:46:35,670231+00:00 systemd[1]: Starting kmod-static-nodes.service - Create List of Static Device Nodes...
2024-10-30T07:46:35,672243+00:00 systemd[1]: Starting lvm2-monitor.service - Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2024-10-30T07:46:35,673625+00:00 systemd[1]: Starting modprobe@configfs.service - Load Kernel Module configfs...
2024-10-30T07:46:35,674947+00:00 systemd[1]: Starting modprobe@dm_mod.service - Load Kernel Module dm_mod...
2024-10-30T07:46:35,676366+00:00 systemd[1]: Starting modprobe@drm.service - Load Kernel Module drm...
2024-10-30T07:46:35,677699+00:00 systemd[1]: Starting modprobe@efi_pstore.service - Load Kernel Module efi_pstore...
2024-10-30T07:46:35,679185+00:00 systemd[1]: Starting modprobe@fuse.service - Load Kernel Module fuse...
2024-10-30T07:46:35,680652+00:00 systemd[1]: Starting modprobe@loop.service - Load Kernel Module loop...
2024-10-30T07:46:35,682048+00:00 systemd[1]: Starting nfs-convert.service - Preprocess NFS configuration convertion...
2024-10-30T07:46:35,689686+00:00 systemd[1]: Starting systemd-fsck-root.service - File System Check on Root Device...
2024-10-30T07:46:35,689803+00:00 systemd[1]: Stopped systemd-journald.service - Journal Service.
2024-10-30T07:46:35,692007+00:00 systemd[1]: Starting systemd-journald.service - Journal Service...
2024-10-30T07:46:35,694260+00:00 systemd[1]: Starting systemd-modules-load.service - Load Kernel Modules...
2024-10-30T07:46:35,695657+00:00 systemd[1]: Starting systemd-network-generator.service - Generate network units from Kernel command line...
2024-10-30T07:46:35,697104+00:00 systemd[1]: Starting systemd-udev-trigger.service - Coldplug All udev Devices...
2024-10-30T07:46:35,699052+00:00 systemd[1]: Mounted dev-hugepages.mount - Huge Pages File System.
2024-10-30T07:46:35,699152+00:00 systemd[1]: Mounted dev-mqueue.mount - POSIX Message Queue File System.
2024-10-30T07:46:35,699218+00:00 systemd[1]: Mounted sys-kernel-debug.mount - Kernel Debug File System.
2024-10-30T07:46:35,699285+00:00 systemd[1]: Mounted sys-kernel-tracing.mount - Kernel Trace File System.
2024-10-30T07:46:35,699349+00:00 systemd[1]: Mounted tmp.mount - Temporary Directory /tmp.
2024-10-30T07:46:35,702241+00:00 systemd[1]: Finished kmod-static-nodes.service - Create List of Static Device Nodes.
2024-10-30T07:46:35,702717+00:00 systemd[1]: modprobe@configfs.service: Deactivated successfully.
2024-10-30T07:46:35,702863+00:00 systemd[1]: Finished modprobe@configfs.service - Load Kernel Module configfs.
2024-10-30T07:46:35,703137+00:00 systemd[1]: modprobe@drm.service: Deactivated successfully.
2024-10-30T07:46:35,703278+00:00 systemd[1]: Finished modprobe@drm.service - Load Kernel Module drm.
2024-10-30T07:46:35,704315+00:00 systemd[1]: nfs-convert.service: Deactivated successfully.
2024-10-30T07:46:35,704494+00:00 systemd[1]: Finished nfs-convert.service - Preprocess NFS configuration convertion.
2024-10-30T07:46:35,706655+00:00 systemd[1]: Mounting sys-kernel-config.mount - Kernel Configuration File System...
2024-10-30T07:46:35,708596+00:00 systemd[1]: Mounted sys-kernel-config.mount - Kernel Configuration File System.
2024-10-30T07:46:35,714080+00:00 systemd[1]: modprobe@efi_pstore.service: Deactivated successfully.
2024-10-30T07:46:35,714234+00:00 systemd[1]: Finished modprobe@efi_pstore.service - Load Kernel Module efi_pstore.
2024-10-30T07:46:35,721071+00:00 systemd[1]: Finished systemd-modules-load.service - Load Kernel Modules.
2024-10-30T07:46:35,722599+00:00 systemd[1]: Starting systemd-sysctl.service - Apply Kernel Variables...
2024-10-30T07:46:35,723080+00:00 systemd[1]: Finished systemd-network-generator.service - Generate network units from Kernel command line.
2024-10-30T07:46:35,738262+00:00 fuse: init (API version 7.38)
2024-10-30T07:46:35,745824+00:00 systemd[1]: modprobe@fuse.service: Deactivated successfully.
2024-10-30T07:46:35,745991+00:00 systemd[1]: Finished modprobe@fuse.service - Load Kernel Module fuse.
2024-10-30T07:46:35,748910+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2024-10-30T07:46:35,750100+00:00 device-mapper: uevent: version 1.0.3
2024-10-30T07:46:35,751770+00:00 systemd[1]: Mounting sys-fs-fuse-connections.mount - FUSE Control File System...
2024-10-30T07:46:35,762875+00:00 systemd[1]: Mounted sys-fs-fuse-connections.mount - FUSE Control File System.
2024-10-30T07:46:35,764303+00:00 systemd[1]: Started systemd-journald.service - Journal Service.
2024-10-30T07:46:35,772556+00:00 device-mapper: ioctl: 4.47.0-ioctl (2022-07-28) initialised: dm-devel@redhat.com
2024-10-30T07:46:35,774269+00:00 loop: module loaded
2024-10-30T07:46:35,846199+00:00 systemd-journald[879]: Received client request to flush runtime journal.
2024-10-30T07:46:36,107771+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0C:00/input/input0
2024-10-30T07:46:36,112286+00:00 ACPI: button: Power Button [PWRB]
2024-10-30T07:46:36,112692+00:00 input: Sleep Button as /devices/LNXSYSTM:00/LNXSYBUS:00/PNP0C0E:00/input/input1
2024-10-30T07:46:36,113548+00:00 ACPI: button: Sleep Button [SLPB]
2024-10-30T07:46:36,129487+00:00 ACPI: \_SB_.PCI0.GSI1: Enabled at IRQ 36
2024-10-30T07:46:36,129953+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) v2.13.0g
2024-10-30T07:46:36,130470+00:00 ena 0000:00:05.0: enabling device (0010 -> 0012)
2024-10-30T07:46:36,142945+00:00 ena 0000:00:05.0: ENA device version: 0.10
2024-10-30T07:46:36,143422+00:00 ena 0000:00:05.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:46:36,243426+00:00 ena 0000:00:05.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:46:36,255184+00:00 ena 0000:00:05.0: Elastic Network Adapter (ENA) found at mem 80004000, mac addr 06:97:42:0c:f7:8f
2024-10-30T07:46:36,313572+00:00 ena 0000:00:05.0 ens5: renamed from eth0
2024-10-30T07:46:36,779309+00:00 RPC: Registered named UNIX socket transport module.
2024-10-30T07:46:36,779821+00:00 RPC: Registered udp transport module.
2024-10-30T07:46:36,780219+00:00 RPC: Registered tcp transport module.
2024-10-30T07:46:36,780598+00:00 RPC: Registered tcp NFSv4.1 backchannel transport module.
2024-10-30T07:46:36,986613+00:00 ena 0000:00:05.0 ens5: Local page cache is disabled for less than 16 channels
2024-10-30T07:47:04,529168+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:47:05,492422+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:47:05,536933+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eni412ec32df6d: link becomes ready
2024-10-30T07:47:07,401729+00:00 pci 0000:00:06.0: [1d0f:ec20] type 00 class 0x020000
2024-10-30T07:47:07,402310+00:00 pci 0000:00:06.0: reg 0x10: [mem 0x00000000-0x00003fff]
2024-10-30T07:47:07,403050+00:00 pci 0000:00:06.0: PME# supported from D0 D1 D2 D3hot D3cold
2024-10-30T07:47:07,403741+00:00 pci 0000:00:06.0: BAR 0: assigned [mem 0x8000c000-0x8000ffff]
2024-10-30T07:47:07,404434+00:00 ena 0000:00:06.0: enabling device (0000 -> 0002)
2024-10-30T07:47:07,416060+00:00 ena 0000:00:06.0: ENA device version: 0.10
2024-10-30T07:47:07,416499+00:00 ena 0000:00:06.0: ENA controller version: 0.0.1 implementation version 1
2024-10-30T07:47:07,496934+00:00 ena 0000:00:06.0: LLQ is not supported Fallback to host mode policy.
2024-10-30T07:47:07,508200+00:00 ena 0000:00:06.0: Elastic Network Adapter (ENA) found at mem 8000c000, mac addr 06:20:66:42:9e:cb
2024-10-30T07:47:07,557153+00:00 ena 0000:00:06.0 ens6: renamed from eth0
2024-10-30T07:47:07,906134+00:00 ena 0000:00:06.0 ens6: Local page cache is disabled for less than 16 channels
2024-10-30T07:53:08,387211+00:00 Initializing XFRM netlink socket
2024-10-30T07:53:08,817408+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cilium_host: link becomes ready
2024-10-30T07:53:09,778468+00:00 cilium_vxlan: Caught tx_queue_len zero misconfig
2024-10-30T07:53:10,947574+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc_health: link becomes ready
2024-10-30T07:53:11,922428+00:00 eth0: renamed from tmp1ee31
2024-10-30T07:53:11,978064+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcc232c477114a: link becomes ready
2024-10-30T07:53:12,023968+00:00 eth0: renamed from tmp1fd8b
2024-10-30T07:53:12,062880+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxcc189d536d5e0: link becomes ready
2024-10-30T07:58:50,137464+00:00 eth0: renamed from tmpa8414
2024-10-30T07:58:50,177412+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T07:58:50,177964+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc7ecd6902bb68: link becomes ready
2024-10-30T08:11:53,986416+00:00 eth0: renamed from tmpf66c0
2024-10-30T08:11:54,036189+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): eth0: link becomes ready
2024-10-30T08:11:54,036742+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): lxc7d5f008c0ff6: link becomes ready
2024-10-30T08:23:00,827058+00:00 printk: dmesg (7848): Attempt to access syslog with CAP_SYS_ADMIN but no CAP_SYSLOG (deprecated).
