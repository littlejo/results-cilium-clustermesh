[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-e12cbb953a21374127902256df0ef3ace5f0074df7f4c783b73c36b1aa9b5ec4.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-f1920b1292723b44a65dec75d5da22cb9ce544876b539261b972471e00fcb610.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-46a52c431db77af4b63a4537683d6092ae95154afbc4eddfc1a9caf88105ae24.scope"
      }
    ],
    "ips": [
      "10.86.0.21"
    ],
    "name": "clustermesh-apiserver-7dbf7d8b58-t7bzb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e8db729_835a_4c05_ad13_4140ef0e9d4c.slice/cri-containerd-2464bd9b2aae788931de63ed9adf66fcec1549b08ec7cba68167f05186ac5c9c.scope"
      }
    ],
    "ips": [
      "10.86.0.246"
    ],
    "name": "coredns-cc6ccd49c-lc5td",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc40bf52_b965_4005_ac50_a9bcef6cee34.slice/cri-containerd-942858d564c4aa0e83e4f6c89770b8cb0b3353fae6d217b7cbf5f023b000b070.scope"
      }
    ],
    "ips": [
      "10.86.0.97"
    ],
    "name": "coredns-cc6ccd49c-4g8pk",
    "namespace": "kube-system"
  }
]

