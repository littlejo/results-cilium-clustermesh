xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 553
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 539
lxcc232c477114a(12) clsact/ingress cil_from_container-lxcc232c477114a id 523
lxcc189d536d5e0(14) clsact/ingress cil_from_container-lxcc189d536d5e0 id 506
lxc7d5f008c0ff6(18) clsact/ingress cil_from_container-lxc7d5f008c0ff6 id 621

flow_dissector:

netfilter:

