ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.254.143:443 (active)    
                                         2 => 172.31.177.74:443 (active)     
2    10.100.82.73:443     ClusterIP      1 => 172.31.162.134:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.86.0.97:53 (active)         
                                         2 => 10.86.0.246:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.86.0.97:9153 (active)       
                                         2 => 10.86.0.246:9153 (active)      
5    10.100.172.52:2379   ClusterIP      1 => 10.86.0.21:2379 (active)       
