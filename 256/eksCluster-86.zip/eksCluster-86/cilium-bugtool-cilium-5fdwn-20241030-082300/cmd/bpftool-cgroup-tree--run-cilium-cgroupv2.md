CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e8db729_835a_4c05_ad13_4140ef0e9d4c.slice/cri-containerd-1fd8b71d4c8ed355c0e1598294e6d03d6bfb5775fec50276ca5fa078d43fc046.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e8db729_835a_4c05_ad13_4140ef0e9d4c.slice/cri-containerd-2464bd9b2aae788931de63ed9adf66fcec1549b08ec7cba68167f05186ac5c9c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc40bf52_b965_4005_ac50_a9bcef6cee34.slice/cri-containerd-942858d564c4aa0e83e4f6c89770b8cb0b3353fae6d217b7cbf5f023b000b070.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc40bf52_b965_4005_ac50_a9bcef6cee34.slice/cri-containerd-1ee31a8b3c21a2ebfda6e57c688b531df602607527acaa5dd9aab5ed97936488.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ca4fce3_0c0e_41d5_b6fe_463f5cc15905.slice/cri-containerd-fcec2e0d9b3f3d73fbcea877d5990c4ea7730da585100cacb37904add896669b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ca4fce3_0c0e_41d5_b6fe_463f5cc15905.slice/cri-containerd-fee26b0e188c2bada0fdcb7f6d8d0ba44927694a616aeaa4cc4a5c74daaf5652.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c646c9a_1e29_4466_a8aa_b30bc281cdc4.slice/cri-containerd-4f5c33b03b99693ab592a34deb924f1857a2df0345a24661ec7e72bf5596456e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c646c9a_1e29_4466_a8aa_b30bc281cdc4.slice/cri-containerd-25c7aef16edba5b395be68ee0a439a161a1a54db3850e0863f976fd384a23795.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-f66c003aecb7dbf12eea9b3daa2d6f7fab88d1904e51261958cedbfed23a6817.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-f1920b1292723b44a65dec75d5da22cb9ce544876b539261b972471e00fcb610.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-e12cbb953a21374127902256df0ef3ace5f0074df7f4c783b73c36b1aa9b5ec4.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1a426f1d_62d5_4567_a5ac_92f83adf0d5f.slice/cri-containerd-46a52c431db77af4b63a4537683d6092ae95154afbc4eddfc1a9caf88105ae24.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c7dfa15_59ba_4128_9749_93a15d93e8cf.slice/cri-containerd-37fced2d63dc2ecd604a38e8a030bc192c8c543cb37137b9af0c6f91830adeb3.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2c7dfa15_59ba_4128_9749_93a15d93e8cf.slice/cri-containerd-228a719ab777cbd1bdcaaed8de900550486e118ebbd3480c7f6af904a9fed272.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d891b8c_5b2d_4e6f_babe_b2bfcd71fa49.slice/cri-containerd-ec9fe1e1385749135b075e5e0ec4a19b00c29af75f8a221f3c0675bf9c65b19e.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d891b8c_5b2d_4e6f_babe_b2bfcd71fa49.slice/cri-containerd-696fe63c6b489177007d7117ba249b7e0783feeed31f02d022732ffaa775728e.scope
    87       cgroup_device   multi                                          
