alloc: 123.85MB (129863136 bytes)
total-alloc: 2.30GB (2466212072 bytes)
sys: 312.77MB (327962980 bytes)
lookups: 0
mallocs: 64493589
frees: 63381000
heap-alloc: 123.85MB (129863136 bytes)
heap-sys: 235.70MB (247144448 bytes)
heap-idle: 67.63MB (70918144 bytes)
heap-in-use: 168.06MB (176226304 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 1112589
stack-in-use: 64.28MB (67403776 bytes)
stack-sys: 64.28MB (67403776 bytes)
stack-mspan-inuse: 2.87MB (3008320 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 930.22KB (952545 bytes)
gc-sys: 6.02MB (6311448 bytes)
next-gc: when heap-alloc >= 214.27MB (224682248 bytes)
last-gc: 2024-10-30 08:23:14.271883695 +0000 UTC
gc-pause-total: 21.218069ms
gc-pause: 92244
gc-pause-end: 1730276594271883695
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00032843022951057585
enable-gc: true
debug-gc: false
