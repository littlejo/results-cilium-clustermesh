IP ADDRESS         LOCAL ENDPOINT INFO
172.31.162.134:0   (localhost)                                                                                        
10.86.0.21:0       id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01   
10.86.0.33:0       (localhost)                                                                                        
10.86.0.246:0      id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34   
10.86.0.89:0       id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41     
10.86.0.97:0       id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70   
172.31.185.31:0    (localhost)                                                                                        
