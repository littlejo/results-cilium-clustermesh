USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         657  0.0  0.2 1240432 16152 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         685  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         686  0.0  0.0   3852  1292 ?        R    08:23   0:00  \_ bash -c hostname
root           1  2.6  4.8 1606080 386036 ?      Ssl  07:53   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         401  0.0  0.1 1229744 8088 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
