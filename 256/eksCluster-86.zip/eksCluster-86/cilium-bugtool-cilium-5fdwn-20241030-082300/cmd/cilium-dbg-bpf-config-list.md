KEY             VALUE
AgentLiveness   2219914314805
UTimeOffset     3379442173828125
