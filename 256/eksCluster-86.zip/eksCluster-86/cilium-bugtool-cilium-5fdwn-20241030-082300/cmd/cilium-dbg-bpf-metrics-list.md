REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35768     2823145     677    bpf_overlay.c
Interface                 INGRESS     634091    131259113   1132   bpf_host.c
Success                   EGRESS      15293     1199396     1694   bpf_host.c
Success                   EGRESS      20400     3233000     86     l3.h
Success                   EGRESS      266641    33705886    1308   bpf_lxc.c
Success                   EGRESS      35134     2781499     53     encap.h
Success                   INGRESS     308523    34698268    86     l3.h
Success                   INGRESS     350049    39599063    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
