key: 4e 01 00 00  value: 1f 02 00 00
key: 8c 03 00 00  value: 6c 02 00 00
key: a3 0a 00 00  value: 05 02 00 00
key: bb 0e 00 00  value: f8 01 00 00
Found 4 elements
