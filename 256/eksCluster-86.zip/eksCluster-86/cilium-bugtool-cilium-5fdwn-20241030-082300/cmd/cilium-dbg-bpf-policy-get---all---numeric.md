Endpoint ID: 334
Path: /sys/fs/bpf/tc/globals/cilium_policy_00334

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1674889   21215     0        
Allow    Ingress     1          ANY          NONE         disabled    26144     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 688
Path: /sys/fs/bpf/tc/globals/cilium_policy_00688

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 908
Path: /sys/fs/bpf/tc/globals/cilium_policy_00908

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11442064   112705    0        
Allow    Ingress     1          ANY          NONE         disabled    9470672    99306     0        
Allow    Egress      0          ANY          NONE         disabled    11594255   115201    0        


Endpoint ID: 2723
Path: /sys/fs/bpf/tc/globals/cilium_policy_02723

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    574094   5161      0        
Allow    Ingress     1          ANY          NONE         disabled    174810   2015      0        
Allow    Egress      0          ANY          NONE         disabled    123487   1194      0        


Endpoint ID: 3771
Path: /sys/fs/bpf/tc/globals/cilium_policy_03771

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    561986   5039      0        
Allow    Ingress     1          ANY          NONE         disabled    174971   2012      0        
Allow    Egress      0          ANY          NONE         disabled    122643   1182      0        


