{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.340Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.162.134:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.340Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.185.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:11.340Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.748Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.759Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.803Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.843Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:15.959Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:50.769Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:50.769Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:50.770Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:50.798Z",
  "value": "id=2756  sec_id=2859463 flags=0x0000 ifindex=16  mac=06:39:0C:3A:62:79 nodemac=E6:63:E7:D3:4E:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:50.799Z",
  "value": "id=2756  sec_id=2859463 flags=0x0000 ifindex=16  mac=06:39:0C:3A:62:79 nodemac=E6:63:E7:D3:4E:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:51.768Z",
  "value": "id=2756  sec_id=2859463 flags=0x0000 ifindex=16  mac=06:39:0C:3A:62:79 nodemac=E6:63:E7:D3:4E:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:51.768Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:51.768Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:51.769Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.673Z",
  "value": "id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.86.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.230Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.883Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.884Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.884Z",
  "value": "id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.885Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.884Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.885Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.885Z",
  "value": "id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.885Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.883Z",
  "value": "id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.884Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.884Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.885Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.885Z",
  "value": "id=2723  sec_id=2871246 flags=0x0000 ifindex=12  mac=BE:C8:52:87:E0:D8 nodemac=22:13:B8:02:3A:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.885Z",
  "value": "id=334   sec_id=4     flags=0x0000 ifindex=10  mac=D6:51:BD:68:57:17 nodemac=BA:A2:1C:38:D5:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.885Z",
  "value": "id=908   sec_id=2859463 flags=0x0000 ifindex=18  mac=1E:A9:AF:8A:56:D8 nodemac=9A:62:F8:B7:3E:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.86.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.885Z",
  "value": "id=3771  sec_id=2871246 flags=0x0000 ifindex=14  mac=FE:EC:83:82:FD:42 nodemac=DA:B9:A8:0A:43:34"
}

