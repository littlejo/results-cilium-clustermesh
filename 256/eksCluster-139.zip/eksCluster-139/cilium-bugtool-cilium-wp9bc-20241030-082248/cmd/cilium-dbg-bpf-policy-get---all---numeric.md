Endpoint ID: 745
Path: /sys/fs/bpf/tc/globals/cilium_policy_00745

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11516347   115921    0        
Allow    Ingress     1          ANY          NONE         disabled    10667353   112644    0        
Allow    Egress      0          ANY          NONE         disabled    14448751   141073    0        


Endpoint ID: 862
Path: /sys/fs/bpf/tc/globals/cilium_policy_00862

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1635436   20632     0        
Allow    Ingress     1          ANY          NONE         disabled    19672     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1781
Path: /sys/fs/bpf/tc/globals/cilium_policy_01781

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2155
Path: /sys/fs/bpf/tc/globals/cilium_policy_02155

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130477   1494      0        
Allow    Egress      0          ANY          NONE         disabled    17210    188       0        


Endpoint ID: 2613
Path: /sys/fs/bpf/tc/globals/cilium_policy_02613

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130934   1505      0        
Allow    Egress      0          ANY          NONE         disabled    18437    201       0        


