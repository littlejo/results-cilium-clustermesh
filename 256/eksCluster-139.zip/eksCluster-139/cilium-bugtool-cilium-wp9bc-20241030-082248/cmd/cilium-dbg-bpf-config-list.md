KEY             VALUE
AgentLiveness   1999426180293
UTimeOffset     3379442580078125
