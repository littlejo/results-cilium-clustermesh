IP ADDRESS         LOCAL ENDPOINT INFO
10.139.0.242:0     (localhost)                                                                                        
10.139.0.91:0      id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E   
10.139.0.171:0     id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF   
10.139.0.115:0     id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16     
10.139.0.27:0      id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55   
172.31.192.199:0   (localhost)                                                                                        
172.31.245.95:0    (localhost)                                                                                        
