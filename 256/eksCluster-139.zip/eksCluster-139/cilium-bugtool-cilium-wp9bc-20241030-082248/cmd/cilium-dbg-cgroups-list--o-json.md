[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-bf5ac00ce1ed66c0b7a04539aa44259782327197909e55a6ee9b328a378312b9.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-b118841e86dff6da0d6efccd2454abadc50dfd4adcac0e09144b37c680b7a75c.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-9b3e07adfc6e25cd1b854ae4766ad4b17b202558dd8d3f6550e4a921a7448b21.scope"
      }
    ],
    "ips": [
      "10.139.0.91"
    ],
    "name": "clustermesh-apiserver-9f69ffdd4-svfsx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda83f5ee2_f5be_47f1_9b8c_18cb926928db.slice/cri-containerd-50f67a4c1bd37f09eddbeb86ee73f6c32ac2879676cbb0a7280324e3ce6ecaf4.scope"
      }
    ],
    "ips": [
      "10.139.0.171"
    ],
    "name": "coredns-cc6ccd49c-bwb59",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62a3c180_8046_4cbd_88ef_ccbce9629a40.slice/cri-containerd-0e3375b941d3839fb501753a86c189a7902a297ed140bad30a458eb0c1833181.scope"
      }
    ],
    "ips": [
      "10.139.0.27"
    ],
    "name": "coredns-cc6ccd49c-7ckh6",
    "namespace": "kube-system"
  }
]

