{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:26.866Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:26.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:26.867Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.455Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.462Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.527Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.590Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.668Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.059Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.060Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.060Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.092Z",
  "value": "id=1550  sec_id=4589942 flags=0x0000 ifindex=16  mac=46:27:82:71:FE:CA nodemac=F6:2E:19:61:5A:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.094Z",
  "value": "id=1550  sec_id=4589942 flags=0x0000 ifindex=16  mac=46:27:82:71:FE:CA nodemac=F6:2E:19:61:5A:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.451Z",
  "value": "id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.139.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.805Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.112Z",
  "value": "id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.113Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.113Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.113Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.111Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.111Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.111Z",
  "value": "id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.112Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.112Z",
  "value": "id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.112Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.112Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.113Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.112Z",
  "value": "id=2613  sec_id=4589552 flags=0x0000 ifindex=14  mac=62:0A:52:AE:DD:5D nodemac=26:E2:0D:87:2E:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.112Z",
  "value": "id=862   sec_id=4     flags=0x0000 ifindex=10  mac=82:78:03:09:3B:82 nodemac=9A:38:30:59:62:16"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.112Z",
  "value": "id=2155  sec_id=4589552 flags=0x0000 ifindex=12  mac=82:32:78:5C:0A:AC nodemac=12:1C:36:0D:F7:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.139.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.112Z",
  "value": "id=745   sec_id=4589942 flags=0x0000 ifindex=18  mac=6A:3A:80:A8:A4:FB nodemac=2E:7D:4A:F1:39:9E"
}

