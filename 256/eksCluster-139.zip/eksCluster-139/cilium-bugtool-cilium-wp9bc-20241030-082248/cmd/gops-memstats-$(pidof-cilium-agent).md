alloc: 171.18MB (179497096 bytes)
total-alloc: 2.31GB (2475599056 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64417544
frees: 62446999
heap-alloc: 171.18MB (179497096 bytes)
heap-sys: 243.76MB (255598592 bytes)
heap-idle: 50.98MB (53452800 bytes)
heap-in-use: 192.78MB (202145792 bytes)
heap-released: 968.00KB (991232 bytes)
heap-objects: 1970545
stack-in-use: 64.22MB (67338240 bytes)
stack-sys: 64.22MB (67338240 bytes)
stack-mspan-inuse: 3.26MB (3414720 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1080345 bytes)
gc-sys: 5.98MB (6268272 bytes)
next-gc: when heap-alloc >= 214.72MB (225145400 bytes)
last-gc: 2024-10-30 08:22:49.852786311 +0000 UTC
gc-pause-total: 11.082483ms
gc-pause: 2540725
gc-pause-end: 1730276569852786311
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00048481177080274767
enable-gc: true
debug-gc: false
