CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62a3c180_8046_4cbd_88ef_ccbce9629a40.slice/cri-containerd-1dc545c8d9233686b4d3399fd9209723e8cda290eb60243c433a4b776504f433.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62a3c180_8046_4cbd_88ef_ccbce9629a40.slice/cri-containerd-0e3375b941d3839fb501753a86c189a7902a297ed140bad30a458eb0c1833181.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79e3ab8a_77a7_4f35_9db1_4d361aef28d3.slice/cri-containerd-13b4c38278d5709e6dad74f0b27220c3ea6b144222cf3a5cd0de2c27c4c15b14.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod79e3ab8a_77a7_4f35_9db1_4d361aef28d3.slice/cri-containerd-68d106bcef8ae47118043c123505f14d1015d6b59b677067586a24132ae9d3d9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda83f5ee2_f5be_47f1_9b8c_18cb926928db.slice/cri-containerd-45c07446f78f8275e19c79f60ecb3af05e6ba6a848876b54bf902edd625b78cf.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda83f5ee2_f5be_47f1_9b8c_18cb926928db.slice/cri-containerd-50f67a4c1bd37f09eddbeb86ee73f6c32ac2879676cbb0a7280324e3ce6ecaf4.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9ad6c64_90d2_490d_afd0_5eebf29b4531.slice/cri-containerd-ab9a83685ef17f2e39b0baad043588e589b59051d4e8b6f9e0de950e8a1c4048.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9ad6c64_90d2_490d_afd0_5eebf29b4531.slice/cri-containerd-aaf9e34e8f02af673cc940d32241dda8f45c83dfd463b6c263ec7f3dcfa609a9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-b118841e86dff6da0d6efccd2454abadc50dfd4adcac0e09144b37c680b7a75c.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-9b3e07adfc6e25cd1b854ae4766ad4b17b202558dd8d3f6550e4a921a7448b21.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-bf5ac00ce1ed66c0b7a04539aa44259782327197909e55a6ee9b328a378312b9.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod755adb32_ac90_40ca_a13e_ea6595878f88.slice/cri-containerd-57b04367a9bb7444fb50049a58a14b81d7a561b7bb91a08cc166d8c0a32f7095.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7939531a_679e_4fc9_9df1_13e205e0332c.slice/cri-containerd-7c1c5e56349a0e9b724aaca9382661d9170293e3167e01695eccc1e3f991391b.scope
    117      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7939531a_679e_4fc9_9df1_13e205e0332c.slice/cri-containerd-400503f41ca5625a25409168e31aa4d26faadfaad8dbf328554c055b3d01c342.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode57a623c_2a10_445c_a282_31b46885683d.slice/cri-containerd-a1a5a324a9e8ce4fe66ada61fcda91331d370175d4fe13ac439897773aa02c55.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode57a623c_2a10_445c_a282_31b46885683d.slice/cri-containerd-86f4277ab2ace94d9f574fe9df2183e79e99150e462329542dd77624c6383729.scope
    105      cgroup_device   multi                                          
