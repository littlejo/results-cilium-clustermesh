1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ee:e2:5a:53:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.192.199/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3445sec preferred_lft 3445sec
    inet6 fe80::8ee:e2ff:fe5a:5395/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:cb:6f:8b:86:65 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8cb:6fff:fe8b:8665/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:95:23:8b:d4:0b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c95:23ff:fe8b:d40b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:c3:32:ca:b5:d9 brd ff:ff:ff:ff:ff:ff
    inet 10.139.0.242/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::bcc3:32ff:feca:b5d9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:23:5a:2b:cb:2d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d823:5aff:fe2b:cb2d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:38:30:59:62:16 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9838:30ff:fe59:6216/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc876ca6f074d3@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:1c:36:0d:f7:ef brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::101c:36ff:fe0d:f7ef/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf756b1eb114e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:e2:0d:87:2e:55 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::24e2:dff:fe87:2e55/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9546b3c2647d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:7d:4a:f1:39:9e brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2c7d:4aff:fef1:399e/64 scope link 
       valid_lft forever preferred_lft forever
