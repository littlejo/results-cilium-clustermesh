key: e9 02 00 00  value: 7b 02 00 00
key: 5e 03 00 00  value: 0c 02 00 00
key: 6b 08 00 00  value: 1b 02 00 00
key: 35 0a 00 00  value: 01 02 00 00
Found 4 elements
