ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.145.87:443 (active)     
                                         2 => 172.31.197.26:443 (active)     
2    10.100.165.232:443   ClusterIP      1 => 172.31.192.199:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.139.0.171:53 (active)       
                                         2 => 10.139.0.27:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.139.0.171:9153 (active)     
                                         2 => 10.139.0.27:9153 (active)      
5    10.100.234.72:2379   ClusterIP      1 => 10.139.0.91:2379 (active)      
