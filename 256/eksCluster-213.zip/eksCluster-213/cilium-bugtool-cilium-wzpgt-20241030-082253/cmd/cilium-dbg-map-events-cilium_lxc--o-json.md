{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.506Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.205.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.506Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.205.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.506Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:15.659Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.104Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.111Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.187Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.199Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:51.785Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:51.786Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:51.787Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:51.818Z",
  "value": "id=2722  sec_id=7043716 flags=0x0000 ifindex=16  mac=A6:D2:4F:0F:7E:E6 nodemac=FA:5E:76:F4:EC:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:51.819Z",
  "value": "id=2722  sec_id=7043716 flags=0x0000 ifindex=16  mac=A6:D2:4F:0F:7E:E6 nodemac=FA:5E:76:F4:EC:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.786Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.787Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.787Z",
  "value": "id=2722  sec_id=7043716 flags=0x0000 ifindex=16  mac=A6:D2:4F:0F:7E:E6 nodemac=FA:5E:76:F4:EC:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.787Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.087Z",
  "value": "id=217   sec_id=7043716 flags=0x0000 ifindex=18  mac=FE:39:D0:E3:6A:CD nodemac=66:5F:FF:CE:FC:C3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.213.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.373Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.649Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.650Z",
  "value": "id=217   sec_id=7043716 flags=0x0000 ifindex=18  mac=FE:39:D0:E3:6A:CD nodemac=66:5F:FF:CE:FC:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.651Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.651Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.641Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.641Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.642Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.642Z",
  "value": "id=217   sec_id=7043716 flags=0x0000 ifindex=18  mac=FE:39:D0:E3:6A:CD nodemac=66:5F:FF:CE:FC:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.642Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.642Z",
  "value": "id=217   sec_id=7043716 flags=0x0000 ifindex=18  mac=FE:39:D0:E3:6A:CD nodemac=66:5F:FF:CE:FC:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.642Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.642Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.642Z",
  "value": "id=2359  sec_id=7042248 flags=0x0000 ifindex=12  mac=5A:A7:4A:68:9B:DB nodemac=F6:B1:C8:AA:36:BA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.642Z",
  "value": "id=217   sec_id=7043716 flags=0x0000 ifindex=18  mac=FE:39:D0:E3:6A:CD nodemac=66:5F:FF:CE:FC:C3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.643Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=D2:36:E4:D7:6B:E6 nodemac=FA:BC:89:5B:48:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.213.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:26.643Z",
  "value": "id=1795  sec_id=7042248 flags=0x0000 ifindex=14  mac=2E:0B:E5:39:3B:21 nodemac=6A:0D:5C:B8:5D:8D"
}

