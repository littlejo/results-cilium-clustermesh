Endpoint ID: 217
Path: /sys/fs/bpf/tc/globals/cilium_policy_00217

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11581480   116434    0        
Allow    Ingress     1          ANY          NONE         disabled    11158805   117975    0        
Allow    Egress      0          ANY          NONE         disabled    14468949   141123    0        


Endpoint ID: 472
Path: /sys/fs/bpf/tc/globals/cilium_policy_00472

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 898
Path: /sys/fs/bpf/tc/globals/cilium_policy_00898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1654010   20869     0        
Allow    Ingress     1          ANY          NONE         disabled    18772     222       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1795
Path: /sys/fs/bpf/tc/globals/cilium_policy_01795

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115135   1319      0        
Allow    Egress      0          ANY          NONE         disabled    16383    176       0        


Endpoint ID: 2359
Path: /sys/fs/bpf/tc/globals/cilium_policy_02359

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114937   1316      0        
Allow    Egress      0          ANY          NONE         disabled    16664    180       0        


