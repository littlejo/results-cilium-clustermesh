xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 563
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 498
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 497
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 594
lxc63a33539481b(12) clsact/ingress cil_from_container-lxc63a33539481b id 591
lxcc0a0b678820a(14) clsact/ingress cil_from_container-lxcc0a0b678820a id 531
lxc332774ccf737(18) clsact/ingress cil_from_container-lxc332774ccf737 id 653

flow_dissector:

netfilter:

