 08:22:54 up 29 min,  0 users,  load average: 0.32, 0.36, 0.28
