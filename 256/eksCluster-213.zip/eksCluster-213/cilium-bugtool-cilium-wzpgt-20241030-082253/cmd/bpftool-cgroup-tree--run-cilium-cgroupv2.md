CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2fd1ad81_a7c9_4db5_8dce_87b589e28651.slice/cri-containerd-1d1023ce9ae2dfe8101d4f1e9d4e04c768b3baf304ea8f3c275409244a6d9cc9.scope
    604      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2fd1ad81_a7c9_4db5_8dce_87b589e28651.slice/cri-containerd-73affef7b798e01b05c9b35c9b15dad6ddd504328544be571fd360b060396a62.scope
    608      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0791d7d4_c481_41ac_8c90_e00e86936205.slice/cri-containerd-e636172ad680017a98a8dc669f28acb7ace19575d96a5165a765c1e8ecdff9eb.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0791d7d4_c481_41ac_8c90_e00e86936205.slice/cri-containerd-f72131630b23f8e228cc3640095a9913e7f157608eed7c8cab1ec78177fba01a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcaab42d_6fcb_4a8d_b3c1_03f04c831e6b.slice/cri-containerd-585329667a1396c2738c67790f460f1e909d2466242595f6d452c7683fe3d2a6.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcaab42d_6fcb_4a8d_b3c1_03f04c831e6b.slice/cri-containerd-d06736d73153811ac85b9fd8626de84a2ab4a3537d16c3f908cf1736c89a62f4.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ea3a4f0_c76d_4e02_bca8_be56c45b5870.slice/cri-containerd-7f539f3a408b63bfbfdf552b3f7fb7098b3e10b8dc1b13afd9824b8c6d7d974d.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ea3a4f0_c76d_4e02_bca8_be56c45b5870.slice/cri-containerd-5773d15901085fa2ea4db1df4d8e80e4ca1255e1229b9d5842215d029c90ac23.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod373d37ce_ff53_4264_8af6_b4434d752df5.slice/cri-containerd-41d3ed31797ff56c11d7c0066672ee23425265fbcfae7c40cee677a708152910.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod373d37ce_ff53_4264_8af6_b4434d752df5.slice/cri-containerd-338019bde58370993187f23271c06b7e79c0462786398c96ca8968f6b77d8ace.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8dc8c18d_263e_43e6_8ca7_f75335bc9414.slice/cri-containerd-646f701f5003e4e7fbdcc6a9d66ad43631ecd874a4b42569ca5254f697b39e1f.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8dc8c18d_263e_43e6_8ca7_f75335bc9414.slice/cri-containerd-e4fce5d7833228d21f746a55650e0e7bc4e240748065e0c7cfa3d4f8016895e6.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-a3cebebf106e72eac214ce0684227c7b0c75a205550d206e59aa5c72c80c8a75.scope
    686      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-bb9371d26b61cdede504fc2b0f3acefb407746cc0a7689647e298fb2de58ef35.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-875bf1f609b8723971477a140efc631148cf378c3395c8888609295353210398.scope
    682      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-1f3b6a3e569020c7d481e9eb2845d197ccbfee3159b7feb27d9f3abdbcf55f32.scope
    662      cgroup_device   multi                                          
