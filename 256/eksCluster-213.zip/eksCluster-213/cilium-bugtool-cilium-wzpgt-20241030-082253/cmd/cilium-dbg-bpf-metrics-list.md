REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37771     2997588     677    bpf_overlay.c
Interface                 INGRESS     670360    135336638   1132   bpf_host.c
Success                   EGRESS      17618     1392762     1694   bpf_host.c
Success                   EGRESS      286514    35550669    1308   bpf_lxc.c
Success                   EGRESS      38737     3066777     53     encap.h
Success                   INGRESS     331069    37527527    86     l3.h
Success                   INGRESS     351873    39176399    235    trace.h
Unsupported L3 protocol   EGRESS      39        2902        1492   bpf_lxc.c
