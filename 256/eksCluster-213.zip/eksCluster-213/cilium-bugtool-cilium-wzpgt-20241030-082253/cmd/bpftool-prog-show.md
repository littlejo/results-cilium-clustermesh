29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:53:36+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:53:37+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:53:41+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:53:53+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
104: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
107: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
492: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
496: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
497: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:16+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 136
498: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:16+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
499: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
500: sched_cls  name tail_handle_ipv4  tag a5a7ff3ac23e5a13  gpl
	loaded_at 2024-10-30T08:03:16+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 139
530: sched_cls  name tail_ipv4_ct_ingress  tag 1531e21d22a5ec97  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,118,84
	btf_id 175
531: sched_cls  name cil_from_container  tag 0bc052cd33899409  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 177
533: sched_cls  name __send_drop_notify  tag b45289ee30b48f56  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
538: sched_cls  name tail_ipv4_to_endpoint  tag 11b930cfce5c97fc  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,118,41,82,83,80,114,39,116,40,37,38
	btf_id 180
539: sched_cls  name tail_ipv4_ct_egress  tag b600ff54766a603b  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,118,84
	btf_id 185
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 186
544: sched_cls  name tail_handle_ipv4  tag 273a83de7164300b  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 188
548: sched_cls  name handle_policy  tag d02fe8041ee67636  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,118,41,80,114,39,84,75,40,37,38
	btf_id 193
549: sched_cls  name tail_handle_arp  tag e35eaf8e79b220a4  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
550: sched_cls  name tail_handle_ipv4_cont  tag e90e737708e90625  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,118,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 197
551: sched_cls  name tail_ipv4_to_endpoint  tag 298b808f138cf0bc  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,119,41,82,83,80,91,39,120,40,37,38
	btf_id 195
553: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
554: sched_cls  name __send_drop_notify  tag b26b4dbdc3b9daf2  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
555: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,121
	btf_id 202
557: sched_cls  name tail_handle_ipv4_from_host  tag 81b7fbfd4b9d3cdd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 204
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 205
560: sched_cls  name tail_handle_ipv4_from_host  tag 81b7fbfd4b9d3cdd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 208
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 210
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 212
564: sched_cls  name __send_drop_notify  tag b26b4dbdc3b9daf2  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
566: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,120
	btf_id 209
569: sched_cls  name tail_handle_ipv4_from_host  tag 81b7fbfd4b9d3cdd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 219
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 220
571: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 221
573: sched_cls  name __send_drop_notify  tag b26b4dbdc3b9daf2  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 223
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,128
	btf_id 225
575: sched_cls  name tail_handle_ipv4  tag 07271b2b2eeba4b9  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,120
	btf_id 215
576: sched_cls  name tail_ipv4_ct_egress  tag b600ff54766a603b  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,119,84
	btf_id 226
577: sched_cls  name tail_handle_arp  tag e6bcc3230149449e  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,120
	btf_id 228
578: sched_cls  name __send_drop_notify  tag 9d383d4a28f77a75  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
580: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,128,75
	btf_id 227
582: sched_cls  name __send_drop_notify  tag b26b4dbdc3b9daf2  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
585: sched_cls  name tail_handle_ipv4_from_host  tag 81b7fbfd4b9d3cdd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,128
	btf_id 236
586: sched_cls  name tail_handle_ipv4  tag d480de8fc2b3bc57  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,129
	btf_id 238
587: sched_cls  name handle_policy  tag a267c9ae17f83f8e  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,120,82,83,119,41,80,91,39,84,75,40,37,38
	btf_id 231
588: sched_cls  name tail_handle_ipv4_cont  tag 16d32dea679b0fc7  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,130,41,105,82,83,39,76,74,77,129,40,37,38,81
	btf_id 239
590: sched_cls  name tail_handle_arp  tag 32b53ffe23ed48c4  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,129
	btf_id 241
591: sched_cls  name cil_from_container  tag 8361586abfc516c5  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 120,76
	btf_id 243
592: sched_cls  name tail_handle_ipv4_cont  tag 1f43283740f3d662  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,119,41,91,82,83,39,76,74,77,120,40,37,38,81
	btf_id 244
593: sched_cls  name handle_policy  tag 5ef8c7825db41e6a  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,129,82,83,130,41,80,105,39,84,75,40,37,38
	btf_id 242
594: sched_cls  name cil_from_container  tag 5f873025ded4e437  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 129,76
	btf_id 245
595: sched_cls  name __send_drop_notify  tag fec0c8eb15967c4d  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 247
596: sched_cls  name tail_ipv4_ct_ingress  tag b9299676cdb1ad44  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,120,82,83,119,84
	btf_id 246
597: sched_cls  name tail_ipv4_to_endpoint  tag 101027eb3ee4fa7d  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,130,41,82,83,80,105,39,129,40,37,38
	btf_id 248
598: sched_cls  name tail_ipv4_ct_ingress  tag 58bfe601d12b94d3  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,129,82,83,130,84
	btf_id 249
599: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,129,82,83,130,84
	btf_id 250
600: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,129
	btf_id 251
601: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
604: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
605: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
608: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
648: sched_cls  name __send_drop_notify  tag 6751c17f8b950e1e  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 265
649: sched_cls  name tail_handle_ipv4  tag f21cf805795e5f32  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,144
	btf_id 266
650: sched_cls  name tail_ipv4_to_endpoint  tag 465f6d62e93c25c2  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,145,41,82,83,80,143,39,144,40,37,38
	btf_id 267
651: sched_cls  name tail_ipv4_ct_ingress  tag 78118854bdd1441b  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 268
652: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,144
	btf_id 269
653: sched_cls  name cil_from_container  tag fe9fddde68af396b  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 144,76
	btf_id 270
654: sched_cls  name tail_handle_ipv4_cont  tag 3bdc6ae84396fc11  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,145,41,143,82,83,39,76,74,77,144,40,37,38,81
	btf_id 271
655: sched_cls  name handle_policy  tag 844ce4cf1a5a5a55  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,144,82,83,145,41,80,143,39,84,75,40,37,38
	btf_id 272
656: sched_cls  name tail_ipv4_ct_egress  tag fd382f2ae0cdd167  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,144,82,83,145,84
	btf_id 273
657: sched_cls  name tail_handle_arp  tag d7798bc8ffb58ad1  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,144
	btf_id 274
659: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
662: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
679: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
682: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
683: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
686: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
