top - 08:22:54 up 29 min,  0 users,  load average: 0.32, 0.36, 0.28
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 65.5 us, 24.1 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4484.4 free,   1183.4 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 388116  78780 S  93.3   4.9   0:58.39 cilium-+
    689 root      20   0 1240432  16488  11484 S   6.7   0.2   0:00.03 cilium-+
    723 root      20   0 1243508  19480  14140 S   6.7   0.2   0:00.01 hubble
    394 root      20   0 1229744   7680   3836 S   0.0   0.1   0:01.19 cilium-+
    636 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    662 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    680 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    713 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    719 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    745 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
