alloc: 154.90MB (162422752 bytes)
total-alloc: 2.33GB (2506235344 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 64920560
frees: 63368280
heap-alloc: 154.90MB (162422752 bytes)
heap-sys: 246.92MB (258916352 bytes)
heap-idle: 61.25MB (64225280 bytes)
heap-in-use: 185.67MB (194691072 bytes)
heap-released: 1.05MB (1097728 bytes)
heap-objects: 1552280
stack-in-use: 65.03MB (68190208 bytes)
stack-sys: 65.03MB (68190208 bytes)
stack-mspan-inuse: 3.11MB (3262400 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1011.74KB (1036017 bytes)
gc-sys: 6.07MB (6360384 bytes)
next-gc: when heap-alloc >= 213.16MB (223512440 bytes)
last-gc: 2024-10-30 08:23:02.972925594 +0000 UTC
gc-pause-total: 13.478549ms
gc-pause: 281610
gc-pause-end: 1730276582972925594
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005273503767458738
enable-gc: true
debug-gc: false
