key: d9 00 00 00  value: 8f 02 00 00
key: 82 03 00 00  value: 51 02 00 00
key: 03 07 00 00  value: 24 02 00 00
key: 37 09 00 00  value: 4b 02 00 00
Found 4 elements
