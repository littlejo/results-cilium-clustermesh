[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-875bf1f609b8723971477a140efc631148cf378c3395c8888609295353210398.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-bb9371d26b61cdede504fc2b0f3acefb407746cc0a7689647e298fb2de58ef35.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8675b_9b4f_4b78_a16f_358ee9e86716.slice/cri-containerd-a3cebebf106e72eac214ce0684227c7b0c75a205550d206e59aa5c72c80c8a75.scope"
      }
    ],
    "ips": [
      "10.213.0.118"
    ],
    "name": "clustermesh-apiserver-b4dfb547c-wm9bt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2fd1ad81_a7c9_4db5_8dce_87b589e28651.slice/cri-containerd-73affef7b798e01b05c9b35c9b15dad6ddd504328544be571fd360b060396a62.scope"
      }
    ],
    "ips": [
      "10.213.0.240"
    ],
    "name": "coredns-cc6ccd49c-7jvn8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0ea3a4f0_c76d_4e02_bca8_be56c45b5870.slice/cri-containerd-5773d15901085fa2ea4db1df4d8e80e4ca1255e1229b9d5842215d029c90ac23.scope"
      }
    ],
    "ips": [
      "10.213.0.161"
    ],
    "name": "coredns-cc6ccd49c-9rlxb",
    "namespace": "kube-system"
  }
]

