1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1b:94:da:fc:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.205.133/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1849sec preferred_lft 1849sec
    inet6 fe80::81b:94ff:feda:fc33/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:82:e4:ff:bc:4d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.205.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::882:e4ff:feff:bc4d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:89:a6:0a:9e:4b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7889:a6ff:fe0a:9e4b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:e8:7a:81:68:b3 brd ff:ff:ff:ff:ff:ff
    inet 10.213.0.28/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::30e8:7aff:fe81:68b3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:eb:cc:5a:96:c5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58eb:ccff:fe5a:96c5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:bc:89:5b:48:66 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8bc:89ff:fe5b:4866/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc63a33539481b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:b1:c8:aa:36:ba brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f4b1:c8ff:feaa:36ba/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc0a0b678820a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:0d:5c:b8:5d:8d brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::680d:5cff:feb8:5d8d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc332774ccf737@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:5f:ff:ce:fc:c3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::645f:ffff:fece:fcc3/64 scope link 
       valid_lft forever preferred_lft forever
