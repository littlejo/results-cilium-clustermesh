KEY             VALUE
AgentLiveness   1792074609086
UTimeOffset     3379442996093750
