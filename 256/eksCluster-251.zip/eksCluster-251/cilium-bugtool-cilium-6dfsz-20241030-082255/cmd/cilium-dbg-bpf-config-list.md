KEY             VALUE
AgentLiveness   1713077330199
UTimeOffset     3379443152343750
