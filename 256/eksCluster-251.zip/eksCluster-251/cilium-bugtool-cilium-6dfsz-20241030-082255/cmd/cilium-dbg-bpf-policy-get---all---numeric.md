Endpoint ID: 310
Path: /sys/fs/bpf/tc/globals/cilium_policy_00310

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112626   1297      0        
Allow    Egress      0          ANY          NONE         disabled    16062    173       0        


Endpoint ID: 620
Path: /sys/fs/bpf/tc/globals/cilium_policy_00620

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1246
Path: /sys/fs/bpf/tc/globals/cilium_policy_01246

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1662609   20979     0        
Allow    Ingress     1          ANY          NONE         disabled    17325     205       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1282
Path: /sys/fs/bpf/tc/globals/cilium_policy_01282

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112642   1292      0        
Allow    Egress      0          ANY          NONE         disabled    16617    179       0        


Endpoint ID: 1762
Path: /sys/fs/bpf/tc/globals/cilium_policy_01762

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11529691   116320    0        
Allow    Ingress     1          ANY          NONE         disabled    11237233   119091    0        
Allow    Egress      0          ANY          NONE         disabled    14597223   142576    0        


