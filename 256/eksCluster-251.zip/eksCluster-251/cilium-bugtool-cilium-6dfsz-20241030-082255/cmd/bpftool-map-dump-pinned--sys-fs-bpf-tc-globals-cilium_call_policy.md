key: 36 01 00 00  value: 18 02 00 00
key: de 04 00 00  value: 24 02 00 00
key: 02 05 00 00  value: 11 02 00 00
key: e2 06 00 00  value: 6d 02 00 00
Found 4 elements
