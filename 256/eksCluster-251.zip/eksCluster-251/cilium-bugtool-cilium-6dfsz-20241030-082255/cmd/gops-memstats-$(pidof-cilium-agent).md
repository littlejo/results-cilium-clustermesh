alloc: 158.93MB (166653216 bytes)
total-alloc: 2.33GB (2501301344 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64905099
frees: 63212221
heap-alloc: 158.93MB (166653216 bytes)
heap-sys: 250.86MB (263045120 bytes)
heap-idle: 58.70MB (61546496 bytes)
heap-in-use: 192.16MB (201498624 bytes)
heap-released: 1.91MB (2007040 bytes)
heap-objects: 1692878
stack-in-use: 65.09MB (68255744 bytes)
stack-sys: 65.09MB (68255744 bytes)
stack-mspan-inuse: 3.22MB (3380960 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1228369 bytes)
gc-sys: 6.02MB (6313472 bytes)
next-gc: when heap-alloc >= 218.38MB (228985160 bytes)
last-gc: 2024-10-30 08:23:01.26704986 +0000 UTC
gc-pause-total: 27.017289ms
gc-pause: 496834
gc-pause-end: 1730276581267049860
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0006351366100393336
enable-gc: true
debug-gc: false
