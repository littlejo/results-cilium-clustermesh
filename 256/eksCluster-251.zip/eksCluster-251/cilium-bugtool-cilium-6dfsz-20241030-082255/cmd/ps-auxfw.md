USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         685  0.0  0.2 1240432 16260 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         702  0.0  0.2 1240432 16260 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         673  0.0  0.0   2208   792 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         678  0.0  0.2 1244340 22728 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         661  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         655  0.0  0.0 1228744 3712 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         622  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  5.2  4.9 1606336 398348 ?      Ssl  08:03   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.1  0.0 1229744 6568 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
