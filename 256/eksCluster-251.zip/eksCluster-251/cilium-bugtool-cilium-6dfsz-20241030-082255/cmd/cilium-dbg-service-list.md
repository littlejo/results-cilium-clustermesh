ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.220.181:443 (active)    
                                         2 => 172.31.164.233:443 (active)    
2    10.100.130.219:443   ClusterIP      1 => 172.31.247.176:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.251.0.225:53 (active)       
                                         2 => 10.251.0.4:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.251.0.225:9153 (active)     
                                         2 => 10.251.0.4:9153 (active)       
5    10.100.45.184:2379   ClusterIP      1 => 10.251.0.163:2379 (active)     
