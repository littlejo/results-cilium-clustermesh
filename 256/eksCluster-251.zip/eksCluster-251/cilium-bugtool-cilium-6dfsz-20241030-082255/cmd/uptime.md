 08:22:56 up 28 min,  0 users,  load average: 0.25, 0.31, 0.24
