REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36906     2921536     677    bpf_overlay.c
Interface                 INGRESS     664731    134669657   1132   bpf_host.c
Success                   EGRESS      16654     1309154     1694   bpf_host.c
Success                   EGRESS      287305    35276709    1308   bpf_lxc.c
Success                   EGRESS      37515     2958793     53     encap.h
Success                   INGRESS     330668    37393379    86     l3.h
Success                   INGRESS     351571    39049807    235    trace.h
Unsupported L3 protocol   EGRESS      40        2992        1492   bpf_lxc.c
