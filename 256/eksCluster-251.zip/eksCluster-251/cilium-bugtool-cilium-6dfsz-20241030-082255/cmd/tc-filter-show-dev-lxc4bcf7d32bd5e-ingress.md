filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4bcf7d32bd5e direct-action not_in_hw id 612 tag 180d5a78cb9adc44 jited 
