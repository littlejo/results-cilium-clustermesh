IP ADDRESS         LOCAL ENDPOINT INFO
10.251.0.225:0     id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95   
10.251.0.229:0     id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85     
172.31.194.63:0    (localhost)                                                                                        
172.31.247.176:0   (localhost)                                                                                        
10.251.0.173:0     (localhost)                                                                                        
10.251.0.163:0     id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42   
10.251.0.4:0       id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C   
