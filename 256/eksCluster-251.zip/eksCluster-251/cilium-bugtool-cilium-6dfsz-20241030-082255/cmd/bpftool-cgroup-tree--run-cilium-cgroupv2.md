CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1726faa6_90e7_468f_8c8c_303b160b6116.slice/cri-containerd-c2bd124a3f4194815b77a3b1f3e6f58a08b26005d607206b2946a89c02b4c0bb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1726faa6_90e7_468f_8c8c_303b160b6116.slice/cri-containerd-30c2643d2984db81978e89a2220c3aabcb6d3d20a108ac12728d282cfb31a5ba.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d96066e_ade6_4902_9584_81612941af7a.slice/cri-containerd-5ca514fc4b9f351966676b0545fbf771120db81da74a0c3964e34556ce4ed561.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d96066e_ade6_4902_9584_81612941af7a.slice/cri-containerd-04ea390896d07cc1ca782ca338d0c5c50d6cfe0eca48f764420b1c808dd6fe9f.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8806d1e0_e4bc_4bdb_9735_f6c398f00612.slice/cri-containerd-a44e5122ff32b523eef5fc513541445cc51cdea3b7baa2401884c922ed6619f5.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8806d1e0_e4bc_4bdb_9735_f6c398f00612.slice/cri-containerd-bb930e442d7ef75bb90d8252e41acfb5260ac714773f88cd356b3fdeae44b9f4.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b0e282a_1f2f_46cd_be56_7194afd80d37.slice/cri-containerd-e95ad2e2565b7e4a8e24165f95d4131e77e81617eddc5cc7f908e5d8eb092573.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2b0e282a_1f2f_46cd_be56_7194afd80d37.slice/cri-containerd-9e725ceb12d1e9498e274749e44282a54bdf1d8d081dae088c2acb648a37fe89.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-3449c417dd908e31ea471adfebb22da9a686d46107fb49d8ee9471191ccaca01.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-02e68f099ce5f8631c143d5e1f8dd9856f575974f3fb57918382243f27150fca.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-2dc65ae7d31a6aec4e43aa590f7bf9b43b88f79bc122923b895576050c6e7912.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-c23549bd917ec3669d4d47d6f5c5e42c3d4a1a34d9f7a6847068889fdb39d526.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28e9b3f8_cf42_448f_b175_dac8cdc63ed0.slice/cri-containerd-7d2e4e186402ef74c9713680f5917a9d9c93a9408629f37160b58093805073ca.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28e9b3f8_cf42_448f_b175_dac8cdc63ed0.slice/cri-containerd-b9653a46e12cd0b8e389a4360ddc0e1d4e61770ddb50657626b3d5ac98f669aa.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8357c989_3b15_43de_8b78_e6e922973cea.slice/cri-containerd-304c54741aeba24ab8ebaa27518f20fc38bd6e84f0fce34d0c29d77710f80121.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8357c989_3b15_43de_8b78_e6e922973cea.slice/cri-containerd-4412fdf36687e0a2a91464508b833f1197d0ee171d618012f112d56e71a26f75.scope
    94       cgroup_device   multi                                          
