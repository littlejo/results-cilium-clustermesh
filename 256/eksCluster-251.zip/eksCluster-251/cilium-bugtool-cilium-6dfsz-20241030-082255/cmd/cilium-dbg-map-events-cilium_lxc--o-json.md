{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:39.518Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.550Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.557Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.587Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.588Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.631Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:39.405Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:39.406Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:39.406Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:39.438Z",
  "value": "id=1141  sec_id=8260632 flags=0x0000 ifindex=16  mac=DE:50:C7:C7:C8:A2 nodemac=9E:87:AF:EB:5D:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.406Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.406Z",
  "value": "id=1141  sec_id=8260632 flags=0x0000 ifindex=16  mac=DE:50:C7:C7:C8:A2 nodemac=9E:87:AF:EB:5D:8C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.406Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:40.406Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.182Z",
  "value": "id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.251.0.148:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:01.032Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.957Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.957Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.957Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.957Z",
  "value": "id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.959Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.959Z",
  "value": "id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.960Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.961Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.959Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.960Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.960Z",
  "value": "id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.961Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.960Z",
  "value": "id=1282  sec_id=8260417 flags=0x0000 ifindex=12  mac=72:7A:0E:69:C7:8F nodemac=8E:F2:44:B0:1F:95"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.960Z",
  "value": "id=310   sec_id=8260417 flags=0x0000 ifindex=14  mac=56:1B:B7:80:AD:AC nodemac=52:E7:46:79:C7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.960Z",
  "value": "id=1246  sec_id=4     flags=0x0000 ifindex=10  mac=EA:3A:BD:3B:C9:3C nodemac=42:56:96:65:CB:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.251.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.961Z",
  "value": "id=1762  sec_id=8260632 flags=0x0000 ifindex=18  mac=7A:E4:B4:9B:DA:03 nodemac=72:77:5E:B9:2E:42"
}

