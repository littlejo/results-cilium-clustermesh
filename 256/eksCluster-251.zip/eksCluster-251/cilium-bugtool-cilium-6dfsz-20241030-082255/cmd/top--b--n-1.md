top - 08:22:57 up 28 min,  0 users,  load average: 0.25, 0.31, 0.24
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 20.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 16.7 si,  0.0 st
MiB Mem :   7814.2 total,   4449.2 free,   1218.4 used,   2146.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6410.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    678 root      20   0 1244340  22812  14464 S  66.7   0.3   0:00.24 hubble
      1 root      20   0 1606336 398348  78548 S  13.3   5.0   1:00.75 cilium-+
    394 root      20   0 1229744   6568   2868 S   0.0   0.1   0:01.20 cilium-+
    622 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    655 root      20   0 1228744   3712   3040 S   0.0   0.0   0:00.00 gops
    661 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    673 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    685 root      20   0 1240432  16260  11292 S   0.0   0.2   0:00.03 cilium-+
    713 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    720 root      20   0     736      4      0 R   0.0   0.0   0:00.00 bpftool
    722 root      20   0    3728    488    436 R   0.0   0.0   0:00.00 bash
