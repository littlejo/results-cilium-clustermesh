key: 01 00 00 00  value: ac 1f dc b5 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a fb 00 a3 09 4b 00 00  00 00 00 00
key: 07 00 00 00  value: 0a fb 00 e1 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f f7 b0 10 94 00 00  00 00 00 00
key: 06 00 00 00  value: 0a fb 00 e1 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a fb 00 04 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a fb 00 04 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f a4 e9 01 bb 00 00  00 00 00 00
Found 8 elements
