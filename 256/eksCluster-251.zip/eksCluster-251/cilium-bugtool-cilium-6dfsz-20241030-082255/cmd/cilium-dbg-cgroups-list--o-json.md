[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8806d1e0_e4bc_4bdb_9735_f6c398f00612.slice/cri-containerd-bb930e442d7ef75bb90d8252e41acfb5260ac714773f88cd356b3fdeae44b9f4.scope"
      }
    ],
    "ips": [
      "10.251.0.225"
    ],
    "name": "coredns-cc6ccd49c-rr9pc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-2dc65ae7d31a6aec4e43aa590f7bf9b43b88f79bc122923b895576050c6e7912.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-c23549bd917ec3669d4d47d6f5c5e42c3d4a1a34d9f7a6847068889fdb39d526.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43119520_00ed_4bd6_a3b5_910e7f4bbaf1.slice/cri-containerd-3449c417dd908e31ea471adfebb22da9a686d46107fb49d8ee9471191ccaca01.scope"
      }
    ],
    "ips": [
      "10.251.0.163"
    ],
    "name": "clustermesh-apiserver-565cf98666-x9962",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2d96066e_ade6_4902_9584_81612941af7a.slice/cri-containerd-04ea390896d07cc1ca782ca338d0c5c50d6cfe0eca48f764420b1c808dd6fe9f.scope"
      }
    ],
    "ips": [
      "10.251.0.4"
    ],
    "name": "coredns-cc6ccd49c-wjkrk",
    "namespace": "kube-system"
  }
]

