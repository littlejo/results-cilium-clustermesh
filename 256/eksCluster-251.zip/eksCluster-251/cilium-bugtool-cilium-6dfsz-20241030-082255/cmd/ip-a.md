1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b4:59:d3:01:e7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.247.176/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1928sec preferred_lft 1928sec
    inet6 fe80::8b4:59ff:fed3:1e7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:fc:50:37:24:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.194.63/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8fc:50ff:fe37:245f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:11:ef:56:a9:7b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d811:efff:fe56:a97b/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:1a:30:03:c1:77 brd ff:ff:ff:ff:ff:ff
    inet 10.251.0.173/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d01a:30ff:fe03:c177/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b6:96:e8:6a:8c:7f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b496:e8ff:fe6a:8c7f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:56:96:65:cb:85 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4056:96ff:fe65:cb85/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca472f3b63aa5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:f2:44:b0:1f:95 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8cf2:44ff:feb0:1f95/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd2ac87053665@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:e7:46:79:c7:5c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::50e7:46ff:fe79:c75c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4bcf7d32bd5e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:77:5e:b9:2e:42 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7077:5eff:feb9:2e42/64 scope link 
       valid_lft forever preferred_lft forever
