key: 06 00 00 00  value: 0a 38 00 0b 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 38 00 ba 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 38 00 0b 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d2 e5 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 38 00 74 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f a9 dc 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 85 ea 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 38 00 ba 23 c1 00 00  00 00 00 00
Found 8 elements
