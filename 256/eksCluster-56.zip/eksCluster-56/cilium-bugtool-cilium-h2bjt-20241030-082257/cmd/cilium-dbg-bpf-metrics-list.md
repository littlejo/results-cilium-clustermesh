REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35724     2819772     677    bpf_overlay.c
Interface                 INGRESS     653241    133173772   1132   bpf_host.c
Success                   EGRESS      15294     1199466     1694   bpf_host.c
Success                   EGRESS      285104    36167912    1308   bpf_lxc.c
Success                   EGRESS      35168     2782912     53     encap.h
Success                   INGRESS     327721    36915161    86     l3.h
Success                   INGRESS     348803    38579583    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
