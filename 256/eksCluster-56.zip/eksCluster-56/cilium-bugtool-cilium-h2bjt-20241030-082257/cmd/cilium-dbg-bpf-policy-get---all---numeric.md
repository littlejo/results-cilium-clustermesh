Endpoint ID: 488
Path: /sys/fs/bpf/tc/globals/cilium_policy_00488

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174905   2011      0        
Allow    Egress      0          ANY          NONE         disabled    20565    229       0        


Endpoint ID: 1720
Path: /sys/fs/bpf/tc/globals/cilium_policy_01720

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173886   2001      0        
Allow    Egress      0          ANY          NONE         disabled    20673    232       0        


Endpoint ID: 2576
Path: /sys/fs/bpf/tc/globals/cilium_policy_02576

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665548   21096     0        
Allow    Ingress     1          ANY          NONE         disabled    25550     297       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3120
Path: /sys/fs/bpf/tc/globals/cilium_policy_03120

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3543
Path: /sys/fs/bpf/tc/globals/cilium_policy_03543

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11515200   113148    0        
Allow    Ingress     1          ANY          NONE         disabled    10396625   105644    0        
Allow    Egress      0          ANY          NONE         disabled    11269336   112123    0        


