markdown output at /tmp/cilium-bugtool-20241030-082258.666+0000-UTC-1451683627/cmd/cilium-debuginfo-20241030-082329.952+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.666+0000-UTC-1451683627/cmd/cilium-debuginfo-20241030-082329.952+0000-UTC.json
