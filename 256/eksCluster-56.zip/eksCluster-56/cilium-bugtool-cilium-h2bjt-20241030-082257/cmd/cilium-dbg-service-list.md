ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.169.220:443 (active)    
                                          2 => 172.31.210.229:443 (active)    
2    10.100.223.20:443     ClusterIP      1 => 172.31.133.234:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.56.0.11:9153 (active)       
                                          2 => 10.56.0.186:9153 (active)      
4    10.100.0.10:53        ClusterIP      1 => 10.56.0.11:53 (active)         
                                          2 => 10.56.0.186:53 (active)        
5    10.100.146.113:2379   ClusterIP      1 => 10.56.0.116:2379 (active)      
