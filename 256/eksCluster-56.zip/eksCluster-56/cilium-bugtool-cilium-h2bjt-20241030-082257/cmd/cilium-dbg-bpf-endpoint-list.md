IP ADDRESS         LOCAL ENDPOINT INFO
172.31.133.234:0   (localhost)                                                                                        
10.56.0.11:0       id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E   
10.56.0.171:0      (localhost)                                                                                        
10.56.0.116:0      id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5   
10.56.0.66:0       id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49     
10.56.0.186:0      id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4   
172.31.141.127:0   (localhost)                                                                                        
