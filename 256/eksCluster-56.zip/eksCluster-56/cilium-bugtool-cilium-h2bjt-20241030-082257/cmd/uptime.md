 08:22:58 up 36 min,  0 users,  load average: 0.10, 0.27, 0.19
