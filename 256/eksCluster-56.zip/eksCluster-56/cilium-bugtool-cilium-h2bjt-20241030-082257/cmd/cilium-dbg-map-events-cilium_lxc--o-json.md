{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:04.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.063Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.073Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.101Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.219Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.305Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:35.247Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:35.247Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:35.247Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:35.276Z",
  "value": "id=2289  sec_id=1878232 flags=0x0000 ifindex=16  mac=F6:3B:E8:E9:EA:1B nodemac=CE:B1:AA:6B:54:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:35.277Z",
  "value": "id=2289  sec_id=1878232 flags=0x0000 ifindex=16  mac=F6:3B:E8:E9:EA:1B nodemac=CE:B1:AA:6B:54:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.247Z",
  "value": "id=2289  sec_id=1878232 flags=0x0000 ifindex=16  mac=F6:3B:E8:E9:EA:1B nodemac=CE:B1:AA:6B:54:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.247Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.247Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.248Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.555Z",
  "value": "id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.56.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.290Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.338Z",
  "value": "id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.339Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.339Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.339Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.337Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.338Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.339Z",
  "value": "id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.339Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.338Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.338Z",
  "value": "id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.339Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.339Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.339Z",
  "value": "id=2576  sec_id=4     flags=0x0000 ifindex=10  mac=1E:17:FA:D5:F4:C7 nodemac=FE:19:87:1C:3B:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.339Z",
  "value": "id=3543  sec_id=1878232 flags=0x0000 ifindex=18  mac=62:7E:C2:A8:4A:AC nodemac=32:4E:10:4E:7B:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.339Z",
  "value": "id=1720  sec_id=1898556 flags=0x0000 ifindex=12  mac=12:5A:DA:CA:82:09 nodemac=FE:4A:36:97:47:0E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.56.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.340Z",
  "value": "id=488   sec_id=1898556 flags=0x0000 ifindex=14  mac=4E:E5:28:6B:70:A5 nodemac=5A:2F:12:56:9C:F4"
}

