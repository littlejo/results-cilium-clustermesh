key: e8 01 00 00  value: fe 01 00 00
key: b8 06 00 00  value: 19 02 00 00
key: 10 0a 00 00  value: 16 02 00 00
key: d7 0d 00 00  value: 78 02 00 00
Found 4 elements
