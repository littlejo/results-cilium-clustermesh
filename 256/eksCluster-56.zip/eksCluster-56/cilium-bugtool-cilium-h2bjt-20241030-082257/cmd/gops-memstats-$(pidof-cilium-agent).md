alloc: 166.94MB (175053800 bytes)
total-alloc: 2.41GB (2591110968 bytes)
sys: 332.96MB (349131108 bytes)
lookups: 0
mallocs: 65307740
frees: 63493691
heap-alloc: 166.94MB (175053800 bytes)
heap-sys: 251.83MB (264060928 bytes)
heap-idle: 53.19MB (55771136 bytes)
heap-in-use: 198.64MB (208289792 bytes)
heap-released: 2.61MB (2736128 bytes)
heap-objects: 1814049
stack-in-use: 68.12MB (71434240 bytes)
stack-sys: 68.12MB (71434240 bytes)
stack-mspan-inuse: 3.37MB (3535040 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1060313 bytes)
gc-sys: 5.98MB (6272632 bytes)
next-gc: when heap-alloc >= 212.57MB (222898488 bytes)
last-gc: 2024-10-30 08:23:05.472703626 +0000 UTC
gc-pause-total: 29.01735ms
gc-pause: 74866
gc-pause-end: 1730276585472703626
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0004578434993523402
enable-gc: true
debug-gc: false
