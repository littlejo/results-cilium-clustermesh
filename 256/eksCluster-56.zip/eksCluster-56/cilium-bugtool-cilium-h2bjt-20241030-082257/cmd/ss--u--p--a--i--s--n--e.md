Total: 683
TCP:   1857 (estab 434, closed 1404, orphaned 0, timewait 559)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  453       441       12       
INET	  463       447       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.133.234%ens5:68         0.0.0.0:*    uid:192 ino:66842 sk:3e9 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31532 sk:3ea cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13286 sk:3eb cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:39171      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32008 sk:3ec fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31531 sk:3ed cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:13287 sk:3ee cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::47e:91ff:fe8b:b583]%ens5:546           [::]:*    uid:192 ino:15510 sk:3ef cgroup:unreachable:c4e v6only:1 <->                   
