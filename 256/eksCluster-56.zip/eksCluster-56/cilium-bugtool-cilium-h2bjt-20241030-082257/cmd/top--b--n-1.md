top - 08:22:58 up 36 min,  0 users,  load average: 0.10, 0.27, 0.19
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.6 us, 30.3 sy,  0.0 ni,  9.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4446.7 free,   1220.6 used,   2146.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6408.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606272 402652  78204 R  68.8   5.0   0:56.47 cilium-+
    630 root      20   0 1240432  16564  11356 S   6.2   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   7984   3836 S   0.0   0.1   0:01.17 cilium-+
    631 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    669 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    670 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    674 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    721 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
