[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-625044cf22287b72e6e213891228fecd2680e718ed7e2ebee8fe4f6c86fe30a3.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-9097d1738ca491c15d38e81a57ebfcb74b0740798bc2832f1c507b5d6f02337d.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-c56a857685b5af62f429d595d3e49ce4524281c457b0224a32dec85a72cc6e4d.scope"
      }
    ],
    "ips": [
      "10.56.0.116"
    ],
    "name": "clustermesh-apiserver-867477bb6d-6zdng",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1db36f_831b_4cf7_8628_3a74004c5cf1.slice/cri-containerd-9d1feaaedf1bcfffca9948d181aa2984781164a10af13d85709ece4eb9a484c7.scope"
      }
    ],
    "ips": [
      "10.56.0.186"
    ],
    "name": "coredns-cc6ccd49c-2cfvh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19b23b4a_e252_4ff8_8477_673e798c38ad.slice/cri-containerd-026f897f8d55ed6b2634d3690489c6a9b3751265ba539841c44a2850af4cae8e.scope"
      }
    ],
    "ips": [
      "10.56.0.11"
    ],
    "name": "coredns-cc6ccd49c-jh6xt",
    "namespace": "kube-system"
  }
]

