CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1db36f_831b_4cf7_8628_3a74004c5cf1.slice/cri-containerd-9d1feaaedf1bcfffca9948d181aa2984781164a10af13d85709ece4eb9a484c7.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8d1db36f_831b_4cf7_8628_3a74004c5cf1.slice/cri-containerd-5e4bb8502503676fc335c671d8b12cbf4b56c4c99966b4bfdd6ba31e861ae0e8.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19b23b4a_e252_4ff8_8477_673e798c38ad.slice/cri-containerd-026f897f8d55ed6b2634d3690489c6a9b3751265ba539841c44a2850af4cae8e.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod19b23b4a_e252_4ff8_8477_673e798c38ad.slice/cri-containerd-5237e4859f416bb3c348fc2a4b403f5b90e19e0d40f4a7fb2d9bd79f56e849f0.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c33d50a_f66d_4398_9480_a7f7b22e2b0e.slice/cri-containerd-eee21842ded7f5cf495a7044cc879b097ec6a316d4c6e6e1fc9808e208c78958.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9c33d50a_f66d_4398_9480_a7f7b22e2b0e.slice/cri-containerd-7ebfdd26bf51e5c8603e80074e6f2259781eb2a17b6d21fa337ae52a73d4fdc8.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd17d1ec1_45bd_463b_9a66_c92fb48d9710.slice/cri-containerd-a951dc085319b4b536ab7992d37dcdbe15908e4b2f7ab157109cb52e2c89798d.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd17d1ec1_45bd_463b_9a66_c92fb48d9710.slice/cri-containerd-69820cbd09ebdc9168a21b3e714f1fd25900db1170f5e594caf0c6abc8096270.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-c56a857685b5af62f429d595d3e49ce4524281c457b0224a32dec85a72cc6e4d.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-9097d1738ca491c15d38e81a57ebfcb74b0740798bc2832f1c507b5d6f02337d.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-5aa226d8c74ab0db17f2d40c8d8f033de86cca4f59f739e3bff68f1a6a63d630.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d132f88_9ab2_4b9a_a5e2_4432862bb861.slice/cri-containerd-625044cf22287b72e6e213891228fecd2680e718ed7e2ebee8fe4f6c86fe30a3.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38e67028_daef_43f8_87fa_7d885f071bcd.slice/cri-containerd-455817844000c3194c2bf6ac151308dec5ebe0ac799b91829ecf3dfd572d8bdd.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38e67028_daef_43f8_87fa_7d885f071bcd.slice/cri-containerd-e045181723e7b62139afe627ed5151c847e5ede316676280557ab8d7f5e13509.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeaacc210_a063_40ad_821d_0d26eba22b99.slice/cri-containerd-650e0f2c8873c18c8f188249cd93d283248bb920a29c241d3f1121d2e09e3b92.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeaacc210_a063_40ad_821d_0d26eba22b99.slice/cri-containerd-76003e56291c67fad4c03320a0b0dc63817a38cccf8f93b67f5b8339c109bdbf.scope
    94       cgroup_device   multi                                          
