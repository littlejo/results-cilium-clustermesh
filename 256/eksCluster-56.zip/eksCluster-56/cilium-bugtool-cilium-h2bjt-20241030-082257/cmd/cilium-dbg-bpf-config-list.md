KEY             VALUE
AgentLiveness   2233615524190
UTimeOffset     3379442140625000
