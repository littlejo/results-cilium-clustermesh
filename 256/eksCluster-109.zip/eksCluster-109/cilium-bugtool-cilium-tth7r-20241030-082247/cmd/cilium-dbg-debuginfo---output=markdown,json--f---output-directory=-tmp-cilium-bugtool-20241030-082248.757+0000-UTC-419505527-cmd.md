markdown output at /tmp/cilium-bugtool-20241030-082248.757+0000-UTC-419505527/cmd/cilium-debuginfo-20241030-082320.133+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.757+0000-UTC-419505527/cmd/cilium-debuginfo-20241030-082320.133+0000-UTC.json
