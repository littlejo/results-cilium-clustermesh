CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb10b4163_4ce5_472f_86d6_c71aed8e3965.slice/cri-containerd-00b8f8700aaceb38771536ab1314a9e4199e7ac7fa3b92e0dce7d7969d74a92f.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb10b4163_4ce5_472f_86d6_c71aed8e3965.slice/cri-containerd-135ad7e061305d94f8c4b712084847d0ef2bda4df8d9e9035d1876d8a0777d7d.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50571281_86b7_4d74_b798_cf37e660125e.slice/cri-containerd-2af8b70e98754af5a86f64599561ae2c63d741e98ca95392994465ccb557c3c4.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50571281_86b7_4d74_b798_cf37e660125e.slice/cri-containerd-0fa565cc5d2425becab240c7be0120ed5f4fa45bd9697c0c0ed3b886052cbf1f.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cd9aaab_597f_4ce7_90a7_66cf4e444abb.slice/cri-containerd-2ca8145b9d1502ec414a13179b699540704ac3c80bc8d33030958f2d7e5c2b4c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cd9aaab_597f_4ce7_90a7_66cf4e444abb.slice/cri-containerd-699195f4dc9077a0b9406480c405dea9e6230aff7d2c239a4d9671cea035dc17.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod847487e2_f85c_401a_b920_cf1d4060e1e4.slice/cri-containerd-ce4faee3d150703949b21dd8b6ac981e3bf539d99fc926a777d92b773376d42f.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod847487e2_f85c_401a_b920_cf1d4060e1e4.slice/cri-containerd-b6bd25ccaf1bf882a316617dd8684f565a5ff9bb6d2188b3be24f43279a64b32.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a827e15_1206_492c_8ae1_b13920eeb00f.slice/cri-containerd-0a1c00b405e7cd669d057ab66da4b072380e8f284567d8be213709530a757283.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a827e15_1206_492c_8ae1_b13920eeb00f.slice/cri-containerd-dbc08d0276a655c5a2dfe0c54f3e1915950dd3f8b888b5efc5b1e07648d55977.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-4c65ae80b166bb82e28787e1b03eeb8869c533a338e0538491fd48c5350e8d04.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-2d93a7d81f55f13113e1246d181127f1dcecba4e62c3cc2ab11f4c2ba5254fae.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-043476c30ed95c0337224382ff7912828b6bcb3d965d546cf2d5ad058171afe5.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-5ef65cfca7b32a6b81497d3fee5c1574a6baa8b850ae58b88d3b7dc6e8c16290.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c63f93d_e964_4c50_967d_df8487548f1c.slice/cri-containerd-7d9008824bcf41b92069ca7be361c68f60257c060828c884874648a7e997e0f2.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c63f93d_e964_4c50_967d_df8487548f1c.slice/cri-containerd-61ccc185ece4d68ba2afaa30c155178eacb319d5fcb0a427cefdb8ae48ba5911.scope
    95       cgroup_device   multi                                          
