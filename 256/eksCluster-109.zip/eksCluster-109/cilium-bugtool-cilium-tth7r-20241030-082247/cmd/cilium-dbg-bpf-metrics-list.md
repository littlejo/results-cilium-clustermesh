REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35276     2791248     677    bpf_overlay.c
Interface                 INGRESS     632070    131013868   1132   bpf_host.c
Success                   EGRESS      15379     1205608     1694   bpf_host.c
Success                   EGRESS      267833    33707457    1308   bpf_lxc.c
Success                   EGRESS      34910     2762112     53     encap.h
Success                   INGRESS     308895    34878370    86     l3.h
Success                   INGRESS     329443    36508056    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
