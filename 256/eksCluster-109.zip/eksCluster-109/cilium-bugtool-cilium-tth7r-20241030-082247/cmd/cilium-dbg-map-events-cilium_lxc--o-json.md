{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.504Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.504Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.242.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.504Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:27.096Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:27.097Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:27.099Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:27.164Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:27.188Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:09.207Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:09.208Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:09.208Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:09.238Z",
  "value": "id=1637  sec_id=3619655 flags=0x0000 ifindex=16  mac=A6:A3:8D:CE:0B:34 nodemac=8E:73:9D:A6:54:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.208Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.208Z",
  "value": "id=1637  sec_id=3619655 flags=0x0000 ifindex=16  mac=A6:A3:8D:CE:0B:34 nodemac=8E:73:9D:A6:54:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.208Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.208Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.649Z",
  "value": "id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.109.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.249Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.970Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.970Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.970Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.970Z",
  "value": "id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.979Z",
  "value": "id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.980Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.981Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.981Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.976Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.976Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.976Z",
  "value": "id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:15.977Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.976Z",
  "value": "id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.976Z",
  "value": "id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.977Z",
  "value": "id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.109.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.977Z",
  "value": "id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F"
}

