IP ADDRESS         LOCAL ENDPOINT INFO
10.109.0.210:0     id=254   sec_id=3623475 flags=0x0000 ifindex=14  mac=BA:33:B1:07:99:7C nodemac=32:AD:5E:F0:C7:B8   
172.31.192.43:0    (localhost)                                                                                        
172.31.242.123:0   (localhost)                                                                                        
10.109.0.86:0      (localhost)                                                                                        
10.109.0.166:0     id=1367  sec_id=4     flags=0x0000 ifindex=10  mac=0A:B8:2F:08:C5:A8 nodemac=86:4D:41:D4:A8:2F     
10.109.0.110:0     id=317   sec_id=3619655 flags=0x0000 ifindex=18  mac=26:87:5A:FB:BD:D4 nodemac=A6:70:2E:B5:3D:6F   
10.109.0.240:0     id=1439  sec_id=3623475 flags=0x0000 ifindex=12  mac=B6:76:87:E7:D5:EA nodemac=F2:9B:20:62:54:A3   
