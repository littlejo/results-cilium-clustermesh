filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6e41bf320114 direct-action not_in_hw id 611 tag c93aed96f861dfd1 jited 
