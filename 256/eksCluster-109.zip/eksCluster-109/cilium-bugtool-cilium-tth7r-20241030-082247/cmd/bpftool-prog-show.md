29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:49:32+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:49:37+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:49:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
51: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:49:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:49:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:58:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:58:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:58:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:58:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:58:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:58:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:58:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:58:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:58:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:58:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 998c2282d9186c67  gpl
	loaded_at 2024-10-30T07:59:24+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:59:24+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:59:24+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:59:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
484: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 131
485: sched_cls  name tail_handle_ipv4_from_host  tag d5fd35dc86b0d56d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 132
486: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,101
	btf_id 133
487: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 134
488: sched_cls  name __send_drop_notify  tag 01546df104c03943  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 135
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_host  tag d5fd35dc86b0d56d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 140
494: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 142
495: sched_cls  name __send_drop_notify  tag 01546df104c03943  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
496: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 145
498: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 147
499: sched_cls  name tail_handle_ipv4_from_host  tag d5fd35dc86b0d56d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 148
502: sched_cls  name __send_drop_notify  tag 01546df104c03943  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
503: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,108
	btf_id 153
504: sched_cls  name tail_handle_ipv4_from_host  tag d5fd35dc86b0d56d  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,108
	btf_id 154
507: sched_cls  name __send_drop_notify  tag 01546df104c03943  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
508: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:59:25+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,108,75
	btf_id 158
510: sched_cls  name tail_handle_ipv4  tag 95d25603cd1944eb  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 161
512: sched_cls  name cil_from_container  tag 2055591c3701d02b  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 165
513: sched_cls  name __send_drop_notify  tag b01a1e556e15b879  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
515: sched_cls  name handle_policy  tag 8cd4519d4982999b  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,110,41,80,109,39,84,75,40,37,38
	btf_id 167
520: sched_cls  name tail_ipv4_to_endpoint  tag 037c1466503c0c4d  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,109,39,111,40,37,38
	btf_id 169
522: sched_cls  name tail_ipv4_ct_egress  tag ebffff840e3db54f  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,110,84
	btf_id 174
523: sched_cls  name tail_handle_ipv4_cont  tag d98bf8b09e0cf95c  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,110,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 176
526: sched_cls  name tail_ipv4_ct_ingress  tag 12fb91dfe7579c2c  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,110,84
	btf_id 177
528: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 180
529: sched_cls  name tail_handle_arp  tag 333c8de41bd4cacd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 181
532: sched_cls  name __send_drop_notify  tag 9d61a90147174701  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
533: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 187
534: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 188
535: sched_cls  name tail_ipv4_ct_ingress  tag 1f345b0bcda0fcaa  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 190
536: sched_cls  name tail_handle_ipv4  tag ceb774a232862283  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 191
538: sched_cls  name handle_policy  tag f2e26f4960bec36c  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 189
539: sched_cls  name __send_drop_notify  tag bba14fc6e06bc9e6  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
540: sched_cls  name tail_ipv4_ct_ingress  tag 286c748f9b4ce521  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 194
541: sched_cls  name tail_handle_ipv4_cont  tag b8512d03b4d8d0e8  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 195
542: sched_cls  name tail_handle_arp  tag 82f737dbbbf5a8b4  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 197
543: sched_cls  name tail_ipv4_to_endpoint  tag 8d861b7e4df10126  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 196
544: sched_cls  name tail_handle_arp  tag ddd0345401e6c93d  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 199
546: sched_cls  name cil_from_container  tag 8fd78eeee9e54730  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 201
547: sched_cls  name tail_handle_ipv4  tag 2522f3e722fe9f4a  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 202
548: sched_cls  name tail_handle_ipv4_cont  tag 272e3c7a8728e8cf  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 203
549: sched_cls  name handle_policy  tag f7ce3b756715964c  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 198
550: sched_cls  name cil_from_container  tag e772864750194f09  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 204
551: sched_cls  name tail_ipv4_ct_egress  tag ebffff840e3db54f  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 205
552: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 206
553: sched_cls  name tail_ipv4_to_endpoint  tag 3d295de88cf20bd3  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_ipv4_to_endpoint  tag 9e3f8f244c779d52  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 221
610: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 222
611: sched_cls  name cil_from_container  tag c93aed96f861dfd1  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 223
612: sched_cls  name handle_policy  tag 908d3d43fe69ccca  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 224
613: sched_cls  name tail_ipv4_ct_egress  tag 0da065b7ac2d8652  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 225
614: sched_cls  name __send_drop_notify  tag 7d23c81e5e322d51  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 226
616: sched_cls  name tail_handle_ipv4  tag 0e82c0cd4e899c11  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 228
617: sched_cls  name tail_handle_ipv4_cont  tag 7aa368e69dac6fb7  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 229
618: sched_cls  name tail_ipv4_ct_ingress  tag 4408133c9649a0ff  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 230
619: sched_cls  name tail_handle_arp  tag 84cac6bb5ab1a694  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
