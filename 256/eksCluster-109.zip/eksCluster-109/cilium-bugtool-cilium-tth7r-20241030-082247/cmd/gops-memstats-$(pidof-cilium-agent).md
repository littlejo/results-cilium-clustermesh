alloc: 191.05MB (200327536 bytes)
total-alloc: 2.23GB (2392338328 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 63033125
frees: 61015006
heap-alloc: 191.05MB (200327536 bytes)
heap-sys: 247.55MB (259571712 bytes)
heap-idle: 29.91MB (31367168 bytes)
heap-in-use: 217.63MB (228204544 bytes)
heap-released: 912.00KB (933888 bytes)
heap-objects: 2018119
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 3.40MB (3566720 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1255337 bytes)
gc-sys: 6.00MB (6294920 bytes)
next-gc: when heap-alloc >= 214.67MB (225102744 bytes)
last-gc: 2024-10-30 08:22:49.870478507 +0000 UTC
gc-pause-total: 15.567842ms
gc-pause: 211457
gc-pause-end: 1730276569870478507
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004430411765261888
enable-gc: true
debug-gc: false
