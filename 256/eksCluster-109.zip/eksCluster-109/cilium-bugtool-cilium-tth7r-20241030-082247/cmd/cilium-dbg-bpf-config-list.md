KEY             VALUE
AgentLiveness   2031063288161
UTimeOffset     3379442517578125
