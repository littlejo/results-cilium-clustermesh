Endpoint ID: 254
Path: /sys/fs/bpf/tc/globals/cilium_policy_00254

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    136189   1559      0        
Allow    Egress      0          ANY          NONE         disabled    17324    190       0        


Endpoint ID: 317
Path: /sys/fs/bpf/tc/globals/cilium_policy_00317

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11497751   114168    0        
Allow    Ingress     1          ANY          NONE         disabled    9634463    100891    0        
Allow    Egress      0          ANY          NONE         disabled    12488426   122925    0        


Endpoint ID: 1064
Path: /sys/fs/bpf/tc/globals/cilium_policy_01064

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1367
Path: /sys/fs/bpf/tc/globals/cilium_policy_01367

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1632268   20581     0        
Allow    Ingress     1          ANY          NONE         disabled    20934     246       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1439
Path: /sys/fs/bpf/tc/globals/cilium_policy_01439

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    137443   1578      0        
Allow    Egress      0          ANY          NONE         disabled    18232    201       0        


