# Cilium debug information

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.109.0.0/24, 
Allocated addresses:
  10.109.0.110 (kube-system/clustermesh-apiserver-787b9c7bc4-d4dg8)
  10.109.0.166 (health)
  10.109.0.210 (kube-system/coredns-cc6ccd49c-mcxc6)
  10.109.0.240 (kube-system/coredns-cc6ccd49c-8bpjl)
  10.109.0.86 (router)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 407988f72c3ac32e
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    56s ago        never        0       no error   
  ct-map-pressure                                                     27s ago        never        0       no error   
  daemon-validate-config                                              34s ago        never        0       no error   
  dns-garbage-collector-job                                           1m2s ago       never        0       no error   
  endpoint-1064-regeneration-recovery                                 never          never        0       no error   
  endpoint-1367-regeneration-recovery                                 never          never        0       no error   
  endpoint-1439-regeneration-recovery                                 never          never        0       no error   
  endpoint-254-regeneration-recovery                                  never          never        0       no error   
  endpoint-317-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m2s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                27s ago        never        0       no error   
  ipcache-inject-labels                                               57s ago        never        0       no error   
  k8s-heartbeat                                                       2s ago         never        0       no error   
  link-cache                                                          12s ago        never        0       no error   
  local-identity-checkpoint                                           23m57s ago     never        0       no error   
  node-neighbor-link-updater                                          7s ago         never        0       no error   
  remote-etcd-cmesh1                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh10                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh100                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh101                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh102                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh103                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh104                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh105                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh106                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh107                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh108                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh109                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh11                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh111                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh112                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh113                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh114                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh115                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh116                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh117                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh118                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh119                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh12                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh120                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh121                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh122                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh123                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh124                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh125                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh126                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh127                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh128                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh129                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh13                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh130                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh131                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh132                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh133                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh134                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh135                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh136                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh137                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh138                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh139                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh14                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh140                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh141                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh142                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh143                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh144                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh145                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh146                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh147                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh148                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh149                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh15                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh150                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh151                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh152                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh153                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh154                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh155                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh156                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh157                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh158                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh159                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh16                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh160                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh161                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh162                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh163                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh164                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh165                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh166                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh167                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh168                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh169                                                11m6s ago      never        0       no error   
  remote-etcd-cmesh17                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh170                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh171                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh172                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh173                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh174                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh175                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh176                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh177                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh178                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh179                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh18                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh180                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh181                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh182                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh183                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh184                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh185                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh186                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh187                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh188                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh189                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh19                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh190                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh191                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh192                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh193                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh194                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh195                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh196                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh197                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh198                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh199                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh2                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh20                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh200                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh201                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh202                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh203                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh204                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh205                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh206                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh207                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh208                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh209                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh21                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh210                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh211                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh212                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh213                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh214                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh215                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh216                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh217                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh218                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh219                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh22                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh220                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh221                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh222                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh223                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh224                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh225                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh226                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh227                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh228                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh229                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh23                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh230                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh231                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh232                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh233                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh234                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh235                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh236                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh237                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh238                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh239                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh24                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh240                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh241                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh242                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh243                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh244                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh245                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh246                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh247                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh248                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh249                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh25                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh250                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh251                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh252                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh253                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh254                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh255                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh256                                                11m5s ago      never        0       no error   
  remote-etcd-cmesh26                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh27                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh28                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh29                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh3                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh30                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh31                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh32                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh33                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh34                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh35                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh36                                                 11m6s ago      never        0       no error   
  remote-etcd-cmesh37                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh38                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh39                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh4                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh40                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh41                                                 11m6s ago      never        0       no error   
  remote-etcd-cmesh42                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh43                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh44                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh45                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh46                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh47                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh48                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh49                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh5                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh50                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh51                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh52                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh53                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh54                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh55                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh56                                                 11m6s ago      never        0       no error   
  remote-etcd-cmesh57                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh58                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh59                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh6                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh60                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh61                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh62                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh63                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh64                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh65                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh66                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh67                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh68                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh69                                                 11m6s ago      never        0       no error   
  remote-etcd-cmesh7                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh70                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh71                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh72                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh73                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh74                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh75                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh76                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh77                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh78                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh79                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh8                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh80                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh81                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh82                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh83                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh84                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh85                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh86                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh87                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh88                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh89                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh9                                                  11m5s ago      never        0       no error   
  remote-etcd-cmesh90                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh91                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh92                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh93                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh94                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh95                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh96                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh97                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh98                                                 11m5s ago      never        0       no error   
  remote-etcd-cmesh99                                                 11m5s ago      never        0       no error   
  resolve-identity-1064                                               3m57s ago      never        0       no error   
  resolve-identity-1367                                               3m56s ago      never        0       no error   
  resolve-identity-1439                                               3m55s ago      never        0       no error   
  resolve-identity-254                                                3m54s ago      never        0       no error   
  resolve-identity-317                                                2m4s ago       never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-787b9c7bc4-d4dg8   12m4s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-8bpjl                  23m55s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mcxc6                  23m54s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      23m57s ago     never        0       no error   
  sync-policymap-1064                                                 8m56s ago      never        0       no error   
  sync-policymap-1367                                                 8m53s ago      never        0       no error   
  sync-policymap-1439                                                 8m53s ago      never        0       no error   
  sync-policymap-254                                                  8m52s ago      never        0       no error   
  sync-policymap-317                                                  12m4s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1439)                                   4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (254)                                    4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (317)                                    4s ago         never        0       no error   
  sync-utime                                                          57s ago        never        0       no error   
  write-cni-file                                                      24m2s ago      never        0       no error   
Proxy Status:            OK, ip 10.109.0.86, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3604480, max 3637247
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 139.87   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
254        Disabled           Disabled          3623475    k8s:eks.amazonaws.com/component=coredns                                             10.109.0.210   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh110                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
317        Disabled           Disabled          3619655    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.109.0.110   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh110                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
1064       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                 
                                                           reserved:host                                                                                              
1367       Disabled           Disabled          4          reserved:health                                                                     10.109.0.166   ready   
1439       Disabled           Disabled          3623475    k8s:eks.amazonaws.com/component=coredns                                             10.109.0.240   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh110                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
```

#### BPF Policy Get 254

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    136189   1559      0        
Allow    Egress      0          ANY          NONE         disabled    17324    190       0        

```


#### BPF CT List 254

```
Invalid argument: unknown type 254
```


#### Endpoint Get 254

```
[
  {
    "id": 254,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-254-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6f7a0d04-8467-4ade-9054-1526da632d87"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-254",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:25.224Z",
            "success-count": 5
          },
          "uuid": "ba9468dc-0588-4e16-b5b6-0fe3112e3af3"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mcxc6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:59:25.222Z",
            "success-count": 1
          },
          "uuid": "593e9b16-07ec-4e02-a542-3e7fc6019c40"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-254",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:14:27.189Z",
            "success-count": 2
          },
          "uuid": "495ffcc7-936e-4693-be75-297a62c67803"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (254)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:15.343Z",
            "success-count": 145
          },
          "uuid": "9196f143-d5b4-4a43-b8ed-5cf1d28f4eeb"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b6bd25ccaf1bf882a316617dd8684f565a5ff9bb6d2188b3be24f43279a64b32:eth0",
        "container-id": "b6bd25ccaf1bf882a316617dd8684f565a5ff9bb6d2188b3be24f43279a64b32",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mcxc6",
        "pod-name": "kube-system/coredns-cc6ccd49c-mcxc6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3623475,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:16Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.109.0.210",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "32:ad:5e:f0:c7:b8",
        "interface-index": 14,
        "interface-name": "lxc82e2ff3fd502",
        "mac": "ba:33:b1:07:99:7c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3623475,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3623475,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 254

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 254

```
Timestamp              Status   State                   Message
2024-10-30T08:12:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:59:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:59:27Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:59:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:59:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:59:25Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:59:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3623475

```
ID        LABELS
3623475   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh110
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 317

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11460255   113755    0        
Allow    Ingress     1          ANY          NONE         disabled    9634463    100891    0        
Allow    Egress      0          ANY          NONE         disabled    12477666   122806    0        

```


#### BPF CT List 317

```
Invalid argument: unknown type 317
```


#### Endpoint Get 317

```
[
  {
    "id": 317,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-317-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "c9e96756-c029-42eb-8903-56a7f0880d9a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-317",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:15.609Z",
            "success-count": 3
          },
          "uuid": "8e6fdd9c-45d0-491f-8681-0ca2e5cbe3a7"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-787b9c7bc4-d4dg8",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:15.608Z",
            "success-count": 1
          },
          "uuid": "b679da58-65b7-43d1-8f8b-ad62bb104be6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-317",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:15.649Z",
            "success-count": 1
          },
          "uuid": "fd35c26e-273d-4150-b105-d098967978fd"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (317)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:15.688Z",
            "success-count": 74
          },
          "uuid": "47e929e2-b721-4c9b-b43a-215509911ee2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "2d93a7d81f55f13113e1246d181127f1dcecba4e62c3cc2ab11f4c2ba5254fae:eth0",
        "container-id": "2d93a7d81f55f13113e1246d181127f1dcecba4e62c3cc2ab11f4c2ba5254fae",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-787b9c7bc4-d4dg8",
        "pod-name": "kube-system/clustermesh-apiserver-787b9c7bc4-d4dg8"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3619655,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=787b9c7bc4"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:16Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.109.0.110",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:70:2e:b5:3d:6f",
        "interface-index": 18,
        "interface-name": "lxc6e41bf320114",
        "mac": "26:87:5a:fb:bd:d4"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3619655,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3619655,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 317

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 317

```
Timestamp              Status   State                   Message
2024-10-30T08:12:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:11:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:11:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:11:15Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:11:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3619655

```
ID        LABELS
3619655   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh110
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1064

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1064

```
Invalid argument: unknown type 1064
```


#### Endpoint Get 1064

```
[
  {
    "id": 1064,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1064-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8c89a3dc-afea-4ad9-8230-78c367712d0d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1064",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:22.626Z",
            "success-count": 5
          },
          "uuid": "4e4c606d-4876-442d-9098-b204a63ca992"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1064",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:14:23.706Z",
            "success-count": 2
          },
          "uuid": "2cd30109-4b8d-4176-b294-13f8285b9225"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:16Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "f6:c2:af:da:4c:c7",
        "interface-name": "cilium_host",
        "mac": "f6:c2:af:da:4c:c7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1064

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1064

```
Timestamp              Status   State                   Message
2024-10-30T08:12:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:59:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:59:27Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:59:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:59:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:59:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:24Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:59:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:59:23Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:59:23Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:59:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:59:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:59:22Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:59:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1367

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1630573   20560     0        
Allow    Ingress     1          ANY          NONE         disabled    20934     246       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 1367

```
Invalid argument: unknown type 1367
```


#### Endpoint Get 1367

```
[
  {
    "id": 1367,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1367-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a38d81fc-5811-495d-8328-91f0b8433f83"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1367",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:23.701Z",
            "success-count": 5
          },
          "uuid": "611ab354-b36e-463b-8eb3-515632bfd747"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1367",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:14:27.099Z",
            "success-count": 2
          },
          "uuid": "846aa98b-8db5-4a78-abba-8288e03cd085"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:16Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.109.0.166",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "86:4d:41:d4:a8:2f",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "0a:b8:2f:08:c5:a8"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1367

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1367

```
Timestamp              Status   State                   Message
2024-10-30T08:12:16Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:16Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:16Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:12:16Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:15Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:14Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:14Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:14Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:14Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:13Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:13Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:13Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:13Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:27Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:59:27Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:59:27Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:59:27Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:59:26Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T07:59:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:59:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:59:23Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:59:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:59:23Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:59:22Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1439

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    137443   1578      0        
Allow    Egress      0          ANY          NONE         disabled    18232    201       0        

```


#### BPF CT List 1439

```
Invalid argument: unknown type 1439
```


#### Endpoint Get 1439

```
[
  {
    "id": 1439,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1439-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "06007157-be40-4659-bb3a-1a211c28c936"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1439",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:25.127Z",
            "success-count": 5
          },
          "uuid": "f0f503e0-4c04-485e-a76e-c7eb9e7e1903"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-8bpjl",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:59:25.123Z",
            "success-count": 1
          },
          "uuid": "ad9d5f94-8513-467a-8a14-6d0ce8ab11ff"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1439",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:14:27.098Z",
            "success-count": 2
          },
          "uuid": "8ad5f228-b301-497a-aa77-2a6a5d011ec9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1439)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:15.235Z",
            "success-count": 145
          },
          "uuid": "9b14eea8-bddf-4710-8873-70b75bea7d91"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "0fa565cc5d2425becab240c7be0120ed5f4fa45bd9697c0c0ed3b886052cbf1f:eth0",
        "container-id": "0fa565cc5d2425becab240c7be0120ed5f4fa45bd9697c0c0ed3b886052cbf1f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-8bpjl",
        "pod-name": "kube-system/coredns-cc6ccd49c-8bpjl"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3623475,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh110",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:12:16Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.109.0.240",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "f2:9b:20:62:54:a3",
        "interface-index": 12,
        "interface-name": "lxccbd7ad8eed8f",
        "mac": "b6:76:87:e7:d5:ea"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3623475,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3623475,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1439

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1439

```
Timestamp              Status    State                   Message
2024-10-30T08:12:16Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:12:16Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:16Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:12:16Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:12:15Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:15Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:15Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:15Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:14Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:14Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:14Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:14Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:12:13Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:12:13Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:12:13Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:12:13Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:10Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:10Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:10Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:10Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:27Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:59:27Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:59:27Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:59:27Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:59:26Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:25Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:59:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:59:25Z   OK        ready                   Set identity for this endpoint
2024-10-30T07:59:25Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:59:25Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3623475

```
ID        LABELS
3623475   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh110
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33626821                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33626821                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33626821                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4014800000 rw-p 00000000 00:00 0 
4014800000-4018000000 ---p 00000000 00:00 0 
ffff3be87000-ffff3c25f000 rw-p 00000000 00:00 0 
ffff3c263000-ffff3c354000 rw-p 00000000 00:00 0 
ffff3c35b000-ffff3c44d000 rw-p 00000000 00:00 0 
ffff3c44d000-ffff3c48e000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3c48e000-ffff3c4cf000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3c4cf000-ffff3c50f000 rw-p 00000000 00:00 0 
ffff3c50f000-ffff3c511000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3c511000-ffff3c513000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff3c513000-ffff3caba000 rw-p 00000000 00:00 0 
ffff3caba000-ffff3cbba000 rw-p 00000000 00:00 0 
ffff3cbba000-ffff3cbcb000 rw-p 00000000 00:00 0 
ffff3cbcb000-ffff3ebcb000 rw-p 00000000 00:00 0 
ffff3ebcb000-ffff3ec4b000 ---p 00000000 00:00 0 
ffff3ec4b000-ffff3ec4c000 rw-p 00000000 00:00 0 
ffff3ec4c000-ffff5ec4b000 ---p 00000000 00:00 0 
ffff5ec4b000-ffff5ec4c000 rw-p 00000000 00:00 0 
ffff5ec4c000-ffff7ebdb000 ---p 00000000 00:00 0 
ffff7ebdb000-ffff7ebdc000 rw-p 00000000 00:00 0 
ffff7ebdc000-ffff82bcd000 ---p 00000000 00:00 0 
ffff82bcd000-ffff82bce000 rw-p 00000000 00:00 0 
ffff82bce000-ffff833cb000 ---p 00000000 00:00 0 
ffff833cb000-ffff833cc000 rw-p 00000000 00:00 0 
ffff833cc000-ffff834cb000 ---p 00000000 00:00 0 
ffff834cb000-ffff8352b000 rw-p 00000000 00:00 0 
ffff8352b000-ffff8352d000 r--p 00000000 00:00 0                          [vvar]
ffff8352d000-ffff8352e000 r-xp 00000000 00:00 0                          [vdso]
ffffe0c4d000-ffffe0c6e000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium environment keys

```
gops-port:9890
conntrack-gc-interval:0s
tofqdns-max-deferred-connection-deletes:10000
tunnel-protocol:vxlan
container-ip-local-reserved-ports:auto
cluster-health-port:4240
l2-pod-announcements-interface:
agent-labels:
node-port-acceleration:disabled
clustermesh-sync-timeout:1m0s
log-driver:
wireguard-persistent-keepalive:0s
monitor-queue-size:0
bpf-root:/sys/fs/bpf
enable-k8s:true
lib-dir:/var/lib/cilium
nodeport-addresses:
enable-ipsec:false
ipsec-key-rotation-duration:5m0s
vtep-mask:
k8s-service-cache-size:128
enable-hubble:true
srv6-encap-mode:reduced
enable-monitor:true
ipv6-mcast-device:
local-max-addr-scope:252
ipv4-pod-subnets:
bpf-lb-rss-ipv6-src-cidr:
enable-icmp-rules:true
operator-api-serve-addr:127.0.0.1:9234
policy-audit-mode:false
enable-metrics:true
use-cilium-internal-ip-for-ipsec:false
bpf-auth-map-max:524288
enable-tracing:false
bpf-ct-global-tcp-max:524288
allocator-list-timeout:3m0s
node-port-range:
envoy-config-retry-interval:15s
k8s-sync-timeout:3m0s
cni-chaining-mode:none
hubble-export-file-compress:false
bpf-ct-timeout-regular-tcp:2h13m20s
enable-host-legacy-routing:false
l2-announcements-lease-duration:15s
enable-mke:false
enable-tcx:true
trace-payloadlen:128
fqdn-regex-compile-lru-size:1024
ipv4-service-loopback-address:169.254.42.1
operator-prometheus-serve-addr::9963
bpf-lb-source-range-map-max:0
api-rate-limit:
bpf-ct-timeout-regular-tcp-fin:10s
envoy-log:
bpf-nat-global-max:524288
bpf-filter-priority:1
trace-sock:true
enable-bpf-tproxy:false
enable-route-mtu-for-cni-chaining:false
hubble-export-file-max-backups:5
mesh-auth-enabled:true
vtep-mac:
k8s-client-connection-keep-alive:30s
hubble-metrics:
cmdref:
l2-announcements-renew-deadline:5s
dnsproxy-enable-transparent-mode:true
disable-envoy-version-check:false
route-metric:0
enable-ipsec-encrypted-overlay:false
static-cnp-path:
enable-host-firewall:false
bpf-policy-map-full-reconciliation-interval:15m0s
vtep-cidr:
enable-ipv4:true
disable-endpoint-crd:false
hubble-redact-http-urlquery:false
derive-masq-ip-addr-from-device:
hubble-skip-unknown-cgroup-ids:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
http-normalize-path:true
proxy-max-requests-per-connection:0
cni-log-file:/var/run/cilium/cilium-cni.log
enable-ipsec-xfrm-state-caching:true
pprof:false
enable-bpf-masquerade:false
prepend-iptables-chains:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
node-labels:
agent-health-port:9879
dnsproxy-concurrency-processing-grace-period:0s
envoy-config-timeout:2m0s
proxy-idle-timeout-seconds:60
proxy-xff-num-trusted-hops-ingress:0
bpf-lb-external-clusterip:false
policy-cidr-match-mode:
set-cilium-is-up-condition:true
proxy-max-connection-duration-seconds:0
nat-map-stats-interval:30s
mesh-auth-signal-backoff-duration:1s
hubble-socket-path:/var/run/cilium/hubble.sock
clustermesh-enable-mcs-api:false
conntrack-gc-max-interval:0s
l2-announcements-retry-period:2s
enable-encryption-strict-mode:false
enable-unreachable-routes:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
monitor-aggregation:medium
proxy-connect-timeout:2
dnsproxy-lock-timeout:500ms
controller-group-metrics:
kvstore-max-consecutive-quorum-errors:2
arping-refresh-period:30s
bpf-lb-maglev-map-max:0
ipv6-service-range:auto
enable-endpoint-routes:false
enable-ipsec-key-watcher:true
metrics:
label-prefix-file:
restore:true
bpf-ct-global-any-max:262144
join-cluster:false
hubble-redact-enabled:false
bpf-lb-sock-hostns-only:false
local-router-ipv6:
http-idle-timeout:0
vlan-bpf-bypass:
bpf-lb-affinity-map-max:0
force-device-detection:false
http-max-grpc-timeout:0
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
cni-external-routing:false
max-controller-interval:0
hubble-disable-tls:false
k8s-require-ipv4-pod-cidr:false
hubble-metrics-server:
k8s-require-ipv6-pod-cidr:false
bpf-lb-maglev-table-size:16381
exclude-local-address:
enable-sctp:false
tofqdns-dns-reject-response-code:refused
k8s-service-proxy-name:
mesh-auth-queue-size:1024
bpf-lb-mode:snat
proxy-xff-num-trusted-hops-egress:0
direct-routing-skip-unreachable:false
dnsproxy-concurrency-limit:0
custom-cni-conf:false
pprof-port:6060
local-router-ipv4:
ipam:cluster-pool
kvstore-opt:
routing-mode:tunnel
hubble-event-buffer-capacity:4095
policy-accounting:true
dnsproxy-lock-count:131
enable-stale-cilium-endpoint-cleanup:true
mtu:0
hubble-export-file-path:
encryption-strict-mode-allow-remote-node-identities:false
http-request-timeout:3600
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bypass-ip-availability-upon-restore:false
hubble-drop-events-reasons:auth_required,policy_denied
mesh-auth-spire-admin-socket:
hubble-prefer-ipv6:false
kvstore-connectivity-timeout:2m0s
tofqdns-idle-connection-grace-period:0s
ipam-cilium-node-update-rate:15s
bpf-ct-timeout-regular-tcp-syn:1m0s
envoy-base-id:0
hubble-listen-address::4244
enable-cilium-health-api-server-access:
ipsec-key-file:
debug-verbose:
enable-masquerade-to-route-source:false
certificates-directory:/var/run/cilium/certs
install-iptables-rules:true
endpoint-bpf-prog-watchdog-interval:30s
enable-l7-proxy:true
bpf-map-dynamic-size-ratio:0.0025
clustermesh-ip-identities-sync-timeout:1m0s
version:false
debug:false
config-dir:/tmp/cilium/config-map
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
enable-pmtu-discovery:false
annotate-k8s-node:false
bpf-events-policy-verdict-enabled:true
bpf-lb-acceleration:disabled
enable-bandwidth-manager:false
encrypt-node:false
nat-map-stats-entries:32
ipv6-node:auto
direct-routing-device:
monitor-aggregation-flags:all
policy-trigger-interval:1s
enable-health-check-nodeport:true
hubble-redact-kafka-apikey:false
bpf-ct-timeout-regular-any:1m0s
bpf-lb-service-backend-map-max:0
service-no-backend-response:reject
procfs:/host/proc
hubble-redact-http-headers-allow:
ipv6-pod-subnets:
cflags:
cluster-pool-ipv4-mask-size:24
bpf-lb-dsr-l4-xlate:frontend
enable-srv6:false
k8s-client-burst:20
enable-ipip-termination:false
k8s-api-server:
bpf-events-trace-enabled:true
envoy-secrets-namespace:
k8s-kubeconfig-path:
proxy-prometheus-port:0
enable-ipv4-masquerade:true
multicast-enabled:false
encryption-strict-mode-cidr:
hubble-drop-events-interval:2m0s
bgp-config-path:/var/lib/cilium/bgp/config.yaml
mke-cgroup-mount:
enable-xdp-prefilter:false
hubble-event-queue-size:0
enable-local-node-route:true
kvstore:
enable-ipv4-fragment-tracking:true
enable-node-selector-labels:false
disable-iptables-feeder-rules:
hubble-redact-http-headers-deny:
set-cilium-node-taints:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
bpf-fragments-map-max:8192
enable-cilium-endpoint-slice:false
bpf-policy-map-max:16384
ipv4-native-routing-cidr:
node-port-algorithm:random
enable-node-port:false
k8s-client-qps:10
devices:
vtep-endpoint:
socket-path:/var/run/cilium/cilium.sock
enable-service-topology:false
identity-allocation-mode:crd
k8s-client-connection-timeout:30s
enable-svc-source-range-check:true
gateway-api-secrets-namespace:
mesh-auth-spiffe-trust-domain:spiffe.cilium
ipv4-node:auto
enable-cilium-api-server-access:
egress-gateway-policy-map-max:16384
enable-ipv4-egress-gateway:false
enable-wireguard-userspace-fallback:false
mesh-auth-mutual-listener-port:0
iptables-lock-timeout:5s
nodes-gc-interval:5m0s
enable-k8s-networkpolicy:true
hubble-flowlogs-config-path:
bgp-announce-lb-ip:false
cluster-id:110
hubble-redact-http-userinfo:true
enable-ipv6-ndp:false
proxy-gid:1337
enable-local-redirect-policy:false
egress-masquerade-interfaces:ens+
bpf-sock-rev-map-max:262144
bpf-map-event-buffers:
enable-k8s-terminating-endpoint:true
tofqdns-proxy-response-max-delay:100ms
bpf-node-map-max:16384
node-port-mode:snat
use-full-tls-context:false
crd-wait-timeout:5m0s
agent-liveness-update-interval:1s
bpf-lb-map-max:65536
mesh-auth-gc-interval:5m0s
bpf-lb-service-map-max:0
hubble-export-file-max-size-mb:10
envoy-keep-cap-netbindservice:false
enable-ipv6-masquerade:true
enable-wireguard:false
cluster-name:cmesh110
hubble-drop-events:false
tofqdns-pre-cache:
labels:
dnsproxy-insecure-skip-transparent-mode-check:false
unmanaged-pod-watcher-interval:15
http-retry-timeout:0
mesh-auth-mutual-connect-timeout:5s
tofqdns-min-ttl:0
log-opt:
identity-heartbeat-timeout:30m0s
policy-queue-size:100
kvstore-lease-ttl:15m0s
ingress-secrets-namespace:
pprof-address:localhost
clustermesh-config:/var/lib/cilium/clustermesh/
read-cni-conf:
enable-bgp-control-plane:false
synchronize-k8s-nodes:true
config:
bpf-lb-rev-nat-map-max:0
enable-endpoint-health-checking:true
enable-ip-masq-agent:false
encrypt-interface:
max-connected-clusters:511
enable-envoy-config:false
tunnel-port:0
tofqdns-enable-dns-compression:true
ipv6-native-routing-cidr:
bpf-lb-dsr-dispatch:opt
enable-k8s-endpoint-slice:true
dns-policy-unload-on-shutdown:false
enable-auto-protect-node-port-range:true
disable-external-ip-mitigation:false
hubble-monitor-events:
dns-max-ips-per-restored-rule:1000
enable-nat46x64-gateway:false
identity-gc-interval:15m0s
log-system-load:false
install-no-conntrack-iptables-rules:false
external-envoy-proxy:true
identity-restore-grace-period:30s
enable-health-check-loadbalancer-ip:false
allow-icmp-frag-needed:true
bpf-ct-timeout-service-tcp:2h13m20s
clustermesh-enable-endpoint-sync:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
max-internal-timer-delay:0s
prometheus-serve-addr:
hubble-recorder-sink-queue-size:1024
tofqdns-proxy-port:0
bpf-neigh-global-max:524288
auto-create-cilium-node-resource:true
enable-active-connection-tracking:false
bpf-events-drop-enabled:true
enable-k8s-api-discovery:false
enable-bpf-clock-probe:false
tofqdns-endpoint-max-ip-per-hostname:50
enable-hubble-recorder-api:true
enable-session-affinity:false
monitor-aggregation-interval:5s
enable-l2-pod-announcements:false
iptables-random-fully:false
bgp-announce-pod-cidr:false
auto-direct-node-routes:false
enable-policy:default
enable-identity-mark:true
endpoint-queue-size:25
hubble-export-allowlist:
enable-high-scale-ipcache:false
enable-vtep:false
kube-proxy-replacement-healthz-bind-address:
enable-host-port:false
proxy-portrange-max:20000
identity-change-grace-period:5s
ipam-default-ip-pool:default
bpf-lb-algorithm:random
endpoint-gc-interval:5m0s
kube-proxy-replacement:false
hubble-export-denylist:
cluster-pool-ipv4-cidr:10.109.0.0/16
preallocate-bpf-maps:false
remove-cilium-node-taints:true
node-port-bind-protection:true
cgroup-root:/run/cilium/cgroupv2
proxy-portrange-min:10000
allow-localhost:auto
ipv4-service-range:auto
ipam-multi-pool-pre-allocation:
bpf-lb-sock-terminate-pod-connections:false
cni-exclusive:true
bpf-ct-timeout-service-tcp-grace:1m0s
fixed-identity-mapping:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
bpf-ct-timeout-service-any:1m0s
keep-config:false
state-dir:/var/run/cilium
enable-external-ips:false
enable-l2-neigh-discovery:true
ipv6-range:auto
enable-gateway-api:false
enable-ipv6-big-tcp:false
enable-xt-socket-fallback:true
enable-ipv4-big-tcp:false
k8s-namespace:kube-system
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-recorder:false
cilium-endpoint-gc-interval:5m0s
k8s-heartbeat-timeout:30s
enable-l2-announcements:false
ipv6-cluster-alloc-cidr:f00d::/64
enable-runtime-device-detection:true
cni-chaining-target:
enable-health-checking:true
datapath-mode:veth
enable-ingress-controller:false
mesh-auth-rotated-identities-queue-size:1024
bpf-lb-sock:false
ipv4-range:auto
http-retry-count:3
enable-custom-calls:false
egress-gateway-reconciliation-trigger-interval:1s
enable-ipv6:false
dnsproxy-socket-linger-timeout:10
proxy-admin-port:0
enable-well-known-identities:false
config-sources:config-map:kube-system/cilium-config
enable-bbr:false
hubble-export-fieldmask:
exclude-node-label-patterns:
egress-multi-home-ip-rule-compat:false
bpf-lb-rss-ipv4-src-cidr:
kvstore-periodic-sync:5m0s
```


#### Service list

```
ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.237.54:443 (active)     
                                         2 => 172.31.173.246:443 (active)    
2    10.100.182.162:443   ClusterIP      1 => 172.31.242.123:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.109.0.240:53 (active)       
                                         2 => 10.109.0.210:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.109.0.240:9153 (active)     
                                         2 => 10.109.0.210:9153 (active)     
5    10.100.26.60:2379    ClusterIP      1 => 10.109.0.110:2379 (active)     
```

#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.109.0.210": (string) (len=35) "kube-system/coredns-cc6ccd49c-mcxc6",
  (string) (len=12) "10.109.0.110": (string) (len=50) "kube-system/clustermesh-apiserver-787b9c7bc4-d4dg8",
  (string) (len=11) "10.109.0.86": (string) (len=6) "router",
  (string) (len=12) "10.109.0.166": (string) (len=6) "health",
  (string) (len=12) "10.109.0.240": (string) (len=35) "kube-system/coredns-cc6ccd49c-8bpjl"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.242.123": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000ef71e0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001cdade0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001cdade0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x40012ff340)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40012ff3f0)(frontends:[10.100.182.162]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40012ff4a0)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x40006b88f0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40012febb0)(frontends:[10.100.26.60]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4000d3da50)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-nk5n7": (*k8s.Endpoints)(0x4002003d40)(172.31.242.123:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4000d3da58)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-np8xp": (*k8s.Endpoints)(0x4003132b60)(10.109.0.210:53/TCP[eu-west-3b],10.109.0.210:53/UDP[eu-west-3b],10.109.0.210:9153/TCP[eu-west-3b],10.109.0.240:53/TCP[eu-west-3b],10.109.0.240:53/UDP[eu-west-3b],10.109.0.240:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000d3cbb8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-q96rw": (*k8s.Endpoints)(0x4002770820)(10.109.0.110:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4000d3da48)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002c30680)(172.31.173.246:443/TCP,172.31.237.54:443/TCP)
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001a5e070)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4002033b80)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x401152e828
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001c95980,
  gcExited: (chan struct {}) 0x4001c95a40,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b86780)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012fb428)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45740)({
       metricMap: (*prometheus.metricMap)(0x4001c45770)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32600)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b86800)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012fb430)({
      MetricVec: (*prometheus.MetricVec)(0x4001c457d0)({
       metricMap: (*prometheus.metricMap)(0x4001c45800)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32660)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b86880)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb438)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45860)({
       metricMap: (*prometheus.metricMap)(0x4001c45890)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a326c0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b86900)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb440)({
      MetricVec: (*prometheus.MetricVec)(0x4001c458f0)({
       metricMap: (*prometheus.metricMap)(0x4001c45920)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32720)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b86980)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb448)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45980)({
       metricMap: (*prometheus.metricMap)(0x4001c459b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32780)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b86a00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb450)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45a10)({
       metricMap: (*prometheus.metricMap)(0x4001c45a40)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a327e0)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b86a80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb458)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45aa0)({
       metricMap: (*prometheus.metricMap)(0x4001c45ad0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32840)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b86b00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012fb468)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45b30)({
       metricMap: (*prometheus.metricMap)(0x4001c45b60)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a328a0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b86b80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012fb470)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45bc0)({
       metricMap: (*prometheus.metricMap)(0x4001c45bf0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001a32900)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001a5e070)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40004d3570)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001d54618)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 361ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium encryption


