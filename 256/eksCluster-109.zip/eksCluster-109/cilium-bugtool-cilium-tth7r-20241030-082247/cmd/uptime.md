 08:22:48 up 33 min,  0 users,  load average: 0.81, 0.34, 0.22
