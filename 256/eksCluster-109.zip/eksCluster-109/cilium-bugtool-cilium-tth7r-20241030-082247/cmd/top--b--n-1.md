top - 08:22:48 up 33 min,  0 users,  load average: 0.81, 0.34, 0.22
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 27.6 sy,  0.0 ni, 62.1 id,  3.4 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4476.2 free,   1191.7 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6437.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 383504  77952 S   6.7   4.8   0:51.44 cilium-+
    846 root      20   0 1240432  16436  11484 S   6.7   0.2   0:00.03 cilium-+
    591 root      20   0 1229488   6928   2864 S   0.0   0.1   0:01.14 cilium-+
    809 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    825 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    835 root      20   0 1228744   3840   3168 S   0.0   0.0   0:00.00 gops
    845 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    880 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    887 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    908 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
