[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50571281_86b7_4d74_b798_cf37e660125e.slice/cri-containerd-2af8b70e98754af5a86f64599561ae2c63d741e98ca95392994465ccb557c3c4.scope"
      }
    ],
    "ips": [
      "10.109.0.240"
    ],
    "name": "coredns-cc6ccd49c-8bpjl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod847487e2_f85c_401a_b920_cf1d4060e1e4.slice/cri-containerd-ce4faee3d150703949b21dd8b6ac981e3bf539d99fc926a777d92b773376d42f.scope"
      }
    ],
    "ips": [
      "10.109.0.210"
    ],
    "name": "coredns-cc6ccd49c-mcxc6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-4c65ae80b166bb82e28787e1b03eeb8869c533a338e0538491fd48c5350e8d04.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-043476c30ed95c0337224382ff7912828b6bcb3d965d546cf2d5ad058171afe5.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d10551_3227_4290_bd01_26114406f3da.slice/cri-containerd-5ef65cfca7b32a6b81497d3fee5c1574a6baa8b850ae58b88d3b7dc6e8c16290.scope"
      }
    ],
    "ips": [
      "10.109.0.110"
    ],
    "name": "clustermesh-apiserver-787b9c7bc4-d4dg8",
    "namespace": "kube-system"
  }
]

