ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.237.54:443 (active)     
                                         2 => 172.31.173.246:443 (active)    
2    10.100.182.162:443   ClusterIP      1 => 172.31.242.123:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.109.0.240:53 (active)       
                                         2 => 10.109.0.210:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.109.0.240:9153 (active)     
                                         2 => 10.109.0.210:9153 (active)     
5    10.100.26.60:2379    ClusterIP      1 => 10.109.0.110:2379 (active)     
