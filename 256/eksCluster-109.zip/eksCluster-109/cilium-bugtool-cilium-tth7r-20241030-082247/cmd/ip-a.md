1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a6:04:5d:ca:3f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.123/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3411sec preferred_lft 3411sec
    inet6 fe80::8a6:4ff:fe5d:ca3f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6d:9b:9c:6a:1b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.43/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86d:9bff:fe9c:6a1b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:bd:42:ec:d0:e6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8bd:42ff:feec:d0e6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:c2:af:da:4c:c7 brd ff:ff:ff:ff:ff:ff
    inet 10.109.0.86/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f4c2:afff:feda:4cc7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:1e:bd:d6:92:15 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::681e:bdff:fed6:9215/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:4d:41:d4:a8:2f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::844d:41ff:fed4:a82f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxccbd7ad8eed8f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:9b:20:62:54:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f09b:20ff:fe62:54a3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc82e2ff3fd502@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:ad:5e:f0:c7:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::30ad:5eff:fef0:c7b8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6e41bf320114@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:70:2e:b5:3d:6f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a470:2eff:feb5:3d6f/64 scope link 
       valid_lft forever preferred_lft forever
