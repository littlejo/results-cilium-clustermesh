key: fe 00 00 00  value: 25 02 00 00
key: 3d 01 00 00  value: 64 02 00 00
key: 57 05 00 00  value: 1a 02 00 00
key: 9f 05 00 00  value: 03 02 00 00
Found 4 elements
