IP ADDRESS         LOCAL ENDPOINT INFO
10.190.0.235:0     (localhost)                                                                                        
10.190.0.220:0     id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80     
172.31.155.14:0    (localhost)                                                                                        
10.190.0.50:0      id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9   
10.190.0.204:0     id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE   
172.31.163.135:0   (localhost)                                                                                        
10.190.0.222:0     id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51   
