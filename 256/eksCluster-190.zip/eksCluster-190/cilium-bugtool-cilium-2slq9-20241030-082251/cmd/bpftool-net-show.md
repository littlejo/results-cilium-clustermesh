xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 565
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 522
lxc1f552e01d4a8(12) clsact/ingress cil_from_container-lxc1f552e01d4a8 id 536
lxc75e9ab2560be(14) clsact/ingress cil_from_container-lxc75e9ab2560be id 516
lxce629a672fa44(18) clsact/ingress cil_from_container-lxce629a672fa44 id 626

flow_dissector:

netfilter:

