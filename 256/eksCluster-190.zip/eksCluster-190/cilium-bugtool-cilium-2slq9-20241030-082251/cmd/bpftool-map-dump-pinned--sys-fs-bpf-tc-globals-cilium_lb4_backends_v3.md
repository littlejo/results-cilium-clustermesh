key: 09 00 00 00  value: 0a be 00 cc 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f a3 87 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 95 41 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ed 20 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a be 00 de 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a be 00 de 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a be 00 32 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a be 00 cc 00 35 00 00  00 00 00 00
Found 8 elements
