ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.149.65:443 (active)     
                                          2 => 172.31.237.32:443 (active)     
2    10.100.208.238:443    ClusterIP      1 => 172.31.163.135:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.190.0.222:53 (active)       
                                          2 => 10.190.0.204:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.190.0.222:9153 (active)     
                                          2 => 10.190.0.204:9153 (active)     
5    10.100.219.116:2379   ClusterIP      1 => 10.190.0.50:2379 (active)      
