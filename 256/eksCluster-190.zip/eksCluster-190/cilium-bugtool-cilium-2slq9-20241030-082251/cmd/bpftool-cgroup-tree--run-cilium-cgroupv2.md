CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbef6b93f_f787_4a5d_b384_f1a8a4036ef4.slice/cri-containerd-9fc2ddf30dc57505d822424df05f5acab10aead3a3f8798e8ea208d4e8374aab.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbef6b93f_f787_4a5d_b384_f1a8a4036ef4.slice/cri-containerd-4eff43b8b5094d3d0615e5f46ba4d89fe65459eaa1df443bc3963d52742971f4.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e2b5bc2_641e_49a6_8d79_b2153cf55d1b.slice/cri-containerd-b58d3e601dab40cfbce03cf200b6c4d9fc609ffe6c3270fb2178eba26885475f.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3e2b5bc2_641e_49a6_8d79_b2153cf55d1b.slice/cri-containerd-9ef76bed41fad0f5e67bf9951dfa4bb152993808207c6474ed001049597cbac4.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6811556_b164_4bab_8d6a_79eb81878fcb.slice/cri-containerd-f227d8560e203b11ec10db2172542eecb90850db58852f3deb3cd5b1730afc40.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6811556_b164_4bab_8d6a_79eb81878fcb.slice/cri-containerd-9ac54ee27758400cf13ba790137871f4281e87d7d66e91dbeee6b40e8127156b.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9600ae3b_6210_4d34_a536_81138e479ce7.slice/cri-containerd-e821eab5ee246fff0b77a46b20c2507a15fa61d863b79df31ce51b8f435f287d.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9600ae3b_6210_4d34_a536_81138e479ce7.slice/cri-containerd-43dd09fb2e39fa30f4365ecf9c8d06096e4b4d96f1778c6d1404aa2118813336.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3bd7ec7_07b1_479e_bddf_9c77e9c92528.slice/cri-containerd-858e7a5aaa3bc4bcd8db22c07d7dff0d8c11c99059d5734c849da8aff41c1880.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode3bd7ec7_07b1_479e_bddf_9c77e9c92528.slice/cri-containerd-988e33c0805a5768d32808b8484dd6223918dc29415e4b4cb179353bf3252b68.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4735b0d4_d46b_4ce3_b23c_d605ebe8fa6d.slice/cri-containerd-317319c9864e968e53d7ac2c4c96605af71a307a4e5d1bbbb8499df590afe2b9.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4735b0d4_d46b_4ce3_b23c_d605ebe8fa6d.slice/cri-containerd-8f3e98a43dd5048f407faf22f913a6fe49e8d3c11a6df7e8f2c671a31dfb7cec.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-34b50f3ed86b78ce87edb98b965b76ed21c16f658e03b0348d492823048cb8dd.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-0c9a52d007a62af05384f3ff04c7dafc192e990fee217a929fa01dfb0e9bbe93.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-b87a6d5e4fed17968af4690896ef599e4aa7b9a33bf93200edac51e9634ad7b7.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-1dc192d0bf069420d3be2eefd5ed5df410d3e90ce7d13b4e823caaf523fc6004.scope
    640      cgroup_device   multi                                          
