Total: 741
TCP:   1916 (estab 481, closed 1416, orphaned 0, timewait 563)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  500       473       27       
INET	  510       479       31       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36871 sk:40d cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15252 sk:40e cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:35121      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=26)) ino:35672 sk:40f fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.163.135%ens5:68         0.0.0.0:*    uid:192 ino:78296 sk:410 cgroup:unreachable:c4e <->                            
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36870 sk:411 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15253 sk:412 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::42b:26ff:fec3:271b]%ens5:546           [::]:*    uid:192 ino:15620 sk:413 cgroup:unreachable:c4e v6only:1 <->                   
