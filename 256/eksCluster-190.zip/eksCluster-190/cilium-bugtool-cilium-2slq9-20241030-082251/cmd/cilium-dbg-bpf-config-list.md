KEY             VALUE
AgentLiveness   1888615789147
UTimeOffset     3379442812500000
