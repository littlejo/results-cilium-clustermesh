{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.155.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.163.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.492Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.497Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.537Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.587Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.650Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.427Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.427Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.428Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.460Z",
  "value": "id=854   sec_id=6284773 flags=0x0000 ifindex=16  mac=9A:AC:3D:AF:91:DF nodemac=06:70:8A:23:DB:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:20.427Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:20.427Z",
  "value": "id=854   sec_id=6284773 flags=0x0000 ifindex=16  mac=9A:AC:3D:AF:91:DF nodemac=06:70:8A:23:DB:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:20.427Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:20.428Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:13.107Z",
  "value": "id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.190.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:19.956Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.043Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.043Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.044Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.048Z",
  "value": "id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.049Z",
  "value": "id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.055Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.056Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.056Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.045Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.045Z",
  "value": "id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.045Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.046Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.045Z",
  "value": "id=363   sec_id=6284773 flags=0x0000 ifindex=18  mac=12:37:63:A8:48:02 nodemac=9A:6A:38:92:C8:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.045Z",
  "value": "id=1792  sec_id=6274791 flags=0x0000 ifindex=12  mac=86:B1:58:B3:ED:93 nodemac=BA:A7:9F:92:7E:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.046Z",
  "value": "id=2973  sec_id=4     flags=0x0000 ifindex=10  mac=FE:B5:83:05:C5:46 nodemac=4A:CB:0F:07:7B:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.190.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.046Z",
  "value": "id=1520  sec_id=6274791 flags=0x0000 ifindex=14  mac=0A:2D:4D:AC:8A:BF nodemac=82:2E:33:CB:72:DE"
}

