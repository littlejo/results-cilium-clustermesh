key: 6b 01 00 00  value: 73 02 00 00
key: f0 05 00 00  value: ff 01 00 00
key: 00 07 00 00  value: 1a 02 00 00
key: 9d 0b 00 00  value: 13 02 00 00
Found 4 elements
