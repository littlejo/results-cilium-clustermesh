[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-b87a6d5e4fed17968af4690896ef599e4aa7b9a33bf93200edac51e9634ad7b7.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-0c9a52d007a62af05384f3ff04c7dafc192e990fee217a929fa01dfb0e9bbe93.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7b03ab2f_5dcc_4330_8c16_efc853b889d4.slice/cri-containerd-34b50f3ed86b78ce87edb98b965b76ed21c16f658e03b0348d492823048cb8dd.scope"
      }
    ],
    "ips": [
      "10.190.0.50"
    ],
    "name": "clustermesh-apiserver-78d4cf445b-w6282",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6811556_b164_4bab_8d6a_79eb81878fcb.slice/cri-containerd-9ac54ee27758400cf13ba790137871f4281e87d7d66e91dbeee6b40e8127156b.scope"
      }
    ],
    "ips": [
      "10.190.0.222"
    ],
    "name": "coredns-cc6ccd49c-lmhzf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9600ae3b_6210_4d34_a536_81138e479ce7.slice/cri-containerd-e821eab5ee246fff0b77a46b20c2507a15fa61d863b79df31ce51b8f435f287d.scope"
      }
    ],
    "ips": [
      "10.190.0.204"
    ],
    "name": "coredns-cc6ccd49c-mmg5d",
    "namespace": "kube-system"
  }
]

