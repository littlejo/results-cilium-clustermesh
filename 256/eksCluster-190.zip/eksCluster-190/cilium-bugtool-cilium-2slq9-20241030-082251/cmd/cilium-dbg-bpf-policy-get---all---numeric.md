Endpoint ID: 363
Path: /sys/fs/bpf/tc/globals/cilium_policy_00363

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11639121   117025    0        
Allow    Ingress     1          ANY          NONE         disabled    10805806   114205    0        
Allow    Egress      0          ANY          NONE         disabled    14105526   138315    0        


Endpoint ID: 1520
Path: /sys/fs/bpf/tc/globals/cilium_policy_01520

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123685   1427      0        
Allow    Egress      0          ANY          NONE         disabled    17408    189       0        


Endpoint ID: 1792
Path: /sys/fs/bpf/tc/globals/cilium_policy_01792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    120253   1375      0        
Allow    Egress      0          ANY          NONE         disabled    17641    191       0        


Endpoint ID: 2973
Path: /sys/fs/bpf/tc/globals/cilium_policy_02973

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664394   21001     0        
Allow    Ingress     1          ANY          NONE         disabled    19490     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3150
Path: /sys/fs/bpf/tc/globals/cilium_policy_03150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


