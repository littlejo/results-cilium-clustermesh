markdown output at /tmp/cilium-bugtool-20241030-082257.232+0000-UTC-868011500/cmd/cilium-debuginfo-20241030-082328.209+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.232+0000-UTC-868011500/cmd/cilium-debuginfo-20241030-082328.209+0000-UTC.json
