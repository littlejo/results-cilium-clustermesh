alloc: 222.28MB (233075792 bytes)
total-alloc: 2.33GB (2501267816 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 64583201
frees: 62271950
heap-alloc: 222.28MB (233075792 bytes)
heap-sys: 250.89MB (263077888 bytes)
heap-idle: 10.35MB (10854400 bytes)
heap-in-use: 240.54MB (252223488 bytes)
heap-released: 4.91MB (5144576 bytes)
heap-objects: 2311251
stack-in-use: 68.66MB (71991296 bytes)
stack-sys: 68.66MB (71991296 bytes)
stack-mspan-inuse: 3.66MB (3837760 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1079865 bytes)
gc-sys: 6.42MB (6735288 bytes)
next-gc: when heap-alloc >= 227.28MB (238325000 bytes)
last-gc: 2024-10-30 08:22:52.274452787 +0000 UTC
gc-pause-total: 17.178772ms
gc-pause: 88625
gc-pause-end: 1730276572274452787
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005397963443718283
enable-gc: true
debug-gc: false
