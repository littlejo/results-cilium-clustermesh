 08:22:50 up 28 min,  0 users,  load average: 0.26, 0.24, 0.22
