top - 08:22:50 up 28 min,  0 users,  load average: 0.26, 0.24, 0.22
Tasks:  12 total,   1 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 37.9 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4476.2 free,   1191.1 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6438.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    724 root      20   0 1244340  19692  13636 S  13.3   0.2   0:00.02 hubble
      1 root      20   0 1606336 381068  78328 S   6.7   4.8   0:52.62 cilium-+
    397 root      20   0 1229744   8060   3836 S   0.0   0.1   0:01.14 cilium-+
    615 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    616 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    617 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    632 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    634 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    635 root      20   0 1240432  16772  11484 S   0.0   0.2   0:00.02 cilium-+
    694 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    709 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    718 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
