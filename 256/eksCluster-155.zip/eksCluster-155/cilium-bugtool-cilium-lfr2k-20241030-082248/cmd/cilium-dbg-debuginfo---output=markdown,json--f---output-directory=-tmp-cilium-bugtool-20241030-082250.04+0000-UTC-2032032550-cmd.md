markdown output at /tmp/cilium-bugtool-20241030-082250.04+0000-UTC-2032032550/cmd/cilium-debuginfo-20241030-082321.344+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.04+0000-UTC-2032032550/cmd/cilium-debuginfo-20241030-082321.344+0000-UTC.json
