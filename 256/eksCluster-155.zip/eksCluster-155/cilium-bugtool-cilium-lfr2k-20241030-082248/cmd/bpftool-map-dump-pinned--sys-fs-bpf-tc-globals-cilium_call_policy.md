key: 80 01 00 00  value: 86 02 00 00
key: 1e 02 00 00  value: 11 02 00 00
key: 28 02 00 00  value: 44 02 00 00
key: 08 0d 00 00  value: 40 02 00 00
Found 4 elements
