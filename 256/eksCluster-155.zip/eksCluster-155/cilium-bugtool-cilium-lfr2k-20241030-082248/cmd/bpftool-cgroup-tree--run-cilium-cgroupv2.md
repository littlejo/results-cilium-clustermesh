CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b3ba062_4638_426d_a266_824d20b55aab.slice/cri-containerd-ab1d318bc5178109316c39ee6d1ca0c2538cce130140d68a6e8f085ba9888c8c.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b3ba062_4638_426d_a266_824d20b55aab.slice/cri-containerd-f364144c587a0b0b52b7eef11ed0b0027830ad11310ebc497b68717754883c60.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05ec1b1a_6b2a_48a5_b28a_de9b46ac8b6b.slice/cri-containerd-b8cd7ea88969bcccf0fe0a3660726a17f987b215f300d0e101cc11381ee79617.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod05ec1b1a_6b2a_48a5_b28a_de9b46ac8b6b.slice/cri-containerd-811b24510a6774fa968153b2f8937dce66ffd84e174aff894b6cfa5494f88d42.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1fae14c_0a00_47a8_9be9_64d286089a0d.slice/cri-containerd-6b15ed052dc39d43ecc8d8c31d232e56a207957b1d01c3ed3a10570871b4e8a8.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1fae14c_0a00_47a8_9be9_64d286089a0d.slice/cri-containerd-37550ad20710f1eb327571b8fa45fe2299e257160a42738c40c30dfbca603dc3.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf064440c_247d_4cce_96f4_061c306ffa0c.slice/cri-containerd-ef95d22667cfc8b7a4f63513a541dd2f2946a34a25ad23d65068bc01c1cd6ed9.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf064440c_247d_4cce_96f4_061c306ffa0c.slice/cri-containerd-51a898166c42daf3007cb0a5aaf994ca5d1c33db5a685cb5380402eb49d144ff.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd240ab86_0f4a_4ebe_9686_5d0f045cafdc.slice/cri-containerd-b8076684d0b817fe0030537919cccb2917f3d2d11243eac10f09a83c05de0eaf.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd240ab86_0f4a_4ebe_9686_5d0f045cafdc.slice/cri-containerd-8745a2784667d914292498a91d4dc14f43f4bd9c96601f0663c87944a8b435e6.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41a65581_04f4_447c_8a64_93405fbbf3aa.slice/cri-containerd-a35ca9e6f8c921966e15b62c869a0623f0f46220cce6e91969229412532bf085.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41a65581_04f4_447c_8a64_93405fbbf3aa.slice/cri-containerd-fa682aa798918c8ef04f0e1fc97fc73fa01fd3b938e9bc9bed0258ccfbc5b7d0.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-2627ff2f57c5a19d423abecc58149de50599a5c8c62b034fd7fd6d884d433c05.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-0ead3b4a00090045bf6e2b42e5d6eb86df4482b42e15a44fb46e172325735180.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-0cfc7118c17d6c0e85749e27f2439d36748806f4ec81c443b68b19c57e8a3a7c.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-1b303ad17cbc90b11b5e6ebdea25ff062cede5a4aa0fde70a2fcdec8c03384ac.scope
    673      cgroup_device   multi                                          
