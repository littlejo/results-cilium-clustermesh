USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         635  0.0  0.2 1240432 16772 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         683  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         684  0.0  0.0   3852  1288 ?        R    08:22   0:00  \_ bash -c hostname
root         634  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         632  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         617  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         616  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         615  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  4.4  4.7 1606336 381068 ?      Ssl  08:03   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.0  0.1 1229744 8060 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
