REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36646     2902008     677    bpf_overlay.c
Interface                 INGRESS     666727    135449231   1132   bpf_host.c
Success                   EGRESS      16500     1299299     1694   bpf_host.c
Success                   EGRESS      289101    35462890    1308   bpf_lxc.c
Success                   EGRESS      37333     2944775     53     encap.h
Success                   INGRESS     331057    37687915    86     l3.h
Success                   INGRESS     351854    39334670    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
