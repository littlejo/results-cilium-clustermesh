alloc: 111.14MB (116543888 bytes)
total-alloc: 2.32GB (2488396440 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64756630
frees: 64061898
heap-alloc: 111.14MB (116543888 bytes)
heap-sys: 251.79MB (264019968 bytes)
heap-idle: 73.71MB (77291520 bytes)
heap-in-use: 178.08MB (186728448 bytes)
heap-released: 1.41MB (1474560 bytes)
heap-objects: 694732
stack-in-use: 60.19MB (63111168 bytes)
stack-sys: 60.19MB (63111168 bytes)
stack-mspan-inuse: 2.85MB (2985120 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.16MB (1220377 bytes)
gc-sys: 6.06MB (6358768 bytes)
next-gc: when heap-alloc >= 218.15MB (228748264 bytes)
last-gc: 2024-10-30 08:23:20.422397921 +0000 UTC
gc-pause-total: 10.698274ms
gc-pause: 253567
gc-pause-end: 1730276600422397921
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005312057913360815
enable-gc: true
debug-gc: false
