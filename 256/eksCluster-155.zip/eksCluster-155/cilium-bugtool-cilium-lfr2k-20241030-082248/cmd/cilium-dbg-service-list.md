ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.205.220:443 (active)   
                                         2 => 172.31.187.231:443 (active)   
2    10.100.204.130:443   ClusterIP      1 => 172.31.224.54:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.155.0.44:53 (active)       
                                         2 => 10.155.0.229:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.155.0.44:9153 (active)     
                                         2 => 10.155.0.229:9153 (active)    
5    10.100.91.158:2379   ClusterIP      1 => 10.155.0.152:2379 (active)    
