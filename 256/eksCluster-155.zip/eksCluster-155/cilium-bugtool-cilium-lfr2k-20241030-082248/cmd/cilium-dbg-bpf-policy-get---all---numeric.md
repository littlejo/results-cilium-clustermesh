Endpoint ID: 28
Path: /sys/fs/bpf/tc/globals/cilium_policy_00028

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 384
Path: /sys/fs/bpf/tc/globals/cilium_policy_00384

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11471249   115866    0        
Allow    Ingress     1          ANY          NONE         disabled    11000927   116246    0        
Allow    Egress      0          ANY          NONE         disabled    15133649   147568    0        


Endpoint ID: 542
Path: /sys/fs/bpf/tc/globals/cilium_policy_00542

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112844   1295      0        
Allow    Egress      0          ANY          NONE         disabled    15867    171       0        


Endpoint ID: 552
Path: /sys/fs/bpf/tc/globals/cilium_policy_00552

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650417   20843     0        
Allow    Ingress     1          ANY          NONE         disabled    17441     207       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3336
Path: /sys/fs/bpf/tc/globals/cilium_policy_03336

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112945   1293      0        
Allow    Egress      0          ANY          NONE         disabled    16732    181       0        


