[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-2627ff2f57c5a19d423abecc58149de50599a5c8c62b034fd7fd6d884d433c05.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-1b303ad17cbc90b11b5e6ebdea25ff062cede5a4aa0fde70a2fcdec8c03384ac.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc5d41ef2_d006_48c9_a4de_3723cbd1b958.slice/cri-containerd-0ead3b4a00090045bf6e2b42e5d6eb86df4482b42e15a44fb46e172325735180.scope"
      }
    ],
    "ips": [
      "10.155.0.152"
    ],
    "name": "clustermesh-apiserver-5f99c77f67-tzj4d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3b3ba062_4638_426d_a266_824d20b55aab.slice/cri-containerd-f364144c587a0b0b52b7eef11ed0b0027830ad11310ebc497b68717754883c60.scope"
      }
    ],
    "ips": [
      "10.155.0.44"
    ],
    "name": "coredns-cc6ccd49c-dcjnd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf064440c_247d_4cce_96f4_061c306ffa0c.slice/cri-containerd-ef95d22667cfc8b7a4f63513a541dd2f2946a34a25ad23d65068bc01c1cd6ed9.scope"
      }
    ],
    "ips": [
      "10.155.0.229"
    ],
    "name": "coredns-cc6ccd49c-t5mnf",
    "namespace": "kube-system"
  }
]

