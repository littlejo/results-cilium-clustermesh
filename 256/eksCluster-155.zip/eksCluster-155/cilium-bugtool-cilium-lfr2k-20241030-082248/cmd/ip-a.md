1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d5:1d:32:01:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.224.54/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1899sec preferred_lft 1899sec
    inet6 fe80::8d5:1dff:fe32:1d7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:4e:f5:77:8b:5f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.212.31/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::84e:f5ff:fe77:8b5f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:1c:23:88:b8:29 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a41c:23ff:fe88:b829/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:f5:c8:39:ac:9b brd ff:ff:ff:ff:ff:ff
    inet 10.155.0.32/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2cf5:c8ff:fe39:ac9b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:72:2c:0d:ff:fd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2472:2cff:fe0d:fffd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:7d:57:e9:32:34 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a07d:57ff:fee9:3234/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc996fad09ee6f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:02:ae:50:f7:9d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6402:aeff:fe50:f79d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc986f09edb5ae@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:c1:89:b5:cf:eb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::24c1:89ff:feb5:cfeb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf37981e113b8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:93:25:d1:d6:f1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::3c93:25ff:fed1:d6f1/64 scope link 
       valid_lft forever preferred_lft forever
