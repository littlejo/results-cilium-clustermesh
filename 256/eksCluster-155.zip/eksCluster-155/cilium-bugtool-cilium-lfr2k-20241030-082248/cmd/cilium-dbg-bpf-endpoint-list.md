IP ADDRESS        LOCAL ENDPOINT INFO
10.155.0.219:0    id=552   sec_id=4     flags=0x0000 ifindex=10  mac=22:D8:2A:94:DF:45 nodemac=A2:7D:57:E9:32:34     
10.155.0.44:0     id=542   sec_id=5141105 flags=0x0000 ifindex=12  mac=8A:CB:98:9E:86:92 nodemac=66:02:AE:50:F7:9D   
10.155.0.229:0    id=3336  sec_id=5141105 flags=0x0000 ifindex=14  mac=EA:19:71:FC:B9:51 nodemac=26:C1:89:B5:CF:EB   
172.31.224.54:0   (localhost)                                                                                        
10.155.0.32:0     (localhost)                                                                                        
10.155.0.152:0    id=384   sec_id=5130918 flags=0x0000 ifindex=18  mac=5E:15:12:AE:06:85 nodemac=3E:93:25:D1:D6:F1   
172.31.212.31:0   (localhost)                                                                                        
