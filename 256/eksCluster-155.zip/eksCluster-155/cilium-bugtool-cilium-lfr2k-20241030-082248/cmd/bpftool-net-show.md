xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 565
ens6(5) clsact/ingress cil_from_netdev-ens6 id 570
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 552
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 587
lxc996fad09ee6f(12) clsact/ingress cil_from_container-lxc996fad09ee6f id 522
lxc986f09edb5ae(14) clsact/ingress cil_from_container-lxc986f09edb5ae id 553
lxcf37981e113b8(18) clsact/ingress cil_from_container-lxcf37981e113b8 id 644

flow_dissector:

netfilter:

