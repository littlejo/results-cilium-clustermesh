[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e30891_c62d_4507_9c57_b8e5b76e623c.slice/cri-containerd-eeabf504052b54e0b75393cd6c7743543eb75305f19305beb69e763d6ed7fd31.scope"
      }
    ],
    "ips": [
      "10.1.0.230"
    ],
    "name": "coredns-cc6ccd49c-69dwf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bdb2bbe_6d68_4afb_a2dc_59fe2e67b25c.slice/cri-containerd-6d8b2949eb9597ff3cfc01d3735d9d8e6a746260344ff3681882da95d05572cb.scope"
      }
    ],
    "ips": [
      "10.1.0.253"
    ],
    "name": "coredns-cc6ccd49c-7c57k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-c87d2a086cddcd93eecde26fa85204cf0ff2a5f44b70a445d994788fcaddc19e.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-cb8d4abb5fa7b76d2df3f627d34f1451e0a3f1d2f5158e8807213d77e7476924.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-377436e7721835519e6b0b957f5f3fbbc947bdc595038fad37d8d1c2b5ce7165.scope"
      }
    ],
    "ips": [
      "10.1.0.222"
    ],
    "name": "clustermesh-apiserver-89b84884c-rlgnm",
    "namespace": "kube-system"
  }
]

