xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 586
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 572
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 563
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxc84ca5db06454(12) clsact/ingress cil_from_container-lxc84ca5db06454 id 522
lxced2a93893188(14) clsact/ingress cil_from_container-lxced2a93893188 id 516
lxce83d4525c704(18) clsact/ingress cil_from_container-lxce83d4525c704 id 630

flow_dissector:

netfilter:

