IP ADDRESS         LOCAL ENDPOINT INFO
10.1.0.230:0       id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22   
10.1.0.120:0       id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F   
172.31.198.203:0   (localhost)                                                                                      
172.31.233.78:0    (localhost)                                                                                      
10.1.0.234:0       (localhost)                                                                                      
10.1.0.222:0       id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37   
10.1.0.253:0       id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54   
