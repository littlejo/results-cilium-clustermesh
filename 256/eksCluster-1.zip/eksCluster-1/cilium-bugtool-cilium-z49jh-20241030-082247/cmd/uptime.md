 08:22:48 up 37 min,  0 users,  load average: 0.57, 0.49, 0.41
