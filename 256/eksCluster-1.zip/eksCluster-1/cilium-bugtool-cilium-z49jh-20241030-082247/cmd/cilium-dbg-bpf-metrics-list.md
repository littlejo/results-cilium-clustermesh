REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36531     2888331     677    bpf_overlay.c
Interface                 INGRESS     656967    134359376   1132   bpf_host.c
Success                   EGRESS      16557     1303361     1694   bpf_host.c
Success                   EGRESS      280073    34744558    1308   bpf_lxc.c
Success                   EGRESS      36964     2922265     53     encap.h
Success                   INGRESS     323934    36584123    86     l3.h
Success                   INGRESS     344559    38213139    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
