KEY             VALUE
AgentLiveness   2283725348366
UTimeOffset     3379442023437500
