CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb47eb1bb_61f8_41e1_8e29_9f25062b77db.slice/cri-containerd-2948f4bfdb2bc9f428b68cc0735fb55ddc509acc6c62d8ea04ecf02beb4ecb24.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb47eb1bb_61f8_41e1_8e29_9f25062b77db.slice/cri-containerd-c7ccf35ff1633919150aa54e465d1d6f5e6ede46f292f101bb5eaf516ef1997c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bdb2bbe_6d68_4afb_a2dc_59fe2e67b25c.slice/cri-containerd-6d8b2949eb9597ff3cfc01d3735d9d8e6a746260344ff3681882da95d05572cb.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bdb2bbe_6d68_4afb_a2dc_59fe2e67b25c.slice/cri-containerd-def514173487b4b50a44eead7b0af47082377bf874bcde512af99643a6727956.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03526e37_40f2_42b2_a837_c4abb828b2a9.slice/cri-containerd-31f0a01145ecb5ed1934eca9343d334f041f9bd4d090e8e6759561afcd497efc.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod03526e37_40f2_42b2_a837_c4abb828b2a9.slice/cri-containerd-850a87018615c6a6e2ad35629c03c0356eb933afc0b7988c3340f6eb51faaf51.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e30891_c62d_4507_9c57_b8e5b76e623c.slice/cri-containerd-eeabf504052b54e0b75393cd6c7743543eb75305f19305beb69e763d6ed7fd31.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e30891_c62d_4507_9c57_b8e5b76e623c.slice/cri-containerd-1377415802614d10eae54ef7e470f950df8f140f9a6641f269a6ef1b764cd65e.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2eaca7ae_165f_46ab_bfd4_a6794f0724f3.slice/cri-containerd-69864666913f4907555c5baad616390217c8dd722bc5818be9d3c332bef92dc3.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2eaca7ae_165f_46ab_bfd4_a6794f0724f3.slice/cri-containerd-d00dd61451fd64b8fc5555a1e4f17ef593f1bf19ba864c4afb533b946cc62df9.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65ac3f75_3ae2_495e_b407_4d120437db84.slice/cri-containerd-fbedb3615682b56ad85b44094756426b7ce39276a87ab9aee854fd389e5363aa.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65ac3f75_3ae2_495e_b407_4d120437db84.slice/cri-containerd-90855fda19c1844c48323284fa816eded548805f191860321a8c522c73c762f1.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-c87d2a086cddcd93eecde26fa85204cf0ff2a5f44b70a445d994788fcaddc19e.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-cb8d4abb5fa7b76d2df3f627d34f1451e0a3f1d2f5158e8807213d77e7476924.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-377436e7721835519e6b0b957f5f3fbbc947bdc595038fad37d8d1c2b5ce7165.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6bf06f_312f_4035_b6d9_8c56cf8c3cf2.slice/cri-containerd-9b2c8fb2a6b91e31845e1e06b5ba2953b1172da613fd52aebe7a6689ebb2b114.scope
    640      cgroup_device   multi                                          
