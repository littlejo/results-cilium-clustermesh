top - 08:22:48 up 37 min,  0 users,  load average: 0.57, 0.49, 0.41
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.1 us, 19.4 sy,  0.0 ni, 16.1 id,  0.0 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   7814.2 total,   4497.3 free,   1200.4 used,   2116.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6428.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 388212  78268 S 100.0   4.9   1:05.35 cilium-+
    661 root      20   0 1240432  15676  10768 S   6.7   0.2   0:00.04 cilium-+
    396 root      20   0 1229488   8236   3836 S   0.0   0.1   0:01.19 cilium-+
    655 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    659 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    671 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    679 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    727 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    745 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
