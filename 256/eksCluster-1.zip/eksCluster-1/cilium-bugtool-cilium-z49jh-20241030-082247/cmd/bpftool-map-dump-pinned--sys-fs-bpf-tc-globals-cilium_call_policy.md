key: 93 02 00 00  value: 20 02 00 00
key: 89 04 00 00  value: 78 02 00 00
key: 02 05 00 00  value: 09 02 00 00
key: 47 07 00 00  value: 02 02 00 00
Found 4 elements
