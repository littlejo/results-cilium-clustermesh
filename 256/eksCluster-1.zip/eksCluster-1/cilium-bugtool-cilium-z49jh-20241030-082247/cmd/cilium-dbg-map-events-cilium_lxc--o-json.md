{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.165Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.198.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.165Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.233.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.165Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.773Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.773Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.849Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.925Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.021Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:01.788Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:01.788Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:01.788Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:01.824Z",
  "value": "id=862   sec_id=85843 flags=0x0000 ifindex=16  mac=16:23:D9:79:86:5D nodemac=0E:C4:D0:BD:F2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:01.826Z",
  "value": "id=862   sec_id=85843 flags=0x0000 ifindex=16  mac=16:23:D9:79:86:5D nodemac=0E:C4:D0:BD:F2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:02.788Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:02.788Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:02.788Z",
  "value": "id=862   sec_id=85843 flags=0x0000 ifindex=16  mac=16:23:D9:79:86:5D nodemac=0E:C4:D0:BD:F2:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:02.789Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.332Z",
  "value": "id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.1.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.783Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.656Z",
  "value": "id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.657Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.657Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.658Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.670Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.671Z",
  "value": "id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.671Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.672Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.671Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.671Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.671Z",
  "value": "id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.672Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.671Z",
  "value": "id=1863  sec_id=94657 flags=0x0000 ifindex=14  mac=92:A3:B6:8C:89:2E nodemac=12:FD:5B:A1:C0:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.672Z",
  "value": "id=1161  sec_id=85843 flags=0x0000 ifindex=18  mac=EA:1B:19:50:34:22 nodemac=D2:F5:0B:A8:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.672Z",
  "value": "id=1282  sec_id=94657 flags=0x0000 ifindex=12  mac=A2:A3:EB:F9:BF:E0 nodemac=06:0E:62:4C:68:54"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.1.0.120:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.672Z",
  "value": "id=659   sec_id=4     flags=0x0000 ifindex=10  mac=1A:21:22:55:F1:C6 nodemac=D6:CB:8E:85:6B:2F"
}

