{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.237:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "3 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "4 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:34.912Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.498Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.498Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.498Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:37.498Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.237:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:38.370Z",
  "value": "5 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.90.237:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:38.370Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.354Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.354Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.376Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.376Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.376Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.376Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "8 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "9 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.397Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:53.620Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:06.994Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.700Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:11.700Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.495Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:25.495Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.213Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.213Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.213Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.355Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.355Z",
  "value": "10 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.355Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.890Z",
  "value": "11 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.112.231:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.890Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.112.231:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.890Z",
  "value": "\u003cnil\u003e"
}

