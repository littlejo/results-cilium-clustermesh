alloc: 108.70MB (113982944 bytes)
total-alloc: 2.35GB (2521026832 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64896412
frees: 64006617
heap-alloc: 108.70MB (113982944 bytes)
heap-sys: 246.73MB (258711552 bytes)
heap-idle: 79.13MB (82976768 bytes)
heap-in-use: 167.59MB (175734784 bytes)
heap-released: 120.00KB (122880 bytes)
heap-objects: 889795
stack-in-use: 65.25MB (68419584 bytes)
stack-sys: 65.25MB (68419584 bytes)
stack-mspan-inuse: 2.90MB (3037920 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.13MB (1180841 bytes)
gc-sys: 6.02MB (6311496 bytes)
next-gc: when heap-alloc >= 212.94MB (223280504 bytes)
last-gc: 2024-10-30 08:23:09.25852763 +0000 UTC
gc-pause-total: 25.220443ms
gc-pause: 94234
gc-pause-end: 1730276589258527630
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00037861550593351617
enable-gc: true
debug-gc: false
