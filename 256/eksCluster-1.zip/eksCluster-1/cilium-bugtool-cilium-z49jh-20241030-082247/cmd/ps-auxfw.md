USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         679  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         671  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         661  0.0  0.1 1240432 15676 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         716  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         659  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         655  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.5  4.8 1606336 384284 ?      Ssl  07:52   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229488 8236 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
