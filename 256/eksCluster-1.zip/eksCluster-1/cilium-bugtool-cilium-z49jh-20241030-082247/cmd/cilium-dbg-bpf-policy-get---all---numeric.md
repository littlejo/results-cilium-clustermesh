Endpoint ID: 241
Path: /sys/fs/bpf/tc/globals/cilium_policy_00241

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 659
Path: /sys/fs/bpf/tc/globals/cilium_policy_00659

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1632219   20666     0        
Allow    Ingress     1          ANY          NONE         disabled    26358     309       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1161
Path: /sys/fs/bpf/tc/globals/cilium_policy_01161

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11510450   115444    0        
Allow    Ingress     1          ANY          NONE         disabled    10592875   111630    0        
Allow    Egress      0          ANY          NONE         disabled    13765249   134904    0        


Endpoint ID: 1282
Path: /sys/fs/bpf/tc/globals/cilium_policy_01282

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176794   2038      0        
Allow    Egress      0          ANY          NONE         disabled    21753    244       0        


Endpoint ID: 1863
Path: /sys/fs/bpf/tc/globals/cilium_policy_01863

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176464   2033      0        
Allow    Egress      0          ANY          NONE         disabled    22646    254       0        


