CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76835b0_40e3_404c_8258_c1715ac22bf9.slice/cri-containerd-2b9a9e32b7704677186ecc22dbcbe1af1a5dc3231ebf325d0affb7fcc03ce509.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76835b0_40e3_404c_8258_c1715ac22bf9.slice/cri-containerd-15d5338fcc7db0429e9c030044d190ac3bb23a9a8c113a8d18187ebb58370d26.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ce0ba51_0f2e_4ff0_825b_5d48d4eb651b.slice/cri-containerd-5bfa9280341248d6d886ae0e8f4a9ca653d8a771c1060423abe7afef7c36bc5f.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ce0ba51_0f2e_4ff0_825b_5d48d4eb651b.slice/cri-containerd-7d4eff3ba7f648f080b15ca844c1083280e1b814246b621995365a9c7e391f73.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6db8195b_9361_4a2a_ade2_2da922331432.slice/cri-containerd-34e5875008e487a29deede6d31fc9f93697125285e8bb19c80aeb26354b0e186.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6db8195b_9361_4a2a_ade2_2da922331432.slice/cri-containerd-07be1dc04164aeb5e606edb3b98ac68074d990594d45dadf87d04365527a2079.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode33f671f_c817_4207_81c4_c1a20da9da8e.slice/cri-containerd-58634e388969dc3e8662cd4499d279eea7eabad9b16d7f3311d1a9b44ccfcaa7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode33f671f_c817_4207_81c4_c1a20da9da8e.slice/cri-containerd-0e308d2dd6811b4b5eb3902611bc40f004930468166ad4ce30f968f2e05aa9c6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e7e55eb_22f6_40e1_ab1d_b7bef002d6a0.slice/cri-containerd-e8e02de8111f1729c9257a9f0eac48645f8c7e513473430ba65300ed2aa2237c.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e7e55eb_22f6_40e1_ab1d_b7bef002d6a0.slice/cri-containerd-392d771663df8227a19a7e1f3c5f3dff31975fbe6ac795263a7c5d697d4da291.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-b7133667ffefba604311ad8672034310c35698433c4303115e2cbce232bf6d57.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-04e9cc4ef0eab7155fd1b532efbb3fce62c836d1a208699da0398e6f63d84642.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-f1a731d240f22989983f34e9556ed258b518106b04dc79e1c00977143b0d520f.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-f23073661f87100153981aa00dbf6d6ee18d4bcc8b14b4929ce7a71c282afb86.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1e4ed47_f09d_4c0d_821d_b32d1003ed02.slice/cri-containerd-843fcdaa234bca18d1fdd14ec58ce312576284b33d096414883c3a8cb154ebef.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1e4ed47_f09d_4c0d_821d_b32d1003ed02.slice/cri-containerd-f954ff443c5179488312f996df630a37b0cdb120ed14ceea299072b6a06738c8.scope
    90       cgroup_device   multi                                          
