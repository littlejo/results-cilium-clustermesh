alloc: 128.80MB (135053656 bytes)
total-alloc: 2.17GB (2328758168 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 61864292
frees: 60940196
heap-alloc: 128.80MB (135053656 bytes)
heap-sys: 243.63MB (255467520 bytes)
heap-idle: 63.41MB (66494464 bytes)
heap-in-use: 180.22MB (188973056 bytes)
heap-released: 352.00KB (360448 bytes)
heap-objects: 924096
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.83MB (2962880 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 974.84KB (998233 bytes)
gc-sys: 6.04MB (6332096 bytes)
next-gc: when heap-alloc >= 211.08MB (221336984 bytes)
last-gc: 2024-10-30 08:22:51.305845208 +0000 UTC
gc-pause-total: 25.815997ms
gc-pause: 117093
gc-pause-end: 1730276571305845208
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003416235155873692
enable-gc: true
debug-gc: false
