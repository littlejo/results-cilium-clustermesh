key: 89 05 00 00  value: 0a 02 00 00
key: 18 0a 00 00  value: 66 02 00 00
key: 89 0c 00 00  value: 28 02 00 00
key: b8 0e 00 00  value: 2c 02 00 00
Found 4 elements
