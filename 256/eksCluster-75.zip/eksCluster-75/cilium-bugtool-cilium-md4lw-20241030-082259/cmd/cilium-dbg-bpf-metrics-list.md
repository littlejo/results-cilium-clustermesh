REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34745     2744013     677    bpf_overlay.c
Interface                 INGRESS     589309    125308505   1132   bpf_host.c
Success                   EGRESS      15222     1194866     1694   bpf_host.c
Success                   EGRESS      248365    30794860    1308   bpf_lxc.c
Success                   EGRESS      34347     2720819     53     encap.h
Success                   INGRESS     287232    31663417    86     l3.h
Success                   INGRESS     307407    33256680    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
