{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.887Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.887Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.887Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.614Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.620Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.659Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.662Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.673Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:13.667Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:13.668Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:13.668Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:13.705Z",
  "value": "id=612   sec_id=2522141 flags=0x0000 ifindex=16  mac=C6:56:EB:F5:7D:13 nodemac=8A:98:AC:F5:CC:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.667Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.667Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.668Z",
  "value": "id=612   sec_id=2522141 flags=0x0000 ifindex=16  mac=C6:56:EB:F5:7D:13 nodemac=8A:98:AC:F5:CC:AD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:14.668Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.245Z",
  "value": "id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.75.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.670Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.927Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.928Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.928Z",
  "value": "id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.929Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.919Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.920Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.920Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.920Z",
  "value": "id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.920Z",
  "value": "id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.920Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.920Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.921Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.921Z",
  "value": "id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.921Z",
  "value": "id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.921Z",
  "value": "id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.75.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.921Z",
  "value": "id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42"
}

