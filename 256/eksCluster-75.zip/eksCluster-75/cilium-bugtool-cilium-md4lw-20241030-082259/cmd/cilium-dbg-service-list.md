ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.196.145:443 (active)    
                                          2 => 172.31.141.171:443 (active)    
2    10.100.205.239:443    ClusterIP      1 => 172.31.195.237:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.75.0.188:53 (active)        
                                          2 => 10.75.0.182:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.75.0.188:9153 (active)      
                                          2 => 10.75.0.182:9153 (active)      
5    10.100.244.157:2379   ClusterIP      1 => 10.75.0.143:2379 (active)      
