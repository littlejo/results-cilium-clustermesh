IP ADDRESS         LOCAL ENDPOINT INFO
10.75.0.182:0      id=3209  sec_id=2497770 flags=0x0000 ifindex=14  mac=F2:2C:01:91:12:CC nodemac=C6:51:C5:BE:BF:42   
172.31.234.253:0   (localhost)                                                                                        
10.75.0.60:0       (localhost)                                                                                        
10.75.0.85:0       id=3768  sec_id=4     flags=0x0000 ifindex=10  mac=F2:DD:FF:E2:C8:F8 nodemac=3A:9D:B4:8E:F6:8B     
10.75.0.143:0      id=2584  sec_id=2522141 flags=0x0000 ifindex=18  mac=E6:95:85:13:4C:33 nodemac=6E:11:2B:90:73:1C   
10.75.0.188:0      id=1417  sec_id=2497770 flags=0x0000 ifindex=12  mac=F6:65:8B:19:27:56 nodemac=EE:E4:22:5C:89:EA   
172.31.195.237:0   (localhost)                                                                                        
