top - 08:23:00 up 36 min,  0 users,  load average: 0.25, 0.19, 0.16
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 30.0 sy,  0.0 ni, 16.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4483.0 free,   1184.9 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6444.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383752  77244 S  93.3   4.8   0:52.21 cilium-+
    398 root      20   0 1229488   8024   3900 S   0.0   0.1   0:01.15 cilium-+
    606 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    612 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    613 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    636 root      20   0 1240432  15904  10704 S   0.0   0.2   0:00.03 cilium-+
    637 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    686 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    704 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0 1616264   8752   6252 S   0.0   0.1   0:00.00 runc:[2+
