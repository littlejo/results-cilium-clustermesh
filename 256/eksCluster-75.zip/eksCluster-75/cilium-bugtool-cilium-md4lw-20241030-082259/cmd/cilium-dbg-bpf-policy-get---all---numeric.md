Endpoint ID: 109
Path: /sys/fs/bpf/tc/globals/cilium_policy_00109

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1417
Path: /sys/fs/bpf/tc/globals/cilium_policy_01417

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165538   1894      0        
Allow    Egress      0          ANY          NONE         disabled    21828    244       0        


Endpoint ID: 2584
Path: /sys/fs/bpf/tc/globals/cilium_policy_02584

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10494531   106029    0        
Allow    Ingress     1          ANY          NONE         disabled    9079328    94749     0        
Allow    Egress      0          ANY          NONE         disabled    10829896   110178    0        


Endpoint ID: 3209
Path: /sys/fs/bpf/tc/globals/cilium_policy_03209

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    166198   1904      0        
Allow    Egress      0          ANY          NONE         disabled    21784    244       0        


Endpoint ID: 3768
Path: /sys/fs/bpf/tc/globals/cilium_policy_03768

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1595721   20206     0        
Allow    Ingress     1          ANY          NONE         disabled    25232     295       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


