[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-04e9cc4ef0eab7155fd1b532efbb3fce62c836d1a208699da0398e6f63d84642.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-b7133667ffefba604311ad8672034310c35698433c4303115e2cbce232bf6d57.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2989b70d_356f_4d31_8b4c_491b6cf46573.slice/cri-containerd-f1a731d240f22989983f34e9556ed258b518106b04dc79e1c00977143b0d520f.scope"
      }
    ],
    "ips": [
      "10.75.0.143"
    ],
    "name": "clustermesh-apiserver-65c8d69bb6-s8j8q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76835b0_40e3_404c_8258_c1715ac22bf9.slice/cri-containerd-2b9a9e32b7704677186ecc22dbcbe1af1a5dc3231ebf325d0affb7fcc03ce509.scope"
      }
    ],
    "ips": [
      "10.75.0.188"
    ],
    "name": "coredns-cc6ccd49c-4pnrc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ce0ba51_0f2e_4ff0_825b_5d48d4eb651b.slice/cri-containerd-5bfa9280341248d6d886ae0e8f4a9ca653d8a771c1060423abe7afef7c36bc5f.scope"
      }
    ],
    "ips": [
      "10.75.0.182"
    ],
    "name": "coredns-cc6ccd49c-slg5z",
    "namespace": "kube-system"
  }
]

