key: 06 00 00 00  value: 0a 4b 00 bc 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 4b 00 8f 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 4b 00 b6 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 4b 00 bc 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 8d ab 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c3 ed 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f c4 91 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 4b 00 b6 00 35 00 00  00 00 00 00
Found 8 elements
