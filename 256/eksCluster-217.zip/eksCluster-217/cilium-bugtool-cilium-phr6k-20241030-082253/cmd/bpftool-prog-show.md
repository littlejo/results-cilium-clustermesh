35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:56:10+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:56:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:56:15+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:41+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
504: sched_cls  name tail_handle_ipv4  tag bafdcc90e5369060  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
505: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
506: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:04:12+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 139
529: sched_cls  name tail_ipv4_ct_egress  tag dad88338e449f7f7  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 165
530: sched_cls  name tail_handle_ipv4  tag 4077e1dad804c382  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 166
531: sched_cls  name tail_handle_arp  tag e26b98ec6f386982  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 167
532: sched_cls  name tail_handle_ipv4_cont  tag cd481980c9b5b224  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 168
534: sched_cls  name handle_policy  tag bcfeb8d01ca877d7  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 170
535: sched_cls  name __send_drop_notify  tag 3117f5e3589d2cba  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
536: sched_cls  name cil_from_container  tag e871d9f9d78e0da9  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 172
537: sched_cls  name tail_ipv4_ct_ingress  tag 53dd45ea45929e6b  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 173
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 174
539: sched_cls  name tail_ipv4_to_endpoint  tag 91ff60d095cd1c59  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 175
540: sched_cls  name cil_from_container  tag c757d14b8040b8f8  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 177
541: sched_cls  name tail_handle_ipv4  tag 4e3514798b46e76e  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 178
543: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 180
544: sched_cls  name tail_ipv4_to_endpoint  tag 9de6b513d86ef5fe  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,105,39,113,40,37,38
	btf_id 181
545: sched_cls  name handle_policy  tag b8eff9ebe9311b03  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,114,41,80,105,39,84,75,40,37,38
	btf_id 182
546: sched_cls  name __send_drop_notify  tag 039bb7fc3fc15d26  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 183
547: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
550: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
551: sched_cls  name tail_handle_arp  tag 4def64495a221550  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 184
552: sched_cls  name tail_ipv4_ct_ingress  tag 874c2893f9bf9c69  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 185
553: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 186
554: sched_cls  name tail_handle_ipv4_cont  tag a7408ca38cf4bb06  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,114,41,105,82,83,39,76,74,77,113,40,37,38,81
	btf_id 187
555: sched_cls  name tail_handle_ipv4_cont  tag f7d67eb7801e0171  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,106,82,83,39,76,74,77,117,40,37,38,81
	btf_id 189
556: sched_cls  name tail_ipv4_ct_egress  tag dad88338e449f7f7  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 190
557: sched_cls  name handle_policy  tag 740c965af9ed2986  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,117,82,83,116,41,80,106,39,84,75,40,37,38
	btf_id 191
558: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 192
559: sched_cls  name cil_from_container  tag bffcac563848c190  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 117,76
	btf_id 193
560: sched_cls  name tail_handle_ipv4  tag fce4e85cf5842cad  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 194
561: sched_cls  name tail_ipv4_to_endpoint  tag 009e1e5d36c70cd4  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,106,39,117,40,37,38
	btf_id 195
563: sched_cls  name tail_ipv4_ct_ingress  tag ee431d5455bea356  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,117,82,83,116,84
	btf_id 197
564: sched_cls  name tail_handle_arp  tag 26ecf06fee2c5251  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 198
565: sched_cls  name __send_drop_notify  tag 1e6e30cc80b1cc3b  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:04:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
570: sched_cls  name __send_drop_notify  tag 1fb524d1fdb9ee6f  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 202
572: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,120
	btf_id 203
574: sched_cls  name tail_handle_ipv4_from_host  tag 29ac7455ba99c8f9  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 205
576: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 207
578: sched_cls  name tail_handle_ipv4_from_host  tag 29ac7455ba99c8f9  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 210
580: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 212
581: sched_cls  name __send_drop_notify  tag 1fb524d1fdb9ee6f  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 214
584: sched_cls  name tail_handle_ipv4_from_host  tag 29ac7455ba99c8f9  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 217
585: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 218
587: sched_cls  name __send_drop_notify  tag 1fb524d1fdb9ee6f  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
588: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 221
593: sched_cls  name tail_handle_ipv4_from_host  tag 29ac7455ba99c8f9  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 227
594: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 228
596: sched_cls  name __send_drop_notify  tag 1fb524d1fdb9ee6f  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
597: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:04:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 231
637: sched_cls  name __send_drop_notify  tag fe1121a61b9bdf29  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 245
638: sched_cls  name tail_ipv4_to_endpoint  tag 99dcdd1559393aae  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,139,41,82,83,80,137,39,138,40,37,38
	btf_id 246
639: sched_cls  name tail_handle_ipv4_cont  tag f0f50d234f41665a  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,139,41,137,82,83,39,76,74,77,138,40,37,38,81
	btf_id 247
640: sched_cls  name handle_policy  tag 2e313692f54c1413  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,138,82,83,139,41,80,137,39,84,75,40,37,38
	btf_id 248
641: sched_cls  name tail_ipv4_ct_ingress  tag 6dfabf007d266e71  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 249
642: sched_cls  name tail_handle_ipv4  tag de97cf02e2693222  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,138
	btf_id 250
643: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,138
	btf_id 251
644: sched_cls  name tail_handle_arp  tag 7c6b66dffab39060  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,138
	btf_id 252
646: sched_cls  name tail_ipv4_ct_egress  tag 2f161b0d300db23b  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 254
647: sched_cls  name cil_from_container  tag dadda55d5d150a2e  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 138,76
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
