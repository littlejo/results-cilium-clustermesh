[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-2f61ed406d6c38d7207d5a0b170feef9a41ba86329f41750faba7d31e03fb00d.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-b3fd68e1a63b11a370ad6dd9559f6a48ad39929492d6172b236d2b8a095455f5.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-9efb7e6b8b47b1d39d304d55cf2ef7b71d3a3c84d75f73b995da129d95e9abb7.scope"
      }
    ],
    "ips": [
      "10.217.0.87"
    ],
    "name": "clustermesh-apiserver-65cffb985c-6rvgg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2344830_4070_4bb5_bdfd_7713e9573970.slice/cri-containerd-ca5c69c79df0fe5c3ca4b16e32204c604161cdd7708a943196e22d96ec641542.scope"
      }
    ],
    "ips": [
      "10.217.0.217"
    ],
    "name": "coredns-cc6ccd49c-zdvzf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod656806b9_cf62_44d7_83bd_4046b7c02460.slice/cri-containerd-8183b719d589f190b516a51f0702fa4ad16a825fc9396078865ac36773537e6a.scope"
      }
    ],
    "ips": [
      "10.217.0.150"
    ],
    "name": "coredns-cc6ccd49c-2tplj",
    "namespace": "kube-system"
  }
]

