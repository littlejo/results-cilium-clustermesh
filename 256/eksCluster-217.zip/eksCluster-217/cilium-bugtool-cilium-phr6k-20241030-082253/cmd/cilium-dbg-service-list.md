ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.199.49:443 (active)     
                                         2 => 172.31.180.116:443 (active)    
2    10.100.96.23:443     ClusterIP      1 => 172.31.250.164:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.217.0.217:53 (active)       
                                         2 => 10.217.0.150:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.217.0.217:9153 (active)     
                                         2 => 10.217.0.150:9153 (active)     
5    10.100.219.60:2379   ClusterIP      1 => 10.217.0.87:2379 (active)      
