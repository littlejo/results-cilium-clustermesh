{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.967Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.967Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.967Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:12.035Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.133Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.142Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.187Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.259Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.315Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:16.250Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:16.250Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:16.251Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:16.279Z",
  "value": "id=368   sec_id=7154237 flags=0x0000 ifindex=16  mac=2A:44:D3:2F:BA:76 nodemac=D6:97:95:B9:40:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:17.250Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:17.251Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:17.251Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:17.251Z",
  "value": "id=368   sec_id=7154237 flags=0x0000 ifindex=16  mac=2A:44:D3:2F:BA:76 nodemac=D6:97:95:B9:40:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.209Z",
  "value": "id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.217.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.600Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.989Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.994Z",
  "value": "id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.997Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:37.000Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:37.963Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:37.964Z",
  "value": "id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:37.964Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:37.964Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.964Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.964Z",
  "value": "id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.964Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:38.965Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.964Z",
  "value": "id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.965Z",
  "value": "id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.965Z",
  "value": "id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.217.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:39.966Z",
  "value": "id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5"
}

