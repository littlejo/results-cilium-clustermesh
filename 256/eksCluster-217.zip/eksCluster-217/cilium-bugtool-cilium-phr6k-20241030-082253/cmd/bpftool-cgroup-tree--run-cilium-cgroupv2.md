CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc974a88c_c2ec_417c_9258_a62912289cfa.slice/cri-containerd-3016e45e51a2034aadb3541615337fbb616ab75562d2f2c42b01e6549af28acd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc974a88c_c2ec_417c_9258_a62912289cfa.slice/cri-containerd-f92def914fc238b8952ca49982dfb00fee23d5dc08fc2c22713187bf9b5fece0.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2344830_4070_4bb5_bdfd_7713e9573970.slice/cri-containerd-e539944c6e3383e0f654585fd59f42ee3b7a6cb164433be3081071e082ab22bd.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc2344830_4070_4bb5_bdfd_7713e9573970.slice/cri-containerd-ca5c69c79df0fe5c3ca4b16e32204c604161cdd7708a943196e22d96ec641542.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod656806b9_cf62_44d7_83bd_4046b7c02460.slice/cri-containerd-8183b719d589f190b516a51f0702fa4ad16a825fc9396078865ac36773537e6a.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod656806b9_cf62_44d7_83bd_4046b7c02460.slice/cri-containerd-d76efcaff557f2643855e986f6db54fd33ed966fc67ee27a823b67decddffb64.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb966e23d_9816_4404_902a_1b96c4984d7f.slice/cri-containerd-16bcd9a5ccc9931aeb6c1c031f4979c8bf51293836c09ae9320a3baa9d31253f.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb966e23d_9816_4404_902a_1b96c4984d7f.slice/cri-containerd-3de8b933bf314aa6df3211b19def7c1753c295c45893e5446378efee11699821.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod012b8ad2_376f_4bd6_875f_6a984b3d25b1.slice/cri-containerd-93701ad6c71983b3d4aaa917b73ca612f2bfbca21a5fc46f7b7726b02e1b9dba.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod012b8ad2_376f_4bd6_875f_6a984b3d25b1.slice/cri-containerd-3c50b4839daeeac68d67ac3a30a4c4314c667855da91bab14e4d0b6d67dd61de.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-2f61ed406d6c38d7207d5a0b170feef9a41ba86329f41750faba7d31e03fb00d.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-9efb7e6b8b47b1d39d304d55cf2ef7b71d3a3c84d75f73b995da129d95e9abb7.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-b3fd68e1a63b11a370ad6dd9559f6a48ad39929492d6172b236d2b8a095455f5.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3629359c_5445_4361_9cfa_8c8249f239ce.slice/cri-containerd-d232d0702af3665725b169b835a04c62300eaa7da5a39ea006e3313d762a72d8.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e0e25c1_2d1a_4f52_b0fd_5113550bc7a2.slice/cri-containerd-1194dbf86cfed3a317dcf71083ffd3eb7cbc5d11674d2bb0ea649d64c61d2310.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e0e25c1_2d1a_4f52_b0fd_5113550bc7a2.slice/cri-containerd-cef7482f24ad0d01897402afacd8c928c09f746b77fdf7eeee654a97e4264fbe.scope
    101      cgroup_device   multi                                          
