USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         716  2.0  0.2 1240432 16092 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         735  0.0  0.0   6408  1640 ?        R    08:22   0:00  \_ ps auxfw
root         737  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c ip a
root         710  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         684  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         672  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.7  4.7 1606336 380832 ?      Ssl  08:03   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.1  0.0 1229744 6976 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
