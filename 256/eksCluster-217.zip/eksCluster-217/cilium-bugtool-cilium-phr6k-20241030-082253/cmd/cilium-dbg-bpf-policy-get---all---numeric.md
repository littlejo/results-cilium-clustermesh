Endpoint ID: 47
Path: /sys/fs/bpf/tc/globals/cilium_policy_00047

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11111706   108123    0        
Allow    Ingress     1          ANY          NONE         disabled    8705965    90746     0        
Allow    Egress      0          ANY          NONE         disabled    10325953   103288    0        


Endpoint ID: 241
Path: /sys/fs/bpf/tc/globals/cilium_policy_00241

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 559
Path: /sys/fs/bpf/tc/globals/cilium_policy_00559

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660597   20968     0        
Allow    Ingress     1          ANY          NONE         disabled    17560     207       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3663
Path: /sys/fs/bpf/tc/globals/cilium_policy_03663

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110017   1263      0        
Allow    Egress      0          ANY          NONE         disabled    16583    180       0        


Endpoint ID: 3793
Path: /sys/fs/bpf/tc/globals/cilium_policy_03793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110091   1264      0        
Allow    Egress      0          ANY          NONE         disabled    16421    177       0        


