IP ADDRESS         LOCAL ENDPOINT INFO
10.217.0.87:0      id=47    sec_id=7154237 flags=0x0000 ifindex=18  mac=2A:D9:AB:F8:5D:7E nodemac=5E:DA:98:98:A1:5C   
10.217.0.150:0     id=3663  sec_id=7152587 flags=0x0000 ifindex=14  mac=9E:7B:AB:84:05:BC nodemac=72:70:25:0C:D8:D5   
10.217.0.201:0     id=559   sec_id=4     flags=0x0000 ifindex=10  mac=3A:34:4D:51:49:85 nodemac=F2:ED:58:06:D8:73     
10.217.0.200:0     (localhost)                                                                                        
10.217.0.217:0     id=3793  sec_id=7152587 flags=0x0000 ifindex=12  mac=6A:D4:B6:D3:AB:67 nodemac=FE:A5:3A:FB:21:E1   
172.31.195.190:0   (localhost)                                                                                        
172.31.250.164:0   (localhost)                                                                                        
