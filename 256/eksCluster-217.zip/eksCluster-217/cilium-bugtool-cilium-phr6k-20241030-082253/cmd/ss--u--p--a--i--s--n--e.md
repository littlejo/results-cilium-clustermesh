Total: 659
TCP:   1848 (estab 423, closed 1406, orphaned 0, timewait 571)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  442       432       10       
INET	  452       438       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:41595      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32842 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.250.164%ens5:68         0.0.0.0:*    uid:192 ino:16569 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32996 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14235 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0      [fe80::8e9:2bff:fe76:30bb]%ens5:546           [::]:*    uid:192 ino:16561 sk:5 cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32995 sk:6 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14236 sk:7 cgroup:unreachable:f0c v6only:1 <->                           
