filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb974bb89c90c direct-action not_in_hw id 647 tag dadda55d5d150a2e jited 
