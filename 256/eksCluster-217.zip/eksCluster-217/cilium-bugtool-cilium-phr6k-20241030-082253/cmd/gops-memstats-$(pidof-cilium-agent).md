alloc: 209.14MB (219300224 bytes)
total-alloc: 2.12GB (2278028560 bytes)
sys: 341.09MB (357653876 bytes)
lookups: 0
mallocs: 61145853
frees: 58993547
heap-alloc: 209.14MB (219300224 bytes)
heap-sys: 264.72MB (277577728 bytes)
heap-idle: 33.11MB (34717696 bytes)
heap-in-use: 231.61MB (242860032 bytes)
heap-released: 3.75MB (3932160 bytes)
heap-objects: 2152306
stack-in-use: 62.91MB (65961984 bytes)
stack-sys: 62.91MB (65961984 bytes)
stack-mspan-inuse: 3.48MB (3649120 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1223825 bytes)
gc-sys: 6.43MB (6746664 bytes)
next-gc: when heap-alloc >= 220.81MB (231540248 bytes)
last-gc: 2024-10-30 08:23:25.087540298 +0000 UTC
gc-pause-total: 23.850799ms
gc-pause: 280543
gc-pause-end: 1730276605087540298
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0006305021679044786
enable-gc: true
debug-gc: false
