key: 2f 00 00 00  value: 80 02 00 00
key: 2f 02 00 00  value: 21 02 00 00
key: 4f 0e 00 00  value: 2d 02 00 00
key: d1 0e 00 00  value: 16 02 00 00
Found 4 elements
