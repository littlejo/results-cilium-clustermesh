REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34078     2694901     677    bpf_overlay.c
Interface                 INGRESS     598225    126122183   1132   bpf_host.c
Success                   EGRESS      13816     1082725     1694   bpf_host.c
Success                   EGRESS      254743    32493227    1308   bpf_lxc.c
Success                   EGRESS      32644     2589987     53     encap.h
Success                   INGRESS     290737    32576188    86     l3.h
Success                   INGRESS     311650    34232410    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
