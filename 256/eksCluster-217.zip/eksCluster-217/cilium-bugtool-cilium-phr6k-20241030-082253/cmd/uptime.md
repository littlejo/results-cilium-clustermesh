 08:22:54 up 26 min,  0 users,  load average: 0.19, 0.21, 0.19
