xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 585
ens6(5) clsact/ingress cil_from_netdev-ens6 id 594
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 580
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 576
cilium_host(7) clsact/egress cil_from_host-cilium_host id 572
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 505
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 506
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 540
lxc3446e616feef(12) clsact/ingress cil_from_container-lxc3446e616feef id 536
lxc5c741b925b12(14) clsact/ingress cil_from_container-lxc5c741b925b12 id 559
lxcb974bb89c90c(18) clsact/ingress cil_from_container-lxcb974bb89c90c id 647

flow_dissector:

netfilter:

