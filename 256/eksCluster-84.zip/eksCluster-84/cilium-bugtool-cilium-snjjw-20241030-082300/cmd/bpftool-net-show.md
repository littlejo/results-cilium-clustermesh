xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 558
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 546
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 541
cilium_host(7) clsact/egress cil_from_host-cilium_host id 538
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 578
lxce9a26c638634(12) clsact/ingress cil_from_container-lxce9a26c638634 id 516
lxc7f9325339f2e(14) clsact/ingress cil_from_container-lxc7f9325339f2e id 536
lxc27419908d40a(18) clsact/ingress cil_from_container-lxc27419908d40a id 637

flow_dissector:

netfilter:

