{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.191Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.191Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.183.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.191Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.754Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.757Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.813Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:18.823Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.422Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.422Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.423Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.449Z",
  "value": "id=2585  sec_id=2804852 flags=0x0000 ifindex=16  mac=3E:5B:C2:02:32:05 nodemac=AA:2C:9A:C9:38:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.450Z",
  "value": "id=2585  sec_id=2804852 flags=0x0000 ifindex=16  mac=3E:5B:C2:02:32:05 nodemac=AA:2C:9A:C9:38:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.421Z",
  "value": "id=2585  sec_id=2804852 flags=0x0000 ifindex=16  mac=3E:5B:C2:02:32:05 nodemac=AA:2C:9A:C9:38:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.421Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.422Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:09.422Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.991Z",
  "value": "id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.84.0.136:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.659Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.453Z",
  "value": "id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.461Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.461Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.462Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.408Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.409Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.409Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.410Z",
  "value": "id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.402Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.402Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.402Z",
  "value": "id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.402Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.402Z",
  "value": "id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.402Z",
  "value": "id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.403Z",
  "value": "id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.84.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.403Z",
  "value": "id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09"
}

