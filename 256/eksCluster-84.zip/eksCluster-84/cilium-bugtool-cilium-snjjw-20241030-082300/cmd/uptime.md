 08:23:01 up 34 min,  0 users,  load average: 0.15, 0.18, 0.13
