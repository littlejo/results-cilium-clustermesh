CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb59f9c1e_2f1d_4755_8422_e7c2830a9d2b.slice/cri-containerd-46011c374f28163f156b85d85ea13f88add0f6ea20965ccdbc9e9c6269dfa600.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb59f9c1e_2f1d_4755_8422_e7c2830a9d2b.slice/cri-containerd-3cbabbca93f9ef6b8d8f68f1784a213f917e9ae9451dcc043a9adc1d2d01eaf5.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405c1a68_fa0f_4bad_aaf4_6880f92fbe4e.slice/cri-containerd-aabfb856e199e421b08a06875391600de77622090fb9e48d07ec3639972a7703.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405c1a68_fa0f_4bad_aaf4_6880f92fbe4e.slice/cri-containerd-e203a41b255c51f5677e3854dd4a006674393dff9a23b2fb44a68e4480186076.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84f5f438_9dae_43a6_8718_31e9db0dcc6f.slice/cri-containerd-36b4e16d4e8567cbc0acd9e0a05ad512fe2cd80d6771a894fbad0eb9b23febc9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod84f5f438_9dae_43a6_8718_31e9db0dcc6f.slice/cri-containerd-9f6336105d820575ae5be73b0c7ded5748668cbb642d543d5eacacf6635fde35.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd886df_61f2_49d1_9b2c_5e7882df59bd.slice/cri-containerd-082dda0ccfed41a657c62883f67ac3812e48e4bad0ac3d70b9f36cbbdbc92005.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd886df_61f2_49d1_9b2c_5e7882df59bd.slice/cri-containerd-159c2d64ea19ec6a5cd90fc5cd4d088eb513f6a8e82f57a79263c5d1a242c849.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bc21443_9903_4d9f_be9b_f372ced1d40e.slice/cri-containerd-0fce3a9dc7ef512e0287ea4ca3eeacfe7af4fdb6e8fe54308b2df75d4f50caf4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bc21443_9903_4d9f_be9b_f372ced1d40e.slice/cri-containerd-61d7fe63d4c5da4a373a6195f3aedd5069bcea11604b1721c6a6505729edeb43.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-b6edae1bc589e8acb80340c184c9626be5e22a7d15d84c08dd62cc7fe9d9b821.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-10151aba3378b5f03dca01518b9804eab20e557864e34a7bdd87013c07ea92af.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-ceb26027fd0c8f91ac79c82b8672cd93cf1209296130812c76ecf2de99094844.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-ac4846c621b8e3749252118ccf73fcca7ca333e80edad8ae6850e9b4ce42a53c.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c314953_0054_46c9_a664_24ac1a2aa478.slice/cri-containerd-75e38e3b9b1be9e65d6ab158a77e474d28c8268650e28ca1421f7a0ed7ca216b.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c314953_0054_46c9_a664_24ac1a2aa478.slice/cri-containerd-513e16fb9a2dfe3fff339e8d7232b5acc9c606e1a6d121965aa9278a52114418.scope
    91       cgroup_device   multi                                          
