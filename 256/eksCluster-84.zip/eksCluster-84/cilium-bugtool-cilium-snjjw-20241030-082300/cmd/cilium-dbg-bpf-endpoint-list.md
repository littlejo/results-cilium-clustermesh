IP ADDRESS        LOCAL ENDPOINT INFO
10.84.0.112:0     id=93    sec_id=2804852 flags=0x0000 ifindex=18  mac=2A:E8:3F:74:80:91 nodemac=36:CB:1F:BB:00:63   
10.84.0.121:0     id=170   sec_id=2811287 flags=0x0000 ifindex=12  mac=CE:98:81:CD:61:21 nodemac=DA:05:80:2A:7F:DC   
10.84.0.201:0     id=1145  sec_id=4     flags=0x0000 ifindex=10  mac=3E:8B:4F:74:08:EF nodemac=CE:BC:10:DA:51:61     
172.31.183.94:0   (localhost)                                                                                        
172.31.149.34:0   (localhost)                                                                                        
10.84.0.184:0     id=1299  sec_id=2811287 flags=0x0000 ifindex=14  mac=CA:40:AA:5D:A6:14 nodemac=66:2F:3D:87:D0:09   
10.84.0.35:0      (localhost)                                                                                        
