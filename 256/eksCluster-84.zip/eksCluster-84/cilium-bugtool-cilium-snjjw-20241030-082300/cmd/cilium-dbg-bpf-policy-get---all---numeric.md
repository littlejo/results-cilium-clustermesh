Endpoint ID: 93
Path: /sys/fs/bpf/tc/globals/cilium_policy_00093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11270236   110021    0        
Allow    Ingress     1          ANY          NONE         disabled    9163901    95788     0        
Allow    Egress      0          ANY          NONE         disabled    10702790   106919    0        


Endpoint ID: 170
Path: /sys/fs/bpf/tc/globals/cilium_policy_00170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    430481   3866      0        
Allow    Ingress     1          ANY          NONE         disabled    150748   1734      0        
Allow    Egress      0          ANY          NONE         disabled    117488   1131      0        


Endpoint ID: 1145
Path: /sys/fs/bpf/tc/globals/cilium_policy_01145

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667290   21066     0        
Allow    Ingress     1          ANY          NONE         disabled    22508     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1299
Path: /sys/fs/bpf/tc/globals/cilium_policy_01299

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    421579   3784      0        
Allow    Ingress     1          ANY          NONE         disabled    152134   1755      0        
Allow    Egress      0          ANY          NONE         disabled    114707   1104      0        


Endpoint ID: 2642
Path: /sys/fs/bpf/tc/globals/cilium_policy_02642

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


