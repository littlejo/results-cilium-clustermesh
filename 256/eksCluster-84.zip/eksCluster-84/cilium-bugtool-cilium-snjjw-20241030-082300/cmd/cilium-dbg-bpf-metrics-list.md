REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35578     2812834     677    bpf_overlay.c
Interface                 INGRESS     622118    129469778   1132   bpf_host.c
Success                   EGRESS      15111     1186264     1694   bpf_host.c
Success                   EGRESS      15300     2424750     86     l3.h
Success                   EGRESS      260992    33245717    1308   bpf_lxc.c
Success                   EGRESS      34878     2764506     53     encap.h
Success                   INGRESS     301980    33893868    86     l3.h
Success                   INGRESS     338271    37979836    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
