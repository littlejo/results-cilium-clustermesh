KEY             VALUE
AgentLiveness   2083753782401
UTimeOffset     3379442437500000
