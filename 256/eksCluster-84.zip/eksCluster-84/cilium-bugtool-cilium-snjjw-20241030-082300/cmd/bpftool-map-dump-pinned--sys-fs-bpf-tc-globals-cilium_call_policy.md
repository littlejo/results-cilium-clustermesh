key: 5d 00 00 00  value: 84 02 00 00
key: aa 00 00 00  value: 13 02 00 00
key: 79 04 00 00  value: 3e 02 00 00
key: 13 05 00 00  value: 36 02 00 00
Found 4 elements
