USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         660  0.0  0.1 1616264 8808 ?        Ssl  08:23   0:00 /usr/sbin/runc init
root         637  0.0  0.2 1240432 16608 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         667  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         668  0.0  0.0   2068   236 ?        R    08:23   0:00  \_ hostname
root         628  0.0  0.0 1228744 3776 ?        Ssl  08:23   0:00 /bin/gops memstats 1
root         618  0.0  0.0 1228744 3660 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root           1  3.1  4.8 1606080 388004 ?      Ssl  07:57   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7320 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
