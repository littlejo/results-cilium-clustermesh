[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-b6edae1bc589e8acb80340c184c9626be5e22a7d15d84c08dd62cc7fe9d9b821.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-ac4846c621b8e3749252118ccf73fcca7ca333e80edad8ae6850e9b4ce42a53c.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23889212_c75d_45d9_b26f_5d5485ac9870.slice/cri-containerd-10151aba3378b5f03dca01518b9804eab20e557864e34a7bdd87013c07ea92af.scope"
      }
    ],
    "ips": [
      "10.84.0.112"
    ],
    "name": "clustermesh-apiserver-6bbc9ccd76-hbsdj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod405c1a68_fa0f_4bad_aaf4_6880f92fbe4e.slice/cri-containerd-e203a41b255c51f5677e3854dd4a006674393dff9a23b2fb44a68e4480186076.scope"
      }
    ],
    "ips": [
      "10.84.0.121"
    ],
    "name": "coredns-cc6ccd49c-bnsjg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cd886df_61f2_49d1_9b2c_5e7882df59bd.slice/cri-containerd-159c2d64ea19ec6a5cd90fc5cd4d088eb513f6a8e82f57a79263c5d1a242c849.scope"
      }
    ],
    "ips": [
      "10.84.0.184"
    ],
    "name": "coredns-cc6ccd49c-mmvs4",
    "namespace": "kube-system"
  }
]

