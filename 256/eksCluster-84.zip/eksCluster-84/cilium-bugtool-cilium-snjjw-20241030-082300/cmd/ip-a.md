1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c8:36:b2:46:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.149.34/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3357sec preferred_lft 3357sec
    inet6 fe80::4c8:36ff:feb2:46cb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f0:22:64:ef:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.183.94/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4f0:22ff:fe64:ef41/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:66:af:b9:55:b5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a866:afff:feb9:55b5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:c9:f9:d1:42:26 brd ff:ff:ff:ff:ff:ff
    inet 10.84.0.35/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::94c9:f9ff:fed1:4226/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 5a:df:20:44:e6:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::58df:20ff:fe44:e6fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:bc:10:da:51:61 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ccbc:10ff:feda:5161/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce9a26c638634@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:05:80:2a:7f:dc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d805:80ff:fe2a:7fdc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7f9325339f2e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:2f:3d:87:d0:09 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::642f:3dff:fe87:d009/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc27419908d40a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:cb:1f:bb:00:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::34cb:1fff:febb:63/64 scope link 
       valid_lft forever preferred_lft forever
