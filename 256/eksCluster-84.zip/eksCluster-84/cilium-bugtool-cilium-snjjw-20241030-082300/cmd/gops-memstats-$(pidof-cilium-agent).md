alloc: 178.64MB (187321800 bytes)
total-alloc: 2.27GB (2432693864 bytes)
sys: 340.84MB (357391732 bytes)
lookups: 0
mallocs: 63533105
frees: 62017713
heap-alloc: 178.64MB (187321800 bytes)
heap-sys: 263.41MB (276209664 bytes)
heap-idle: 52.88MB (55443456 bytes)
heap-in-use: 210.54MB (220766208 bytes)
heap-released: 2.03MB (2129920 bytes)
heap-objects: 1515392
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.06MB (3212960 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 910.36KB (932209 bytes)
gc-sys: 6.10MB (6396600 bytes)
next-gc: when heap-alloc >= 213.25MB (223612072 bytes)
last-gc: 2024-10-30 08:23:08.725600275 +0000 UTC
gc-pause-total: 14.944694ms
gc-pause: 104731
gc-pause-end: 1730276588725600275
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004042616388488255
enable-gc: true
debug-gc: false
