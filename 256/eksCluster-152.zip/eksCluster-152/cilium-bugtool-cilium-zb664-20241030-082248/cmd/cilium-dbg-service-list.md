ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.157.210:443 (active)   
                                          2 => 172.31.211.144:443 (active)   
2    10.100.44.63:443      ClusterIP      1 => 172.31.190.51:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.152.0.110:53 (active)      
                                          2 => 10.152.0.74:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.152.0.110:9153 (active)    
                                          2 => 10.152.0.74:9153 (active)     
5    10.100.162.199:2379   ClusterIP      1 => 10.152.0.2:2379 (active)      
