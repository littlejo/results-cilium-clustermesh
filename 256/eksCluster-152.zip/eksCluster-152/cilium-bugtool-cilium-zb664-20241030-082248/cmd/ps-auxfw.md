USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         686  0.0  0.2 1240432 16668 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         701  0.0  0.2 1240432 16668 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         665  0.0  0.0 1229000 4164 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         659  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         651  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         633  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  4.1  4.8 1606080 384412 ?      Ssl  08:01   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.1 1229488 8164 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
