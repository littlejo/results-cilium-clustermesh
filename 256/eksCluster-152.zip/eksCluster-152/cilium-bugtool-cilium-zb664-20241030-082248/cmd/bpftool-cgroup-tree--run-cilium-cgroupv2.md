CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd69efb8d_377c_4c73_a5a8_cfdbec5e15c0.slice/cri-containerd-104eae7070a41a37d3601652fe1a488a2b66889814f43bcac25200f9cc009c7e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd69efb8d_377c_4c73_a5a8_cfdbec5e15c0.slice/cri-containerd-88454673af39a53004a164be6abce0ed7cd98d032beef0553606dbae5a13a53f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68237965_0bed_4a15_a569_38bd1606a459.slice/cri-containerd-27391132519db12c104066d5a7e2c1ea98633f22ffa92d2244511ac35d535f9d.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68237965_0bed_4a15_a569_38bd1606a459.slice/cri-containerd-31bab5c0b34aad53fd6063759d19ee976997d6588e6fa4bd8e7fcfcbc3e79e4f.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f830102_c00b_48c6_b7e4_1409a6092d57.slice/cri-containerd-8fc59e0ec3c97c51180ff460ddb0011c3f083073cf79a62c79175dbc60c70c1f.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f830102_c00b_48c6_b7e4_1409a6092d57.slice/cri-containerd-baf499cc986be1e340ade214d510d24642a772c67b64899b6fa95735b5df2114.scope
    521      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc40ff5ed_5230_4f61_84f0_f0920588f3f7.slice/cri-containerd-ddca486f4697b83706c75bf6c9fb4a928ffd390347561762989a14865e618722.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc40ff5ed_5230_4f61_84f0_f0920588f3f7.slice/cri-containerd-d7453bf61ff443921075e8aa35d2390c7ba6f2dfd7d8fddf578d0f50dacbfc0a.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2dae3d56_7a28_408b_9de0_5bef3e864a6c.slice/cri-containerd-ea5fcd59cc642e03e57dbf6c55f87f77b8530d1813ff0c21da0e1f62e25f14d7.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2dae3d56_7a28_408b_9de0_5bef3e864a6c.slice/cri-containerd-1eb47675f9f3bededcbc60fba0341146d12d3130da666811a3fd5e5a528a9ca7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdb98f1b_2a30_47e4_af97_3c29a76fa59a.slice/cri-containerd-7fa27131930944335bff54bb13e495fdb3f434586ff456a693392b33fddd3721.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcdb98f1b_2a30_47e4_af97_3c29a76fa59a.slice/cri-containerd-0a0042c79c1f4c4b5a0af07b39cff7674243cc62355cc9eaf830f38b7f3cf1b5.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-dfa4e496cbf9b7715ceb2ee3a99d9baeecf08c7cd5a53e4253b71e88460a26f6.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-0c730a8adc203a825bdfad5e7b2a1e59ef10797cd99ed673b76e81373206b14f.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-9f7bfc3dc58466ac8f1204eab9c4e6e060aa8b37d5bc6b31e7e239afa66a2f1f.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-5a8886d50017aae3c26f114130a6298aae9478abf9a669c75c7964a16e48d887.scope
    658      cgroup_device   multi                                          
