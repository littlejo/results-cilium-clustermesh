KEY             VALUE
AgentLiveness   1930377688374
UTimeOffset     3379442714843750
