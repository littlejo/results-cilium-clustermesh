top - 08:22:49 up 31 min,  0 users,  load average: 1.85, 0.51, 0.22
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.6 us, 31.0 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4463.2 free,   1205.1 used,   2145.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 391276  78656 S  93.3   4.9   0:53.82 cilium-+
    743 root      20   0 1243508  18016  13192 S   6.7   0.2   0:00.01 hubble
    406 root      20   0 1229488   8164   3900 S   0.0   0.1   0:01.19 cilium-+
    633 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1229000   4164   3456 S   0.0   0.1   0:00.00 gops
    686 root      20   0 1240432  17016  11484 S   0.0   0.2   0:00.02 cilium-+
    712 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    727 root      20   0    2208    780    704 S   0.0   0.0   0:00.00 timeout
    737 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
