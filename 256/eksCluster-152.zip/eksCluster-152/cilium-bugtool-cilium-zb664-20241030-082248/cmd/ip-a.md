1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7f:9c:72:54:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.51/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3509sec preferred_lft 3509sec
    inet6 fe80::47f:9cff:fe72:543b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:92:77:b3:80:55 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.142.63/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::492:77ff:feb3:8055/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:f3:3e:bf:93:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4cf3:3eff:febf:93f1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:12:2b:f2:0a:86 brd ff:ff:ff:ff:ff:ff
    inet 10.152.0.234/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ac12:2bff:fef2:a86/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 26:35:01:61:38:b9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2435:1ff:fe61:38b9/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:d5:45:35:fa:59 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cd5:45ff:fe35:fa59/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3efbae8ce40a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:32:0c:7a:15:0b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b432:cff:fe7a:150b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca7393ef0f795@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:69:78:d1:b3:27 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7469:78ff:fed1:b327/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3fda9a61461a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:21:fa:a5:1a:76 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ac21:faff:fea5:1a76/64 scope link 
       valid_lft forever preferred_lft forever
