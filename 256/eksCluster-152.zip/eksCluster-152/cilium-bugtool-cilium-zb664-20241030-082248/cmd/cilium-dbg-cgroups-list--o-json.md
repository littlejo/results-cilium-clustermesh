[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-dfa4e496cbf9b7715ceb2ee3a99d9baeecf08c7cd5a53e4253b71e88460a26f6.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-5a8886d50017aae3c26f114130a6298aae9478abf9a669c75c7964a16e48d887.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2564d13f_283d_45cb_9d2a_ef1f782ce056.slice/cri-containerd-9f7bfc3dc58466ac8f1204eab9c4e6e060aa8b37d5bc6b31e7e239afa66a2f1f.scope"
      }
    ],
    "ips": [
      "10.152.0.2"
    ],
    "name": "clustermesh-apiserver-6fc896d77c-8mxwp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f830102_c00b_48c6_b7e4_1409a6092d57.slice/cri-containerd-8fc59e0ec3c97c51180ff460ddb0011c3f083073cf79a62c79175dbc60c70c1f.scope"
      }
    ],
    "ips": [
      "10.152.0.74"
    ],
    "name": "coredns-cc6ccd49c-x7b2s",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68237965_0bed_4a15_a569_38bd1606a459.slice/cri-containerd-27391132519db12c104066d5a7e2c1ea98633f22ffa92d2244511ac35d535f9d.scope"
      }
    ],
    "ips": [
      "10.152.0.110"
    ],
    "name": "coredns-cc6ccd49c-hkzd5",
    "namespace": "kube-system"
  }
]

