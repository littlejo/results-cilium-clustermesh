alloc: 198.69MB (208344032 bytes)
total-alloc: 2.36GB (2535578280 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65638057
frees: 63544123
heap-alloc: 198.69MB (208344032 bytes)
heap-sys: 247.17MB (259178496 bytes)
heap-idle: 23.98MB (25141248 bytes)
heap-in-use: 223.20MB (234037248 bytes)
heap-released: 3.72MB (3899392 bytes)
heap-objects: 2093934
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 3.50MB (3671360 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 992.64KB (1016465 bytes)
gc-sys: 6.02MB (6309328 bytes)
next-gc: when heap-alloc >= 211.86MB (222150040 bytes)
last-gc: 2024-10-30 08:22:45.372114298 +0000 UTC
gc-pause-total: 23.23634ms
gc-pause: 100720
gc-pause-end: 1730276565372114298
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00044983043522733477
enable-gc: true
debug-gc: false
