 08:22:49 up 31 min,  0 users,  load average: 1.85, 0.51, 0.22
