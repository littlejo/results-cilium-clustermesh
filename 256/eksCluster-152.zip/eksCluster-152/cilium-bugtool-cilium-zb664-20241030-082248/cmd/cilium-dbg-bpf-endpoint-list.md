IP ADDRESS        LOCAL ENDPOINT INFO
10.152.0.87:0     id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59     
10.152.0.234:0    (localhost)                                                                                        
10.152.0.110:0    id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27   
10.152.0.74:0     id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B   
10.152.0.2:0      id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76   
172.31.190.51:0   (localhost)                                                                                        
172.31.142.63:0   (localhost)                                                                                        
