Endpoint ID: 961
Path: /sys/fs/bpf/tc/globals/cilium_policy_00961

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1325
Path: /sys/fs/bpf/tc/globals/cilium_policy_01325

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    535705   4806      0        
Allow    Ingress     1          ANY          NONE         disabled    123406   1412      0        
Allow    Egress      0          ANY          NONE         disabled    116468   1112      0        


Endpoint ID: 1735
Path: /sys/fs/bpf/tc/globals/cilium_policy_01735

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1638128   20706     0        
Allow    Ingress     1          ANY          NONE         disabled    19918     237       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2049
Path: /sys/fs/bpf/tc/globals/cilium_policy_02049

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11453943   115670    0        
Allow    Ingress     1          ANY          NONE         disabled    10745189   113471    0        
Allow    Egress      0          ANY          NONE         disabled    15179607   147912    0        


Endpoint ID: 2916
Path: /sys/fs/bpf/tc/globals/cilium_policy_02916

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    546885   4913      0        
Allow    Ingress     1          ANY          NONE         disabled    123613   1419      0        
Allow    Egress      0          ANY          NONE         disabled    117761   1126      0        


