{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.804Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.142.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.804Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:33.804Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.341Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.343Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.412Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.522Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.609Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.416Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.416Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.416Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.453Z",
  "value": "id=365   sec_id=5019300 flags=0x0000 ifindex=16  mac=F6:60:E0:22:73:99 nodemac=62:FD:91:9A:51:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.453Z",
  "value": "id=365   sec_id=5019300 flags=0x0000 ifindex=16  mac=F6:60:E0:22:73:99 nodemac=62:FD:91:9A:51:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.416Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.417Z",
  "value": "id=365   sec_id=5019300 flags=0x0000 ifindex=16  mac=F6:60:E0:22:73:99 nodemac=62:FD:91:9A:51:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.417Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:20.417Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.612Z",
  "value": "id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.152.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.015Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.816Z",
  "value": "id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.817Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.817Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.818Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.816Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.816Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.817Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.817Z",
  "value": "id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.816Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.817Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.817Z",
  "value": "id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.817Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.817Z",
  "value": "id=1325  sec_id=5016143 flags=0x0000 ifindex=14  mac=7E:6A:68:0D:7E:61 nodemac=76:69:78:D1:B3:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.818Z",
  "value": "id=2916  sec_id=5016143 flags=0x0000 ifindex=12  mac=6E:82:00:76:CE:6F nodemac=B6:32:0C:7A:15:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.87:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.818Z",
  "value": "id=1735  sec_id=4     flags=0x0000 ifindex=10  mac=96:5C:7F:F7:1A:62 nodemac=8E:D5:45:35:FA:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.152.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.818Z",
  "value": "id=2049  sec_id=5019300 flags=0x0000 ifindex=18  mac=22:9B:4F:4E:BD:00 nodemac=AE:21:FA:A5:1A:76"
}

