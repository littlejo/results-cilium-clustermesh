key: 2d 05 00 00  value: fe 01 00 00
key: c7 06 00 00  value: 18 02 00 00
key: 01 08 00 00  value: 6c 02 00 00
key: 64 0b 00 00  value: 05 02 00 00
Found 4 elements
