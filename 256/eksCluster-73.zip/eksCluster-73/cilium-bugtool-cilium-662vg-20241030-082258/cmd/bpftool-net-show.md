xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 581
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxc79ee6008e159(12) clsact/ingress cil_from_container-lxc79ee6008e159 id 527
lxc886cbfb53f4d(14) clsact/ingress cil_from_container-lxc886cbfb53f4d id 543
lxcb238c4187a50(18) clsact/ingress cil_from_container-lxcb238c4187a50 id 626

flow_dissector:

netfilter:

