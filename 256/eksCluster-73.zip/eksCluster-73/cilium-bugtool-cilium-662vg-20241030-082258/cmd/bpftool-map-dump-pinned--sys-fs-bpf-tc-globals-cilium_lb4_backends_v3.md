key: 07 00 00 00  value: 0a 49 00 fc 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 49 00 be 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 49 00 56 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f cb c8 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 49 00 be 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c1 8c 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9a 95 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 49 00 fc 00 35 00 00  00 00 00 00
Found 8 elements
