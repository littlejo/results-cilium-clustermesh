{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:02.307Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.140:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:02.307Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:02.307Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.536Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.562Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.612Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.665Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:06.726Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.128Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.128Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.129Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:55.158Z",
  "value": "id=865   sec_id=2430387 flags=0x0000 ifindex=16  mac=42:F8:36:42:6E:F1 nodemac=8A:4B:AD:FC:39:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:56.128Z",
  "value": "id=865   sec_id=2430387 flags=0x0000 ifindex=16  mac=42:F8:36:42:6E:F1 nodemac=8A:4B:AD:FC:39:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:56.129Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:56.129Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:56.129Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.653Z",
  "value": "id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.73.0.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.983Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.572Z",
  "value": "id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.575Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.576Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.576Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.565Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.566Z",
  "value": "id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.567Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.567Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.563Z",
  "value": "id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.563Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.564Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.564Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.563Z",
  "value": "id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.563Z",
  "value": "id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.564Z",
  "value": "id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.73.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.564Z",
  "value": "id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42"
}

