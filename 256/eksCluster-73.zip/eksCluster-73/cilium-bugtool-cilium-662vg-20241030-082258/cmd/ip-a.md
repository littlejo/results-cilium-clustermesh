1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d0:4d:cc:a1:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.193.140/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3319sec preferred_lft 3319sec
    inet6 fe80::8d0:4dff:fecc:a1cb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f8:cb:d3:81:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.227.222/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f8:cbff:fed3:81f3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:06:c5:d2:bb:a5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d406:c5ff:fed2:bba5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:02:15:b8:5c:e4 brd ff:ff:ff:ff:ff:ff
    inet 10.73.0.198/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c002:15ff:feb8:5ce4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7e:cc:f2:47:0d:2d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7ccc:f2ff:fe47:d2d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:7c:f9:3e:1a:37 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c47c:f9ff:fe3e:1a37/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc79ee6008e159@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:8e:74:c5:1f:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f08e:74ff:fec5:1fd5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc886cbfb53f4d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:fc:c7:2f:0d:cc brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5cfc:c7ff:fe2f:dcc/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb238c4187a50@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:64:cd:d7:a5:42 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9864:cdff:fed7:a542/64 scope link 
       valid_lft forever preferred_lft forever
