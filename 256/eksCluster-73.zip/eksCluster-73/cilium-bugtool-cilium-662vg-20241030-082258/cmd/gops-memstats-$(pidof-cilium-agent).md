alloc: 127.00MB (133169088 bytes)
total-alloc: 2.38GB (2555696120 bytes)
sys: 336.84MB (353197428 bytes)
lookups: 0
mallocs: 65588762
frees: 64735943
heap-alloc: 127.00MB (133169088 bytes)
heap-sys: 259.30MB (271892480 bytes)
heap-idle: 75.19MB (78839808 bytes)
heap-in-use: 184.11MB (193052672 bytes)
heap-released: 4.56MB (4784128 bytes)
heap-objects: 852819
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 2.86MB (3001920 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 937.29KB (959785 bytes)
gc-sys: 6.10MB (6400576 bytes)
next-gc: when heap-alloc >= 216.07MB (226562392 bytes)
last-gc: 2024-10-30 08:23:24.050813275 +0000 UTC
gc-pause-total: 26.977534ms
gc-pause: 118047
gc-pause-end: 1730276604050813275
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004157605776792019
enable-gc: true
debug-gc: false
