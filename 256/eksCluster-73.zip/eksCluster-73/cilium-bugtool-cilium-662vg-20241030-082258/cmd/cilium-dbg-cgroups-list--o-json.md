[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod618c4e9a_0f8d_4361_962b_989aa9b5db60.slice/cri-containerd-8c3a626d356baeedf0ac576c5c068c45ef2422f29ee59756d3580618ecbc1b98.scope"
      }
    ],
    "ips": [
      "10.73.0.252"
    ],
    "name": "coredns-cc6ccd49c-jgjbq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-555ba3dbe4180f16d5c3b613f827ab0ad1708c5cff5dd64f0403916d486154aa.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-9da847ae7f82c6fe9d1ff33116deb44d2f3fb3359bf1c1cf8ae29e4a0a89429b.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-d088c870ae94149e86cd0bc7a17bc4826542f4a518d8d71cb435066240076238.scope"
      }
    ],
    "ips": [
      "10.73.0.86"
    ],
    "name": "clustermesh-apiserver-5ddf6b6c8f-nfqfk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cf93341_bb54_416c_9bc6_a228e6a97b75.slice/cri-containerd-642a7483e126f6ae2253821623e98195900fcc87f9ea9d5be8ff9c04d90b8edd.scope"
      }
    ],
    "ips": [
      "10.73.0.190"
    ],
    "name": "coredns-cc6ccd49c-lfr89",
    "namespace": "kube-system"
  }
]

