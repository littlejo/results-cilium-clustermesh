markdown output at /tmp/cilium-bugtool-20241030-082259.812+0000-UTC-340181292/cmd/cilium-debuginfo-20241030-082330.774+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.812+0000-UTC-340181292/cmd/cilium-debuginfo-20241030-082330.774+0000-UTC.json
