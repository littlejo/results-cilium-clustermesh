key: 86 01 00 00  value: 0b 02 00 00
key: d3 01 00 00  value: 01 02 00 00
key: fb 02 00 00  value: 20 02 00 00
key: 06 03 00 00  value: 7b 02 00 00
Found 4 elements
