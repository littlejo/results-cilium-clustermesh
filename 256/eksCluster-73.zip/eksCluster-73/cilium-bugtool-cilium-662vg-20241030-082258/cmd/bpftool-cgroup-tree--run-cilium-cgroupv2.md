CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod618c4e9a_0f8d_4361_962b_989aa9b5db60.slice/cri-containerd-9b7ab0a5396976bb462e1b7569831e4bc0a7585101578c08b930446bf2927df0.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod618c4e9a_0f8d_4361_962b_989aa9b5db60.slice/cri-containerd-8c3a626d356baeedf0ac576c5c068c45ef2422f29ee59756d3580618ecbc1b98.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cf93341_bb54_416c_9bc6_a228e6a97b75.slice/cri-containerd-bf6444e611affcbdf61aab9e1c21cf9f730fd0695ba832c3bfc775a488698e45.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5cf93341_bb54_416c_9bc6_a228e6a97b75.slice/cri-containerd-642a7483e126f6ae2253821623e98195900fcc87f9ea9d5be8ff9c04d90b8edd.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33a56626_eed4_48ac_b138_431197a40499.slice/cri-containerd-87e2ecc75e087cd75b52d3fb678a71f74993baffef628b35a38a45371f1f2600.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod33a56626_eed4_48ac_b138_431197a40499.slice/cri-containerd-1fb7e015491ab49aad9b0007ffd2fa45f4b4ce3b75d3c3abe69276692f16a14e.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae420988_b853_4d7e_b512_0321c43f3e78.slice/cri-containerd-57827359c3b4a02b3651b27cae316d4599566ac807ba75e596e2068ed19670c4.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podae420988_b853_4d7e_b512_0321c43f3e78.slice/cri-containerd-62989032065ec860f2cdb22c42a8d731aab759fb1353c63b58dd9ee750bf8c0d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8fc5edcb_b49e_431b_882f_6c630299fe62.slice/cri-containerd-762e3235900056ec0cac3343d8083010456996fad20175734c2b411ffa0b825d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8fc5edcb_b49e_431b_882f_6c630299fe62.slice/cri-containerd-02231735cb1d124f9bc39e13dedf388c245a779bb0b04920ba53b1f24cb0ad5e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-9da847ae7f82c6fe9d1ff33116deb44d2f3fb3359bf1c1cf8ae29e4a0a89429b.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-6a87c7350bcef9eb48b05c400ba1ac76232167c53d4a3b618a2c57321bfb7a1e.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-555ba3dbe4180f16d5c3b613f827ab0ad1708c5cff5dd64f0403916d486154aa.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ea62269_325d_4ed1_9fad_b4c2f61096be.slice/cri-containerd-d088c870ae94149e86cd0bc7a17bc4826542f4a518d8d71cb435066240076238.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2bdb59a3_e935_48bc_8750_e49c2a751b6a.slice/cri-containerd-d077eefb704289821c51ae88f4972c2937f38f2756cb374992a432f9b823978b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2bdb59a3_e935_48bc_8750_e49c2a751b6a.slice/cri-containerd-85b1d36896071217db05cf6630618fce862da351b39c4696f66a9df378e5f82d.scope
    105      cgroup_device   multi                                          
