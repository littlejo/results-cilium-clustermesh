Endpoint ID: 390
Path: /sys/fs/bpf/tc/globals/cilium_policy_00390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    155561   1782      0        
Allow    Egress      0          ANY          NONE         disabled    19923    220       0        


Endpoint ID: 404
Path: /sys/fs/bpf/tc/globals/cilium_policy_00404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 467
Path: /sys/fs/bpf/tc/globals/cilium_policy_00467

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1668623   21144     0        
Allow    Ingress     1          ANY          NONE         disabled    24596     291       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 763
Path: /sys/fs/bpf/tc/globals/cilium_policy_00763

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    157087   1805      0        
Allow    Egress      0          ANY          NONE         disabled    20134    223       0        


Endpoint ID: 774
Path: /sys/fs/bpf/tc/globals/cilium_policy_00774

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11525319   116303    0        
Allow    Ingress     1          ANY          NONE         disabled    10863493   114889    0        
Allow    Egress      0          ANY          NONE         disabled    15277121   149119    0        


