IP ADDRESS         LOCAL ENDPOINT INFO
10.73.0.252:0      id=390   sec_id=2443311 flags=0x0000 ifindex=12  mac=1E:B6:04:75:40:B8 nodemac=F2:8E:74:C5:1F:D5   
172.31.193.140:0   (localhost)                                                                                        
172.31.227.222:0   (localhost)                                                                                        
10.73.0.34:0       id=467   sec_id=4     flags=0x0000 ifindex=10  mac=4A:7C:73:BA:F3:1B nodemac=C6:7C:F9:3E:1A:37     
10.73.0.86:0       id=774   sec_id=2430387 flags=0x0000 ifindex=18  mac=F2:A7:E4:B6:BE:74 nodemac=9A:64:CD:D7:A5:42   
10.73.0.190:0      id=763   sec_id=2443311 flags=0x0000 ifindex=14  mac=EA:FD:F1:B7:46:47 nodemac=5E:FC:C7:2F:0D:CC   
10.73.0.198:0      (localhost)                                                                                        
