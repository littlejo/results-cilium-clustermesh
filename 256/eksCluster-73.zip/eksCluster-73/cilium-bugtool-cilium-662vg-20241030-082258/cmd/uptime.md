 08:22:59 up 34 min,  0 users,  load average: 0.30, 0.24, 0.19
