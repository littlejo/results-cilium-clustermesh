KEY             VALUE
AgentLiveness   2122867557956
UTimeOffset     3379442359375000
