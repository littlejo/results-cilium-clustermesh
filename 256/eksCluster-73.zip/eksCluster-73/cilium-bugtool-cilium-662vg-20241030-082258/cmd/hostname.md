ip-172-31-193-140.eu-west-3.compute.internal
