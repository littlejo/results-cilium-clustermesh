REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38143     3019657     677    bpf_overlay.c
Interface                 INGRESS     672823    136657046   1132   bpf_host.c
Success                   EGRESS      17670     1396477     1694   bpf_host.c
Success                   EGRESS      291455    35710913    1308   bpf_lxc.c
Success                   EGRESS      39083     3091738     53     encap.h
Success                   INGRESS     332377    37861987    86     l3.h
Success                   INGRESS     353501    39529213    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
