ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.154.149:443 (active)    
                                        2 => 172.31.203.200:443 (active)    
2    10.100.82.196:443   ClusterIP      1 => 172.31.193.140:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.73.0.252:53 (active)        
                                        2 => 10.73.0.190:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.73.0.252:9153 (active)      
                                        2 => 10.73.0.190:9153 (active)      
5    10.100.63.19:2379   ClusterIP      1 => 10.73.0.86:2379 (active)       
