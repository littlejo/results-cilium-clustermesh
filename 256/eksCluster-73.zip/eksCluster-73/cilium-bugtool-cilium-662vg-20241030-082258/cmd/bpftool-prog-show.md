35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:10+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:11+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:15+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:28+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:56:04+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
485: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:56:04+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
486: sched_cls  name tail_handle_ipv4  tag 6da7b7e7feb86be2  gpl
	loaded_at 2024-10-30T07:56:04+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
487: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:56:04+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
510: sched_cls  name tail_handle_ipv4_cont  tag 8f867a9beb620147  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 153
512: sched_cls  name tail_ipv4_to_endpoint  tag d9f64eaa44ea86c4  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 155
513: sched_cls  name handle_policy  tag 141669814f6839f1  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 156
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
515: sched_cls  name tail_handle_ipv4  tag 24e120bcd7dae007  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 158
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
517: sched_cls  name tail_handle_arp  tag 4c71ac1eb9ee0d0d  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 160
518: sched_cls  name cil_from_container  tag aef2e583132f3606  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 161
519: sched_cls  name __send_drop_notify  tag 7dc67855dc8d9df1  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
520: sched_cls  name tail_ipv4_ct_ingress  tag e1a91d323ec66d31  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 163
521: sched_cls  name tail_ipv4_to_endpoint  tag fa9d9b1e9843e170  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 165
522: sched_cls  name tail_handle_ipv4  tag 6849d5c6be2034e3  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 166
523: sched_cls  name handle_policy  tag 4a4004ba171a981b  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 167
524: sched_cls  name tail_handle_arp  tag 9c2fa5b9bddd6193  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 168
525: sched_cls  name tail_handle_ipv4_cont  tag ef1d8935bda675d3  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 169
526: sched_cls  name tail_ipv4_ct_egress  tag 422c35e01bacb0a1  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 170
527: sched_cls  name cil_from_container  tag 2e7d61cdc41a6f9c  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 171
528: sched_cls  name tail_ipv4_ct_ingress  tag bd634b248305fcfc  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 172
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 173
531: sched_cls  name __send_drop_notify  tag 89d7bd28022b882b  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 175
532: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
535: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
536: sched_cls  name tail_ipv4_ct_egress  tag 422c35e01bacb0a1  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 177
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: sched_cls  name tail_ipv4_ct_ingress  tag a66813b10baa3379  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 178
542: sched_cls  name tail_ipv4_to_endpoint  tag bed5c359a44b1597  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,111,40,37,38
	btf_id 179
543: sched_cls  name cil_from_container  tag 9c7bc73c21fb824e  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 180
544: sched_cls  name handle_policy  tag 082dfc38f2de486d  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 181
546: sched_cls  name tail_handle_ipv4_cont  tag 05a9a0b9770f0715  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,111,40,37,38,81
	btf_id 183
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 184
548: sched_cls  name tail_handle_ipv4  tag 8a18b1e6fc006482  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 185
549: sched_cls  name __send_drop_notify  tag 1937dd3a37004082  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
550: sched_cls  name tail_handle_arp  tag 1b5c11e309b10232  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 190
562: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 192
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
564: sched_cls  name tail_handle_ipv4_from_host  tag 5bf350d46621cf00  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
565: sched_cls  name __send_drop_notify  tag ae412cb14d15b0b9  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
567: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
568: sched_cls  name tail_handle_ipv4_from_host  tag 5bf350d46621cf00  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 199
569: sched_cls  name __send_drop_notify  tag ae412cb14d15b0b9  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 202
574: sched_cls  name tail_handle_ipv4_from_host  tag 5bf350d46621cf00  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
575: sched_cls  name __send_drop_notify  tag ae412cb14d15b0b9  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
576: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 208
577: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 209
580: sched_cls  name __send_drop_notify  tag ae412cb14d15b0b9  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
581: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 214
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 215
586: sched_cls  name tail_handle_ipv4_from_host  tag 5bf350d46621cf00  gpl
	loaded_at 2024-10-30T07:56:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 219
626: sched_cls  name cil_from_container  tag f482a41e7d54a1dc  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 233
627: sched_cls  name __send_drop_notify  tag eafa9001a68f4a15  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 234
629: sched_cls  name tail_ipv4_to_endpoint  tag 81b0247afcc0bb07  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 236
630: sched_cls  name tail_ipv4_ct_ingress  tag cd5c05e05c73297d  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 237
631: sched_cls  name tail_ipv4_ct_egress  tag 4fd061f360ec29dd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 238
632: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 239
633: sched_cls  name tail_handle_arp  tag effa0f7ae6609194  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 240
634: sched_cls  name tail_handle_ipv4_cont  tag d436cba6d1c91196  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 241
635: sched_cls  name handle_policy  tag 5387fdc080051bbd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 242
636: sched_cls  name tail_handle_ipv4  tag f1afdefecc0e3f69  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
