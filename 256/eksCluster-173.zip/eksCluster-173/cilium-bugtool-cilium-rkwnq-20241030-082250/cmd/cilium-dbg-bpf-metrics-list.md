REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36658     2903194     677    bpf_overlay.c
Interface                 INGRESS     650040    132118759   1132   bpf_host.c
Success                   EGRESS      16453     1295910     1694   bpf_host.c
Success                   EGRESS      272730    34139489    1308   bpf_lxc.c
Success                   EGRESS      36936     2921792     53     encap.h
Success                   INGRESS     316899    35621727    86     l3.h
Success                   INGRESS     337755    37273057    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
