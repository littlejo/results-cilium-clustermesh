KEY             VALUE
AgentLiveness   1902556185216
UTimeOffset     3379442773437500
