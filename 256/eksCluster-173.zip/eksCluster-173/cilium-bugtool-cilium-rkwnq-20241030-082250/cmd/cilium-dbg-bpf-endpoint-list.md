IP ADDRESS         LOCAL ENDPOINT INFO
172.31.219.254:0   (localhost)                                                                                        
10.173.0.178:0     id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B   
172.31.231.64:0    (localhost)                                                                                        
10.173.0.108:0     id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C   
10.173.0.184:0     id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74   
10.173.0.164:0     (localhost)                                                                                        
10.173.0.151:0     id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01     
