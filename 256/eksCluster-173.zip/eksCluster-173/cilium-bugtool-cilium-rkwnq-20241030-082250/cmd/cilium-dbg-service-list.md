ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.178.41:443 (active)    
                                          2 => 172.31.195.65:443 (active)    
2    10.100.65.43:443      ClusterIP      1 => 172.31.231.64:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.173.0.108:53 (active)      
                                          2 => 10.173.0.178:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.173.0.108:9153 (active)    
                                          2 => 10.173.0.178:9153 (active)    
5    10.100.115.224:2379   ClusterIP      1 => 10.173.0.184:2379 (active)    
