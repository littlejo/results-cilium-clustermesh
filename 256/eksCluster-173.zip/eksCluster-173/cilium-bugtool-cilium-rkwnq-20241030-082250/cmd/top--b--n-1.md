top - 08:22:51 up 31 min,  0 users,  load average: 0.48, 0.27, 0.20
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 65.5 us, 13.8 sy,  0.0 ni, 20.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4481.7 free,   1185.6 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383888  78976 S  93.3   4.8   0:48.97 cilium-+
    646 root      20   0 1240176  16404  11356 S   6.7   0.2   0:00.03 cilium-+
    414 root      20   0 1229744   8136   3900 S   0.0   0.1   0:01.14 cilium-+
    647 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    663 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    676 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    697 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    712 root      20   0 1243508  17652  12932 S   0.0   0.2   0:00.01 hubble
    720 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    738 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
