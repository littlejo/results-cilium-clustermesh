{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:56.996Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.219.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:56.996Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:56.996Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.519Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.523Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.600Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.663Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:01.730Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:00.235Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:00.235Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:00.236Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:00.266Z",
  "value": "id=1284  sec_id=5710543 flags=0x0000 ifindex=16  mac=26:6A:46:A3:2E:30 nodemac=56:5B:EE:2A:8F:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:01.236Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:01.236Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:01.236Z",
  "value": "id=1284  sec_id=5710543 flags=0x0000 ifindex=16  mac=26:6A:46:A3:2E:30 nodemac=56:5B:EE:2A:8F:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:01.236Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.708Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.173.0.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.988Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.336Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.337Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.338Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.338Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.320Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.320Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.321Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.322Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.319Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.319Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.320Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.320Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.320Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.320Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.320Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.321Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.320Z",
  "value": "id=4056  sec_id=4     flags=0x0000 ifindex=10  mac=F2:E3:EC:BD:C7:D2 nodemac=FA:B3:A0:E9:76:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.320Z",
  "value": "id=2003  sec_id=5710543 flags=0x0000 ifindex=18  mac=C6:DC:CD:F3:D4:E7 nodemac=F2:D2:A0:80:CF:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.320Z",
  "value": "id=2520  sec_id=5712305 flags=0x0000 ifindex=14  mac=EE:D7:62:6C:AD:A0 nodemac=6E:65:18:2D:9B:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.173.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.320Z",
  "value": "id=2562  sec_id=5712305 flags=0x0000 ifindex=12  mac=FE:9B:B9:E1:C6:F2 nodemac=F2:E8:B7:87:07:6C"
}

