1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9d:ab:82:5b:69 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.231.64/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3540sec preferred_lft 3540sec
    inet6 fe80::89d:abff:fe82:5b69/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1f:67:12:50:1f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.219.254/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81f:67ff:fe12:501f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:74:c3:90:da:ae brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6074:c3ff:fe90:daae/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:ae:cb:5a:f5:fb brd ff:ff:ff:ff:ff:ff
    inet 10.173.0.164/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::34ae:cbff:fe5a:f5fb/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ae:38:a8:13:aa:a5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac38:a8ff:fe13:aaa5/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:b3:a0:e9:76:01 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8b3:a0ff:fee9:7601/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc52cafd31856c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:e8:b7:87:07:6c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f0e8:b7ff:fe87:76c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8f91b8067932@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:65:18:2d:9b:1b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::6c65:18ff:fe2d:9b1b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc948f2618e61e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:d2:a0:80:cf:74 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f0d2:a0ff:fe80:cf74/64 scope link 
       valid_lft forever preferred_lft forever
