Endpoint ID: 2003
Path: /sys/fs/bpf/tc/globals/cilium_policy_02003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11546200   115028    0        
Allow    Ingress     1          ANY          NONE         disabled    10320598   108877    0        
Allow    Egress      0          ANY          NONE         disabled    12791258   126106    0        


Endpoint ID: 2450
Path: /sys/fs/bpf/tc/globals/cilium_policy_02450

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2520
Path: /sys/fs/bpf/tc/globals/cilium_policy_02520

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121942   1397      0        
Allow    Egress      0          ANY          NONE         disabled    17822    194       0        


Endpoint ID: 2562
Path: /sys/fs/bpf/tc/globals/cilium_policy_02562

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122668   1408      0        
Allow    Egress      0          ANY          NONE         disabled    17293    188       0        


Endpoint ID: 4056
Path: /sys/fs/bpf/tc/globals/cilium_policy_04056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655652   20909     0        
Allow    Ingress     1          ANY          NONE         disabled    19358     228       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


