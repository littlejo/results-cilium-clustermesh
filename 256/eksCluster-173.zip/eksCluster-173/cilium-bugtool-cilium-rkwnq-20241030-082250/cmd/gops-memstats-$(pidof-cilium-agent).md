alloc: 152.21MB (159601848 bytes)
total-alloc: 2.27GB (2432842344 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63737915
frees: 62165579
heap-alloc: 152.21MB (159601848 bytes)
heap-sys: 243.70MB (255541248 bytes)
heap-idle: 58.88MB (61734912 bytes)
heap-in-use: 184.83MB (193806336 bytes)
heap-released: 728.00KB (745472 bytes)
heap-objects: 1572336
stack-in-use: 64.25MB (67371008 bytes)
stack-sys: 64.25MB (67371008 bytes)
stack-mspan-inuse: 3.11MB (3265600 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1015.16KB (1039521 bytes)
gc-sys: 6.00MB (6294920 bytes)
next-gc: when heap-alloc >= 215.77MB (226253320 bytes)
last-gc: 2024-10-30 08:22:59.974665768 +0000 UTC
gc-pause-total: 13.506642ms
gc-pause: 119969
gc-pause-end: 1730276579974665768
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.000440264812901505
enable-gc: true
debug-gc: false
