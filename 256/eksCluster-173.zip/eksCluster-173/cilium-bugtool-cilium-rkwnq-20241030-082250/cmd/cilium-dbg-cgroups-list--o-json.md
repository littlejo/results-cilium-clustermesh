[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod743ae513_612c_4806_8923_651429d88fb8.slice/cri-containerd-07f6eec3352b90008adf87ae685f9338a04228920b347c25945c8062b164c1b4.scope"
      }
    ],
    "ips": [
      "10.173.0.178"
    ],
    "name": "coredns-cc6ccd49c-d88wc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f426a1a_5525_444f_af97_0b4a26ca3850.slice/cri-containerd-88458692b6175c8738643aff6829a32f4bfdbd4bad15beefea4445f1a6e41da3.scope"
      }
    ],
    "ips": [
      "10.173.0.108"
    ],
    "name": "coredns-cc6ccd49c-v2pdj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-0b98c9a13a848439f0fb4d880c85d05c5e361aa8faf471c0648d1ceb3d3d5468.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-50264f13431dddda0922bad73ecebebd2275a4920d9ee0879471b1f7b2a492fe.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-a9a45ef7b48967a1d6a9e001519783f700b59a4978aaf60f25a2711cc842a77c.scope"
      }
    ],
    "ips": [
      "10.173.0.184"
    ],
    "name": "clustermesh-apiserver-74d454cffd-6bn2x",
    "namespace": "kube-system"
  }
]

