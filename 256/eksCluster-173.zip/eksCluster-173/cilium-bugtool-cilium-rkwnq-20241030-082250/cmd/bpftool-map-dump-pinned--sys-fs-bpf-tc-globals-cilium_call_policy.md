key: d3 07 00 00  value: 71 02 00 00
key: d8 09 00 00  value: fd 01 00 00
key: 02 0a 00 00  value: 0e 02 00 00
key: d8 0f 00 00  value: 21 02 00 00
Found 4 elements
