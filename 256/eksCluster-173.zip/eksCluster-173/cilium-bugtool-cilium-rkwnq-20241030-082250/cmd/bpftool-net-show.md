xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 575
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 546
lxc52cafd31856c(12) clsact/ingress cil_from_container-lxc52cafd31856c id 524
lxc8f91b8067932(14) clsact/ingress cil_from_container-lxc8f91b8067932 id 517
lxc948f2618e61e(18) clsact/ingress cil_from_container-lxc948f2618e61e id 633

flow_dissector:

netfilter:

