CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74caa752_6094_45aa_9416_622417514d9d.slice/cri-containerd-294a89c9554dd748a6241ffd86dec0d4c0cbe429abd1255da4c588f8beb33079.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod74caa752_6094_45aa_9416_622417514d9d.slice/cri-containerd-d1e1e6c37cad10fd4fad7c461c2f4b0503ca3e0b6f7ac28714a43d0355cb8fdb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd928b55_f891_4456_9a7a_9198e2830e6d.slice/cri-containerd-d103255f6cde997f009d5b955d79f88d3dfe031ab760c60ebb6403dee3d0f46b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddd928b55_f891_4456_9a7a_9198e2830e6d.slice/cri-containerd-20496629de3965f80defa7f0e20cdf6a5ca816936c06659499f7247b2245f9c2.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f426a1a_5525_444f_af97_0b4a26ca3850.slice/cri-containerd-88458692b6175c8738643aff6829a32f4bfdbd4bad15beefea4445f1a6e41da3.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f426a1a_5525_444f_af97_0b4a26ca3850.slice/cri-containerd-8e597a80b354e7e1d42db9ef2db546c76444f614427c47864bd29d6d4af76d5e.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod743ae513_612c_4806_8923_651429d88fb8.slice/cri-containerd-07f6eec3352b90008adf87ae685f9338a04228920b347c25945c8062b164c1b4.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod743ae513_612c_4806_8923_651429d88fb8.slice/cri-containerd-3fe6915c2ca55038b78b47f9cbab010c3857a6f93f5d26891fb3af17f6d39a30.scope
    543      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-a9a45ef7b48967a1d6a9e001519783f700b59a4978aaf60f25a2711cc842a77c.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-d8d362a646b212b36796f8ff21c51999221d3ab5d0bfd20b2c416bd3f3312bec.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-50264f13431dddda0922bad73ecebebd2275a4920d9ee0879471b1f7b2a492fe.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod618ef3f2_6f84_4736_bce1_812852e45f2a.slice/cri-containerd-0b98c9a13a848439f0fb4d880c85d05c5e361aa8faf471c0648d1ceb3d3d5468.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29a701c9_43aa_4e6f_91c8_cca2435710cb.slice/cri-containerd-48a5e0570e2c5bf8f07582a93408062728d2d2ab0a608701deacc7da09798ef2.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29a701c9_43aa_4e6f_91c8_cca2435710cb.slice/cri-containerd-6bd2a287fbc400a499fac30a903c247a6e99c01423ea59384a78ed33b55034a7.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff6931e1_d3fd_4248_818b_ad925d31d299.slice/cri-containerd-254dddf2200b901c0e9c7419ea172bcd0fdd01fc7e9d7c7b92ad0022cf84cb69.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff6931e1_d3fd_4248_818b_ad925d31d299.slice/cri-containerd-e8d26d9880f515544c398e4436501ed6ad38ca3d0e0be8ec7ae7b6f5e307c54e.scope
    94       cgroup_device   multi                                          
