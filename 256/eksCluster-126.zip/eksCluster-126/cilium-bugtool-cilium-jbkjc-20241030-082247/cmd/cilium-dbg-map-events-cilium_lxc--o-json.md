{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:33.365Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.139.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:33.365Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:33.365Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.038Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.038Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.133Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.192Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.324Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.021Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.021Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.021Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.055Z",
  "value": "id=851   sec_id=4170797 flags=0x0000 ifindex=16  mac=1E:D9:73:65:E3:B7 nodemac=2E:5D:C4:C4:95:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.020Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.021Z",
  "value": "id=851   sec_id=4170797 flags=0x0000 ifindex=16  mac=1E:D9:73:65:E3:B7 nodemac=2E:5D:C4:C4:95:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.021Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:27.021Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:20.425Z",
  "value": "id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.126.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.821Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.889Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.890Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.890Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.890Z",
  "value": "id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.886Z",
  "value": "id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.887Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.887Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.888Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.887Z",
  "value": "id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.888Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.888Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.888Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.889Z",
  "value": "id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.889Z",
  "value": "id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.889Z",
  "value": "id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.126.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.889Z",
  "value": "id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55"
}

