[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-40aeb86e303407229d8bcfb2665541d628d9f4ff7cb2e5b6b4923de7d77a68ff.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-1614830f3b695f5b5065e8ff5da50a30c37fa898b8e59f0bde322c08f54677e6.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-648863d41e338c86bd70117d6749670380ac06e980ab59f62d92deb0995e7222.scope"
      }
    ],
    "ips": [
      "10.126.0.206"
    ],
    "name": "clustermesh-apiserver-75674c8f8b-lp24d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc710dbfc_c449_490a_b231_4f750b0ad5ce.slice/cri-containerd-b66d25cde203962586493745a2dca048b2c95d90dd7b731116dee4b78998a22c.scope"
      }
    ],
    "ips": [
      "10.126.0.93"
    ],
    "name": "coredns-cc6ccd49c-gd8zf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod026c6ae6_9e33_405f_9452_dccb17075448.slice/cri-containerd-df40c29fa6f0056566e7210ead651856f9658e6a4ed7299c6c03d9d02bcffb1c.scope"
      }
    ],
    "ips": [
      "10.126.0.119"
    ],
    "name": "coredns-cc6ccd49c-mrm9m",
    "namespace": "kube-system"
  }
]

