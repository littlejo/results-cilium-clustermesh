markdown output at /tmp/cilium-bugtool-20241030-082249.093+0000-UTC-3278090094/cmd/cilium-debuginfo-20241030-082320.22+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.093+0000-UTC-3278090094/cmd/cilium-debuginfo-20241030-082320.22+0000-UTC.json
