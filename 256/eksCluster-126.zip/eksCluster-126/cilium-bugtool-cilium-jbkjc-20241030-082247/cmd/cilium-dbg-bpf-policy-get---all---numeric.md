Endpoint ID: 3
Path: /sys/fs/bpf/tc/globals/cilium_policy_00003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1639312   20684     0        
Allow    Ingress     1          ANY          NONE         disabled    22592     265       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 634
Path: /sys/fs/bpf/tc/globals/cilium_policy_00634

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11543076   115701    0        
Allow    Ingress     1          ANY          NONE         disabled    10271597   108235    0        
Allow    Egress      0          ANY          NONE         disabled    13881547   136091    0        


Endpoint ID: 963
Path: /sys/fs/bpf/tc/globals/cilium_policy_00963

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3031
Path: /sys/fs/bpf/tc/globals/cilium_policy_03031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147244   1687      0        
Allow    Egress      0          ANY          NONE         disabled    19958    220       0        


Endpoint ID: 3084
Path: /sys/fs/bpf/tc/globals/cilium_policy_03084

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147337   1693      0        
Allow    Egress      0          ANY          NONE         disabled    19736    218       0        


