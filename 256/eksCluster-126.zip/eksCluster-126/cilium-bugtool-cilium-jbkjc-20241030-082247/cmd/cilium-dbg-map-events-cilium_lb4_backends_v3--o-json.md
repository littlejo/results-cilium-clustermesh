{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.063Z",
  "value": "ANY://172.31.184.122"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.063Z",
  "value": "ANY://172.31.225.197"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.063Z",
  "value": "ANY://172.31.168.238"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.063Z",
  "value": "ANY://172.31.168.238"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:33.983Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:33.983Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:34.164Z",
  "value": "ANY://172.31.190.244"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.659Z",
  "value": "ANY://10.126.0.93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.659Z",
  "value": "ANY://10.126.0.93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.683Z",
  "value": "ANY://10.126.0.119"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.683Z",
  "value": "ANY://10.126.0.119"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:33.242Z",
  "value": "ANY://10.126.0.42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.340Z",
  "value": "ANY://10.126.0.206"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.401Z",
  "value": "ANY://10.126.0.42"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.916Z",
  "value": "\u003cnil\u003e"
}

