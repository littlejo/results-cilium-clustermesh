IP ADDRESS         LOCAL ENDPOINT INFO
10.126.0.119:0     id=3031  sec_id=4162169 flags=0x0000 ifindex=14  mac=BE:B3:B9:5A:52:E3 nodemac=CE:DE:7B:AB:C2:CA   
172.31.190.244:0   (localhost)                                                                                        
172.31.139.126:0   (localhost)                                                                                        
10.126.0.84:0      (localhost)                                                                                        
10.126.0.206:0     id=634   sec_id=4170797 flags=0x0000 ifindex=18  mac=AE:9A:07:69:0D:32 nodemac=26:AE:A1:16:4F:55   
10.126.0.93:0      id=3084  sec_id=4162169 flags=0x0000 ifindex=12  mac=26:36:92:28:74:D3 nodemac=3A:3F:57:94:F7:40   
10.126.0.244:0     id=3     sec_id=4     flags=0x0000 ifindex=10  mac=D2:0D:19:19:BA:D7 nodemac=A2:23:73:FC:DC:96     
