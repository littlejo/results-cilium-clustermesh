alloc: 113.63MB (119153872 bytes)
total-alloc: 2.31GB (2484153384 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64251754
frees: 63561059
heap-alloc: 113.63MB (119153872 bytes)
heap-sys: 256.07MB (268509184 bytes)
heap-idle: 78.77MB (82599936 bytes)
heap-in-use: 177.30MB (185909248 bytes)
heap-released: 7.50MB (7864320 bytes)
heap-objects: 690695
stack-in-use: 59.91MB (62816256 bytes)
stack-sys: 59.91MB (62816256 bytes)
stack-mspan-inuse: 2.80MB (2933920 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1281169 bytes)
gc-sys: 6.02MB (6309448 bytes)
next-gc: when heap-alloc >= 219.05MB (229694888 bytes)
last-gc: 2024-10-30 08:23:19.430060789 +0000 UTC
gc-pause-total: 19.114914ms
gc-pause: 86392
gc-pause-end: 1730276599430060789
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004356592545659645
enable-gc: true
debug-gc: false
