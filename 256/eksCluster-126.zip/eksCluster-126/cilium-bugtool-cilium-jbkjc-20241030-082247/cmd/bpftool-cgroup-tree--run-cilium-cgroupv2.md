CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc710dbfc_c449_490a_b231_4f750b0ad5ce.slice/cri-containerd-b66d25cde203962586493745a2dca048b2c95d90dd7b731116dee4b78998a22c.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc710dbfc_c449_490a_b231_4f750b0ad5ce.slice/cri-containerd-64cf803f216db0eff05d4f7c24ae868c9ef2f36a823b7075711e799d2272347e.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd2ef4aed_0fda_44db_85b7_cb27eda9603a.slice/cri-containerd-26e856929317c3908241077db56947a9617697105a8d653b99ddb1bed812e752.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd2ef4aed_0fda_44db_85b7_cb27eda9603a.slice/cri-containerd-4592c898fc65a3cb992e2191dc71964e2f3f5d6a1d9703956065ee698152263f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53863610_6be5_461a_a8cf_908a4792f3e3.slice/cri-containerd-f5f84498fc39d1ae360182a25535a32adf816f5ec11b4fbfe91b5219633d8162.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53863610_6be5_461a_a8cf_908a4792f3e3.slice/cri-containerd-e15be50943534f74e6d3d43c098dbe01e20cc4618efff961939daf03e6eca1fc.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod026c6ae6_9e33_405f_9452_dccb17075448.slice/cri-containerd-df40c29fa6f0056566e7210ead651856f9658e6a4ed7299c6c03d9d02bcffb1c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod026c6ae6_9e33_405f_9452_dccb17075448.slice/cri-containerd-110acbd132b84f64268368a7add454d6e6fee049d3f724341a5e46756cddf0ad.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14c3856f_e6bf_4132_b19a_5e84adfa9c92.slice/cri-containerd-5c5b785398d17a9e5ce8a67f736b79aa5183d5e2b063971dde054b7317708d14.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod14c3856f_e6bf_4132_b19a_5e84adfa9c92.slice/cri-containerd-9f90b85a8e3b50576de4e9a1684c6a0d81b2b518d3b2beb71d193e045e5f979d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-40aeb86e303407229d8bcfb2665541d628d9f4ff7cb2e5b6b4923de7d77a68ff.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-3a70ad5d7d81484370d8d3d1fce21044eb7e7712299863f901b60bc19a4c8073.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-648863d41e338c86bd70117d6749670380ac06e980ab59f62d92deb0995e7222.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod61cd0087_ba88_4dd8_bc0d_d126cafef608.slice/cri-containerd-1614830f3b695f5b5065e8ff5da50a30c37fa898b8e59f0bde322c08f54677e6.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod632b1819_e778_4cbe_a82a_1fc59a9515e6.slice/cri-containerd-3076814f1162c68f54a856603da5dd8051e65c13ec5a7f9ab1815883d5d5a4da.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod632b1819_e778_4cbe_a82a_1fc59a9515e6.slice/cri-containerd-223720295f3321c97a4e6b716f0663260bd3141db095ef20db616702f749f715.scope
    99       cgroup_device   multi                                          
