REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36521     2893460     677    bpf_overlay.c
Interface                 INGRESS     652301    133523976   1132   bpf_host.c
Success                   EGRESS      16534     1301848     1694   bpf_host.c
Success                   EGRESS      278262    34613854    1308   bpf_lxc.c
Success                   EGRESS      36906     2918889     53     encap.h
Success                   INGRESS     320086    36270760    86     l3.h
Success                   INGRESS     340724    37906418    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
