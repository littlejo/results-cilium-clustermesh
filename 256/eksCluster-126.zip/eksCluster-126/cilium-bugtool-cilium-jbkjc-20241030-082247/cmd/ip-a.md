1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f9:94:af:75:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.244/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3388sec preferred_lft 3388sec
    inet6 fe80::4f9:94ff:feaf:7515/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:06:ea:c1:30:7d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.139.126/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::406:eaff:fec1:307d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:d5:05:2f:00:5d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4d5:5ff:fe2f:5d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:8f:dd:27:61:52 brd ff:ff:ff:ff:ff:ff
    inet 10.126.0.84/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d08f:ddff:fe27:6152/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether e6:c6:60:d0:68:0b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e4c6:60ff:fed0:680b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:23:73:fc:dc:96 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a023:73ff:fefc:dc96/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3850a948349b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:3f:57:94:f7:40 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::383f:57ff:fe94:f740/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc899103d37c15@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:de:7b:ab:c2:ca brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ccde:7bff:feab:c2ca/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce686bfd031d0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:ae:a1:16:4f:55 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::24ae:a1ff:fe16:4f55/64 scope link 
       valid_lft forever preferred_lft forever
