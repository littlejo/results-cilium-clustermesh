key: 03 00 00 00  value: fa 01 00 00
key: 7a 02 00 00  value: 6e 02 00 00
key: d7 0b 00 00  value: 15 02 00 00
key: 0c 0c 00 00  value: 1d 02 00 00
Found 4 elements
