xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 569
ens6(5) clsact/ingress cil_from_netdev-ens6 id 575
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 562
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 510
lxc3850a948349b(12) clsact/ingress cil_from_container-lxc3850a948349b id 538
lxc899103d37c15(14) clsact/ingress cil_from_container-lxc899103d37c15 id 519
lxce686bfd031d0(18) clsact/ingress cil_from_container-lxce686bfd031d0 id 630

flow_dissector:

netfilter:

