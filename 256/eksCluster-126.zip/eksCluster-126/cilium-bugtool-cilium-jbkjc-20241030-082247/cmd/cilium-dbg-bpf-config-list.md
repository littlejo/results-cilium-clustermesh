KEY             VALUE
AgentLiveness   2051939009907
UTimeOffset     3379442476562500
