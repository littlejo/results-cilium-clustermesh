{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:22.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.151.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:22.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.162.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:22.701Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:27.358Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:27.371Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:27.426Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:27.475Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:27.545Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.203Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.204Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.204Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.233Z",
  "value": "id=663   sec_id=1375997 flags=0x0000 ifindex=16  mac=96:42:D0:AB:BF:DD nodemac=7A:B8:DE:FC:FE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:39.235Z",
  "value": "id=663   sec_id=1375997 flags=0x0000 ifindex=16  mac=96:42:D0:AB:BF:DD nodemac=7A:B8:DE:FC:FE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:40.204Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:40.204Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:40.204Z",
  "value": "id=663   sec_id=1375997 flags=0x0000 ifindex=16  mac=96:42:D0:AB:BF:DD nodemac=7A:B8:DE:FC:FE:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:40.204Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.049Z",
  "value": "id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.40.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.415Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.478Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.479Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.481Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.481Z",
  "value": "id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.451Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.451Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.452Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.452Z",
  "value": "id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.422Z",
  "value": "id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.422Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.422Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.423Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.422Z",
  "value": "id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.423Z",
  "value": "id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.423Z",
  "value": "id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.40.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.424Z",
  "value": "id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37"
}

