IP ADDRESS         LOCAL ENDPOINT INFO
10.40.0.94:0       id=3306  sec_id=1355265 flags=0x0000 ifindex=14  mac=4E:A2:98:0C:CF:2C nodemac=12:2E:F6:C6:D4:37   
10.40.0.207:0      id=4041  sec_id=1375997 flags=0x0000 ifindex=18  mac=F6:FF:8F:FC:78:6D nodemac=4E:83:D5:75:8B:CF   
10.40.0.125:0      id=1495  sec_id=4     flags=0x0000 ifindex=10  mac=5A:5B:69:B0:7A:1B nodemac=A6:10:27:7C:69:0B     
10.40.0.196:0      (localhost)                                                                                        
172.31.151.223:0   (localhost)                                                                                        
172.31.162.144:0   (localhost)                                                                                        
10.40.0.146:0      id=1777  sec_id=1355265 flags=0x0000 ifindex=12  mac=A2:3C:F9:D2:5A:CC nodemac=BE:90:FD:98:C9:A6   
