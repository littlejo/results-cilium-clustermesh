REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38050     3015049     677    bpf_overlay.c
Interface                 INGRESS     666054    135075543   1132   bpf_host.c
Success                   EGRESS      17647     1393575     1694   bpf_host.c
Success                   EGRESS      282129    34910421    1308   bpf_lxc.c
Success                   EGRESS      38917     3080485     53     encap.h
Success                   INGRESS     325491    36744556    86     l3.h
Success                   INGRESS     346418    38400678    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
