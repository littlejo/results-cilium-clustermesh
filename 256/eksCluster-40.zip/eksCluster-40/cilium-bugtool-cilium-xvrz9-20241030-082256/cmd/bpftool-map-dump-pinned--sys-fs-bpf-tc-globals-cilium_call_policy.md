key: d7 05 00 00  value: 17 02 00 00
key: f1 06 00 00  value: 0b 02 00 00
key: ea 0c 00 00  value: 00 02 00 00
key: c9 0f 00 00  value: 6d 02 00 00
Found 4 elements
