CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47b73655_5114_44a6_8224_b7d4cbe0556f.slice/cri-containerd-3c8ddf8d3b18e1a163953e92346301b8905f5aaa712cf3c0383c1c85e234c7b8.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47b73655_5114_44a6_8224_b7d4cbe0556f.slice/cri-containerd-2bbbedc85babe777fb5b433f1fc730a5126303ad024c3b853a63f4bfa38f426e.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb5cc547_071e_4d1a_b1ca_0def41eee6bb.slice/cri-containerd-d19fdda3048006c0fce72b9f531d36a1563438bdc31faeaed994e5cba914f772.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb5cc547_071e_4d1a_b1ca_0def41eee6bb.slice/cri-containerd-9b05a2e139e20cff3eb47ba771f1c05461c0515831b398a24114bc8875300786.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24ce029d_b4f9_490c_a7d4_79bc80ec2670.slice/cri-containerd-17289fafdc7ca6c59c9d1659c176b15957e221623020cf7d44174cae405f4f81.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24ce029d_b4f9_490c_a7d4_79bc80ec2670.slice/cri-containerd-548b07074e63974697fa163285302415125de374b68c00d1c2446301e3462036.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72260c98_3215_462b_b599_319bcb647c00.slice/cri-containerd-7fe4f4486d0edd9f7fcaf4d3d288725a3023b83bfcc28a661e1014efbe5dbdd4.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72260c98_3215_462b_b599_319bcb647c00.slice/cri-containerd-1e696879043ee128c28f375613babc1129c5c4f217ace555e27d2d9a58143c80.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20aadd0b_3f1d_474b_984f_1bb3aff00a32.slice/cri-containerd-b4b6bb0f70a9e3e125e48cce30336a774ac084c0dd2d29644aaf1cb82bdca932.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod20aadd0b_3f1d_474b_984f_1bb3aff00a32.slice/cri-containerd-86787ce3737ba12b05fe9782f5d7d566e4ab0ca63284a3b4267b38ece10c74a2.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-7659bec890cc0a261a94ca009fdf07e2b84021438ad92d09ce03da4b9c60c97c.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-6c23edf24943cc28bb9be6a3252d62738d9e548e9f2392d5cee214d5092d1bed.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-9f11b9dbf84e3762ce2921117d9e5eaaf1458ca870c4c8913babfd902c918ece.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-8f51c71448e851a9450494b50e9c11792e6bc694ce4d21f52c85ceee00770ab5.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod05ca5dd9_8cc5_4129_9c75_45b4c7c4f0da.slice/cri-containerd-21858d8d85ba10a2c7a5a16f168490aa1f3fee2425a8c73a9b579961e2763564.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod05ca5dd9_8cc5_4129_9c75_45b4c7c4f0da.slice/cri-containerd-a98e852c3227a22611392c3bc1091dbf42ef2a5fd7e20b78a779d6db38e0f6c7.scope
    95       cgroup_device   multi                                          
