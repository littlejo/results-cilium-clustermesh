ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.152.9:443 (active)      
                                        2 => 172.31.214.166:443 (active)    
2    10.100.72.14:443    ClusterIP      1 => 172.31.162.144:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.40.0.146:53 (active)        
                                        2 => 10.40.0.94:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.40.0.146:9153 (active)      
                                        2 => 10.40.0.94:9153 (active)       
5    10.100.65.66:2379   ClusterIP      1 => 10.40.0.207:2379 (active)      
