markdown output at /tmp/cilium-bugtool-20241030-082257.332+0000-UTC-3096638934/cmd/cilium-debuginfo-20241030-082328.409+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.332+0000-UTC-3096638934/cmd/cilium-debuginfo-20241030-082328.409+0000-UTC.json
