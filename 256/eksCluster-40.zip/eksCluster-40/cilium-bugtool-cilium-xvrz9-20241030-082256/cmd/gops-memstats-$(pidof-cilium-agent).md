alloc: 118.74MB (124512528 bytes)
total-alloc: 2.35GB (2523084824 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64961553
frees: 64203163
heap-alloc: 118.74MB (124512528 bytes)
heap-sys: 256.01MB (268443648 bytes)
heap-idle: 74.55MB (78168064 bytes)
heap-in-use: 181.46MB (190275584 bytes)
heap-released: 3.78MB (3964928 bytes)
heap-objects: 758390
stack-in-use: 59.97MB (62881792 bytes)
stack-sys: 59.97MB (62881792 bytes)
stack-mspan-inuse: 2.87MB (3005440 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1255089 bytes)
gc-sys: 5.99MB (6278584 bytes)
next-gc: when heap-alloc >= 214.68MB (225111800 bytes)
last-gc: 2024-10-30 08:23:26.247200064 +0000 UTC
gc-pause-total: 8.820328ms
gc-pause: 116023
gc-pause-end: 1730276606247200064
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00036293114312147256
enable-gc: true
debug-gc: false
