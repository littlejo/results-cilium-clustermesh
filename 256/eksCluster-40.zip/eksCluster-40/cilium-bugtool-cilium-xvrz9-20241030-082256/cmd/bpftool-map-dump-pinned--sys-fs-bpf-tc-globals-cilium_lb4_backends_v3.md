key: 01 00 00 00  value: ac 1f 98 09 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 28 00 cf 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 28 00 5e 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d6 a6 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f a2 90 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 28 00 92 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 28 00 92 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 28 00 5e 23 c1 00 00  00 00 00 00
Found 8 elements
