29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:47:25+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:26+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:47:30+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:47:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:47:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:47:40+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:55+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:55+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:58+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:58+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:54:25+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag 982f1c559776a3ff  gpl
	loaded_at 2024-10-30T07:54:25+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:54:25+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:54:25+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 127
502: sched_cls  name cil_from_container  tag 2ec7f3ac962f165f  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 108,76
	btf_id 152
504: sched_cls  name tail_ipv4_ct_ingress  tag 4a85a41a4443c1d6  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 154
505: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,108
	btf_id 155
508: sched_cls  name tail_ipv4_ct_egress  tag c1b771d3a9dbf425  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,108,82,83,107,84
	btf_id 156
509: sched_cls  name tail_ipv4_to_endpoint  tag 752e2b12797f7373  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,107,41,82,83,80,106,39,108,40,37,38
	btf_id 158
510: sched_cls  name tail_handle_ipv4  tag a6b224637aa55dad  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,108
	btf_id 159
511: sched_cls  name __send_drop_notify  tag adc0902695150898  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 160
512: sched_cls  name handle_policy  tag 5b57861d72a03308  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,108,82,83,107,41,80,106,39,84,75,40,37,38
	btf_id 161
513: sched_cls  name tail_handle_arp  tag cdbccc28dc3a5e4d  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,108
	btf_id 162
514: sched_cls  name tail_handle_ipv4_cont  tag 946381b9b1c1f609  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,107,41,106,82,83,39,76,74,77,108,40,37,38,81
	btf_id 163
515: sched_cls  name __send_drop_notify  tag 6cae4e8588f00621  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 165
516: sched_cls  name cil_from_container  tag ba7c76d1a9f62d23  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 166
517: sched_cls  name tail_ipv4_to_endpoint  tag 805f61504091c35d  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 167
518: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 168
519: sched_cls  name tail_ipv4_ct_egress  tag c1b771d3a9dbf425  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 169
520: sched_cls  name tail_handle_arp  tag df6fdb9f387034f1  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 170
521: sched_cls  name tail_handle_ipv4_cont  tag 61852f80b7eb3188  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 171
522: sched_cls  name tail_ipv4_ct_ingress  tag ccee75c5aba2c0e3  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 172
523: sched_cls  name handle_policy  tag 661a6f28eda4c4c5  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 173
524: sched_cls  name tail_handle_ipv4  tag a89ac3ef7c92f018  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 174
527: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 178
528: sched_cls  name cil_from_container  tag abbbedc8c758fd07  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 179
529: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 180
530: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
533: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
534: sched_cls  name tail_handle_arp  tag 8140b4e558de17e2  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 181
535: sched_cls  name handle_policy  tag 62bb18774a484cfc  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,111,41,80,101,39,84,75,40,37,38
	btf_id 182
536: sched_cls  name tail_handle_ipv4_cont  tag da487d30e8bddad4  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,111,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 183
537: sched_cls  name tail_ipv4_to_endpoint  tag e6cca53bccd9f7f7  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,111,41,82,83,80,101,39,112,40,37,38
	btf_id 184
538: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
541: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
542: sched_cls  name tail_handle_ipv4  tag db87a90cb7c75396  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 185
543: sched_cls  name tail_ipv4_ct_ingress  tag 301ae7b1e0bf3b2f  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 186
544: sched_cls  name __send_drop_notify  tag 81c201b5322a85a8  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
553: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 189
554: sched_cls  name tail_handle_ipv4_from_host  tag cd4c12d5b76a30aa  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 190
557: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
558: sched_cls  name __send_drop_notify  tag 50bd0ec944008710  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
559: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,117
	btf_id 195
560: sched_cls  name tail_handle_ipv4_from_host  tag cd4c12d5b76a30aa  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 197
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 200
564: sched_cls  name __send_drop_notify  tag 50bd0ec944008710  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 203
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 205
568: sched_cls  name tail_handle_ipv4_from_host  tag cd4c12d5b76a30aa  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
569: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 207
572: sched_cls  name __send_drop_notify  tag 50bd0ec944008710  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 214
576: sched_cls  name tail_handle_ipv4_from_host  tag cd4c12d5b76a30aa  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 215
577: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 216
580: sched_cls  name __send_drop_notify  tag 50bd0ec944008710  gpl
	loaded_at 2024-10-30T07:54:28+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
620: sched_cls  name __send_drop_notify  tag ebd37940507743a9  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 233
621: sched_cls  name handle_policy  tag 2174b6c1f373c1d1  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,137,82,83,136,41,80,135,39,84,75,40,37,38
	btf_id 234
622: sched_cls  name tail_handle_ipv4  tag 72a43b2ca7735210  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,137
	btf_id 235
624: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,137
	btf_id 237
625: sched_cls  name tail_ipv4_ct_ingress  tag 930c865e3af7d5a4  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 238
626: sched_cls  name cil_from_container  tag 01e26d31a000b097  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 137,76
	btf_id 239
627: sched_cls  name tail_ipv4_ct_egress  tag 31fa222e0354301e  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,137,82,83,136,84
	btf_id 240
628: sched_cls  name tail_handle_ipv4_cont  tag 38b9c448568adbf7  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,136,41,135,82,83,39,76,74,77,137,40,37,38,81
	btf_id 241
629: sched_cls  name tail_handle_arp  tag 714ce58aff8afe10  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,137
	btf_id 242
630: sched_cls  name tail_ipv4_to_endpoint  tag f63f19f2d8dc9da3  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,136,41,82,83,80,135,39,137,40,37,38
	btf_id 243
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
