xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 569
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 563
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 528
lxca6b98d9c62fe(12) clsact/ingress cil_from_container-lxca6b98d9c62fe id 516
lxc315f7318896f(14) clsact/ingress cil_from_container-lxc315f7318896f id 502
lxcef79fc8aec96(18) clsact/ingress cil_from_container-lxcef79fc8aec96 id 626

flow_dissector:

netfilter:

