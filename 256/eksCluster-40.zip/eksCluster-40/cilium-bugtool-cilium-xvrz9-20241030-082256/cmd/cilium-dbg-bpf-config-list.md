KEY             VALUE
AgentLiveness   2165264518333
UTimeOffset     3379442271484375
