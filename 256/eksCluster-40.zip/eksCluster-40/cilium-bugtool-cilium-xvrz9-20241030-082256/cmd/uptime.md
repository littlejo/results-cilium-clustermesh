 08:22:57 up 35 min,  0 users,  load average: 0.16, 0.28, 0.20
