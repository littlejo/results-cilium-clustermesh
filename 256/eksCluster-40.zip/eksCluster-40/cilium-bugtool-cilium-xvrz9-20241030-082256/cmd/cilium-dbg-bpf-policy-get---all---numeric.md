Endpoint ID: 1495
Path: /sys/fs/bpf/tc/globals/cilium_policy_01495

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658708   20960     0        
Allow    Ingress     1          ANY          NONE         disabled    25710     301       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1712
Path: /sys/fs/bpf/tc/globals/cilium_policy_01712

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1777
Path: /sys/fs/bpf/tc/globals/cilium_policy_01777

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165303   1894      0        
Allow    Egress      0          ANY          NONE         disabled    20837    231       0        


Endpoint ID: 3306
Path: /sys/fs/bpf/tc/globals/cilium_policy_03306

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165026   1895      0        
Allow    Egress      0          ANY          NONE         disabled    20361    227       0        


Endpoint ID: 4041
Path: /sys/fs/bpf/tc/globals/cilium_policy_04041

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11649433   116875    0        
Allow    Ingress     1          ANY          NONE         disabled    10592984   111857    0        
Allow    Egress      0          ANY          NONE         disabled    13845728   135782    0        


