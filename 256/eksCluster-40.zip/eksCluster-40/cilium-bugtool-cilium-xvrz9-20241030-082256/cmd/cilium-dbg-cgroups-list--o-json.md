[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-9f11b9dbf84e3762ce2921117d9e5eaaf1458ca870c4c8913babfd902c918ece.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-7659bec890cc0a261a94ca009fdf07e2b84021438ad92d09ce03da4b9c60c97c.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc33a8f33_242e_4d9e_83fd_6ae2b9481db1.slice/cri-containerd-8f51c71448e851a9450494b50e9c11792e6bc694ce4d21f52c85ceee00770ab5.scope"
      }
    ],
    "ips": [
      "10.40.0.207"
    ],
    "name": "clustermesh-apiserver-84f675b877-46td8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod72260c98_3215_462b_b599_319bcb647c00.slice/cri-containerd-1e696879043ee128c28f375613babc1129c5c4f217ace555e27d2d9a58143c80.scope"
      }
    ],
    "ips": [
      "10.40.0.94"
    ],
    "name": "coredns-cc6ccd49c-mmjbz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb5cc547_071e_4d1a_b1ca_0def41eee6bb.slice/cri-containerd-9b05a2e139e20cff3eb47ba771f1c05461c0515831b398a24114bc8875300786.scope"
      }
    ],
    "ips": [
      "10.40.0.146"
    ],
    "name": "coredns-cc6ccd49c-b9pdk",
    "namespace": "kube-system"
  }
]

