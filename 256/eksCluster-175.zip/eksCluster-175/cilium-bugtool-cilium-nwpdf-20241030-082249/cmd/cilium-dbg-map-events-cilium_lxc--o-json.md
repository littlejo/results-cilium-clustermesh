{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.715Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.715Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.715Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.297Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.297Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.333Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.335Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.357Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.028Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.028Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.028Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:56.060Z",
  "value": "id=1159  sec_id=5787010 flags=0x0000 ifindex=16  mac=0E:00:25:A5:4C:8F nodemac=46:8F:D4:FD:31:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.028Z",
  "value": "id=1159  sec_id=5787010 flags=0x0000 ifindex=16  mac=0E:00:25:A5:4C:8F nodemac=46:8F:D4:FD:31:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.029Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.029Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:57.029Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.884Z",
  "value": "id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.175.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.355Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.665Z",
  "value": "id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.666Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.680Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:23.680Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.768Z",
  "value": "id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.770Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.770Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:24.771Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.665Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.665Z",
  "value": "id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.665Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:25.666Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.666Z",
  "value": "id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.33:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.666Z",
  "value": "id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.666Z",
  "value": "id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.175.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:26.666Z",
  "value": "id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED"
}

