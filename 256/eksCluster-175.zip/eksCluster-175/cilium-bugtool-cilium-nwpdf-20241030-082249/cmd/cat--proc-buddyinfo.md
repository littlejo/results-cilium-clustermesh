Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal     67    105     49      3      2     10     38     19     13      6    858 
