IP ADDRESS         LOCAL ENDPOINT INFO
10.175.0.155:0     id=2323  sec_id=5793914 flags=0x0000 ifindex=12  mac=A6:78:4E:53:69:5F nodemac=D6:39:E9:F3:2B:D1   
10.175.0.33:0      id=816   sec_id=5787010 flags=0x0000 ifindex=18  mac=E2:00:6B:9E:5C:95 nodemac=F6:32:65:52:66:D3   
172.31.192.97:0    (localhost)                                                                                        
10.175.0.28:0      id=1062  sec_id=4     flags=0x0000 ifindex=10  mac=E6:5F:CD:A3:93:2C nodemac=2A:F2:D5:49:B6:ED     
10.175.0.182:0     id=186   sec_id=5793914 flags=0x0000 ifindex=14  mac=4E:99:15:44:E9:87 nodemac=2E:5C:22:49:CA:5E   
172.31.207.141:0   (localhost)                                                                                        
10.175.0.181:0     (localhost)                                                                                        
