KEY             VALUE
AgentLiveness   1913273776687
UTimeOffset     3379442751953125
