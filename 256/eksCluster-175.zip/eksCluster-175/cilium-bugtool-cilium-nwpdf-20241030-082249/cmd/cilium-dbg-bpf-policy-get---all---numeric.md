Endpoint ID: 46
Path: /sys/fs/bpf/tc/globals/cilium_policy_00046

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 186
Path: /sys/fs/bpf/tc/globals/cilium_policy_00186

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122707   1405      0        
Allow    Egress      0          ANY          NONE         disabled    17851    195       0        


Endpoint ID: 816
Path: /sys/fs/bpf/tc/globals/cilium_policy_00816

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11218177   109343    0        
Allow    Ingress     1          ANY          NONE         disabled    8815146    92004     0        
Allow    Egress      0          ANY          NONE         disabled    10619265   106085    0        


Endpoint ID: 1062
Path: /sys/fs/bpf/tc/globals/cilium_policy_01062

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1646834   20828     0        
Allow    Ingress     1          ANY          NONE         disabled    18278     213       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2323
Path: /sys/fs/bpf/tc/globals/cilium_policy_02323

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122113   1396      0        
Allow    Egress      0          ANY          NONE         disabled    17374    189       0        


