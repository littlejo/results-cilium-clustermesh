CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a462556_ad9a_4145_aba6_1b6d2025e26b.slice/cri-containerd-c6b8dd4de9e5309f340e0c7f9a06b9b4ede329e55700f3bb926cc41526d788d1.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a462556_ad9a_4145_aba6_1b6d2025e26b.slice/cri-containerd-f4c6b8baea9c2ac52bef013bd3d29906d50f74042caa1c256313806d1997575f.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d7cd797_b536_4c8d_9f7b_fa859951362b.slice/cri-containerd-eee0c44e4f0970249ffb3029037d54ff4c20de3b8b3925fdfcb5b41504b692e7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4d7cd797_b536_4c8d_9f7b_fa859951362b.slice/cri-containerd-e3b94c6365a9fef3cf08dd41602051832deca22d789a6feb688c2e5dd3cf8042.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8d4454a_5654_412d_a123_b2b5049b1bd7.slice/cri-containerd-a151f187a89ee62ba9e75b2904a166029023d428e2f7a2767f094b025a6e9f4d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc8d4454a_5654_412d_a123_b2b5049b1bd7.slice/cri-containerd-d3b8262e59d74b7f11f1736e7e4b1e0be109e35963e562431a16fc02faa0c30b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfad5ff8d_5828_4f6a_a8f0_9a7687b84331.slice/cri-containerd-b1db13e7278b00b11eec75300d0e7136026605ce1ef9613cab9fb30fa99909ee.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfad5ff8d_5828_4f6a_a8f0_9a7687b84331.slice/cri-containerd-b9c0422118fd3351e5a6dc037b0b2f0b1cecc642ab3c37bb5a2c7e6042b6ca15.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6222640_df61_439f_a1a0_188078112abe.slice/cri-containerd-b0212336080ca2a6f4420cc1ce05b027dec06c9c193d3466ab5e00453d754683.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb6222640_df61_439f_a1a0_188078112abe.slice/cri-containerd-fc99935bc4234828ae23084b53e9bfcf0f2ed7ce0b78bc5e83165f9f5c0cc1f7.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-16e1567c00ccd26daaa72e6fd12990bf4e97c4146c560d5d6e1dc1f53e35391a.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-e1e6c2939c49226a0af4643f84a53d9c5cfcf38d285e56fc3ae5b6abec98507f.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-b414df665c90a924243179d4dd98a3696a6dd1e957a52b95427fa233bd9b5c57.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-1c996e6cac137dc4357925de547067b846855a0b7e0f53dff04c96b3329b3860.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda31d1691_cc9d_4cdb_ba46_4db13d5e3872.slice/cri-containerd-c440828f1b6456a1b1597a3280d57a2a4bba97df486c9ee11dad7e8eb4ee53c1.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda31d1691_cc9d_4cdb_ba46_4db13d5e3872.slice/cri-containerd-ab9fe8507ad3e842ee38c0be9c7baf9a83d7e90e251d7ed760e8a29104becf16.scope
    103      cgroup_device   multi                                          
