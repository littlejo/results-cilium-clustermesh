[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfad5ff8d_5828_4f6a_a8f0_9a7687b84331.slice/cri-containerd-b9c0422118fd3351e5a6dc037b0b2f0b1cecc642ab3c37bb5a2c7e6042b6ca15.scope"
      }
    ],
    "ips": [
      "10.175.0.155"
    ],
    "name": "coredns-cc6ccd49c-glwhm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a462556_ad9a_4145_aba6_1b6d2025e26b.slice/cri-containerd-f4c6b8baea9c2ac52bef013bd3d29906d50f74042caa1c256313806d1997575f.scope"
      }
    ],
    "ips": [
      "10.175.0.182"
    ],
    "name": "coredns-cc6ccd49c-vctqg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-1c996e6cac137dc4357925de547067b846855a0b7e0f53dff04c96b3329b3860.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-e1e6c2939c49226a0af4643f84a53d9c5cfcf38d285e56fc3ae5b6abec98507f.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67b6ccde_6155_414f_b721_099a2f64d1d1.slice/cri-containerd-16e1567c00ccd26daaa72e6fd12990bf4e97c4146c560d5d6e1dc1f53e35391a.scope"
      }
    ],
    "ips": [
      "10.175.0.33"
    ],
    "name": "clustermesh-apiserver-5b9cc5c974-lnj4m",
    "namespace": "kube-system"
  }
]

