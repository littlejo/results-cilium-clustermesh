Total: 691
TCP:   2363 (estab 438, closed 1906, orphaned 0, timewait 1064)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  457       445       12       
INET	  467       451       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                            127.0.0.1:40233      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:37014 sk:15d6 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.192.97%ens5:68         0.0.0.0:*    uid:192 ino:76111 sk:15d7 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:37152 sk:15d8 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15205 sk:15d9 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:37151 sk:15da cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15206 sk:15db cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8df:bcff:fe3d:8e23]%ens5:546           [::]:*    uid:192 ino:16459 sk:15dc cgroup:unreachable:c4e v6only:1 <->                   
