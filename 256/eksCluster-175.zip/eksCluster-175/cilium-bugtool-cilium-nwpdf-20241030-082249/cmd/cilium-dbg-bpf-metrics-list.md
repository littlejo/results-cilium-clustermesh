REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34064     2689335     677    bpf_overlay.c
Interface                 INGRESS     605301    127422822   1132   bpf_host.c
Success                   EGRESS      13944     1091125     1694   bpf_host.c
Success                   EGRESS      254377    32464554    1308   bpf_lxc.c
Success                   EGRESS      32792     2598365     53     encap.h
Success                   INGRESS     294452    33031419    86     l3.h
Success                   INGRESS     315223    34673675    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
