alloc: 135.89MB (142490736 bytes)
total-alloc: 2.12GB (2281251648 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 61416471
frees: 60038577
heap-alloc: 135.89MB (142490736 bytes)
heap-sys: 247.38MB (259399680 bytes)
heap-idle: 78.03MB (81821696 bytes)
heap-in-use: 169.35MB (177577984 bytes)
heap-released: 4.67MB (4898816 bytes)
heap-objects: 1377894
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 2.88MB (3015040 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1004.34KB (1028441 bytes)
gc-sys: 6.00MB (6288872 bytes)
next-gc: when heap-alloc >= 212.02MB (222318504 bytes)
last-gc: 2024-10-30 08:23:01.84709506 +0000 UTC
gc-pause-total: 21.759694ms
gc-pause: 218398
gc-pause-end: 1730276581847095060
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004783284498242191
enable-gc: true
debug-gc: false
