1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:df:bc:3d:8e:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.192.97/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3528sec preferred_lft 3528sec
    inet6 fe80::8df:bcff:fe3d:8e23/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:45:02:50:1a:55 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.207.141/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::845:2ff:fe50:1a55/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:2a:37:57:4a:16 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d82a:37ff:fe57:4a16/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:92:a1:50:f7:11 brd ff:ff:ff:ff:ff:ff
    inet 10.175.0.181/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cc92:a1ff:fe50:f711/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether de:a8:33:87:69:87 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dca8:33ff:fe87:6987/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:f2:d5:49:b6:ed brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::28f2:d5ff:fe49:b6ed/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6781a78de165@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:39:e9:f3:2b:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d439:e9ff:fef3:2bd1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf493369890c8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:5c:22:49:ca:5e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c5c:22ff:fe49:ca5e/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca11719e2400d@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:32:65:52:66:d3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f432:65ff:fe52:66d3/64 scope link 
       valid_lft forever preferred_lft forever
