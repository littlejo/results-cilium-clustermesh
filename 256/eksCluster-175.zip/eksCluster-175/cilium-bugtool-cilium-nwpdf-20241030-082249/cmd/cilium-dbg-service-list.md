ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.170.16:443 (active)    
                                          2 => 172.31.238.4:443 (active)     
2    10.100.167.239:443    ClusterIP      1 => 172.31.192.97:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.175.0.155:53 (active)      
                                          2 => 10.175.0.182:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.175.0.155:9153 (active)    
                                          2 => 10.175.0.182:9153 (active)    
5    10.100.126.203:2379   ClusterIP      1 => 10.175.0.33:2379 (active)     
