key: ba 00 00 00  value: 29 02 00 00
key: 30 03 00 00  value: 62 02 00 00
key: 26 04 00 00  value: 1a 02 00 00
key: 13 09 00 00  value: 06 02 00 00
Found 4 elements
