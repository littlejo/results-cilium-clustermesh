key: 09 00 00 00  value: 76 02 00 00
key: ad 00 00 00  value: 0e 02 00 00
key: 05 04 00 00  value: 15 02 00 00
key: 25 04 00 00  value: 01 02 00 00
Found 4 elements
