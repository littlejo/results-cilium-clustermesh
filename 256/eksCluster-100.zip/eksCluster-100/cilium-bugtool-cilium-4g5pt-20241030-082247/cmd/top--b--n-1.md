top - 08:22:49 up 34 min,  0 users,  load average: 0.19, 0.21, 0.13
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.7 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4478.9 free,   1188.9 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6440.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    716 root      20   0 1244340  22692  14456 R  40.0   0.3   0:00.11 hubble
      1 root      20   0 1606336 384344  78716 S   6.7   4.8   0:49.94 cilium-+
    664 root      20   0 1240432  16680  11548 S   6.7   0.2   0:00.03 cilium-+
    401 root      20   0 1229744   6972   2924 S   0.0   0.1   0:01.14 cilium-+
    659 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    670 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    687 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    707 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    740 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    756 root      20   0    3728    484    432 R   0.0   0.0   0:00.00 bash
