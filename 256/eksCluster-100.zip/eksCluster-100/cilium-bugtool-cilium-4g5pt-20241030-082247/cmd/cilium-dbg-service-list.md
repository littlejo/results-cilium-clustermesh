ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.136.241:443 (active)   
                                         2 => 172.31.202.2:443 (active)     
2    10.100.13.160:443    ClusterIP      1 => 172.31.156.41:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.100.0.240:53 (active)      
                                         2 => 10.100.0.21:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.100.0.240:9153 (active)    
                                         2 => 10.100.0.21:9153 (active)     
5    10.100.27.225:2379   ClusterIP      1 => 10.100.0.242:2379 (active)    
