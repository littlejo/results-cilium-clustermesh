KEY             VALUE
AgentLiveness   2102205717721
UTimeOffset     3379442378906250
