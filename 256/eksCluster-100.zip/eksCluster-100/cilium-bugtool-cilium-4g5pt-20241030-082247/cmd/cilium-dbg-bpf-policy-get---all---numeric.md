Endpoint ID: 9
Path: /sys/fs/bpf/tc/globals/cilium_policy_00009

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11312789   110953    0        
Allow    Ingress     1          ANY          NONE         disabled    9127500    95559     0        
Allow    Egress      0          ANY          NONE         disabled    11176143   110931    0        


Endpoint ID: 173
Path: /sys/fs/bpf/tc/globals/cilium_policy_00173

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    675916   6057      0        
Allow    Ingress     1          ANY          NONE         disabled    152179   1745      0        
Allow    Egress      0          ANY          NONE         disabled    125248   1204      0        


Endpoint ID: 1029
Path: /sys/fs/bpf/tc/globals/cilium_policy_01029

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    666464   5995      0        
Allow    Ingress     1          ANY          NONE         disabled    154210   1771      0        
Allow    Egress      0          ANY          NONE         disabled    123981   1192      0        


Endpoint ID: 1061
Path: /sys/fs/bpf/tc/globals/cilium_policy_01061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1637975   20671     0        
Allow    Ingress     1          ANY          NONE         disabled    22544     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2211
Path: /sys/fs/bpf/tc/globals/cilium_policy_02211

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


