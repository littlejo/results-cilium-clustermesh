CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ec98f3_b5b9_46b0_b7fa_f396c89341c4.slice/cri-containerd-1c75c46056c41c6196a5a00708fdde2b08c78f7de3d8f7197a98a982a3fc0377.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ec98f3_b5b9_46b0_b7fa_f396c89341c4.slice/cri-containerd-178ac7a340ac31f6c53fa9a3d846063f8d4effb2e3bb6f2e0a1575dd3a879716.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14aee21f_79cd_4a04_bd2a_83127712d0f7.slice/cri-containerd-447b76eb1962a3965d0fb63cae09654db59077c2b3a87ec2e21c194404a2dce1.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14aee21f_79cd_4a04_bd2a_83127712d0f7.slice/cri-containerd-abdbd477ba57feb30294a82336e57b5a8c15aef85ecc3577f8e2b365ad431ea9.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0bef3cb0_aded_46b1_8fb1_fe540ce7106f.slice/cri-containerd-e4449b42fadf4bc38784ed6727043f42c4dc06aef34d82b5aeabda67563a51ed.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0bef3cb0_aded_46b1_8fb1_fe540ce7106f.slice/cri-containerd-69b804ea6859bbcaeb3977e560d13ebdb40df3c0c10664c235569af0609c6386.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3803c087_149e_4728_b013_eb97242100af.slice/cri-containerd-14d191208624871dbe8a501bad12acde5401facbb805c1455be85c72bc37fd21.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3803c087_149e_4728_b013_eb97242100af.slice/cri-containerd-795b1b44acda88b8ca24b85a4497d36b5ae0f76b51173c63f22f9e0f8dae6ed2.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1296e0f_5514_4dda_80eb_bc1ad0731349.slice/cri-containerd-956a898c647ff76585b016065698b9bc61ce8a08a1459a9dcc1fb414f1551161.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb1296e0f_5514_4dda_80eb_bc1ad0731349.slice/cri-containerd-1157e9bceb44c79db9968df21df173da6400278138db238528e7db562ce65b0f.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7815bd45_f75b_44f5_b3dc_e3d339bfb3a3.slice/cri-containerd-84087d66a8dc54e60e429abe23e753dc5554e77a8f38cf87763762b9a3f2439d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7815bd45_f75b_44f5_b3dc_e3d339bfb3a3.slice/cri-containerd-7da90be8a52d044f24e832538051e23b80e1997fa3db3a3084d76a21d1244e91.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-06811df588e4a31b1ce5d5908608d22655d0412502d48a43b881fe90db9b89cc.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-2faf324e92941a1c99f4d56bafeb93fc770b4384f43453c4137c1f8be9a3a2c6.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-2d4c169f7469eab080790b96cbc2696fd9a4517582a5308126e108ff1e6d8cab.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-2e3c0dbdbe13eff9a8623858fd5b5657cbba030dc226660e418cf761cb16fdf2.scope
    637      cgroup_device   multi                                          
