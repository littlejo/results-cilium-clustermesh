[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-2d4c169f7469eab080790b96cbc2696fd9a4517582a5308126e108ff1e6d8cab.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-2faf324e92941a1c99f4d56bafeb93fc770b4384f43453c4137c1f8be9a3a2c6.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda4f7f1cd_b63e_47c0_8172_2429daa74eb8.slice/cri-containerd-06811df588e4a31b1ce5d5908608d22655d0412502d48a43b881fe90db9b89cc.scope"
      }
    ],
    "ips": [
      "10.100.0.242"
    ],
    "name": "clustermesh-apiserver-546cdd876f-rplk7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1ec98f3_b5b9_46b0_b7fa_f396c89341c4.slice/cri-containerd-178ac7a340ac31f6c53fa9a3d846063f8d4effb2e3bb6f2e0a1575dd3a879716.scope"
      }
    ],
    "ips": [
      "10.100.0.21"
    ],
    "name": "coredns-cc6ccd49c-jldgv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3803c087_149e_4728_b013_eb97242100af.slice/cri-containerd-795b1b44acda88b8ca24b85a4497d36b5ae0f76b51173c63f22f9e0f8dae6ed2.scope"
      }
    ],
    "ips": [
      "10.100.0.240"
    ],
    "name": "coredns-cc6ccd49c-xt76d",
    "namespace": "kube-system"
  }
]

