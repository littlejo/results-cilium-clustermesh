{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.644Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.156.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.644Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.179.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:36.644Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.211Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.214Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.296Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.340Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:41.432Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.087Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.087Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.087Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.117Z",
  "value": "id=519   sec_id=3320714 flags=0x0000 ifindex=16  mac=2E:CE:FD:AC:1C:00 nodemac=BA:5A:A1:AB:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:21.117Z",
  "value": "id=519   sec_id=3320714 flags=0x0000 ifindex=16  mac=2E:CE:FD:AC:1C:00 nodemac=BA:5A:A1:AB:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:22.086Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:22.087Z",
  "value": "id=519   sec_id=3320714 flags=0x0000 ifindex=16  mac=2E:CE:FD:AC:1C:00 nodemac=BA:5A:A1:AB:BA:68"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:22.087Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:22.087Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.048Z",
  "value": "id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.888Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.158Z",
  "value": "id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.161Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.162Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.162Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.160Z",
  "value": "id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.162Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.162Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:53.163Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.184Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.185Z",
  "value": "id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.186Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.187Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.158Z",
  "value": "id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.159Z",
  "value": "id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.159Z",
  "value": "id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.160Z",
  "value": "id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80"
}

