IP ADDRESS        LOCAL ENDPOINT INFO
172.31.156.41:0   (localhost)                                                                                        
10.100.0.160:0    (localhost)                                                                                        
172.31.179.95:0   (localhost)                                                                                        
10.100.0.21:0     id=173   sec_id=3312435 flags=0x0000 ifindex=14  mac=06:BD:BF:6F:B2:5A nodemac=8A:F2:1C:A9:F6:6C   
10.100.0.242:0    id=9     sec_id=3320714 flags=0x0000 ifindex=18  mac=D2:EE:4C:78:A0:A1 nodemac=4E:DF:0E:5C:8B:33   
10.100.0.173:0    id=1061  sec_id=4     flags=0x0000 ifindex=10  mac=F6:92:66:D1:EA:73 nodemac=BA:86:50:8A:A4:80     
10.100.0.240:0    id=1029  sec_id=3312435 flags=0x0000 ifindex=12  mac=46:88:01:72:F1:0E nodemac=46:CB:E5:C6:D1:F2   
