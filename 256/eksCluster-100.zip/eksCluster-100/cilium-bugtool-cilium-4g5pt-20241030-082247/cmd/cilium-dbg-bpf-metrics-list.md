REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33915     2681432     677    bpf_overlay.c
Interface                 INGRESS     620465    129506032   1132   bpf_host.c
Success                   EGRESS      13931     1090275     1694   bpf_host.c
Success                   EGRESS      24104     3820084     86     l3.h
Success                   EGRESS      261940    33199711    1308   bpf_lxc.c
Success                   EGRESS      32805     2597954     53     encap.h
Success                   INGRESS     302461    34072459    86     l3.h
Success                   INGRESS     347200    39527746    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
