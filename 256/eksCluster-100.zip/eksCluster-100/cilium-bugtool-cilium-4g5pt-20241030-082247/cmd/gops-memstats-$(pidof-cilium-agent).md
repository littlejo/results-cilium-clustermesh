alloc: 142.45MB (149368568 bytes)
total-alloc: 2.26GB (2424626792 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 63733129
frees: 62528858
heap-alloc: 142.45MB (149368568 bytes)
heap-sys: 247.54MB (259563520 bytes)
heap-idle: 62.44MB (65470464 bytes)
heap-in-use: 185.10MB (194093056 bytes)
heap-released: 2.98MB (3121152 bytes)
heap-objects: 1204271
stack-in-use: 64.44MB (67567616 bytes)
stack-sys: 64.44MB (67567616 bytes)
stack-mspan-inuse: 2.88MB (3020960 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.24MB (1296649 bytes)
gc-sys: 5.98MB (6266224 bytes)
next-gc: when heap-alloc >= 211.99MB (222282488 bytes)
last-gc: 2024-10-30 08:23:02.283505308 +0000 UTC
gc-pause-total: 24.929256ms
gc-pause: 73862
gc-pause-end: 1730276582283505308
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00042636853797246675
enable-gc: true
debug-gc: false
