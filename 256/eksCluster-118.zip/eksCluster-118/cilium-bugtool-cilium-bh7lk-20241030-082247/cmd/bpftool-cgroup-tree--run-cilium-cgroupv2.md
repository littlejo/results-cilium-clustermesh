CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3693ae57_17b0_4096_9191_3d7265ca4aa7.slice/cri-containerd-3c721cdab292314a9d08b3c61179e03e633fff8c4bcc38342b954276c94de7ec.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3693ae57_17b0_4096_9191_3d7265ca4aa7.slice/cri-containerd-86d0e8c6f31c8b65156363f398fe271500e5599c80a53360a4d155795d680237.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f258dd9_ee48_4054_8a5a_4912ec6c1428.slice/cri-containerd-b446bae42bdb0c10e685d5b61b659b7a999f43a3f11366970b301c71e8ab1e9c.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f258dd9_ee48_4054_8a5a_4912ec6c1428.slice/cri-containerd-eda421e8e9e906a91432f55dac3b432db1d25c0d4490f85bd7005bc66b2e025e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a723946_a46e_4a33_8bca_e44450a177fe.slice/cri-containerd-05281c5d36c06ae5b619246c346eb5af4b387a1e02307d77411e52f40b592e59.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5a723946_a46e_4a33_8bca_e44450a177fe.slice/cri-containerd-8b02a099a4325d90a56354f47a9d22b845a969999479275394013e9f83aab1b2.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e98dba5_509d_4a70_af51_bb9fcff4a0c9.slice/cri-containerd-dea152153f2214d254d07ee1d1cd66f0a664402e8fba6dfaf7dd4842284d8abd.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e98dba5_509d_4a70_af51_bb9fcff4a0c9.slice/cri-containerd-5c5c3db2b74f3a44c771c451620ed9f621a14367d570b4690c99e2ec88ceea23.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec74dca0_cf4a_4904_bd92_71ba38c08ee9.slice/cri-containerd-cf7e798a4b793757ed93ae2f8fcadc1c31fdf71a3dbef2b370b29555f0ae972d.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podec74dca0_cf4a_4904_bd92_71ba38c08ee9.slice/cri-containerd-1dadaa4ae7cb7bccc202b921b75bda6afc379973ff64f2c81200683e28262288.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-0c9b493ce0edc54c3ff45a52e3406061cc9aeeede91db220bee272a03a3085ba.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-7e3f7300bada72ca0831d90ff15c7adbb94fe9cf6362806632c48fc97812dfa7.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-b7e43c6e828134058ca1a66a8cc5a6ce6bb90f09f498a8eb41c40199901260c3.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-a489decbec78d1288b9809d4373fb9255b0559b8955e9394a4e669771eee2ea1.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91ec6c44_7d6a_4f08_9625_718788aa1436.slice/cri-containerd-5bde6ec53dcb4f2b3e593d790d69cb6294b0333af3d7a3f4efe2d0acb2f54223.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91ec6c44_7d6a_4f08_9625_718788aa1436.slice/cri-containerd-6f9d5d93eb88e82d6c6ba0f63e80b61bcf8fd7a88db5b3701693db997d450867.scope
    90       cgroup_device   multi                                          
