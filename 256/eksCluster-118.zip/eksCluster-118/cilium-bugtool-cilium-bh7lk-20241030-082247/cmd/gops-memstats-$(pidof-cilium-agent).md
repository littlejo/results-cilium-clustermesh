alloc: 123.89MB (129904536 bytes)
total-alloc: 2.20GB (2364427600 bytes)
sys: 316.58MB (331960676 bytes)
lookups: 0
mallocs: 62541457
frees: 61456380
heap-alloc: 123.89MB (129904536 bytes)
heap-sys: 239.35MB (250978304 bytes)
heap-idle: 78.43MB (82239488 bytes)
heap-in-use: 160.92MB (168738816 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1085077
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 2.74MB (2873760 bytes)
stack-mspan-sys: 3.74MB (3916800 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 851.51KB (871945 bytes)
gc-sys: 6.07MB (6364696 bytes)
next-gc: when heap-alloc >= 213.17MB (223528584 bytes)
last-gc: 2024-10-30 08:23:09.708563113 +0000 UTC
gc-pause-total: 9.207743ms
gc-pause: 125690
gc-pause-end: 1730276589708563113
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00035152427813528534
enable-gc: true
debug-gc: false
