Endpoint ID: 399
Path: /sys/fs/bpf/tc/globals/cilium_policy_00399

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148203   1699      0        
Allow    Egress      0          ANY          NONE         disabled    20574    229       0        


Endpoint ID: 489
Path: /sys/fs/bpf/tc/globals/cilium_policy_00489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150490   1729      0        
Allow    Egress      0          ANY          NONE         disabled    17887    196       0        


Endpoint ID: 845
Path: /sys/fs/bpf/tc/globals/cilium_policy_00845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11186385   109335    0        
Allow    Ingress     1          ANY          NONE         disabled    9328694    97542     0        
Allow    Egress      0          ANY          NONE         disabled    10742937   106924    0        


Endpoint ID: 1452
Path: /sys/fs/bpf/tc/globals/cilium_policy_01452

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641871   20726     0        
Allow    Ingress     1          ANY          NONE         disabled    22568     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2877
Path: /sys/fs/bpf/tc/globals/cilium_policy_02877

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


