top - 08:22:48 up 34 min,  0 users,  load average: 0.56, 0.39, 0.26
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 59.4 us, 34.4 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.2 si,  0.0 st
MiB Mem :   7814.2 total,   4492.9 free,   1174.6 used,   2146.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6454.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1605888 385140  80124 S  75.0   4.8   0:50.48 cilium-+
    407 root      20   0 1229744   8248   3836 S   0.0   0.1   0:01.18 cilium-+
    642 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    662 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    672 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    692 root      20   0 1240432  16220  10960 S   0.0   0.2   0:00.03 cilium-+
    724 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    749 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    755 root      20   0 1550472   8008   5900 R   0.0   0.1   0:00.00 runc:[2+
