key: 8f 01 00 00  value: 16 02 00 00
key: e9 01 00 00  value: 17 02 00 00
key: 4d 03 00 00  value: 68 02 00 00
key: ac 05 00 00  value: 22 02 00 00
Found 4 elements
