[
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-7e3f7300bada72ca0831d90ff15c7adbb94fe9cf6362806632c48fc97812dfa7.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-a489decbec78d1288b9809d4373fb9255b0559b8955e9394a4e669771eee2ea1.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda969a9ec_ae5f_40d4_928c_000d045b4aa0.slice/cri-containerd-b7e43c6e828134058ca1a66a8cc5a6ce6bb90f09f498a8eb41c40199901260c3.scope"
      }
    ],
    "ips": [
      "10.118.0.135"
    ],
    "name": "clustermesh-apiserver-9bdf4bbf7-bxnhd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e98dba5_509d_4a70_af51_bb9fcff4a0c9.slice/cri-containerd-5c5c3db2b74f3a44c771c451620ed9f621a14367d570b4690c99e2ec88ceea23.scope"
      }
    ],
    "ips": [
      "10.118.0.242"
    ],
    "name": "coredns-cc6ccd49c-cmp45",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3693ae57_17b0_4096_9191_3d7265ca4aa7.slice/cri-containerd-3c721cdab292314a9d08b3c61179e03e633fff8c4bcc38342b954276c94de7ec.scope"
      }
    ],
    "ips": [
      "10.118.0.93"
    ],
    "name": "coredns-cc6ccd49c-tb8pn",
    "namespace": "kube-system"
  }
]

