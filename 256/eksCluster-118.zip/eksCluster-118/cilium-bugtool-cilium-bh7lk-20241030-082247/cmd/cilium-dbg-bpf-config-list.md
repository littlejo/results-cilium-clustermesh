KEY             VALUE
AgentLiveness   2074478509737
UTimeOffset     3379442431640625
