IP ADDRESS         LOCAL ENDPOINT INFO
10.118.0.202:0     id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23     
10.118.0.135:0     id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4   
10.118.0.108:0     (localhost)                                                                                        
172.31.164.223:0   (localhost)                                                                                        
10.118.0.93:0      id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A   
172.31.160.70:0    (localhost)                                                                                        
10.118.0.242:0     id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F   
