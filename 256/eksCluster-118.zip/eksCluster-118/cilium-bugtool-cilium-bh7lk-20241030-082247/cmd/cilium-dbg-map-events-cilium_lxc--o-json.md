{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.160.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.999Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.005Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.048Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.050Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:16.082Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:03.483Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:03.483Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:03.483Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:03.519Z",
  "value": "id=847   sec_id=3928592 flags=0x0000 ifindex=16  mac=8A:03:EA:A1:1A:1E nodemac=8A:35:D5:D2:D5:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.483Z",
  "value": "id=847   sec_id=3928592 flags=0x0000 ifindex=16  mac=8A:03:EA:A1:1A:1E nodemac=8A:35:D5:D2:D5:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.483Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.483Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:04.484Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.375Z",
  "value": "id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.118.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.813Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.751Z",
  "value": "id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.753Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.754Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.755Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.757Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.764Z",
  "value": "id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.767Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.767Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.751Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.751Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.751Z",
  "value": "id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.751Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.751Z",
  "value": "id=1452  sec_id=4     flags=0x0000 ifindex=10  mac=F2:F5:82:15:58:4F nodemac=3E:0E:FF:D4:ED:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.752Z",
  "value": "id=845   sec_id=3928592 flags=0x0000 ifindex=18  mac=FA:87:D1:01:B6:F5 nodemac=02:95:80:BA:FE:B4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.752Z",
  "value": "id=489   sec_id=3906672 flags=0x0000 ifindex=14  mac=FA:3C:94:FC:07:56 nodemac=C2:69:A2:10:E9:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.118.0.93:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.752Z",
  "value": "id=399   sec_id=3906672 flags=0x0000 ifindex=12  mac=5E:5E:3A:35:85:5E nodemac=EE:36:75:0B:D0:8A"
}

