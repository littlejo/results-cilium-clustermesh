xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 496
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 491
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 550
lxcf0127bdb916b(12) clsact/ingress cil_from_container-lxcf0127bdb916b id 521
lxc84d91bf2f4e8(14) clsact/ingress cil_from_container-lxc84d91bf2f4e8 id 545
lxc168ff714d9a7(18) clsact/ingress cil_from_container-lxc168ff714d9a7 id 620

flow_dissector:

netfilter:

