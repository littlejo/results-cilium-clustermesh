REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35299     2792295     677    bpf_overlay.c
Interface                 INGRESS     616173    128946987   1132   bpf_host.c
Success                   EGRESS      15263     1197448     1694   bpf_host.c
Success                   EGRESS      256102    32753776    1308   bpf_lxc.c
Success                   EGRESS      34767     2753335     53     encap.h
Success                   INGRESS     299996    33573451    86     l3.h
Success                   INGRESS     320683    35212344    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
