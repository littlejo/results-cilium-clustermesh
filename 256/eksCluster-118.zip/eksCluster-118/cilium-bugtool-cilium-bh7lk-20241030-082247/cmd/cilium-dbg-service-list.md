ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.175.203:443 (active)   
                                          2 => 172.31.232.151:443 (active)   
2    10.100.46.250:443     ClusterIP      1 => 172.31.160.70:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.118.0.242:53 (active)      
                                          2 => 10.118.0.93:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.118.0.242:9153 (active)    
                                          2 => 10.118.0.93:9153 (active)     
5    10.100.207.117:2379   ClusterIP      1 => 10.118.0.135:2379 (active)    
