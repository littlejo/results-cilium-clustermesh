USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         692  0.0  0.2 1240432 16220 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         678  0.0  0.0 1229000 4048 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         672  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         662  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         642  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  4.7 1605888 378804 ?      Ssl  07:57   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         407  0.0  0.1 1229744 8248 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
