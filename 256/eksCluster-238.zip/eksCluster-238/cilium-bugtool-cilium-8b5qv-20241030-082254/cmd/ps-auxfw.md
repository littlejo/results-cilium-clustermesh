USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         673  2.0  0.2 1240176 16032 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         703  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         704  0.0  0.0   2068   236 ?        R    08:22   0:00  \_ hostname
root         672  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         661  0.0  0.0 1228744 4032 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         650  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         630  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.1  4.9 1606080 392660 ?      Ssl  08:04   0:35 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1229488 8160 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
