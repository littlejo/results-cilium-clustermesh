KEY             VALUE
AgentLiveness   1618608838729
UTimeOffset     3379443335937500
