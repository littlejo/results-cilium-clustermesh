top - 08:22:55 up 26 min,  0 users,  load average: 0.08, 0.16, 0.16
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.4 us, 25.0 sy,  0.0 ni, 53.6 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4485.2 free,   1183.6 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 392660  80508 S   6.7   4.9   0:35.90 cilium-+
    673 root      20   0 1240432  16336  11292 S   6.7   0.2   0:00.03 cilium-+
    415 root      20   0 1229488   8160   3836 S   0.0   0.1   0:01.05 cilium-+
    630 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    650 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    661 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
    672 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    714 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    732 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
