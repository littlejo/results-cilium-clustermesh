key: 0a 00 00 00  value: 22 02 00 00
key: a3 01 00 00  value: 84 02 00 00
key: 41 05 00 00  value: 18 02 00 00
key: e2 0e 00 00  value: 48 02 00 00
Found 4 elements
