ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.170.62:443 (active)    
                                          2 => 172.31.211.121:443 (active)   
2    10.100.216.248:443    ClusterIP      1 => 172.31.148.36:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.238.0.246:53 (active)      
                                          2 => 10.238.0.104:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.238.0.246:9153 (active)    
                                          2 => 10.238.0.104:9153 (active)    
5    10.100.154.213:2379   ClusterIP      1 => 10.238.0.16:2379 (active)     
