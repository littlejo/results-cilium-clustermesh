markdown output at /tmp/cilium-bugtool-20241030-082255.453+0000-UTC-2229500344/cmd/cilium-debuginfo-20241030-082326.438+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.453+0000-UTC-2229500344/cmd/cilium-debuginfo-20241030-082326.438+0000-UTC.json
