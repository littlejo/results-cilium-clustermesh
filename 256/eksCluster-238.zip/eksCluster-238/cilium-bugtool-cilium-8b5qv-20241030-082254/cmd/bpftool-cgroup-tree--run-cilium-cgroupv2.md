CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb6e61f8_e276_46f3_9d4c_55936c78f5f3.slice/cri-containerd-3cc9a71415a15510726e8bff4c76b31f76dd4d871940dcc9a2d5eab4ae6b537d.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb6e61f8_e276_46f3_9d4c_55936c78f5f3.slice/cri-containerd-821b8b126beef76feef346ce03812462ffab857d5bfb020c59396372aa559aee.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7b4935a_b5a2_4b4d_9cf0_e7f77191942f.slice/cri-containerd-52af560033b72fbac144a6387bc2dda7756f7d15666c2d3ac5cd9bfc60cf97fe.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7b4935a_b5a2_4b4d_9cf0_e7f77191942f.slice/cri-containerd-4a6fc4defc6a4ba5d718bc3f426f31b919ee591184d9837dc3067386b092a107.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3f8aedb_0347_4bff_a4ba_1323e58e387f.slice/cri-containerd-18ceb0992fedc12fcba620cf369448f5085fce4f0b8cffac71e98aedce108c2b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3f8aedb_0347_4bff_a4ba_1323e58e387f.slice/cri-containerd-5d4e2eccc935d9eb29cae7960aaa9915549010b3ef97452c38d183094f98e1d4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db55b7e_73e3_400a_b8af_a883c80f4fe2.slice/cri-containerd-8de3a0b85c73782ee6db79fc0a1f77d531b46f4ffd455fe89e12283742ba2f68.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db55b7e_73e3_400a_b8af_a883c80f4fe2.slice/cri-containerd-b70c56cbb93143c8ea0381dea8402b57c4d9742c6063b392e7b50f94728299e1.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod832ad342_6c96_412e_b0dc_d9273bf1e65b.slice/cri-containerd-b60ab2efce6a99a17297929e19fb5e7974d57e7ca56236850d67647c46b95c39.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod832ad342_6c96_412e_b0dc_d9273bf1e65b.slice/cri-containerd-2149b23a584b3c7ab0d5e1e000b1edad81393d0595639bdf6da6c3f90973404a.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0960086_442c_4723_970f_7863fdf372da.slice/cri-containerd-f270c1a7afa35317cca78ef0a6395cdebb43d9621cfeb6d90ef332d6bf986bd2.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode0960086_442c_4723_970f_7863fdf372da.slice/cri-containerd-076c277a4da3c62b0a9b3d4a7145786e9ad1a91eb6822e7cf0709ed1c0cca352.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-d9d7bd2fd9771035751fcf6059ad317180054d120448dc00fb46cacf28466df2.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-c7819c0cd8deb79bce696267a260dc58e347b6b7ff8bec8f6bd7729e79cb6362.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-ea5680ba1157e2fbc3068cb2bfbbba2d8f768730c1b675875f36e8e049cdc610.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-600633f515b40d9982f5b4040fb46702dc4fd156a6c37d0d7d7ccbcf3861f23e.scope
    657      cgroup_device   multi                                          
