[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-d9d7bd2fd9771035751fcf6059ad317180054d120448dc00fb46cacf28466df2.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-ea5680ba1157e2fbc3068cb2bfbbba2d8f768730c1b675875f36e8e049cdc610.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc1046d83_212f_4187_8ca3_2078a06185fe.slice/cri-containerd-c7819c0cd8deb79bce696267a260dc58e347b6b7ff8bec8f6bd7729e79cb6362.scope"
      }
    ],
    "ips": [
      "10.238.0.16"
    ],
    "name": "clustermesh-apiserver-7f99c8fb6d-7tpxs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3db55b7e_73e3_400a_b8af_a883c80f4fe2.slice/cri-containerd-8de3a0b85c73782ee6db79fc0a1f77d531b46f4ffd455fe89e12283742ba2f68.scope"
      }
    ],
    "ips": [
      "10.238.0.246"
    ],
    "name": "coredns-cc6ccd49c-25szk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddb6e61f8_e276_46f3_9d4c_55936c78f5f3.slice/cri-containerd-821b8b126beef76feef346ce03812462ffab857d5bfb020c59396372aa559aee.scope"
      }
    ],
    "ips": [
      "10.238.0.104"
    ],
    "name": "coredns-cc6ccd49c-wj4ht",
    "namespace": "kube-system"
  }
]

