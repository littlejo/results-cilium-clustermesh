Endpoint ID: 10
Path: /sys/fs/bpf/tc/globals/cilium_policy_00010

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    107536   1229      0        
Allow    Egress      0          ANY          NONE         disabled    14996    160       0        


Endpoint ID: 419
Path: /sys/fs/bpf/tc/globals/cilium_policy_00419

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11188083   109084    0        
Allow    Ingress     1          ANY          NONE         disabled    8452497    87733     0        
Allow    Egress      0          ANY          NONE         disabled    10649220   106132    0        


Endpoint ID: 874
Path: /sys/fs/bpf/tc/globals/cilium_policy_00874

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1345
Path: /sys/fs/bpf/tc/globals/cilium_policy_01345

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    107470   1228      0        
Allow    Egress      0          ANY          NONE         disabled    16153    172       0        


Endpoint ID: 3810
Path: /sys/fs/bpf/tc/globals/cilium_policy_03810

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1663774   21003     0        
Allow    Ingress     1          ANY          NONE         disabled    17140     201       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


