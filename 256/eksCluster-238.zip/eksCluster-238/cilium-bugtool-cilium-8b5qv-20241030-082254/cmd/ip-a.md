1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b3:ab:b6:1f:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.36/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2023sec preferred_lft 2023sec
    inet6 fe80::4b3:abff:feb6:1f87/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b7:8a:05:27:05 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.187.174/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4b7:8aff:fe05:2705/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:4b:7a:c8:f3:d3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::604b:7aff:fec8:f3d3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:66:c4:ea:61:9d brd ff:ff:ff:ff:ff:ff
    inet 10.238.0.149/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8c66:c4ff:feea:619d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ba:04:5d:93:a1:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b804:5dff:fe93:a1cd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:9b:c6:ff:b0:44 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::749b:c6ff:feff:b044/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9a6484acfdef@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:da:35:1b:3c:27 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::80da:35ff:fe1b:3c27/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb3f33a91305d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:87:fa:fc:62:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3c87:faff:fefc:62c7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7bbf65cd0501@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:ac:3f:15:44:82 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8ac:3fff:fe15:4482/64 scope link 
       valid_lft forever preferred_lft forever
