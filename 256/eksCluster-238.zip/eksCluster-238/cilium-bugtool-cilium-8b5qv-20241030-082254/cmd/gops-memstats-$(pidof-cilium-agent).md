alloc: 177.38MB (185996840 bytes)
total-alloc: 2.10GB (2254972744 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 61072140
frees: 59265437
heap-alloc: 177.38MB (185996840 bytes)
heap-sys: 251.13MB (263331840 bytes)
heap-idle: 47.19MB (49479680 bytes)
heap-in-use: 203.95MB (213852160 bytes)
heap-released: 832.00KB (851968 bytes)
heap-objects: 1806703
stack-in-use: 64.84MB (67993600 bytes)
stack-sys: 64.84MB (67993600 bytes)
stack-mspan-inuse: 3.24MB (3392160 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 940.02KB (962585 bytes)
gc-sys: 6.00MB (6293016 bytes)
next-gc: when heap-alloc >= 212.72MB (223048648 bytes)
last-gc: 2024-10-30 08:23:00.784922748 +0000 UTC
gc-pause-total: 12.63293ms
gc-pause: 87103
gc-pause-end: 1730276580784922748
num-gc: 78
num-forced-gc: 0
gc-cpu-fraction: 0.0004455284772064587
enable-gc: true
debug-gc: false
