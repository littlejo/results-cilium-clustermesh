filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7bbf65cd0501 direct-action not_in_hw id 650 tag 0af1d5c1115b4c2c jited 
