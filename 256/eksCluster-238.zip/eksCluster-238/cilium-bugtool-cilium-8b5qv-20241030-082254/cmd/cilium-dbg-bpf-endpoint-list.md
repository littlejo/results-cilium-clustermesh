IP ADDRESS         LOCAL ENDPOINT INFO
172.31.148.36:0    (localhost)                                                                                        
10.238.0.246:0     id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27   
172.31.187.174:0   (localhost)                                                                                        
10.238.0.16:0      id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82   
10.238.0.184:0     id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44     
10.238.0.104:0     id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7   
10.238.0.149:0     (localhost)                                                                                        
