REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34079     2695501     677    bpf_overlay.c
Interface                 INGRESS     600500    126756774   1132   bpf_host.c
Success                   EGRESS      13797     1081439     1694   bpf_host.c
Success                   EGRESS      251751    32253715    1308   bpf_lxc.c
Success                   EGRESS      32459     2577639     53     encap.h
Success                   INGRESS     289509    32627260    86     l3.h
Success                   INGRESS     310442    34285368    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
