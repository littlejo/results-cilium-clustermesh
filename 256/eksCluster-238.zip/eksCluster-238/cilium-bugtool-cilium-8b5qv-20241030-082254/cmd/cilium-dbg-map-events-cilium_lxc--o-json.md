{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.36:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.187.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.050Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:22.267Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:22.272Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:22.303Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:22.348Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:31.107Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:31.108Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:31.108Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:31.136Z",
  "value": "id=2448  sec_id=7843821 flags=0x0000 ifindex=16  mac=DE:1D:44:0A:C5:32 nodemac=B6:5B:51:47:0F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:32.107Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:32.107Z",
  "value": "id=2448  sec_id=7843821 flags=0x0000 ifindex=16  mac=DE:1D:44:0A:C5:32 nodemac=B6:5B:51:47:0F:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:32.107Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:32.108Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.397Z",
  "value": "id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.238.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.896Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.844Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.858Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.859Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:44.859Z",
  "value": "id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.832Z",
  "value": "id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.837Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.837Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:45.837Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.823Z",
  "value": "id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.824Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.824Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:46.825Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:47.824Z",
  "value": "id=419   sec_id=7843821 flags=0x0000 ifindex=18  mac=BA:C7:E0:7B:E8:3C nodemac=0A:AC:3F:15:44:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:47.825Z",
  "value": "id=3810  sec_id=4     flags=0x0000 ifindex=10  mac=16:9B:8E:16:BF:A8 nodemac=76:9B:C6:FF:B0:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:47.825Z",
  "value": "id=1345  sec_id=7841370 flags=0x0000 ifindex=12  mac=8E:D9:7F:0F:6A:F9 nodemac=82:DA:35:1B:3C:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.238.0.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:47.825Z",
  "value": "id=10    sec_id=7841370 flags=0x0000 ifindex=14  mac=9E:51:1B:95:18:D9 nodemac=3E:87:FA:FC:62:C7"
}

