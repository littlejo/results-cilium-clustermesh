[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1427ec3e_80b4_4576_9744_e7d22eb19112.slice/cri-containerd-6273304e744a0808975a307f605674ac80a1ee3454f3fbf0578172eb72b49c22.scope"
      }
    ],
    "ips": [
      "10.117.0.231"
    ],
    "name": "coredns-cc6ccd49c-n4jsr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b7268c3_d796_4f4c_bbdf_5450195e011f.slice/cri-containerd-d4c8a2dfe04756a73a4690dd529100654df8be51d0f6bd41a96161b9ecc1da34.scope"
      }
    ],
    "ips": [
      "10.117.0.143"
    ],
    "name": "coredns-cc6ccd49c-fchp9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-40a08e42812cdab0089d0f08b19a95a6c36ea18e4f85a61a15e51376bc70452e.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-4c3c0945b38e31426b0fecd48b53249440644909158033ffbd04536898fc35d5.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-fb7df96541784b06c6ed0b002ecbf20ad31625c7496ebd631684e0b77913c1da.scope"
      }
    ],
    "ips": [
      "10.117.0.28"
    ],
    "name": "clustermesh-apiserver-7646f84849-jjzng",
    "namespace": "kube-system"
  }
]

