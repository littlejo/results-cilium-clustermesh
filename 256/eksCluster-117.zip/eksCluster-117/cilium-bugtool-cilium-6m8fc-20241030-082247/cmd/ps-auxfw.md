USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         666  0.0  0.1 1240432 15828 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         702  0.0  0.1 1240432 15828 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         703  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         665  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         652  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         651  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.9  4.9 1606080 396304 ?      Ssl  07:57   1:00 cilium-agent --config-dir=/tmp/cilium/config-map
root         391  0.0  0.1 1229744 8164 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
