key: 46 02 00 00  value: 04 02 00 00
key: 10 04 00 00  value: 68 02 00 00
key: 99 05 00 00  value: 1b 02 00 00
key: a9 0d 00 00  value: 2a 02 00 00
Found 4 elements
