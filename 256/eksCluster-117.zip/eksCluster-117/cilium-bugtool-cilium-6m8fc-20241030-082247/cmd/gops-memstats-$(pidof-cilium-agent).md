alloc: 96.53MB (101216832 bytes)
total-alloc: 2.49GB (2668487600 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 66731076
frees: 66047812
heap-alloc: 96.53MB (101216832 bytes)
heap-sys: 256.63MB (269099008 bytes)
heap-idle: 89.41MB (93749248 bytes)
heap-in-use: 167.23MB (175349760 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 683264
stack-in-use: 63.34MB (66420736 bytes)
stack-sys: 63.34MB (66420736 bytes)
stack-mspan-inuse: 2.92MB (3062880 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 849.94KB (870337 bytes)
gc-sys: 6.03MB (6325880 bytes)
next-gc: when heap-alloc >= 211.70MB (221981144 bytes)
last-gc: 2024-10-30 08:23:19.085140249 +0000 UTC
gc-pause-total: 12.262787ms
gc-pause: 94647
gc-pause-end: 1730276599085140249
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004556586000587093
enable-gc: true
debug-gc: false
