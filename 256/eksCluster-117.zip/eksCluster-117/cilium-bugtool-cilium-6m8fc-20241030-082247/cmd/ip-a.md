1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c8:f3:b9:d3:27 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.246.191/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3380sec preferred_lft 3380sec
    inet6 fe80::8c8:f3ff:feb9:d327/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e8:ce:bb:ef:61 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.249.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e8:ceff:febb:ef61/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:85:42:ae:79:e4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c85:42ff:feae:79e4/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:5e:91:82:97:b3 brd ff:ff:ff:ff:ff:ff
    inet 10.117.0.112/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c5e:91ff:fe82:97b3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:ad:29:0f:85:ff brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6cad:29ff:fe0f:85ff/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:92:9c:4c:ac:a9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d892:9cff:fe4c:aca9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc83b1a5c72525@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:ea:ae:83:01:2e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::38ea:aeff:fe83:12e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc38f1deef9101@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:3e:a4:79:79:6f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c03e:a4ff:fe79:796f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc50ae5cae953@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:a9:c7:a2:a0:33 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2ca9:c7ff:fea2:a033/64 scope link 
       valid_lft forever preferred_lft forever
