Endpoint ID: 582
Path: /sys/fs/bpf/tc/globals/cilium_policy_00582

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148141   1697      0        
Allow    Egress      0          ANY          NONE         disabled    18946    211       0        


Endpoint ID: 770
Path: /sys/fs/bpf/tc/globals/cilium_policy_00770

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1040
Path: /sys/fs/bpf/tc/globals/cilium_policy_01040

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11613621   116541    0        
Allow    Ingress     1          ANY          NONE         disabled    11632780   119493    0        
Allow    Egress      0          ANY          NONE         disabled    13911574   136181    0        


Endpoint ID: 1433
Path: /sys/fs/bpf/tc/globals/cilium_policy_01433

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147547   1688      0        
Allow    Egress      0          ANY          NONE         disabled    20365    227       0        


Endpoint ID: 3497
Path: /sys/fs/bpf/tc/globals/cilium_policy_03497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1639390   20734     0        
Allow    Ingress     1          ANY          NONE         disabled    22616     266       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


