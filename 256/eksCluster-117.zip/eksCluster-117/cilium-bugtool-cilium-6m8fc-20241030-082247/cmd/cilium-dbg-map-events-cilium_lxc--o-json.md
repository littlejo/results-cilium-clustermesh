{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.246.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.249.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.840Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.849Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.876Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.918Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.938Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.939Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.939Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.970Z",
  "value": "id=635   sec_id=3882181 flags=0x0000 ifindex=16  mac=26:5F:D9:46:84:AB nodemac=46:08:7D:B1:AE:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.938Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.938Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.938Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.939Z",
  "value": "id=635   sec_id=3882181 flags=0x0000 ifindex=16  mac=26:5F:D9:46:84:AB nodemac=46:08:7D:B1:AE:1E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.925Z",
  "value": "id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.117.0.90:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.585Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.337Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.337Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.338Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.339Z",
  "value": "id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.342Z",
  "value": "id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.348Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.349Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.349Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.340Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.340Z",
  "value": "id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.340Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.341Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.340Z",
  "value": "id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.340Z",
  "value": "id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.340Z",
  "value": "id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.117.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.341Z",
  "value": "id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F"
}

