IP ADDRESS         LOCAL ENDPOINT INFO
10.117.0.231:0     id=582   sec_id=3872992 flags=0x0000 ifindex=12  mac=C6:29:15:99:95:74 nodemac=3A:EA:AE:83:01:2E   
10.117.0.28:0      id=1040  sec_id=3882181 flags=0x0000 ifindex=18  mac=CA:79:A3:2C:A2:46 nodemac=2E:A9:C7:A2:A0:33   
10.117.0.143:0     id=1433  sec_id=3872992 flags=0x0000 ifindex=14  mac=AE:C4:65:88:BC:3B nodemac=C2:3E:A4:79:79:6F   
10.117.0.112:0     (localhost)                                                                                        
172.31.249.223:0   (localhost)                                                                                        
10.117.0.54:0      id=3497  sec_id=4     flags=0x0000 ifindex=10  mac=B6:93:B6:75:9A:18 nodemac=DA:92:9C:4C:AC:A9     
172.31.246.191:0   (localhost)                                                                                        
