ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.144.238:443 (active)    
                                         2 => 172.31.206.170:443 (active)    
2    10.100.190.178:443   ClusterIP      1 => 172.31.246.191:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.117.0.143:53 (active)       
                                         2 => 10.117.0.231:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.117.0.143:9153 (active)     
                                         2 => 10.117.0.231:9153 (active)     
5    10.100.64.205:2379   ClusterIP      1 => 10.117.0.28:2379 (active)      
