key: 01 00 00 00  value: ac 1f 90 ee 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 75 00 e7 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 75 00 e7 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ce aa 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 75 00 1c 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 75 00 8f 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 75 00 8f 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f f6 bf 10 94 00 00  00 00 00 00
Found 8 elements
