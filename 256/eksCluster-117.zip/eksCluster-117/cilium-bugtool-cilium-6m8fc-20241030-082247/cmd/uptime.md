 08:22:48 up 33 min,  0 users,  load average: 0.57, 0.29, 0.17
