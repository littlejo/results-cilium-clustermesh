CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode416240e_692e_4023_bc37_297d76fd52ef.slice/cri-containerd-dd0a251c652923a70dab207d22d3e34b92887c81f7b9ec3ec2f6be893da99f8c.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode416240e_692e_4023_bc37_297d76fd52ef.slice/cri-containerd-6b057b6b22be09d72376ba71721407220d184066106b53dfd43e3f70a81eff3e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b7268c3_d796_4f4c_bbdf_5450195e011f.slice/cri-containerd-d4c8a2dfe04756a73a4690dd529100654df8be51d0f6bd41a96161b9ecc1da34.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b7268c3_d796_4f4c_bbdf_5450195e011f.slice/cri-containerd-ed4f95dae14c7ee1b08c137cec5870b68355492cfa9dfbfb8aa5692f8074af38.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cf2c750_4617_4ffd_b818_7cf0a098c2e1.slice/cri-containerd-06d5c8c0f9ebe6e5235a09843606ae1737c828dc4e5a21556a0d10dbfc954f41.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0cf2c750_4617_4ffd_b818_7cf0a098c2e1.slice/cri-containerd-d79cb45d0484e50aeaea8f35c20f661d26930852e2d2e2112f682b18d1ae2ba2.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1427ec3e_80b4_4576_9744_e7d22eb19112.slice/cri-containerd-6273304e744a0808975a307f605674ac80a1ee3454f3fbf0578172eb72b49c22.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1427ec3e_80b4_4576_9744_e7d22eb19112.slice/cri-containerd-8303265a42bcc404559d550cad07eb6351082596dab77170006baba9ea38e395.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd50ed9d_b8ff_4c40_a4c1_57e7f6a0362c.slice/cri-containerd-da3c720913732b6f2a84f7b630e8eb046ccb0b0f5c0a6ed8b77db1a6aa932aef.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcd50ed9d_b8ff_4c40_a4c1_57e7f6a0362c.slice/cri-containerd-81b6b129a7956ecd5950d1f92638734fd7004e24621a64acd4bc16471ae00566.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15e167f7_c7c6_44d3_af0b_5956d79119f4.slice/cri-containerd-1b8b70bd622d646ff03e09d56f5c6c02f341543de9b6356c417767699eccaf98.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15e167f7_c7c6_44d3_af0b_5956d79119f4.slice/cri-containerd-9f07625915a9cafa24c8d5d6e3beca9cb64beb5b0ab1062a06a17db18c157643.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-40a08e42812cdab0089d0f08b19a95a6c36ea18e4f85a61a15e51376bc70452e.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-4badcd3576d8ebb222db7d28c39368211af9943df0705d13b97e03aae6c7f126.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-4c3c0945b38e31426b0fecd48b53249440644909158033ffbd04536898fc35d5.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda6a56d2_f9f8_41e2_8e9f_534dfbb109e3.slice/cri-containerd-fb7df96541784b06c6ed0b002ecbf20ad31625c7496ebd631684e0b77913c1da.scope
    646      cgroup_device   multi                                          
