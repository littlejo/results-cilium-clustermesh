key: 0e 00 00 00  value: 80 02 00 00
key: 97 06 00 00  value: 1a 02 00 00
key: a7 0c 00 00  value: 20 02 00 00
key: 1f 0f 00 00  value: 2e 02 00 00
Found 4 elements
