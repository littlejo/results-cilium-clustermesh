Endpoint ID: 14
Path: /sys/fs/bpf/tc/globals/cilium_policy_00014

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11167545   109109    0        
Allow    Ingress     1          ANY          NONE         disabled    8858489    92212     0        
Allow    Egress      0          ANY          NONE         disabled    10830363   107979    0        


Endpoint ID: 1156
Path: /sys/fs/bpf/tc/globals/cilium_policy_01156

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1687
Path: /sys/fs/bpf/tc/globals/cilium_policy_01687

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    166087   1913      0        
Allow    Egress      0          ANY          NONE         disabled    20506    228       0        


Endpoint ID: 3239
Path: /sys/fs/bpf/tc/globals/cilium_policy_03239

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    165502   1899      0        
Allow    Egress      0          ANY          NONE         disabled    21272    238       0        


Endpoint ID: 3871
Path: /sys/fs/bpf/tc/globals/cilium_policy_03871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631752   20613     0        
Allow    Ingress     1          ANY          NONE         disabled    24088     280       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


