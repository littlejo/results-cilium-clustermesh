ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.169.200:443 (active)    
                                        2 => 172.31.222.136:443 (active)    
2    10.100.89.121:443   ClusterIP      1 => 172.31.145.117:4244 (active)   
3    10.100.0.10:9153    ClusterIP      1 => 10.102.0.85:9153 (active)      
                                        2 => 10.102.0.184:9153 (active)     
4    10.100.0.10:53      ClusterIP      1 => 10.102.0.85:53 (active)        
                                        2 => 10.102.0.184:53 (active)       
5    10.100.79.49:2379   ClusterIP      1 => 10.102.0.174:2379 (active)     
