35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:47:37+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:38+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:47:41+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:47:47+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:47:47+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:47:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
504: sched_cls  name tail_handle_ipv4  tag 2dbf9ecec63cf14d  gpl
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
505: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
506: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:54:35+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 139
529: sched_cls  name tail_ipv4_ct_ingress  tag f98056df949fd39e  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 165
530: sched_cls  name tail_handle_ipv4  tag 3953f6e71a1da160  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 166
531: sched_cls  name tail_ipv4_to_endpoint  tag 90dcde85dd313a03  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 167
533: sched_cls  name tail_handle_arp  tag 480a98843739c587  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 169
534: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 170
535: sched_cls  name __send_drop_notify  tag 642889b328120c84  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
536: sched_cls  name tail_handle_ipv4_cont  tag 986682ec84123ef0  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 172
537: sched_cls  name tail_ipv4_ct_egress  tag cf5ff637e3331f89  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 173
538: sched_cls  name handle_policy  tag 69e99062e1b761a6  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 174
539: sched_cls  name cil_from_container  tag 4b38dc300710ad0c  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 175
540: sched_cls  name tail_ipv4_to_endpoint  tag 1ac1e6288cb09ea6  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,106,39,114,40,37,38
	btf_id 177
541: sched_cls  name tail_ipv4_ct_ingress  tag 88fffae4427c5e59  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 178
542: sched_cls  name tail_handle_ipv4_cont  tag 8b98f61944db840d  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,106,82,83,39,76,74,77,114,40,37,38,81
	btf_id 179
543: sched_cls  name tail_handle_arp  tag 1bbbc253c19ede66  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 180
544: sched_cls  name handle_policy  tag 33beb08beb5b5f06  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,106,39,84,75,40,37,38
	btf_id 181
545: sched_cls  name tail_handle_ipv4  tag c32f8100b8ea1ad1  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 182
547: sched_cls  name cil_from_container  tag 68c1158f53c9bde3  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 184
548: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 185
549: sched_cls  name tail_ipv4_ct_egress  tag cf5ff637e3331f89  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 186
550: sched_cls  name __send_drop_notify  tag 262a218cbe682afc  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
551: sched_cls  name tail_handle_ipv4_cont  tag 50be1118b413811f  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,115,41,105,82,83,39,76,74,77,116,40,37,38,81
	btf_id 189
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name tail_handle_ipv4  tag fe57214666724e40  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 190
557: sched_cls  name tail_handle_arp  tag b23c56fad252eafa  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 191
558: sched_cls  name handle_policy  tag cbeae3e7ca48e0ab  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,116,82,83,115,41,80,105,39,84,75,40,37,38
	btf_id 192
559: sched_cls  name cil_from_container  tag 5070ede02c90571b  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,76
	btf_id 193
560: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 194
561: sched_cls  name tail_ipv4_ct_ingress  tag a1e80a61a4c93778  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 195
562: sched_cls  name tail_ipv4_to_endpoint  tag 544b71c79597e973  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,115,41,82,83,80,105,39,116,40,37,38
	btf_id 196
564: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 198
565: sched_cls  name __send_drop_notify  tag e2f3d228fe77f22b  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 199
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:38+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
570: sched_cls  name tail_handle_ipv4_from_host  tag d207343045e032f3  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 201
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
572: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,119
	btf_id 203
573: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 204
574: sched_cls  name __send_drop_notify  tag 0bf846e9342529e1  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
579: sched_cls  name tail_handle_ipv4_from_host  tag d207343045e032f3  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 211
580: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 212
582: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 214
583: sched_cls  name __send_drop_notify  tag 0bf846e9342529e1  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
584: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 217
585: sched_cls  name tail_handle_ipv4_from_host  tag d207343045e032f3  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
586: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 219
589: sched_cls  name __send_drop_notify  tag 0bf846e9342529e1  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
591: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 225
594: sched_cls  name __send_drop_notify  tag 0bf846e9342529e1  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 228
596: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 230
597: sched_cls  name tail_handle_ipv4_from_host  tag d207343045e032f3  gpl
	loaded_at 2024-10-30T07:54:39+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 231
637: sched_cls  name tail_ipv4_to_endpoint  tag da2b17a093e08ed5  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 245
638: sched_cls  name tail_ipv4_ct_ingress  tag 239825642c75ecf8  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 246
639: sched_cls  name tail_ipv4_ct_egress  tag 1add5b3c4a1a9265  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 247
640: sched_cls  name handle_policy  tag 8d2f65db9e48aa2e  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 248
641: sched_cls  name tail_handle_arp  tag 25126bb49289f0f0  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 249
642: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 250
643: sched_cls  name __send_drop_notify  tag a786ce6b0bcf10c2  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 251
645: sched_cls  name cil_from_container  tag 7bede4206228f7dd  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 253
646: sched_cls  name tail_handle_ipv4  tag 6bab60d183e1dac5  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 254
647: sched_cls  name tail_handle_ipv4_cont  tag 7642d92ec2afb8f3  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:21+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:21+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
