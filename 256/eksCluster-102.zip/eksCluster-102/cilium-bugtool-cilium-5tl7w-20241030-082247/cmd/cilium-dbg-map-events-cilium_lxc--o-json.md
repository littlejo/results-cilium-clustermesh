{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:31.615Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:34.849Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:38.043Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:38.046Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:38.106Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:38.137Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:38.211Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:48.478Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:48.479Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:48.479Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:48.510Z",
  "value": "id=2906  sec_id=3396214 flags=0x0000 ifindex=16  mac=B6:A9:F8:69:97:63 nodemac=0E:25:3B:A7:9F:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:49.478Z",
  "value": "id=2906  sec_id=3396214 flags=0x0000 ifindex=16  mac=B6:A9:F8:69:97:63 nodemac=0E:25:3B:A7:9F:3A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:49.479Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:49.480Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:49.480Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.872Z",
  "value": "id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.102.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.657Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.777Z",
  "value": "id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.778Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.780Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:08.780Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:09.778Z",
  "value": "id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:09.780Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:09.780Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:09.781Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:10.778Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:10.778Z",
  "value": "id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:10.778Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:10.778Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:11.779Z",
  "value": "id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:11.779Z",
  "value": "id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:11.779Z",
  "value": "id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.102.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:11.780Z",
  "value": "id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25"
}

