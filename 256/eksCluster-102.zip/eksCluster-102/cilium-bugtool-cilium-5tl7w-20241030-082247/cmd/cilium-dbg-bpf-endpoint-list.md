IP ADDRESS         LOCAL ENDPOINT INFO
10.102.0.165:0     (localhost)                                                                                        
172.31.145.117:0   (localhost)                                                                                        
172.31.141.30:0    (localhost)                                                                                        
10.102.0.184:0     id=3239  sec_id=3389125 flags=0x0000 ifindex=14  mac=06:18:3C:D2:76:B2 nodemac=62:64:EE:C8:5D:25   
10.102.0.39:0      id=3871  sec_id=4     flags=0x0000 ifindex=10  mac=9E:4A:20:86:68:B6 nodemac=16:E9:0B:8E:5B:B9     
10.102.0.85:0      id=1687  sec_id=3389125 flags=0x0000 ifindex=12  mac=DA:04:4C:E2:55:0C nodemac=AA:DF:EC:E0:4F:7D   
10.102.0.174:0     id=14    sec_id=3396214 flags=0x0000 ifindex=18  mac=F6:0A:84:CF:83:D9 nodemac=AA:C9:E3:12:02:8A   
