REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33902     2678215     677    bpf_overlay.c
Interface                 INGRESS     608958    128097358   1132   bpf_host.c
Success                   EGRESS      13962     1092345     1694   bpf_host.c
Success                   EGRESS      255410    32566907    1308   bpf_lxc.c
Success                   EGRESS      32740     2594231     53     encap.h
Success                   INGRESS     294635    33113556    86     l3.h
Success                   INGRESS     315226    34743472    235    trace.h
Unsupported L3 protocol   EGRESS      40        2956        1492   bpf_lxc.c
