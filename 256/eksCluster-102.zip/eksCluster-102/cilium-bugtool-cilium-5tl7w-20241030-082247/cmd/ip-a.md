1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b5:ef:36:a6:61 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.145.117/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3295sec preferred_lft 3295sec
    inet6 fe80::4b5:efff:fe36:a661/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a9:40:7e:50:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.141.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4a9:40ff:fe7e:508b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:43:1b:2a:28:aa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c843:1bff:fe2a:28aa/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:8e:3f:7e:77:b3 brd ff:ff:ff:ff:ff:ff
    inet 10.102.0.165/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::948e:3fff:fe7e:77b3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:04:26:b1:ce:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc04:26ff:feb1:ce8a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:e9:0b:8e:5b:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::14e9:bff:fe8e:5bb9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcceb83f4e34c3@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:df:ec:e0:4f:7d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a8df:ecff:fee0:4f7d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc236396e90596@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:64:ee:c8:5d:25 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6064:eeff:fec8:5d25/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2679dbeb0520@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:c9:e3:12:02:8a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a8c9:e3ff:fe12:28a/64 scope link 
       valid_lft forever preferred_lft forever
