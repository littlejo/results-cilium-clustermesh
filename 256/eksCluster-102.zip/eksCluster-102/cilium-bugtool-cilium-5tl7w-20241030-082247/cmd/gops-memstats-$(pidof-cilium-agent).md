alloc: 191.12MB (200402536 bytes)
total-alloc: 2.19GB (2350872416 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62257633
frees: 60280241
heap-alloc: 191.12MB (200402536 bytes)
heap-sys: 251.33MB (263536640 bytes)
heap-idle: 30.59MB (32071680 bytes)
heap-in-use: 220.74MB (231464960 bytes)
heap-released: 1.34MB (1409024 bytes)
heap-objects: 1977392
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 3.44MB (3610720 bytes)
stack-mspan-sys: 3.92MB (4112640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 905.34KB (927073 bytes)
gc-sys: 6.04MB (6338096 bytes)
next-gc: when heap-alloc >= 218.30MB (228903624 bytes)
last-gc: 2024-10-30 08:22:48.871613099 +0000 UTC
gc-pause-total: 17.487051ms
gc-pause: 348075
gc-pause-end: 1730276568871613099
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003749695093407181
enable-gc: true
debug-gc: false
