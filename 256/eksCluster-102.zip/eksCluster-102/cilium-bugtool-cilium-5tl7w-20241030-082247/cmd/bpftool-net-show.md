xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 584
ens6(5) clsact/ingress cil_from_netdev-ens6 id 596
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 582
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 573
cilium_host(7) clsact/egress cil_from_host-cilium_host id 572
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 505
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 506
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 559
lxcceb83f4e34c3(12) clsact/ingress cil_from_container-lxcceb83f4e34c3 id 539
lxc236396e90596(14) clsact/ingress cil_from_container-lxc236396e90596 id 547
lxc2679dbeb0520(18) clsact/ingress cil_from_container-lxc2679dbeb0520 id 645

flow_dissector:

netfilter:

