[
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8acad6f_e1cc_4850_bef9_40656e99722d.slice/cri-containerd-f3f816221f5c6ad100a3a6864d21a1c7dc861d28e361c7d9565d7e892594b3df.scope"
      }
    ],
    "ips": [
      "10.102.0.85"
    ],
    "name": "coredns-cc6ccd49c-7nnm4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5adc5690_6975_485f_9b79_c21aac6bddf7.slice/cri-containerd-9e725e093869c92fbaa1b53ea9f419fb18d868e566b82567b70a222e81de76a5.scope"
      }
    ],
    "ips": [
      "10.102.0.184"
    ],
    "name": "coredns-cc6ccd49c-dmtq7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-c0dd8d8c08791dd4b80b8d0fa24ba3db551eae32129c091d10fc6962e3858421.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-7ceb6b5a168dd9c678cb21eaac7ae254056ab2b738301b82c7356dc9f56fdb58.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-caa2b8846d6227ce634c65765e65bc1a355344c6146bebc60b865bd7f6cd498c.scope"
      }
    ],
    "ips": [
      "10.102.0.174"
    ],
    "name": "clustermesh-apiserver-7df78c7475-vwxtt",
    "namespace": "kube-system"
  }
]

