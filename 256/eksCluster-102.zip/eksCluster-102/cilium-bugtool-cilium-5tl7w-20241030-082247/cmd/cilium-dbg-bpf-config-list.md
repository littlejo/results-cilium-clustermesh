KEY             VALUE
AgentLiveness   2146175462788
UTimeOffset     3379442292968750
