CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8865932a_ea2f_413f_b075_514fb9674770.slice/cri-containerd-2b5964f4dd4ee4369f003d382c2655b3abbf07a4bb64fae84338dd84f2e8f448.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8865932a_ea2f_413f_b075_514fb9674770.slice/cri-containerd-427a47d0a5baf99bbeaa01151c6add4bcbaa19e8bb0954f6c2e8a6ed223c3d60.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8acad6f_e1cc_4850_bef9_40656e99722d.slice/cri-containerd-f3f816221f5c6ad100a3a6864d21a1c7dc861d28e361c7d9565d7e892594b3df.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8acad6f_e1cc_4850_bef9_40656e99722d.slice/cri-containerd-5a6a85b11487fd8f7b7e42577f03b0c9384f3a3163077b6debc18165f88285b4.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9570de72_0764_4af4_8f63_fa8621ba2eda.slice/cri-containerd-5346b70fd950a9f36c6f33c1a6a3c6491c75fd40c99fa05db10d9cce73a46c98.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9570de72_0764_4af4_8f63_fa8621ba2eda.slice/cri-containerd-2d43c400fd2ada33313b83f7db99d3309e3f680373595d12d249de6f253c0164.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5adc5690_6975_485f_9b79_c21aac6bddf7.slice/cri-containerd-9e725e093869c92fbaa1b53ea9f419fb18d868e566b82567b70a222e81de76a5.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5adc5690_6975_485f_9b79_c21aac6bddf7.slice/cri-containerd-4028648d87ca384f26d67225d9aac90e8dcba9ae39e8cb6e768fea78e448a44a.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2dd1a872_7865_400d_927a_b3213f9edb84.slice/cri-containerd-84015c5b8761ba8d0c34a1ecaf0a0c42486a977620e18feac47097dc269db6c3.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2dd1a872_7865_400d_927a_b3213f9edb84.slice/cri-containerd-128973445bed8d71075ef49822905fdcef8e95e00a12521e0810ebaec18f1be6.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eaae57d_affb_4b65_862d_4055495cca78.slice/cri-containerd-8e3bc4f372030a6ac7f3a368fe7f1fed3d8f91520b7383df36151a3be24d1f5c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9eaae57d_affb_4b65_862d_4055495cca78.slice/cri-containerd-7609472ebae06731f7514fda96ea74c4ce3600fa59ab30da3cefbdc748d4847c.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-caa2b8846d6227ce634c65765e65bc1a355344c6146bebc60b865bd7f6cd498c.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-7ceb6b5a168dd9c678cb21eaac7ae254056ab2b738301b82c7356dc9f56fdb58.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-60a1159371bd7227ad836647fb9f4d6070be032e1285c19e334943555af89de7.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4d61f196_2672_4ff4_b199_2334df007284.slice/cri-containerd-c0dd8d8c08791dd4b80b8d0fa24ba3db551eae32129c091d10fc6962e3858421.scope
    671      cgroup_device   multi                                          
