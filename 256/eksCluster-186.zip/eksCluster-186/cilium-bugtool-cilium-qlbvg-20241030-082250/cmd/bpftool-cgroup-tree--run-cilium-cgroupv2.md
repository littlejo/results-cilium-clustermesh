CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e6164df_8d5d_40ff_9c83_afd45d8296de.slice/cri-containerd-f191debf3477826807788728be3009fb9162e57f5d8d8af68f0039d68c5f70bc.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e6164df_8d5d_40ff_9c83_afd45d8296de.slice/cri-containerd-c84e1891a81571898d359cd9d3ba99e5fca9bed1dc474987280e9dc093eb4986.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f3b8a00_8acc_4ffb_a155_9fcdb4177fd4.slice/cri-containerd-b550617da549ec51c3fac96ac5ab75c1ecb662db7020681b9377737d173bc9f0.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1f3b8a00_8acc_4ffb_a155_9fcdb4177fd4.slice/cri-containerd-6a15ff3b37d9ae8c6aa363f0c4329e7f1d4c97662655f7a5d30a92a40ebb5992.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac201c0d_cb16_4e44_bffe_c4bd1412cf68.slice/cri-containerd-b16029998d9908a2c71496753742f08bc3ce7222427e9eb1420941a316ab08b9.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac201c0d_cb16_4e44_bffe_c4bd1412cf68.slice/cri-containerd-0ae699c705d81c1491a6d410dc3a1197404a36b270d5d42a2d7b873861ade47f.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c3ada9_a158_4d6d_b8ac_0fcdf17a71c6.slice/cri-containerd-3850e34ccbeca1a3072e98e7a8889b15ff9797f79569cb763a82702cc8a1fc8f.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c3ada9_a158_4d6d_b8ac_0fcdf17a71c6.slice/cri-containerd-64a99998f571648cb504fc7538ecf9e725d9ae3fb57a7c2db3df72293c78b87f.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5752824f_1657_4659_b58d_4379ea7e2fe7.slice/cri-containerd-27cb4dcec967dccf5f5b4c4d55804153ea094cdc3ba5df03d992e62187908aed.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5752824f_1657_4659_b58d_4379ea7e2fe7.slice/cri-containerd-3e844822b463ebd14dccc2b19fd1ccb23718458768f70e4e1a9a843746f1ba10.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87713e16_e74f_4dc1_90e1_97a052a8c063.slice/cri-containerd-173fe720cd52d78940c40254ca2e59f6818ad428098b777052b3f576c7bf3456.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod87713e16_e74f_4dc1_90e1_97a052a8c063.slice/cri-containerd-1ba70cc4363dede973caa7b287c7baa8c75d74fcc1644db4e1086c99cedce548.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-85fecada5a9db5f0c2cde84027d0781592ce515613e1f031abcc554f8560437e.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-3ca8cb82446838dff9ebf8de16af65f8aff00a9527951cc62351e7804f08f4e2.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-ec473695eae99c8855011fdf62eb65039c52a12208d52b95ad685ec5201bbfef.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-dd8d0658b4ae89c7cd94d78dc220edf0805dc01405990e785428c29cea627326.scope
    670      cgroup_device   multi                                          
