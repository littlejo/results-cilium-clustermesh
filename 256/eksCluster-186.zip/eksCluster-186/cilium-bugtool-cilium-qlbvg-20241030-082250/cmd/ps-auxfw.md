USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         686  0.0  0.2 1240432 16384 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         703  0.0  0.0   2068   228 ?        R    08:22   0:00  \_ hostname
root         677  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         667  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         653  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         646  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.5  4.7 1606080 380328 ?      Ssl  08:02   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.0  0.0 1229744 7956 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
