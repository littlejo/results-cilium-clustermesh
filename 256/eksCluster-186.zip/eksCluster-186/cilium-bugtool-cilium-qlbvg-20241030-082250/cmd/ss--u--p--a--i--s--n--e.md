Total: 662
TCP:   1855 (estab 427, closed 1409, orphaned 0, timewait 574)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  446       435       11       
INET	  456       441       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:37185 sk:1001 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15363 sk:1002 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                           127.0.0.1:45617      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=37)) ino:36415 sk:1003 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.180.46%ens5:68         0.0.0.0:*    uid:192 ino:88268 sk:1004 cgroup:unreachable:c4e <->                            
UNCONN 0      0                                [::]:8472          [::]:*    ino:37184 sk:1005 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15364 sk:1006 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::47d:70ff:fe96:8fb]%ens5:546           [::]:*    uid:192 ino:16478 sk:1007 cgroup:unreachable:c4e v6only:1 <->                   
