[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-3ca8cb82446838dff9ebf8de16af65f8aff00a9527951cc62351e7804f08f4e2.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-dd8d0658b4ae89c7cd94d78dc220edf0805dc01405990e785428c29cea627326.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7681198f_bb73_4b0a_bfe0_aacb4a632bdd.slice/cri-containerd-85fecada5a9db5f0c2cde84027d0781592ce515613e1f031abcc554f8560437e.scope"
      }
    ],
    "ips": [
      "10.186.0.252"
    ],
    "name": "clustermesh-apiserver-56794b9bdf-bl2d8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5c3ada9_a158_4d6d_b8ac_0fcdf17a71c6.slice/cri-containerd-3850e34ccbeca1a3072e98e7a8889b15ff9797f79569cb763a82702cc8a1fc8f.scope"
      }
    ],
    "ips": [
      "10.186.0.5"
    ],
    "name": "coredns-cc6ccd49c-z97n9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac201c0d_cb16_4e44_bffe_c4bd1412cf68.slice/cri-containerd-0ae699c705d81c1491a6d410dc3a1197404a36b270d5d42a2d7b873861ade47f.scope"
      }
    ],
    "ips": [
      "10.186.0.96"
    ],
    "name": "coredns-cc6ccd49c-gm8g8",
    "namespace": "kube-system"
  }
]

