IP ADDRESS        LOCAL ENDPOINT INFO
172.31.180.46:0   (localhost)                                                                                        
10.186.0.116:0    (localhost)                                                                                        
10.186.0.41:0     id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76     
10.186.0.96:0     id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70   
10.186.0.5:0      id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7   
172.31.149.46:0   (localhost)                                                                                        
10.186.0.252:0    id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F   
