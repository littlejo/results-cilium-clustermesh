key: f2 08 00 00  value: 83 02 00 00
key: 7c 0b 00 00  value: 3d 02 00 00
key: 3c 0d 00 00  value: 09 02 00 00
key: 4b 0e 00 00  value: 47 02 00 00
Found 4 elements
