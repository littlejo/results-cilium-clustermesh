Endpoint ID: 2290
Path: /sys/fs/bpf/tc/globals/cilium_policy_02290

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11384922   112226    0        
Allow    Ingress     1          ANY          NONE         disabled    9212586    96234     0        
Allow    Egress      0          ANY          NONE         disabled    11603250   115341    0        


Endpoint ID: 2940
Path: /sys/fs/bpf/tc/globals/cilium_policy_02940

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    571834   5134      0        
Allow    Ingress     1          ANY          NONE         disabled    117639   1350      0        
Allow    Egress      0          ANY          NONE         disabled    120848   1153      0        


Endpoint ID: 3388
Path: /sys/fs/bpf/tc/globals/cilium_policy_03388

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    565136   5074      0        
Allow    Ingress     1          ANY          NONE         disabled    117884   1350      0        
Allow    Egress      0          ANY          NONE         disabled    120878   1155      0        


Endpoint ID: 3659
Path: /sys/fs/bpf/tc/globals/cilium_policy_03659

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641066   20732     0        
Allow    Ingress     1          ANY          NONE         disabled    18048     212       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 4082
Path: /sys/fs/bpf/tc/globals/cilium_policy_04082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


