1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:7d:70:96:08:fb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.180.46/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3574sec preferred_lft 3574sec
    inet6 fe80::47d:70ff:fe96:8fb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:50:4a:65:91:11 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.149.46/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::450:4aff:fe65:9111/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:e8:d2:6c:10:29 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::18e8:d2ff:fe6c:1029/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:ea:a2:76:7c:d4 brd ff:ff:ff:ff:ff:ff
    inet 10.186.0.116/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::fcea:a2ff:fe76:7cd4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:80:2b:d7:43:be brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1080:2bff:fed7:43be/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:36:b5:d5:f6:76 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d836:b5ff:fed5:f676/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0fccd7caf5e8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:5d:d6:0f:25:70 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::585d:d6ff:fe0f:2570/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0e67edb9d308@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:6c:13:7e:02:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::386c:13ff:fe7e:2f7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdc15fceba433@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:15:94:ca:cf:7f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e015:94ff:feca:cf7f/64 scope link 
       valid_lft forever preferred_lft forever
