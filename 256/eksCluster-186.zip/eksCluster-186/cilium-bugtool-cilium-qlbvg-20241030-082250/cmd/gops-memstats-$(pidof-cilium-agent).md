alloc: 119.08MB (124860864 bytes)
total-alloc: 2.22GB (2383099632 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63226973
frees: 62498870
heap-alloc: 119.08MB (124860864 bytes)
heap-sys: 251.86MB (264093696 bytes)
heap-idle: 67.16MB (70426624 bytes)
heap-in-use: 184.70MB (193667072 bytes)
heap-released: 2.65MB (2777088 bytes)
heap-objects: 728103
stack-in-use: 60.09MB (63012864 bytes)
stack-sys: 60.09MB (63012864 bytes)
stack-mspan-inuse: 2.89MB (3025280 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 959.25KB (982273 bytes)
gc-sys: 6.04MB (6336024 bytes)
next-gc: when heap-alloc >= 213.03MB (223380520 bytes)
last-gc: 2024-10-30 08:23:18.503343542 +0000 UTC
gc-pause-total: 19.65976ms
gc-pause: 64829
gc-pause-end: 1730276598503343542
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00042921960127943905
enable-gc: true
debug-gc: false
