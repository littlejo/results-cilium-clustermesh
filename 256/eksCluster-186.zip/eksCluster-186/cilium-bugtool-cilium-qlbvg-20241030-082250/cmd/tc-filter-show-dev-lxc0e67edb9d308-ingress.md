filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0e67edb9d308 direct-action not_in_hw id 543 tag aa139d50607decdc jited 
