{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.505Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.505Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.180.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.505Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:30.969Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:30.977Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:31.022Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:31.051Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.095Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.096Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.097Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:16.127Z",
  "value": "id=95    sec_id=6157533 flags=0x0000 ifindex=16  mac=A6:55:D7:FC:5B:99 nodemac=02:9E:49:A0:1A:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:17.096Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:17.097Z",
  "value": "id=95    sec_id=6157533 flags=0x0000 ifindex=16  mac=A6:55:D7:FC:5B:99 nodemac=02:9E:49:A0:1A:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:17.097Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:17.097Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.069Z",
  "value": "id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.186.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.601Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.838Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.838Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.838Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.839Z",
  "value": "id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.834Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.835Z",
  "value": "id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.835Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.836Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.832Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.832Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.832Z",
  "value": "id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.832Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.832Z",
  "value": "id=3659  sec_id=4     flags=0x0000 ifindex=10  mac=1E:BA:F4:37:3C:C1 nodemac=DA:36:B5:D5:F6:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.832Z",
  "value": "id=2290  sec_id=6157533 flags=0x0000 ifindex=18  mac=72:C8:23:DF:4E:A4 nodemac=E2:15:94:CA:CF:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.832Z",
  "value": "id=3388  sec_id=6149687 flags=0x0000 ifindex=12  mac=9A:C6:C6:86:31:30 nodemac=5A:5D:D6:0F:25:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.186.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.833Z",
  "value": "id=2940  sec_id=6149687 flags=0x0000 ifindex=14  mac=72:3D:27:30:DE:20 nodemac=3A:6C:13:7E:02:F7"
}

