xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 561
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 549
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 548
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxc0fccd7caf5e8(12) clsact/ingress cil_from_container-lxc0fccd7caf5e8 id 529
lxc0e67edb9d308(14) clsact/ingress cil_from_container-lxc0e67edb9d308 id 543
lxcdc15fceba433(18) clsact/ingress cil_from_container-lxcdc15fceba433 id 641

flow_dissector:

netfilter:

