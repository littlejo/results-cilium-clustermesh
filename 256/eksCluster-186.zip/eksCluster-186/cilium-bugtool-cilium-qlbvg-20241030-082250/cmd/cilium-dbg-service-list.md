ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.162.159:443 (active)   
                                         2 => 172.31.220.8:443 (active)     
2    10.100.145.175:443   ClusterIP      1 => 172.31.180.46:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.186.0.96:53 (active)       
                                         2 => 10.186.0.5:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.186.0.96:9153 (active)     
                                         2 => 10.186.0.5:9153 (active)      
5    10.100.38.223:2379   ClusterIP      1 => 10.186.0.252:2379 (active)    
