KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.186.0.0/24, 
Allocated addresses:
  10.186.0.116 (router)
  10.186.0.252 (kube-system/clustermesh-apiserver-56794b9bdf-bl2d8)
  10.186.0.41 (health)
  10.186.0.5 (kube-system/coredns-cc6ccd49c-z97n9)
  10.186.0.96 (kube-system/coredns-cc6ccd49c-gm8g8)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: 3267d79a0bdd686e
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    57s ago        never        0       no error   
  ct-map-pressure                                                     28s ago        never        0       no error   
  daemon-validate-config                                              38s ago        never        0       no error   
  dns-garbage-collector-job                                           1m1s ago       never        0       no error   
  endpoint-2290-regeneration-recovery                                 never          never        0       no error   
  endpoint-2940-regeneration-recovery                                 never          never        0       no error   
  endpoint-3388-regeneration-recovery                                 never          never        0       no error   
  endpoint-3659-regeneration-recovery                                 never          never        0       no error   
  endpoint-4082-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                         1m2s ago       never        0       no error   
  ep-bpf-prog-watchdog                                                28s ago        never        0       no error   
  ipcache-inject-labels                                               58s ago        never        0       no error   
  k8s-heartbeat                                                       32s ago        never        0       no error   
  link-cache                                                          13s ago        never        0       no error   
  local-identity-checkpoint                                           20m58s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh10                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh100                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh101                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh102                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh103                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh104                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh105                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh106                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh107                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh108                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh109                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh11                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh110                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh111                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh112                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh113                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh114                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh115                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh116                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh117                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh118                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh119                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh12                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh120                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh121                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh122                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh123                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh124                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh125                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh126                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh127                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh128                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh129                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh13                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh130                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh131                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh132                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh133                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh134                                                10m40s ago     never        0       no error   
  remote-etcd-cmesh135                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh136                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh137                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh138                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh139                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh14                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh140                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh141                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh142                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh143                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh144                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh145                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh146                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh147                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh148                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh149                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh15                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh150                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh151                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh152                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh153                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh154                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh155                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh156                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh157                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh158                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh159                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh16                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh160                                                10m40s ago     never        0       no error   
  remote-etcd-cmesh161                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh162                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh163                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh164                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh165                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh166                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh167                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh168                                                10m40s ago     never        0       no error   
  remote-etcd-cmesh169                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh17                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh170                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh171                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh172                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh173                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh174                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh175                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh176                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh177                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh178                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh179                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh18                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh180                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh181                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh182                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh183                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh184                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh185                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh186                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh188                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh189                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh19                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh190                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh191                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh192                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh193                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh194                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh195                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh196                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh197                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh198                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh199                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh2                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh20                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh200                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh201                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh202                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh203                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh204                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh205                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh206                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh207                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh208                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh209                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh21                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh210                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh211                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh212                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh213                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh214                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh215                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh216                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh217                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh218                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh219                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh22                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh220                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh221                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh222                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh223                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh224                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh225                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh226                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh227                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh228                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh229                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh23                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh230                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh231                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh232                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh233                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh234                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh235                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh236                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh237                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh238                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh239                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh24                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh240                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh241                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh242                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh243                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh244                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh245                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh246                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh247                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh248                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh249                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh25                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh250                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh251                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh252                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh253                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh254                                                10m38s ago     never        0       no error   
  remote-etcd-cmesh255                                                10m39s ago     never        0       no error   
  remote-etcd-cmesh256                                                10m40s ago     never        0       no error   
  remote-etcd-cmesh26                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh27                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh28                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh29                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh3                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh30                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh31                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh32                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh33                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh34                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh35                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh36                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh37                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh38                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh39                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh4                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh40                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh41                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh42                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh43                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh44                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh45                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh46                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh47                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh48                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh49                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh5                                                  10m39s ago     never        0       no error   
  remote-etcd-cmesh50                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh51                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh52                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh53                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh54                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh55                                                 10m40s ago     never        0       no error   
  remote-etcd-cmesh56                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh57                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh58                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh59                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh6                                                  10m39s ago     never        0       no error   
  remote-etcd-cmesh60                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh61                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh62                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh63                                                 10m40s ago     never        0       no error   
  remote-etcd-cmesh64                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh65                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh66                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh67                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh68                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh69                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh7                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh70                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh71                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh72                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh73                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh74                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh75                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh76                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh77                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh78                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh79                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh8                                                  10m39s ago     never        0       no error   
  remote-etcd-cmesh80                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh81                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh82                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh83                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh84                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh85                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh86                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh87                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh88                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh89                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh9                                                  10m38s ago     never        0       no error   
  remote-etcd-cmesh90                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh91                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh92                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh93                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh94                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh95                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh96                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh97                                                 10m39s ago     never        0       no error   
  remote-etcd-cmesh98                                                 10m38s ago     never        0       no error   
  remote-etcd-cmesh99                                                 10m38s ago     never        0       no error   
  resolve-identity-2290                                               1m35s ago      never        0       no error   
  resolve-identity-2940                                               56s ago        never        0       no error   
  resolve-identity-3388                                               56s ago        never        0       no error   
  resolve-identity-3659                                               57s ago        never        0       no error   
  resolve-identity-4082                                               58s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-56794b9bdf-bl2d8   11m35s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-gm8g8                  20m56s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-z97n9                  20m56s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      20m58s ago     never        0       no error   
  sync-policymap-2290                                                 11m35s ago     never        0       no error   
  sync-policymap-2940                                                 5m54s ago      never        0       no error   
  sync-policymap-3388                                                 5m54s ago      never        0       no error   
  sync-policymap-3659                                                 5m54s ago      never        0       no error   
  sync-policymap-4082                                                 5m57s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (2290)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2940)                                   6s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (3388)                                   6s ago         never        0       no error   
  sync-utime                                                          58s ago        never        0       no error   
  write-cni-file                                                      21m2s ago      never        0       no error   
Proxy Status:            OK, ip 10.186.0.116, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 6127616, max 6160383
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 168.84   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:                                                          Disabled           
Cluster health:                                                      38/256 reachable   (2024-10-30T08:22:28Z)
  Name                                                               IP                 Node          Endpoints
  cmesh187/ip-172-31-180-46.eu-west-3.compute.internal (localhost)   172.31.180.46      reachable     unreachable
  cmesh1/ip-172-31-129-111.eu-west-3.compute.internal                172.31.129.111     unreachable   unreachable
  cmesh10/ip-172-31-238-115.eu-west-3.compute.internal               172.31.238.115     unreachable   unreachable
  cmesh100/ip-172-31-202-187.eu-west-3.compute.internal              172.31.202.187     unreachable   unreachable
  cmesh101/ip-172-31-156-41.eu-west-3.compute.internal               172.31.156.41      unreachable   reachable
  cmesh102/ip-172-31-255-237.eu-west-3.compute.internal              172.31.255.237     reachable     unreachable
  cmesh103/ip-172-31-145-117.eu-west-3.compute.internal              172.31.145.117     reachable     unreachable
  cmesh104/ip-172-31-251-68.eu-west-3.compute.internal               172.31.251.68      reachable     reachable
  cmesh105/ip-172-31-177-69.eu-west-3.compute.internal               172.31.177.69      reachable     unreachable
  cmesh106/ip-172-31-250-86.eu-west-3.compute.internal               172.31.250.86      unreachable   reachable
  cmesh107/ip-172-31-181-183.eu-west-3.compute.internal              172.31.181.183     reachable     unreachable
  cmesh108/ip-172-31-214-227.eu-west-3.compute.internal              172.31.214.227     reachable     unreachable
  cmesh109/ip-172-31-170-46.eu-west-3.compute.internal               172.31.170.46      unreachable   reachable
  cmesh11/ip-172-31-144-15.eu-west-3.compute.internal                172.31.144.15      unreachable   reachable
  cmesh110/ip-172-31-242-123.eu-west-3.compute.internal              172.31.242.123     reachable     unreachable
  cmesh111/ip-172-31-152-250.eu-west-3.compute.internal              172.31.152.250     reachable     unreachable
  cmesh112/ip-172-31-199-216.eu-west-3.compute.internal              172.31.199.216     unreachable   reachable
  cmesh113/ip-172-31-145-79.eu-west-3.compute.internal               172.31.145.79      unreachable   unreachable
  cmesh114/ip-172-31-234-247.eu-west-3.compute.internal              172.31.234.247     unreachable   reachable
  cmesh115/ip-172-31-187-38.eu-west-3.compute.internal               172.31.187.38      reachable     unreachable
  cmesh116/ip-172-31-254-132.eu-west-3.compute.internal              172.31.254.132     reachable     unreachable
  cmesh117/ip-172-31-150-111.eu-west-3.compute.internal              172.31.150.111     unreachable   unreachable
  cmesh118/ip-172-31-246-191.eu-west-3.compute.internal              172.31.246.191     reachable     unreachable
  cmesh119/ip-172-31-160-70.eu-west-3.compute.internal               172.31.160.70      unreachable   unreachable
  cmesh12/ip-172-31-201-141.eu-west-3.compute.internal               172.31.201.141     reachable     reachable
  cmesh120/ip-172-31-192-187.eu-west-3.compute.internal              172.31.192.187     unreachable   unreachable
  cmesh121/ip-172-31-138-53.eu-west-3.compute.internal               172.31.138.53      reachable     unreachable
  cmesh122/ip-172-31-197-64.eu-west-3.compute.internal               172.31.197.64      reachable     unreachable
  cmesh123/ip-172-31-138-178.eu-west-3.compute.internal              172.31.138.178     unreachable   reachable
  cmesh124/ip-172-31-210-31.eu-west-3.compute.internal               172.31.210.31      unreachable   unreachable
  cmesh125/ip-172-31-149-67.eu-west-3.compute.internal               172.31.149.67      unreachable   reachable
  cmesh126/ip-172-31-225-47.eu-west-3.compute.internal               172.31.225.47      unreachable   reachable
  cmesh127/ip-172-31-190-244.eu-west-3.compute.internal              172.31.190.244     unreachable   unreachable
  cmesh128/ip-172-31-197-3.eu-west-3.compute.internal                172.31.197.3       reachable     unreachable
  cmesh129/ip-172-31-189-76.eu-west-3.compute.internal               172.31.189.76      unreachable   reachable
  cmesh13/ip-172-31-151-115.eu-west-3.compute.internal               172.31.151.115     unreachable   unreachable
  cmesh130/ip-172-31-202-148.eu-west-3.compute.internal              172.31.202.148     unreachable   reachable
  cmesh131/ip-172-31-130-213.eu-west-3.compute.internal              172.31.130.213     unreachable   reachable
  cmesh132/ip-172-31-208-241.eu-west-3.compute.internal              172.31.208.241     reachable     unreachable
  cmesh133/ip-172-31-154-190.eu-west-3.compute.internal              172.31.154.190     reachable     unreachable
  cmesh134/ip-172-31-198-209.eu-west-3.compute.internal              172.31.198.209     reachable     unreachable
  cmesh135/ip-172-31-128-28.eu-west-3.compute.internal               172.31.128.28      reachable     unreachable
  cmesh136/ip-172-31-197-13.eu-west-3.compute.internal               172.31.197.13      unreachable   reachable
  cmesh137/ip-172-31-140-38.eu-west-3.compute.internal               172.31.140.38      unreachable   unreachable
  cmesh138/ip-172-31-240-43.eu-west-3.compute.internal               172.31.240.43      unreachable   unreachable
  cmesh139/ip-172-31-148-213.eu-west-3.compute.internal              172.31.148.213     reachable     reachable
  cmesh14/ip-172-31-193-152.eu-west-3.compute.internal               172.31.193.152     unreachable   unreachable
  cmesh140/ip-172-31-192-199.eu-west-3.compute.internal              172.31.192.199     unreachable   reachable
  cmesh141/ip-172-31-184-128.eu-west-3.compute.internal              172.31.184.128     unreachable   unreachable
  cmesh142/ip-172-31-219-42.eu-west-3.compute.internal               172.31.219.42      unreachable   unreachable
  cmesh143/ip-172-31-136-110.eu-west-3.compute.internal              172.31.136.110     reachable     unreachable
  cmesh144/ip-172-31-222-170.eu-west-3.compute.internal              172.31.222.170     reachable     reachable
  cmesh145/ip-172-31-132-52.eu-west-3.compute.internal               172.31.132.52      unreachable   unreachable
  cmesh146/ip-172-31-238-193.eu-west-3.compute.internal              172.31.238.193     unreachable   reachable
  cmesh147/ip-172-31-159-14.eu-west-3.compute.internal               172.31.159.14      unreachable   reachable
  cmesh148/ip-172-31-255-51.eu-west-3.compute.internal               172.31.255.51      reachable     unreachable
  cmesh149/ip-172-31-175-74.eu-west-3.compute.internal               172.31.175.74      reachable     reachable
  cmesh15/ip-172-31-145-58.eu-west-3.compute.internal                172.31.145.58      unreachable   unreachable
  cmesh150/ip-172-31-201-166.eu-west-3.compute.internal              172.31.201.166     unreachable   unreachable
  cmesh151/ip-172-31-190-101.eu-west-3.compute.internal              172.31.190.101     unreachable   unreachable
  cmesh152/ip-172-31-210-247.eu-west-3.compute.internal              172.31.210.247     reachable     unreachable
  cmesh153/ip-172-31-190-51.eu-west-3.compute.internal               172.31.190.51      reachable     reachable
  cmesh154/ip-172-31-218-179.eu-west-3.compute.internal              172.31.218.179     unreachable   unreachable
  cmesh155/ip-172-31-143-150.eu-west-3.compute.internal              172.31.143.150     unreachable   reachable
  cmesh156/ip-172-31-224-54.eu-west-3.compute.internal               172.31.224.54      unreachable   reachable
  cmesh157/ip-172-31-161-63.eu-west-3.compute.internal               172.31.161.63      reachable     reachable
  cmesh158/ip-172-31-194-176.eu-west-3.compute.internal              172.31.194.176     unreachable   unreachable
  cmesh159/ip-172-31-137-12.eu-west-3.compute.internal               172.31.137.12      unreachable   unreachable
  cmesh16/ip-172-31-241-253.eu-west-3.compute.internal               172.31.241.253     unreachable   unreachable
  cmesh160/ip-172-31-243-44.eu-west-3.compute.internal               172.31.243.44      unreachable   unreachable
  cmesh161/ip-172-31-169-97.eu-west-3.compute.internal               172.31.169.97      unreachable   unreachable
  cmesh162/ip-172-31-233-29.eu-west-3.compute.internal               172.31.233.29      reachable     unreachable
  cmesh163/ip-172-31-164-49.eu-west-3.compute.internal               172.31.164.49      unreachable   reachable
  cmesh164/ip-172-31-234-82.eu-west-3.compute.internal               172.31.234.82      unreachable   unreachable
  cmesh165/ip-172-31-132-35.eu-west-3.compute.internal               172.31.132.35      unreachable   reachable
  cmesh166/ip-172-31-217-164.eu-west-3.compute.internal              172.31.217.164     unreachable   reachable
  cmesh167/ip-172-31-178-44.eu-west-3.compute.internal               172.31.178.44      unreachable   unreachable
  cmesh168/ip-172-31-214-172.eu-west-3.compute.internal              172.31.214.172     reachable     unreachable
  cmesh169/ip-172-31-152-47.eu-west-3.compute.internal               172.31.152.47      unreachable   unreachable
  cmesh17/ip-172-31-143-246.eu-west-3.compute.internal               172.31.143.246     unreachable   unreachable
  cmesh170/ip-172-31-230-34.eu-west-3.compute.internal               172.31.230.34      unreachable   unreachable
  cmesh171/ip-172-31-186-20.eu-west-3.compute.internal               172.31.186.20      unreachable   unreachable
  cmesh172/ip-172-31-197-244.eu-west-3.compute.internal              172.31.197.244     unreachable   reachable
  cmesh173/ip-172-31-136-100.eu-west-3.compute.internal              172.31.136.100     unreachable   unreachable
  cmesh174/ip-172-31-231-64.eu-west-3.compute.internal               172.31.231.64      unreachable   unreachable
  cmesh175/ip-172-31-129-133.eu-west-3.compute.internal              172.31.129.133     reachable     reachable
  cmesh176/ip-172-31-192-97.eu-west-3.compute.internal               172.31.192.97      unreachable   reachable
  cmesh177/ip-172-31-181-74.eu-west-3.compute.internal               172.31.181.74      reachable     reachable
  cmesh178/ip-172-31-201-97.eu-west-3.compute.internal               172.31.201.97      reachable     unreachable
  cmesh179/ip-172-31-169-181.eu-west-3.compute.internal              172.31.169.181     reachable     unreachable
  cmesh18/ip-172-31-194-203.eu-west-3.compute.internal               172.31.194.203     unreachable   unreachable
  cmesh180/ip-172-31-242-15.eu-west-3.compute.internal               172.31.242.15      reachable     unreachable
  cmesh181/ip-172-31-152-115.eu-west-3.compute.internal              172.31.152.115     reachable     unreachable
  cmesh182/ip-172-31-194-217.eu-west-3.compute.internal              172.31.194.217     reachable     reachable
  cmesh183/ip-172-31-154-13.eu-west-3.compute.internal               172.31.154.13      reachable     unreachable
  cmesh184/ip-172-31-233-71.eu-west-3.compute.internal               172.31.233.71      reachable     reachable
  cmesh185/ip-172-31-183-204.eu-west-3.compute.internal              172.31.183.204     unreachable   reachable
  cmesh186/ip-172-31-238-57.eu-west-3.compute.internal               172.31.238.57      unreachable   unreachable
  cmesh188/ip-172-31-242-2.eu-west-3.compute.internal                172.31.242.2       reachable     unreachable
  cmesh189/ip-172-31-189-46.eu-west-3.compute.internal               172.31.189.46      unreachable   unreachable
  cmesh19/ip-172-31-159-147.eu-west-3.compute.internal               172.31.159.147     unreachable   reachable
  cmesh190/ip-172-31-194-190.eu-west-3.compute.internal              172.31.194.190     unreachable   unreachable
  cmesh191/ip-172-31-163-135.eu-west-3.compute.internal              172.31.163.135     reachable     reachable
  cmesh192/ip-172-31-233-108.eu-west-3.compute.internal              172.31.233.108     unreachable   unreachable
  cmesh193/ip-172-31-170-23.eu-west-3.compute.internal               172.31.170.23      reachable     reachable
  cmesh194/ip-172-31-238-226.eu-west-3.compute.internal              172.31.238.226     unreachable   unreachable
  cmesh195/ip-172-31-167-218.eu-west-3.compute.internal              172.31.167.218     reachable     reachable
  cmesh196/ip-172-31-211-96.eu-west-3.compute.internal               172.31.211.96      reachable     unreachable
  cmesh197/ip-172-31-145-37.eu-west-3.compute.internal               172.31.145.37      reachable     reachable
  cmesh198/ip-172-31-232-195.eu-west-3.compute.internal              172.31.232.195     reachable     unreachable
  cmesh199/ip-172-31-146-99.eu-west-3.compute.internal               172.31.146.99      unreachable   reachable
  cmesh2/ip-172-31-198-203.eu-west-3.compute.internal                172.31.198.203     reachable     unreachable
  cmesh20/ip-172-31-241-81.eu-west-3.compute.internal                172.31.241.81      unreachable   unreachable
  cmesh200/ip-172-31-205-54.eu-west-3.compute.internal               172.31.205.54      unreachable   unreachable
  cmesh201/ip-172-31-174-157.eu-west-3.compute.internal              172.31.174.157     unreachable   unreachable
  cmesh202/ip-172-31-224-57.eu-west-3.compute.internal               172.31.224.57      reachable     unreachable
  cmesh203/ip-172-31-143-84.eu-west-3.compute.internal               172.31.143.84      unreachable   unreachable
  cmesh204/ip-172-31-244-196.eu-west-3.compute.internal              172.31.244.196     unreachable   unreachable
  cmesh205/ip-172-31-177-23.eu-west-3.compute.internal               172.31.177.23      unreachable   reachable
  cmesh206/ip-172-31-195-50.eu-west-3.compute.internal               172.31.195.50      reachable     unreachable
  cmesh207/ip-172-31-164-108.eu-west-3.compute.internal              172.31.164.108     reachable     unreachable
  cmesh208/ip-172-31-244-52.eu-west-3.compute.internal               172.31.244.52      reachable     reachable
  cmesh209/ip-172-31-171-115.eu-west-3.compute.internal              172.31.171.115     unreachable   unreachable
  cmesh21/ip-172-31-175-194.eu-west-3.compute.internal               172.31.175.194     unreachable   reachable
  cmesh210/ip-172-31-230-218.eu-west-3.compute.internal              172.31.230.218     reachable     reachable
  cmesh211/ip-172-31-156-152.eu-west-3.compute.internal              172.31.156.152     reachable     unreachable
  cmesh212/ip-172-31-214-171.eu-west-3.compute.internal              172.31.214.171     reachable     unreachable
  cmesh213/ip-172-31-176-70.eu-west-3.compute.internal               172.31.176.70      reachable     reachable
  cmesh214/ip-172-31-205-133.eu-west-3.compute.internal              172.31.205.133     unreachable   unreachable
  cmesh215/ip-172-31-135-249.eu-west-3.compute.internal              172.31.135.249     unreachable   unreachable
  cmesh216/ip-172-31-248-161.eu-west-3.compute.internal              172.31.248.161     unreachable   unreachable
  cmesh217/ip-172-31-142-17.eu-west-3.compute.internal               172.31.142.17      reachable     reachable
  cmesh218/ip-172-31-250-164.eu-west-3.compute.internal              172.31.250.164     unreachable   unreachable
  cmesh219/ip-172-31-149-217.eu-west-3.compute.internal              172.31.149.217     unreachable   unreachable
  cmesh22/ip-172-31-219-89.eu-west-3.compute.internal                172.31.219.89      reachable     reachable
  cmesh220/ip-172-31-216-60.eu-west-3.compute.internal               172.31.216.60      unreachable   unreachable
  cmesh221/ip-172-31-178-150.eu-west-3.compute.internal              172.31.178.150     unreachable   reachable
  cmesh222/ip-172-31-212-27.eu-west-3.compute.internal               172.31.212.27      reachable     reachable
  cmesh223/ip-172-31-180-162.eu-west-3.compute.internal              172.31.180.162     unreachable   reachable
  cmesh224/ip-172-31-234-57.eu-west-3.compute.internal               172.31.234.57      unreachable   unreachable
  cmesh225/ip-172-31-132-154.eu-west-3.compute.internal              172.31.132.154     reachable     reachable
  cmesh226/ip-172-31-212-55.eu-west-3.compute.internal               172.31.212.55      reachable     unreachable
  cmesh227/ip-172-31-177-98.eu-west-3.compute.internal               172.31.177.98      reachable     unreachable
  cmesh228/ip-172-31-245-124.eu-west-3.compute.internal              172.31.245.124     unreachable   reachable
  cmesh229/ip-172-31-148-66.eu-west-3.compute.internal               172.31.148.66      unreachable   reachable
  cmesh23/ip-172-31-172-110.eu-west-3.compute.internal               172.31.172.110     unreachable   unreachable
  cmesh230/ip-172-31-218-213.eu-west-3.compute.internal              172.31.218.213     unreachable   unreachable
  cmesh231/ip-172-31-138-46.eu-west-3.compute.internal               172.31.138.46      unreachable   reachable
  cmesh232/ip-172-31-219-47.eu-west-3.compute.internal               172.31.219.47      reachable     unreachable
  cmesh233/ip-172-31-189-68.eu-west-3.compute.internal               172.31.189.68      unreachable   unreachable
  cmesh234/ip-172-31-202-43.eu-west-3.compute.internal               172.31.202.43      unreachable   unreachable
  cmesh235/ip-172-31-167-143.eu-west-3.compute.internal              172.31.167.143     unreachable   unreachable
  cmesh236/ip-172-31-200-108.eu-west-3.compute.internal              172.31.200.108     unreachable   unreachable
  cmesh237/ip-172-31-134-110.eu-west-3.compute.internal              172.31.134.110     unreachable   reachable
  cmesh238/ip-172-31-226-233.eu-west-3.compute.internal              172.31.226.233     unreachable   unreachable
  cmesh239/ip-172-31-148-36.eu-west-3.compute.internal               172.31.148.36      unreachable   unreachable
  cmesh24/ip-172-31-198-128.eu-west-3.compute.internal               172.31.198.128     reachable     unreachable
  cmesh240/ip-172-31-247-110.eu-west-3.compute.internal              172.31.247.110     unreachable   reachable
  cmesh241/ip-172-31-168-247.eu-west-3.compute.internal              172.31.168.247     reachable     unreachable
  cmesh242/ip-172-31-225-246.eu-west-3.compute.internal              172.31.225.246     reachable     unreachable
  cmesh243/ip-172-31-167-121.eu-west-3.compute.internal              172.31.167.121     reachable     unreachable
  cmesh244/ip-172-31-196-138.eu-west-3.compute.internal              172.31.196.138     unreachable   reachable
  cmesh245/ip-172-31-143-97.eu-west-3.compute.internal               172.31.143.97      unreachable   unreachable
  cmesh246/ip-172-31-254-192.eu-west-3.compute.internal              172.31.254.192     unreachable   reachable
  cmesh247/ip-172-31-151-215.eu-west-3.compute.internal              172.31.151.215     unreachable   unreachable
  cmesh248/ip-172-31-217-105.eu-west-3.compute.internal              172.31.217.105     unreachable   unreachable
  cmesh249/ip-172-31-191-30.eu-west-3.compute.internal               172.31.191.30      unreachable   unreachable
  cmesh25/ip-172-31-171-219.eu-west-3.compute.internal               172.31.171.219     unreachable   reachable
  cmesh250/ip-172-31-223-254.eu-west-3.compute.internal              172.31.223.254     reachable     unreachable
  cmesh251/ip-172-31-130-97.eu-west-3.compute.internal               172.31.130.97      unreachable   unreachable
  cmesh252/ip-172-31-247-176.eu-west-3.compute.internal              172.31.247.176     unreachable   reachable
  cmesh253/ip-172-31-190-227.eu-west-3.compute.internal              172.31.190.227     unreachable   unreachable
  cmesh254/ip-172-31-194-196.eu-west-3.compute.internal              172.31.194.196     reachable     unreachable
  cmesh255/ip-172-31-158-156.eu-west-3.compute.internal              172.31.158.156     reachable     reachable
  cmesh256/ip-172-31-249-38.eu-west-3.compute.internal               172.31.249.38      reachable     reachable
  cmesh26/ip-172-31-210-57.eu-west-3.compute.internal                172.31.210.57      reachable     reachable
  cmesh27/ip-172-31-155-250.eu-west-3.compute.internal               172.31.155.250     reachable     unreachable
  cmesh28/ip-172-31-193-237.eu-west-3.compute.internal               172.31.193.237     unreachable   reachable
  cmesh29/ip-172-31-152-77.eu-west-3.compute.internal                172.31.152.77      unreachable   reachable
  cmesh3/ip-172-31-178-139.eu-west-3.compute.internal                172.31.178.139     unreachable   unreachable
  cmesh30/ip-172-31-231-174.eu-west-3.compute.internal               172.31.231.174     reachable     unreachable
  cmesh31/ip-172-31-183-179.eu-west-3.compute.internal               172.31.183.179     reachable     reachable
  cmesh32/ip-172-31-222-197.eu-west-3.compute.internal               172.31.222.197     unreachable   reachable
  cmesh33/ip-172-31-172-199.eu-west-3.compute.internal               172.31.172.199     unreachable   unreachable
  cmesh34/ip-172-31-250-23.eu-west-3.compute.internal                172.31.250.23      unreachable   reachable
  cmesh35/ip-172-31-186-233.eu-west-3.compute.internal               172.31.186.233     reachable     unreachable
  cmesh36/ip-172-31-202-120.eu-west-3.compute.internal               172.31.202.120     unreachable   unreachable
  cmesh37/ip-172-31-148-248.eu-west-3.compute.internal               172.31.148.248     unreachable   reachable
  cmesh38/ip-172-31-227-217.eu-west-3.compute.internal               172.31.227.217     unreachable   reachable
  cmesh39/ip-172-31-189-138.eu-west-3.compute.internal               172.31.189.138     reachable     reachable
  cmesh4/ip-172-31-226-7.eu-west-3.compute.internal                  172.31.226.7       reachable     reachable
  cmesh40/ip-172-31-252-16.eu-west-3.compute.internal                172.31.252.16      reachable     unreachable
  cmesh41/ip-172-31-162-144.eu-west-3.compute.internal               172.31.162.144     unreachable   unreachable
  cmesh42/ip-172-31-192-60.eu-west-3.compute.internal                172.31.192.60      unreachable   unreachable
  cmesh43/ip-172-31-129-213.eu-west-3.compute.internal               172.31.129.213     unreachable   unreachable
  cmesh44/ip-172-31-231-5.eu-west-3.compute.internal                 172.31.231.5       unreachable   unreachable
  cmesh45/ip-172-31-146-155.eu-west-3.compute.internal               172.31.146.155     reachable     reachable
  cmesh46/ip-172-31-218-14.eu-west-3.compute.internal                172.31.218.14      reachable     reachable
  cmesh47/ip-172-31-130-28.eu-west-3.compute.internal                172.31.130.28      unreachable   reachable
  cmesh48/ip-172-31-253-19.eu-west-3.compute.internal                172.31.253.19      reachable     unreachable
  cmesh49/ip-172-31-162-77.eu-west-3.compute.internal                172.31.162.77      reachable     unreachable
  cmesh5/ip-172-31-188-9.eu-west-3.compute.internal                  172.31.188.9       unreachable   reachable
  cmesh50/ip-172-31-216-105.eu-west-3.compute.internal               172.31.216.105     unreachable   unreachable
  cmesh51/ip-172-31-186-245.eu-west-3.compute.internal               172.31.186.245     unreachable   unreachable
  cmesh52/ip-172-31-250-78.eu-west-3.compute.internal                172.31.250.78      unreachable   unreachable
  cmesh53/ip-172-31-153-228.eu-west-3.compute.internal               172.31.153.228     unreachable   unreachable
  cmesh54/ip-172-31-235-129.eu-west-3.compute.internal               172.31.235.129     unreachable   reachable
  cmesh55/ip-172-31-170-243.eu-west-3.compute.internal               172.31.170.243     unreachable   unreachable
  cmesh56/ip-172-31-227-236.eu-west-3.compute.internal               172.31.227.236     reachable     reachable
  cmesh57/ip-172-31-133-234.eu-west-3.compute.internal               172.31.133.234     unreachable   reachable
  cmesh58/ip-172-31-237-78.eu-west-3.compute.internal                172.31.237.78      unreachable   reachable
  cmesh59/ip-172-31-157-22.eu-west-3.compute.internal                172.31.157.22      unreachable   unreachable
  cmesh6/ip-172-31-219-104.eu-west-3.compute.internal                172.31.219.104     unreachable   unreachable
  cmesh60/ip-172-31-237-111.eu-west-3.compute.internal               172.31.237.111     reachable     unreachable
  cmesh61/ip-172-31-177-157.eu-west-3.compute.internal               172.31.177.157     unreachable   unreachable
  cmesh62/ip-172-31-221-85.eu-west-3.compute.internal                172.31.221.85      reachable     unreachable
  cmesh63/ip-172-31-146-191.eu-west-3.compute.internal               172.31.146.191     reachable     reachable
  cmesh64/ip-172-31-232-42.eu-west-3.compute.internal                172.31.232.42      unreachable   reachable
  cmesh65/ip-172-31-165-36.eu-west-3.compute.internal                172.31.165.36      unreachable   reachable
  cmesh66/ip-172-31-209-31.eu-west-3.compute.internal                172.31.209.31      unreachable   reachable
  cmesh67/ip-172-31-159-51.eu-west-3.compute.internal                172.31.159.51      unreachable   unreachable
  cmesh68/ip-172-31-213-86.eu-west-3.compute.internal                172.31.213.86      unreachable   reachable
  cmesh69/ip-172-31-164-224.eu-west-3.compute.internal               172.31.164.224     unreachable   unreachable
  cmesh7/ip-172-31-154-145.eu-west-3.compute.internal                172.31.154.145     unreachable   unreachable
  cmesh70/ip-172-31-210-245.eu-west-3.compute.internal               172.31.210.245     unreachable   unreachable
  cmesh71/ip-172-31-181-32.eu-west-3.compute.internal                172.31.181.32      unreachable   unreachable
  cmesh72/ip-172-31-209-21.eu-west-3.compute.internal                172.31.209.21      unreachable   unreachable
  cmesh73/ip-172-31-154-219.eu-west-3.compute.internal               172.31.154.219     reachable     reachable
  cmesh74/ip-172-31-193-140.eu-west-3.compute.internal               172.31.193.140     unreachable   unreachable
  cmesh75/ip-172-31-133-182.eu-west-3.compute.internal               172.31.133.182     unreachable   unreachable
  cmesh76/ip-172-31-195-237.eu-west-3.compute.internal               172.31.195.237     unreachable   unreachable
  cmesh77/ip-172-31-185-59.eu-west-3.compute.internal                172.31.185.59      reachable     reachable
  cmesh78/ip-172-31-247-137.eu-west-3.compute.internal               172.31.247.137     unreachable   unreachable
  cmesh79/ip-172-31-151-179.eu-west-3.compute.internal               172.31.151.179     reachable     unreachable
  cmesh8/ip-172-31-250-177.eu-west-3.compute.internal                172.31.250.177     reachable     unreachable
  cmesh80/ip-172-31-192-135.eu-west-3.compute.internal               172.31.192.135     reachable     unreachable
  cmesh81/ip-172-31-140-137.eu-west-3.compute.internal               172.31.140.137     reachable     reachable
  cmesh82/ip-172-31-217-76.eu-west-3.compute.internal                172.31.217.76      unreachable   reachable
  cmesh83/ip-172-31-164-11.eu-west-3.compute.internal                172.31.164.11      reachable     unreachable
  cmesh84/ip-172-31-210-93.eu-west-3.compute.internal                172.31.210.93      reachable     reachable
  cmesh85/ip-172-31-149-34.eu-west-3.compute.internal                172.31.149.34      unreachable   unreachable
  cmesh86/ip-172-31-238-97.eu-west-3.compute.internal                172.31.238.97      unreachable   reachable
  cmesh87/ip-172-31-162-134.eu-west-3.compute.internal               172.31.162.134     reachable     unreachable
  cmesh88/ip-172-31-214-37.eu-west-3.compute.internal                172.31.214.37      reachable     unreachable
  cmesh89/ip-172-31-166-5.eu-west-3.compute.internal                 172.31.166.5       reachable     unreachable
  cmesh9/ip-172-31-179-121.eu-west-3.compute.internal                172.31.179.121     unreachable   unreachable
  cmesh90/ip-172-31-225-122.eu-west-3.compute.internal               172.31.225.122     unreachable   unreachable
  cmesh91/ip-172-31-155-193.eu-west-3.compute.internal               172.31.155.193     reachable     unreachable
  cmesh92/ip-172-31-250-18.eu-west-3.compute.internal                172.31.250.18      reachable     reachable
  cmesh93/ip-172-31-139-231.eu-west-3.compute.internal               172.31.139.231     unreachable   unreachable
  cmesh94/ip-172-31-253-50.eu-west-3.compute.internal                172.31.253.50      reachable     reachable
  cmesh95/ip-172-31-135-220.eu-west-3.compute.internal               172.31.135.220     unreachable   reachable
  cmesh96/ip-172-31-214-5.eu-west-3.compute.internal                 172.31.214.5       unreachable   unreachable
  cmesh97/ip-172-31-175-246.eu-west-3.compute.internal               172.31.175.246     reachable     unreachable
  cmesh98/ip-172-31-220-44.eu-west-3.compute.internal                172.31.220.44      unreachable   unreachable
  cmesh99/ip-172-31-139-133.eu-west-3.compute.internal               172.31.139.133     unreachable   unreachable
Modules Health:
      agent
      ├── controlplane
      │   ├── auth
      │   │   ├── observer-job-auth gc-identity-events            [OK] OK (7.713µs) [3] (18m, x1)
      │   │   ├── observer-job-auth request-authentication        [OK] Primed (21m, x1)
      │   │   └── timer-job-auth gc-cleanup                       [OK] OK (15.467µs) (62s, x1)
      │   ├── bgp-control-plane
      │   │   └── job-diffstore-events                            [OK] Running (20m, x2)
      │   ├── clustermesh
      │   │   ├── job-clustermesh-ipset-notifier                  [OK] Running (20m, x1)
      │   │   └── job-clustermesh-nodemanager-notifier            [OK] Running (20m, x1)
      │   ├── daemon
      │   │   ├──                                                 [OK] daemon-validate-config (38s, x21)
      │   │   ├── ep-bpf-prog-watchdog
      │   │   │   └── ep-bpf-prog-watchdog                        [OK] ep-bpf-prog-watchdog (28s, x42)
      │   │   └── job-sync-hostips                                [OK] Synchronized (58s, x22)
      │   ├── endpoint-manager
      │   │   ├── cilium-endpoint-2290 (kube-system/clustermesh-apiserver-56794b9bdf-bl2d8)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2290) (5s, x71)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (10m, x5)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2290 (11m, x1)
      │   │   ├── cilium-endpoint-2940 (kube-system/coredns-cc6ccd49c-z97n9)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (2940) (6s, x127)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (10m, x7)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-2940 (5m54s, x2)
      │   │   ├── cilium-endpoint-3388 (kube-system/coredns-cc6ccd49c-gm8g8)
      │   │   │   ├── cep-k8s-sync                                [OK] sync-to-k8s-ciliumendpoint (3388) (6s, x127)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (10m, x7)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3388 (5m54s, x2)
      │   │   ├── cilium-endpoint-3659 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (10m, x8)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-3659 (5m54s, x2)
      │   │   ├── cilium-endpoint-4082 (/)
      │   │   │   ├── datapath-regenerate                         [OK] Endpoint regeneration successful (10m, x9)
      │   │   │   └── policymap-sync                              [OK] sync-policymap-4082 (5m57s, x2)
      │   │   └── endpoint-gc                                     [OK] endpoint-gc (62s, x5)
      │   ├── envoy-proxy
      │   │   └── timer-job-version-check                         [OK] OK (2.421845ms) (58s, x1)
      │   ├── l2-announcer
      │   │   └── job-l2-announcer lease-gc                       [OK] Running (21m, x1)
      │   ├── node-manager
      │   │   ├── background-sync                                 [OK] Node validation successful (4m46s, x16)
      │   │   ├── node-checkpoint-writer                          [OK] node checkpoint written (8m39s, x4)
      │   │   └── nodes-add                                       [OK] Node adds successful (10m, x256)
      │   ├── service-manager
      │   │   └── job-ServiceReconciler                           [OK] 2 NodePort frontend addresses (20m, x1)
      │   ├── service-resolver
      │   │   └── job-service-reloader-initializer                [OK] Synchronized (10m, x1)
      │   ├── stale-endpoint-cleanup
      │   │   └── job-endpoint-cleanup                            [OK] Running (20m, x1)
      │   └── timer-job-device-reloader                           [OK] OK (10m23.522019013s) (60s, x1)
      ├── datapath
      │   ├── agent-liveness-updater
      │   │   └── timer-job-agent-liveness-updater                [OK] OK (36.209µs) (0s, x1)
      │   ├── iptables
      │   │   ├── ipset
      │   │   │   ├── job-ipset-init-finalizer                    [OK] Running (21m, x1)
      │   │   │   └── job-reconciler-loop                         [OK] OK, 0 objects (21m, x1)
      │   │   └── job-iptables-reconciliation-loop                [OK] iptables rules full reconciliation completed (20m, x1)
      │   ├── l2-responder
      │   │   └── job-l2-responder-reconciler                     [OK] Running (20m, x1)
      │   ├── maps
      │   │   └── bwmap
      │   │       └── timer-job-pressure-metric-throttle          [OK] OK (2.15µs) (28s, x1)
      │   ├── node-address
      │   │   └── job-node-address-update                         [OK] 10.186.0.116 (primary), fe80::fcea:a2ff:fe76:7cd4 (primary) (20m, x1)
      │   └── sysctl
      │       └── job-reconciler-loop                             [OK] OK, 20 objects (62s, x21)
      └── infra
          └── k8s-synced-crdsync
              └── job-sync-crds                                   [OK] Running (21m, x1)
      
