REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34050     2689467     677    bpf_overlay.c
Interface                 INGRESS     619101    129246663   1132   bpf_host.c
Success                   EGRESS      14005     1095223     1694   bpf_host.c
Success                   EGRESS      20416     3235564     86     l3.h
Success                   EGRESS      261989    33116842    1308   bpf_lxc.c
Success                   EGRESS      32940     2607921     53     encap.h
Success                   INGRESS     301834    34079685    86     l3.h
Success                   INGRESS     342946    38953539    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
