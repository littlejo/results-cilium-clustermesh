KEY             VALUE
AgentLiveness   1867080775924
UTimeOffset     3379442843750000
