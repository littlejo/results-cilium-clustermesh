key: c5 03 00 00  value: 1c 02 00 00
key: 7a 05 00 00  value: 7b 02 00 00
key: 03 09 00 00  value: 01 02 00 00
key: c1 0a 00 00  value: 0d 02 00 00
Found 4 elements
