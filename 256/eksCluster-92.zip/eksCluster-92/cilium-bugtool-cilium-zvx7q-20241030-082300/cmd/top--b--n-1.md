top - 08:23:01 up 34 min,  0 users,  load average: 0.37, 0.34, 0.21
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.7 us, 43.3 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4477.1 free,   1190.8 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6438.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1671940 396020  78088 S  46.7   4.9   0:53.57 cilium-+
    406 root      20   0 1229744   6664   2928 S   0.0   0.1   0:01.18 cilium-+
    647 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    664 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    671 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    677 root      20   0 1240432  16756  11548 S   0.0   0.2   0:00.02 cilium-+
    717 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    736 root      20   0 1228744   3976   3328 S   0.0   0.0   0:00.00 gops
