[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-552f7fab4a0687bf66bb1778f688deb326050cd1c69bb6eb8b186300e06e7015.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-fd01e2858c3fa643945fbe758cc6a92f616167c12d64b8313130e083357235b3.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-b63c84f5d9af1ad67ff1d9963e8957ce5a1b13d9aa00a630c77332f6add16def.scope"
      }
    ],
    "ips": [
      "10.92.0.21"
    ],
    "name": "clustermesh-apiserver-565cbb77f5-q2vbs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45844ef8_7cc0_45ec_a41e_873a307d276e.slice/cri-containerd-e67ceaa77f667a469f272b4c400e520c435ba6fedc2991c3fc3f895015a02900.scope"
      }
    ],
    "ips": [
      "10.92.0.92"
    ],
    "name": "coredns-cc6ccd49c-89hmr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28150d25_0a8e_4a7d_9074_0637d6833009.slice/cri-containerd-70494586c1e725d0d836633559cb8dac0b6a12276d293c9c3ae6879272d24bc2.scope"
      }
    ],
    "ips": [
      "10.92.0.186"
    ],
    "name": "coredns-cc6ccd49c-f9n24",
    "namespace": "kube-system"
  }
]

