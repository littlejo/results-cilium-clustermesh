 08:23:01 up 34 min,  0 users,  load average: 0.37, 0.34, 0.21
