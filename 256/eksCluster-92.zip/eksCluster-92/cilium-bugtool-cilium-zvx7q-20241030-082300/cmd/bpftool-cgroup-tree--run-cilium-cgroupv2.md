CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28150d25_0a8e_4a7d_9074_0637d6833009.slice/cri-containerd-0a12691536e84128eff76b2f70debb54fa41aa380790d23c1c40af2ea1189915.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod28150d25_0a8e_4a7d_9074_0637d6833009.slice/cri-containerd-70494586c1e725d0d836633559cb8dac0b6a12276d293c9c3ae6879272d24bc2.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bbe22e6_dcfe_4c1d_834c_18a1a52b943d.slice/cri-containerd-8743430080fcd98a91d144da5cc84b0212f95902d0916085f8b93db845f5832b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2bbe22e6_dcfe_4c1d_834c_18a1a52b943d.slice/cri-containerd-1437235cfe466ede7b7d13da403ae78ab6b8bdb912fae75c386cea1683a232d9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45844ef8_7cc0_45ec_a41e_873a307d276e.slice/cri-containerd-e67ceaa77f667a469f272b4c400e520c435ba6fedc2991c3fc3f895015a02900.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod45844ef8_7cc0_45ec_a41e_873a307d276e.slice/cri-containerd-b3b96b4a09dd49b3f3712cb56a404c5db90a602714eb3788c69c7ffeffeb9469.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc8d4b66_d687_4526_a872_904394b53f62.slice/cri-containerd-b0fe77974fbd083321dd675500af4e97def3914a592fb556eb4220c17f090c13.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfc8d4b66_d687_4526_a872_904394b53f62.slice/cri-containerd-17198ad3a60283663d74503c2a0c3b6e61ad165fcded2e4ffe87513693ee4e23.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38de99b6_7b60_475f_973f_498ca5d07bee.slice/cri-containerd-27ff99877d8028ff764f63649d43a83498e4d21d7a904b44ca3d0f5cd92fd3eb.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod38de99b6_7b60_475f_973f_498ca5d07bee.slice/cri-containerd-12552bc2dc3904238913ad3101eed0bb8f7370370aa95409d5ae3c2b932d1909.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-b63c84f5d9af1ad67ff1d9963e8957ce5a1b13d9aa00a630c77332f6add16def.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-a58bf95e53f0ea0120a01d3f0018b4e1d9dcc22984c6b349d8f9640f221dcfd0.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-fd01e2858c3fa643945fbe758cc6a92f616167c12d64b8313130e083357235b3.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod16baf0e1_1732_4e3e_a9b7_6ba130ef43d9.slice/cri-containerd-552f7fab4a0687bf66bb1778f688deb326050cd1c69bb6eb8b186300e06e7015.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod482d60f0_35a1_472d_ab3c_6f1c681ee17d.slice/cri-containerd-3633e9d9c1112279befd51d97d076a8fadc78d7f626b3713caadac89b30490e5.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod482d60f0_35a1_472d_ab3c_6f1c681ee17d.slice/cri-containerd-23ec61873796d2d78f7f10c413f68f83ae414751f292d25301eac51cce73ffdd.scope
    97       cgroup_device   multi                                          
