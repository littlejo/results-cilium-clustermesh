filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1716fe3fbe47 direct-action not_in_hw id 524 tag 8ccac8b3b3e3afcc jited 
