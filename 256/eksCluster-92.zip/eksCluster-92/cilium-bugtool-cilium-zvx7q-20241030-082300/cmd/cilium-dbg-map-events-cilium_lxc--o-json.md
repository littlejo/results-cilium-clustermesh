{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.297Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.139.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.297Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.297Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:50.838Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:50.844Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:50.915Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:50.977Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:51.079Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.478Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.478Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.478Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.511Z",
  "value": "id=473   sec_id=3069868 flags=0x0000 ifindex=16  mac=AE:FF:54:79:15:D7 nodemac=CE:4C:FC:1A:AD:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:45.478Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:45.479Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:45.479Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:45.479Z",
  "value": "id=473   sec_id=3069868 flags=0x0000 ifindex=16  mac=AE:FF:54:79:15:D7 nodemac=CE:4C:FC:1A:AD:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.350Z",
  "value": "id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.92.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.751Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.900Z",
  "value": "id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.902Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.902Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:11.903Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.909Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.931Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.931Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:12.932Z",
  "value": "id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.883Z",
  "value": "id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.883Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.884Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.884Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.884Z",
  "value": "id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.884Z",
  "value": "id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.884Z",
  "value": "id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.92.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.884Z",
  "value": "id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A"
}

