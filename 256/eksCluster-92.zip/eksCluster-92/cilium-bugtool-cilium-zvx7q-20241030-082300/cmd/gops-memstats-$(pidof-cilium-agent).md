alloc: 106.64MB (111820808 bytes)
total-alloc: 2.33GB (2502133824 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 64694284
frees: 63917346
heap-alloc: 106.64MB (111820808 bytes)
heap-sys: 263.83MB (276643840 bytes)
heap-idle: 95.52MB (100155392 bytes)
heap-in-use: 168.31MB (176488448 bytes)
heap-released: 13.66MB (14319616 bytes)
heap-objects: 776938
stack-in-use: 60.12MB (63045632 bytes)
stack-sys: 60.12MB (63045632 bytes)
stack-mspan-inuse: 2.84MB (2978560 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1262945 bytes)
gc-sys: 6.09MB (6382072 bytes)
next-gc: when heap-alloc >= 210.99MB (221236664 bytes)
last-gc: 2024-10-30 08:23:26.839146991 +0000 UTC
gc-pause-total: 15.611021ms
gc-pause: 88584
gc-pause-end: 1730276606839146991
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003767287595156643
enable-gc: true
debug-gc: false
