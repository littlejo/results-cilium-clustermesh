IP ADDRESS         LOCAL ENDPOINT INFO
10.92.0.73:0       id=2307  sec_id=4     flags=0x0000 ifindex=10  mac=DA:3A:E9:BD:8D:04 nodemac=12:03:3A:2C:B2:39     
172.31.150.239:0   (localhost)                                                                                        
10.92.0.181:0      (localhost)                                                                                        
10.92.0.92:0       id=2753  sec_id=3056843 flags=0x0000 ifindex=12  mac=72:DE:11:17:D5:1E nodemac=BA:55:D3:0F:9D:6A   
10.92.0.21:0       id=1402  sec_id=3069868 flags=0x0000 ifindex=18  mac=E6:39:8B:96:A6:37 nodemac=9E:9D:5F:DB:13:A7   
10.92.0.186:0      id=965   sec_id=3056843 flags=0x0000 ifindex=14  mac=AA:CD:07:4F:0A:06 nodemac=A6:59:A0:8C:BA:B3   
172.31.139.231:0   (localhost)                                                                                        
