Endpoint ID: 965
Path: /sys/fs/bpf/tc/globals/cilium_policy_00965

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    158539   1820      0        
Allow    Egress      0          ANY          NONE         disabled    21742    243       0        


Endpoint ID: 1402
Path: /sys/fs/bpf/tc/globals/cilium_policy_01402

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11625796   116345    0        
Allow    Ingress     1          ANY          NONE         disabled    10537441   111018    0        
Allow    Egress      0          ANY          NONE         disabled    13533433   133195    0        


Endpoint ID: 1821
Path: /sys/fs/bpf/tc/globals/cilium_policy_01821

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2307
Path: /sys/fs/bpf/tc/globals/cilium_policy_02307

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660329   20993     0        
Allow    Ingress     1          ANY          NONE         disabled    23326     272       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2753
Path: /sys/fs/bpf/tc/globals/cilium_policy_02753

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    158080   1818      0        
Allow    Egress      0          ANY          NONE         disabled    19940    223       0        


