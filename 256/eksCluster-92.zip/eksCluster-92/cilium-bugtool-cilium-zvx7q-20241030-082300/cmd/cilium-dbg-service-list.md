ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.141.124:443 (active)    
                                         2 => 172.31.248.190:443 (active)    
2    10.100.75.200:443    ClusterIP      1 => 172.31.139.231:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.92.0.92:53 (active)         
                                         2 => 10.92.0.186:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.92.0.92:9153 (active)       
                                         2 => 10.92.0.186:9153 (active)      
5    10.100.99.103:2379   ClusterIP      1 => 10.92.0.21:2379 (active)       
