{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:57.057Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.727Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.731Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.783Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.784Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:01.795Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.364Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.364Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.365Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:57.395Z",
  "value": "id=139   sec_id=1735452 flags=0x0000 ifindex=16  mac=3E:F8:7E:13:C3:04 nodemac=12:EA:B7:75:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.365Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.365Z",
  "value": "id=139   sec_id=1735452 flags=0x0000 ifindex=16  mac=3E:F8:7E:13:C3:04 nodemac=12:EA:B7:75:BC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.366Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:58.366Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.663Z",
  "value": "id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.51.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:48.986Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.103Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.103Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.104Z",
  "value": "id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.105Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.105Z",
  "value": "id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.107Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.107Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.108Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.107Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.107Z",
  "value": "id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.107Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.108Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.107Z",
  "value": "id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.107Z",
  "value": "id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.107Z",
  "value": "id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.51.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.107Z",
  "value": "id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF"
}

