 08:22:58 up 34 min,  0 users,  load average: 0.13, 0.32, 0.28
