[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-2ba4bf837c2e6f1b370557654a49317a8fd332f700379639243aa7dfcd2895ab.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-6392b6e7d27a94ffc88d46b9578fd6a3e8825a6394215b4dd6802c9a41a33324.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-999272999d8a94cf741d520f2c229dc1998ee42eddf86fd187bf9bf93324d2e0.scope"
      }
    ],
    "ips": [
      "10.51.0.167"
    ],
    "name": "clustermesh-apiserver-5c75d7cbd9-8vn7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff47b10f_8ea5_4e4b_94f8_71546f275a04.slice/cri-containerd-46cad164006eeadf7ab8c3ae43005beb85c87f6fe8dc4b982d7495c581b076f9.scope"
      }
    ],
    "ips": [
      "10.51.0.115"
    ],
    "name": "coredns-cc6ccd49c-tl6jp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dec6966_a542_44cf_af7c_9f7455d8258c.slice/cri-containerd-ed86262ba445b719ba3834240471035bf9091e5fe7e89b92e43145c4181e40fc.scope"
      }
    ],
    "ips": [
      "10.51.0.95"
    ],
    "name": "coredns-cc6ccd49c-qsqhp",
    "namespace": "kube-system"
  }
]

