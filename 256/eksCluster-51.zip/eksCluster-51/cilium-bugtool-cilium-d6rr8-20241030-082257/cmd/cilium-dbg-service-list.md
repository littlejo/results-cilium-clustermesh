ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.131.179:443 (active)   
                                         2 => 172.31.225.108:443 (active)   
2    10.100.185.56:443    ClusterIP      1 => 172.31.250.78:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.51.0.95:53 (active)        
                                         2 => 10.51.0.115:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.51.0.95:9153 (active)      
                                         2 => 10.51.0.115:9153 (active)     
5    10.100.53.248:2379   ClusterIP      1 => 10.51.0.167:2379 (active)     
