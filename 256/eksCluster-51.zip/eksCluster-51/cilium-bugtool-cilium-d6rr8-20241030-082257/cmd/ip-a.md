1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1b:b3:65:c0:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.78/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3347sec preferred_lft 3347sec
    inet6 fe80::81b:b3ff:fe65:c07b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ba:e1:a5:79:45 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.218.46/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ba:e1ff:fea5:7945/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:6a:ff:01:e3:21 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a86a:ffff:fe01:e321/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:de:58:03:90:0c brd ff:ff:ff:ff:ff:ff
    inet 10.51.0.237/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b4de:58ff:fe03:900c/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:6d:1e:c8:84:9a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::106d:1eff:fec8:849a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:67:b7:f1:fc:df brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f867:b7ff:fef1:fcdf/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb429ceb7814d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:91:ef:36:73:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4091:efff:fe36:73b9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce742a5ad3956@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:d1:d4:37:1d:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::20d1:d4ff:fe37:1db1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcadc1c7e7d737@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:dc:50:c9:0b:4f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::54dc:50ff:fec9:b4f/64 scope link 
       valid_lft forever preferred_lft forever
