key: e4 03 00 00  value: 6a 02 00 00
key: 00 08 00 00  value: 20 02 00 00
key: 12 0a 00 00  value: 22 02 00 00
key: 50 0c 00 00  value: 16 02 00 00
Found 4 elements
