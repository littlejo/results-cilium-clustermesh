REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35558     2811588     677    bpf_overlay.c
Interface                 INGRESS     631258    130943729   1132   bpf_host.c
Success                   EGRESS      15263     1197432     1694   bpf_host.c
Success                   EGRESS      266030    33485785    1308   bpf_lxc.c
Success                   EGRESS      34940     2768267     53     encap.h
Success                   INGRESS     306555    34495141    86     l3.h
Success                   INGRESS     327501    36153343    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
