KEY             VALUE
AgentLiveness   2094621265795
UTimeOffset     3379442412109375
