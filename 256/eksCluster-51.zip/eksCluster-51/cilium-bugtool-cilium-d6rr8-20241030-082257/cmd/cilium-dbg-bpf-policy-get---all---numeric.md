Endpoint ID: 996
Path: /sys/fs/bpf/tc/globals/cilium_policy_00996

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11515959   113720    0        
Allow    Ingress     1          ANY          NONE         disabled    9455332    99185     0        
Allow    Egress      0          ANY          NONE         disabled    12018467   119164    0        


Endpoint ID: 2048
Path: /sys/fs/bpf/tc/globals/cilium_policy_02048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150773   1732      0        
Allow    Egress      0          ANY          NONE         disabled    19533    216       0        


Endpoint ID: 2578
Path: /sys/fs/bpf/tc/globals/cilium_policy_02578

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659352   20962     0        
Allow    Ingress     1          ANY          NONE         disabled    22500     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3152
Path: /sys/fs/bpf/tc/globals/cilium_policy_03152

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151482   1738      0        
Allow    Egress      0          ANY          NONE         disabled    19789    219       0        


Endpoint ID: 3769
Path: /sys/fs/bpf/tc/globals/cilium_policy_03769

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


