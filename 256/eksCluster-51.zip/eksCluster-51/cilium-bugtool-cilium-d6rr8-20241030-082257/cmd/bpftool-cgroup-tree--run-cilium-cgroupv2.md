CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80695548_0fd0_4c31_a418_1d8c769feeaf.slice/cri-containerd-0122c31de62790bc65a00a0c9ea62d008581d2b6a0fe448d57723d20cf0b990a.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80695548_0fd0_4c31_a418_1d8c769feeaf.slice/cri-containerd-7e571f5937f2c1463837b5632b5a3293ccc975590244c459a2169dfab7124a98.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff47b10f_8ea5_4e4b_94f8_71546f275a04.slice/cri-containerd-104e768d066f0be6a319a2476e9f50616f757fe76b030daf6de23676f99b2603.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff47b10f_8ea5_4e4b_94f8_71546f275a04.slice/cri-containerd-46cad164006eeadf7ab8c3ae43005beb85c87f6fe8dc4b982d7495c581b076f9.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8fdeaee_9605_4bf5_a200_bbd3752fa09e.slice/cri-containerd-a240e1b07cbc28b6f7891ae5a512b09b9d4dabcc49ac71f9897f53c95ebd04bd.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb8fdeaee_9605_4bf5_a200_bbd3752fa09e.slice/cri-containerd-69b2342f2122fcf780500a80723aa15a1dfbcaeed7d207ac3610cc136db9b3c9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dec6966_a542_44cf_af7c_9f7455d8258c.slice/cri-containerd-9a54642dafa5f6e17b71a0cc3b1ba00cb0303e95b5ad8959202594fd577d927c.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4dec6966_a542_44cf_af7c_9f7455d8258c.slice/cri-containerd-ed86262ba445b719ba3834240471035bf9091e5fe7e89b92e43145c4181e40fc.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-3c3789c06ea67dafc713792c47b0415e3b015fc7fa1cdef7cc27435f28bf8367.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-6392b6e7d27a94ffc88d46b9578fd6a3e8825a6394215b4dd6802c9a41a33324.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-999272999d8a94cf741d520f2c229dc1998ee42eddf86fd187bf9bf93324d2e0.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod978f6ac5_116e_4ff9_a43e_1b840816a382.slice/cri-containerd-2ba4bf837c2e6f1b370557654a49317a8fd332f700379639243aa7dfcd2895ab.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d7427b9_df1d_4544_b4ae_b55355bfbe42.slice/cri-containerd-e7d1ca9d91dca5db71f5fde8d3a0595b7dfdafce58463cb1c7f7d344349ace18.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d7427b9_df1d_4544_b4ae_b55355bfbe42.slice/cri-containerd-f764cb9fd080e3c264e0df0123bcf1d1027df6a7daad372dd16d0513331d8687.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ac0843_1963_4ae9_9ce6_c3bc914ad9f1.slice/cri-containerd-e9d59e237b21e5f274ec4c388c973753141b6d5888e778dd01bbb0a0127a2da4.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ac0843_1963_4ae9_9ce6_c3bc914ad9f1.slice/cri-containerd-f9d4296383ccf4b3b861ce9f57699c0b7380b1654d080c72d7231354a94627fa.scope
    105      cgroup_device   multi                                          
