xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 504
ens6(5) clsact/ingress cil_from_netdev-ens6 id 509
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 499
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 494
cilium_host(7) clsact/egress cil_from_host-cilium_host id 493
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxcb429ceb7814d(12) clsact/ingress cil_from_container-lxcb429ceb7814d id 549
lxce742a5ad3956(14) clsact/ingress cil_from_container-lxce742a5ad3956 id 537
lxcadc1c7e7d737(18) clsact/ingress cil_from_container-lxcadc1c7e7d737 id 625

flow_dissector:

netfilter:

