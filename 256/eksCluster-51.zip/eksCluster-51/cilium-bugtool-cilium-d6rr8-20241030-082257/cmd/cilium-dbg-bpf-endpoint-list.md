IP ADDRESS        LOCAL ENDPOINT INFO
172.31.250.78:0   (localhost)                                                                                        
10.51.0.95:0      id=2048  sec_id=1704622 flags=0x0000 ifindex=12  mac=FE:A3:36:A5:AD:81 nodemac=42:91:EF:36:73:B9   
10.51.0.167:0     id=996   sec_id=1735452 flags=0x0000 ifindex=18  mac=4A:B3:9A:B2:55:5A nodemac=56:DC:50:C9:0B:4F   
10.51.0.202:0     id=2578  sec_id=4     flags=0x0000 ifindex=10  mac=3A:7F:7A:F8:BD:23 nodemac=FA:67:B7:F1:FC:DF     
10.51.0.237:0     (localhost)                                                                                        
10.51.0.115:0     id=3152  sec_id=1704622 flags=0x0000 ifindex=14  mac=B2:49:9A:0A:83:A8 nodemac=22:D1:D4:37:1D:B1   
172.31.218.46:0   (localhost)                                                                                        
