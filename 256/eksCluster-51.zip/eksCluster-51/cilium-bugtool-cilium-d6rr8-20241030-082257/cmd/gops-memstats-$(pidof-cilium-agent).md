alloc: 187.35MB (196447784 bytes)
total-alloc: 2.24GB (2406792152 bytes)
sys: 345.09MB (361848180 bytes)
lookups: 0
mallocs: 63010494
frees: 61316170
heap-alloc: 187.35MB (196447784 bytes)
heap-sys: 267.48MB (280477696 bytes)
heap-idle: 49.51MB (51912704 bytes)
heap-in-use: 217.98MB (228564992 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 1694324
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.16MB (3312320 bytes)
stack-mspan-sys: 3.92MB (4112640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.13MB (1189697 bytes)
gc-sys: 6.10MB (6398552 bytes)
next-gc: when heap-alloc >= 212.19MB (222495912 bytes)
last-gc: 2024-10-30 08:23:03.994658522 +0000 UTC
gc-pause-total: 26.892053ms
gc-pause: 209020
gc-pause-end: 1730276583994658522
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.00040727312859325284
enable-gc: true
debug-gc: false
