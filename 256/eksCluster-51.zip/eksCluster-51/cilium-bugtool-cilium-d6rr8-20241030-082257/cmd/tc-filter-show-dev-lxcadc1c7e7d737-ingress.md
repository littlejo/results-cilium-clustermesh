filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcadc1c7e7d737 direct-action not_in_hw id 625 tag 15fa1c168c3f90c8 jited 
