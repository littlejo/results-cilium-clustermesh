 08:22:49 up 29 min,  0 users,  load average: 0.20, 0.25, 0.21
