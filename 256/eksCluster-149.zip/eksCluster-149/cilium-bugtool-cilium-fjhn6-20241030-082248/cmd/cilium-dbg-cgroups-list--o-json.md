[
  {
    "containers": [
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-a820e3510224bb33837cd8ead803a4f5f7cb44743ad5d5b4f7d6ed3ae023df16.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-faa83dc5bfb53515394564a3fb88cc1e3eac71aca0fe2161d4052da750cced34.scope"
      },
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-0c470016c6820d6d8c6702b8502544ea0b5a89c1befbc48915ea65cb7000bb52.scope"
      }
    ],
    "ips": [
      "10.149.0.172"
    ],
    "name": "clustermesh-apiserver-6c9f55bc9d-2zz2v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20d79d55_5618_4c9d_8fc7_9c078e691391.slice/cri-containerd-d0bd452b3a6f7057b0630bccec1defc6c6108c406c087b5a5c76514f85b230d6.scope"
      }
    ],
    "ips": [
      "10.149.0.8"
    ],
    "name": "coredns-cc6ccd49c-czwht",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a9445e3_56b5_4c42_a553_4e83145841ac.slice/cri-containerd-972d1cf19026eb659a754aa6c73e4db484dc6687daef1530ef997c16483d78ae.scope"
      }
    ],
    "ips": [
      "10.149.0.32"
    ],
    "name": "coredns-cc6ccd49c-g5pk9",
    "namespace": "kube-system"
  }
]

