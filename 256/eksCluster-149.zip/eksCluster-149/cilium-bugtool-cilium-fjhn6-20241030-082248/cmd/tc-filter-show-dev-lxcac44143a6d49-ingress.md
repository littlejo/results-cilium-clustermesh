filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcac44143a6d49 direct-action not_in_hw id 612 tag a0f6076cb8c83816 jited 
