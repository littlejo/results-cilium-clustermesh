top - 08:22:50 up 29 min,  0 users,  load average: 0.75, 0.36, 0.24
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 40.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4481.4 free,   1186.5 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6442.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    682 root      20   0 1244340  22244  14524 S  40.0   0.3   0:00.16 hubble
      1 root      20   0 1606080 378868  79476 R  13.3   4.7   0:53.50 cilium-+
    648 root      20   0 1240432  15940  10960 S   6.7   0.2   0:00.03 cilium-+
    392 root      20   0 1229744   6980   2928 S   0.0   0.1   0:01.20 cilium-+
    619 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    640 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    672 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    709 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    728 root      20   0    3720   1288   1136 R   0.0   0.0   0:00.00 bash
