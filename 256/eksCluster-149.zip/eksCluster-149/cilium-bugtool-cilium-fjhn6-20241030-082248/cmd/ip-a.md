1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:40:d8:97:a9:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.201.166/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1863sec preferred_lft 1863sec
    inet6 fe80::840:d8ff:fe97:a9f7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5e:5c:07:2a:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.204.78/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::85e:5cff:fe07:2a5d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:ff:83:0b:c9:65 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcff:83ff:fe0b:c965/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:52:35:71:f8:10 brd ff:ff:ff:ff:ff:ff
    inet 10.149.0.72/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5452:35ff:fe71:f810/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c2:b1:5b:19:fb:c3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c0b1:5bff:fe19:fbc3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:ae:31:fa:c2:7b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::68ae:31ff:fefa:c27b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf867f728163a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:27:96:27:6b:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c027:96ff:fe27:6bc7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce8f7ddcbd67f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:4e:1d:07:b4:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f44e:1dff:fe07:b4b1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcac44143a6d49@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:e8:0f:0e:ca:bf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64e8:fff:fe0e:cabf/64 scope link 
       valid_lft forever preferred_lft forever
