alloc: 161.32MB (169152784 bytes)
total-alloc: 2.21GB (2368850760 bytes)
sys: 352.84MB (369974644 bytes)
lookups: 0
mallocs: 62520766
frees: 61234479
heap-alloc: 161.32MB (169152784 bytes)
heap-sys: 275.32MB (288694272 bytes)
heap-idle: 75.80MB (79486976 bytes)
heap-in-use: 199.52MB (209207296 bytes)
heap-released: 10.24MB (10739712 bytes)
heap-objects: 1286287
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 2.88MB (3021280 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1070369 bytes)
gc-sys: 6.07MB (6365736 bytes)
next-gc: when heap-alloc >= 216.24MB (226743928 bytes)
last-gc: 2024-10-30 08:23:00.632495433 +0000 UTC
gc-pause-total: 35.954951ms
gc-pause: 601652
gc-pause-end: 1730276580632495433
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005805077611840974
enable-gc: true
debug-gc: false
