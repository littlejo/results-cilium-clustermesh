filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf867f728163a direct-action not_in_hw id 520 tag b8451891e3f6d6c4 jited 
