REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35354     2796848     677    bpf_overlay.c
Interface                 INGRESS     620444    128879406   1132   bpf_host.c
Success                   EGRESS      15249     1196996     1694   bpf_host.c
Success                   EGRESS      261370    33169337    1308   bpf_lxc.c
Success                   EGRESS      34985     2767274     53     encap.h
Success                   INGRESS     304966    34179759    86     l3.h
Success                   INGRESS     325722    35823657    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
