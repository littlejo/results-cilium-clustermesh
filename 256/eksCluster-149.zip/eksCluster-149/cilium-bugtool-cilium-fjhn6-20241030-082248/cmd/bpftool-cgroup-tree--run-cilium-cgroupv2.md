CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20d79d55_5618_4c9d_8fc7_9c078e691391.slice/cri-containerd-eb0370650d6b95d3e4bec6ca9cc95a78ec06fba2c7afddfb05de5bb9abe8e6a6.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod20d79d55_5618_4c9d_8fc7_9c078e691391.slice/cri-containerd-d0bd452b3a6f7057b0630bccec1defc6c6108c406c087b5a5c76514f85b230d6.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda398fd00_5cd9_4db0_9015_e9d3124d3f13.slice/cri-containerd-13cc3042f9546c921f3d807fb1dfaf2877f3a8c0017295009f1531c05ee6ca91.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda398fd00_5cd9_4db0_9015_e9d3124d3f13.slice/cri-containerd-7e1e95abd17f3e73593d53746e01e45ee8acfce81338237abcbd38640e317679.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10a1686c_ffce_4548_9324_a7680d8eaf81.slice/cri-containerd-0f64bc45bb9517d569d1852cf015e8fac7f7dc185fc1fc5b040cd1a91b492450.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10a1686c_ffce_4548_9324_a7680d8eaf81.slice/cri-containerd-64b7cfc0be64d9be226efb5e1b0b021f858c58e58eaad2fdd7ed0dd09c460309.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a9445e3_56b5_4c42_a553_4e83145841ac.slice/cri-containerd-47c604b3d862101455ccdcdb7e5728334b4117ace57a62971dbebd53778898c8.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8a9445e3_56b5_4c42_a553_4e83145841ac.slice/cri-containerd-972d1cf19026eb659a754aa6c73e4db484dc6687daef1530ef997c16483d78ae.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-faa83dc5bfb53515394564a3fb88cc1e3eac71aca0fe2161d4052da750cced34.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-94514cda49cb89363457a4a1bb9296ffcd3dfffcf6136458a10fa079ee3b40f9.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-0c470016c6820d6d8c6702b8502544ea0b5a89c1befbc48915ea65cb7000bb52.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod296f07af_5efe_4e19_9d69_85e2514f6824.slice/cri-containerd-a820e3510224bb33837cd8ead803a4f5f7cb44743ad5d5b4f7d6ed3ae023df16.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb6384f0_9b1a_4f98_a9eb_21d6731d8357.slice/cri-containerd-f56917f47d30bd87165de776d4a56cb1006ef759a54faa2676dbb56e3a823fb4.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb6384f0_9b1a_4f98_a9eb_21d6731d8357.slice/cri-containerd-2eb6401b1ab5d879a5d65ec2d0725ad28cec9c0e2929906ed240a311162c4e39.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod083876b2_febb_4210_9a20_2642f988ff0d.slice/cri-containerd-a9fffbd0610a281601911381f0864b94caf5e0af85173cd4548c77b7636468b0.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod083876b2_febb_4210_9a20_2642f988ff0d.slice/cri-containerd-55dc398aaaef0b50e88b5a59a61e5b0c51ed686ea0982faa91a3fea7c0d4437a.scope
    95       cgroup_device   multi                                          
