xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 507
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 493
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 483
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 547
lxcf867f728163a(12) clsact/ingress cil_from_container-lxcf867f728163a id 520
lxce8f7ddcbd67f(14) clsact/ingress cil_from_container-lxce8f7ddcbd67f id 553
lxcac44143a6d49(18) clsact/ingress cil_from_container-lxcac44143a6d49 id 612

flow_dissector:

netfilter:

