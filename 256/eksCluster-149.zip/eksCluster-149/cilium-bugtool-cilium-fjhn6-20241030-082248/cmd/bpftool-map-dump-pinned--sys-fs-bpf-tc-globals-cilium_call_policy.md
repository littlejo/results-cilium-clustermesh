key: ed 00 00 00  value: 19 02 00 00
key: 4d 03 00 00  value: 04 02 00 00
key: 40 0c 00 00  value: 1a 02 00 00
key: 77 0f 00 00  value: 69 02 00 00
Found 4 elements
