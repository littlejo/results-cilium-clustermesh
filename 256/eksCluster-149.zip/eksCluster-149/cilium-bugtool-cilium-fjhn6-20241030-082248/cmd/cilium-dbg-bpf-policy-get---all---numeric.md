Endpoint ID: 237
Path: /sys/fs/bpf/tc/globals/cilium_policy_00237

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647494   20801     0        
Allow    Ingress     1          ANY          NONE         disabled    18022     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 845
Path: /sys/fs/bpf/tc/globals/cilium_policy_00845

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113702   1308      0        
Allow    Egress      0          ANY          NONE         disabled    15265    163       0        


Endpoint ID: 1741
Path: /sys/fs/bpf/tc/globals/cilium_policy_01741

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3136
Path: /sys/fs/bpf/tc/globals/cilium_policy_03136

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114729   1320      0        
Allow    Egress      0          ANY          NONE         disabled    17148    186       0        


Endpoint ID: 3959
Path: /sys/fs/bpf/tc/globals/cilium_policy_03959

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11379102   112004    0        
Allow    Ingress     1          ANY          NONE         disabled    9703125    101709    0        
Allow    Egress      0          ANY          NONE         disabled    11459993   113788    0        


