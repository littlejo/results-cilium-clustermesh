KEY             VALUE
AgentLiveness   1779580839001
UTimeOffset     3379443009765625
