{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.022Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.022Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.204.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:19.022Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:24.092Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:24.094Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:24.137Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:24.147Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:03.048Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:03.049Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:03.049Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:03.080Z",
  "value": "id=134   sec_id=4945197 flags=0x0000 ifindex=16  mac=AE:FC:40:90:E5:AF nodemac=AE:9A:53:C8:CC:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.048Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.048Z",
  "value": "id=134   sec_id=4945197 flags=0x0000 ifindex=16  mac=AE:FC:40:90:E5:AF nodemac=AE:9A:53:C8:CC:E6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.048Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.048Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.716Z",
  "value": "id=3959  sec_id=4945197 flags=0x0000 ifindex=18  mac=7E:05:C8:EF:80:8C nodemac=66:E8:0F:0E:CA:BF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.149.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.117Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.338Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.339Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.339Z",
  "value": "id=3959  sec_id=4945197 flags=0x0000 ifindex=18  mac=7E:05:C8:EF:80:8C nodemac=66:E8:0F:0E:CA:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.340Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.315Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.315Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.315Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.316Z",
  "value": "id=3959  sec_id=4945197 flags=0x0000 ifindex=18  mac=7E:05:C8:EF:80:8C nodemac=66:E8:0F:0E:CA:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.313Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.313Z",
  "value": "id=3959  sec_id=4945197 flags=0x0000 ifindex=18  mac=7E:05:C8:EF:80:8C nodemac=66:E8:0F:0E:CA:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.313Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.314Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.314Z",
  "value": "id=3959  sec_id=4945197 flags=0x0000 ifindex=18  mac=7E:05:C8:EF:80:8C nodemac=66:E8:0F:0E:CA:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.314Z",
  "value": "id=237   sec_id=4     flags=0x0000 ifindex=10  mac=BA:C5:A2:2A:74:0B nodemac=6A:AE:31:FA:C2:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.314Z",
  "value": "id=3136  sec_id=4925264 flags=0x0000 ifindex=14  mac=06:88:28:FC:33:10 nodemac=F6:4E:1D:07:B4:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.149.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.314Z",
  "value": "id=845   sec_id=4925264 flags=0x0000 ifindex=12  mac=D6:54:C1:A6:E6:08 nodemac=C2:27:96:27:6B:C7"
}

