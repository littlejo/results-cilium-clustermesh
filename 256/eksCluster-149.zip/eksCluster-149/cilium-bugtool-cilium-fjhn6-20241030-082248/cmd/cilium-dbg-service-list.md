ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.173.130:443 (active)    
                                         2 => 172.31.197.179:443 (active)    
2    10.100.234.20:443    ClusterIP      1 => 172.31.201.166:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.149.0.8:53 (active)         
                                         2 => 10.149.0.32:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.149.0.8:9153 (active)       
                                         2 => 10.149.0.32:9153 (active)      
5    10.100.59.243:2379   ClusterIP      1 => 10.149.0.172:2379 (active)     
