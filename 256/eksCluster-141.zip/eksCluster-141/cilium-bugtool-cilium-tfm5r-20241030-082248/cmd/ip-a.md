1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0c:90:39:f6:b5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.219.42/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3437sec preferred_lft 3437sec
    inet6 fe80::80c:90ff:fe39:f6b5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:89:7c:e5:ff:67 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.192.28/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::889:7cff:fee5:ff67/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:b5:fd:f4:3d:92 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30b5:fdff:fef4:3d92/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:ad:3a:16:cd:bf brd ff:ff:ff:ff:ff:ff
    inet 10.141.0.202/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::58ad:3aff:fe16:cdbf/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ea:e2:d6:24:9f:18 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e8e2:d6ff:fe24:9f18/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:dd:c4:17:e1:f8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c0dd:c4ff:fe17:e1f8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc82760e4d404@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:ef:0a:59:47:41 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::20ef:aff:fe59:4741/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc44058a405726@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:62:c8:cf:9e:71 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1062:c8ff:fecf:9e71/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca4dc910d1a52@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:71:71:ec:e7:ca brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a471:71ff:feec:e7ca/64 scope link 
       valid_lft forever preferred_lft forever
