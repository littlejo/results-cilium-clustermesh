xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 555
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 516
lxcc82760e4d404(12) clsact/ingress cil_from_container-lxcc82760e4d404 id 531
lxc44058a405726(14) clsact/ingress cil_from_container-lxc44058a405726 id 511
lxca4dc910d1a52(18) clsact/ingress cil_from_container-lxca4dc910d1a52 id 620

flow_dissector:

netfilter:

