{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.219.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:24.944Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:24.946Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.010Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.066Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.139Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:34.140Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:34.140Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:34.141Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:34.171Z",
  "value": "id=1209  sec_id=4669967 flags=0x0000 ifindex=16  mac=E6:DE:9F:4C:A1:63 nodemac=8A:9C:CE:1C:85:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.140Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.140Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.141Z",
  "value": "id=1209  sec_id=4669967 flags=0x0000 ifindex=16  mac=E6:DE:9F:4C:A1:63 nodemac=8A:9C:CE:1C:85:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.141Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.076Z",
  "value": "id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.141.0.169:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.458Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.704Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.705Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.705Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.706Z",
  "value": "id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.706Z",
  "value": "id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.713Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.713Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.713Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.695Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.695Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.695Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.695Z",
  "value": "id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.161:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.695Z",
  "value": "id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.696Z",
  "value": "id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.696Z",
  "value": "id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.141.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.696Z",
  "value": "id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71"
}

