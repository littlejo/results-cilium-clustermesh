filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc82760e4d404 direct-action not_in_hw id 531 tag eea2f8b2948822fa jited 
