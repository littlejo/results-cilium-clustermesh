KEY             VALUE
AgentLiveness   2005487345892
UTimeOffset     3379442568359375
