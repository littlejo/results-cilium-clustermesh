top - 08:22:49 up 32 min,  0 users,  load average: 0.18, 0.19, 0.14
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.7 us, 45.2 sy,  0.0 ni,  9.7 id,  0.0 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   7814.2 total,   4480.9 free,   1187.8 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6441.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 393048  77640 S  40.0   4.9   0:53.45 cilium-+
    696 root      20   0 1240432  16248  10960 S   6.7   0.2   0:00.04 cilium-+
    393 root      20   0 1229744   7864   3840 S   0.0   0.1   0:01.21 cilium-+
    677 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    678 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    722 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    740 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    746 root      20   0 1616520   8788   6284 S   0.0   0.1   0:00.00 runc:[2+
