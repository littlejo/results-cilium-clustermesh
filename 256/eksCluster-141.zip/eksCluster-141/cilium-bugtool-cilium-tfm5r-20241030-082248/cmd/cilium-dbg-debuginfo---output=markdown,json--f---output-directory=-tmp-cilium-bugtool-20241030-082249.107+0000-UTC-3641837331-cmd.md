markdown output at /tmp/cilium-bugtool-20241030-082249.107+0000-UTC-3641837331/cmd/cilium-debuginfo-20241030-082320.106+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.107+0000-UTC-3641837331/cmd/cilium-debuginfo-20241030-082320.106+0000-UTC.json
