[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc447d3_47e9_4afa_8358_1b8761553a25.slice/cri-containerd-09b743a14f93aeca690b603c2cfd1425c80bddeb44f080ec09fa44b74115a2b7.scope"
      }
    ],
    "ips": [
      "10.141.0.177"
    ],
    "name": "coredns-cc6ccd49c-t2pbz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-fce8c742b3443cc254de2d6c52718497483ee2f0f22b4232fd78bd3ae958623d.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-a09a1029e373fecbd8c5ee937ffdbb96891159698289b22f05c32669bb1a2d62.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-f8d5c18810145b721c3de67357084eb9fb7153ea0eb9e79ab97a1aa352b0438d.scope"
      }
    ],
    "ips": [
      "10.141.0.161"
    ],
    "name": "clustermesh-apiserver-7b999bc85-4nzpp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad9e99fb_ece1_44f9_9200_8a340f443312.slice/cri-containerd-a0c69a81b2eed914a0201c02136a5b4977536109775784713924ea04d1882118.scope"
      }
    ],
    "ips": [
      "10.141.0.27"
    ],
    "name": "coredns-cc6ccd49c-7fdf8",
    "namespace": "kube-system"
  }
]

