CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc447d3_47e9_4afa_8358_1b8761553a25.slice/cri-containerd-dd791786d81cb6d9aabfb6612e36c40e7ded15f08655deba6983a87c31ea66d9.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bc447d3_47e9_4afa_8358_1b8761553a25.slice/cri-containerd-09b743a14f93aeca690b603c2cfd1425c80bddeb44f080ec09fa44b74115a2b7.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b7ca4f1_0a4f_44a0_b78c_4294e6ad40ba.slice/cri-containerd-b33c82eb6ca43f7307802fa57bef0ccc0e8cff9ed523b4b7e752d0081495d2fc.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b7ca4f1_0a4f_44a0_b78c_4294e6ad40ba.slice/cri-containerd-db086e50d9ff271d374505687685d80a6a3d7796c90a2782c75d70a51a0ab2ba.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d834551_9f95_4531_b664_50b54f37ac3c.slice/cri-containerd-51d6a0cf263a030bb7cd6253a982f456ec733169fd1d62250275bd8d61b496ab.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7d834551_9f95_4531_b664_50b54f37ac3c.slice/cri-containerd-8ff3536318b5eac4351119237490ed78a8b5fb54bfb3b5f3c8f828c8c2facc89.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad9e99fb_ece1_44f9_9200_8a340f443312.slice/cri-containerd-515b058a2db078eac3ecef0893c3a73ccd550aec108579a9994e31e3029662a5.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad9e99fb_ece1_44f9_9200_8a340f443312.slice/cri-containerd-a0c69a81b2eed914a0201c02136a5b4977536109775784713924ea04d1882118.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb63816bd_062e_4ec1_8463_ea6a99e31e43.slice/cri-containerd-39e25bda68b5763ea3caa9778d4d27d93bcc096c3947f54960c2674278fc2f6a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb63816bd_062e_4ec1_8463_ea6a99e31e43.slice/cri-containerd-4aebe4b3c8c632f9f26cbd234f59e109d1b310ca01c08891c190512eafc209c8.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-f8d5c18810145b721c3de67357084eb9fb7153ea0eb9e79ab97a1aa352b0438d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-fce8c742b3443cc254de2d6c52718497483ee2f0f22b4232fd78bd3ae958623d.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-f1830679926eb59de076d08634046d85939428b412e0a450a21b9359ff306cbb.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod75283274_212d_492c_be52_1d1679a6b2da.slice/cri-containerd-a09a1029e373fecbd8c5ee937ffdbb96891159698289b22f05c32669bb1a2d62.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70d4dc4b_0a08_430c_a786_9f25c3c6e0b3.slice/cri-containerd-237dd773ba55ef4fd351ac4f04df2e8d5ffd1d9491d8407f0cc8b8b691be7c70.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod70d4dc4b_0a08_430c_a786_9f25c3c6e0b3.slice/cri-containerd-31bec625af0689d433e48560ad1cc169fd18a657f1ede24600f4e611ff302f4a.scope
    99       cgroup_device   multi                                          
