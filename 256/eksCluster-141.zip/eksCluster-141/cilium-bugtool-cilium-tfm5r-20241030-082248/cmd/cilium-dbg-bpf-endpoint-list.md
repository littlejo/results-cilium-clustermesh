IP ADDRESS        LOCAL ENDPOINT INFO
10.141.0.27:0     id=1149  sec_id=4663319 flags=0x0000 ifindex=14  mac=E2:C9:1C:72:B1:59 nodemac=12:62:C8:CF:9E:71   
10.141.0.202:0    (localhost)                                                                                        
172.31.192.28:0   (localhost)                                                                                        
172.31.219.42:0   (localhost)                                                                                        
10.141.0.66:0     id=2428  sec_id=4     flags=0x0000 ifindex=10  mac=6E:4A:94:00:81:D1 nodemac=C2:DD:C4:17:E1:F8     
10.141.0.177:0    id=656   sec_id=4663319 flags=0x0000 ifindex=12  mac=6A:84:39:CA:EE:D4 nodemac=22:EF:0A:59:47:41   
10.141.0.161:0    id=431   sec_id=4669967 flags=0x0000 ifindex=18  mac=0E:6C:FE:CB:90:9A nodemac=A6:71:71:EC:E7:CA   
