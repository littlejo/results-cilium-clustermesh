ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.239.163:443 (active)   
                                          2 => 172.31.158.33:443 (active)    
2    10.100.125.215:443    ClusterIP      1 => 172.31.219.42:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.141.0.177:53 (active)      
                                          2 => 10.141.0.27:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.141.0.177:9153 (active)    
                                          2 => 10.141.0.27:9153 (active)     
5    10.100.171.157:2379   ClusterIP      1 => 10.141.0.161:2379 (active)    
