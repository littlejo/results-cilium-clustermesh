key: 06 00 00 00  value: 0a 8d 00 b1 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f db 2a 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 9e 21 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 8d 00 1b 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 8d 00 b1 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 8d 00 a1 09 4b 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 8d 00 1b 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ef a3 01 bb 00 00  00 00 00 00
Found 8 elements
