 08:22:49 up 32 min,  0 users,  load average: 0.18, 0.19, 0.14
