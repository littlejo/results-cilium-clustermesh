Endpoint ID: 382
Path: /sys/fs/bpf/tc/globals/cilium_policy_00382

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 431
Path: /sys/fs/bpf/tc/globals/cilium_policy_00431

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11342245   111648    0        
Allow    Ingress     1          ANY          NONE         disabled    9422426    98707     0        
Allow    Egress      0          ANY          NONE         disabled    11475826   113896    0        


Endpoint ID: 656
Path: /sys/fs/bpf/tc/globals/cilium_policy_00656

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131335   1507      0        
Allow    Egress      0          ANY          NONE         disabled    17258    188       0        


Endpoint ID: 1149
Path: /sys/fs/bpf/tc/globals/cilium_policy_01149

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    130406   1497      0        
Allow    Egress      0          ANY          NONE         disabled    17830    193       0        


Endpoint ID: 2428
Path: /sys/fs/bpf/tc/globals/cilium_policy_02428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640840   20753     0        
Allow    Ingress     1          ANY          NONE         disabled    19340     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


