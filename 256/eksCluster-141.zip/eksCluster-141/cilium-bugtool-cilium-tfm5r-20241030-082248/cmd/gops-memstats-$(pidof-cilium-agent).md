alloc: 178.90MB (187588504 bytes)
total-alloc: 2.18GB (2344867200 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 62344808
frees: 60323310
heap-alloc: 178.90MB (187588504 bytes)
heap-sys: 247.30MB (259309568 bytes)
heap-idle: 44.36MB (46514176 bytes)
heap-in-use: 202.94MB (212795392 bytes)
heap-released: 2.77MB (2908160 bytes)
heap-objects: 2021498
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.39MB (3554080 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1060337 bytes)
gc-sys: 6.03MB (6325760 bytes)
next-gc: when heap-alloc >= 214.04MB (224437960 bytes)
last-gc: 2024-10-30 08:22:49.675021132 +0000 UTC
gc-pause-total: 13.689976ms
gc-pause: 89335
gc-pause-end: 1730276569675021132
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004716603102225579
enable-gc: true
debug-gc: false
