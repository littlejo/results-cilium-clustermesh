REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34083     2690215     677    bpf_overlay.c
Interface                 INGRESS     617588    128865079   1132   bpf_host.c
Success                   EGRESS      14009     1095551     1694   bpf_host.c
Success                   EGRESS      260424    32985289    1308   bpf_lxc.c
Success                   EGRESS      33078     2615590     53     encap.h
Success                   INGRESS     302753    33972685    86     l3.h
Success                   INGRESS     323478    35611395    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
