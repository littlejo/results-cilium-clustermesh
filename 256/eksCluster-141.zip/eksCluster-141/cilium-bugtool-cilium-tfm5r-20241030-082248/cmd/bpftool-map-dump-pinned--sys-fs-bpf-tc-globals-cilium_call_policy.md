key: af 01 00 00  value: 74 02 00 00
key: 90 02 00 00  value: 1c 02 00 00
key: 7d 04 00 00  value: f8 01 00 00
key: 7c 09 00 00  value: 0b 02 00 00
Found 4 elements
