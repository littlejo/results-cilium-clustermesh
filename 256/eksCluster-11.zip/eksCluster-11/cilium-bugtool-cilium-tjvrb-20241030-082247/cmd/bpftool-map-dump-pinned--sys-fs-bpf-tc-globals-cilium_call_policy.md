key: db 00 00 00  value: 74 02 00 00
key: 99 01 00 00  value: f8 01 00 00
key: 9b 02 00 00  value: 0a 02 00 00
key: 15 0f 00 00  value: 0e 02 00 00
Found 4 elements
