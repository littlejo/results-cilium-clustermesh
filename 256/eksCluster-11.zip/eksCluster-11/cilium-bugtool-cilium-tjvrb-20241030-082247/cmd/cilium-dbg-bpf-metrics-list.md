REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37608     2978929     677    bpf_overlay.c
Interface                 INGRESS     668007    135896586   1132   bpf_host.c
Success                   EGRESS      17651     1395004     1694   bpf_host.c
Success                   EGRESS      285064    35382440    1308   bpf_lxc.c
Success                   EGRESS      38612     3056765     53     encap.h
Success                   INGRESS     329000    37298597    86     l3.h
Success                   INGRESS     349608    38926568    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
