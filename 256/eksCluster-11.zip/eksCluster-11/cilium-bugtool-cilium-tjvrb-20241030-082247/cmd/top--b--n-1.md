top - 08:22:49 up 36 min,  0 users,  load average: 0.12, 0.21, 0.17
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s):  6.9 us, 31.0 sy,  0.0 ni, 62.1 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4477.6 free,   1190.3 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6438.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    656 root      20   0 1240432  16560  11292 S   6.7   0.2   0:00.03 cilium-+
      1 root      20   0 1606336 381428  78772 S   0.0   4.8   0:55.92 cilium-+
    411 root      20   0 1229744   6992   3052 S   0.0   0.1   0:01.14 cilium-+
    645 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    650 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    655 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    657 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    666 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    719 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    737 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
