[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47b91f3d_5ec6_4902_a507_9bd071a2e61b.slice/cri-containerd-4c1c783793813fc6c93dbdce9df28fcaa319b9a0f730d55f1ed4fc0a5e93c7e6.scope"
      }
    ],
    "ips": [
      "10.11.0.203"
    ],
    "name": "coredns-cc6ccd49c-jq4sp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-d839a1c59959ee9a8404cc7ac4bbe07474c0b7b53cf4d89e587f47401f8ff2eb.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-4745978eab610826a208243a6a9a40707d7e6563d2fc3aeda7da88ff0c65e281.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-5135a1063227e8ead13533fb25cbe06652632a9a1c51fd204f1798d8d9088371.scope"
      }
    ],
    "ips": [
      "10.11.0.58"
    ],
    "name": "clustermesh-apiserver-57bd7c56dd-pchxw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53be3774_095f_4731_a561_df63f0882f38.slice/cri-containerd-1bb5c263e862b1c897075ea33a953ff95d3333d5d0ceb3416ece5b3c61a58c44.scope"
      }
    ],
    "ips": [
      "10.11.0.222"
    ],
    "name": "coredns-cc6ccd49c-c4tb5",
    "namespace": "kube-system"
  }
]

