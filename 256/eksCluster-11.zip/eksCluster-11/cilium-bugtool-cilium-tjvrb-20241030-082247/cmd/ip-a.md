1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ee:e5:46:16:85 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.201.141/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3221sec preferred_lft 3221sec
    inet6 fe80::8ee:e5ff:fe46:1685/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:49:dc:a4:e2:2d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.197.191/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::849:dcff:fea4:e22d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:03:72:c3:16:c3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2c03:72ff:fec3:16c3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:32:60:0f:4f:c1 brd ff:ff:ff:ff:ff:ff
    inet 10.11.0.183/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a032:60ff:fe0f:4fc1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:5a:09:ba:1c:86 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::705a:9ff:feba:1c86/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:c1:a1:4f:5e:93 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d0c1:a1ff:fe4f:5e93/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf9199cce4de7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:26:c1:7e:d4:1d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c826:c1ff:fe7e:d41d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc53f84eaf3a13@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:b3:9c:fc:5c:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::94b3:9cff:fefc:5cb1/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6e6642b0bda5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:46:32:a9:f2:62 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7c46:32ff:fea9:f262/64 scope link 
       valid_lft forever preferred_lft forever
