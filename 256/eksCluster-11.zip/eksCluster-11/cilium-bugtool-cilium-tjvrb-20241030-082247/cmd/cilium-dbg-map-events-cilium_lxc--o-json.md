{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.762Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.762Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:07.762Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.279Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.283Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.329Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.377Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:12.431Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.092Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.093Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.094Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.123Z",
  "value": "id=2095  sec_id=413016 flags=0x0000 ifindex=16  mac=A6:F9:EA:39:3C:40 nodemac=86:16:A4:BE:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.092Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.093Z",
  "value": "id=2095  sec_id=413016 flags=0x0000 ifindex=16  mac=A6:F9:EA:39:3C:40 nodemac=86:16:A4:BE:09:6D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.093Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.093Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.319Z",
  "value": "id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.11.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.701Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.769Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.771Z",
  "value": "id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.772Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.773Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.767Z",
  "value": "id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.768Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.769Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.769Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.767Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.767Z",
  "value": "id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.768Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.768Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.58:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.768Z",
  "value": "id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.769Z",
  "value": "id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.769Z",
  "value": "id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.11.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.769Z",
  "value": "id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D"
}

