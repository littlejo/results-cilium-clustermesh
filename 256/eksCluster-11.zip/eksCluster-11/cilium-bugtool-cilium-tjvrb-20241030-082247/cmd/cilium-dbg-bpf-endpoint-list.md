IP ADDRESS         LOCAL ENDPOINT INFO
10.11.0.203:0      id=3861  sec_id=397675 flags=0x0000 ifindex=12  mac=3A:05:C9:AA:E2:82 nodemac=CA:26:C1:7E:D4:1D   
10.11.0.222:0      id=409   sec_id=397675 flags=0x0000 ifindex=14  mac=6A:AF:F3:66:89:5C nodemac=96:B3:9C:FC:5C:B1   
10.11.0.96:0       id=667   sec_id=4     flags=0x0000 ifindex=10  mac=8A:57:B3:DA:95:0A nodemac=D2:C1:A1:4F:5E:93    
10.11.0.58:0       id=219   sec_id=413016 flags=0x0000 ifindex=18  mac=42:34:4B:89:3D:E4 nodemac=7E:46:32:A9:F2:62   
172.31.201.141:0   (localhost)                                                                                       
10.11.0.183:0      (localhost)                                                                                       
172.31.197.191:0   (localhost)                                                                                       
