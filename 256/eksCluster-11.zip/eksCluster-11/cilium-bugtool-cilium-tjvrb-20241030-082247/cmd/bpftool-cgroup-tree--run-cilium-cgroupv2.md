CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47b91f3d_5ec6_4902_a507_9bd071a2e61b.slice/cri-containerd-4c1c783793813fc6c93dbdce9df28fcaa319b9a0f730d55f1ed4fc0a5e93c7e6.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47b91f3d_5ec6_4902_a507_9bd071a2e61b.slice/cri-containerd-7f24c9961f8d4cb30c22abad7bff8e3cc9dbca05e05afb00b03928a6a1b6908e.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53be3774_095f_4731_a561_df63f0882f38.slice/cri-containerd-b2a9056faec31c4d7f0ef394958fe9efc0fafc7607630e224e7af6cfaf43cd90.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53be3774_095f_4731_a561_df63f0882f38.slice/cri-containerd-1bb5c263e862b1c897075ea33a953ff95d3333d5d0ceb3416ece5b3c61a58c44.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f16ddbb_0ffa_49b0_b7ee_ef60a2b327d8.slice/cri-containerd-b20371bd61d969890456204d2cb6c208d63e693f63e028e421b07b9aa0292673.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f16ddbb_0ffa_49b0_b7ee_ef60a2b327d8.slice/cri-containerd-ad196b06298c4e74611493590499ee40265b1aa9f823b2d9e5c9af30a6c021bb.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ecc3ce1_1a97_4aba_968a_15a6ee69d81d.slice/cri-containerd-a14a8632397a82cfe38562996dfa4f0686f322a430e3e8124d38dc78f81f82e4.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ecc3ce1_1a97_4aba_968a_15a6ee69d81d.slice/cri-containerd-9cd586671665bd6af6a293d2dcc00f7845e0384fca9e4fc5a1e92a2b3ac327e7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-c99ec36689bbcc9a08803daf8206fefd88f753907dd5c5a91038378e4c3a6f78.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-5135a1063227e8ead13533fb25cbe06652632a9a1c51fd204f1798d8d9088371.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-d839a1c59959ee9a8404cc7ac4bbe07474c0b7b53cf4d89e587f47401f8ff2eb.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c982c08_330d_41cf_867c_e3cae045476f.slice/cri-containerd-4745978eab610826a208243a6a9a40707d7e6563d2fc3aeda7da88ff0c65e281.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod136ed40f_0461_4795_8216_82c162e9e906.slice/cri-containerd-753cf0163fddebfda158b500aa3aff970a8c7f00bbe6cc73237f6cc20cee942f.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod136ed40f_0461_4795_8216_82c162e9e906.slice/cri-containerd-f914f9e31fc597709d8ee2ab71d528ef55ee1c256da3aab6f7e772951e647666.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91db7746_3bd2_4957_9c05_b7e5c51da4c8.slice/cri-containerd-6853bfc9581a9e251f6b1750542c7828b0d1aa382dfd1bb28289ae4f6847db3a.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91db7746_3bd2_4957_9c05_b7e5c51da4c8.slice/cri-containerd-0139680406aff3fc5d239ef047a9cec7871cd646cf4e0dd671e2586b69b65c41.scope
    103      cgroup_device   multi                                          
