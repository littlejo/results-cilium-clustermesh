markdown output at /tmp/cilium-bugtool-20241030-082248.913+0000-UTC-545925979/cmd/cilium-debuginfo-20241030-082320.072+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.913+0000-UTC-545925979/cmd/cilium-debuginfo-20241030-082320.072+0000-UTC.json
