alloc: 146.91MB (154044552 bytes)
total-alloc: 2.37GB (2540065288 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 65221638
frees: 64076002
heap-alloc: 146.91MB (154044552 bytes)
heap-sys: 247.14MB (259145728 bytes)
heap-idle: 54.80MB (57458688 bytes)
heap-in-use: 192.34MB (201687040 bytes)
heap-released: 2.76MB (2891776 bytes)
heap-objects: 1145636
stack-in-use: 64.81MB (67960832 bytes)
stack-sys: 64.81MB (67960832 bytes)
stack-mspan-inuse: 2.99MB (3137760 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1262489 bytes)
gc-sys: 6.01MB (6299064 bytes)
next-gc: when heap-alloc >= 213.65MB (224029848 bytes)
last-gc: 2024-10-30 08:23:05.874669471 +0000 UTC
gc-pause-total: 9.825899ms
gc-pause: 63908
gc-pause-end: 1730276585874669471
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003578405801455749
enable-gc: true
debug-gc: false
