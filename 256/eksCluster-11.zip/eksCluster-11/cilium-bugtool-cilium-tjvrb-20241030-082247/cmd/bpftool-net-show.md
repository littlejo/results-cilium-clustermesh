xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 558
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 517
lxcf9199cce4de7(12) clsact/ingress cil_from_container-lxcf9199cce4de7 id 530
lxc53f84eaf3a13(14) clsact/ingress cil_from_container-lxc53f84eaf3a13 id 511
lxc6e6642b0bda5(18) clsact/ingress cil_from_container-lxc6e6642b0bda5 id 620

flow_dissector:

netfilter:

