KEY             VALUE
AgentLiveness   2220338561537
UTimeOffset     3379442148437500
