key: ee 00 00 00  value: 15 02 00 00
key: fe 01 00 00  value: 20 02 00 00
key: 1d 08 00 00  value: 67 02 00 00
key: 7c 08 00 00  value: 29 02 00 00
Found 4 elements
