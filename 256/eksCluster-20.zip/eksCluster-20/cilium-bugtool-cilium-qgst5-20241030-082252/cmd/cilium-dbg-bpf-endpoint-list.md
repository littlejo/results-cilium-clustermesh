IP ADDRESS         LOCAL ENDPOINT INFO
172.31.190.191:0   (localhost)                                                                                       
172.31.175.194:0   (localhost)                                                                                       
10.20.0.89:0       id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8   
10.20.0.125:0      (localhost)                                                                                       
10.20.0.240:0      id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79   
10.20.0.123:0      id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B   
10.20.0.119:0      id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3    
