xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 513
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 497
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 494
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 487
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxccdec4f9cf6f5(12) clsact/ingress cil_from_container-lxccdec4f9cf6f5 id 521
lxcf54de4d75f65(14) clsact/ingress cil_from_container-lxcf54de4d75f65 id 539
lxc490571cacf0c(18) clsact/ingress cil_from_container-lxc490571cacf0c id 619

flow_dissector:

netfilter:

