[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-4e3ff920a56714295174e7dc802d486a2a0486d61ad1a52b1b68c9ec134bf6af.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-7172d3de1dc374e7ea3f3476369583a47fa82bfe58d26de79657e0a70f183a94.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-b57bc689738e9023178e7f7414b9879151cd31d3e7ed931be7056cf9e643ba47.scope"
      }
    ],
    "ips": [
      "10.20.0.123"
    ],
    "name": "clustermesh-apiserver-7fcd676786-r6kbz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod271b8f73_4221_4a24_ad53_4fe1fae79d44.slice/cri-containerd-b4ae8d50529cfe56911e475867d727a0d550ebfd8b964ace40200600c0d567e0.scope"
      }
    ],
    "ips": [
      "10.20.0.89"
    ],
    "name": "coredns-cc6ccd49c-lh5xb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb186953_88c9_4858_8a06_d2a00c77057c.slice/cri-containerd-fb1311a59fc54398d5c13c46da7dac4527702912ee661b2fd0ffe5946239605b.scope"
      }
    ],
    "ips": [
      "10.20.0.240"
    ],
    "name": "coredns-cc6ccd49c-hgj7w",
    "namespace": "kube-system"
  }
]

