Endpoint ID: 238
Path: /sys/fs/bpf/tc/globals/cilium_policy_00238

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    169654   1935      0        
Allow    Egress      0          ANY          NONE         disabled    19881    222       0        


Endpoint ID: 510
Path: /sys/fs/bpf/tc/globals/cilium_policy_00510

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171211   1964      0        
Allow    Egress      0          ANY          NONE         disabled    21857    245       0        


Endpoint ID: 2077
Path: /sys/fs/bpf/tc/globals/cilium_policy_02077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11534085   114618    0        
Allow    Ingress     1          ANY          NONE         disabled    10045539   105647    0        
Allow    Egress      0          ANY          NONE         disabled    12569060   123895    0        


Endpoint ID: 2172
Path: /sys/fs/bpf/tc/globals/cilium_policy_02172

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650642   20862     0        
Allow    Ingress     1          ANY          NONE         disabled    26574     311       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2756
Path: /sys/fs/bpf/tc/globals/cilium_policy_02756

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


