{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.756Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.175.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.756Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.756Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:14.403Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:14.413Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:14.461Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:14.462Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:14.472Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:44.188Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:44.189Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:44.190Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:44.217Z",
  "value": "id=803   sec_id=695119 flags=0x0000 ifindex=16  mac=86:7A:C0:83:3E:7B nodemac=46:6C:27:BA:A9:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:44.218Z",
  "value": "id=803   sec_id=695119 flags=0x0000 ifindex=16  mac=86:7A:C0:83:3E:7B nodemac=46:6C:27:BA:A9:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:45.189Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:45.189Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:45.189Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:45.189Z",
  "value": "id=803   sec_id=695119 flags=0x0000 ifindex=16  mac=86:7A:C0:83:3E:7B nodemac=46:6C:27:BA:A9:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.217Z",
  "value": "id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.20.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.556Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.345Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.345Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.345Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.345Z",
  "value": "id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.346Z",
  "value": "id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.347Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.347Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.348Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.346Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.346Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.347Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.347Z",
  "value": "id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.123:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.347Z",
  "value": "id=2077  sec_id=695119 flags=0x0000 ifindex=18  mac=16:A4:E2:A9:89:1A nodemac=0A:4C:AA:2E:35:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.348Z",
  "value": "id=2172  sec_id=4     flags=0x0000 ifindex=10  mac=4E:2C:16:FB:18:33 nodemac=9E:87:31:D2:7D:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.349Z",
  "value": "id=238   sec_id=697072 flags=0x0000 ifindex=12  mac=3E:43:BA:FE:BD:59 nodemac=8A:A1:C7:37:41:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.20.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.349Z",
  "value": "id=510   sec_id=697072 flags=0x0000 ifindex=14  mac=5E:1B:CF:E5:8C:F1 nodemac=0E:CC:EE:83:DC:D8"
}

