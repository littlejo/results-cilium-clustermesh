markdown output at /tmp/cilium-bugtool-20241030-082253.309+0000-UTC-1623943247/cmd/cilium-debuginfo-20241030-082324.483+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.309+0000-UTC-1623943247/cmd/cilium-debuginfo-20241030-082324.483+0000-UTC.json
