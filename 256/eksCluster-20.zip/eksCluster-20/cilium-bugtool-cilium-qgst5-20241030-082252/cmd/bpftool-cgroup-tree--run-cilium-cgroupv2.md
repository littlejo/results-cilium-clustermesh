CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod271b8f73_4221_4a24_ad53_4fe1fae79d44.slice/cri-containerd-b4ae8d50529cfe56911e475867d727a0d550ebfd8b964ace40200600c0d567e0.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod271b8f73_4221_4a24_ad53_4fe1fae79d44.slice/cri-containerd-05f8a2a63b06d4477adeeefd8dd9a6a015c883361c4ff22c2887b565722588b4.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b5fcf22_f45d_41d2_9289_9883909ceb3c.slice/cri-containerd-a2e02518ad43dbb2bfc44f9d18571961ec7bc5d6aa653ab3a0959d56b9f091b4.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b5fcf22_f45d_41d2_9289_9883909ceb3c.slice/cri-containerd-479104802b62ee8ddac2f90b7b9fb6d15c90d6e94cdb5386d78e1a43c4828e22.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb186953_88c9_4858_8a06_d2a00c77057c.slice/cri-containerd-fb1311a59fc54398d5c13c46da7dac4527702912ee661b2fd0ffe5946239605b.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfb186953_88c9_4858_8a06_d2a00c77057c.slice/cri-containerd-b7d3302e4186d3bc7c7b7e52aac547a578b3155cb5bd033c38f3de2695bdd7f3.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a9b7611_2af6_4cbe_91b1_54775a029d57.slice/cri-containerd-6bb96f89aadc8c0db86041e0712fb507c8fd991b7ee5feca0b6f407db25009dd.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a9b7611_2af6_4cbe_91b1_54775a029d57.slice/cri-containerd-06f47c636a5e8d97e2b2349e918b1908ad3fe62e85a4265deacce7605b6bb99f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-b57bc689738e9023178e7f7414b9879151cd31d3e7ed931be7056cf9e643ba47.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-520c97d330b58ddf1d26b61b12479a5ab079ad9b608d90480d8e9f228f69f2ba.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-4e3ff920a56714295174e7dc802d486a2a0486d61ad1a52b1b68c9ec134bf6af.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfa759c6c_015c_4e45_a393_350b270997e1.slice/cri-containerd-7172d3de1dc374e7ea3f3476369583a47fa82bfe58d26de79657e0a70f183a94.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7483e655_a525_4411_a552_5aa05f34086c.slice/cri-containerd-d4a4f151646261d976edf28d37ad792100e37eaad9b79094cfef51866fb6f675.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7483e655_a525_4411_a552_5aa05f34086c.slice/cri-containerd-af40630c4a32832f3471d87387fd344cdc3c4090dec95130e51465f9b2135f50.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72f1804d_91b2_45a3_8deb_442b971096d3.slice/cri-containerd-236ec66ae51a2cfdfb751769ba0b4df0c1ca87fd377f34df39b002fbc252e409.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod72f1804d_91b2_45a3_8deb_442b971096d3.slice/cri-containerd-6c88cd7f6e82f83c2e62bea477e7ae90edae3d0da4c375cd185bc541e9bb021e.scope
    93       cgroup_device   multi                                          
