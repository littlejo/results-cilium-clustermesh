REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36721     2905719     677    bpf_overlay.c
Interface                 INGRESS     648628    133151430   1132   bpf_host.c
Success                   EGRESS      16549     1302065     1694   bpf_host.c
Success                   EGRESS      271391    34140739    1308   bpf_lxc.c
Success                   EGRESS      36900     2920799     53     encap.h
Success                   INGRESS     314967    35428531    86     l3.h
Success                   INGRESS     335790    37076231    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
