alloc: 135.33MB (141902856 bytes)
total-alloc: 2.31GB (2480108688 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64216308
frees: 63022729
heap-alloc: 135.33MB (141902856 bytes)
heap-sys: 243.11MB (254918656 bytes)
heap-idle: 70.08MB (73482240 bytes)
heap-in-use: 173.03MB (181436416 bytes)
heap-released: 2.84MB (2973696 bytes)
heap-objects: 1193579
stack-in-use: 64.84MB (67993600 bytes)
stack-sys: 64.84MB (67993600 bytes)
stack-mspan-inuse: 2.90MB (3039040 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1084777 bytes)
gc-sys: 6.00MB (6286680 bytes)
next-gc: when heap-alloc >= 214.75MB (225185560 bytes)
last-gc: 2024-10-30 08:23:10.096997443 +0000 UTC
gc-pause-total: 8.414377ms
gc-pause: 143272
gc-pause-end: 1730276590096997443
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00033154116370527566
enable-gc: true
debug-gc: false
