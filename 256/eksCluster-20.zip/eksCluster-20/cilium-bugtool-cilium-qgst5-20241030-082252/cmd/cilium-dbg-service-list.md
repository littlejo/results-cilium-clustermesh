ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.155.244:443 (active)    
                                         2 => 172.31.203.144:443 (active)    
2    10.100.136.102:443   ClusterIP      1 => 172.31.175.194:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.20.0.89:53 (active)         
                                         2 => 10.20.0.240:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.20.0.89:9153 (active)       
                                         2 => 10.20.0.240:9153 (active)      
5    10.100.58.101:2379   ClusterIP      1 => 10.20.0.123:2379 (active)      
