 08:22:53 up 36 min,  0 users,  load average: 0.25, 0.28, 0.20
