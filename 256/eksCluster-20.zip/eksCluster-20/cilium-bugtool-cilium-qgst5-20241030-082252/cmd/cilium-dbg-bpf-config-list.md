KEY             VALUE
AgentLiveness   2214313642811
UTimeOffset     3379442167968750
