[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95cf3f36_3d8b_40a5_9f9e_be5d39f24503.slice/cri-containerd-a6ba2a437e85e0aea783052aedd371a964b25bce1fd4a9f40a1273e0e52b5350.scope"
      }
    ],
    "ips": [
      "10.97.0.80"
    ],
    "name": "coredns-cc6ccd49c-wxsmz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-47d6bca29299c6ea678380d76fe198190e232d3cc7f52ec7a1a333cc04802494.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-1487ff40914e155189f366981cfb3600e57cd800b137128aede8cc1399d0d037.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-bc8661f3bb4f03897b9ab67da7fb6e3a9a59e5b15234f9802293dbc6d2801e23.scope"
      }
    ],
    "ips": [
      "10.97.0.178"
    ],
    "name": "clustermesh-apiserver-5f6b566fcc-jhq2m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26293587_4fd8_42d6_8e66_2aea9d42340f.slice/cri-containerd-590fc321a474513c95b94fec1b2bb8b3fc357146104de7bb02bff0e202b6be55.scope"
      }
    ],
    "ips": [
      "10.97.0.209"
    ],
    "name": "coredns-cc6ccd49c-rtd87",
    "namespace": "kube-system"
  }
]

