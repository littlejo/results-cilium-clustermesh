1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:77:5f:80:63:31 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.220.44/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3172sec preferred_lft 3172sec
    inet6 fe80::877:5fff:fe80:6331/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:27:f6:2a:1b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.220.12/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::899:27ff:fef6:2a1b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:dc:90:a4:60:9f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8dc:90ff:fea4:609f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:6d:e7:9a:0c:8f brd ff:ff:ff:ff:ff:ff
    inet 10.97.0.210/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::146d:e7ff:fe9a:c8f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:fd:93:10:0c:d0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::68fd:93ff:fe10:cd0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:0d:83:fe:69:b7 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::fc0d:83ff:fefe:69b7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc54018f56af51@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:3d:8a:72:81:2c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::803d:8aff:fe72:812c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc790e9892532c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:d9:b8:77:99:83 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d9:b8ff:fe77:9983/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc1d5ca8d14fd1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:bd:eb:f1:20:a3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::34bd:ebff:fef1:20a3/64 scope link 
       valid_lft forever preferred_lft forever
