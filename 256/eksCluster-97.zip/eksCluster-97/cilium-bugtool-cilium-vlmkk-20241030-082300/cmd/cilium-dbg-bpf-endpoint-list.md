IP ADDRESS        LOCAL ENDPOINT INFO
10.97.0.209:0     id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83   
172.31.220.12:0   (localhost)                                                                                        
10.97.0.62:0      id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7     
10.97.0.80:0      id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C   
10.97.0.210:0     (localhost)                                                                                        
10.97.0.178:0     id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3   
172.31.220.44:0   (localhost)                                                                                        
