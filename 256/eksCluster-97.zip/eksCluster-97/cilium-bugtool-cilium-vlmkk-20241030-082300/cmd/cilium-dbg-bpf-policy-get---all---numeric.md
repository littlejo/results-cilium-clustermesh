Endpoint ID: 599
Path: /sys/fs/bpf/tc/globals/cilium_policy_00599

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 894
Path: /sys/fs/bpf/tc/globals/cilium_policy_00894

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176064   2025      0        
Allow    Egress      0          ANY          NONE         disabled    22046    247       0        


Endpoint ID: 1123
Path: /sys/fs/bpf/tc/globals/cilium_policy_01123

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11502333   113973    0        
Allow    Ingress     1          ANY          NONE         disabled    9367673    98038     0        
Allow    Egress      0          ANY          NONE         disabled    12208381   120933    0        


Endpoint ID: 1697
Path: /sys/fs/bpf/tc/globals/cilium_policy_01697

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174647   2009      0        
Allow    Egress      0          ANY          NONE         disabled    22400    252       0        


Endpoint ID: 3929
Path: /sys/fs/bpf/tc/globals/cilium_policy_03929

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1677766   21255     0        
Allow    Ingress     1          ANY          NONE         disabled    26424     310       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


