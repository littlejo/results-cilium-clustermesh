ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.174.15:443 (active)    
                                        2 => 172.31.205.69:443 (active)    
2    10.100.42.84:443    ClusterIP      1 => 172.31.220.44:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.97.0.80:53 (active)        
                                        2 => 10.97.0.209:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.97.0.80:9153 (active)      
                                        2 => 10.97.0.209:9153 (active)     
5    10.100.70.18:2379   ClusterIP      1 => 10.97.0.178:2379 (active)     
