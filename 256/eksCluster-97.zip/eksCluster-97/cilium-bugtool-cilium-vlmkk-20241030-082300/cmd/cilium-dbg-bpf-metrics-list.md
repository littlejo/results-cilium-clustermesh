REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35968     2837005     677    bpf_overlay.c
Interface                 INGRESS     629800    131328979   1132   bpf_host.c
Success                   EGRESS      15427     1208384     1694   bpf_host.c
Success                   EGRESS      266984    33471234    1308   bpf_lxc.c
Success                   EGRESS      35330     2794943     53     encap.h
Success                   INGRESS     306023    34514058    86     l3.h
Success                   INGRESS     327215    36186725    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
