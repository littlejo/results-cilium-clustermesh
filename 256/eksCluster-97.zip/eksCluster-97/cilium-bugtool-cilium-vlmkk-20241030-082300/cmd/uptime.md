 08:23:02 up 37 min,  0 users,  load average: 0.20, 0.21, 0.17
