CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26293587_4fd8_42d6_8e66_2aea9d42340f.slice/cri-containerd-f7354bab1f05be4cd748b933acd43d274e44f8a73f714769a5397d5364cf7cad.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod26293587_4fd8_42d6_8e66_2aea9d42340f.slice/cri-containerd-590fc321a474513c95b94fec1b2bb8b3fc357146104de7bb02bff0e202b6be55.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95cf3f36_3d8b_40a5_9f9e_be5d39f24503.slice/cri-containerd-60e7b3182ce95adef82589047a725892a1e4a8b85058f4825038e601dc1ad5ed.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95cf3f36_3d8b_40a5_9f9e_be5d39f24503.slice/cri-containerd-a6ba2a437e85e0aea783052aedd371a964b25bce1fd4a9f40a1273e0e52b5350.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2868daf_648d_4f5c_8e98_b72b07b15931.slice/cri-containerd-4103264da9bfeae149d4fd68337e7d6bf5f4cda7340cd4a954f6184113712180.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb2868daf_648d_4f5c_8e98_b72b07b15931.slice/cri-containerd-2180d722120920fe0519e9418cea160de264c6798c40a5d0f3bf6b08883d4ca9.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53566742_7689_481f_85b4_122693460da0.slice/cri-containerd-4ae6b499916437267e441b627bc0228df504d33a52844c48f19d380a101688e3.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53566742_7689_481f_85b4_122693460da0.slice/cri-containerd-51a6b88f7da8435b24fbc0efbf47f516902768a088db76799c553402f9d5de07.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-6537d11a8d61a2849140c0e6bd34f2f8147bbcba4d9767a0bc58babbc497febf.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-bc8661f3bb4f03897b9ab67da7fb6e3a9a59e5b15234f9802293dbc6d2801e23.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-47d6bca29299c6ea678380d76fe198190e232d3cc7f52ec7a1a333cc04802494.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd893ec4c_4f30_4ee2_b81c_413b5f9d5400.slice/cri-containerd-1487ff40914e155189f366981cfb3600e57cd800b137128aede8cc1399d0d037.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cdb10d5_9758_4fcb_be2d_46641e2a5a17.slice/cri-containerd-8c28b4f791d1db7d32bb9051ccc837b17378c7dfaee044bfb88c505b4903f446.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0cdb10d5_9758_4fcb_be2d_46641e2a5a17.slice/cri-containerd-0ee2dc8ebf5af5d567e9194012204ee472ae40d591838af9e9329833bb0261c3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41d9f4f8_f212_4bba_b4d8_5bd2c94414f3.slice/cri-containerd-9d33a0605f101b193d4789216dc079eca27a8c7ffb2a04796c49246559aef59a.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41d9f4f8_f212_4bba_b4d8_5bd2c94414f3.slice/cri-containerd-d1b2cd72f1dcb23f5371d32616c12bb99abc6e469be922e91a88f75f79232258.scope
    99       cgroup_device   multi                                          
