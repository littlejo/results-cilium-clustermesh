KEY             VALUE
AgentLiveness   2270137410845
UTimeOffset     3379442076171875
