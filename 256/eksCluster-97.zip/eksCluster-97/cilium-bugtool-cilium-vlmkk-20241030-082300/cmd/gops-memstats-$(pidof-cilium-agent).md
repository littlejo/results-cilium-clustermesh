alloc: 140.71MB (147541256 bytes)
total-alloc: 2.26GB (2425606488 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63433721
frees: 62343967
heap-alloc: 140.71MB (147541256 bytes)
heap-sys: 243.23MB (255049728 bytes)
heap-idle: 62.08MB (65093632 bytes)
heap-in-use: 181.16MB (189956096 bytes)
heap-released: 1.03MB (1081344 bytes)
heap-objects: 1089754
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 2.76MB (2898080 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 981.28KB (1004833 bytes)
gc-sys: 6.04MB (6334000 bytes)
next-gc: when heap-alloc >= 213.17MB (223528232 bytes)
last-gc: 2024-10-30 08:23:15.123896057 +0000 UTC
gc-pause-total: 16.512805ms
gc-pause: 105371
gc-pause-end: 1730276595123896057
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004054419238069975
enable-gc: true
debug-gc: false
