{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.578Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.578Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.220.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:58.578Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.181Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.187Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.253Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.312Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:03.429Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.863Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.864Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.864Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:16.892Z",
  "value": "id=2892  sec_id=3223588 flags=0x0000 ifindex=16  mac=56:52:F8:10:06:3E nodemac=6E:54:11:04:7C:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:17.862Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:17.862Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:17.862Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:17.863Z",
  "value": "id=2892  sec_id=3223588 flags=0x0000 ifindex=16  mac=56:52:F8:10:06:3E nodemac=6E:54:11:04:7C:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.450Z",
  "value": "id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.97.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.853Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.838Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.839Z",
  "value": "id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.840Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.840Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.869Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.879Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.880Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.880Z",
  "value": "id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.832Z",
  "value": "id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.832Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.832Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.833Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.832Z",
  "value": "id=3929  sec_id=4     flags=0x0000 ifindex=10  mac=42:36:A8:34:36:81 nodemac=FE:0D:83:FE:69:B7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.833Z",
  "value": "id=1697  sec_id=3224540 flags=0x0000 ifindex=12  mac=7E:21:A2:BB:25:31 nodemac=82:3D:8A:72:81:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.833Z",
  "value": "id=894   sec_id=3224540 flags=0x0000 ifindex=14  mac=92:F6:F4:12:F6:1B nodemac=02:D9:B8:77:99:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.97.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.834Z",
  "value": "id=1123  sec_id=3223588 flags=0x0000 ifindex=18  mac=0E:71:D8:73:5A:D8 nodemac=36:BD:EB:F1:20:A3"
}

