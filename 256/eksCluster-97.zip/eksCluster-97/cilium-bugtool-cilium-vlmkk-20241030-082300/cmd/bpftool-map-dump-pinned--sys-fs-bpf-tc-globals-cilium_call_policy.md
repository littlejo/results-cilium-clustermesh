key: 7e 03 00 00  value: 01 02 00 00
key: 63 04 00 00  value: 76 02 00 00
key: a1 06 00 00  value: 07 02 00 00
key: 59 0f 00 00  value: 1f 02 00 00
Found 4 elements
