Endpoint ID: 521
Path: /sys/fs/bpf/tc/globals/cilium_policy_00521

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174290   1993      0        
Allow    Egress      0          ANY          NONE         disabled    21284    239       0        


Endpoint ID: 900
Path: /sys/fs/bpf/tc/globals/cilium_policy_00900

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11575454   115830    0        
Allow    Ingress     1          ANY          NONE         disabled    10577335   111366    0        
Allow    Egress      0          ANY          NONE         disabled    13334371   130742    0        


Endpoint ID: 1129
Path: /sys/fs/bpf/tc/globals/cilium_policy_01129

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176373   2019      0        
Allow    Egress      0          ANY          NONE         disabled    23171    261       0        


Endpoint ID: 3178
Path: /sys/fs/bpf/tc/globals/cilium_policy_03178

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3877
Path: /sys/fs/bpf/tc/globals/cilium_policy_03877

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659465   21017     0        
Allow    Ingress     1          ANY          NONE         disabled    27294     320       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


