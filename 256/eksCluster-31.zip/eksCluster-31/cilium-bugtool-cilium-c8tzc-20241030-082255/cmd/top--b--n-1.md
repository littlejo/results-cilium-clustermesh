top - 08:22:57 up 38 min,  0 users,  load average: 0.63, 0.44, 0.27
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 42.9 us, 42.9 sy,  0.0 ni,  7.1 id,  0.0 wa,  0.0 hi,  7.1 si,  0.0 st
MiB Mem :   7814.2 total,   4481.8 free,   1186.0 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    722 root      20   0 1244340  21924  14340 S  46.7   0.3   0:00.07 hubble
      1 root      20   0 1606080 384860  78064 S   6.7   4.8   1:04.61 cilium-+
    677 root      20   0 1240432  16792  11484 S   6.7   0.2   0:00.03 cilium-+
    420 root      20   0 1229744   7944   3836 S   0.0   0.1   0:01.18 cilium-+
    635 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    650 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    671 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    683 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    715 root      20   0    2208    792    712 S   0.0   0.0   0:00.00 timeout
    723 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
