REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38083     3014303     677    bpf_overlay.c
Interface                 INGRESS     664507    135056686   1132   bpf_host.c
Success                   EGRESS      17747     1401143     1694   bpf_host.c
Success                   EGRESS      278144    34684190    1308   bpf_lxc.c
Success                   EGRESS      38959     3082937     53     encap.h
Success                   INGRESS     323185    36400500    86     l3.h
Success                   INGRESS     344172    38057706    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
