# Cilium debug information

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 39890878                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 39890878                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 39890878                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4014800000 rw-p 00000000 00:00 0 
4014800000-4018000000 ---p 00000000 00:00 0 
ffff6dfaa000-ffff6e312000 rw-p 00000000 00:00 0 
ffff6e316000-ffff6e457000 rw-p 00000000 00:00 0 
ffff6e45e000-ffff6e540000 rw-p 00000000 00:00 0 
ffff6e540000-ffff6e581000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e581000-ffff6e5c2000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e5c2000-ffff6e602000 rw-p 00000000 00:00 0 
ffff6e602000-ffff6e604000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e604000-ffff6e606000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e606000-ffff6eb9d000 rw-p 00000000 00:00 0 
ffff6eb9d000-ffff6ec9d000 rw-p 00000000 00:00 0 
ffff6ec9d000-ffff6ecae000 rw-p 00000000 00:00 0 
ffff6ecae000-ffff70cae000 rw-p 00000000 00:00 0 
ffff70cae000-ffff70d2e000 ---p 00000000 00:00 0 
ffff70d2e000-ffff70d2f000 rw-p 00000000 00:00 0 
ffff70d2f000-ffff90d2e000 ---p 00000000 00:00 0 
ffff90d2e000-ffff90d2f000 rw-p 00000000 00:00 0 
ffff90d2f000-ffffb0cbe000 ---p 00000000 00:00 0 
ffffb0cbe000-ffffb0cbf000 rw-p 00000000 00:00 0 
ffffb0cbf000-ffffb4cb0000 ---p 00000000 00:00 0 
ffffb4cb0000-ffffb4cb1000 rw-p 00000000 00:00 0 
ffffb4cb1000-ffffb54ae000 ---p 00000000 00:00 0 
ffffb54ae000-ffffb54af000 rw-p 00000000 00:00 0 
ffffb54af000-ffffb55ae000 ---p 00000000 00:00 0 
ffffb55ae000-ffffb560e000 rw-p 00000000 00:00 0 
ffffb560e000-ffffb5610000 r--p 00000000 00:00 0                          [vvar]
ffffb5610000-ffffb5611000 r-xp 00000000 00:00 0                          [vdso]
ffffca733000-ffffca754000 rw-p 00000000 00:00 0                          [stack]

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.31.0.64": (string) (len=6) "health",
  (string) (len=11) "10.31.0.111": (string) (len=35) "kube-system/coredns-cc6ccd49c-dbw26",
  (string) (len=10) "10.31.0.73": (string) (len=35) "kube-system/coredns-cc6ccd49c-4rr5s",
  (string) (len=10) "10.31.0.38": (string) (len=49) "kube-system/clustermesh-apiserver-dfb7b889d-mh9zz",
  (string) (len=10) "10.31.0.31": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.222.197": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4000c0bb80)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001d8a0c0,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001d8a0c0,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002ba8a50)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002ba8b00)(frontends:[10.100.57.55]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002ba8c60)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x400333e4d0)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40013a8b00)(frontends:[10.100.178.142]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x40012b0160)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002c955f0)(172.31.165.16:443/TCP,172.31.253.60:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x40012b0168)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-zbmk9": (*k8s.Endpoints)(0x40007641a0)(172.31.222.197:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x40012b0170)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-sbmd8": (*k8s.Endpoints)(0x40033de9c0)(10.31.0.111:53/TCP[eu-west-3b],10.31.0.111:53/UDP[eu-west-3b],10.31.0.111:9153/TCP[eu-west-3b],10.31.0.73:53/TCP[eu-west-3b],10.31.0.73:53/UDP[eu-west-3b],10.31.0.73:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x40016c6f30)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-dxfm2": (*k8s.Endpoints)(0x4003594680)(10.31.0.38:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40004bd5e0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x40021b54a0)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x4007f7e360
  },
  gcTrigger: (chan struct {}) (cap=1) 0x4001d66ae0,
  gcExited: (chan struct {}) 0x4001d66ba0,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4000acbe80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001968ca8)({
      MetricVec: (*prometheus.MetricVec)(0x4001531f50)({
       metricMap: (*prometheus.metricMap)(0x4001c90000)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9f860)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4000acbf00)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001968cb0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c90060)({
       metricMap: (*prometheus.metricMap)(0x4001c90090)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9f8c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001c92000)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968cb8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c900f0)({
       metricMap: (*prometheus.metricMap)(0x4001c90120)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9f920)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001c92080)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968cc0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c90180)({
       metricMap: (*prometheus.metricMap)(0x4001c901b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9f980)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001c92100)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968cc8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c90210)({
       metricMap: (*prometheus.metricMap)(0x4001c90240)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9f9e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001c92180)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968cd0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c902a0)({
       metricMap: (*prometheus.metricMap)(0x4001c902d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9fa40)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001c92200)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968cd8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c90330)({
       metricMap: (*prometheus.metricMap)(0x4001c90360)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9faa0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001c92280)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001968ce0)({
      MetricVec: (*prometheus.MetricVec)(0x4001c903c0)({
       metricMap: (*prometheus.metricMap)(0x4001c903f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9fb00)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001c92300)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001968ce8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c90450)({
       metricMap: (*prometheus.metricMap)(0x4001c90480)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000e9fb60)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40004bd5e0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001caaa10)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001c813e0)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 385ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4
  }
 })
})

```


#### Cilium encryption



#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium environment keys

```
k8s-service-proxy-name:
k8s-kubeconfig-path:
exclude-node-label-patterns:
bpf-lb-dsr-l4-xlate:frontend
bpf-lb-algorithm:random
dnsproxy-socket-linger-timeout:10
ipv6-mcast-device:
conntrack-gc-max-interval:0s
cluster-health-port:4240
bpf-lb-acceleration:disabled
clustermesh-enable-endpoint-sync:false
mesh-auth-signal-backoff-duration:1s
cmdref:
conntrack-gc-interval:0s
agent-labels:
ipsec-key-rotation-duration:5m0s
fixed-identity-mapping:
k8s-service-cache-size:128
cni-chaining-mode:none
egress-gateway-reconciliation-trigger-interval:1s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
cilium-endpoint-gc-interval:5m0s
label-prefix-file:
bpf-ct-global-tcp-max:524288
kube-proxy-replacement-healthz-bind-address:
set-cilium-node-taints:true
enable-bbr:false
enable-ipv6-masquerade:true
enable-local-redirect-policy:false
fqdn-regex-compile-lru-size:1024
keep-config:false
certificates-directory:/var/run/cilium/certs
use-cilium-internal-ip-for-ipsec:false
l2-announcements-lease-duration:15s
srv6-encap-mode:reduced
encryption-strict-mode-cidr:
agent-health-port:9879
install-iptables-rules:true
bpf-events-drop-enabled:true
enable-bpf-masquerade:false
tofqdns-max-deferred-connection-deletes:10000
external-envoy-proxy:true
ipv6-node:auto
ip-masq-agent-config-path:/etc/config/ip-masq-agent
envoy-base-id:0
bpf-lb-sock-terminate-pod-connections:false
mesh-auth-queue-size:1024
ipam-multi-pool-pre-allocation:
clustermesh-sync-timeout:1m0s
ipam-cilium-node-update-rate:15s
hubble-prefer-ipv6:false
enable-high-scale-ipcache:false
pprof:false
bpf-ct-timeout-regular-tcp-fin:10s
hubble-redact-http-headers-deny:
labels:
hubble-redact-http-urlquery:false
enable-ipv6-big-tcp:false
kube-proxy-replacement:false
enable-l7-proxy:true
k8s-client-burst:20
enable-service-topology:false
direct-routing-device:
operator-api-serve-addr:127.0.0.1:9234
log-system-load:false
bpf-ct-timeout-service-tcp:2h13m20s
hubble-redact-enabled:false
bpf-lb-service-backend-map-max:0
endpoint-gc-interval:5m0s
tunnel-protocol:vxlan
proxy-admin-port:0
hubble-monitor-events:
bpf-map-event-buffers:
enable-active-connection-tracking:false
bpf-nat-global-max:524288
k8s-client-connection-keep-alive:30s
enable-hubble-recorder-api:true
hubble-export-allowlist:
agent-liveness-update-interval:1s
nat-map-stats-entries:32
enable-xdp-prefilter:false
k8s-sync-timeout:3m0s
direct-routing-skip-unreachable:false
enable-node-port:false
enable-stale-cilium-endpoint-cleanup:true
metrics:
monitor-aggregation:medium
bpf-lb-sock-hostns-only:false
l2-announcements-renew-deadline:5s
proxy-xff-num-trusted-hops-egress:0
bpf-lb-mode:snat
tofqdns-enable-dns-compression:true
hubble-metrics-server:
enable-endpoint-health-checking:true
cluster-name:cmesh32
bypass-ip-availability-upon-restore:false
mke-cgroup-mount:
hubble-export-file-max-backups:5
enable-external-ips:false
endpoint-queue-size:25
trace-sock:true
enable-masquerade-to-route-source:false
exclude-local-address:
bpf-lb-maglev-map-max:0
pprof-address:localhost
bpf-map-dynamic-size-ratio:0.0025
enable-identity-mark:true
enable-ipv4:true
bpf-fragments-map-max:8192
log-opt:
enable-k8s:true
config:
policy-trigger-interval:1s
enable-icmp-rules:true
policy-accounting:true
enable-policy:default
gateway-api-secrets-namespace:
monitor-aggregation-interval:5s
envoy-config-retry-interval:15s
k8s-require-ipv6-pod-cidr:false
node-port-bind-protection:true
prometheus-serve-addr:
mesh-auth-enabled:true
tofqdns-proxy-response-max-delay:100ms
tunnel-port:0
egress-multi-home-ip-rule-compat:false
enable-route-mtu-for-cni-chaining:false
policy-cidr-match-mode:
dnsproxy-insecure-skip-transparent-mode-check:false
multicast-enabled:false
vtep-endpoint:
enable-nat46x64-gateway:false
k8s-require-ipv4-pod-cidr:false
proxy-xff-num-trusted-hops-ingress:0
api-rate-limit:
k8s-api-server:
enable-auto-protect-node-port-range:true
ingress-secrets-namespace:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
hubble-export-file-max-size-mb:10
enable-custom-calls:false
envoy-secrets-namespace:
enable-monitor:true
max-connected-clusters:511
use-full-tls-context:false
enable-wireguard:false
http-retry-count:3
kvstore:
vtep-cidr:
tofqdns-dns-reject-response-code:refused
allow-localhost:auto
endpoint-bpf-prog-watchdog-interval:30s
wireguard-persistent-keepalive:0s
bpf-lb-rev-nat-map-max:0
proxy-idle-timeout-seconds:60
enable-health-check-loadbalancer-ip:false
ipam:cluster-pool
disable-iptables-feeder-rules:
enable-cilium-api-server-access:
bpf-events-policy-verdict-enabled:true
http-retry-timeout:0
enable-tracing:false
enable-k8s-networkpolicy:true
http-normalize-path:true
k8s-client-qps:10
container-ip-local-reserved-ports:auto
clustermesh-enable-mcs-api:false
socket-path:/var/run/cilium/cilium.sock
nat-map-stats-interval:30s
bpf-events-trace-enabled:true
enable-svc-source-range-check:true
state-dir:/var/run/cilium
hubble-export-denylist:
identity-heartbeat-timeout:30m0s
node-port-algorithm:random
enable-ipsec-encrypted-overlay:false
dnsproxy-lock-count:131
enable-tcx:true
envoy-config-timeout:2m0s
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
dnsproxy-concurrency-limit:0
cluster-id:32
http-idle-timeout:0
cflags:
egress-gateway-policy-map-max:16384
bpf-ct-timeout-regular-tcp-syn:1m0s
allocator-list-timeout:3m0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
enable-endpoint-routes:false
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-runtime-device-detection:true
bpf-lb-service-map-max:0
join-cluster:false
enable-hubble:true
bpf-lb-rss-ipv4-src-cidr:
hubble-export-file-path:
kvstore-lease-ttl:15m0s
kvstore-max-consecutive-quorum-errors:2
kvstore-connectivity-timeout:2m0s
enable-ipv4-masquerade:true
proxy-portrange-min:10000
cni-exclusive:true
crd-wait-timeout:5m0s
http-request-timeout:3600
synchronize-k8s-nodes:true
monitor-queue-size:0
mesh-auth-spire-admin-socket:
allow-icmp-frag-needed:true
kvstore-opt:
operator-prometheus-serve-addr::9963
enable-vtep:false
proxy-prometheus-port:0
bpf-lb-map-max:65536
enable-k8s-endpoint-slice:true
mesh-auth-gc-interval:5m0s
controller-group-metrics:
enable-recorder:false
enable-mke:false
proxy-max-connection-duration-seconds:0
debug-verbose:
trace-payloadlen:128
policy-queue-size:100
iptables-lock-timeout:5s
enable-cilium-endpoint-slice:false
ipv4-native-routing-cidr:
proxy-max-requests-per-connection:0
debug:false
identity-gc-interval:15m0s
enable-ipv6:false
iptables-random-fully:false
version:false
cni-external-routing:false
static-cnp-path:
enable-ip-masq-agent:false
node-labels:
prepend-iptables-chains:true
proxy-portrange-max:20000
dnsproxy-concurrency-processing-grace-period:0s
bpf-sock-rev-map-max:262144
tofqdns-idle-connection-grace-period:0s
proxy-connect-timeout:2
node-port-acceleration:disabled
node-port-mode:snat
mesh-auth-rotated-identities-queue-size:1024
install-no-conntrack-iptables-rules:false
enable-wireguard-userspace-fallback:false
enable-xt-socket-fallback:true
enable-encryption-strict-mode:false
tofqdns-min-ttl:0
enable-unreachable-routes:false
ipsec-key-file:
nodeport-addresses:
tofqdns-proxy-port:0
ipv4-service-range:auto
hubble-drop-events-interval:2m0s
bpf-ct-global-any-max:262144
bpf-lb-source-range-map-max:0
clustermesh-ip-identities-sync-timeout:1m0s
enable-gateway-api:false
bgp-config-path:/var/lib/cilium/bgp/config.yaml
enable-k8s-api-discovery:false
cgroup-root:/run/cilium/cgroupv2
hubble-event-buffer-capacity:4095
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
clustermesh-config:/var/lib/cilium/clustermesh/
vlan-bpf-bypass:
ipv4-range:auto
enable-health-checking:true
enable-bandwidth-manager:false
mesh-auth-spiffe-trust-domain:spiffe.cilium
service-no-backend-response:reject
cluster-pool-ipv4-mask-size:24
config-dir:/tmp/cilium/config-map
enable-l2-pod-announcements:false
max-internal-timer-delay:0s
hubble-flowlogs-config-path:
enable-metrics:true
hubble-export-fieldmask:
mesh-auth-mutual-connect-timeout:5s
routing-mode:tunnel
identity-change-grace-period:5s
vtep-mac:
bgp-announce-lb-ip:false
procfs:/host/proc
enable-host-legacy-routing:false
derive-masq-ip-addr-from-device:
bpf-lb-rss-ipv6-src-cidr:
enable-ipv4-fragment-tracking:true
mtu:0
dns-policy-unload-on-shutdown:false
devices:
ipv4-service-loopback-address:169.254.42.1
tofqdns-pre-cache:
local-router-ipv6:
hubble-listen-address::4244
enable-ipip-termination:false
annotate-k8s-node:false
bpf-ct-timeout-regular-tcp:2h13m20s
hubble-export-file-compress:false
remove-cilium-node-taints:true
bpf-policy-map-full-reconciliation-interval:15m0s
enable-well-known-identities:false
bpf-lb-affinity-map-max:0
enable-bgp-control-plane:false
enable-l2-announcements:false
hubble-drop-events-reasons:auth_required,policy_denied
enable-ipsec-key-watcher:true
bgp-announce-pod-cidr:false
cni-chaining-target:
cni-log-file:/var/run/cilium/cilium-cni.log
set-cilium-is-up-condition:true
egress-masquerade-interfaces:ens+
dnsproxy-enable-transparent-mode:true
tofqdns-endpoint-max-ip-per-hostname:50
hubble-disable-tls:false
read-cni-conf:
enable-host-firewall:false
hubble-skip-unknown-cgroup-ids:true
bpf-policy-map-max:16384
hubble-socket-path:/var/run/cilium/hubble.sock
route-metric:0
identity-restore-grace-period:30s
bpf-lb-external-clusterip:false
l2-pod-announcements-interface:
config-sources:config-map:kube-system/cilium-config
enable-ipv6-ndp:false
nodes-gc-interval:5m0s
enable-pmtu-discovery:false
bpf-auth-map-max:524288
enable-cilium-health-api-server-access:
enable-ingress-controller:false
ipv4-node:auto
unmanaged-pod-watcher-interval:15
ipv6-cluster-alloc-cidr:f00d::/64
enable-l2-neigh-discovery:true
encrypt-interface:
enable-bpf-tproxy:false
enable-local-node-route:true
disable-envoy-version-check:false
bpf-lb-dsr-dispatch:opt
k8s-client-connection-timeout:30s
node-port-range:
envoy-log:
kvstore-periodic-sync:5m0s
pprof-port:6060
enable-health-check-nodeport:true
bpf-ct-timeout-service-any:1m0s
bpf-node-map-max:16384
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
local-router-ipv4:
mesh-auth-mutual-listener-port:0
bpf-lb-maglev-table-size:16381
ipv6-range:auto
force-device-detection:false
hubble-redact-http-headers-allow:
lib-dir:/var/lib/cilium
hubble-redact-kafka-apikey:false
identity-allocation-mode:crd
k8s-namespace:kube-system
ipv6-service-range:auto
bpf-lb-sock:false
ipv6-pod-subnets:
enable-ipv4-egress-gateway:false
enable-ipsec:false
proxy-gid:1337
gops-port:9890
custom-cni-conf:false
hubble-redact-http-userinfo:true
disable-endpoint-crd:false
log-driver:
enable-sctp:false
datapath-mode:veth
enable-envoy-config:false
auto-create-cilium-node-resource:true
enable-srv6:false
bpf-root:/sys/fs/bpf
enable-host-port:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-ipsec-xfrm-state-caching:true
restore:true
ipam-default-ip-pool:default
ipv4-pod-subnets:
cluster-pool-ipv4-cidr:10.31.0.0/16
encryption-strict-mode-allow-remote-node-identities:false
enable-bpf-clock-probe:false
encrypt-node:false
max-controller-interval:0
bpf-ct-timeout-regular-any:1m0s
disable-external-ip-mitigation:false
auto-direct-node-routes:false
ipv6-native-routing-cidr:
enable-k8s-terminating-endpoint:true
hubble-event-queue-size:0
enable-session-affinity:false
http-max-grpc-timeout:0
dns-max-ips-per-restored-rule:1000
dnsproxy-lock-timeout:500ms
arping-refresh-period:30s
bpf-filter-priority:1
k8s-heartbeat-timeout:30s
bpf-neigh-global-max:524288
preallocate-bpf-maps:false
enable-ipv4-big-tcp:false
vtep-mask:
bpf-ct-timeout-service-tcp-grace:1m0s
policy-audit-mode:false
monitor-aggregation-flags:all
hubble-metrics:
hubble-recorder-sink-queue-size:1024
enable-node-selector-labels:false
hubble-drop-events:false
envoy-keep-cap-netbindservice:false
local-max-addr-scope:252
l2-announcements-retry-period:2s
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
521        Disabled           Disabled          1067747    k8s:eks.amazonaws.com/component=coredns                                             10.31.0.73    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
900        Disabled           Disabled          1050811    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.31.0.38    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1129       Disabled           Disabled          1067747    k8s:eks.amazonaws.com/component=coredns                                             10.31.0.111   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh32                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
3178       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3877       Disabled           Disabled          4          reserved:health                                                                     10.31.0.64    ready   
```

#### BPF Policy Get 521

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174290   1993      0        
Allow    Egress      0          ANY          NONE         disabled    21284    239       0        

```


#### BPF CT List 521

```
Invalid argument: unknown type 521
```


#### Endpoint Get 521

```
[
  {
    "id": 521,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-521-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3281212e-51b8-4a31-bc82-d9c417efd5ea"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-521",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:23.762Z",
            "success-count": 7
          },
          "uuid": "f5214248-e589-488e-a055-6a582b447e49"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-4rr5s",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:52:23.760Z",
            "success-count": 1
          },
          "uuid": "49ba2602-e21a-450a-8875-34632b25e10e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-521",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:25.799Z",
            "success-count": 3
          },
          "uuid": "b4c4dd35-3894-49e8-a3b7-9eccd12a6ab8"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (521)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:23.917Z",
            "success-count": 188
          },
          "uuid": "35a71c8a-37bf-4340-8cfd-606c03f438ce"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "21bcc06fba65011f3a732edca76219aaf0204086590aa2c9f1e51792c53a39e8:eth0",
        "container-id": "21bcc06fba65011f3a732edca76219aaf0204086590aa2c9f1e51792c53a39e8",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-4rr5s",
        "pod-name": "kube-system/coredns-cc6ccd49c-4rr5s"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1067747,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.73",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "7e:c0:09:56:34:27",
        "interface-index": 14,
        "interface-name": "lxc3a81eb130d6b",
        "mac": "2a:9c:ba:84:6c:cd"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1067747,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1067747,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 521

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 521

```
Timestamp              Status   State                   Message
2024-10-30T08:10:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:59Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:23Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:23Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1067747

```
ID        LABELS
1067747   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 900

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11555302   115610    0        
Allow    Ingress     1          ANY          NONE         disabled    10577335   111366    0        
Allow    Egress      0          ANY          NONE         disabled    13325071   130637    0        

```


#### BPF CT List 900

```
Invalid argument: unknown type 900
```


#### Endpoint Get 900

```
[
  {
    "id": 900,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-900-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "4965d4a8-d782-4e84-9879-a46d0fbbf285"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-900",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:20:41.489Z",
            "success-count": 3
          },
          "uuid": "2bb952e5-2635-4a7c-b1f1-3e9003f1fb88"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-dfb7b889d-mh9zz",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:10:41.487Z",
            "success-count": 1
          },
          "uuid": "1ac77cf0-4c0f-4248-a885-46ba06c21ebf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-900",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:10:41.525Z",
            "success-count": 1
          },
          "uuid": "b09b828b-769f-47ce-a2dc-c96698508d6d"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (900)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:21.574Z",
            "success-count": 78
          },
          "uuid": "dc3f5571-e5e5-441e-8772-643065a1e648"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "126e23955991f5c6686f5893569214a361052b35a10380bb0f85e3c547f56793:eth0",
        "container-id": "126e23955991f5c6686f5893569214a361052b35a10380bb0f85e3c547f56793",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-dfb7b889d-mh9zz",
        "pod-name": "kube-system/clustermesh-apiserver-dfb7b889d-mh9zz"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1050811,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=dfb7b889d"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.38",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "76:c7:27:3a:5b:45",
        "interface-index": 18,
        "interface-name": "lxc5fe46757f280",
        "mac": "02:2c:c9:c2:e2:dc"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1050811,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1050811,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 900

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 900

```
Timestamp              Status   State                   Message
2024-10-30T08:10:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:59Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:10:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:10:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:10:41Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:10:41Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1050811

```
ID        LABELS
1050811   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1129

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176373   2019      0        
Allow    Egress      0          ANY          NONE         disabled    23171    261       0        

```


#### BPF CT List 1129

```
Invalid argument: unknown type 1129
```


#### Endpoint Get 1129

```
[
  {
    "id": 1129,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1129-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bdb7d2e6-ff67-4592-befb-5c74db47bd90"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1129",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:23.763Z",
            "success-count": 7
          },
          "uuid": "1b343bf7-1bfa-4914-84f3-cf4e5814e476"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-dbw26",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:52:23.759Z",
            "success-count": 1
          },
          "uuid": "8e082de6-775f-4d33-be76-f215a6f65d7a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1129",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:25.755Z",
            "success-count": 3
          },
          "uuid": "118871a3-aa54-447b-89e7-9b65306f3d72"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1129)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:23.917Z",
            "success-count": 188
          },
          "uuid": "fcc65055-c18c-4da8-b04e-fd5c16330afe"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fd2d959756fce73d48e70646f327a1e4bede0ce08771f9d81d880cbe822f79cd:eth0",
        "container-id": "fd2d959756fce73d48e70646f327a1e4bede0ce08771f9d81d880cbe822f79cd",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-dbw26",
        "pod-name": "kube-system/coredns-cc6ccd49c-dbw26"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1067747,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh32",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:59Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.111",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "3e:a7:88:cf:78:40",
        "interface-index": 12,
        "interface-name": "lxcaa4bbff8a17d",
        "mac": "fa:62:91:b3:02:d9"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1067747,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1067747,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1129

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1129

```
Timestamp              Status    State                   Message
2024-10-30T08:10:59Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:59Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:59Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:10:59Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:58Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:58Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:58Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:58Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:57Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:57Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:57Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:57Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:56Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:56Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:56Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:56Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:32Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:32Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:32Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:32Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:31Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:31Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:31Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:31Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:25Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:25Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:25Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:25Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:24Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:23Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:23Z   OK        ready                   Set identity for this endpoint
2024-10-30T07:52:23Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 1067747

```
ID        LABELS
1067747   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh32
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 3178

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 3178

```
Invalid argument: unknown type 3178
```


#### Endpoint Get 3178

```
[
  {
    "id": 3178,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3178-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "2b409524-a12e-49ad-9d0c-3fa025dc3036"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3178",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:21.241Z",
            "success-count": 7
          },
          "uuid": "c04a923b-75f2-45b7-981b-9378160599b5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3178",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:22.343Z",
            "success-count": 3
          },
          "uuid": "2d49762b-06d3-430f-8480-5a29b60cbe3d"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "a2:cd:30:fb:49:ed",
        "interface-name": "cilium_host",
        "mac": "a2:cd:30:fb:49:ed"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3178

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3178

```
Timestamp              Status   State                   Message
2024-10-30T08:10:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:59Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:52:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:25Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:52:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:52:24Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:52:22Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:22Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:21Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:21Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:21Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3877

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658894   21010     0        
Allow    Ingress     1          ANY          NONE         disabled    27294     320       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 3877

```
Invalid argument: unknown type 3877
```


#### Endpoint Get 3877

```
[
  {
    "id": 3877,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3877-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "7bb474ea-7abf-4d9b-af00-5c301b0ad5a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3877",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:22.291Z",
            "success-count": 7
          },
          "uuid": "7cdf36f2-2edd-4fb1-8335-0524c4e6730f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3877",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:25.735Z",
            "success-count": 3
          },
          "uuid": "4dd66da7-d918-4910-a036-127ebe40cc14"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:59Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.31.0.64",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "36:c5:78:d7:c6:7e",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "3a:e1:4a:de:53:c7"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3877

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3877

```
Timestamp              Status   State                   Message
2024-10-30T08:10:59Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:59Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:59Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:58Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:58Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:58Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:58Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:57Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:56Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:56Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:56Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:56Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:32Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:32Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:32Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:32Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:31Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:31Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:31Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:31Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:52:25Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T07:52:25Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:52:25Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T07:52:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:52:24Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:52:23Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T07:52:22Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:52:22Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:52:22Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:52:21Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.165.16:443 (active)     
                                          2 => 172.31.253.60:443 (active)     
2    10.100.57.55:443      ClusterIP      1 => 172.31.222.197:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.31.0.73:53 (active)         
                                          2 => 10.31.0.111:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.31.0.73:9153 (active)       
                                          2 => 10.31.0.111:9153 (active)      
5    10.100.178.142:2379   ClusterIP      1 => 10.31.0.38:2379 (active)       
```

#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.31.0.0/24, 
Allocated addresses:
  10.31.0.111 (kube-system/coredns-cc6ccd49c-dbw26)
  10.31.0.31 (router)
  10.31.0.38 (kube-system/clustermesh-apiserver-dfb7b889d-mh9zz)
  10.31.0.64 (health)
  10.31.0.73 (kube-system/coredns-cc6ccd49c-4rr5s)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: fe557c1bc8e529dd
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   6s ago         never        0       no error   
  ct-map-pressure                                                    8s ago         never        0       no error   
  daemon-validate-config                                             38s ago        never        0       no error   
  dns-garbage-collector-job                                          10s ago        never        0       no error   
  endpoint-1129-regeneration-recovery                                never          never        0       no error   
  endpoint-3178-regeneration-recovery                                never          never        0       no error   
  endpoint-3877-regeneration-recovery                                never          never        0       no error   
  endpoint-521-regeneration-recovery                                 never          never        0       no error   
  endpoint-900-regeneration-recovery                                 never          never        0       no error   
  endpoint-gc                                                        1m10s ago      never        0       no error   
  ep-bpf-prog-watchdog                                               8s ago         never        0       no error   
  ipcache-inject-labels                                              8s ago         never        0       no error   
  k8s-heartbeat                                                      11s ago        never        0       no error   
  link-cache                                                         8s ago         never        0       no error   
  local-identity-checkpoint                                          31m8s ago      never        0       no error   
  node-neighbor-link-updater                                         8s ago         never        0       no error   
  remote-etcd-cmesh1                                                 12m33s ago     never        0       no error   
  remote-etcd-cmesh10                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh100                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh101                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh102                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh103                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh104                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh105                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh106                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh107                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh108                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh109                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh11                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh110                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh111                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh112                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh113                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh114                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh115                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh116                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh117                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh118                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh119                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh12                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh120                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh121                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh122                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh123                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh124                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh125                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh126                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh127                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh128                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh129                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh13                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh130                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh131                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh132                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh133                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh134                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh135                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh136                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh137                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh138                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh139                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh14                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh140                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh141                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh142                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh143                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh144                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh145                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh146                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh147                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh148                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh149                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh15                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh150                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh151                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh152                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh153                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh154                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh155                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh156                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh157                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh158                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh159                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh16                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh160                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh161                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh162                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh163                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh164                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh165                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh166                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh167                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh168                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh169                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh17                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh170                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh171                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh172                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh173                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh174                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh175                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh176                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh177                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh178                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh179                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh18                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh180                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh181                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh182                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh183                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh184                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh185                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh186                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh187                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh188                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh189                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh19                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh190                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh191                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh192                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh193                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh194                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh195                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh196                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh197                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh198                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh199                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh2                                                 12m32s ago     never        0       no error   
  remote-etcd-cmesh20                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh200                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh201                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh202                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh203                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh204                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh205                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh206                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh207                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh208                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh209                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh21                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh210                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh211                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh212                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh213                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh214                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh215                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh216                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh217                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh218                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh219                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh22                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh220                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh221                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh222                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh223                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh224                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh225                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh226                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh227                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh228                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh229                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh23                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh230                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh231                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh232                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh233                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh234                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh235                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh236                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh237                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh238                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh239                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh24                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh240                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh241                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh242                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh243                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh244                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh245                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh246                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh247                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh248                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh249                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh25                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh250                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh251                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh252                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh253                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh254                                               12m33s ago     never        0       no error   
  remote-etcd-cmesh255                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh256                                               12m32s ago     never        0       no error   
  remote-etcd-cmesh26                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh27                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh28                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh29                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh3                                                 12m33s ago     never        0       no error   
  remote-etcd-cmesh30                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh31                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh33                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh34                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh35                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh36                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh37                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh38                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh39                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh4                                                 12m32s ago     never        0       no error   
  remote-etcd-cmesh40                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh41                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh42                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh43                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh44                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh45                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh46                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh47                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh48                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh49                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh5                                                 12m32s ago     never        0       no error   
  remote-etcd-cmesh50                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh51                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh52                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh53                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh54                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh55                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh56                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh57                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh58                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh59                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh6                                                 12m33s ago     never        0       no error   
  remote-etcd-cmesh60                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh61                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh62                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh63                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh64                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh65                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh66                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh67                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh68                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh69                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh7                                                 12m32s ago     never        0       no error   
  remote-etcd-cmesh70                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh71                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh72                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh73                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh74                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh75                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh76                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh77                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh78                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh79                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh8                                                 12m33s ago     never        0       no error   
  remote-etcd-cmesh80                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh81                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh82                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh83                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh84                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh85                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh86                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh87                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh88                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh89                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh9                                                 12m32s ago     never        0       no error   
  remote-etcd-cmesh90                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh91                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh92                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh93                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh94                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh95                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh96                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh97                                                12m33s ago     never        0       no error   
  remote-etcd-cmesh98                                                12m32s ago     never        0       no error   
  remote-etcd-cmesh99                                                12m32s ago     never        0       no error   
  resolve-identity-1129                                              1m5s ago       never        0       no error   
  resolve-identity-3178                                              1m8s ago       never        0       no error   
  resolve-identity-3877                                              1m7s ago       never        0       no error   
  resolve-identity-521                                               1m5s ago       never        0       no error   
  resolve-identity-900                                               2m48s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-dfb7b889d-mh9zz   12m48s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-4rr5s                 31m5s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-dbw26                 31m5s ago      never        0       no error   
  sync-lb-maps-with-k8s-services                                     31m8s ago      never        0       no error   
  sync-policymap-1129                                                1m3s ago       never        0       no error   
  sync-policymap-3178                                                1m7s ago       never        0       no error   
  sync-policymap-3877                                                1m3s ago       never        0       no error   
  sync-policymap-521                                                 1m3s ago       never        0       no error   
  sync-policymap-900                                                 12m48s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1129)                                  5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (521)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (900)                                   8s ago         never        0       no error   
  sync-utime                                                         8s ago         never        0       no error   
  write-cni-file                                                     31m11s ago     never        0       no error   
Proxy Status:            OK, ip 10.31.0.31, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1048576, max 1081343
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 115.23   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```
