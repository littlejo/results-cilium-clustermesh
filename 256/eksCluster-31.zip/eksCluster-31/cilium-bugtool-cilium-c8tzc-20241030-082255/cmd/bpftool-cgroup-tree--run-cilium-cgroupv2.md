CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95b34784_88b2_41b0_bfdc_163a319c333e.slice/cri-containerd-18829b3689d88743f88a88e973cb951f8e59586a3121ed6999a2b144250bf1e6.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod95b34784_88b2_41b0_bfdc_163a319c333e.slice/cri-containerd-ad0152a3f23574fe8adee8b6e8b80dc4a7f9dab056fcf09baebbac4d2344f658.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c3b84a7_52ad_4794_8667_547086d5fa9e.slice/cri-containerd-fd2d959756fce73d48e70646f327a1e4bede0ce08771f9d81d880cbe822f79cd.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c3b84a7_52ad_4794_8667_547086d5fa9e.slice/cri-containerd-ce5814c0ce1c4194f7da1346c29c354739ca4e45cec75e17c7f8d795ef550247.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1bac644_384d_41ce_aa89_d38532247b15.slice/cri-containerd-da9dad86ce54b3ae896623bf2d49d89324f599744c9d42429568a7f63d28d7c9.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode1bac644_384d_41ce_aa89_d38532247b15.slice/cri-containerd-2e5d414999ccbc0f868997fb38cdea45ff1c0cd4072122359637adaa038b4ac6.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660738f1_e9b7_4c22_bacc_d1d8807aedfe.slice/cri-containerd-21bcc06fba65011f3a732edca76219aaf0204086590aa2c9f1e51792c53a39e8.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660738f1_e9b7_4c22_bacc_d1d8807aedfe.slice/cri-containerd-018fb5a1c43e76bcb421af27e4448ba589aa3e0b3e22ea5a19599b6e10bb770c.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-70ecce0e51caaeb5976f4986fbadb0345f35fd56cf75bdad8da2ff393fdcc6fd.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-ac6e784930a6c5a03e724af281412c11bc14a6763965c4966f5e505786a609c5.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-520e18aec8a1bd357b987eadb2e40a28a33f96c31d1a89b1d9cc45c48ead3e92.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-126e23955991f5c6686f5893569214a361052b35a10380bb0f85e3c547f56793.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod13bd86ab_cec6_435d_9c03_6522e921ec08.slice/cri-containerd-9a67ba9bb8e6334e2c7575b70ff9515b8f275f0124184649b0dd4afde7687f65.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod13bd86ab_cec6_435d_9c03_6522e921ec08.slice/cri-containerd-a4f11bb2b3b31f4525b74e6f8655e626ac48cfb0c0b484d683271aae07f61a40.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb3b6bbb_d4b7_4178_ac38_62a18ad33f0e.slice/cri-containerd-4facdd6c24d2be860363365c15e4d97662c264a1e30df440534e6aeb782f49ca.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podeb3b6bbb_d4b7_4178_ac38_62a18ad33f0e.slice/cri-containerd-d37e8c9c1d3448ee64c86df557901b4eab226afe383bc706732026ac11595cdd.scope
    109      cgroup_device   multi                                          
