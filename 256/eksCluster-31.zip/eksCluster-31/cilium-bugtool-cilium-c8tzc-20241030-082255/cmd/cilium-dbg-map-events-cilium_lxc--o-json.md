{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:21.088Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.215.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:21.088Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.222.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:21.088Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.733Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.745Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.794Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.797Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.801Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.346Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.347Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.347Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:31.378Z",
  "value": "id=2094  sec_id=1050811 flags=0x0000 ifindex=16  mac=32:30:69:0A:A2:1F nodemac=82:69:4C:6B:16:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.346Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.347Z",
  "value": "id=2094  sec_id=1050811 flags=0x0000 ifindex=16  mac=32:30:69:0A:A2:1F nodemac=82:69:4C:6B:16:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.347Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.347Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:41.524Z",
  "value": "id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.31.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.105Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.186Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.186Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.186Z",
  "value": "id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.187Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.184Z",
  "value": "id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.184Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.184Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.185Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.184Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.184Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.185Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.185Z",
  "value": "id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.184Z",
  "value": "id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.185Z",
  "value": "id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.185Z",
  "value": "id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.31.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.185Z",
  "value": "id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27"
}

