key: 09 02 00 00  value: 1a 02 00 00
key: 84 03 00 00  value: 6b 02 00 00
key: 69 04 00 00  value: 14 02 00 00
key: 25 0f 00 00  value: 1d 02 00 00
Found 4 elements
