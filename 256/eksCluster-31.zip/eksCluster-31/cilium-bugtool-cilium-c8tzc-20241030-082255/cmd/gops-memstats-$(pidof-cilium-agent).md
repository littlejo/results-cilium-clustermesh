alloc: 147.81MB (154986040 bytes)
total-alloc: 2.37GB (2544311912 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65220108
frees: 64059796
heap-alloc: 147.81MB (154986040 bytes)
heap-sys: 247.33MB (259342336 bytes)
heap-idle: 51.45MB (53952512 bytes)
heap-in-use: 195.88MB (205389824 bytes)
heap-released: 552.00KB (565248 bytes)
heap-objects: 1160312
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 3.07MB (3220640 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 904.70KB (926417 bytes)
gc-sys: 6.04MB (6336096 bytes)
next-gc: when heap-alloc >= 213.74MB (224124152 bytes)
last-gc: 2024-10-30 08:23:14.556979556 +0000 UTC
gc-pause-total: 28.218419ms
gc-pause: 76109
gc-pause-end: 1730276594556979556
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00040793692054099637
enable-gc: true
debug-gc: false
