markdown output at /tmp/cilium-bugtool-20241030-082257.169+0000-UTC-2792742945/cmd/cilium-debuginfo-20241030-082327.963+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.169+0000-UTC-2792742945/cmd/cilium-debuginfo-20241030-082327.963+0000-UTC.json
