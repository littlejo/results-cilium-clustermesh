IP ADDRESS         LOCAL ENDPOINT INFO
10.31.0.31:0       (localhost)                                                                                        
10.31.0.73:0       id=521   sec_id=1067747 flags=0x0000 ifindex=14  mac=2A:9C:BA:84:6C:CD nodemac=7E:C0:09:56:34:27   
10.31.0.64:0       id=3877  sec_id=4     flags=0x0000 ifindex=10  mac=3A:E1:4A:DE:53:C7 nodemac=36:C5:78:D7:C6:7E     
172.31.222.197:0   (localhost)                                                                                        
10.31.0.38:0       id=900   sec_id=1050811 flags=0x0000 ifindex=18  mac=02:2C:C9:C2:E2:DC nodemac=76:C7:27:3A:5B:45   
172.31.215.159:0   (localhost)                                                                                        
10.31.0.111:0      id=1129  sec_id=1067747 flags=0x0000 ifindex=12  mac=FA:62:91:B3:02:D9 nodemac=3E:A7:88:CF:78:40   
