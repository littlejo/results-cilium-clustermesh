ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.165.16:443 (active)     
                                          2 => 172.31.253.60:443 (active)     
2    10.100.57.55:443      ClusterIP      1 => 172.31.222.197:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.31.0.73:53 (active)         
                                          2 => 10.31.0.111:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.31.0.73:9153 (active)       
                                          2 => 10.31.0.111:9153 (active)      
5    10.100.178.142:2379   ClusterIP      1 => 10.31.0.38:2379 (active)       
