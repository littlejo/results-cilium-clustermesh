1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5e:36:2e:d3:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.222.197/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3084sec preferred_lft 3084sec
    inet6 fe80::85e:36ff:fe2e:d3b7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1e:f9:d0:55:3f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.215.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81e:f9ff:fed0:553f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:cb:02:63:ef:dd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0cb:2ff:fe63:efdd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:cd:30:fb:49:ed brd ff:ff:ff:ff:ff:ff
    inet 10.31.0.31/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a0cd:30ff:fefb:49ed/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8a:a3:64:9c:40:ee brd ff:ff:ff:ff:ff:ff
    inet6 fe80::88a3:64ff:fe9c:40ee/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:c5:78:d7:c6:7e brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::34c5:78ff:fed7:c67e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcaa4bbff8a17d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:a7:88:cf:78:40 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3ca7:88ff:fecf:7840/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3a81eb130d6b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:c0:09:56:34:27 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7cc0:9ff:fe56:3427/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5fe46757f280@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:c7:27:3a:5b:45 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::74c7:27ff:fe3a:5b45/64 scope link 
       valid_lft forever preferred_lft forever
