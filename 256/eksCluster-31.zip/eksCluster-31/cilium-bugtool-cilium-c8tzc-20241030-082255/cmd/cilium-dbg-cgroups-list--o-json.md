[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c3b84a7_52ad_4794_8667_547086d5fa9e.slice/cri-containerd-ce5814c0ce1c4194f7da1346c29c354739ca4e45cec75e17c7f8d795ef550247.scope"
      }
    ],
    "ips": [
      "10.31.0.111"
    ],
    "name": "coredns-cc6ccd49c-dbw26",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-ac6e784930a6c5a03e724af281412c11bc14a6763965c4966f5e505786a609c5.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-520e18aec8a1bd357b987eadb2e40a28a33f96c31d1a89b1d9cc45c48ead3e92.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podef57e012_7cbf_420b_bd3d_38d9e766d065.slice/cri-containerd-70ecce0e51caaeb5976f4986fbadb0345f35fd56cf75bdad8da2ff393fdcc6fd.scope"
      }
    ],
    "ips": [
      "10.31.0.38"
    ],
    "name": "clustermesh-apiserver-dfb7b889d-mh9zz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660738f1_e9b7_4c22_bacc_d1d8807aedfe.slice/cri-containerd-018fb5a1c43e76bcb421af27e4448ba589aa3e0b3e22ea5a19599b6e10bb770c.scope"
      }
    ],
    "ips": [
      "10.31.0.73"
    ],
    "name": "coredns-cc6ccd49c-4rr5s",
    "namespace": "kube-system"
  }
]

