KEY             VALUE
AgentLiveness   2358659812816
UTimeOffset     3379441892578125
