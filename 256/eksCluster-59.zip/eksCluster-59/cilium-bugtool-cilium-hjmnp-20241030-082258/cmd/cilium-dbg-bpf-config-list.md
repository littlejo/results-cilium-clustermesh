KEY             VALUE
AgentLiveness   2209299058534
UTimeOffset     3379442189453125
