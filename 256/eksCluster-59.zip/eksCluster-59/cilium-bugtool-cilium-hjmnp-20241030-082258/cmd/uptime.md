 08:22:59 up 36 min,  0 users,  load average: 0.31, 0.34, 0.27
