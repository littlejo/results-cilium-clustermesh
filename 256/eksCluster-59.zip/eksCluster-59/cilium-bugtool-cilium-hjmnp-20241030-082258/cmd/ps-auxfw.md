USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         744  0.0  0.1 1616008 8332 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         722  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         732  0.0  0.2 1244084 20548 ?       Rl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         715  0.0  0.1 1240432 15656 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         746  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         753  0.0  0.1 1240432 15656 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         686  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         685  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.6  5.1 1671812 413696 ?      Ssl  07:53   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         413  0.0  0.0 1229744 7736 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
