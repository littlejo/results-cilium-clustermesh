Endpoint ID: 487
Path: /sys/fs/bpf/tc/globals/cilium_policy_00487

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 832
Path: /sys/fs/bpf/tc/globals/cilium_policy_00832

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660202   21016     0        
Allow    Ingress     1          ANY          NONE         disabled    26339     310       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2692
Path: /sys/fs/bpf/tc/globals/cilium_policy_02692

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174604   2010      0        
Allow    Egress      0          ANY          NONE         disabled    22512    253       0        


Endpoint ID: 3849
Path: /sys/fs/bpf/tc/globals/cilium_policy_03849

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11554096   116687    0        
Allow    Ingress     1          ANY          NONE         disabled    12332357   127318    0        
Allow    Egress      0          ANY          NONE         disabled    15318884   149682    0        


Endpoint ID: 4038
Path: /sys/fs/bpf/tc/globals/cilium_policy_04038

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174049   2007      0        
Allow    Egress      0          ANY          NONE         disabled    21426    240       0        


