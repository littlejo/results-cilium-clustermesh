REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38124     3017811     677    bpf_overlay.c
Interface                 INGRESS     702242    140116444   1132   bpf_host.c
Success                   EGRESS      17779     1403052     1694   bpf_host.c
Success                   EGRESS      313043    38595343    1308   bpf_lxc.c
Success                   EGRESS      39260     3101318     53     encap.h
Success                   INGRESS     357378    40789835    86     l3.h
Success                   INGRESS     378374    42448640    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
