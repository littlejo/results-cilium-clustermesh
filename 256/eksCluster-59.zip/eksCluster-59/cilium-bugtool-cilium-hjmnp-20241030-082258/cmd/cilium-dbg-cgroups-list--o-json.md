[
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ea297e8_db38_44df_acf1_7ada76e68fc4.slice/cri-containerd-a51f78f9c14b3032c9194a78650b1f08a77ed6fc3f6d7b344f9d7400ada5ffcc.scope"
      }
    ],
    "ips": [
      "10.59.0.78"
    ],
    "name": "coredns-cc6ccd49c-69qtx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0766f2d_6604_4826_9020_31d4ef3bbd19.slice/cri-containerd-4408d7b18ceef83988c148935203fd65ffdb723c869483c49eaf5d9312a47ce0.scope"
      }
    ],
    "ips": [
      "10.59.0.202"
    ],
    "name": "coredns-cc6ccd49c-9rd56",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-03fb142a256c2ee002ce9e1341e46260ce5cbd2ea9d1fa8650fbfc989380c53d.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-174e9022b3337b399471df25147f677c89004c259a70c4e0baf1383c8575437d.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-8f96918bb27b5ed2b924f6bfaf4578353f9ff48961af477205448d62f0121972.scope"
      }
    ],
    "ips": [
      "10.59.0.91"
    ],
    "name": "clustermesh-apiserver-59985cfbf-xz5g2",
    "namespace": "kube-system"
  }
]

