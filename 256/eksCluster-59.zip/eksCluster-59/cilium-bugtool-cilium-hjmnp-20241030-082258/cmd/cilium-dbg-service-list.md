ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.232.31:443 (active)     
                                          2 => 172.31.137.237:443 (active)    
2    10.100.118.145:443    ClusterIP      1 => 172.31.237.111:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.59.0.78:53 (active)         
                                          2 => 10.59.0.202:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.59.0.78:9153 (active)       
                                          2 => 10.59.0.202:9153 (active)      
5    10.100.145.199:2379   ClusterIP      1 => 10.59.0.91:2379 (active)       
