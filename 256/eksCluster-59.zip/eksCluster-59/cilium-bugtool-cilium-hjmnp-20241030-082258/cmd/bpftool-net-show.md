xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 589
ens6(5) clsact/ingress cil_from_netdev-ens6 id 596
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 583
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 574
cilium_host(7) clsact/egress cil_from_host-cilium_host id 572
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 506
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 503
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxc600d43b92b75(12) clsact/ingress cil_from_container-lxc600d43b92b75 id 538
lxc73551ff07af5(14) clsact/ingress cil_from_container-lxc73551ff07af5 id 553
lxce8f87f2eb18b(18) clsact/ingress cil_from_container-lxce8f87f2eb18b id 646

flow_dissector:

netfilter:

