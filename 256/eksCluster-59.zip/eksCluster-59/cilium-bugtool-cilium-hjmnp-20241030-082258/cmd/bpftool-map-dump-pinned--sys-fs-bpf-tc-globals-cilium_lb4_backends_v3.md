key: 03 00 00 00  value: ac 1f ed 6f 10 94 00 00  00 00 00 00
key: 04 00 00 00  value: 0a 3b 00 4e 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 3b 00 ca 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f 89 ed 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 3b 00 5b 09 4b 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f e8 1f 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: 0a 3b 00 4e 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 3b 00 ca 00 35 00 00  00 00 00 00
Found 8 elements
