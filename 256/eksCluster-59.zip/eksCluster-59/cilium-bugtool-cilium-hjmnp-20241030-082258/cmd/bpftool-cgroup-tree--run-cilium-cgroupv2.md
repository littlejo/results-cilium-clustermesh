CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0766f2d_6604_4826_9020_31d4ef3bbd19.slice/cri-containerd-4408d7b18ceef83988c148935203fd65ffdb723c869483c49eaf5d9312a47ce0.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0766f2d_6604_4826_9020_31d4ef3bbd19.slice/cri-containerd-b4e1d4b7adbbfb71acad851f781fafa7d3621990efc52850ea1499dbe668a607.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce668ac0_b0bf_4cfb_a433_d1f00c8c9276.slice/cri-containerd-c3a7e71c049fe92b5e3e6fb1973b110a023a9dca1ec393d692f45705a3216a5a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce668ac0_b0bf_4cfb_a433_d1f00c8c9276.slice/cri-containerd-b8d336cd4135655b8f8fde44b554214f3c39edf4d7dba6ad1b0ebefcdd9bdf3d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ea297e8_db38_44df_acf1_7ada76e68fc4.slice/cri-containerd-a51f78f9c14b3032c9194a78650b1f08a77ed6fc3f6d7b344f9d7400ada5ffcc.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ea297e8_db38_44df_acf1_7ada76e68fc4.slice/cri-containerd-c8db22cde0270f6280ca4b2b7798b8fe3e9edec64287f91d5c99ab42ca90ea9e.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6831f62d_acd2_43db_8d2f_96e1e6bfb3a0.slice/cri-containerd-a9f00396c3ff2e4eecec448d9354abcbaca544b2898c80d080666fc732872db9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6831f62d_acd2_43db_8d2f_96e1e6bfb3a0.slice/cri-containerd-c65206af80b2ee79479f3e1cbffaccd75dd2fbc158196ff755c7d5ed57c87914.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-d0c50241a5bec8f0ea76da8139221042f576a0bebf435747596c6f37e0ea8b39.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-174e9022b3337b399471df25147f677c89004c259a70c4e0baf1383c8575437d.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-8f96918bb27b5ed2b924f6bfaf4578353f9ff48961af477205448d62f0121972.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod29341810_4756_49eb_b3c0_d9256b45ea91.slice/cri-containerd-03fb142a256c2ee002ce9e1341e46260ce5cbd2ea9d1fa8650fbfc989380c53d.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf84e156_abc2_4c13_9185_b63c4f13bbc3.slice/cri-containerd-cb1cb1797e24333228f2ba173d854e9e31782d31ffad759f8747edd2678a3c6f.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf84e156_abc2_4c13_9185_b63c4f13bbc3.slice/cri-containerd-0b916cb2f07b3f2d36152e18208c0d261335b51f98c61e4901c266e9648ae602.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21f79b41_5cc3_4738_a49c_6b403afdfcdf.slice/cri-containerd-c2541a020c6b5fb50e61ae74c6e4d2450f90e1fb3a961d2cd7679e1007627c3a.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21f79b41_5cc3_4738_a49c_6b403afdfcdf.slice/cri-containerd-26c8735330050134962867a0d28c997f956fb65dd7db21a283332b39f23147ff.scope
    97       cgroup_device   multi                                          
