key: 40 03 00 00  value: 23 02 00 00
key: 84 0a 00 00  value: 2d 02 00 00
key: 09 0f 00 00  value: 83 02 00 00
key: c6 0f 00 00  value: 16 02 00 00
Found 4 elements
