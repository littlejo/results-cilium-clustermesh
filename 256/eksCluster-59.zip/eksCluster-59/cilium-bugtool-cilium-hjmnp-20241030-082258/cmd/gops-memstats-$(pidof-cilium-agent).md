alloc: 170.12MB (178383920 bytes)
total-alloc: 2.58GB (2771738664 bytes)
sys: 336.96MB (353328500 bytes)
lookups: 0
mallocs: 68277281
frees: 66335099
heap-alloc: 170.12MB (178383920 bytes)
heap-sys: 255.51MB (267919360 bytes)
heap-idle: 55.04MB (57712640 bytes)
heap-in-use: 200.47MB (210206720 bytes)
heap-released: 2.72MB (2850816 bytes)
heap-objects: 1942182
stack-in-use: 68.47MB (71794688 bytes)
stack-sys: 68.47MB (71794688 bytes)
stack-mspan-inuse: 3.45MB (3617120 bytes)
stack-mspan-sys: 3.98MB (4177920 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1093937 bytes)
gc-sys: 5.93MB (6216088 bytes)
next-gc: when heap-alloc >= 214.53MB (224952104 bytes)
last-gc: 2024-10-30 08:23:03.516504534 +0000 UTC
gc-pause-total: 18.561798ms
gc-pause: 107415
gc-pause-end: 1730276583516504534
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.00040465796300808246
enable-gc: true
debug-gc: false
