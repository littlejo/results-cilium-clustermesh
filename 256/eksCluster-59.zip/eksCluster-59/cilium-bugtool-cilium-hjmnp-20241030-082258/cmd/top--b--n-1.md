top - 08:23:00 up 36 min,  0 users,  load average: 0.31, 0.34, 0.27
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.0 us, 40.0 sy,  0.0 ni, 10.0 id,  0.0 wa,  0.0 hi, 10.0 si,  0.0 st
MiB Mem :   7814.2 total,   4436.0 free,   1230.2 used,   2148.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6399.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    732 root      20   0 1244596  21776  14016 S  46.7   0.3   0:00.18 hubble
      1 root      20   0 1671812 413696  78460 S   6.7   5.2   1:05.44 cilium-+
    413 root      20   0 1229744   7736   3836 S   0.0   0.1   0:01.18 cilium-+
    685 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    686 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    715 root      20   0 1240432  15656  10896 S   0.0   0.2   0:00.02 cilium-+
    722 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    764 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    777 root      20   0       0      0      0 R   0.0   0.0   0:00.00 bpftool
    781 root      20   0 1240432  15656  10896 R   0.0   0.2   0:00.00 cilium-+
