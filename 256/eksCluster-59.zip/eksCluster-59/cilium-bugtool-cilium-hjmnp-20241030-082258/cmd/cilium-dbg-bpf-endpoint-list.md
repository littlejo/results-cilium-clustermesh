IP ADDRESS         LOCAL ENDPOINT INFO
10.59.0.91:0       id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5   
10.59.0.78:0       id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1   
10.59.0.202:0      id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F   
172.31.237.111:0   (localhost)                                                                                        
10.59.0.66:0       id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF     
172.31.202.15:0    (localhost)                                                                                        
10.59.0.117:0      (localhost)                                                                                        
