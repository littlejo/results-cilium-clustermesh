{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:19.739Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.202.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:19.739Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.237.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:19.739Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:22.985Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:26.126Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:26.163Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:26.199Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:26.286Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:26.347Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:58.789Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:58.790Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:58.792Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:58.823Z",
  "value": "id=2640  sec_id=1995873 flags=0x0000 ifindex=16  mac=DE:02:2E:7E:AB:E1 nodemac=AA:5B:DF:EE:83:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:59.789Z",
  "value": "id=2640  sec_id=1995873 flags=0x0000 ifindex=16  mac=DE:02:2E:7E:AB:E1 nodemac=AA:5B:DF:EE:83:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:59.789Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:59.790Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:59.790Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.230Z",
  "value": "id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.59.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.834Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:41.364Z",
  "value": "id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:41.366Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:41.366Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:41.366Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.364Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.365Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.366Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:42.368Z",
  "value": "id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.365Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.365Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.365Z",
  "value": "id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:43.366Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.365Z",
  "value": "id=832   sec_id=4     flags=0x0000 ifindex=10  mac=76:50:5A:EE:A1:11 nodemac=72:7D:AF:44:7A:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.365Z",
  "value": "id=4038  sec_id=1984758 flags=0x0000 ifindex=12  mac=A2:69:22:8E:66:60 nodemac=F6:A2:9B:EB:7E:C1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.366Z",
  "value": "id=3849  sec_id=1995873 flags=0x0000 ifindex=18  mac=36:77:3D:17:D9:98 nodemac=4A:19:41:69:09:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.59.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:44.366Z",
  "value": "id=2692  sec_id=1984758 flags=0x0000 ifindex=14  mac=86:FA:AD:10:F2:FE nodemac=A6:DE:AB:EB:39:5F"
}

