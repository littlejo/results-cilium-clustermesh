alloc: 186.06MB (195101832 bytes)
total-alloc: 2.36GB (2529160096 bytes)
sys: 324.64MB (340414820 bytes)
lookups: 0
mallocs: 65374836
frees: 63195479
heap-alloc: 186.06MB (195101832 bytes)
heap-sys: 247.23MB (259235840 bytes)
heap-idle: 37.75MB (39583744 bytes)
heap-in-use: 209.48MB (219652096 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 2179357
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.58MB (3753920 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1004.68KB (1028793 bytes)
gc-sys: 5.89MB (6172208 bytes)
next-gc: when heap-alloc >= 214.37MB (224779592 bytes)
last-gc: 2024-10-30 08:22:56.360760333 +0000 UTC
gc-pause-total: 16.221817ms
gc-pause: 221303
gc-pause-end: 1730276576360760333
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.000549100429317035
enable-gc: true
debug-gc: false
