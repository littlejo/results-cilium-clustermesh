USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         653  0.0  0.2 1240432 16656 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         670  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         672  0.0  0.0   3852  1296 ?        R    08:22   0:00  \_ bash -c hostname
root           1  4.6  4.7 1605952 378580 ?      Ssl  08:04   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.1  0.1 1229744 8100 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
