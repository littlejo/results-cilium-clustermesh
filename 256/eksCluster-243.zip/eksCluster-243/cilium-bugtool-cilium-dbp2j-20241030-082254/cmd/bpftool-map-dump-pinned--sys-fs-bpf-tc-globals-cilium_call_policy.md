key: a8 00 00 00  value: 61 02 00 00
key: cc 02 00 00  value: 17 02 00 00
key: 0b 0c 00 00  value: 25 02 00 00
key: ee 0c 00 00  value: fe 01 00 00
Found 4 elements
