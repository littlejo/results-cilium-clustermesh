CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode0d7774a_1045_4e9c_8628_48105e8fc148.slice/cri-containerd-097219f8b5ece0dd25b15301bc71ed163d59794b8dae7f3f7379a810e960fb23.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode0d7774a_1045_4e9c_8628_48105e8fc148.slice/cri-containerd-ac5dc7eb4219bef5e886d251bd9aea4638f8c375ce01d17c206797dd87f21bc7.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6aa4f960_68ee_4e39_9912_580ffcc3ee6e.slice/cri-containerd-7b8f067dc5886836fec40a6f53d5eb41191596f3ceb053f9b910a12e982ab33b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6aa4f960_68ee_4e39_9912_580ffcc3ee6e.slice/cri-containerd-a07877829d5bdeb3c34ace4d918e3f836f586d205d73d4634894f3644ee97293.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef2f42b3_feed_4b98_8110_ac607e9b37d2.slice/cri-containerd-fb6e56b7210ad99ae7f8dd86af6a11bda488e2204244644daa72d22bc4b81eb5.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podef2f42b3_feed_4b98_8110_ac607e9b37d2.slice/cri-containerd-936f42e5eec2a40f7ee0ee40a3812748e08c9dca3e43152b1727efa945d39273.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4e5708e_82c6_4e5f_a4b3_269b891791b4.slice/cri-containerd-c82722ceb2c600ac7459162a44ce73eeb64db769d1137129fb707c607588bb9f.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4e5708e_82c6_4e5f_a4b3_269b891791b4.slice/cri-containerd-7d0834d7f51dd05184cb6841783aba9538aa8d0c9203ba5922489949a1dbc6a4.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2ae7db1_7b43_4e30_8884_afdef185884b.slice/cri-containerd-906953428642e5e8c2f32d9d4d7a43571ef765f192a845fd3010da05f6bc83ad.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb2ae7db1_7b43_4e30_8884_afdef185884b.slice/cri-containerd-2aa3d64953ffab42ed21dbbc1949da7ee83475fecdd138b4672991831b1074c5.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a596e8_ce06_4e48_b425_1daf0737fe7a.slice/cri-containerd-28435c6ee88e0860ca9a38b1d3256e29a4bbe2f51cdf8c66bfd5a9b7a05b69fc.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a596e8_ce06_4e48_b425_1daf0737fe7a.slice/cri-containerd-579237e99030e54d1ed6763c163e05f6523650712d68db2abb62caf014d59e35.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-fd60eaf67e058598bffdd86fbda3097a8ac498baad36ce59bcc19f0843514131.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-e2d200cede0e5d1c95533394b5e02e5ae66a8df8e57f6eb8c3a86b955f55ac70.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-4499674b1d5c87926de332981a08a53daceab994ae9d64ea62b1680adde47c41.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-c40f433558d9751a2cee23a4dc87cd77fa7c358b7049f6225659657cb2b61aef.scope
    643      cgroup_device   multi                                          
