IP ADDRESS         LOCAL ENDPOINT INFO
10.243.0.133:0     id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE   
172.31.231.253:0   (localhost)                                                                                        
10.243.0.34:0      id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6   
172.31.196.138:0   (localhost)                                                                                        
10.243.0.50:0      (localhost)                                                                                        
10.243.0.48:0      id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83   
10.243.0.177:0     id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F     
