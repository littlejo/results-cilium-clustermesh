[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-c40f433558d9751a2cee23a4dc87cd77fa7c358b7049f6225659657cb2b61aef.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-fd60eaf67e058598bffdd86fbda3097a8ac498baad36ce59bcc19f0843514131.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf6398337_0621_44e2_9ad1_1d194ae4ff2b.slice/cri-containerd-e2d200cede0e5d1c95533394b5e02e5ae66a8df8e57f6eb8c3a86b955f55ac70.scope"
      }
    ],
    "ips": [
      "10.243.0.34"
    ],
    "name": "clustermesh-apiserver-c45c6b844-7hhpb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4e5708e_82c6_4e5f_a4b3_269b891791b4.slice/cri-containerd-c82722ceb2c600ac7459162a44ce73eeb64db769d1137129fb707c607588bb9f.scope"
      }
    ],
    "ips": [
      "10.243.0.133"
    ],
    "name": "coredns-cc6ccd49c-vcgdj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7751,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode0d7774a_1045_4e9c_8628_48105e8fc148.slice/cri-containerd-097219f8b5ece0dd25b15301bc71ed163d59794b8dae7f3f7379a810e960fb23.scope"
      }
    ],
    "ips": [
      "10.243.0.48"
    ],
    "name": "coredns-cc6ccd49c-7l668",
    "namespace": "kube-system"
  }
]

