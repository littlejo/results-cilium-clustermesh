KEY             VALUE
AgentLiveness   1622597191043
UTimeOffset     3379443328125000
