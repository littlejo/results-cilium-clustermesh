ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.222.66:443 (active)     
                                         2 => 172.31.183.140:443 (active)    
2    10.100.73.187:443    ClusterIP      1 => 172.31.196.138:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.243.0.48:53 (active)        
                                         2 => 10.243.0.133:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.243.0.48:9153 (active)      
                                         2 => 10.243.0.133:9153 (active)     
5    10.100.16.113:2379   ClusterIP      1 => 10.243.0.34:2379 (active)      
