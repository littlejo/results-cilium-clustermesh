REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38014     3013985     677    bpf_overlay.c
Interface                 INGRESS     678507    136540900   1132   bpf_host.c
Success                   EGRESS      17726     1399425     1694   bpf_host.c
Success                   EGRESS      292825    35993133    1308   bpf_lxc.c
Success                   EGRESS      39200     3095563     53     encap.h
Success                   INGRESS     336987    38271770    86     l3.h
Success                   INGRESS     357926    39930376    235    trace.h
Unsupported L3 protocol   EGRESS      45        3402        1492   bpf_lxc.c
