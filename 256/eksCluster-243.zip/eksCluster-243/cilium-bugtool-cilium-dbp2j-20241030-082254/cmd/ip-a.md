1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b8:a8:39:ab:c3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.196.138/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2019sec preferred_lft 2019sec
    inet6 fe80::8b8:a8ff:fe39:abc3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:91:66:3a:98:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.231.253/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::891:66ff:fe3a:98cd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:28:e1:31:5e:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8c28:e1ff:fe31:5e82/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:ca:93:e6:1a:20 brd ff:ff:ff:ff:ff:ff
    inet 10.243.0.50/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::48ca:93ff:fee6:1a20/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 42:d9:06:c2:96:81 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40d9:6ff:fec2:9681/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:df:d0:44:08:5f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cdf:d0ff:fe44:85f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxccc70aba2dcc0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:bc:d9:3a:7d:83 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f8bc:d9ff:fe3a:7d83/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9609ed22a3a9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:83:1c:f1:bd:fe brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c83:1cff:fef1:bdfe/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc11787c2203be@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:1b:05:ee:b8:b6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d41b:5ff:feee:b8b6/64 scope link 
       valid_lft forever preferred_lft forever
