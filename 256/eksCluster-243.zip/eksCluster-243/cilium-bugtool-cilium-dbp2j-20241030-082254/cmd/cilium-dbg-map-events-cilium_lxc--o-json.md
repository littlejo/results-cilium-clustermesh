{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.036Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.196.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.036Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.231.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.036Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.542Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.576Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.578Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.630Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:21.662Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.671Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.672Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.673Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.702Z",
  "value": "id=366   sec_id=7997894 flags=0x0000 ifindex=16  mac=66:B1:88:D7:F8:11 nodemac=26:7C:C7:DA:DC:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.671Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.672Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.672Z",
  "value": "id=366   sec_id=7997894 flags=0x0000 ifindex=16  mac=66:B1:88:D7:F8:11 nodemac=26:7C:C7:DA:DC:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.673Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:28.180Z",
  "value": "id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.243.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:38.499Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.167Z",
  "value": "id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.168Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.169Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.169Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.167Z",
  "value": "id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.168Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.169Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.169Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.167Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.167Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.167Z",
  "value": "id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.168Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.167Z",
  "value": "id=3083  sec_id=4     flags=0x0000 ifindex=10  mac=72:7D:47:FE:14:DF nodemac=8E:DF:D0:44:08:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.167Z",
  "value": "id=3310  sec_id=8011404 flags=0x0000 ifindex=12  mac=82:A8:E7:E9:23:BD nodemac=FA:BC:D9:3A:7D:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.168Z",
  "value": "id=168   sec_id=7997894 flags=0x0000 ifindex=18  mac=9A:84:AB:BB:14:18 nodemac=D6:1B:05:EE:B8:B6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.243.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.168Z",
  "value": "id=716   sec_id=8011404 flags=0x0000 ifindex=14  mac=82:3C:02:42:51:CB nodemac=2E:83:1C:F1:BD:FE"
}

