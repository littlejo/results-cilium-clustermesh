Endpoint ID: 168
Path: /sys/fs/bpf/tc/globals/cilium_policy_00168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11516788   116305    0        
Allow    Ingress     1          ANY          NONE         disabled    11457420   121252    0        
Allow    Egress      0          ANY          NONE         disabled    15264408   148889    0        


Endpoint ID: 716
Path: /sys/fs/bpf/tc/globals/cilium_policy_00716

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    108526   1244      0        
Allow    Egress      0          ANY          NONE         disabled    15932    172       0        


Endpoint ID: 3083
Path: /sys/fs/bpf/tc/globals/cilium_policy_03083

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1663406   20999     0        
Allow    Ingress     1          ANY          NONE         disabled    18215     218       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3310
Path: /sys/fs/bpf/tc/globals/cilium_policy_03310

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    107181   1227      0        
Allow    Egress      0          ANY          NONE         disabled    16943    184       0        


Endpoint ID: 3606
Path: /sys/fs/bpf/tc/globals/cilium_policy_03606

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


