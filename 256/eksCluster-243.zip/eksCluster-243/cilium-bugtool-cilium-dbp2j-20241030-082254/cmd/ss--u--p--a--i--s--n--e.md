Total: 679
TCP:   1858 (estab 429, closed 1410, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  448       437       11       
INET	  458       443       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:38797      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:34052 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.196.138%ens5:68         0.0.0.0:*    uid:192 ino:16485 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34130 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13269 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34129 sk:1001 cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:13270 sk:1002 cgroup:unreachable:f0c v6only:1 <->                        
UNCONN 0      0      [fe80::8b8:a8ff:fe39:abc3]%ens5:546           [::]:*    uid:192 ino:16482 sk:1003 cgroup:unreachable:c4e v6only:1 <->                
