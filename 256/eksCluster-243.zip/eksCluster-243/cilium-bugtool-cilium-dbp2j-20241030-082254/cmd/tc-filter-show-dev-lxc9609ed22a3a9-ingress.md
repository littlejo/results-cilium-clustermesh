filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc9609ed22a3a9 direct-action not_in_hw id 530 tag 6e4d6634c54fa9eb jited 
