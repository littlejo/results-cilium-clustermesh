xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 502
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 488
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxccc70aba2dcc0(12) clsact/ingress cil_from_container-lxccc70aba2dcc0 id 512
lxc9609ed22a3a9(14) clsact/ingress cil_from_container-lxc9609ed22a3a9 id 530
lxc11787c2203be(18) clsact/ingress cil_from_container-lxc11787c2203be id 617

flow_dissector:

netfilter:

