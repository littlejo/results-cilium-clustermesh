xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 542
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 540
cilium_host(7) clsact/egress cil_from_host-cilium_host id 536
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxcb32710492852(12) clsact/ingress cil_from_container-lxcb32710492852 id 530
lxce2dc03346236(14) clsact/ingress cil_from_container-lxce2dc03346236 id 533
lxcb6fd9c7d98e6(18) clsact/ingress cil_from_container-lxcb6fd9c7d98e6 id 644

flow_dissector:

netfilter:

