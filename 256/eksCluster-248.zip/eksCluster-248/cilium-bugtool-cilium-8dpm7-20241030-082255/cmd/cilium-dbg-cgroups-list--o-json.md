[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod206faa59_5024_46ca_8b0c_de747137e63c.slice/cri-containerd-dfc9b1a50d014f8384cbcc4865becd5ca9db1c6bb562b9a3a8d325738356a51c.scope"
      }
    ],
    "ips": [
      "10.248.0.10"
    ],
    "name": "coredns-cc6ccd49c-zlt9z",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-8d43572d06ece9c3166798020873bc06d3994fa7dd40955e47a424fc91e70bbd.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-5682e381986c9d7d1e5a2dc8d728e545b079c544205a91be82189b6d2b48e329.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-0e27d2a39485279aaf89dd58590c6ff58172c6c55913a2b6faf9a71579f43024.scope"
      }
    ],
    "ips": [
      "10.248.0.64"
    ],
    "name": "clustermesh-apiserver-6fb7cf8867-xg29c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a92f83a_0382_40b6_813c_5793c88d3ab8.slice/cri-containerd-4e8cde6c90dca831d4f8b0984516f872898d38992849b28bc1196bdcfcb03c7a.scope"
      }
    ],
    "ips": [
      "10.248.0.238"
    ],
    "name": "coredns-cc6ccd49c-6mr8z",
    "namespace": "kube-system"
  }
]

