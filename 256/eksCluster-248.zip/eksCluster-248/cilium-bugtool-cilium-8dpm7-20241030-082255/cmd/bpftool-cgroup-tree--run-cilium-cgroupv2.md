CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ffddad8_6ee7_46b7_a04f_6a2bcf5a51f2.slice/cri-containerd-000e7ba8fd0102b34a0f54426f8c72f2d7a9fdeae702653bd57ae2113a7e8ffd.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ffddad8_6ee7_46b7_a04f_6a2bcf5a51f2.slice/cri-containerd-0fa107ddfe1a77c76cf484cc09cc6ead63c498cee5bdbdec0c2989ea3ffcd298.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8092b0b9_b773_4567_8d96_0744c9807231.slice/cri-containerd-06eb83f4bdb32bcf331693394ed8fceefd30bc99a4991c169e560414bdff1d10.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8092b0b9_b773_4567_8d96_0744c9807231.slice/cri-containerd-563ec80afd324c04ad8bf1c2f65d4531cf195fa3871ae054b1cc41a2a5059272.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a92f83a_0382_40b6_813c_5793c88d3ab8.slice/cri-containerd-4e8cde6c90dca831d4f8b0984516f872898d38992849b28bc1196bdcfcb03c7a.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a92f83a_0382_40b6_813c_5793c88d3ab8.slice/cri-containerd-98876cf66daf224dfe29950a668fac9f5a3d8a2382ccdddb5bf7f093bd5e53cd.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod206faa59_5024_46ca_8b0c_de747137e63c.slice/cri-containerd-dfc9b1a50d014f8384cbcc4865becd5ca9db1c6bb562b9a3a8d325738356a51c.scope
    594      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod206faa59_5024_46ca_8b0c_de747137e63c.slice/cri-containerd-2d0fa946e3a59392008950f609eb4ff2aa64cf4f70acadb43de14ebac64d16ba.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe151925_7c4b_4728_9684_5f9e4a5a102d.slice/cri-containerd-daf375d5928ae23f33627962e2ab56f55ba99b1e556d96194851e59b0e59f558.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe151925_7c4b_4728_9684_5f9e4a5a102d.slice/cri-containerd-cfab644f6f98f2f48f6f3dbfa294d19bce9b60c02a2caa01f393ae0fcc9a3784.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d3225f7_91de_4820_9e5c_ced3525e06c8.slice/cri-containerd-eb45ded9a07176b882409d51aee4af84a536805615a48fe98a2ff738ca37015b.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d3225f7_91de_4820_9e5c_ced3525e06c8.slice/cri-containerd-6010d394351ab7da160c04dc8dfe2af77ed11383cbd6eec6029c8c66b60667c7.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-5682e381986c9d7d1e5a2dc8d728e545b079c544205a91be82189b6d2b48e329.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-0e27d2a39485279aaf89dd58590c6ff58172c6c55913a2b6faf9a71579f43024.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-3cf9d5709377c871e02623d7fb92aa85a42c6b69d84f15db972a7aeac6392391.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84d0e772_03c7_4f97_9e3b_32356d641342.slice/cri-containerd-8d43572d06ece9c3166798020873bc06d3994fa7dd40955e47a424fc91e70bbd.scope
    671      cgroup_device   multi                                          
