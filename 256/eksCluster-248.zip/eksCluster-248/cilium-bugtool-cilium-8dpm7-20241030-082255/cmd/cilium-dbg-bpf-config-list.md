KEY             VALUE
AgentLiveness   1584953763446
UTimeOffset     3379443404296875
