key: a0 03 00 00  value: 86 02 00 00
key: 3d 04 00 00  value: 35 02 00 00
key: 17 05 00 00  value: 10 02 00 00
key: 70 0a 00 00  value: 3f 02 00 00
Found 4 elements
