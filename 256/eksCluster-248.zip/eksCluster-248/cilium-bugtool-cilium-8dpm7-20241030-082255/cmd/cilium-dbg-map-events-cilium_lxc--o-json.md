{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.395Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.395Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.191.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:15.395Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.881Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.881Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.937Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:19.963Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.428Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.429Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.429Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:29.461Z",
  "value": "id=1905  sec_id=8178003 flags=0x0000 ifindex=16  mac=F6:B2:58:2B:F3:F0 nodemac=9A:6C:86:DE:7D:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.429Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.429Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.429Z",
  "value": "id=1905  sec_id=8178003 flags=0x0000 ifindex=16  mac=F6:B2:58:2B:F3:F0 nodemac=9A:6C:86:DE:7D:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:30.429Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.183Z",
  "value": "id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.248.0.115:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.902Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.771Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.773Z",
  "value": "id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.773Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.774Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.746Z",
  "value": "id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.750Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.754Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.754Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.712Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.713Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.713Z",
  "value": "id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.713Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.10:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.712Z",
  "value": "id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.712Z",
  "value": "id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.713Z",
  "value": "id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.248.0.105:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.713Z",
  "value": "id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91"
}

