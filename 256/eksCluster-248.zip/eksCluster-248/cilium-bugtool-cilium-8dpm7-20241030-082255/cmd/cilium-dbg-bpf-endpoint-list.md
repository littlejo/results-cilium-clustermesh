IP ADDRESS        LOCAL ENDPOINT INFO
10.248.0.238:0    id=1085  sec_id=8181730 flags=0x0000 ifindex=14  mac=12:3C:29:90:A8:83 nodemac=3E:07:A4:AB:D2:64   
10.248.0.10:0     id=1303  sec_id=8181730 flags=0x0000 ifindex=12  mac=62:F7:CA:00:31:99 nodemac=3A:01:DE:2F:5C:44   
172.31.191.30:0   (localhost)                                                                                        
10.248.0.64:0     id=928   sec_id=8178003 flags=0x0000 ifindex=18  mac=6A:B7:F2:3B:12:ED nodemac=CE:3F:2B:14:39:74   
10.248.0.105:0    id=2672  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CB:51:EB:0B:7F nodemac=2E:83:5F:88:B9:91     
10.248.0.25:0     (localhost)                                                                                        
172.31.154.30:0   (localhost)                                                                                        
