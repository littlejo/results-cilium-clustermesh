markdown output at /tmp/cilium-bugtool-20241030-082257.298+0000-UTC-1760843215/cmd/cilium-debuginfo-20241030-082328.238+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.298+0000-UTC-1760843215/cmd/cilium-debuginfo-20241030-082328.238+0000-UTC.json
