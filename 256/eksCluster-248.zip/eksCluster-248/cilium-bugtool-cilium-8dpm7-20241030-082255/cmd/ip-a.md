1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d5:e4:be:bb:89 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.191.30/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2056sec preferred_lft 2056sec
    inet6 fe80::4d5:e4ff:febe:bb89/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:37:f2:38:fb:ab brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.154.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::437:f2ff:fe38:fbab/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:81:1d:7c:15:79 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a881:1dff:fe7c:1579/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:f4:3f:70:ec:bc brd ff:ff:ff:ff:ff:ff
    inet 10.248.0.25/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::30f4:3fff:fe70:ecbc/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0a:29:a4:47:bb:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::829:a4ff:fe47:bbbd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:83:5f:88:b9:91 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2c83:5fff:fe88:b991/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb32710492852@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:01:de:2f:5c:44 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3801:deff:fe2f:5c44/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce2dc03346236@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:07:a4:ab:d2:64 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3c07:a4ff:feab:d264/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb6fd9c7d98e6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:3f:2b:14:39:74 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::cc3f:2bff:fe14:3974/64 scope link 
       valid_lft forever preferred_lft forever
