ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.166.159:443 (active)   
                                         2 => 172.31.255.97:443 (active)    
2    10.100.66.231:443    ClusterIP      1 => 172.31.191.30:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.248.0.10:9153 (active)     
                                         2 => 10.248.0.238:9153 (active)    
4    10.100.0.10:53       ClusterIP      1 => 10.248.0.10:53 (active)       
                                         2 => 10.248.0.238:53 (active)      
5    10.100.29.124:2379   ClusterIP      1 => 10.248.0.64:2379 (active)     
