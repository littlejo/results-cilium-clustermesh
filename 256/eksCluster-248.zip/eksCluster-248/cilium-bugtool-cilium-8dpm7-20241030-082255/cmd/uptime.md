 08:22:57 up 25 min,  0 users,  load average: 0.13, 0.20, 0.14
