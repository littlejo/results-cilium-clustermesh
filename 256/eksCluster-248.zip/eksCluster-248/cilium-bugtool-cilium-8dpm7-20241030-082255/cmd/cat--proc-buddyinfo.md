Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal     92     97     32     11    176     85     24      7      4      5    850 
