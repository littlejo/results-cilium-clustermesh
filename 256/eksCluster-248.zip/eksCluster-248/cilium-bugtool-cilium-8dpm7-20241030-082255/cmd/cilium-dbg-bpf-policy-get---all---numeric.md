Endpoint ID: 386
Path: /sys/fs/bpf/tc/globals/cilium_policy_00386

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 928
Path: /sys/fs/bpf/tc/globals/cilium_policy_00928

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11510093   113829    0        
Allow    Ingress     1          ANY          NONE         disabled    9476977    99470     0        
Allow    Egress      0          ANY          NONE         disabled    11946491   118347    0        


Endpoint ID: 1085
Path: /sys/fs/bpf/tc/globals/cilium_policy_01085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    103183   1181      0        
Allow    Egress      0          ANY          NONE         disabled    15569    166       0        


Endpoint ID: 1303
Path: /sys/fs/bpf/tc/globals/cilium_policy_01303

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    103960   1196      0        
Allow    Egress      0          ANY          NONE         disabled    15875    170       0        


Endpoint ID: 2672
Path: /sys/fs/bpf/tc/globals/cilium_policy_02672

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664458   21007     0        
Allow    Ingress     1          ANY          NONE         disabled    16496     194       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


