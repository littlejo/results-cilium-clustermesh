top - 08:22:57 up 25 min,  0 users,  load average: 0.13, 0.20, 0.14
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 46.9 us, 40.6 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 12.5 si,  0.0 st
MiB Mem :   7814.2 total,   4463.4 free,   1204.5 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    705 root      20   0 1244340  23144  14652 S  53.3   0.3   0:00.23 hubble
      1 root      20   0 1606080 380524  78200 S   6.7   4.8   0:38.31 cilium-+
    415 root      20   0 1229744   8212   3844 S   0.0   0.1   0:01.07 cilium-+
    653 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    664 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    682 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    697 root      20   0    2208    788    712 S   0.0   0.0   0:00.00 timeout
    699 root      20   0 1240432  16252  11292 S   0.0   0.2   0:00.02 cilium-+
    745 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    750 root      20   0    3132    988    868 R   0.0   0.0   0:00.00 bpftool
