alloc: 176.60MB (185179960 bytes)
total-alloc: 2.17GB (2332601552 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 62323067
frees: 60974194
heap-alloc: 176.60MB (185179960 bytes)
heap-sys: 259.91MB (272531456 bytes)
heap-idle: 48.72MB (51085312 bytes)
heap-in-use: 211.19MB (221446144 bytes)
heap-released: 11.47MB (12025856 bytes)
heap-objects: 1348873
stack-in-use: 59.72MB (62619648 bytes)
stack-sys: 59.72MB (62619648 bytes)
stack-mspan-inuse: 3.50MB (3673120 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1089417 bytes)
gc-sys: 6.35MB (6663632 bytes)
next-gc: when heap-alloc >= 219.23MB (229882360 bytes)
last-gc: 2024-10-30 08:23:27.401102965 +0000 UTC
gc-pause-total: 9.774031ms
gc-pause: 134059
gc-pause-end: 1730276607401102965
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005621138118789889
enable-gc: true
debug-gc: false
