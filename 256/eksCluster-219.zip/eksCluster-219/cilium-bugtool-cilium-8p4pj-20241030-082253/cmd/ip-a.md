1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f3:8c:34:49:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.216.60/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1928sec preferred_lft 1928sec
    inet6 fe80::8f3:8cff:fe34:4937/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b7:a7:57:45:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.207.191/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b7:a7ff:fe57:45d1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:1f:62:e1:ab:42 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cc1f:62ff:fee1:ab42/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:05:bd:85:33:25 brd ff:ff:ff:ff:ff:ff
    inet 10.219.0.128/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3005:bdff:fe85:3325/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 22:06:08:23:31:d4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2006:8ff:fe23:31d4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:69:a6:0b:44:bd brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b869:a6ff:fe0b:44bd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc90d03dbf858c@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:77:af:63:07:88 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1877:afff:fe63:788/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc61dc372462b1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:05:67:58:12:01 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::bc05:67ff:fe58:1201/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcacfbb99ecf89@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:c7:99:05:6b:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::58c7:99ff:fe05:6be8/64 scope link 
       valid_lft forever preferred_lft forever
