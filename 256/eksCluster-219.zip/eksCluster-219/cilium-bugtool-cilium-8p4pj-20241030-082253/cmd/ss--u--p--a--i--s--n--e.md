Total: 686
TCP:   1857 (estab 436, closed 1402, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  455       443       12       
INET	  465       449       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.216.60%ens5:68         0.0.0.0:*    uid:192 ino:14224 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34156 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15603 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:33211      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33988 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34155 sk:100b cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:15604 sk:100c cgroup:unreachable:f0c v6only:1 <->                        
UNCONN 0      0      [fe80::8f3:8cff:fe34:4937]%ens5:546           [::]:*    uid:192 ino:14220 sk:100d cgroup:unreachable:c4e v6only:1 <->                
