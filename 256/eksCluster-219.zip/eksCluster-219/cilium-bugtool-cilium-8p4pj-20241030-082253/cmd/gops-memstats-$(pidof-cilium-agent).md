alloc: 174.71MB (183197024 bytes)
total-alloc: 2.15GB (2308565784 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 61898890
frees: 59889122
heap-alloc: 174.71MB (183197024 bytes)
heap-sys: 255.66MB (268083200 bytes)
heap-idle: 57.07MB (59842560 bytes)
heap-in-use: 198.59MB (208240640 bytes)
heap-released: 10.98MB (11517952 bytes)
heap-objects: 2009768
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.36MB (3523360 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.38KB (1023369 bytes)
gc-sys: 6.02MB (6315616 bytes)
next-gc: when heap-alloc >= 214.65MB (225079640 bytes)
last-gc: 2024-10-30 08:22:55.557321289 +0000 UTC
gc-pause-total: 7.914166ms
gc-pause: 585268
gc-pause-end: 1730276575557321289
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0005891208043901611
enable-gc: true
debug-gc: false
