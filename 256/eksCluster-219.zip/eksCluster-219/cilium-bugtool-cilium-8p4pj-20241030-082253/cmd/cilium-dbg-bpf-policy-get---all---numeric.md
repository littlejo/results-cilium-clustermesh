Endpoint ID: 465
Path: /sys/fs/bpf/tc/globals/cilium_policy_00465

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660860   21009     0        
Allow    Ingress     1          ANY          NONE         disabled    16978     199       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1082
Path: /sys/fs/bpf/tc/globals/cilium_policy_01082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112147   1288      0        
Allow    Egress      0          ANY          NONE         disabled    15785    171       0        


Endpoint ID: 1387
Path: /sys/fs/bpf/tc/globals/cilium_policy_01387

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11361163   111906    0        
Allow    Ingress     1          ANY          NONE         disabled    9186422    95923     0        
Allow    Egress      0          ANY          NONE         disabled    11496501   114231    0        


Endpoint ID: 1447
Path: /sys/fs/bpf/tc/globals/cilium_policy_01447

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3606
Path: /sys/fs/bpf/tc/globals/cilium_policy_03606

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112609   1295      0        
Allow    Egress      0          ANY          NONE         disabled    16329    176       0        


