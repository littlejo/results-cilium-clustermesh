IP ADDRESS         LOCAL ENDPOINT INFO
10.219.0.80:0      id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88   
10.219.0.95:0      id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01   
10.219.0.128:0     (localhost)                                                                                        
172.31.216.60:0    (localhost)                                                                                        
10.219.0.54:0      id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD     
10.219.0.12:0      id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8   
172.31.207.191:0   (localhost)                                                                                        
