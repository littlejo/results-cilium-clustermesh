{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.267Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.267Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.216.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.267Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.782Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.789Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.833Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.898Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:41.991Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.394Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.394Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.395Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.424Z",
  "value": "id=2122  sec_id=7217396 flags=0x0000 ifindex=16  mac=AE:18:2F:09:4E:28 nodemac=4E:D5:77:2C:CB:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:28.425Z",
  "value": "id=2122  sec_id=7217396 flags=0x0000 ifindex=16  mac=AE:18:2F:09:4E:28 nodemac=4E:D5:77:2C:CB:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.395Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.395Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.395Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:29.395Z",
  "value": "id=2122  sec_id=7217396 flags=0x0000 ifindex=16  mac=AE:18:2F:09:4E:28 nodemac=4E:D5:77:2C:CB:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.081Z",
  "value": "id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.219.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:08.465Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.634Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.635Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.635Z",
  "value": "id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.636Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.636Z",
  "value": "id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.637Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.638Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.638Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.636Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.636Z",
  "value": "id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.636Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.637Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.637Z",
  "value": "id=465   sec_id=4     flags=0x0000 ifindex=10  mac=26:FA:50:93:EE:F8 nodemac=BA:69:A6:0B:44:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.637Z",
  "value": "id=3606  sec_id=7209488 flags=0x0000 ifindex=12  mac=5E:5C:C2:3D:27:77 nodemac=1A:77:AF:63:07:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.638Z",
  "value": "id=1082  sec_id=7209488 flags=0x0000 ifindex=14  mac=A2:4F:A7:7F:0A:F6 nodemac=BE:05:67:58:12:01"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.219.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.638Z",
  "value": "id=1387  sec_id=7217396 flags=0x0000 ifindex=18  mac=FA:18:12:78:48:E8 nodemac=5A:C7:99:05:6B:E8"
}

