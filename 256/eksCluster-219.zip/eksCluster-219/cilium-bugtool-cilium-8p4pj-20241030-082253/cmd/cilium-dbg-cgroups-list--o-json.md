[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-724dea60571e0c03be379b05c867ba6024652feb2d851e43d973c9b47b2911f6.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-a462a084004f32231109f85e1e562fea721314cdb3dfa66c2b1eef64b2fe8094.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-1f9d585e6e694b0e4990b15ed36542c65ed3b5467f6174428435c4af347fe095.scope"
      }
    ],
    "ips": [
      "10.219.0.12"
    ],
    "name": "clustermesh-apiserver-cf8cfdcf9-qsgbl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf56cc18_e7e7_48b4_a9b5_426872e86796.slice/cri-containerd-5841cf5a34440a78a29bfbf5f78826112664a93108246b4fe337f83a042e9bc9.scope"
      }
    ],
    "ips": [
      "10.219.0.95"
    ],
    "name": "coredns-cc6ccd49c-vzr6g",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cebeb35_c3f6_4829_8c41_c2c3eac55529.slice/cri-containerd-35fba4a235194e808565fd128b477175ad03952025b13754c4e5350086f4a448.scope"
      }
    ],
    "ips": [
      "10.219.0.80"
    ],
    "name": "coredns-cc6ccd49c-4qtkr",
    "namespace": "kube-system"
  }
]

