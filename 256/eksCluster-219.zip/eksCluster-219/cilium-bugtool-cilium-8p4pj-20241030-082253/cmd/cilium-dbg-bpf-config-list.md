KEY             VALUE
AgentLiveness   1714828894751
UTimeOffset     3379443148437500
