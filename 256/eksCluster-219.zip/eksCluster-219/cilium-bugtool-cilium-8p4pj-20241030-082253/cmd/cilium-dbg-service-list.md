ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.236.254:443 (active)   
                                         2 => 172.31.153.95:443 (active)    
2    10.100.236.133:443   ClusterIP      1 => 172.31.216.60:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.219.0.80:9153 (active)     
                                         2 => 10.219.0.95:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.219.0.80:53 (active)       
                                         2 => 10.219.0.95:53 (active)       
5    10.100.84.41:2379    ClusterIP      1 => 10.219.0.12:2379 (active)     
