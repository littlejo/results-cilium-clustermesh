CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cebeb35_c3f6_4829_8c41_c2c3eac55529.slice/cri-containerd-35fba4a235194e808565fd128b477175ad03952025b13754c4e5350086f4a448.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2cebeb35_c3f6_4829_8c41_c2c3eac55529.slice/cri-containerd-998be75d359809d6bfa067848ee49337e0730359a9f7c69e47cb7652b7e39ef6.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf56cc18_e7e7_48b4_a9b5_426872e86796.slice/cri-containerd-690bf6e3f889304bc0e400767b9f065bb4cf1d252b8b32e00717cbee9b278b8f.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddf56cc18_e7e7_48b4_a9b5_426872e86796.slice/cri-containerd-5841cf5a34440a78a29bfbf5f78826112664a93108246b4fe337f83a042e9bc9.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0eb2f858_4b81_4cc4_86e8_cbb81f552427.slice/cri-containerd-9416adf1fb05197faafe31f3ea9215cda895906e567e397056a2764713187bba.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0eb2f858_4b81_4cc4_86e8_cbb81f552427.slice/cri-containerd-a824a4fd03cf09d75a9b0f65e558367480101b6d0f4f89fd2bdfa769c4fb46b5.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f5602a3_62a9_487c_ba6f_c44b2a6a17c3.slice/cri-containerd-26fb3e7911d8ac7feabd98d2be6261d3a03fe6c842c1ba2c41f9a371fbb40b3c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f5602a3_62a9_487c_ba6f_c44b2a6a17c3.slice/cri-containerd-01d6ef3af438d98cd682e5dca27a13bd4259c9afba63fb3d83c6a0a4c82d56f5.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-852c410de2107c3eabafb85045463bc2f8acb646d1a4a5717c4ec9b05778f923.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-724dea60571e0c03be379b05c867ba6024652feb2d851e43d973c9b47b2911f6.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-1f9d585e6e694b0e4990b15ed36542c65ed3b5467f6174428435c4af347fe095.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda2681a42_e28c_4bf9_948f_bc661a0c4e5e.slice/cri-containerd-a462a084004f32231109f85e1e562fea721314cdb3dfa66c2b1eef64b2fe8094.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779dc05b_fbae_4552_9149_d525a81ddcd2.slice/cri-containerd-1a8308e453239161f293490d79fd49f8616710388ad0a470deafb6a42765d4f4.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod779dc05b_fbae_4552_9149_d525a81ddcd2.slice/cri-containerd-43d5d8e0a723bc06242d085558c603dabd16b061aa92d02a6295694c3202125d.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa1440ef_4820_4414_baed_4f9a6c8335a8.slice/cri-containerd-d957197ba6c661f8bc1c71d2c85ce191768aa0ff5c1e39473f885fd83a275770.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa1440ef_4820_4414_baed_4f9a6c8335a8.slice/cri-containerd-753c6abc4e595be7f501be017b1b7f6fc8f58d76cda0d059477a6b9b95791957.scope
    97       cgroup_device   multi                                          
