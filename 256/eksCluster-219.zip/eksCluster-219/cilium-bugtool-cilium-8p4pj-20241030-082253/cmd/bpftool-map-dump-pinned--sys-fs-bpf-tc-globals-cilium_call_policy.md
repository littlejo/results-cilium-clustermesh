key: d1 01 00 00  value: 10 02 00 00
key: 3a 04 00 00  value: 01 02 00 00
key: 6b 05 00 00  value: 78 02 00 00
key: 16 0e 00 00  value: 21 02 00 00
Found 4 elements
