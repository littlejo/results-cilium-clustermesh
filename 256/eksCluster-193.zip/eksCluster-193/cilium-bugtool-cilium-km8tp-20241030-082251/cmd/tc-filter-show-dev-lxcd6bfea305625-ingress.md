filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd6bfea305625 direct-action not_in_hw id 533 tag 204c0f6372f5f9ab jited 
