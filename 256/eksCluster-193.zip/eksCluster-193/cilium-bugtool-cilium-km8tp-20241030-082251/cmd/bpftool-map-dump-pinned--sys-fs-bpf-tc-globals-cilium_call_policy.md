key: 27 01 00 00  value: 61 02 00 00
key: 0b 05 00 00  value: 17 02 00 00
key: 28 0c 00 00  value: 18 02 00 00
key: c4 0c 00 00  value: 00 02 00 00
Found 4 elements
