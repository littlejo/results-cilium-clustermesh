 08:22:57 up 31 min,  0 users,  load average: 0.44, 0.36, 0.21
