alloc: 194.32MB (203760072 bytes)
total-alloc: 2.29GB (2459057872 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64178020
frees: 62159880
heap-alloc: 194.32MB (203760072 bytes)
heap-sys: 247.48MB (259506176 bytes)
heap-idle: 26.79MB (28090368 bytes)
heap-in-use: 220.70MB (231415808 bytes)
heap-released: 1.17MB (1228800 bytes)
heap-objects: 2018140
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.44MB (3604160 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 999.10KB (1023081 bytes)
gc-sys: 6.02MB (6317616 bytes)
next-gc: when heap-alloc >= 208.37MB (218491784 bytes)
last-gc: 2024-10-30 08:22:54.849363971 +0000 UTC
gc-pause-total: 13.421119ms
gc-pause: 108080
gc-pause-end: 1730276574849363971
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0004227618668966007
enable-gc: true
debug-gc: false
