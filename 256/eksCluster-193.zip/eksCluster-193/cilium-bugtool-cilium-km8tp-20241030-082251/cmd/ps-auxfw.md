USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         605  0.0  0.0  13060  1224 ?        R    08:22   0:00 /usr/sbin/runc init
root         590  0.0  0.2 1240432 16476 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         606  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         608  0.0  0.2 1240432 16476 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.9  4.7 1606080 380100 ?      Ssl  08:01   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 6908 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
