REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36790     2912384     677    bpf_overlay.c
Interface                 INGRESS     652788    133145395   1132   bpf_host.c
Success                   EGRESS      16519     1300450     1694   bpf_host.c
Success                   EGRESS      277390    34523811    1308   bpf_lxc.c
Success                   EGRESS      37060     2931929     53     encap.h
Success                   INGRESS     321373    36205634    86     l3.h
Success                   INGRESS     342295    37861614    235    trace.h
Unsupported L3 protocol   EGRESS      45        3382        1492   bpf_lxc.c
