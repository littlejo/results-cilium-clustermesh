ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.190.33:443 (active)     
                                         2 => 172.31.214.78:443 (active)     
2    10.100.183.66:443    ClusterIP      1 => 172.31.238.226:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.193.0.66:53 (active)        
                                         2 => 10.193.0.18:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.193.0.66:9153 (active)      
                                         2 => 10.193.0.18:9153 (active)      
5    10.100.98.118:2379   ClusterIP      1 => 10.193.0.47:2379 (active)      
