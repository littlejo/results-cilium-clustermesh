CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd3bc401_e051_4956_9aee_ddc58d95218a.slice/cri-containerd-80566573e67bde7c88656f034be0f24ac14fc3bed0572f1d52e42c0d3b39069b.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd3bc401_e051_4956_9aee_ddc58d95218a.slice/cri-containerd-1ed9f789323d8a634f56ff2a191b8959d82dbe5213c3b805abef3fdebe1186f1.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ccdc79_61f0_4215_b9b3_70752c7e3cfc.slice/cri-containerd-66e31c24b70bb1b7a016524d5f38c9cd53cbd0774609901d8ebb1feade02e7d7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34ccdc79_61f0_4215_b9b3_70752c7e3cfc.slice/cri-containerd-afc62b1a4f193e969f86e8d5bfdf658d37c485d3fcb4f4f8bbd99cc30ad3f268.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6c6c976_2431_4f1a_86f0_43eec9499227.slice/cri-containerd-e048b6e337bf2b8a5a1bef42a6bc071b3afb3714744cde48a1e4f5b9d2b0b2ef.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda6c6c976_2431_4f1a_86f0_43eec9499227.slice/cri-containerd-e59bb07471a8a9132402cbcd65a264a85422c1337f47c98286c117f43bb00e7a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podade8efc8_ef0b_462f_b498_983af54cd2cc.slice/cri-containerd-d9071fcf633d8cb14067c1cdab84818ea3357e66ac0f97c4e1c036e7d40b8b59.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podade8efc8_ef0b_462f_b498_983af54cd2cc.slice/cri-containerd-2a90432ca562eeaa2a6816d24895d94143f6f5df326960f6c47dce68abe9aeb4.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11fa93fd_0a30_4bc1_9f95_8e89106d98f4.slice/cri-containerd-923c3dd71651be81086545ae275cdf2a9522d8d1c66eacd809cf0638b4737c75.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod11fa93fd_0a30_4bc1_9f95_8e89106d98f4.slice/cri-containerd-1785fa92a6316f43de02dbbd29b000ba686ac177e6393a50368d194edbe4fed7.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-a63991cbaa7b5bc3be6f00b37c4f2c324c51fab8c74909e5730e9c09c5efb1d5.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-97422175f1b542a2b0c9aee82ee8a10d91901412fb9ff0ae72a5a76ec07d5417.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-4feb87d4fe857ac70e1325bf56326bbc676feb2d885db0739a0081e78108e2af.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-02245be871fabbd99c88855ac25854616e5f7d7678ac44b86eaf05e7d6f659bf.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f5588f7_5fb2_49ec_9a53_4ce7061e25e7.slice/cri-containerd-fae1cb5665537f5555de78a943572a565560c7185defa5f5045593e41c9a5569.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5f5588f7_5fb2_49ec_9a53_4ce7061e25e7.slice/cri-containerd-05d29e7284f101965882524d733ff531e67cf7baa314f941bca235ae139c5a02.scope
    91       cgroup_device   multi                                          
