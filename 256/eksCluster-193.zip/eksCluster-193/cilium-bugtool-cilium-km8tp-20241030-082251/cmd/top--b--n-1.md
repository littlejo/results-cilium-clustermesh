top - 08:22:57 up 31 min,  0 users,  load average: 0.44, 0.36, 0.21
Tasks:  11 total,   4 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.2 us, 40.6 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   7814.2 total,   4435.4 free,   1232.9 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6396.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    668 root      20   0 1244340  22528  14396 S  25.0   0.3   0:00.04 hubble
      1 root      20   0 1606080 382724  80520 S  12.5   4.8   0:50.65 cilium-+
    685 root      20   0    2400   1492   1284 R   6.2   0.0   0:00.01 sysctl
    393 root      20   0 1229744   6908   2864 S   0.0   0.1   0:01.14 cilium-+
    590 root      20   0 1240432  16476  11292 S   0.0   0.2   0:00.02 cilium-+
    637 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    638 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    639 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    675 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    693 root      20   0 1550472   7432   5556 R   0.0   0.1   0:00.00 runc:[2+
    699 root      20   0   13060   1228     60 R   0.0   0.0   0:00.00 runc:[1+
