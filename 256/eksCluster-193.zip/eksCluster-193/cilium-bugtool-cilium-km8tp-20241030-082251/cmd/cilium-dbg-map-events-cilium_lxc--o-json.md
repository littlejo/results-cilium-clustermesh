{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.207.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:46.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.233Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.234Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.278Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.279Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:51.301Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:49.318Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:49.319Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:49.319Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:49.349Z",
  "value": "id=230   sec_id=6386549 flags=0x0000 ifindex=16  mac=6E:F2:63:18:B5:E9 nodemac=4A:0E:6D:5D:30:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:50.319Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:50.320Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:50.320Z",
  "value": "id=230   sec_id=6386549 flags=0x0000 ifindex=16  mac=6E:F2:63:18:B5:E9 nodemac=4A:0E:6D:5D:30:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:50.320Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.980Z",
  "value": "id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.193.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:40.785Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.322Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.323Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.323Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.323Z",
  "value": "id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.147Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.148Z",
  "value": "id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.148Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.149Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.147Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.148Z",
  "value": "id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.148Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.149Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.147Z",
  "value": "id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.148Z",
  "value": "id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.148Z",
  "value": "id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.193.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.149Z",
  "value": "id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1"
}

