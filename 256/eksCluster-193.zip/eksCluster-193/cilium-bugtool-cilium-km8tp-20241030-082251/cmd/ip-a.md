1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bf:fc:94:44:eb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.238.226/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3521sec preferred_lft 3521sec
    inet6 fe80::8bf:fcff:fe94:44eb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:30:a3:5c:a3:17 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.207.31/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::830:a3ff:fe5c:a317/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:a6:f9:75:7b:4f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34a6:f9ff:fe75:7b4f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:b0:5b:53:4d:36 brd ff:ff:ff:ff:ff:ff
    inet 10.193.0.37/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8b0:5bff:fe53:4d36/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 66:8c:a5:49:dd:63 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::648c:a5ff:fe49:dd63/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:0d:84:f7:5b:55 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9c0d:84ff:fef7:5b55/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd8e9514ea4e7@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:d3:68:ab:f5:4d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cd3:68ff:feab:f54d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd6bfea305625@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:90:fb:71:2c:4f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c490:fbff:fe71:2c4f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc44cf7f415a2f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:4a:07:d8:5e:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::804a:7ff:fed8:5ed1/64 scope link 
       valid_lft forever preferred_lft forever
