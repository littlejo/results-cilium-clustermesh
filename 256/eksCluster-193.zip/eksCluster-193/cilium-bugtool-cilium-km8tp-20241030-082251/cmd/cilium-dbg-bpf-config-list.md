KEY             VALUE
AgentLiveness   1919308681490
UTimeOffset     3379442751953125
