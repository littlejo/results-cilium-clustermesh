[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podade8efc8_ef0b_462f_b498_983af54cd2cc.slice/cri-containerd-d9071fcf633d8cb14067c1cdab84818ea3357e66ac0f97c4e1c036e7d40b8b59.scope"
      }
    ],
    "ips": [
      "10.193.0.18"
    ],
    "name": "coredns-cc6ccd49c-hr64c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfd3bc401_e051_4956_9aee_ddc58d95218a.slice/cri-containerd-80566573e67bde7c88656f034be0f24ac14fc3bed0572f1d52e42c0d3b39069b.scope"
      }
    ],
    "ips": [
      "10.193.0.66"
    ],
    "name": "coredns-cc6ccd49c-dfv48",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-a63991cbaa7b5bc3be6f00b37c4f2c324c51fab8c74909e5730e9c09c5efb1d5.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-97422175f1b542a2b0c9aee82ee8a10d91901412fb9ff0ae72a5a76ec07d5417.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00146e68_f2ee_4cb1_ab3f_8316020c1e66.slice/cri-containerd-02245be871fabbd99c88855ac25854616e5f7d7678ac44b86eaf05e7d6f659bf.scope"
      }
    ],
    "ips": [
      "10.193.0.47"
    ],
    "name": "clustermesh-apiserver-699d4c968c-rfrjw",
    "namespace": "kube-system"
  }
]

