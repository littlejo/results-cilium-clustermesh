IP ADDRESS         LOCAL ENDPOINT INFO
10.193.0.18:0      id=1291  sec_id=6374673 flags=0x0000 ifindex=14  mac=DE:9D:97:69:A1:36 nodemac=C6:90:FB:71:2C:4F   
10.193.0.47:0      id=295   sec_id=6386549 flags=0x0000 ifindex=18  mac=7A:A0:D1:CD:6B:33 nodemac=82:4A:07:D8:5E:D1   
10.193.0.49:0      id=3112  sec_id=4     flags=0x0000 ifindex=10  mac=22:C0:A7:28:CB:DD nodemac=9E:0D:84:F7:5B:55     
172.31.207.31:0    (localhost)                                                                                        
10.193.0.37:0      (localhost)                                                                                        
172.31.238.226:0   (localhost)                                                                                        
10.193.0.66:0      id=3268  sec_id=6374673 flags=0x0000 ifindex=12  mac=6A:1F:56:04:0A:1A nodemac=8E:D3:68:AB:F5:4D   
