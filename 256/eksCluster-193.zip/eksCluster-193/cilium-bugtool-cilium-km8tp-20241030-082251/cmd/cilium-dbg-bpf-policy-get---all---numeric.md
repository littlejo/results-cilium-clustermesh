Endpoint ID: 295
Path: /sys/fs/bpf/tc/globals/cilium_policy_00295

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11619868   116454    0        
Allow    Ingress     1          ANY          NONE         disabled    10526591   111004    0        
Allow    Egress      0          ANY          NONE         disabled    13547529   133285    0        


Endpoint ID: 487
Path: /sys/fs/bpf/tc/globals/cilium_policy_00487

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1291
Path: /sys/fs/bpf/tc/globals/cilium_policy_01291

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123811   1422      0        
Allow    Egress      0          ANY          NONE         disabled    17279    187       0        


Endpoint ID: 3112
Path: /sys/fs/bpf/tc/globals/cilium_policy_03112

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660194   20973     0        
Allow    Ingress     1          ANY          NONE         disabled    19646     233       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3268
Path: /sys/fs/bpf/tc/globals/cilium_policy_03268

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123745   1421      0        
Allow    Egress      0          ANY          NONE         disabled    15600    168       0        


