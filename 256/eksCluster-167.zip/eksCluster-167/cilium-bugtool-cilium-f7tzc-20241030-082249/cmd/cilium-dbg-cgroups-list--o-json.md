[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-3bd1e6d936dd91fc6605cac5a9c1bdc0713e4cef70c5139991b7305b7c296a28.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-c40e2f4a54426d70d8939d11e940d5fcae4d14c62f9ff709e0a7e0991fb628bb.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-d56624bab26785427decf14dab1bce9e3904c514a871a5a3eff40b73f630b719.scope"
      }
    ],
    "ips": [
      "10.167.0.209"
    ],
    "name": "clustermesh-apiserver-f8f76b774-vwxwf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dc49bfa_7300_4b12_b7ef_32ed23e5219b.slice/cri-containerd-652de113328e97f37f94a2eb2e8154c8ab6a60edb0893baaa1180944c643e7e2.scope"
      }
    ],
    "ips": [
      "10.167.0.60"
    ],
    "name": "coredns-cc6ccd49c-ztfmt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0af41e80_4b4a_46b9_b939_0679af010292.slice/cri-containerd-4fe628970605aeb5638ffcc978c1913a1db80db06299e8fe07dbaa1f385dd127.scope"
      }
    ],
    "ips": [
      "10.167.0.83"
    ],
    "name": "coredns-cc6ccd49c-rq4t7",
    "namespace": "kube-system"
  }
]

