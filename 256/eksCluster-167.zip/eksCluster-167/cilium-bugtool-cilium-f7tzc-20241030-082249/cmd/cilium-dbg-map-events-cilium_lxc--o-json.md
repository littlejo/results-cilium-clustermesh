{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.204.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.214.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.878Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:04.366Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:04.370Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:04.450Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:04.501Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:04.548Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:33.137Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:33.138Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:33.138Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:33.171Z",
  "value": "id=1018  sec_id=5531044 flags=0x0000 ifindex=16  mac=AA:1E:FB:6A:57:07 nodemac=46:0C:D6:9B:56:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.138Z",
  "value": "id=1018  sec_id=5531044 flags=0x0000 ifindex=16  mac=AA:1E:FB:6A:57:07 nodemac=46:0C:D6:9B:56:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.138Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.138Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:34.138Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.953Z",
  "value": "id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.167.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.360Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.087Z",
  "value": "id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.088Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.088Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.089Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.096Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.121Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.122Z",
  "value": "id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:53.142Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.090Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.091Z",
  "value": "id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.091Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:54.091Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.091Z",
  "value": "id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.091Z",
  "value": "id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.091Z",
  "value": "id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.167.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.091Z",
  "value": "id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD"
}

