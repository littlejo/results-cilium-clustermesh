xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 579
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 553
cilium_host(7) clsact/egress cil_from_host-cilium_host id 555
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 502
lxccd255905d36d(12) clsact/ingress cil_from_container-lxccd255905d36d id 530
lxc9676816defdb(14) clsact/ingress cil_from_container-lxc9676816defdb id 518
lxc7c4b5bca0356(18) clsact/ingress cil_from_container-lxc7c4b5bca0356 id 626

flow_dissector:

netfilter:

