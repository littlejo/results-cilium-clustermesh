IP ADDRESS         LOCAL ENDPOINT INFO
10.167.0.83:0      id=1785  sec_id=5518922 flags=0x0000 ifindex=14  mac=6E:78:51:A4:90:EC nodemac=1E:7B:C9:65:6C:CD   
10.167.0.168:0     id=3441  sec_id=4     flags=0x0000 ifindex=10  mac=76:7A:DD:19:8C:A3 nodemac=A6:65:F8:B8:9D:89     
172.31.204.157:0   (localhost)                                                                                        
10.167.0.236:0     (localhost)                                                                                        
10.167.0.209:0     id=2406  sec_id=5531044 flags=0x0000 ifindex=18  mac=2A:71:B0:86:E3:0E nodemac=BE:D1:3D:AB:68:4A   
172.31.214.172:0   (localhost)                                                                                        
10.167.0.60:0      id=657   sec_id=5518922 flags=0x0000 ifindex=12  mac=D6:68:33:19:F2:25 nodemac=D2:4F:1A:AE:F1:4F   
