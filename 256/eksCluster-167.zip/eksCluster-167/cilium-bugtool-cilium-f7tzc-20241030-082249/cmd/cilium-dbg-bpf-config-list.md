KEY             VALUE
AgentLiveness   1847436604032
UTimeOffset     3379442878906250
