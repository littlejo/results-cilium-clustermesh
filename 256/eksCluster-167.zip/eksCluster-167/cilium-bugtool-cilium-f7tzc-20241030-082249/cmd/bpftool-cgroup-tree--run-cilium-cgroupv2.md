CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2e2c6b6_c76e_4c36_b156_64d98cf230ec.slice/cri-containerd-a84c4fd68c275762ba84ae7e55aff84216808f58ada925bbcd71eb83d436ddbb.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode2e2c6b6_c76e_4c36_b156_64d98cf230ec.slice/cri-containerd-f886b7681a100b93d834d8c02eda451d4e626eda3d49460b96d19d7710da0a2c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fea061b_cb72_4738_a2ca_8885adef7112.slice/cri-containerd-1bc78de1bdda28bd07317612d87be5cdcd49dc3a7ee294b0942875136d6d345b.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fea061b_cb72_4738_a2ca_8885adef7112.slice/cri-containerd-6a735ddd161d4dffa0716ba7e64dd528750616234d1fb9166dfaf0df9dc8ff18.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0af41e80_4b4a_46b9_b939_0679af010292.slice/cri-containerd-dd5140db9e0a3e4471c79e580eac290e29ab0ae64c25f0b6d12011c1d0e15543.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0af41e80_4b4a_46b9_b939_0679af010292.slice/cri-containerd-4fe628970605aeb5638ffcc978c1913a1db80db06299e8fe07dbaa1f385dd127.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dc49bfa_7300_4b12_b7ef_32ed23e5219b.slice/cri-containerd-652de113328e97f37f94a2eb2e8154c8ab6a60edb0893baaa1180944c643e7e2.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9dc49bfa_7300_4b12_b7ef_32ed23e5219b.slice/cri-containerd-40f8e2eeb634cef844726b167aa7de8a0f46304bbb1f1cc0a9eca5860ac90702.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-3bd1e6d936dd91fc6605cac5a9c1bdc0713e4cef70c5139991b7305b7c296a28.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-d56624bab26785427decf14dab1bce9e3904c514a871a5a3eff40b73f630b719.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-dea361dd155edbdf1f19d867b8cda039b72f754810a0dcf256c6b091a26999ce.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc8765229_52af_4a42_bdce_e8c43f5274a0.slice/cri-containerd-c40e2f4a54426d70d8939d11e940d5fcae4d14c62f9ff709e0a7e0991fb628bb.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9264851b_9486_4eee_ae1a_26b6cae31215.slice/cri-containerd-20cafb391061e9350fb3ac76d1393555608bbaac40af23284517998e565ef984.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9264851b_9486_4eee_ae1a_26b6cae31215.slice/cri-containerd-a4b4bec433f8a05c41d1348d18193f90a70e021daa0e782a3ae5205a8bc3da89.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ba1887a_a32d_40db_9d84_58c94f430160.slice/cri-containerd-01befee31e71088c564ecf0b74db4dd8ad8e7aacec1418bf193d1cedbda5da52.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ba1887a_a32d_40db_9d84_58c94f430160.slice/cri-containerd-5c28eabf0ecb3b910d31835fd6da466f97af7f783cbed0d7eed3f8c5050301f0.scope
    107      cgroup_device   multi                                          
