alloc: 158.86MB (166580584 bytes)
total-alloc: 2.29GB (2462083048 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 64206589
frees: 62451517
heap-alloc: 158.86MB (166580584 bytes)
heap-sys: 247.23MB (259235840 bytes)
heap-idle: 63.54MB (66625536 bytes)
heap-in-use: 183.69MB (192610304 bytes)
heap-released: 3.50MB (3670016 bytes)
heap-objects: 1755072
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.14MB (3290720 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 986.10KB (1009769 bytes)
gc-sys: 6.01MB (6303232 bytes)
next-gc: when heap-alloc >= 211.77MB (222058680 bytes)
last-gc: 2024-10-30 08:22:56.446972248 +0000 UTC
gc-pause-total: 8.2815ms
gc-pause: 74266
gc-pause-end: 1730276576446972248
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005684661484006944
enable-gc: true
debug-gc: false
