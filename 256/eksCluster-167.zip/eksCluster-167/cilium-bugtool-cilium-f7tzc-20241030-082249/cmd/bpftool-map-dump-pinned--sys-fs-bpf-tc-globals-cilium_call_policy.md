key: 91 02 00 00  value: 1f 02 00 00
key: f9 06 00 00  value: 09 02 00 00
key: 66 09 00 00  value: 75 02 00 00
key: 71 0d 00 00  value: 01 02 00 00
Found 4 elements
