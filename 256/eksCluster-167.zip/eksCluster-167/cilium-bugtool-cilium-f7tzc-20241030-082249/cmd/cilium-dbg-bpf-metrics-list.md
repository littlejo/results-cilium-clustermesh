REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37558     2982124     677    bpf_overlay.c
Interface                 INGRESS     654934    132863023   1132   bpf_host.c
Success                   EGRESS      17608     1392462     1694   bpf_host.c
Success                   EGRESS      278044    34631032    1308   bpf_lxc.c
Success                   EGRESS      38579     3055270     53     encap.h
Success                   INGRESS     322492    36277160    86     l3.h
Success                   INGRESS     343093    37910868    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
