ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.232.46:443 (active)     
                                         2 => 172.31.158.104:443 (active)    
2    10.100.47.20:443     ClusterIP      1 => 172.31.214.172:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.167.0.83:53 (active)        
                                         2 => 10.167.0.60:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.167.0.83:9153 (active)      
                                         2 => 10.167.0.60:9153 (active)      
5    10.100.68.148:2379   ClusterIP      1 => 10.167.0.209:2379 (active)     
