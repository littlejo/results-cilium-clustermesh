Endpoint ID: 329
Path: /sys/fs/bpf/tc/globals/cilium_policy_00329

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 657
Path: /sys/fs/bpf/tc/globals/cilium_policy_00657

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115397   1323      0        
Allow    Egress      0          ANY          NONE         disabled    16057    172       0        


Endpoint ID: 1785
Path: /sys/fs/bpf/tc/globals/cilium_policy_01785

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115463   1324      0        
Allow    Egress      0          ANY          NONE         disabled    16899    183       0        


Endpoint ID: 2406
Path: /sys/fs/bpf/tc/globals/cilium_policy_02406

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11579976   115879    0        
Allow    Ingress     1          ANY          NONE         disabled    10772585   113949    0        
Allow    Egress      0          ANY          NONE         disabled    13396284   131727    0        


Endpoint ID: 3441
Path: /sys/fs/bpf/tc/globals/cilium_policy_03441

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1638405   20661     0        
Allow    Ingress     1          ANY          NONE         disabled    18170     213       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


