goroutines: 10817
OS threads: 18
GOMAXPROCS: 2
num CPU: 2
