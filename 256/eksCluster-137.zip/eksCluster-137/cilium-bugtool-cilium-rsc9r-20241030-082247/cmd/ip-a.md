1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:24:10:9b:97:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.240.43/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3434sec preferred_lft 3434sec
    inet6 fe80::824:10ff:fe9b:9759/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:7e:bf:58:54:37 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.61/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::87e:bfff:fe58:5437/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:8c:ac:93:1a:91 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::188c:acff:fe93:1a91/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:0a:a1:f0:e0:67 brd ff:ff:ff:ff:ff:ff
    inet 10.137.0.244/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::100a:a1ff:fef0:e067/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c6:eb:39:c1:24:5a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c4eb:39ff:fec1:245a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:3a:b8:ce:66:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d43a:b8ff:fece:66c7/64 scope link 
       valid_lft forever preferred_lft forever
12: lxccb0e3e0c22fc@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:81:72:e4:16:0c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8881:72ff:fee4:160c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0e6cb5cb88e1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:54:94:da:e2:73 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7c54:94ff:feda:e273/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce3732ebeded8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:0d:97:b9:1a:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c40d:97ff:feb9:1ad1/64 scope link 
       valid_lft forever preferred_lft forever
