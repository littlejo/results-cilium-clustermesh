[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d4f60a3_e1dc_45f0_803b_679b2734df28.slice/cri-containerd-57d5622d95d972dcc28538029cdb90fda0b20d71f2fb2b144aebd288cbf24954.scope"
      }
    ],
    "ips": [
      "10.137.0.183"
    ],
    "name": "coredns-cc6ccd49c-bw5pm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-f901ab89e7cc5285be99bf7ae834b2e34311a47a2ac9a1938ec15b599507d839.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-15ebd19ab2daf9f3b07ea0c1322a372715850a14fee79cc6921734106cb04060.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-70d0e1b628bccfc8d0e77b2cee812046f7890ef42835182c67d693dedcebac00.scope"
      }
    ],
    "ips": [
      "10.137.0.242"
    ],
    "name": "clustermesh-apiserver-564dbfcf85-pkmnf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19efa4e_325f_454c_a807_df188795ab70.slice/cri-containerd-42b57e47e0fb56e0424e19ad1f1215aa42f40b8773aee0d133fd1aa962737d57.scope"
      }
    ],
    "ips": [
      "10.137.0.184"
    ],
    "name": "coredns-cc6ccd49c-xd5ck",
    "namespace": "kube-system"
  }
]

