ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.250.26:443 (active)    
                                         2 => 172.31.190.47:443 (active)    
2    10.100.245.138:443   ClusterIP      1 => 172.31.240.43:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.137.0.184:53 (active)      
                                         2 => 10.137.0.183:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.137.0.184:9153 (active)    
                                         2 => 10.137.0.183:9153 (active)    
5    10.100.166.27:2379   ClusterIP      1 => 10.137.0.242:2379 (active)    
