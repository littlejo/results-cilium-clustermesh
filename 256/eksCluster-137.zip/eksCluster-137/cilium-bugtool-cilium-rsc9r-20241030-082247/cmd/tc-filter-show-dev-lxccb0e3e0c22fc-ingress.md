filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccb0e3e0c22fc direct-action not_in_hw id 523 tag e43e6a86d8f2bf8f jited 
