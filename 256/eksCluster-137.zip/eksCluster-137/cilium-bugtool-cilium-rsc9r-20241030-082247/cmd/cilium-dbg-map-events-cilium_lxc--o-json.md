{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:04.677Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.240.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:04.677Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:04.677Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.259Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.286Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.333Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.412Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.487Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.222Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.223Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.225Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.258Z",
  "value": "id=1096  sec_id=4524347 flags=0x0000 ifindex=16  mac=7A:6B:ED:6F:76:72 nodemac=42:80:5A:14:6E:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.223Z",
  "value": "id=1096  sec_id=4524347 flags=0x0000 ifindex=16  mac=7A:6B:ED:6F:76:72 nodemac=42:80:5A:14:6E:6F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.223Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.223Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.223Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.303Z",
  "value": "id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.137.0.151:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.694Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.973Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.974Z",
  "value": "id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.974Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:28.975Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.003Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.007Z",
  "value": "id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.009Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.009Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.998Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.999Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.999Z",
  "value": "id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.999Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.999Z",
  "value": "id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.999Z",
  "value": "id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.000Z",
  "value": "id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.137.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.000Z",
  "value": "id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7"
}

