 08:22:49 up 32 min,  0 users,  load average: 0.15, 0.16, 0.12
