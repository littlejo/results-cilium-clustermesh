Endpoint ID: 77
Path: /sys/fs/bpf/tc/globals/cilium_policy_00077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 470
Path: /sys/fs/bpf/tc/globals/cilium_policy_00470

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131809   1507      0        
Allow    Egress      0          ANY          NONE         disabled    18499    203       0        


Endpoint ID: 808
Path: /sys/fs/bpf/tc/globals/cilium_policy_00808

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11513351   115353    0        
Allow    Ingress     1          ANY          NONE         disabled    10121922   106368    0        
Allow    Egress      0          ANY          NONE         disabled    13780817   135114    0        


Endpoint ID: 2093
Path: /sys/fs/bpf/tc/globals/cilium_policy_02093

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649283   20837     0        
Allow    Ingress     1          ANY          NONE         disabled    20538     240       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2294
Path: /sys/fs/bpf/tc/globals/cilium_policy_02294

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131083   1496      0        
Allow    Egress      0          ANY          NONE         disabled    16788    183       0        


