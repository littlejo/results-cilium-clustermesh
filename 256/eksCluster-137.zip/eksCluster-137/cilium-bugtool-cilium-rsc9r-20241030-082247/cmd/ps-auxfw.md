USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         702  0.0  0.1 1616008 8408 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         678  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         665  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         661  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         660  0.0  0.2 1240432 16252 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         710  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         650  0.0  0.0 1228744 3604 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         640  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.8  4.7 1606080 380180 ?      Ssl  07:59   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         406  0.0  0.0 1229744 7272 ?        Sl   08:00   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
