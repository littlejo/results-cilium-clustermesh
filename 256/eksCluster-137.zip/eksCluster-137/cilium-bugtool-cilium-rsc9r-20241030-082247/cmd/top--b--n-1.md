top - 08:22:49 up 32 min,  0 users,  load average: 0.15, 0.16, 0.12
Tasks:  12 total,   2 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 36.7 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 13.3 si,  0.0 st
MiB Mem :   7814.2 total,   4483.7 free,   1183.6 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    718 root      20   0 1244340  22192  14720 S  53.3   0.3   0:00.10 hubble
      1 root      20   0 1606080 380180  78436 S   6.7   4.8   0:52.66 cilium-+
    406 root      20   0 1229744   7272   3052 S   0.0   0.1   0:01.14 cilium-+
    640 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    650 root      20   0 1228744   3604   2912 S   0.0   0.0   0:00.00 gops
    660 root      20   0 1240432  16488  11292 S   0.0   0.2   0:00.02 cilium-+
    661 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    665 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    702 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    728 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    735 root      20   0    3852   1288   1136 R   0.0   0.0   0:00.00 bash
