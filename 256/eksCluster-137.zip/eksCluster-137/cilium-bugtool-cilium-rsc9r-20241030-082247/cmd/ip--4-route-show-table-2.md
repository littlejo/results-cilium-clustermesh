default via 172.31.192.1 dev ens6 
172.31.192.1 dev ens6 scope link 
