REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36569     2895720     677    bpf_overlay.c
Interface                 INGRESS     650358    132966454   1132   bpf_host.c
Success                   EGRESS      16427     1293997     1694   bpf_host.c
Success                   EGRESS      276245    34219112    1308   bpf_lxc.c
Success                   EGRESS      36837     2914342     53     encap.h
Success                   INGRESS     316810    35972372    86     l3.h
Success                   INGRESS     337603    37618141    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
