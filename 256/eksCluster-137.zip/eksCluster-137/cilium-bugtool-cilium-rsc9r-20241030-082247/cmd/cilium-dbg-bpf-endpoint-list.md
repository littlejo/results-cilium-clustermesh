IP ADDRESS        LOCAL ENDPOINT INFO
10.137.0.184:0    id=470   sec_id=4523032 flags=0x0000 ifindex=12  mac=E6:5E:FA:0E:32:59 nodemac=8A:81:72:E4:16:0C   
172.31.244.61:0   (localhost)                                                                                        
172.31.240.43:0   (localhost)                                                                                        
10.137.0.183:0    id=2294  sec_id=4523032 flags=0x0000 ifindex=14  mac=3E:04:3A:9B:B9:77 nodemac=7E:54:94:DA:E2:73   
10.137.0.204:0    id=2093  sec_id=4     flags=0x0000 ifindex=10  mac=DE:9A:18:69:52:31 nodemac=D6:3A:B8:CE:66:C7     
10.137.0.242:0    id=808   sec_id=4524347 flags=0x0000 ifindex=18  mac=9A:E6:78:81:AD:45 nodemac=C6:0D:97:B9:1A:D1   
10.137.0.244:0    (localhost)                                                                                        
