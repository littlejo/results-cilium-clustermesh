Total: 691
TCP:   1857 (estab 445, closed 1393, orphaned 0, timewait 548)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  464       451       13       
INET	  474       457       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.240.43%ens5:68         0.0.0.0:*    uid:192 ino:74170 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:37000 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15056 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:34469      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36331 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36999 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15057 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::824:10ff:fe9b:9759]%ens5:546           [::]:*    uid:192 ino:15295 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
