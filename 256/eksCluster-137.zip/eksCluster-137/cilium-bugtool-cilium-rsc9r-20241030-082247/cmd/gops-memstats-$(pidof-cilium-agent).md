alloc: 108.10MB (113355000 bytes)
total-alloc: 2.28GB (2443122712 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63892858
frees: 63203205
heap-alloc: 108.10MB (113355000 bytes)
heap-sys: 252.23MB (264478720 bytes)
heap-idle: 77.51MB (81272832 bytes)
heap-in-use: 174.72MB (183205888 bytes)
heap-released: 3.24MB (3399680 bytes)
heap-objects: 689653
stack-in-use: 59.75MB (62652416 bytes)
stack-sys: 59.75MB (62652416 bytes)
stack-mspan-inuse: 2.88MB (3015200 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 962.27KB (985369 bytes)
gc-sys: 6.02MB (6315616 bytes)
next-gc: when heap-alloc >= 233.42MB (244763608 bytes)
last-gc: 2024-10-30 08:23:19.508877308 +0000 UTC
gc-pause-total: 11.412476ms
gc-pause: 259081
gc-pause-end: 1730276599508877308
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0005605270522496993
enable-gc: true
debug-gc: false
