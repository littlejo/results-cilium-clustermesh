key: d6 01 00 00  value: 13 02 00 00
key: 28 03 00 00  value: 78 02 00 00
key: 2d 08 00 00  value: 08 02 00 00
key: f6 08 00 00  value: 23 02 00 00
Found 4 elements
