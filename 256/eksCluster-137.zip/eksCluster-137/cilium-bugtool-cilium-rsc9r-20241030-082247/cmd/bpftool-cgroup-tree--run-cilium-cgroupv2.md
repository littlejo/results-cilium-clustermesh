CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc850f179_cb1c_46fb_ab0d_5df4ae1390ee.slice/cri-containerd-54f39c005832c8809fc239143b8d93a74e8ae1f1190844db13b384879b99fa4a.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc850f179_cb1c_46fb_ab0d_5df4ae1390ee.slice/cri-containerd-53d9086d9f320acbed061a182bd96f8326af220dc0b02a8a1643b7080a1aff62.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19efa4e_325f_454c_a807_df188795ab70.slice/cri-containerd-d404ea79d533c15e5d7804dd9b59966817b50caf22afd963743feda2abe4c01a.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd19efa4e_325f_454c_a807_df188795ab70.slice/cri-containerd-42b57e47e0fb56e0424e19ad1f1215aa42f40b8773aee0d133fd1aa962737d57.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd675e59a_a2d1_4435_8fc3_897872382bb1.slice/cri-containerd-d29096973ce4665e3cbe54acb8fd2479e76038ba5f539163f31414901912ef04.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd675e59a_a2d1_4435_8fc3_897872382bb1.slice/cri-containerd-0fd737a1e1e980757c6ceda2c9899686ea1896ca61e7dd12a397891e84d39d79.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d4f60a3_e1dc_45f0_803b_679b2734df28.slice/cri-containerd-57d5622d95d972dcc28538029cdb90fda0b20d71f2fb2b144aebd288cbf24954.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d4f60a3_e1dc_45f0_803b_679b2734df28.slice/cri-containerd-89a430271a2015417f9f9dd15666eebb2ee5fcfccfe70f1919606df45d8d5015.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-15ebd19ab2daf9f3b07ea0c1322a372715850a14fee79cc6921734106cb04060.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-f901ab89e7cc5285be99bf7ae834b2e34311a47a2ac9a1938ec15b599507d839.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-e4581551c02efb702054d375d2698c6aef3c8cd8ac7174485f6eabf37d9fe8fa.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb8006aaa_9eaf_4b35_b388_f7f9ddc4a07a.slice/cri-containerd-70d0e1b628bccfc8d0e77b2cee812046f7890ef42835182c67d693dedcebac00.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ba1173c_6dcb_4948_8c24_79593c8db04a.slice/cri-containerd-3de2eeda875dd2495292df657ce9a7f21cf9524a8270b8445d07829cb0122d4e.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ba1173c_6dcb_4948_8c24_79593c8db04a.slice/cri-containerd-a801552da65de5abd690f788807fcc26ef6bd3be88b8d9b3338191206e4cd279.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod310c62bb_48d9_4d8c_a7d0_a01bdb6a142f.slice/cri-containerd-9b373620869dbb93318bb9d136e0cbb11cbf2c092f2b4daee17c57a814a36c17.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod310c62bb_48d9_4d8c_a7d0_a01bdb6a142f.slice/cri-containerd-fda4aea440c3a3c8672d1325db84400d79d6cbfcb18f1c3ad21ef50f646d1474.scope
    101      cgroup_device   multi                                          
