35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:46:43+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:44+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:46:48+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:46:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:46:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:46:58+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name tail_handle_ipv4  tag 02fdd2158f2c9998  gpl
	loaded_at 2024-10-30T07:53:20+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
485: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:53:20+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
486: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:53:20+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
487: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:53:20+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
517: sched_cls  name tail_ipv4_ct_ingress  tag a131bef3f833dada  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 162
518: sched_cls  name tail_handle_arp  tag 79a44c73652f6604  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 165
519: sched_cls  name tail_handle_ipv4_cont  tag 74471d292fc11feb  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 166
525: sched_cls  name tail_handle_ipv4  tag 2062ca7a73aeedb5  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 167
526: sched_cls  name cil_from_container  tag 8f8907598cad9f69  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 173
527: sched_cls  name __send_drop_notify  tag ec041a3b0ef19f73  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 174
531: sched_cls  name tail_ipv4_to_endpoint  tag 774e5b526f094df5  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 176
533: sched_cls  name handle_policy  tag b084d023836ad4f2  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 179
536: sched_cls  name __send_drop_notify  tag aa80250bc8f244f8  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 184
537: sched_cls  name tail_ipv4_ct_egress  tag a7bfaed06a6eaafd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 181
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 186
539: sched_cls  name tail_handle_ipv4  tag 438ccf1d6e9b782e  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 185
540: sched_cls  name tail_ipv4_ct_egress  tag a7bfaed06a6eaafd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 188
542: sched_cls  name tail_ipv4_to_endpoint  tag f7d9f6d06ca5468e  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 189
543: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 191
544: sched_cls  name cil_from_container  tag 4bcc5018c8ea1406  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 192
546: sched_cls  name tail_handle_ipv4_from_host  tag fda5f226c1f9fb7f  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 194
547: sched_cls  name __send_drop_notify  tag 822d79b4260008b6  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 196
548: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 197
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 198
552: sched_cls  name tail_handle_ipv4_from_host  tag fda5f226c1f9fb7f  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 202
553: sched_cls  name handle_policy  tag 9db380b843ba3c44  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 195
554: sched_cls  name __send_drop_notify  tag 822d79b4260008b6  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
555: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 205
556: sched_cls  name tail_handle_arp  tag 70ccd1ac6dc4782b  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 204
557: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 207
560: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 211
562: sched_cls  name tail_handle_ipv4_from_host  tag fda5f226c1f9fb7f  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 213
563: sched_cls  name __send_drop_notify  tag 822d79b4260008b6  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
565: sched_cls  name tail_ipv4_ct_ingress  tag a6c9b0d23b3c6a4d  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 206
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 216
568: sched_cls  name __send_drop_notify  tag 822d79b4260008b6  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 220
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 222
572: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 224
573: sched_cls  name tail_handle_ipv4_cont  tag 28ef4681b4c45457  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 218
575: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 226
576: sched_cls  name tail_handle_ipv4_from_host  tag fda5f226c1f9fb7f  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 227
577: sched_cls  name tail_ipv4_ct_ingress  tag b1d8f3791e75db18  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 229
578: sched_cls  name __send_drop_notify  tag 7c6762ee3a8b1dcc  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
579: sched_cls  name tail_handle_ipv4  tag de67e8d2c1b109e8  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,126
	btf_id 231
580: sched_cls  name tail_handle_ipv4_cont  tag 8095cce85e48ae6b  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,125,41,100,82,83,39,76,74,77,126,40,37,38,81
	btf_id 232
581: sched_cls  name handle_policy  tag 9216091ae8bd54b9  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,126,82,83,125,41,80,100,39,84,75,40,37,38
	btf_id 233
582: sched_cls  name tail_handle_arp  tag 9946152651904f9e  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,126
	btf_id 234
583: sched_cls  name tail_ipv4_to_endpoint  tag 6db092776c788eac  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,125,41,82,83,80,100,39,126,40,37,38
	btf_id 235
585: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,126
	btf_id 237
586: sched_cls  name cil_from_container  tag a060fbd58a2c82f5  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 126,76
	btf_id 238
587: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,126,82,83,125,84
	btf_id 239
588: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
591: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
592: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
595: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
596: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
599: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
600: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
603: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:23+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: sched_cls  name tail_handle_ipv4_cont  tag 31759d7bdf9022df  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 253
645: sched_cls  name tail_handle_ipv4  tag 49c86d5b0d1400f2  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 255
646: sched_cls  name cil_from_container  tag 986b438bc7efbfbf  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 256
647: sched_cls  name handle_policy  tag e4ac6d5b327e05b9  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 257
648: sched_cls  name tail_ipv4_ct_egress  tag 7141c5cb30853c3c  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 258
649: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 259
650: sched_cls  name tail_handle_arp  tag f8ffeabff4c896fb  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 260
651: sched_cls  name tail_ipv4_to_endpoint  tag 6f5bed6e94144b60  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 261
652: sched_cls  name __send_drop_notify  tag e0b28e7795df42c4  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 262
653: sched_cls  name tail_ipv4_ct_ingress  tag c9222e9275bfa8b4  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 263
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
670: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
673: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
674: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
677: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
678: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
681: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
