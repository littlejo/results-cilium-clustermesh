Endpoint ID: 173
Path: /sys/fs/bpf/tc/globals/cilium_policy_00173

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171861   1972      0        
Allow    Egress      0          ANY          NONE         disabled    21451    240       0        


Endpoint ID: 737
Path: /sys/fs/bpf/tc/globals/cilium_policy_00737

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11298249   110867    0        
Allow    Ingress     1          ANY          NONE         disabled    9242471    96596     0        
Allow    Egress      0          ANY          NONE         disabled    11166528   110795    0        


Endpoint ID: 811
Path: /sys/fs/bpf/tc/globals/cilium_policy_00811

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172389   1980      0        
Allow    Egress      0          ANY          NONE         disabled    21087    235       0        


Endpoint ID: 1221
Path: /sys/fs/bpf/tc/globals/cilium_policy_01221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631718   20610     0        
Allow    Ingress     1          ANY          NONE         disabled    25698     300       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3834
Path: /sys/fs/bpf/tc/globals/cilium_policy_03834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


