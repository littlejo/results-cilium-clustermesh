ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.138.68:443 (active)    
                                         2 => 172.31.194.103:443 (active)   
2    10.100.163.143:443   ClusterIP      1 => 172.31.144.15:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.10.0.188:53 (active)       
                                         2 => 10.10.0.112:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.10.0.188:9153 (active)     
                                         2 => 10.10.0.112:9153 (active)     
5    10.100.75.19:2379    ClusterIP      1 => 10.10.0.44:2379 (active)      
