key: 08 00 00 00  value: 0a 0a 00 70 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 0a 00 bc 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 90 0f 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 0a 00 2c 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 0a 00 70 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 8a 44 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 0a 00 bc 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f c2 67 01 bb 00 00  00 00 00 00
Found 8 elements
