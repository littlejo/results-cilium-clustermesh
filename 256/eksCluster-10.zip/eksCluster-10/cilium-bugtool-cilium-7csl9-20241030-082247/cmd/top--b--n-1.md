top - 08:22:48 up 36 min,  0 users,  load average: 0.11, 0.14, 0.09
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.7 us, 20.7 sy,  0.0 ni, 55.2 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4497.6 free,   1171.3 used,   2145.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6458.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 381860  78648 S   6.2   4.8   0:53.04 cilium-+
    668 root      20   0 1240432  16056  11100 S   6.2   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   8112   3836 S   0.0   0.1   0:01.17 cilium-+
    641 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    700 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    719 root      20   0 1228744   3976   3328 S   0.0   0.0   0:00.00 gops
