1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b6:b6:a0:2b:03 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.144.15/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3243sec preferred_lft 3243sec
    inet6 fe80::4b6:b6ff:fea0:2b03/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:74:d5:a5:ca:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.139.111/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::474:d5ff:fea5:ca53/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:d5:35:4d:35:84 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70d5:35ff:fe4d:3584/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:29:ad:79:14:b6 brd ff:ff:ff:ff:ff:ff
    inet 10.10.0.241/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cc29:adff:fe79:14b6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 4a:b0:46:a4:b0:04 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::48b0:46ff:fea4:b004/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:eb:9a:e2:78:dc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::98eb:9aff:fee2:78dc/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc69f03fcf7969@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:e2:3d:1e:b0:58 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::80e2:3dff:fe1e:b058/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6e0242d840d7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:ad:00:a2:48:c8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ecad:ff:fea2:48c8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxccd7964a3fe20@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:20:71:af:d1:69 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6c20:71ff:feaf:d169/64 scope link 
       valid_lft forever preferred_lft forever
