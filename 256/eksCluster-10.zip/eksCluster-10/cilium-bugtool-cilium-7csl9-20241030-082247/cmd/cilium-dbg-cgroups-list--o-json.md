[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57da0dde_9124_4fbd_9c1b_d7b8675f1d5e.slice/cri-containerd-f17b1eb52c9d03177f4f3b270aa8175da24d6ca148591c1a9e2928d5f1983391.scope"
      }
    ],
    "ips": [
      "10.10.0.188"
    ],
    "name": "coredns-cc6ccd49c-m5gc6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-890e87fe6de7b35fba0e3dd9d3c67489fc7e88d09004b426a95e06f807428272.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-c04f2fc2cf85a75ab1c61f3e03bf9e786f28a800eff3a27aff48aef13b84b2be.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-79f894cd14e134093aa470d7a55b1758e2c422bc907582294f5f5a7dfc2e3caa.scope"
      }
    ],
    "ips": [
      "10.10.0.44"
    ],
    "name": "clustermesh-apiserver-956d58469-tcrcc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce58b73_d036_4a0f_88b0_c0cb2edc18de.slice/cri-containerd-92d60cdd42cd73376af706f633665805753b10b3c2144cf5e8981ad31780de61.scope"
      }
    ],
    "ips": [
      "10.10.0.112"
    ],
    "name": "coredns-cc6ccd49c-hcc6l",
    "namespace": "kube-system"
  }
]

