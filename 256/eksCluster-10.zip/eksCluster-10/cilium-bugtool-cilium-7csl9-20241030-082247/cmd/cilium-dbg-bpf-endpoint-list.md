IP ADDRESS         LOCAL ENDPOINT INFO
172.31.139.111:0   (localhost)                                                                                       
10.10.0.44:0       id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69   
10.10.0.188:0      id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8   
10.10.0.241:0      (localhost)                                                                                       
172.31.144.15:0    (localhost)                                                                                       
10.10.0.112:0      id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58   
10.10.0.230:0      id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC    
