KEY             VALUE
AgentLiveness   2198976704039
UTimeOffset     3379442189453125
