{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:18.419Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.139.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:18.419Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:18.419Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:23.277Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:23.282Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:23.319Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:23.365Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:53.782Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:53.783Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:53.783Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:53.811Z",
  "value": "id=3603  sec_id=365614 flags=0x0000 ifindex=16  mac=8A:FA:F3:36:57:AF nodemac=96:52:C8:92:82:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:53.811Z",
  "value": "id=3603  sec_id=365614 flags=0x0000 ifindex=16  mac=8A:FA:F3:36:57:AF nodemac=96:52:C8:92:82:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:54.782Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:54.783Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:54.783Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:54.783Z",
  "value": "id=3603  sec_id=365614 flags=0x0000 ifindex=16  mac=8A:FA:F3:36:57:AF nodemac=96:52:C8:92:82:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.949Z",
  "value": "id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.10.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.489Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.627Z",
  "value": "id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.628Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.629Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.629Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.640Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.640Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.641Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.641Z",
  "value": "id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.626Z",
  "value": "id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.627Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.627Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.627Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.627Z",
  "value": "id=1221  sec_id=4     flags=0x0000 ifindex=10  mac=BE:A7:18:E2:85:0F nodemac=9A:EB:9A:E2:78:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.627Z",
  "value": "id=737   sec_id=365614 flags=0x0000 ifindex=18  mac=86:FF:8A:F2:7D:3F nodemac=6E:20:71:AF:D1:69"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.628Z",
  "value": "id=811   sec_id=390955 flags=0x0000 ifindex=12  mac=7A:88:CF:8D:E7:01 nodemac=82:E2:3D:1E:B0:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.10.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.628Z",
  "value": "id=173   sec_id=390955 flags=0x0000 ifindex=14  mac=7E:50:55:23:64:1D nodemac=EE:AD:00:A2:48:C8"
}

