CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57da0dde_9124_4fbd_9c1b_d7b8675f1d5e.slice/cri-containerd-f17b1eb52c9d03177f4f3b270aa8175da24d6ca148591c1a9e2928d5f1983391.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod57da0dde_9124_4fbd_9c1b_d7b8675f1d5e.slice/cri-containerd-3c809157b39e303721019c0d9a19d311e87536f27b82dfaef69e0d1c46c11ab6.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce58b73_d036_4a0f_88b0_c0cb2edc18de.slice/cri-containerd-92d60cdd42cd73376af706f633665805753b10b3c2144cf5e8981ad31780de61.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbce58b73_d036_4a0f_88b0_c0cb2edc18de.slice/cri-containerd-a980729a283d6b7cdd6684079358e8e1e015144451d8f39f32b8c88f9d568483.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod06aa42c9_7a5f_43f3_8b2e_a1b10bbd63ab.slice/cri-containerd-bb8a8971baf9ed2c5a69d101adce7d839c7563808555a4480d1b84b3bca321ed.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod06aa42c9_7a5f_43f3_8b2e_a1b10bbd63ab.slice/cri-containerd-ae32aedf81b65c96a1df1521e4181351beb72f52e5dcecd388695734a1b9c199.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c217086_d9fa_4aee_98fa_0f96e4616bc3.slice/cri-containerd-9da09053a68afeededd2ce59ddb1b3af2184d6b972ad823d7f4a45dbfb42782b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c217086_d9fa_4aee_98fa_0f96e4616bc3.slice/cri-containerd-8e51f6b0fa9bee4ad3bacff1db9daf19a693142cbdbff90156f3e5c70154198d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e74ef67_124f_4e11_93e3_e102fb2268cf.slice/cri-containerd-fadf1c5536d55dd1232a346987eb0fa0f175c476a0bc623a4dc41277da8ff529.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5e74ef67_124f_4e11_93e3_e102fb2268cf.slice/cri-containerd-1d9ad5433c7619942e15fa1e4a1de6e4fd093cf609957655e7c80098bfc1dd88.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f965880_6999_429b_8e0b_2b600e1826cb.slice/cri-containerd-40e004f80936ae6bce6cf518e563a57efc183396bec6fd91d8295b80b1231cbd.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1f965880_6999_429b_8e0b_2b600e1826cb.slice/cri-containerd-3b22ac7fbfad91846400ac47b46ceab62ef89c5053de3f090c722ddab8293a81.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-890e87fe6de7b35fba0e3dd9d3c67489fc7e88d09004b426a95e06f807428272.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-c04f2fc2cf85a75ab1c61f3e03bf9e786f28a800eff3a27aff48aef13b84b2be.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-12b20596d7d07a0a9020c20e261ded021cb57cd8bf5c0eca3a8435ed0fff35b1.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74f2b9d6_7da5_49f1_ae37_d9019b303c69.slice/cri-containerd-79f894cd14e134093aa470d7a55b1758e2c422bc907582294f5f5a7dfc2e3caa.scope
    681      cgroup_device   multi                                          
