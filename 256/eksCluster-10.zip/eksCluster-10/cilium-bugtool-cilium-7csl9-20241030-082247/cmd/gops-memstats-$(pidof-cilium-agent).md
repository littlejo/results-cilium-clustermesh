alloc: 172.45MB (180828816 bytes)
total-alloc: 2.21GB (2376025312 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 62644211
frees: 60851587
heap-alloc: 172.45MB (180828816 bytes)
heap-sys: 247.51MB (259530752 bytes)
heap-idle: 45.13MB (47325184 bytes)
heap-in-use: 202.38MB (212205568 bytes)
heap-released: 3.37MB (3530752 bytes)
heap-objects: 1792624
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.21MB (3363200 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 942.75KB (965377 bytes)
gc-sys: 6.02MB (6311496 bytes)
next-gc: when heap-alloc >= 214.72MB (225151032 bytes)
last-gc: 2024-10-30 08:22:51.97190575 +0000 UTC
gc-pause-total: 14.056326ms
gc-pause: 120307
gc-pause-end: 1730276571971905750
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00035560102691815465
enable-gc: true
debug-gc: false
