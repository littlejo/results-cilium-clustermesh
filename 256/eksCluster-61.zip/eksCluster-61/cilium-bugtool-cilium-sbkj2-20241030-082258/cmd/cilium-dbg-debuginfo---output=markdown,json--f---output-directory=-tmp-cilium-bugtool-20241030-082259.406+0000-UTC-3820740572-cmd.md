markdown output at /tmp/cilium-bugtool-20241030-082259.406+0000-UTC-3820740572/cmd/cilium-debuginfo-20241030-082330.787+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.406+0000-UTC-3820740572/cmd/cilium-debuginfo-20241030-082330.787+0000-UTC.json
