{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.624Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.210.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.624Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.221.85:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.624Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.223Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.232Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.270Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.271Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.293Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.180Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.180Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.181Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.211Z",
  "value": "id=3018  sec_id=2038582 flags=0x0000 ifindex=16  mac=DA:11:69:35:D0:2E nodemac=F2:75:23:C9:A9:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.176Z",
  "value": "id=3018  sec_id=2038582 flags=0x0000 ifindex=16  mac=DA:11:69:35:D0:2E nodemac=F2:75:23:C9:A9:FB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.178Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.178Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.178Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.869Z",
  "value": "id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.61.0.116:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.204Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.154Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.157Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.158Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.158Z",
  "value": "id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.025Z",
  "value": "id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.027Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.028Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.028Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.004Z",
  "value": "id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.004Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.005Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.005Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.005Z",
  "value": "id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.234:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.005Z",
  "value": "id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.005Z",
  "value": "id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.61.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:58.006Z",
  "value": "id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD"
}

