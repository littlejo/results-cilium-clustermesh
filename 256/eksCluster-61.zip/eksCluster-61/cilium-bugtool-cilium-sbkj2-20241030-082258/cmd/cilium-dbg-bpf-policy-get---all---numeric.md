Endpoint ID: 253
Path: /sys/fs/bpf/tc/globals/cilium_policy_00253

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 677
Path: /sys/fs/bpf/tc/globals/cilium_policy_00677

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149581   1721      0        
Allow    Egress      0          ANY          NONE         disabled    19731    218       0        


Endpoint ID: 1076
Path: /sys/fs/bpf/tc/globals/cilium_policy_01076

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659772   20966     0        
Allow    Ingress     1          ANY          NONE         disabled    23230     274       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2870
Path: /sys/fs/bpf/tc/globals/cilium_policy_02870

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11535979   116431    0        
Allow    Ingress     1          ANY          NONE         disabled    11488225   121834    0        
Allow    Egress      0          ANY          NONE         disabled    15252428   148757    0        


Endpoint ID: 3648
Path: /sys/fs/bpf/tc/globals/cilium_policy_03648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149824   1720      0        
Allow    Egress      0          ANY          NONE         disabled    18714    206       0        


