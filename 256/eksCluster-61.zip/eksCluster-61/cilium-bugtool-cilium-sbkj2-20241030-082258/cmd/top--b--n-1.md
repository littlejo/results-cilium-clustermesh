top - 08:22:59 up 34 min,  0 users,  load average: 0.44, 0.26, 0.20
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 36.7 sy,  0.0 ni, 23.3 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4482.6 free,   1184.3 used,   2147.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6444.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606144 376460  78420 S   6.7   4.7   0:56.41 cilium-+
    660 root      20   0 1240432  16524  11356 S   6.7   0.2   0:00.03 cilium-+
    415 root      20   0 1229744   6828   2924 S   0.0   0.1   0:01.17 cilium-+
    633 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    692 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    696 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    715 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    726 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
    732 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
