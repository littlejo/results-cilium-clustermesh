key: a5 02 00 00  value: 08 02 00 00
key: 34 04 00 00  value: 25 02 00 00
key: 36 0b 00 00  value: 65 02 00 00
key: 40 0e 00 00  value: 14 02 00 00
Found 4 elements
