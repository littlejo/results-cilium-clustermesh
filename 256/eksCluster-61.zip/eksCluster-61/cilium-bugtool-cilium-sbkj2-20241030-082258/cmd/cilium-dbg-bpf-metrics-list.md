REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38004     3012614     677    bpf_overlay.c
Interface                 INGRESS     683543    137633349   1132   bpf_host.c
Success                   EGRESS      17719     1399158     1694   bpf_host.c
Success                   EGRESS      293633    36081355    1308   bpf_lxc.c
Success                   EGRESS      39170     3095049     53     encap.h
Success                   INGRESS     338106    38354189    86     l3.h
Success                   INGRESS     359042    40011691    235    trace.h
Unsupported L3 protocol   EGRESS      42        3132        1492   bpf_lxc.c
