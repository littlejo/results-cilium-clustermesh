USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         674  0.0  0.1 1616264 8816 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         660  0.0  0.2 1240432 16524 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         681  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         633  0.0  0.0 1229000 4048 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.6  4.7 1606144 376460 ?      Ssl  07:57   0:56 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.0 1229744 6828 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
