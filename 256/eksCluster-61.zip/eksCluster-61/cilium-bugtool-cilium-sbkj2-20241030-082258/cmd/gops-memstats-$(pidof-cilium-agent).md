alloc: 177.33MB (185946352 bytes)
total-alloc: 2.39GB (2565421152 bytes)
sys: 309.08MB (324096356 bytes)
lookups: 0
mallocs: 66010087
frees: 63991406
heap-alloc: 177.33MB (185946352 bytes)
heap-sys: 230.89MB (242106368 bytes)
heap-idle: 33.09MB (34701312 bytes)
heap-in-use: 197.80MB (207405056 bytes)
heap-released: 2.61MB (2736128 bytes)
heap-objects: 2018681
stack-in-use: 65.06MB (68222976 bytes)
stack-sys: 65.06MB (68222976 bytes)
stack-mspan-inuse: 3.35MB (3508160 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.25MB (1308849 bytes)
gc-sys: 6.11MB (6407800 bytes)
next-gc: when heap-alloc >= 213.84MB (224229000 bytes)
last-gc: 2024-10-30 08:23:02.614051198 +0000 UTC
gc-pause-total: 7.228067ms
gc-pause: 93532
gc-pause-end: 1730276582614051198
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004291170271820988
enable-gc: true
debug-gc: false
