CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod977e4352_a319_4597_bdb0_e168249ce9c2.slice/cri-containerd-efb00797b44886264c9821a74490a2f2f6dd8473e7839507679844c64f90518c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod977e4352_a319_4597_bdb0_e168249ce9c2.slice/cri-containerd-32ed8b0945c51e5ce4d3d580a86009ca0890840334662080f4fa55bba1f071cf.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35a707dd_f192_4a99_9e91_f59d85287072.slice/cri-containerd-37442e2d58660e9f413642a9841771ddbfd528cd8d205df280a8016817a0abc1.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35a707dd_f192_4a99_9e91_f59d85287072.slice/cri-containerd-3580a944b435c63ef75af65561fd73ea004fbfb0f538e355951959870304b96c.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bd29da6_49d1_4208_b32a_30fe3434217b.slice/cri-containerd-332dd2c71e003004d0921e7d6a306b8763b3c2df926d331f0f5731ab19cebbe6.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bd29da6_49d1_4208_b32a_30fe3434217b.slice/cri-containerd-3b399b96aada9603ad803986ec8c3a2ae68bb9e7f97de63cecffd0084789abf2.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc14b7f4_d455_4737_aaa8_c2e142dd8f6f.slice/cri-containerd-b3a73aac0ef66cb87dfbd11b2afa4f8e74576999a6f42c0482ae02c3e51d41ce.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc14b7f4_d455_4737_aaa8_c2e142dd8f6f.slice/cri-containerd-c843edbfa4d061b468324e18f9b8016e740b858137ea4dca813c0b269beed739.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b1544cd_b4ea_4a61_924c_87f0931b40a2.slice/cri-containerd-ca7ed008b76dc39bad28a86b19103433247d08da524766b5d99dcd567d673b9b.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3b1544cd_b4ea_4a61_924c_87f0931b40a2.slice/cri-containerd-6807320854ccec1b6d910753eac10201720ea2c991d4bcb8f45007a0e364bc8f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-f0086193959e8e66db77176b4605a3f6e1943c8b67bb26fe0c6095d8efd0f678.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-3600d21d29cb901a14b4a34331e91b10b6e2dafc72357f7490a3678e98d875ed.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-f71d62709a03370239c3a0dc68121a578c3645a1b31293eb1eaa51367768d535.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-8c6525aff0cbcf0ba03d849e042f5be48009c04678e014b295c436981d3cbe3f.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb917c82a_9676_40e4_aacd_de9411d518d2.slice/cri-containerd-8cdc227048e816d51a3551f6b311601310122fe039c9892d6e843cda683fc934.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb917c82a_9676_40e4_aacd_de9411d518d2.slice/cri-containerd-76398503fc7a4c4ec4c531a8d11600e08c8aaef1fdde0cc40d93486e67874ffe.scope
    99       cgroup_device   multi                                          
