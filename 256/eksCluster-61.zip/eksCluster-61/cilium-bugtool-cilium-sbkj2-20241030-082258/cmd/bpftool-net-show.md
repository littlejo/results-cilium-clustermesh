xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 496
ens6(5) clsact/ingress cil_from_netdev-ens6 id 507
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 483
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 551
lxceb8b3bc78958(12) clsact/ingress cil_from_container-lxceb8b3bc78958 id 529
lxcf9711703670d(14) clsact/ingress cil_from_container-lxcf9711703670d id 542
lxcdb61148b3bed(18) clsact/ingress cil_from_container-lxcdb61148b3bed id 609

flow_dissector:

netfilter:

