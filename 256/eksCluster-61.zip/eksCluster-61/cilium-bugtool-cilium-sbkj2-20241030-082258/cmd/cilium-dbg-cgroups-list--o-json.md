[
  {
    "containers": [
      {
        "cgroup-id": 7840,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc14b7f4_d455_4737_aaa8_c2e142dd8f6f.slice/cri-containerd-c843edbfa4d061b468324e18f9b8016e740b858137ea4dca813c0b269beed739.scope"
      }
    ],
    "ips": [
      "10.61.0.200"
    ],
    "name": "coredns-cc6ccd49c-srjh2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7756,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3bd29da6_49d1_4208_b32a_30fe3434217b.slice/cri-containerd-332dd2c71e003004d0921e7d6a306b8763b3c2df926d331f0f5731ab19cebbe6.scope"
      }
    ],
    "ips": [
      "10.61.0.18"
    ],
    "name": "coredns-cc6ccd49c-gcpnt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9316,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-f0086193959e8e66db77176b4605a3f6e1943c8b67bb26fe0c6095d8efd0f678.scope"
      },
      {
        "cgroup-id": 9232,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-3600d21d29cb901a14b4a34331e91b10b6e2dafc72357f7490a3678e98d875ed.scope"
      },
      {
        "cgroup-id": 9400,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod653562ed_3d5f_46a6_9fac_a2736ff25e0d.slice/cri-containerd-f71d62709a03370239c3a0dc68121a578c3645a1b31293eb1eaa51367768d535.scope"
      }
    ],
    "ips": [
      "10.61.0.150"
    ],
    "name": "clustermesh-apiserver-648b49cc66-j2flb",
    "namespace": "kube-system"
  }
]

