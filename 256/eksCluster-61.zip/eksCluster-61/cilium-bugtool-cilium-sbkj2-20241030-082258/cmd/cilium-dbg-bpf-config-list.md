KEY             VALUE
AgentLiveness   2087182354151
UTimeOffset     3379442429687500
