IP ADDRESS        LOCAL ENDPOINT INFO
172.31.210.63:0   (localhost)                                                                                        
10.61.0.126:0     (localhost)                                                                                        
10.61.0.150:0     id=2870  sec_id=2038582 flags=0x0000 ifindex=18  mac=C6:D6:BE:28:FA:43 nodemac=1E:02:F9:A6:80:BD   
10.61.0.200:0     id=3648  sec_id=2061974 flags=0x0000 ifindex=14  mac=5E:B2:14:99:B3:3A nodemac=86:BC:EC:68:A0:CD   
10.61.0.234:0     id=1076  sec_id=4     flags=0x0000 ifindex=10  mac=AE:9B:4E:08:0E:26 nodemac=8A:86:31:45:28:94     
172.31.221.85:0   (localhost)                                                                                        
10.61.0.18:0      id=677   sec_id=2061974 flags=0x0000 ifindex=12  mac=BE:88:25:DE:D6:A1 nodemac=36:23:96:28:B6:FA   
