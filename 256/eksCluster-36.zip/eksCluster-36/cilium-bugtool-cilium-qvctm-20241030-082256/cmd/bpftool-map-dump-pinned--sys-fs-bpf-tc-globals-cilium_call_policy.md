key: eb 00 00 00  value: 6e 02 00 00
key: 82 06 00 00  value: 27 02 00 00
key: 09 0d 00 00  value: 1d 02 00 00
key: d3 0d 00 00  value: 0a 02 00 00
Found 4 elements
