REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38323     3035800     677    bpf_overlay.c
Interface                 INGRESS     680260    137206202   1132   bpf_host.c
Success                   EGRESS      17721     1399304     1694   bpf_host.c
Success                   EGRESS      297494    37144626    1308   bpf_lxc.c
Success                   EGRESS      39119     3095661     53     encap.h
Success                   INGRESS     339311    38497200    86     l3.h
Success                   INGRESS     360564    40177742    235    trace.h
Unsupported L3 protocol   EGRESS      42        3096        1492   bpf_lxc.c
