alloc: 104.32MB (109384192 bytes)
total-alloc: 2.50GB (2686617592 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 66878502
frees: 66133724
heap-alloc: 104.32MB (109384192 bytes)
heap-sys: 256.33MB (268779520 bytes)
heap-idle: 81.51MB (85467136 bytes)
heap-in-use: 174.82MB (183312384 bytes)
heap-released: 3.01MB (3153920 bytes)
heap-objects: 744778
stack-in-use: 67.62MB (70909952 bytes)
stack-sys: 67.62MB (70909952 bytes)
stack-mspan-inuse: 2.99MB (3132000 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1091033 bytes)
gc-sys: 6.10MB (6392360 bytes)
next-gc: when heap-alloc >= 209.73MB (219917240 bytes)
last-gc: 2024-10-30 08:23:32.490915813 +0000 UTC
gc-pause-total: 21.272618ms
gc-pause: 96321
gc-pause-end: 1730276612490915813
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.00041179031361819726
enable-gc: true
debug-gc: false
