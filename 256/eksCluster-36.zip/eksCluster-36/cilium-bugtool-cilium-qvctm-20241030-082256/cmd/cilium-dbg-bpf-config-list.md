KEY             VALUE
AgentLiveness   2336163416924
UTimeOffset     3379441949218750
