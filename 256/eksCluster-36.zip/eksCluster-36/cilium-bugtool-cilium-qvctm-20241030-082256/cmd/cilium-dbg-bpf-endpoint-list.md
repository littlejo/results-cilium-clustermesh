IP ADDRESS         LOCAL ENDPOINT INFO
172.31.144.141:0   (localhost)                                                                                        
10.36.0.206:0      id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE   
10.36.0.69:0       (localhost)                                                                                        
10.36.0.125:0      id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92   
10.36.0.217:0      id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1   
172.31.148.248:0   (localhost)                                                                                        
10.36.0.244:0      id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD     
