ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.252.139:443 (active)    
                                         2 => 172.31.170.121:443 (active)    
2    10.100.30.119:443    ClusterIP      1 => 172.31.148.248:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.36.0.217:53 (active)        
                                         2 => 10.36.0.125:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.36.0.217:9153 (active)      
                                         2 => 10.36.0.125:9153 (active)      
5    10.100.93.127:2379   ClusterIP      1 => 10.36.0.206:2379 (active)      
