1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c4:9b:a8:6f:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.248/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3107sec preferred_lft 3107sec
    inet6 fe80::4c4:9bff:fea8:6f9b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c8:61:3a:ff:4b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.144.141/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c8:61ff:fe3a:ff4b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:bc:8d:56:c4:07 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84bc:8dff:fe56:c407/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:73:27:b7:eb:be brd ff:ff:ff:ff:ff:ff
    inet 10.36.0.69/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cc73:27ff:feb7:ebbe/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ce:c2:15:0b:35:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ccc2:15ff:fe0b:3500/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:06:71:35:0d:bd brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6:71ff:fe35:dbd/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf3e331512b08@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:f9:8c:17:05:d1 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::90f9:8cff:fe17:5d1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcecfafecf4f0a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:05:43:8d:f2:92 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4805:43ff:fe8d:f292/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcaf84bcd8e14a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:ea:51:c9:48:fe brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a8ea:51ff:fec9:48fe/64 scope link 
       valid_lft forever preferred_lft forever
