{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.69:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:22.604Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.355Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.369Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.397Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.399Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:27.436Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.750Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.751Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.751Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.779Z",
  "value": "id=3129  sec_id=1241299 flags=0x0000 ifindex=16  mac=AA:A5:D7:C3:F2:42 nodemac=AA:29:1D:DB:80:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.780Z",
  "value": "id=3129  sec_id=1241299 flags=0x0000 ifindex=16  mac=AA:A5:D7:C3:F2:42 nodemac=AA:29:1D:DB:80:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.751Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.751Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.751Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:38.751Z",
  "value": "id=3129  sec_id=1241299 flags=0x0000 ifindex=16  mac=AA:A5:D7:C3:F2:42 nodemac=AA:29:1D:DB:80:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.569Z",
  "value": "id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.36.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.156Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.280Z",
  "value": "id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.280Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.280Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:03.281Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.280Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.281Z",
  "value": "id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.282Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.282Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.278Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.278Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.279Z",
  "value": "id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.279Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.279Z",
  "value": "id=1666  sec_id=4     flags=0x0000 ifindex=10  mac=C2:8E:B2:99:FB:9C nodemac=02:06:71:35:0D:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.279Z",
  "value": "id=235   sec_id=1241299 flags=0x0000 ifindex=18  mac=1E:17:8D:47:F3:64 nodemac=AA:EA:51:C9:48:FE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.125:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.279Z",
  "value": "id=3337  sec_id=1229269 flags=0x0000 ifindex=14  mac=A2:C4:09:AF:6D:AF nodemac=4A:05:43:8D:F2:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.36.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.279Z",
  "value": "id=3539  sec_id=1229269 flags=0x0000 ifindex=12  mac=46:64:E1:A2:BC:44 nodemac=92:F9:8C:17:05:D1"
}

