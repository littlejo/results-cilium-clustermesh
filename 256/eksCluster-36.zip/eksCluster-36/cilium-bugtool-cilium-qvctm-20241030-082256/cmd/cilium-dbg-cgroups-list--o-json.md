[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44c5e966_c943_41ee_938c_3903159b2601.slice/cri-containerd-3e05402009f01a26dbe8b5649951547409c427d5433adfcae11f18619f37a9ec.scope"
      }
    ],
    "ips": [
      "10.36.0.217"
    ],
    "name": "coredns-cc6ccd49c-fzcrv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1f3aa9c_f9ee_4932_8e5e_8810f8d002d9.slice/cri-containerd-0ae5ae2274e5347011ae09e0c3975251b31cb880811cea3d661d5dbbe372cd0f.scope"
      }
    ],
    "ips": [
      "10.36.0.125"
    ],
    "name": "coredns-cc6ccd49c-kv6ds",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-086b12523a6ff50060c9078aff74bc724a555bca2cace3100f9785345eb41abc.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-7918c3bba1fad4db5c00298756b2211d93ebcaf1003cf8cd3e210867a8f1d96d.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-f1dd0981b8c3578461cb90d409c2fb427e460db740990527fcc2917acaa05c07.scope"
      }
    ],
    "ips": [
      "10.36.0.206"
    ],
    "name": "clustermesh-apiserver-7d7f569d7-rgtwz",
    "namespace": "kube-system"
  }
]

