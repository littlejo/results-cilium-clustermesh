markdown output at /tmp/cilium-bugtool-20241030-082302.932+0000-UTC-3958231009/cmd/cilium-debuginfo-20241030-082334.668+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082302.932+0000-UTC-3958231009/cmd/cilium-debuginfo-20241030-082334.668+0000-UTC.json
