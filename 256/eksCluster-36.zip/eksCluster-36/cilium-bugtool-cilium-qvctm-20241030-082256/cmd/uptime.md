 08:23:03 up 38 min,  0 users,  load average: 3.47, 0.84, 0.33
