CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44c5e966_c943_41ee_938c_3903159b2601.slice/cri-containerd-345301b626e888840237ce0c7bfba595f38caab648807d2e3a1c57a2c3ecbd43.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod44c5e966_c943_41ee_938c_3903159b2601.slice/cri-containerd-3e05402009f01a26dbe8b5649951547409c427d5433adfcae11f18619f37a9ec.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc19b0af_9f45_4139_8df9_d2681b322347.slice/cri-containerd-0d4aac74745d81d23aa875a0583a37f6758bfe8ef37cd91b67a6e153e3583959.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc19b0af_9f45_4139_8df9_d2681b322347.slice/cri-containerd-4dc4eaaea0e33608f587df9cd59ddab025b74cd17e9836aca0ea850cebd2d967.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c7c9837_f13f_41d2_851f_4cfd3fc87b19.slice/cri-containerd-7d78919490568fd2d097cd49309568ecca28d7d1571fe77e4bdfb6853a48f8f4.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c7c9837_f13f_41d2_851f_4cfd3fc87b19.slice/cri-containerd-08353ce543a991872ad32ee09d1e1183ef16432af67a8c8c0f3b9d4a02ee60d8.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1f3aa9c_f9ee_4932_8e5e_8810f8d002d9.slice/cri-containerd-0ae5ae2274e5347011ae09e0c3975251b31cb880811cea3d661d5dbbe372cd0f.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1f3aa9c_f9ee_4932_8e5e_8810f8d002d9.slice/cri-containerd-7893d154edef7890c117bb7fbe9adec9dac86109b7392436530016d50397fb3b.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37cebab3_687d_44d6_8c08_020a5efd916d.slice/cri-containerd-99123c79281df93d35901f0d1083128c96011605ea93249b66b342d03da7c37e.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37cebab3_687d_44d6_8c08_020a5efd916d.slice/cri-containerd-d0fdcc8e5abcff843e4b40bceb66679ec4573ad4ef0050d21db94891a32cf846.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-086b12523a6ff50060c9078aff74bc724a555bca2cace3100f9785345eb41abc.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-f1dd0981b8c3578461cb90d409c2fb427e460db740990527fcc2917acaa05c07.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-0745d69872ccbb5eac77e16cd424a8c861f015871876724f171740790ca76f6a.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode5c31881_4f1c_4dbb_bf9a_eb49aa775198.slice/cri-containerd-7918c3bba1fad4db5c00298756b2211d93ebcaf1003cf8cd3e210867a8f1d96d.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf3616d5_ee39_4bfd_a7f4_588092a43fd1.slice/cri-containerd-8523e92ac814c8bf66fe9c2904a09e4e4e428cf6d0617e9e6b4729f0ab0b0b5c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddf3616d5_ee39_4bfd_a7f4_588092a43fd1.slice/cri-containerd-3cf690d5a86781207aeccfc311c26d6330c5b9fc4bb59d5635f9954af5c7ba4a.scope
    102      cgroup_device   multi                                          
