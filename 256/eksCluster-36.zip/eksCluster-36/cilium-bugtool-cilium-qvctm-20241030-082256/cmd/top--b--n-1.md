top - 08:23:03 up 38 min,  0 users,  load average: 3.47, 0.84, 0.33
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 66.7 us, 26.7 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4368.4 free,   1298.5 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6330.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 403016  78008 R  46.7   5.0   1:00.74 cilium-+
    710 root      20   0    2400   1488   1284 R  13.3   0.0   0:00.02 sysctl
    396 root      20   0 1229744   8004   3840 S   0.0   0.1   0:01.17 cilium-+
    623 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    629 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    633 root      20   0 1240432  16468  11292 S   0.0   0.2   0:00.02 cilium-+
    651 root      20   0 1228744   3604   2912 S   0.0   0.0   0:00.00 gops
    652 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    670 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    687 root      20   0 1243508  18028  13120 S   0.0   0.2   0:00.01 hubble
    707 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
