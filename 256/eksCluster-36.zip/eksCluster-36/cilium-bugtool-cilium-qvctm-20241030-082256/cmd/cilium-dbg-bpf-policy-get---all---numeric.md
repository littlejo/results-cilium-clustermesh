Endpoint ID: 165
Path: /sys/fs/bpf/tc/globals/cilium_policy_00165

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 235
Path: /sys/fs/bpf/tc/globals/cilium_policy_00235

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11760050   117522    0        
Allow    Ingress     1          ANY          NONE         disabled    11410931   116930    0        
Allow    Egress      0          ANY          NONE         disabled    13305276   131095    0        


Endpoint ID: 1666
Path: /sys/fs/bpf/tc/globals/cilium_policy_01666

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1684432   21301     0        
Allow    Ingress     1          ANY          NONE         disabled    27208     318       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3337
Path: /sys/fs/bpf/tc/globals/cilium_policy_03337

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    179512   2063      0        
Allow    Egress      0          ANY          NONE         disabled    22002    247       0        


Endpoint ID: 3539
Path: /sys/fs/bpf/tc/globals/cilium_policy_03539

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    180106   2072      0        
Allow    Egress      0          ANY          NONE         disabled    21954    245       0        


