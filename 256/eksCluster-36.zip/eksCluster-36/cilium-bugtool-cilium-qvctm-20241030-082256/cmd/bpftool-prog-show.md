32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:44:41+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:44:42+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:44:46+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:44:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
53: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:44:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:44:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name tail_handle_ipv4  tag 00d4eaf4a5857259  gpl
	loaded_at 2024-10-30T07:52:24+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
482: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:52:24+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 125
483: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:52:24+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 126
484: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:52:24+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
485: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,101
	btf_id 129
487: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 131
488: sched_cls  name tail_handle_ipv4_from_host  tag 556693b32beb2bf5  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,101
	btf_id 132
489: sched_cls  name __send_drop_notify  tag 22757377dc6f8690  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 133
491: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,101
	btf_id 135
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 137
495: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 140
496: sched_cls  name tail_handle_ipv4_from_host  tag 556693b32beb2bf5  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 141
497: sched_cls  name __send_drop_notify  tag 22757377dc6f8690  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 142
499: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 145
500: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 146
504: sched_cls  name tail_handle_ipv4_from_host  tag 556693b32beb2bf5  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 150
505: sched_cls  name __send_drop_notify  tag 22757377dc6f8690  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
506: sched_cls  name tail_handle_ipv4_from_host  tag 556693b32beb2bf5  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 153
507: sched_cls  name __send_drop_notify  tag 22757377dc6f8690  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 154
508: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 155
509: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:26+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 156
513: sched_cls  name tail_handle_arp  tag 92c5631f704e2da8  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 163
516: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 164
517: sched_cls  name cil_from_container  tag 86c13fd2c31067f4  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 167
522: sched_cls  name handle_policy  tag 21e969388a6aef6c  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 168
527: sched_cls  name tail_ipv4_to_endpoint  tag 90a4d46e54b56393  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 173
528: sched_cls  name tail_ipv4_ct_egress  tag be16d5e5fb6a95e5  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 178
532: sched_cls  name tail_ipv4_ct_egress  tag be16d5e5fb6a95e5  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 183
533: sched_cls  name tail_handle_ipv4  tag 6bab4ce7428e62f2  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 180
534: sched_cls  name tail_handle_ipv4_cont  tag 939a0847088dd749  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 185
535: sched_cls  name tail_handle_ipv4  tag 28d1c94acb0a06e0  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 184
536: sched_cls  name __send_drop_notify  tag c5bd0f89334109f7  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
537: sched_cls  name tail_ipv4_ct_ingress  tag ed8c99fdbca6449a  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 187
538: sched_cls  name __send_drop_notify  tag d170f6927043772c  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
539: sched_cls  name __send_drop_notify  tag 0ae247192330591f  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,117
	btf_id 192
541: sched_cls  name handle_policy  tag d94ccb24770e681c  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 188
543: sched_cls  name tail_handle_ipv4_cont  tag 294c30fb150fb266  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 193
544: sched_cls  name tail_handle_arp  tag 691348b5e37ca843  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 196
545: sched_cls  name cil_from_container  tag 7856793dfb1e9e1b  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 197
546: sched_cls  name tail_ipv4_to_endpoint  tag d0d6c6a9275d3a60  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 198
547: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 195
548: sched_cls  name cil_from_container  tag 09a813c0683e2160  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 117,76
	btf_id 199
549: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 201
550: sched_cls  name tail_ipv4_ct_ingress  tag a91e93fed0bb64dd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 202
551: sched_cls  name handle_policy  tag 8a032d387351031d  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,117,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 200
552: sched_cls  name tail_handle_arp  tag 98a558fa0fa97928  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,117
	btf_id 203
553: sched_cls  name tail_handle_ipv4_cont  tag 6ff9c96901126dfd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,117,40,37,38,81
	btf_id 204
554: sched_cls  name tail_ipv4_ct_ingress  tag f46415af58a9195b  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,117,82,83,118,84
	btf_id 205
555: sched_cls  name tail_ipv4_to_endpoint  tag c671844a5cfd2488  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,117,40,37,38
	btf_id 206
556: sched_cls  name tail_handle_ipv4  tag ff5bce01bdc3cd2a  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,117
	btf_id 207
557: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
560: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
568: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
569: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
572: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:27+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
612: sched_cls  name tail_ipv4_to_endpoint  tag 27b5deb6405b9a0f  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 221
613: sched_cls  name tail_handle_ipv4_cont  tag 0adb96741a07cfff  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 222
615: sched_cls  name tail_handle_arp  tag ffeaab57c702c83f  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 224
616: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 225
617: sched_cls  name cil_from_container  tag 3f181069e29e2447  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 226
618: sched_cls  name tail_ipv4_ct_egress  tag 7a919564b59bddc5  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 227
619: sched_cls  name tail_handle_ipv4  tag 07da9cacbd054b90  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 228
620: sched_cls  name tail_ipv4_ct_ingress  tag 1c48f5c0ce90eba1  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 229
621: sched_cls  name __send_drop_notify  tag 86bf9ee60d96b466  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
622: sched_cls  name handle_policy  tag 79894f6d997732f1  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 231
623: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
626: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
639: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
642: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
643: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
646: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:53+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
