REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36457     2885764     677    bpf_overlay.c
Interface                 INGRESS     646529    132883007   1132   bpf_host.c
Stale or unroutable IP    INGRESS     2         148         882    bpf_host.c
Success                   EGRESS      11300     1791482     86     l3.h
Success                   EGRESS      16453     1295798     1694   bpf_host.c
Success                   EGRESS      274181    34239170    1308   bpf_lxc.c
Success                   EGRESS      36705     2905906     53     encap.h
Success                   INGRESS     315159    35578895    86     l3.h
Success                   INGRESS     347114    39004389    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
