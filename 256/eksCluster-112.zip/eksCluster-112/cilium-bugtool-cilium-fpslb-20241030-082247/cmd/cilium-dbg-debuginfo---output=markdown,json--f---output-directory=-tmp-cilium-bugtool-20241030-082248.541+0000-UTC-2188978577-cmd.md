markdown output at /tmp/cilium-bugtool-20241030-082248.541+0000-UTC-2188978577/cmd/cilium-debuginfo-20241030-082319.9+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.541+0000-UTC-2188978577/cmd/cilium-debuginfo-20241030-082319.9+0000-UTC.json
