CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2210cfb6_70a8_48c5_aeab_9ea499522d83.slice/cri-containerd-77f32f9aa6d18ec1f1688a94cc72e1bd887bab8d1e10cd1da997b6905da104cf.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2210cfb6_70a8_48c5_aeab_9ea499522d83.slice/cri-containerd-7c937ec9a991a58f85a2a790792d7dcaec4b1a3ea3b421e17b69927bb7c41205.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd1940_6448_4412_88b0_e2ff130ada01.slice/cri-containerd-20ae3d35fe203b2312600f908c3ea7201611a6b5f58b8683b86155c353d87e61.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd1940_6448_4412_88b0_e2ff130ada01.slice/cri-containerd-b7d1f46af7f84a2864a0c1ab42b2bfbe5b6d840e0bc92826b7c4016ed0d49385.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod436d4dc8_d8a3_4c7b_a448_37b73441a7c3.slice/cri-containerd-ad23b96eefae7b97f7fa310da6276f5a56a19e5c815678d75176293d71f47106.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod436d4dc8_d8a3_4c7b_a448_37b73441a7c3.slice/cri-containerd-48d9ff3e4bca0cadeb9308e2b254f02c7a7d1de35b52cb02c808190f4f3a4abc.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6dfc3fa_07ba_4b3e_b9c5_369b9d181af6.slice/cri-containerd-5b4aef44845e4f8d6fe9f3fede8dcc7e6cb703407c8fbf1edb103d9ccd7b00b5.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6dfc3fa_07ba_4b3e_b9c5_369b9d181af6.slice/cri-containerd-49edb60d4c49c406cce1f57231864b51b7b05700f2de0473178cc891c19c8081.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3031075c_1650_48cd_95c0_5ccbd1b7582f.slice/cri-containerd-ab77fa2069911d389fb848b5b86146220addd4dded34f6bb5d7e8161f0ea369a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3031075c_1650_48cd_95c0_5ccbd1b7582f.slice/cri-containerd-78b05a212e4c494d46b6fab74a13214bbcc072c822a0999f41d2015d5b07d9f4.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-cb11710a880ae41231930a6e3c7e4ee672f02c6ae21b086c0a0d79236d19c590.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-3aa2ac97dc87598863e9f894a4eed380008a28de993c0e07aec8995d699b0cca.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-26cbace72b2cebc61fd9334c6f089ab903ce434f4bc091458587c5570a1ce5d8.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-b89e8d59f5077fc437df658db132c46bc6c35bfc11b50c34073e3fe417337f14.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb17aa265_31b3_4cf5_9533_c7b6be0a265d.slice/cri-containerd-0c03e8e577d2c99539cf71c9f42f144fb2f70e1b22e6b436a2b8f0e95878b712.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb17aa265_31b3_4cf5_9533_c7b6be0a265d.slice/cri-containerd-3606a21e1351d1d081d875fe94fd530adc1b82a72816e5dab2767a328aba0af1.scope
    98       cgroup_device   multi                                          
