key: 2b 03 00 00  value: 19 02 00 00
key: cc 0a 00 00  value: 0a 02 00 00
key: 14 0b 00 00  value: 05 02 00 00
key: 79 0c 00 00  value: 77 02 00 00
Found 4 elements
