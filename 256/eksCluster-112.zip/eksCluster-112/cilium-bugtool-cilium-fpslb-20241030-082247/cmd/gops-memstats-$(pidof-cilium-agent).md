alloc: 189.79MB (199008672 bytes)
total-alloc: 2.34GB (2510830032 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 64821453
frees: 62661923
heap-alloc: 189.79MB (199008672 bytes)
heap-sys: 251.45MB (263667712 bytes)
heap-idle: 41.12MB (43122688 bytes)
heap-in-use: 210.33MB (220545024 bytes)
heap-released: 8.61MB (9027584 bytes)
heap-objects: 2159530
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.52MB (3693760 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1000.77KB (1024793 bytes)
gc-sys: 6.06MB (6350408 bytes)
next-gc: when heap-alloc >= 221.48MB (232235096 bytes)
last-gc: 2024-10-30 08:22:49.083912914 +0000 UTC
gc-pause-total: 20.229263ms
gc-pause: 7629735
gc-pause-end: 1730276569083912914
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0004012888509598843
enable-gc: true
debug-gc: false
