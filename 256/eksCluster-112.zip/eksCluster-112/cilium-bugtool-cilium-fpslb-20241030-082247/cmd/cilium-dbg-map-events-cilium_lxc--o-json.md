{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.859Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.859Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.859Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.443Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.466Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.537Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.597Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.642Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:29.903Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:29.904Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:29.904Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:29.935Z",
  "value": "id=3942  sec_id=3713456 flags=0x0000 ifindex=16  mac=C2:76:D9:2E:E3:43 nodemac=E2:11:AB:E0:98:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:29.935Z",
  "value": "id=3942  sec_id=3713456 flags=0x0000 ifindex=16  mac=C2:76:D9:2E:E3:43 nodemac=E2:11:AB:E0:98:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.045Z",
  "value": "id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.112.0.202:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.623Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.886Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.886Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.887Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:42.887Z",
  "value": "id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.895Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.896Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.896Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:43.897Z",
  "value": "id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.885Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.885Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.885Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.886Z",
  "value": "id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.80:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.885Z",
  "value": "id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.886Z",
  "value": "id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.886Z",
  "value": "id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.112.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.886Z",
  "value": "id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07"
}

