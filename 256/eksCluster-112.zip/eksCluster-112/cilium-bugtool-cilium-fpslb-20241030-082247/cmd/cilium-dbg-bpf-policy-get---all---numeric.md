Endpoint ID: 432
Path: /sys/fs/bpf/tc/globals/cilium_policy_00432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 811
Path: /sys/fs/bpf/tc/globals/cilium_policy_00811

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    317448   2856      0        
Allow    Ingress     1          ANY          NONE         disabled    174208   2004      0        
Allow    Egress      0          ANY          NONE         disabled    106797   1042      0        


Endpoint ID: 2764
Path: /sys/fs/bpf/tc/globals/cilium_policy_02764

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    312166   2794      0        
Allow    Ingress     1          ANY          NONE         disabled    174961   2010      0        
Allow    Egress      0          ANY          NONE         disabled    103921   1010      0        


Endpoint ID: 2836
Path: /sys/fs/bpf/tc/globals/cilium_policy_02836

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1637286   20697     0        
Allow    Ingress     1          ANY          NONE         disabled    25874     301       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3193
Path: /sys/fs/bpf/tc/globals/cilium_policy_03193

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11501782   114670    0        
Allow    Ingress     1          ANY          NONE         disabled    9954702    104808    0        
Allow    Egress      0          ANY          NONE         disabled    12823796   126323    0        


