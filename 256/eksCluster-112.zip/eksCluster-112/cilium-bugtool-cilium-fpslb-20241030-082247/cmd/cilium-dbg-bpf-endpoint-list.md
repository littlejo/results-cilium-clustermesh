IP ADDRESS         LOCAL ENDPOINT INFO
10.112.0.157:0     id=3193  sec_id=3713456 flags=0x0000 ifindex=18  mac=52:E5:52:5E:93:7D nodemac=C6:AB:78:4F:88:07   
10.112.0.80:0      id=811   sec_id=3706613 flags=0x0000 ifindex=14  mac=EA:31:3F:51:32:5D nodemac=72:94:01:EA:E3:8A   
10.112.0.102:0     id=2764  sec_id=3706613 flags=0x0000 ifindex=12  mac=7A:3E:E1:17:30:53 nodemac=42:2A:39:E5:CD:7E   
172.31.145.79:0    (localhost)                                                                                        
172.31.177.254:0   (localhost)                                                                                        
10.112.0.132:0     (localhost)                                                                                        
10.112.0.96:0      id=2836  sec_id=4     flags=0x0000 ifindex=10  mac=F6:7C:61:24:6D:0C nodemac=8A:3B:D9:EF:23:DF     
