ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.155.238:443 (active)   
                                          2 => 172.31.212.82:443 (active)    
2    10.100.26.35:443      ClusterIP      1 => 172.31.145.79:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.112.0.102:53 (active)      
                                          2 => 10.112.0.80:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.112.0.102:9153 (active)    
                                          2 => 10.112.0.80:9153 (active)     
5    10.100.148.220:2379   ClusterIP      1 => 10.112.0.157:2379 (active)    
