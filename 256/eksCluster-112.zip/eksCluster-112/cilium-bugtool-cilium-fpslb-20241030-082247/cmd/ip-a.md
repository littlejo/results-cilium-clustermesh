1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:41:cf:90:ea:f3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.145.79/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3205sec preferred_lft 3205sec
    inet6 fe80::441:cfff:fe90:eaf3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:fe:ab:49:10:61 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.177.254/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4fe:abff:fe49:1061/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:98:2f:bb:80:b2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8898:2fff:febb:80b2/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:d3:09:5f:e7:a4 brd ff:ff:ff:ff:ff:ff
    inet 10.112.0.132/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::18d3:9ff:fe5f:e7a4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 8e:b3:7d:06:83:b0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8cb3:7dff:fe06:83b0/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:3b:d9:ef:23:df brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::883b:d9ff:feef:23df/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc6ba7ed96a924@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:2a:39:e5:cd:7e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::402a:39ff:fee5:cd7e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf5732edf370c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:94:01:ea:e3:8a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::7094:1ff:feea:e38a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcad1d1a90f271@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:ab:78:4f:88:07 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c4ab:78ff:fe4f:8807/64 scope link 
       valid_lft forever preferred_lft forever
