filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6ba7ed96a924 direct-action not_in_hw id 521 tag 35aab27d2b695a4a jited 
