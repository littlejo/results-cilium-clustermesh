[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode9dd1940_6448_4412_88b0_e2ff130ada01.slice/cri-containerd-b7d1f46af7f84a2864a0c1ab42b2bfbe5b6d840e0bc92826b7c4016ed0d49385.scope"
      }
    ],
    "ips": [
      "10.112.0.102"
    ],
    "name": "coredns-cc6ccd49c-h4gfq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-3aa2ac97dc87598863e9f894a4eed380008a28de993c0e07aec8995d699b0cca.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-cb11710a880ae41231930a6e3c7e4ee672f02c6ae21b086c0a0d79236d19c590.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb234f36_0869_465a_affe_00c40fbe2be5.slice/cri-containerd-b89e8d59f5077fc437df658db132c46bc6c35bfc11b50c34073e3fe417337f14.scope"
      }
    ],
    "ips": [
      "10.112.0.157"
    ],
    "name": "clustermesh-apiserver-587fcf44c9-rbwft",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6dfc3fa_07ba_4b3e_b9c5_369b9d181af6.slice/cri-containerd-49edb60d4c49c406cce1f57231864b51b7b05700f2de0473178cc891c19c8081.scope"
      }
    ],
    "ips": [
      "10.112.0.80"
    ],
    "name": "coredns-cc6ccd49c-zz5q5",
    "namespace": "kube-system"
  }
]

