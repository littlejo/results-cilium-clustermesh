KEY             VALUE
AgentLiveness   2236417592780
UTimeOffset     3379442115234375
