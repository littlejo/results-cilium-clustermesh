alloc: 157.14MB (164775264 bytes)
total-alloc: 2.40GB (2575684808 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 65944142
frees: 64566328
heap-alloc: 157.14MB (164775264 bytes)
heap-sys: 251.48MB (263692288 bytes)
heap-idle: 52.88MB (55451648 bytes)
heap-in-use: 198.59MB (208240640 bytes)
heap-released: 0 bytes
heap-objects: 1377814
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.12MB (3266400 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.16MB (1213329 bytes)
gc-sys: 6.01MB (6301184 bytes)
next-gc: when heap-alloc >= 217.57MB (228137272 bytes)
last-gc: 2024-10-30 08:23:11.70600941 +0000 UTC
gc-pause-total: 10.717054ms
gc-pause: 62637
gc-pause-end: 1730276591706009410
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003757399913178346
enable-gc: true
debug-gc: false
