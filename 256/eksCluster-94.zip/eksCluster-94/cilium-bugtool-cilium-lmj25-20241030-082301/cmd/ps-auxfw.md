USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         657  0.0  0.0 1228744 4036 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         653  0.0  0.1 1240432 15548 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         692  0.0  0.0   6408  1648 ?        R    08:23   0:00  \_ ps auxfw
root           1  3.5  4.7 1606336 382244 ?      Ssl  07:57   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.0 1229744 6860 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
