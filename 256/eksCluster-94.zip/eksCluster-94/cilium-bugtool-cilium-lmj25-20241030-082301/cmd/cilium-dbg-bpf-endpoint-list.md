IP ADDRESS         LOCAL ENDPOINT INFO
10.94.0.235:0      id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03   
10.94.0.23:0       id=421   sec_id=3120174 flags=0x0000 ifindex=18  mac=B6:3C:6C:B3:19:FB nodemac=1A:1B:E7:8A:E6:47   
10.94.0.214:0      id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30   
172.31.153.143:0   (localhost)                                                                                        
10.94.0.166:0      id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A     
10.94.0.89:0       (localhost)                                                                                        
172.31.135.220:0   (localhost)                                                                                        
