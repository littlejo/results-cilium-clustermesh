Endpoint ID: 133
Path: /sys/fs/bpf/tc/globals/cilium_policy_00133

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1679596   21242     0        
Allow    Ingress     1          ANY          NONE         disabled    23024     271       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 420
Path: /sys/fs/bpf/tc/globals/cilium_policy_00420

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147844   1690      0        
Allow    Egress      0          ANY          NONE         disabled    19028    209       0        


Endpoint ID: 421
Path: /sys/fs/bpf/tc/globals/cilium_policy_00421

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11597836   117037    0        
Allow    Ingress     1          ANY          NONE         disabled    11305679   119562    0        
Allow    Egress      0          ANY          NONE         disabled    15296739   149188    0        


Endpoint ID: 1834
Path: /sys/fs/bpf/tc/globals/cilium_policy_01834

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148504   1700      0        
Allow    Egress      0          ANY          NONE         disabled    17643    194       0        


Endpoint ID: 1882
Path: /sys/fs/bpf/tc/globals/cilium_policy_01882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


