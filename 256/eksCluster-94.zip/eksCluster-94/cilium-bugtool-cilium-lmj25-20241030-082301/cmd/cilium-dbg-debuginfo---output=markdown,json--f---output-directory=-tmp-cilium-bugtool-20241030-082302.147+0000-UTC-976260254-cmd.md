markdown output at /tmp/cilium-bugtool-20241030-082302.147+0000-UTC-976260254/cmd/cilium-debuginfo-20241030-082333.235+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082302.147+0000-UTC-976260254/cmd/cilium-debuginfo-20241030-082333.235+0000-UTC.json
