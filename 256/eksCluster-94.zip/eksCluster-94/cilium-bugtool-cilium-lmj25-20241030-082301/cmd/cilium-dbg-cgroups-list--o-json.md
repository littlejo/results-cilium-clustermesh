[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-01e7a889db60129b9d1e70d60fbfacce7d7005d99627adb3387ae33fd2be9ca8.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-92124b6f49144c55f7d35384f289400ad636bdb125c500ba46257240d233f2a4.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-8f18c7bddbbb424f8357c893757954e54cb7e195e037570d9cc6b7e63114095d.scope"
      }
    ],
    "ips": [
      "10.94.0.23"
    ],
    "name": "clustermesh-apiserver-77c9798975-cqz75",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bc2733e_44af_450f_990c_0b9f942b343c.slice/cri-containerd-e5bd886d47f1004ff76d9040d559b685a4080d34b1ee5980193262d968da9d20.scope"
      }
    ],
    "ips": [
      "10.94.0.235"
    ],
    "name": "coredns-cc6ccd49c-zmh94",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7258653b_7377_425a_a128_354bc611d86c.slice/cri-containerd-81e55fb868018ca869fbc3e35605b98a3d530f70a5008219297e0afd4ad23560.scope"
      }
    ],
    "ips": [
      "10.94.0.214"
    ],
    "name": "coredns-cc6ccd49c-5b4kr",
    "namespace": "kube-system"
  }
]

