{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.031Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.135.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.031Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.153.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:15.031Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.555Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.557Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.609Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.610Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.622Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.199Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.199Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.199Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.230Z",
  "value": "id=3464  sec_id=3120174 flags=0x0000 ifindex=16  mac=8A:5E:CE:1E:FF:C5 nodemac=1E:E9:4B:FD:2F:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.200Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.200Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.200Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.200Z",
  "value": "id=3464  sec_id=3120174 flags=0x0000 ifindex=16  mac=8A:5E:CE:1E:FF:C5 nodemac=1E:E9:4B:FD:2F:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.954Z",
  "value": "id=421   sec_id=3120174 flags=0x0000 ifindex=18  mac=B6:3C:6C:B3:19:FB nodemac=1A:1B:E7:8A:E6:47"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.94.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.294Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.590Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.591Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.592Z",
  "value": "id=421   sec_id=3120174 flags=0x0000 ifindex=18  mac=B6:3C:6C:B3:19:FB nodemac=1A:1B:E7:8A:E6:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.592Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.589Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.589Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.589Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.589Z",
  "value": "id=421   sec_id=3120174 flags=0x0000 ifindex=18  mac=B6:3C:6C:B3:19:FB nodemac=1A:1B:E7:8A:E6:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.214:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.590Z",
  "value": "id=1834  sec_id=3125873 flags=0x0000 ifindex=14  mac=C2:9D:2C:24:25:F6 nodemac=1A:62:4C:25:AD:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.166:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.590Z",
  "value": "id=133   sec_id=4     flags=0x0000 ifindex=10  mac=96:CD:54:E5:64:B8 nodemac=0A:7F:0D:AE:E1:4A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.590Z",
  "value": "id=421   sec_id=3120174 flags=0x0000 ifindex=18  mac=B6:3C:6C:B3:19:FB nodemac=1A:1B:E7:8A:E6:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.94.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.590Z",
  "value": "id=420   sec_id=3125873 flags=0x0000 ifindex=12  mac=32:7A:59:C0:7E:6D nodemac=A6:6B:DB:9F:0B:03"
}

