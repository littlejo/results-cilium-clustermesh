key: 85 00 00 00  value: 27 02 00 00
key: a4 01 00 00  value: 11 02 00 00
key: a5 01 00 00  value: 6b 02 00 00
key: 2a 07 00 00  value: 1c 02 00 00
Found 4 elements
