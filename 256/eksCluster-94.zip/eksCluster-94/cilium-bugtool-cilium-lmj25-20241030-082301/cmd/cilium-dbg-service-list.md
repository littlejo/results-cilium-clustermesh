ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.136.213:443 (active)    
                                          2 => 172.31.215.96:443 (active)     
2    10.100.52.59:443      ClusterIP      1 => 172.31.135.220:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.94.0.214:53 (active)        
                                          2 => 10.94.0.235:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.94.0.214:9153 (active)      
                                          2 => 10.94.0.235:9153 (active)      
5    10.100.196.230:2379   ClusterIP      1 => 10.94.0.23:2379 (active)       
