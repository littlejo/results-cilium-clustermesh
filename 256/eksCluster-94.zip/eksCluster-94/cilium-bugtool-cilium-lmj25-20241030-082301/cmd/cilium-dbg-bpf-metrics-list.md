REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38334     3035512     677    bpf_overlay.c
Interface                 INGRESS     683199    137818363   1132   bpf_host.c
Success                   EGRESS      17797     1404138     1694   bpf_host.c
Success                   EGRESS      293279    36037598    1308   bpf_lxc.c
Success                   EGRESS      39447     3114220     53     encap.h
Success                   INGRESS     336516    38299070    86     l3.h
Success                   INGRESS     357704    39974490    235    trace.h
Unsupported L3 protocol   EGRESS      43        3222        1492   bpf_lxc.c
