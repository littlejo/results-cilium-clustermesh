CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7258653b_7377_425a_a128_354bc611d86c.slice/cri-containerd-81e55fb868018ca869fbc3e35605b98a3d530f70a5008219297e0afd4ad23560.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7258653b_7377_425a_a128_354bc611d86c.slice/cri-containerd-83f064ec9f6de11248a22415fe5cd7de44a7a140710e1888d1f29d0dca2a2ec3.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bc2733e_44af_450f_990c_0b9f942b343c.slice/cri-containerd-67141f56845a867dd6314c01bd07b41d0756752dd0ad31b8312c5622cf8ef6b5.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4bc2733e_44af_450f_990c_0b9f942b343c.slice/cri-containerd-e5bd886d47f1004ff76d9040d559b685a4080d34b1ee5980193262d968da9d20.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59be516a_c245_48e7_846d_ea3de87480ca.slice/cri-containerd-1b8dc7678a8f0c408a70d3a1ebd6d9677158f563c612a67fbad456dd0941f417.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod59be516a_c245_48e7_846d_ea3de87480ca.slice/cri-containerd-b55b7776a320ffc47a6de4c84cf33b58d36bf99a23599b1231a8f5af769fd90c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a81459a_4729_47ea_8d04_2ca010059ebb.slice/cri-containerd-00e78e55027a271520e2f6d4d19a83186e5a09066a633128831080a37c2b475d.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2a81459a_4729_47ea_8d04_2ca010059ebb.slice/cri-containerd-7708878a283ef59f7a4e4df51482ebf789eecb9987c858a25bda44e9a37a3575.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod806ac2b4_9d85_44e0_b5d4_dd77e0883656.slice/cri-containerd-0ebbb9aed2d9a4988814aede12e2901b45dc1c34994cd70275e64c4350d170d3.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod806ac2b4_9d85_44e0_b5d4_dd77e0883656.slice/cri-containerd-0ef0db7f8eca38e5751fd084a10588d8e42d1d48331fe65a0a850c22f8f088d4.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-92124b6f49144c55f7d35384f289400ad636bdb125c500ba46257240d233f2a4.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-01e7a889db60129b9d1e70d60fbfacce7d7005d99627adb3387ae33fd2be9ca8.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-05dc0aa06127def8f53cdd32af3dfbca9c9c2d253e8d6e3d0c8bfa92e400797d.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6e8224f4_53f2_49a2_9b3f_bc44dc7b72c3.slice/cri-containerd-8f18c7bddbbb424f8357c893757954e54cb7e195e037570d9cc6b7e63114095d.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6009865_23c4_4bda_8e09_8cb4ba54a39e.slice/cri-containerd-a165350ca613ca9378a54f0f5e061b4fc28e01ac59f90ffdf5ae72f4392134de.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6009865_23c4_4bda_8e09_8cb4ba54a39e.slice/cri-containerd-efc5d91f3ca673efe3af11485d6ba33a63c2a46967cf56e820d1b6e3fd8872a8.scope
    102      cgroup_device   multi                                          
