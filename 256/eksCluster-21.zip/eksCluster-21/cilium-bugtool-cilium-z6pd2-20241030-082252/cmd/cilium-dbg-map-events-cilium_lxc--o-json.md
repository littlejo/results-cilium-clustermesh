{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.195.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.219.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:36.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.517Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.519Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.592Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.644Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.727Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.889Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.889Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.889Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:58.920Z",
  "value": "id=2254  sec_id=738081 flags=0x0000 ifindex=16  mac=46:AD:DC:0B:63:9D nodemac=16:A3:72:01:E8:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.890Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.890Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.891Z",
  "value": "id=2254  sec_id=738081 flags=0x0000 ifindex=16  mac=46:AD:DC:0B:63:9D nodemac=16:A3:72:01:E8:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:59.891Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:05.170Z",
  "value": "id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.21.0.6:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.962Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.334Z",
  "value": "id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.335Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.335Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.335Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.337Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.348Z",
  "value": "id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.351Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.352Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.334Z",
  "value": "id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.334Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.335Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.335Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.335Z",
  "value": "id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.335Z",
  "value": "id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.335Z",
  "value": "id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.21.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.336Z",
  "value": "id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A"
}

