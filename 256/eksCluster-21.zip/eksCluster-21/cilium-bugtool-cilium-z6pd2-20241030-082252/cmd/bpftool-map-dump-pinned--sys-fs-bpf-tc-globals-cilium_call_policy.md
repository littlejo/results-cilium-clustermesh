key: 6a 02 00 00  value: 1e 02 00 00
key: 7a 02 00 00  value: 73 02 00 00
key: b8 08 00 00  value: 00 02 00 00
key: f5 0e 00 00  value: 0b 02 00 00
Found 4 elements
