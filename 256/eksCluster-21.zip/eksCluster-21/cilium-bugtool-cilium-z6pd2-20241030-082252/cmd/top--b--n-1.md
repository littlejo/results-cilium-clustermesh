top - 08:22:54 up 37 min,  0 users,  load average: 0.27, 0.30, 0.27
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.5 us, 39.4 sy,  0.0 ni, 15.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4465.5 free,   1201.4 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6427.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1671812 399164  78152 S  73.3   5.0   1:05.52 cilium-+
    659 root      20   0 1240432  16764  11548 S   6.7   0.2   0:00.03 cilium-+
    737 root      20   0 1243508  17648  12928 S   6.7   0.2   0:00.01 hubble
    396 root      20   0 1229744   8324   3900 S   0.0   0.1   0:01.18 cilium-+
    638 root      20   0 1229000   3736   3040 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    702 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    717 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    722 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    747 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
