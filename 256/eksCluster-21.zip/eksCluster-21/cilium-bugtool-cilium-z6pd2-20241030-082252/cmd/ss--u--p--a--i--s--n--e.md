Total: 674
TCP:   1851 (estab 428, closed 1404, orphaned 0, timewait 567)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  447       436       11       
INET	  457       442       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.219.89%ens5:68         0.0.0.0:*    uid:192 ino:65158 sk:3ee cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33258 sk:3ef cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15460 sk:3f0 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:42001      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33186 sk:3f1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33257 sk:3f2 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15461 sk:3f3 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::871:32ff:fed3:eeb5]%ens5:546           [::]:*    uid:192 ino:15752 sk:3f4 cgroup:unreachable:c4e v6only:1 <->                   
