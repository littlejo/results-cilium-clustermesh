REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36638     2900319     677    bpf_overlay.c
Interface                 INGRESS     669787    135757010   1132   bpf_host.c
Success                   EGRESS      16344     1288069     1694   bpf_host.c
Success                   EGRESS      291928    36562517    1308   bpf_lxc.c
Success                   EGRESS      36971     2924438     53     encap.h
Success                   INGRESS     335042    37919459    86     l3.h
Success                   INGRESS     355861    39566427    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
