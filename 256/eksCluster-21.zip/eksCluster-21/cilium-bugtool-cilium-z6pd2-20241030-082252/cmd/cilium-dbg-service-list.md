ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.129.237:443 (active)   
                                         2 => 172.31.197.131:443 (active)   
2    10.100.168.104:443   ClusterIP      1 => 172.31.219.89:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.21.0.192:9153 (active)     
                                         2 => 10.21.0.236:9153 (active)     
4    10.100.0.10:53       ClusterIP      1 => 10.21.0.192:53 (active)       
                                         2 => 10.21.0.236:53 (active)       
5    10.100.200.38:2379   ClusterIP      1 => 10.21.0.15:2379 (active)      
