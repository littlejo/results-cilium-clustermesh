alloc: 111.46MB (116870128 bytes)
total-alloc: 2.46GB (2641746976 bytes)
sys: 340.96MB (357522804 bytes)
lookups: 0
mallocs: 66215082
frees: 65358313
heap-alloc: 111.46MB (116870128 bytes)
heap-sys: 260.14MB (272777216 bytes)
heap-idle: 82.50MB (86507520 bytes)
heap-in-use: 177.64MB (186269696 bytes)
heap-released: 9.53MB (9994240 bytes)
heap-objects: 856769
stack-in-use: 67.81MB (71106560 bytes)
stack-sys: 67.81MB (71106560 bytes)
stack-mspan-inuse: 3.04MB (3190400 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1023.92KB (1048489 bytes)
gc-sys: 6.01MB (6302416 bytes)
next-gc: when heap-alloc >= 214.07MB (224467560 bytes)
last-gc: 2024-10-30 08:23:18.86782908 +0000 UTC
gc-pause-total: 23.540056ms
gc-pause: 67217
gc-pause-end: 1730276598867829080
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.00047264294537835547
enable-gc: true
debug-gc: false
