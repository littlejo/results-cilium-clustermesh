Endpoint ID: 618
Path: /sys/fs/bpf/tc/globals/cilium_policy_00618

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176020   2019      0        
Allow    Egress      0          ANY          NONE         disabled    20987    234       0        


Endpoint ID: 634
Path: /sys/fs/bpf/tc/globals/cilium_policy_00634

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11670086   116575    0        
Allow    Ingress     1          ANY          NONE         disabled    11249074   115251    0        
Allow    Egress      0          ANY          NONE         disabled    12779331   126018    0        


Endpoint ID: 1950
Path: /sys/fs/bpf/tc/globals/cilium_policy_01950

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2232
Path: /sys/fs/bpf/tc/globals/cilium_policy_02232

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175845   2018      0        
Allow    Egress      0          ANY          NONE         disabled    20850    232       0        


Endpoint ID: 3829
Path: /sys/fs/bpf/tc/globals/cilium_policy_03829

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649870   20855     0        
Allow    Ingress     1          ANY          NONE         disabled    26756     314       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


