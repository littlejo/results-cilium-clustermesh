IP ADDRESS         LOCAL ENDPOINT INFO
172.31.195.159:0   (localhost)                                                                                       
172.31.219.89:0    (localhost)                                                                                       
10.21.0.79:0       (localhost)                                                                                       
10.21.0.192:0      id=2232  sec_id=749075 flags=0x0000 ifindex=14  mac=2A:15:B8:C6:BB:88 nodemac=EE:3A:F9:20:15:03   
10.21.0.137:0      id=3829  sec_id=4     flags=0x0000 ifindex=10  mac=AA:96:7A:9B:EE:83 nodemac=AA:3A:A5:B7:88:DE    
10.21.0.236:0      id=618   sec_id=749075 flags=0x0000 ifindex=12  mac=3A:4D:6D:5B:19:9D nodemac=D2:D1:DD:5D:63:0A   
10.21.0.15:0       id=634   sec_id=738081 flags=0x0000 ifindex=18  mac=6A:B3:0A:C5:8B:8D nodemac=7E:D6:81:91:CE:EF   
