KEY             VALUE
AgentLiveness   2299480623506
UTimeOffset     3379442003906250
