1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:71:32:d3:ee:b5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.219.89/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3141sec preferred_lft 3141sec
    inet6 fe80::871:32ff:fed3:eeb5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:97:ed:e5:d9:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.195.159/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::897:edff:fee5:d991/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:c3:39:f1:ce:87 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::68c3:39ff:fef1:ce87/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:63:3c:a2:39:c3 brd ff:ff:ff:ff:ff:ff
    inet 10.21.0.79/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2463:3cff:fea2:39c3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:7c:14:c9:ca:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c87c:14ff:fec9:ca97/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:3a:a5:b7:88:de brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a83a:a5ff:feb7:88de/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcd358387ab665@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:d1:dd:5d:63:0a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d0d1:ddff:fe5d:630a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb18e53a5f542@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:3a:f9:20:15:03 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ec3a:f9ff:fe20:1503/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc62ca84857c83@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:d6:81:91:ce:ef brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7cd6:81ff:fe91:ceef/64 scope link 
       valid_lft forever preferred_lft forever
