xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 574
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 565
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxcd358387ab665(12) clsact/ingress cil_from_container-lxcd358387ab665 id 548
lxcb18e53a5f542(14) clsact/ingress cil_from_container-lxcb18e53a5f542 id 511
lxc62ca84857c83(18) clsact/ingress cil_from_container-lxc62ca84857c83 id 634

flow_dissector:

netfilter:

