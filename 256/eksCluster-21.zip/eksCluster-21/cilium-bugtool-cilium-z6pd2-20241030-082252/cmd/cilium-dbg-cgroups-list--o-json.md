[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-8dec453373e15ee9e7d2b438b962be80f4a00b9d5c8b0a39d9407f3589f9255e.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-fa094044e69d96ad9ecc092333565bee602d7b747a8269c31dbcc377171b9cf9.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-52bf61a43d05c645a59c02ae9081483a45d6c49fae22ca8fe15c06b0522292a1.scope"
      }
    ],
    "ips": [
      "10.21.0.15"
    ],
    "name": "clustermesh-apiserver-57f5b7464c-2cjht",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f6eee29_a7f5_454c_9ea2_31c723734f85.slice/cri-containerd-51c54045c93bdb458990332875156a486f82ad32f2594e8d85d693fd72a69c71.scope"
      }
    ],
    "ips": [
      "10.21.0.236"
    ],
    "name": "coredns-cc6ccd49c-ts7fh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa102d2c_f4f0_474a_bca1_587fbfabf1d9.slice/cri-containerd-4ecc2573c1dd9b7795f71d75374d0422a3b6888cb66224297ee367bb7bc1374c.scope"
      }
    ],
    "ips": [
      "10.21.0.192"
    ],
    "name": "coredns-cc6ccd49c-bkcg4",
    "namespace": "kube-system"
  }
]

