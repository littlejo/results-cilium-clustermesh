CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6fef5393_e4dd_4583_ad63_9c9e0a1c7b01.slice/cri-containerd-77cac48bb523c814176bfb5fe6b498fb43b862310595f9ee3d4dee53a8b35cc9.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6fef5393_e4dd_4583_ad63_9c9e0a1c7b01.slice/cri-containerd-9301cbe573e83025ed5dd95eef0e6822085b9110d9c7bdfcb4d4635f872fdc89.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa102d2c_f4f0_474a_bca1_587fbfabf1d9.slice/cri-containerd-4ecc2573c1dd9b7795f71d75374d0422a3b6888cb66224297ee367bb7bc1374c.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa102d2c_f4f0_474a_bca1_587fbfabf1d9.slice/cri-containerd-b8416f9a95d08fa4c700c8364ed51fb816d08041e8933b3037090a7326f54db1.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3da603c_7099_4809_ac82_49c583027e34.slice/cri-containerd-89a20dd91da3ae5b777754de63d794f3d49d8a9f8624357749dc4a68ec5ffbac.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc3da603c_7099_4809_ac82_49c583027e34.slice/cri-containerd-4cad330c3c2ce44dd1be9b201691161374544fb48dea62a603d0505c26c32b74.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f6eee29_a7f5_454c_9ea2_31c723734f85.slice/cri-containerd-e9c907d5887fd0618e360a8054d78b5274fb85a15b6d72d5de865d4287259417.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7f6eee29_a7f5_454c_9ea2_31c723734f85.slice/cri-containerd-51c54045c93bdb458990332875156a486f82ad32f2594e8d85d693fd72a69c71.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3db2fce5_bb15_42f1_9b20_9ffeb2441f7e.slice/cri-containerd-1270b12a61789aba3d1a79b522815929c907bf32954b9a2cd4d6a6f2d3a4475a.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3db2fce5_bb15_42f1_9b20_9ffeb2441f7e.slice/cri-containerd-24704a6673c048e477df0841e390f78ae8ee05de3f55638621cf599153092ac6.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1565ee8f_e4a8_4d48_8dc7_6a32174f00fd.slice/cri-containerd-68c88602b793191d0d30d4afa73fb6cf38a8a04b0accfbe9e9d1c3b88456e542.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1565ee8f_e4a8_4d48_8dc7_6a32174f00fd.slice/cri-containerd-c76616212b7bddde14d381abc1a49f83410d3d9720357990bca2ace680ec03e3.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-8dec453373e15ee9e7d2b438b962be80f4a00b9d5c8b0a39d9407f3589f9255e.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-55cda79263b8263435185146c01fb93073768e2d4fb63448eefb0f234757d0cb.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-52bf61a43d05c645a59c02ae9081483a45d6c49fae22ca8fe15c06b0522292a1.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b256c13_6d54_4c79_be55_df08b7fd3d7c.slice/cri-containerd-fa094044e69d96ad9ecc092333565bee602d7b747a8269c31dbcc377171b9cf9.scope
    656      cgroup_device   multi                                          
