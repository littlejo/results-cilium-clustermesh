 08:22:54 up 37 min,  0 users,  load average: 0.27, 0.30, 0.27
