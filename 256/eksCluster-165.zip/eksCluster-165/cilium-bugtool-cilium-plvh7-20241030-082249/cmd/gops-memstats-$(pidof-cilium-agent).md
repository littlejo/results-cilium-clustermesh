alloc: 200.42MB (210158760 bytes)
total-alloc: 2.22GB (2388056424 bytes)
sys: 320.83MB (336417124 bytes)
lookups: 0
mallocs: 63041292
frees: 60907998
heap-alloc: 200.42MB (210158760 bytes)
heap-sys: 243.70MB (255541248 bytes)
heap-idle: 21.37MB (22405120 bytes)
heap-in-use: 222.34MB (233136128 bytes)
heap-released: 3.58MB (3751936 bytes)
heap-objects: 2133294
stack-in-use: 64.25MB (67371008 bytes)
stack-sys: 64.25MB (67371008 bytes)
stack-mspan-inuse: 3.46MB (3631520 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1064241 bytes)
gc-sys: 6.07MB (6360432 bytes)
next-gc: when heap-alloc >= 211.86MB (222152136 bytes)
last-gc: 2024-10-30 08:22:46.037439885 +0000 UTC
gc-pause-total: 22.77231ms
gc-pause: 133243
gc-pause-end: 1730276566037439885
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.00040059200523766004
enable-gc: true
debug-gc: false
