ip-172-31-217-164.eu-west-3.compute.internal
