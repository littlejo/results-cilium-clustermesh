markdown output at /tmp/cilium-bugtool-20241030-082250.281+0000-UTC-795993392/cmd/cilium-debuginfo-20241030-082321.692+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082250.281+0000-UTC-795993392/cmd/cilium-debuginfo-20241030-082321.692+0000-UTC.json
