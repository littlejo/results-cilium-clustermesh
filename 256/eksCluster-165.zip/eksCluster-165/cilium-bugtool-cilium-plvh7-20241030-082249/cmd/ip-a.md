1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:65:13:d8:49:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.217.164/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3501sec preferred_lft 3501sec
    inet6 fe80::865:13ff:fed8:49b7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2d:11:b0:90:1d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.255.94/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::82d:11ff:feb0:901d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:3a:cc:4a:73:23 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::203a:ccff:fe4a:7323/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:9d:12:29:66:04 brd ff:ff:ff:ff:ff:ff
    inet 10.165.0.172/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::389d:12ff:fe29:6604/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:e0:82:6c:b6:b6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f4e0:82ff:fe6c:b6b6/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:60:47:f8:70:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7060:47ff:fef8:70c9/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc9080495b1c01@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:e0:76:27:c0:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::94e0:76ff:fe27:c0e4/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb4017227c67c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:98:1f:d6:ba:11 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::2098:1fff:fed6:ba11/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce90ff17e9323@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:f4:6c:fb:e0:17 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::78f4:6cff:fefb:e017/64 scope link 
       valid_lft forever preferred_lft forever
