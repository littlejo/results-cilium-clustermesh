CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22edefd9_6caa_4b6e_a859_98fb50479039.slice/cri-containerd-32d882eafbb87a605b4f0c31e7e506096f8d52240f0d27cf3990e766296bccfa.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22edefd9_6caa_4b6e_a859_98fb50479039.slice/cri-containerd-d19885daf6da6ea6bff391782f3763a540dd49fbe35027e8497fc121aad757f5.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a5b2494_0bb1_4aef_8440_2af625bca02f.slice/cri-containerd-0fab34224b35c5545383708aae4624d4a030220bad00ed42630694da791aa600.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a5b2494_0bb1_4aef_8440_2af625bca02f.slice/cri-containerd-1e5bc5ff740fd449de9a8bca2d39f758e3e0fcf91843ee5b4b58e627910e940a.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a569b2e_e9c7_4011_84bf_07f9478c1266.slice/cri-containerd-0f991d3fbe0bc96c3122eb4dab94fc05cd1a7fbdcc5dddd5353731cde1fc9c69.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a569b2e_e9c7_4011_84bf_07f9478c1266.slice/cri-containerd-4cf607faf23e93c0ff71ed4774946f86d97381e2b90a88850eaadaf5c166a5c3.scope
    546      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1903284d_717d_4c37_949b_4b6fe15cdc3f.slice/cri-containerd-e0337b2965ed64267ac8b38a29e317486cee1e097a29f31daa9bf662df278f2b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1903284d_717d_4c37_949b_4b6fe15cdc3f.slice/cri-containerd-191517a57d3b21ea2ed6b9c1d243c081a909671c0cfa4c9cac95c4486fc63922.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod533db1f8_0bf6_4a82_a9d9_71ba0238fdec.slice/cri-containerd-0e292a7c97e919f2e3ad13b05972acfdb2ee563bb3629f21032d17a61b2b7ef5.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod533db1f8_0bf6_4a82_a9d9_71ba0238fdec.slice/cri-containerd-27f18ad8081ddfab862cab7cb2138b6243d7375e2e9591a620b2d492f5ebb010.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9c0c794_49bd_4606_8257_fa0f3c93f075.slice/cri-containerd-fe0ee6eb91a2efe672b22b8623c2923b5a61509a0beeb3fff3f4f8788d517e6b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb9c0c794_49bd_4606_8257_fa0f3c93f075.slice/cri-containerd-2974cbe10073d227912728568a750330a86c99b63da1281daa91b69ff285d481.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-cb4fe017d0d922b0e2c50f8c145404a7b0df7a892a2b35c7b26b86026a07f47a.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-d7d06165d8f478ae98d995930d99e32cdbcba4bcfd2ab9b0fb3f0b0bfdda78d3.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-a4f7d9a8998ef1542345556c2e857a2686d1955150b274152ea3f2fdc9fd5596.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-b8480537938100aefbaba38c44e2ddd0f70def93a1918ab7be773b0272539501.scope
    660      cgroup_device   multi                                          
