Endpoint ID: 351
Path: /sys/fs/bpf/tc/globals/cilium_policy_00351

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 466
Path: /sys/fs/bpf/tc/globals/cilium_policy_00466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11504013   113490    0        
Allow    Ingress     1          ANY          NONE         disabled    9907160    103963    0        
Allow    Egress      0          ANY          NONE         disabled    12066532   119128    0        


Endpoint ID: 561
Path: /sys/fs/bpf/tc/globals/cilium_policy_00561

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    125689   1443      0        
Allow    Egress      0          ANY          NONE         disabled    15198    166       0        


Endpoint ID: 618
Path: /sys/fs/bpf/tc/globals/cilium_policy_00618

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1630928   20587     0        
Allow    Ingress     1          ANY          NONE         disabled    19382     229       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 885
Path: /sys/fs/bpf/tc/globals/cilium_policy_00885

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124640   1431      0        
Allow    Egress      0          ANY          NONE         disabled    17084    187       0        


