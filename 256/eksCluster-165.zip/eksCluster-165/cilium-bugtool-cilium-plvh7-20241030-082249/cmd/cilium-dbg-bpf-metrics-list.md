REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35253     2787660     677    bpf_overlay.c
Interface                 INGRESS     629515    130291762   1132   bpf_host.c
Success                   EGRESS      15381     1205708     1694   bpf_host.c
Success                   EGRESS      266509    33956535    1308   bpf_lxc.c
Success                   EGRESS      34941     2764194     53     encap.h
Success                   INGRESS     310754    35033715    86     l3.h
Success                   INGRESS     331277    36659713    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
