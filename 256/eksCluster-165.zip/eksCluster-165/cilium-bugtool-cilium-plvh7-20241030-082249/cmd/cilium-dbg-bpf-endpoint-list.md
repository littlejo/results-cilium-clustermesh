IP ADDRESS         LOCAL ENDPOINT INFO
10.165.0.223:0     id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11   
172.31.217.164:0   (localhost)                                                                                        
10.165.0.172:0     (localhost)                                                                                        
10.165.0.38:0      id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9     
10.165.0.124:0     id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17   
172.31.255.94:0    (localhost)                                                                                        
10.165.0.42:0      id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4   
