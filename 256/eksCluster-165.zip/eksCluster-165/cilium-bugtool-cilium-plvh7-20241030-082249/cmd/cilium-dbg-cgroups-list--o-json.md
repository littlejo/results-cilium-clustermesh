[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod22edefd9_6caa_4b6e_a859_98fb50479039.slice/cri-containerd-d19885daf6da6ea6bff391782f3763a540dd49fbe35027e8497fc121aad757f5.scope"
      }
    ],
    "ips": [
      "10.165.0.223"
    ],
    "name": "coredns-cc6ccd49c-hflx7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-a4f7d9a8998ef1542345556c2e857a2686d1955150b274152ea3f2fdc9fd5596.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-b8480537938100aefbaba38c44e2ddd0f70def93a1918ab7be773b0272539501.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc7b99ee9_477f_4885_98fd_593aca97f173.slice/cri-containerd-d7d06165d8f478ae98d995930d99e32cdbcba4bcfd2ab9b0fb3f0b0bfdda78d3.scope"
      }
    ],
    "ips": [
      "10.165.0.124"
    ],
    "name": "clustermesh-apiserver-58656655d-vs9qc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7a569b2e_e9c7_4011_84bf_07f9478c1266.slice/cri-containerd-0f991d3fbe0bc96c3122eb4dab94fc05cd1a7fbdcc5dddd5353731cde1fc9c69.scope"
      }
    ],
    "ips": [
      "10.165.0.42"
    ],
    "name": "coredns-cc6ccd49c-mt7s5",
    "namespace": "kube-system"
  }
]

