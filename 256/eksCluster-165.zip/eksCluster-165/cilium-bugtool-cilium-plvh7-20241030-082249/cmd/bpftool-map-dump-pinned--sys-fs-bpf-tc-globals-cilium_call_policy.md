key: d2 01 00 00  value: 79 02 00 00
key: 31 02 00 00  value: 16 02 00 00
key: 6a 02 00 00  value: 00 02 00 00
key: 75 03 00 00  value: 0b 02 00 00
Found 4 elements
