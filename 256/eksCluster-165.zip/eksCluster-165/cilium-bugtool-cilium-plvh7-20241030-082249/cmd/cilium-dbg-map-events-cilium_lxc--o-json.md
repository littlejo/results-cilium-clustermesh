{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.974Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.217.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.974Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.255.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:24.974Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:29.210Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:29.214Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:29.276Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:29.321Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:29.365Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.064Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.064Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.064Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:08.092Z",
  "value": "id=3343  sec_id=5453708 flags=0x0000 ifindex=16  mac=3A:14:A7:3B:2E:E6 nodemac=2A:7E:B9:B2:2A:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.064Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.064Z",
  "value": "id=3343  sec_id=5453708 flags=0x0000 ifindex=16  mac=3A:14:A7:3B:2E:E6 nodemac=2A:7E:B9:B2:2A:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.064Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:09.065Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.409Z",
  "value": "id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.165.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.816Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.778Z",
  "value": "id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.781Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.781Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.782Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.757Z",
  "value": "id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.758Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.758Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.759Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.757Z",
  "value": "id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.758Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.758Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.758Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.757Z",
  "value": "id=618   sec_id=4     flags=0x0000 ifindex=10  mac=46:03:86:22:90:1A nodemac=72:60:47:F8:70:C9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.757Z",
  "value": "id=466   sec_id=5453708 flags=0x0000 ifindex=18  mac=36:62:77:37:47:6E nodemac=7A:F4:6C:FB:E0:17"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.758Z",
  "value": "id=885   sec_id=5464157 flags=0x0000 ifindex=12  mac=E2:D6:B0:CB:7E:DE nodemac=96:E0:76:27:C0:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.165.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.758Z",
  "value": "id=561   sec_id=5464157 flags=0x0000 ifindex=14  mac=8E:2A:37:B4:04:9A nodemac=22:98:1F:D6:BA:11"
}

