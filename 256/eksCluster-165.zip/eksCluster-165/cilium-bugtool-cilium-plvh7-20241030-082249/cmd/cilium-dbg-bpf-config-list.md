KEY             VALUE
AgentLiveness   1941527279925
UTimeOffset     3379442695312500
