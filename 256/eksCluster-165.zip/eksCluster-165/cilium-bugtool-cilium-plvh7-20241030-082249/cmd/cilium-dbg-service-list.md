ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.145.31:443 (active)     
                                          2 => 172.31.205.146:443 (active)    
2    10.100.76.237:443     ClusterIP      1 => 172.31.217.164:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.165.0.42:53 (active)        
                                          2 => 10.165.0.223:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.165.0.42:9153 (active)      
                                          2 => 10.165.0.223:9153 (active)     
5    10.100.165.144:2379   ClusterIP      1 => 10.165.0.124:2379 (active)     
