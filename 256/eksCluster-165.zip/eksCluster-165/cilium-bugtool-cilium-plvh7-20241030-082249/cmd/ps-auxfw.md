USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         690  0.0  0.2 1240432 16204 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         707  0.0  0.2 1240432 16204 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         677  0.0  0.0 1228744 3976 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         676  0.0  0.0 1228744 3716 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  4.7 1605888 380124 ?      Ssl  08:01   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1229744 8016 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
