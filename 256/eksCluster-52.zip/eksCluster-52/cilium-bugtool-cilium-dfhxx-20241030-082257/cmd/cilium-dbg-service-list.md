ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.220.185:443 (active)    
                                         2 => 172.31.186.3:443 (active)      
2    10.100.162.228:443   ClusterIP      1 => 172.31.153.228:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.52.0.210:53 (active)        
                                         2 => 10.52.0.5:53 (active)          
4    10.100.0.10:9153     ClusterIP      1 => 10.52.0.210:9153 (active)      
                                         2 => 10.52.0.5:9153 (active)        
5    10.100.220.93:2379   ClusterIP      1 => 10.52.0.25:2379 (active)       
