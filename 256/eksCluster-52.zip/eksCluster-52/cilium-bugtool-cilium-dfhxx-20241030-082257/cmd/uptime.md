 08:22:58 up 33 min,  0 users,  load average: 0.26, 0.18, 0.13
