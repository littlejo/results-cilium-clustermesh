REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34657     2739434     677    bpf_overlay.c
Interface                 INGRESS     596505    125936096   1132   bpf_host.c
Success                   EGRESS      15237     1196180     1694   bpf_host.c
Success                   EGRESS      257278    31654999    1308   bpf_lxc.c
Success                   EGRESS      34538     2730799     53     encap.h
Success                   INGRESS     297708    32889749    86     l3.h
Success                   INGRESS     317779    34477049    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
