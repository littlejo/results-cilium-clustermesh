alloc: 157.33MB (164969848 bytes)
total-alloc: 2.19GB (2348777920 bytes)
sys: 304.77MB (319574372 bytes)
lookups: 0
mallocs: 62612131
frees: 60911989
heap-alloc: 157.33MB (164969848 bytes)
heap-sys: 227.44MB (238485504 bytes)
heap-idle: 46.41MB (48668672 bytes)
heap-in-use: 181.02MB (189816832 bytes)
heap-released: 512.00KB (524288 bytes)
heap-objects: 1700142
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.09MB (3234880 bytes)
stack-mspan-sys: 3.80MB (3982080 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1077697 bytes)
gc-sys: 5.98MB (6270488 bytes)
next-gc: when heap-alloc >= 209.64MB (219825176 bytes)
last-gc: 2024-10-30 08:22:21.9970808 +0000 UTC
gc-pause-total: 13.062698ms
gc-pause: 107347
gc-pause-end: 1730276541997080800
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003875348863801445
enable-gc: true
debug-gc: false
