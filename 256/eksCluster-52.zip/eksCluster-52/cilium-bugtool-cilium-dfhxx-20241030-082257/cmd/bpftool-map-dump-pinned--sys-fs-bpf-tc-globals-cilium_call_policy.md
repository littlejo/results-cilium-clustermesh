key: 81 01 00 00  value: 73 02 00 00
key: 80 02 00 00  value: 03 02 00 00
key: 5d 07 00 00  value: 19 02 00 00
key: 8f 08 00 00  value: ff 01 00 00
Found 4 elements
