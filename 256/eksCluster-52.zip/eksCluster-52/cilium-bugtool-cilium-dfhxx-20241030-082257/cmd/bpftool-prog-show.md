29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:49:01+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:02+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:49:05+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:49:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:49:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:49:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:22+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:22+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name tail_handle_ipv4  tag 9322998058338132  gpl
	loaded_at 2024-10-30T07:57:33+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:57:33+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:57:33+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:57:33+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 127
504: sched_cls  name cil_from_container  tag 08ef7c7220e82c5c  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 153
505: sched_cls  name tail_handle_ipv4_cont  tag 3590fe46a91b5e5c  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 154
506: sched_cls  name tail_ipv4_ct_egress  tag 2c145b14c42f684a  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 155
508: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 157
509: sched_cls  name tail_handle_ipv4  tag 4da37730c00e86dc  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 158
510: sched_cls  name tail_ipv4_ct_ingress  tag b716597a213a2a1e  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 159
511: sched_cls  name handle_policy  tag fe121080ffff36d3  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 160
512: sched_cls  name tail_ipv4_to_endpoint  tag 792f2091cca2008c  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 161
513: sched_cls  name __send_drop_notify  tag 6676f23fa42b88b5  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 162
514: sched_cls  name tail_handle_arp  tag 63c25da64f739fc9  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 163
515: sched_cls  name handle_policy  tag 8b99482b0d742dd7  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 165
516: sched_cls  name __send_drop_notify  tag 453152737f2ab14b  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 166
517: sched_cls  name tail_handle_arp  tag 6bd0ff3c6fc41f59  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 167
518: sched_cls  name cil_from_container  tag 6891498f396ab5b2  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,76
	btf_id 168
519: sched_cls  name tail_ipv4_ct_ingress  tag d2e3f0ea2b5d31c3  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 169
520: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 170
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name tail_ipv4_to_endpoint  tag 8d01db9177a25b99  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 171
526: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 172
527: sched_cls  name tail_handle_ipv4  tag 5778022d22093256  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 173
528: sched_cls  name tail_handle_ipv4_cont  tag 77174b383dc7b50c  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 174
530: sched_cls  name tail_ipv4_ct_egress  tag 2c145b14c42f684a  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 177
531: sched_cls  name tail_ipv4_to_endpoint  tag 3907d7603f400904  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,101,39,113,40,37,38
	btf_id 178
532: sched_cls  name tail_handle_ipv4  tag 9b77d5f887a69e5c  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 179
533: sched_cls  name __send_drop_notify  tag 2d19f7de07da7823  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 180
534: sched_cls  name tail_handle_ipv4_cont  tag c1d9c275ace51d65  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,101,82,83,39,76,74,77,113,40,37,38,81
	btf_id 181
535: sched_cls  name tail_handle_arp  tag d9214bb1620e72d9  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 182
536: sched_cls  name cil_from_container  tag 7433b127d0082bf9  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 183
537: sched_cls  name handle_policy  tag 32d619eff1b351de  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,101,39,84,75,40,37,38
	btf_id 184
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 185
539: sched_cls  name tail_ipv4_ct_ingress  tag 41e3548cd25e11cb  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 186
541: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
544: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
545: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
548: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
549: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
552: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
554: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 190
555: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 191
556: sched_cls  name __send_drop_notify  tag 00245d8f5ee2720b  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
557: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 193
559: sched_cls  name tail_handle_ipv4_from_host  tag 0fa83f3ea7ef8292  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 195
560: sched_cls  name __send_drop_notify  tag 00245d8f5ee2720b  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 197
563: sched_cls  name tail_handle_ipv4_from_host  tag 0fa83f3ea7ef8292  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 200
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
566: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 203
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 205
569: sched_cls  name __send_drop_notify  tag 00245d8f5ee2720b  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
572: sched_cls  name tail_handle_ipv4_from_host  tag 0fa83f3ea7ef8292  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 210
573: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 211
575: sched_cls  name tail_handle_ipv4_from_host  tag 0fa83f3ea7ef8292  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 214
576: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 215
577: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 216
579: sched_cls  name __send_drop_notify  tag 00245d8f5ee2720b  gpl
	loaded_at 2024-10-30T07:57:36+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
620: sched_cls  name tail_handle_arp  tag 4a4563a8db4d3d17  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 233
621: sched_cls  name cil_from_container  tag 882976e9f6788fb7  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 234
622: sched_cls  name tail_ipv4_ct_egress  tag b736c8d0ec2291be  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 235
623: sched_cls  name tail_ipv4_to_endpoint  tag 14cbde5d1d23f3d5  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 236
624: sched_cls  name tail_handle_ipv4_cont  tag ad3e3da97bdeb481  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 237
625: sched_cls  name tail_ipv4_ct_ingress  tag 70364a4221281f75  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
626: sched_cls  name __send_drop_notify  tag bb8db4c840014180  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
627: sched_cls  name handle_policy  tag 39f9ed5798faac6c  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 240
628: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 241
629: sched_cls  name tail_handle_ipv4  tag 533eb17b2c8c28c5  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 242
631: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
634: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
647: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
650: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
655: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
658: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
