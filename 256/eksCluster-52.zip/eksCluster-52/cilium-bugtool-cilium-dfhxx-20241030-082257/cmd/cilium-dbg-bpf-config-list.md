KEY             VALUE
AgentLiveness   2042214925529
UTimeOffset     3379442457031250
