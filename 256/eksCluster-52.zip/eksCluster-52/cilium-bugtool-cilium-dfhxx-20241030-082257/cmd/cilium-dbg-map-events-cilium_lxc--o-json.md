{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.656Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.141.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.656Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.153.228:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:30.656Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.267Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.269Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.391Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.470Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:35.503Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.390Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.390Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.390Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:20.423Z",
  "value": "id=1656  sec_id=1745901 flags=0x0000 ifindex=16  mac=F6:01:55:A4:3A:22 nodemac=0E:53:36:19:30:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.390Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.391Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.391Z",
  "value": "id=1656  sec_id=1745901 flags=0x0000 ifindex=16  mac=F6:01:55:A4:3A:22 nodemac=0E:53:36:19:30:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:21.392Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:42.067Z",
  "value": "id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.52.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.466Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.397Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.397Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.397Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:33.398Z",
  "value": "id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.451Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.456Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.457Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:34.457Z",
  "value": "id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.439Z",
  "value": "id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.439Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.439Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:35.440Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.210:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.440Z",
  "value": "id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.440Z",
  "value": "id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.440Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.52.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:36.440Z",
  "value": "id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D"
}

