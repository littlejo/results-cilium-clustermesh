IP ADDRESS         LOCAL ENDPOINT INFO
172.31.141.47:0    (localhost)                                                                                        
10.52.0.147:0      (localhost)                                                                                        
10.52.0.199:0      id=640   sec_id=4     flags=0x0000 ifindex=10  mac=DE:CF:0D:3F:72:9D nodemac=C2:F2:F5:77:CF:39     
10.52.0.210:0      id=2191  sec_id=1739292 flags=0x0000 ifindex=14  mac=62:A0:1B:9E:65:C2 nodemac=32:83:05:B3:96:D9   
10.52.0.5:0        id=1885  sec_id=1739292 flags=0x0000 ifindex=12  mac=4A:66:9A:14:EB:B8 nodemac=0A:EF:89:99:61:73   
172.31.153.228:0   (localhost)                                                                                        
10.52.0.25:0       id=385   sec_id=1745901 flags=0x0000 ifindex=18  mac=66:5C:35:BF:D5:AF nodemac=86:4F:37:80:92:3D   
