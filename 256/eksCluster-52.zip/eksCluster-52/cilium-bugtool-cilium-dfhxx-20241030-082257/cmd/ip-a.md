1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:37:a4:bc:eb:5b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.153.228/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3371sec preferred_lft 3371sec
    inet6 fe80::437:a4ff:febc:eb5b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:95:d6:05:ea:b5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.141.47/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::495:d6ff:fe05:eab5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ad:94:0d:e5:bb brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0ad:94ff:fe0d:e5bb/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:b7:e0:ac:28:b4 brd ff:ff:ff:ff:ff:ff
    inet 10.52.0.147/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::10b7:e0ff:feac:28b4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ae:8a:8e:bc:c4:c3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac8a:8eff:febc:c4c3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:f2:f5:77:cf:39 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c0f2:f5ff:fe77:cf39/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca58b4413b797@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:ef:89:99:61:73 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8ef:89ff:fe99:6173/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc4b56dac97421@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:83:05:b3:96:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::3083:5ff:feb3:96d9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc4a969fcc739e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 86:4f:37:80:92:3d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::844f:37ff:fe80:923d/64 scope link 
       valid_lft forever preferred_lft forever
