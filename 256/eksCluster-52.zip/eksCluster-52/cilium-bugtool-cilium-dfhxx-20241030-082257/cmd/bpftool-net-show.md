xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 576
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 566
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 555
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 518
lxca58b4413b797(12) clsact/ingress cil_from_container-lxca58b4413b797 id 536
lxc4b56dac97421(14) clsact/ingress cil_from_container-lxc4b56dac97421 id 504
lxc4a969fcc739e(18) clsact/ingress cil_from_container-lxc4a969fcc739e id 621

flow_dissector:

netfilter:

