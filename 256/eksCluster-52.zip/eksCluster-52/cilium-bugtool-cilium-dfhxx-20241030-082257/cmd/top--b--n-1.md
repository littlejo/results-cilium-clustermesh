top - 08:22:58 up 33 min,  0 users,  load average: 0.26, 0.18, 0.13
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 45.2 us, 38.7 sy,  0.0 ni, 12.9 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4474.5 free,   1194.7 used,   2145.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6434.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 376428  77932 S  13.3   4.7   0:52.41 cilium-+
    634 root      20   0 1240432  16484  11484 S   6.7   0.2   0:00.03 cilium-+
    417 root      20   0 1229488   8164   3904 S   0.0   0.1   0:01.14 cilium-+
    669 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    693 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    695 root      20   0 1616264   9128   6420 R   0.0   0.1   0:00.00 runc:[2+
    703 root      20   0 1228488   1756   1456 S   0.0   0.0   0:00.00 gops
    710 root      20   0 1267208   3272   1820 S   0.0   0.0   0:00.00 runc:[2+
    713 root      20   0 1616264   9180   6452 D   0.0   0.1   0:00.00 runc:[2+
    725 root      20   0   13060   1228     60 R   0.0   0.0   0:00.00 runc:[2+
