[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-15e27e44b7550456009a7becee50237ba28604aa01fef195b40d28e4d607820b.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-8d1ec7590879083de8d0163fc667809afb0e6624a5120b7dd12da47660c4a040.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-7d1cc969fd4c8fdce13cba5c011a9ecf8ba4971f4e2796eb42ca0e7ec9e90ff2.scope"
      }
    ],
    "ips": [
      "10.52.0.25"
    ],
    "name": "clustermesh-apiserver-5ffdf4ff85-8v85q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78b8c74c_6121_4742_94eb_0276ceb14d4d.slice/cri-containerd-ae788cce7bce38371373f9ed2c3c71a9829ce71958b3556ce2dccff56d087cff.scope"
      }
    ],
    "ips": [
      "10.52.0.5"
    ],
    "name": "coredns-cc6ccd49c-jmzvt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbeb4864_fdd3_4466_b14f_d97468f6b24f.slice/cri-containerd-72f1c5ca3aa30626746eeac051a6364675a5200c535a08393bb65e253551d9b4.scope"
      }
    ],
    "ips": [
      "10.52.0.210"
    ],
    "name": "coredns-cc6ccd49c-m9nc8",
    "namespace": "kube-system"
  }
]

