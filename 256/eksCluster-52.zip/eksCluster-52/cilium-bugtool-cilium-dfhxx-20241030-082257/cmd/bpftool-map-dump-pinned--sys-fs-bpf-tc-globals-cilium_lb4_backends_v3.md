key: 05 00 00 00  value: ac 1f 99 e4 10 94 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f dc b9 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 34 00 d2 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 34 00 05 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 34 00 05 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 34 00 d2 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ba 03 01 bb 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 34 00 19 09 4b 00 00  00 00 00 00
Found 8 elements
