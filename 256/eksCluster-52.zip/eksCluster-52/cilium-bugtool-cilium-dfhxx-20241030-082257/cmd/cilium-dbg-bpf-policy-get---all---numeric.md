Endpoint ID: 172
Path: /sys/fs/bpf/tc/globals/cilium_policy_00172

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 385
Path: /sys/fs/bpf/tc/globals/cilium_policy_00385

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10378427   106805    0        
Allow    Ingress     1          ANY          NONE         disabled    9889020    103850    0        
Allow    Egress      0          ANY          NONE         disabled    11930795   120926    0        


Endpoint ID: 640
Path: /sys/fs/bpf/tc/globals/cilium_policy_00640

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1592062   20129     0        
Allow    Ingress     1          ANY          NONE         disabled    22246     261       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1885
Path: /sys/fs/bpf/tc/globals/cilium_policy_01885

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    146104   1687      0        
Allow    Egress      0          ANY          NONE         disabled    19889    220       0        


Endpoint ID: 2191
Path: /sys/fs/bpf/tc/globals/cilium_policy_02191

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147168   1694      0        
Allow    Egress      0          ANY          NONE         disabled    17866    197       0        


