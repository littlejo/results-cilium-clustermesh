CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbeb4864_fdd3_4466_b14f_d97468f6b24f.slice/cri-containerd-72f1c5ca3aa30626746eeac051a6364675a5200c535a08393bb65e253551d9b4.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfbeb4864_fdd3_4466_b14f_d97468f6b24f.slice/cri-containerd-eed7bee1f2f34fa3d7ab996a8633f416aac1fab52d4aa0e88de6025a814ee566.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78b8c74c_6121_4742_94eb_0276ceb14d4d.slice/cri-containerd-ae788cce7bce38371373f9ed2c3c71a9829ce71958b3556ce2dccff56d087cff.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78b8c74c_6121_4742_94eb_0276ceb14d4d.slice/cri-containerd-056d2a956db8fafa0b3ddabbf1ffd87c8c48f340e5c99e290f3d332cad6296e2.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15c16806_48be_4749_9f7d_bbafcb2de297.slice/cri-containerd-4e09e597a238d90a60e5e4139a068808cb9ce68b0562edc7202c31cb16455981.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod15c16806_48be_4749_9f7d_bbafcb2de297.slice/cri-containerd-ad7bb7b340a65dc5891c1119dae64a0e4421ac2b067c5e9cb3b5400bbc14ab07.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc249c0e_d8a0_4090_8519_8afd103941d2.slice/cri-containerd-99244e0bf7e8f09991ff58f53f24d6574296c6b56ee809104be3f5008861666d.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc249c0e_d8a0_4090_8519_8afd103941d2.slice/cri-containerd-25311e71348e8e2b1a5198784511a20d66a283be75c39e314c8d5fb4bdd02461.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-15e27e44b7550456009a7becee50237ba28604aa01fef195b40d28e4d607820b.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-da8abc3797276bb8d7a13657a847387d356e4413ab24cd6467daf3bfbdf4d863.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-8d1ec7590879083de8d0163fc667809afb0e6624a5120b7dd12da47660c4a040.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc2220791_d3da_412c_821a_4d3abe7a7c78.slice/cri-containerd-7d1cc969fd4c8fdce13cba5c011a9ecf8ba4971f4e2796eb42ca0e7ec9e90ff2.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23512994_32d3_4738_a251_a190058a48a4.slice/cri-containerd-3cead81fad94d65b48279d5527ba27ba426584423e31b179e6bc49c8048542f2.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod23512994_32d3_4738_a251_a190058a48a4.slice/cri-containerd-f8b684e4a70c61cfac6bf5b6680f6594fd8893c974457be01cb5f4382f6e0bfb.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eb869a2_467c_4307_8887_06c1405ca5f1.slice/cri-containerd-79935040694b334e9fd3cecc5497fad4d0693a50810e85573c998e4e1718a6cc.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3eb869a2_467c_4307_8887_06c1405ca5f1.slice/cri-containerd-7443da0ae83ed8028446e375732f66e3dca44a9a2235ac4d86bfd256c28c851c.scope
    103      cgroup_device   multi                                          
