xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 582
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 569
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 506
lxc153eab635e9e(12) clsact/ingress cil_from_container-lxc153eab635e9e id 538
lxca3534f44a191(14) clsact/ingress cil_from_container-lxca3534f44a191 id 519
lxcc7dced2e9b53(18) clsact/ingress cil_from_container-lxcc7dced2e9b53 id 624

flow_dissector:

netfilter:

