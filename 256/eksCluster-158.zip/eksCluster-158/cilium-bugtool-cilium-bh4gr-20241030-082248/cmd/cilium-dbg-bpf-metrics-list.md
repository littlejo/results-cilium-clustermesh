REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37618     2984769     677    bpf_overlay.c
Interface                 INGRESS     676903    136110250   1132   bpf_host.c
Success                   EGRESS      17671     1396003     1694   bpf_host.c
Success                   EGRESS      290189    35655664    1308   bpf_lxc.c
Success                   EGRESS      38888     3072605     53     encap.h
Success                   INGRESS     335214    38048210    86     l3.h
Success                   INGRESS     355813    39681088    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
