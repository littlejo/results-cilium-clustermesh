CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0fca7c_08f5_42aa_84e2_1d5b935e08ca.slice/cri-containerd-75d6eae71646071125a866f40fe376b6acca65fece16abd07cfac6ea950f30ca.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0fca7c_08f5_42aa_84e2_1d5b935e08ca.slice/cri-containerd-7c995ed5e567fca6a35893407ac8ff52e06ae139360388711fd35a7073005977.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd43b0e2c_85f7_4810_9921_e649206f29ab.slice/cri-containerd-61f3335a54132d3f767124b4188b510eaf7095b7adea891249cf99edcda39920.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd43b0e2c_85f7_4810_9921_e649206f29ab.slice/cri-containerd-35c39109e509e3605a52b3f7260a9c5b516a0720fcda330d3ebb857ba235775b.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc76f4609_8744_4fec_a38b_e46f36ddb579.slice/cri-containerd-73fe5b1afd8e577b2e842b27941d1091c04ce8ad0a687661abd9a38be9166e73.scope
    530      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc76f4609_8744_4fec_a38b_e46f36ddb579.slice/cri-containerd-5bf1f86eac0f20d07acc31177aa68d58513cc99c5abfb91f64601a1fe3412daf.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b133aa7_10df_4406_b85e_a63270349f9b.slice/cri-containerd-d37cef2e547f22256d793b19ec54c775aa3cf3920582dbee43358ae4add346c5.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6b133aa7_10df_4406_b85e_a63270349f9b.slice/cri-containerd-9da8c3c1e39b350e79828cd60745c5b1f9723941210cd3e5c4314ed9357d3167.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35828c06_33b1_4aba_9010_0e8be5ca8f13.slice/cri-containerd-e29a0f1bedab8cedd35a22b556dd47fbf003adce5b27974ec85e9be6bcef5079.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod35828c06_33b1_4aba_9010_0e8be5ca8f13.slice/cri-containerd-9efaa3c6aea159339d33a229fcf6a60f32981580b5b95b3d24e91c296f66ae14.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d96b852_e147_44c7_8fdf_02f7b863797b.slice/cri-containerd-5eca4d8e7f998da5900bf04a99f9bf798c035a73b5403e440c3f130842ab83f5.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d96b852_e147_44c7_8fdf_02f7b863797b.slice/cri-containerd-ff6515e01e7200d5eec3f00a36f0b0da97ac16e995f4e4408a9a1115206d6c88.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-3ea41e559ee7a4bb72ea10fac6be6b35fc20ffd6889389a8a027e5b0ba5dce3d.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-5b010f8af283f49e05e8c13a3e117cfe0cc31742f5ffda086936a466e7422610.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-1ff129d8b1234ab14008e372d715fbe8e2e875c2f95b249e46d2a6181d541f13.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-966194c0db05c307022d585499e58667913b1a1bb7b72c970574588b747a031b.scope
    637      cgroup_device   multi                                          
