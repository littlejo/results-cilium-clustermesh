ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.185.116:443 (active)   
                                          2 => 172.31.226.96:443 (active)    
2    10.100.113.218:443    ClusterIP      1 => 172.31.137.12:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.158.0.16:53 (active)       
                                          2 => 10.158.0.162:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.158.0.16:9153 (active)     
                                          2 => 10.158.0.162:9153 (active)    
5    10.100.202.113:2379   ClusterIP      1 => 10.158.0.74:2379 (active)     
