top - 08:22:49 up 32 min,  0 users,  load average: 0.10, 0.21, 0.24
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4434.3 free,   1232.9 used,   2147.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6396.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606208 392120  78524 S  66.7   4.9   0:49.16 cilium-+
    640 root      20   0 1229640  34288   4004 S  26.7   0.4   0:00.04 gops
    406 root      20   0 1229744   7664   3836 S   0.0   0.1   0:01.11 cilium-+
    644 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    652 root      20   0 1229000   4760   3876 S   0.0   0.1   0:00.00 gops
    663 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    697 root      20   0 1240432  16712  11548 S   0.0   0.2   0:00.02 cilium-+
    723 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    736 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    746 root      20   0 1242164   3948   3524 S   0.0   0.0   0:00.00 hubble
    751 root      20   0 1240432  16712  11548 R   0.0   0.2   0:00.00 cilium-+
