KEY             VALUE
AgentLiveness   1966603012197
UTimeOffset     3379442644531250
