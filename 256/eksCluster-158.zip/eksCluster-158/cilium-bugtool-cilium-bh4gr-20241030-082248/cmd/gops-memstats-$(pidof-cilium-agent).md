alloc: 164.99MB (173001968 bytes)
total-alloc: 2.37GB (2544652176 bytes)
sys: 328.89MB (344871268 bytes)
lookups: 0
mallocs: 65266567
frees: 63692742
heap-alloc: 164.99MB (173001968 bytes)
heap-sys: 250.88MB (263069696 bytes)
heap-idle: 52.92MB (55492608 bytes)
heap-in-use: 197.96MB (207577088 bytes)
heap-released: 2.02MB (2113536 bytes)
heap-objects: 1573825
stack-in-use: 65.09MB (68255744 bytes)
stack-sys: 65.09MB (68255744 bytes)
stack-mspan-inuse: 3.14MB (3291840 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.24MB (1304849 bytes)
gc-sys: 5.86MB (6147512 bytes)
next-gc: when heap-alloc >= 212.51MB (222833832 bytes)
last-gc: 2024-10-30 08:22:59.768051475 +0000 UTC
gc-pause-total: 9.650532ms
gc-pause: 80174
gc-pause-end: 1730276579768051475
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.000417106986049866
enable-gc: true
debug-gc: false
