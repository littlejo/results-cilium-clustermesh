[
  {
    "containers": [
      {
        "cgroup-id": 7746,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc76f4609_8744_4fec_a38b_e46f36ddb579.slice/cri-containerd-5bf1f86eac0f20d07acc31177aa68d58513cc99c5abfb91f64601a1fe3412daf.scope"
      }
    ],
    "ips": [
      "10.158.0.162"
    ],
    "name": "coredns-cc6ccd49c-svcn8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7830,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f0fca7c_08f5_42aa_84e2_1d5b935e08ca.slice/cri-containerd-75d6eae71646071125a866f40fe376b6acca65fece16abd07cfac6ea950f30ca.scope"
      }
    ],
    "ips": [
      "10.158.0.16"
    ],
    "name": "coredns-cc6ccd49c-bn9gr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-3ea41e559ee7a4bb72ea10fac6be6b35fc20ffd6889389a8a027e5b0ba5dce3d.scope"
      },
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-5b010f8af283f49e05e8c13a3e117cfe0cc31742f5ffda086936a466e7422610.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a022b98_a74a_4f0e_885d_ae2dff8a7307.slice/cri-containerd-1ff129d8b1234ab14008e372d715fbe8e2e875c2f95b249e46d2a6181d541f13.scope"
      }
    ],
    "ips": [
      "10.158.0.74"
    ],
    "name": "clustermesh-apiserver-69f7644f89-zlbkz",
    "namespace": "kube-system"
  }
]

