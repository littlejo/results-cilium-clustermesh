1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5f:67:7e:a6:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.137.12/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3474sec preferred_lft 3474sec
    inet6 fe80::45f:67ff:fe7e:a615/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:07:36:21:1c:97 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.150.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::407:36ff:fe21:1c97/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:f7:55:9a:22:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::60f7:55ff:fe9a:22f1/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:58:95:8c:f6:7e brd ff:ff:ff:ff:ff:ff
    inet 10.158.0.185/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7858:95ff:fe8c:f67e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:56:1b:fc:b6:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f056:1bff:fefc:b6f1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:48:7e:9c:fc:5a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c448:7eff:fe9c:fc5a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc153eab635e9e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:2f:23:8f:2f:58 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::882f:23ff:fe8f:2f58/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca3534f44a191@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:d0:c5:e6:88:db brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::38d0:c5ff:fee6:88db/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc7dced2e9b53@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:1c:8b:99:ca:ef brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b81c:8bff:fe99:caef/64 scope link 
       valid_lft forever preferred_lft forever
