IP ADDRESS        LOCAL ENDPOINT INFO
10.158.0.211:0    id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A     
172.31.150.95:0   (localhost)                                                                                        
10.158.0.74:0     id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF   
10.158.0.185:0    (localhost)                                                                                        
10.158.0.162:0    id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58   
10.158.0.16:0     id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB   
172.31.137.12:0   (localhost)                                                                                        
