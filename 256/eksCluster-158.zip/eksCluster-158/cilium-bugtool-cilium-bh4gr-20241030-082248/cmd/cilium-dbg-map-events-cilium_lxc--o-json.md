{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.044Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.137.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.044Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.150.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.044Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:14.466Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:14.479Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:14.570Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:14.624Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:14.683Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.290Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.291Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.291Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.320Z",
  "value": "id=140   sec_id=5217356 flags=0x0000 ifindex=16  mac=1A:51:AC:90:3B:15 nodemac=DE:94:77:FF:F9:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:59.321Z",
  "value": "id=140   sec_id=5217356 flags=0x0000 ifindex=16  mac=1A:51:AC:90:3B:15 nodemac=DE:94:77:FF:F9:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.289Z",
  "value": "id=140   sec_id=5217356 flags=0x0000 ifindex=16  mac=1A:51:AC:90:3B:15 nodemac=DE:94:77:FF:F9:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.289Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.290Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.290Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:30.339Z",
  "value": "id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.158.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:36.977Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.611Z",
  "value": "id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.612Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.612Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.613Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.615Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.615Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.616Z",
  "value": "id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.616Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.616Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.616Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.616Z",
  "value": "id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.617Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.617Z",
  "value": "id=362   sec_id=5224916 flags=0x0000 ifindex=12  mac=C6:8A:1C:D0:A1:69 nodemac=8A:2F:23:8F:2F:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.617Z",
  "value": "id=1041  sec_id=5217356 flags=0x0000 ifindex=18  mac=C2:48:C3:19:42:BD nodemac=BA:1C:8B:99:CA:EF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.211:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.617Z",
  "value": "id=2090  sec_id=4     flags=0x0000 ifindex=10  mac=D2:74:FF:B0:7B:00 nodemac=C6:48:7E:9C:FC:5A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.158.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.617Z",
  "value": "id=1429  sec_id=5224916 flags=0x0000 ifindex=14  mac=66:D8:89:64:35:01 nodemac=3A:D0:C5:E6:88:DB"
}

