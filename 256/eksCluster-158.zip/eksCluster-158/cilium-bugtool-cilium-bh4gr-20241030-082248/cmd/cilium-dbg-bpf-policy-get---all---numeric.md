Endpoint ID: 362
Path: /sys/fs/bpf/tc/globals/cilium_policy_00362

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    127549   1464      0        
Allow    Egress      0          ANY          NONE         disabled    16995    185       0        


Endpoint ID: 1041
Path: /sys/fs/bpf/tc/globals/cilium_policy_01041

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11461923   115816    0        
Allow    Ingress     1          ANY          NONE         disabled    11305213   119645    0        
Allow    Egress      0          ANY          NONE         disabled    15089615   146739    0        


Endpoint ID: 1332
Path: /sys/fs/bpf/tc/globals/cilium_policy_01332

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1429
Path: /sys/fs/bpf/tc/globals/cilium_policy_01429

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    126958   1459      0        
Allow    Egress      0          ANY          NONE         disabled    17437    190       0        


Endpoint ID: 2090
Path: /sys/fs/bpf/tc/globals/cilium_policy_02090

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1637612   20658     0        
Allow    Ingress     1          ANY          NONE         disabled    20451     243       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


