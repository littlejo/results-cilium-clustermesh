key: 6a 01 00 00  value: 19 02 00 00
key: 11 04 00 00  value: 73 02 00 00
key: 95 05 00 00  value: 08 02 00 00
key: 2a 08 00 00  value: 01 02 00 00
Found 4 elements
