[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb428078_cd2b_4a36_9b59_6466febc9d3a.slice/cri-containerd-1960cf409625dffab1f574932fb0964c5600c6c717fa00edaaf6eec3c8b0379e.scope"
      }
    ],
    "ips": [
      "10.245.0.128"
    ],
    "name": "coredns-cc6ccd49c-rbp62",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08f0e62d_ec44_4cc9_b7db_6829a1dc194a.slice/cri-containerd-52b9f70cbc41ee115fd5062038e78f843885134fce1f98000cb7c8be3b7e1e75.scope"
      }
    ],
    "ips": [
      "10.245.0.252"
    ],
    "name": "coredns-cc6ccd49c-pgkng",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-0144d90b3d44ea13e741360384a0a589e4d23e27e439520b6d2321f3ad5aef72.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-7feb46c5e10477e39dff609439aee79c49c506f0a90ce2d6ff010c702f830ef1.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-3b7d620622caccc14734ecf4c1b7e1227c6aef0cb264cd1658d2dc43223b0cd6.scope"
      }
    ],
    "ips": [
      "10.245.0.187"
    ],
    "name": "clustermesh-apiserver-c8c9c7567-fcslt",
    "namespace": "kube-system"
  }
]

