CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod930c3d87_90f4_405d_b746_a07caba8c23c.slice/cri-containerd-f16986efa8cbb12839e6445e1c50f19b449382b72a5dfd5426d42ff13323eecc.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod930c3d87_90f4_405d_b746_a07caba8c23c.slice/cri-containerd-145ee9efe8c1755ea3d0255ce614b9375077500931b253324a496ba1df5098a8.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08f0e62d_ec44_4cc9_b7db_6829a1dc194a.slice/cri-containerd-52b9f70cbc41ee115fd5062038e78f843885134fce1f98000cb7c8be3b7e1e75.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod08f0e62d_ec44_4cc9_b7db_6829a1dc194a.slice/cri-containerd-426be5f70fc6947f5f79b0732f4835ad2189d523d210849e4a0d4f1a9f3b9aa3.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb428078_cd2b_4a36_9b59_6466febc9d3a.slice/cri-containerd-1960cf409625dffab1f574932fb0964c5600c6c717fa00edaaf6eec3c8b0379e.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb428078_cd2b_4a36_9b59_6466febc9d3a.slice/cri-containerd-b96c6696e143a85e8639967886364f38aa672272f167ad38289da612428872da.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40116201_9f22_4626_82fb_948d9f91ec52.slice/cri-containerd-8a09fc1a73d01eb8fe2a9adc3feaa79f0637b9e874fe095162fc1c51607b85f2.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40116201_9f22_4626_82fb_948d9f91ec52.slice/cri-containerd-87b2f72aaa3d8be87b2cd8350f51b6e1ae02bafec9535832842cd089d1e9c645.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda08d8c04_cd43_4604_aed3_3569848f370c.slice/cri-containerd-d0154756b404e1c1fdc0e4d1bac9ce02588c57fc17ebcde6b59b4e0e040d40de.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda08d8c04_cd43_4604_aed3_3569848f370c.slice/cri-containerd-677f851d65af1efd36474a6ec9be2a6e91f066bceb180f96d22e4daba13dba39.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-acfcb7a65b0f4e005ed298ed49cc64c6a24b285b8ba7863e7189d6f0f017faee.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-0144d90b3d44ea13e741360384a0a589e4d23e27e439520b6d2321f3ad5aef72.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-7feb46c5e10477e39dff609439aee79c49c506f0a90ce2d6ff010c702f830ef1.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod888f87f5_3d11_4888_9f53_a50fddeeef7d.slice/cri-containerd-3b7d620622caccc14734ecf4c1b7e1227c6aef0cb264cd1658d2dc43223b0cd6.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8bd6183_1670_4073_9cb4_2892f6a28b73.slice/cri-containerd-0081fca9fa55c9d9ea2d6748fe6714161355c4b8d2687c4aa2231a3b5845e502.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda8bd6183_1670_4073_9cb4_2892f6a28b73.slice/cri-containerd-4b9044e42d6e3cab6461674bc02d2d33d5eaef1b9d5fcbbc2acc18a0871608a4.scope
    95       cgroup_device   multi                                          
