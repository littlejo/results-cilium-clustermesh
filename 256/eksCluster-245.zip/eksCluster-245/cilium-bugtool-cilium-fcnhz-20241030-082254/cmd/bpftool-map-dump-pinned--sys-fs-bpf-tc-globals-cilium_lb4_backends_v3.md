key: 01 00 00 00  value: ac 1f b1 02 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a f5 00 80 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a f5 00 bb 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ec e7 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f fe c0 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a f5 00 fc 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a f5 00 80 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a f5 00 fc 23 c1 00 00  00 00 00 00
Found 8 elements
