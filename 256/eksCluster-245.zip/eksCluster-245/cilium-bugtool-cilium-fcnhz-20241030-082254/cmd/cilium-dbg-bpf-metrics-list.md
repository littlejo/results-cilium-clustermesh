REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36691     2902207     677    bpf_overlay.c
Interface                 INGRESS     663383    133933755   1132   bpf_host.c
Success                   EGRESS      16560     1303255     1694   bpf_host.c
Success                   EGRESS      290764    36575008    1308   bpf_lxc.c
Success                   EGRESS      36968     2925317     53     encap.h
Success                   INGRESS     334838    37872281    86     l3.h
Success                   INGRESS     355620    39515279    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
