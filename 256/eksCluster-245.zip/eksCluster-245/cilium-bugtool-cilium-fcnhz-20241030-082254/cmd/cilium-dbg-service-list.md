ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.177.2:443 (active)      
                                          2 => 172.31.236.231:443 (active)    
2    10.100.216.216:443    ClusterIP      1 => 172.31.254.192:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.245.0.128:53 (active)       
                                          2 => 10.245.0.252:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.245.0.128:9153 (active)     
                                          2 => 10.245.0.252:9153 (active)     
5    10.100.179.109:2379   ClusterIP      1 => 10.245.0.187:2379 (active)     
