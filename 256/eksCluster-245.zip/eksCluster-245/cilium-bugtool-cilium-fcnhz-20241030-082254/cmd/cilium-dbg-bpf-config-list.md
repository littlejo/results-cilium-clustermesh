KEY             VALUE
AgentLiveness   1706479298481
UTimeOffset     3379443166015625
