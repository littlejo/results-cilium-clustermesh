key: 9f 01 00 00  value: fa 01 00 00
key: 32 05 00 00  value: 74 02 00 00
key: 4d 0b 00 00  value: 12 02 00 00
key: d7 0c 00 00  value: 0a 02 00 00
Found 4 elements
