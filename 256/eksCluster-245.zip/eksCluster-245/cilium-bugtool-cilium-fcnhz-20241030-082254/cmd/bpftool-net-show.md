xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 568
ens6(5) clsact/ingress cil_from_netdev-ens6 id 576
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 559
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 532
lxc3df020b8f81d(12) clsact/ingress cil_from_container-lxc3df020b8f81d id 519
lxc0642d708f889(14) clsact/ingress cil_from_container-lxc0642d708f889 id 510
lxce43891715c77(18) clsact/ingress cil_from_container-lxce43891715c77 id 624

flow_dissector:

netfilter:

