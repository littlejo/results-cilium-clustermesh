Endpoint ID: 415
Path: /sys/fs/bpf/tc/globals/cilium_policy_00415

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113104   1299      0        
Allow    Egress      0          ANY          NONE         disabled    16269    175       0        


Endpoint ID: 1307
Path: /sys/fs/bpf/tc/globals/cilium_policy_01307

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1330
Path: /sys/fs/bpf/tc/globals/cilium_policy_01330

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11680582   116503    0        
Allow    Ingress     1          ANY          NONE         disabled    11179605   114893    0        
Allow    Egress      0          ANY          NONE         disabled    12825189   126447    0        


Endpoint ID: 2893
Path: /sys/fs/bpf/tc/globals/cilium_policy_02893

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647801   20841     0        
Allow    Ingress     1          ANY          NONE         disabled    18036     215       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3287
Path: /sys/fs/bpf/tc/globals/cilium_policy_03287

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    110860   1265      0        
Allow    Egress      0          ANY          NONE         disabled    16718    180       0        


