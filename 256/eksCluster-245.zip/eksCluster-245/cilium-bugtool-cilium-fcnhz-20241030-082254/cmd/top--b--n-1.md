top - 08:22:56 up 27 min,  0 users,  load average: 0.30, 0.34, 0.27
Tasks:   7 total,   1 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 20.0 us, 43.3 sy,  0.0 ni, 36.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4465.4 free,   1202.6 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6426.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 397620  78780 S   6.2   5.0   0:59.47 cilium-+
    394 root      20   0 1229744   6828   3052 S   0.0   0.1   0:01.21 cilium-+
    647 root      20   0 1240432  16008  11164 S   0.0   0.2   0:00.02 cilium-+
    654 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    705 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    737 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
