alloc: 212.81MB (223152024 bytes)
total-alloc: 2.40GB (2572888416 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 65437435
frees: 63120437
heap-alloc: 212.81MB (223152024 bytes)
heap-sys: 256.08MB (268517376 bytes)
heap-idle: 19.75MB (20709376 bytes)
heap-in-use: 236.33MB (247808000 bytes)
heap-released: 3.16MB (3309568 bytes)
heap-objects: 2316998
stack-in-use: 63.53MB (66617344 bytes)
stack-sys: 63.53MB (66617344 bytes)
stack-mspan-inuse: 3.73MB (3913120 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.12MB (1169185 bytes)
gc-sys: 6.37MB (6682136 bytes)
next-gc: when heap-alloc >= 233.61MB (244958728 bytes)
last-gc: 2024-10-30 08:23:26.293891419 +0000 UTC
gc-pause-total: 26.480854ms
gc-pause: 1744420
gc-pause-end: 1730276606293891419
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0006879350118386531
enable-gc: true
debug-gc: false
