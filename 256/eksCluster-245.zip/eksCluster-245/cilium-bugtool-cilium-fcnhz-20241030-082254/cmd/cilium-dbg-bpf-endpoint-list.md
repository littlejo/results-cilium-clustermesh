IP ADDRESS         LOCAL ENDPOINT INFO
10.245.0.232:0     (localhost)                                                                                        
10.245.0.128:0     id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8   
10.245.0.187:0     id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63   
172.31.223.95:0    (localhost)                                                                                        
10.245.0.252:0     id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1   
172.31.254.192:0   (localhost)                                                                                        
10.245.0.7:0       id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09     
