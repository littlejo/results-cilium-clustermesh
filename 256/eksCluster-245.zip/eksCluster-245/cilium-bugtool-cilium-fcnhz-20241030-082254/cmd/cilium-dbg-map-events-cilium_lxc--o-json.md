{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:42.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.223.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:42.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.254.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:42.917Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.636Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.649Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.715Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.789Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.830Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.625Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.626Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.626Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.662Z",
  "value": "id=510   sec_id=8063340 flags=0x0000 ifindex=16  mac=8E:11:8D:28:98:16 nodemac=DE:AE:47:E3:9E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.625Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.625Z",
  "value": "id=510   sec_id=8063340 flags=0x0000 ifindex=16  mac=8E:11:8D:28:98:16 nodemac=DE:AE:47:E3:9E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.626Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.626Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.936Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.245.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.718Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.329Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.331Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.332Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.332Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.313Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.313Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.313Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.314Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.313Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.313Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.314Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.315Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.312Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.312Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.313Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.313Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.313Z",
  "value": "id=415   sec_id=8064077 flags=0x0000 ifindex=14  mac=46:98:E3:3E:52:53 nodemac=2E:1C:B4:5F:B9:E8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.313Z",
  "value": "id=1330  sec_id=8063340 flags=0x0000 ifindex=18  mac=E6:EA:15:0C:E5:9B nodemac=06:73:62:F0:43:63"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.314Z",
  "value": "id=2893  sec_id=4     flags=0x0000 ifindex=10  mac=DE:8B:BB:77:D3:AD nodemac=9E:13:98:E7:AF:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.245.0.252:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.314Z",
  "value": "id=3287  sec_id=8064077 flags=0x0000 ifindex=12  mac=3E:CF:25:E3:32:76 nodemac=96:8B:F4:A1:50:B1"
}

