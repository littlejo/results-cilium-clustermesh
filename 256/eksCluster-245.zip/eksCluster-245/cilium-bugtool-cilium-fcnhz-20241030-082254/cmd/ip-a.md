1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:80:1a:a7:39:fd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.254.192/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1936sec preferred_lft 1936sec
    inet6 fe80::880:1aff:fea7:39fd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6c:2e:94:54:bd brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.223.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86c:2eff:fe94:54bd/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:71:a6:76:fd:72 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c71:a6ff:fe76:fd72/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:d0:11:c7:db:71 brd ff:ff:ff:ff:ff:ff
    inet 10.245.0.232/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::74d0:11ff:fec7:db71/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:15:8f:41:4e:7e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1015:8fff:fe41:4e7e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:13:98:e7:af:09 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::9c13:98ff:fee7:af09/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc3df020b8f81d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:8b:f4:a1:50:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::948b:f4ff:fea1:50b1/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0642d708f889@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:1c:b4:5f:b9:e8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2c1c:b4ff:fe5f:b9e8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce43891715c77@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:73:62:f0:43:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::473:62ff:fef0:4363/64 scope link 
       valid_lft forever preferred_lft forever
