REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35718     2820208     677    bpf_overlay.c
Interface                 INGRESS     620070    128917089   1132   bpf_host.c
Success                   EGRESS      15257     1196940     1694   bpf_host.c
Success                   EGRESS      258787    32963251    1308   bpf_lxc.c
Success                   EGRESS      34995     2773078     53     encap.h
Success                   INGRESS     299291    33554306    86     l3.h
Success                   INGRESS     320403    35221620    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
