ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.233.134:443 (active)   
                                         2 => 172.31.184.167:443 (active)   
2    10.100.47.255:443    ClusterIP      1 => 172.31.253.50:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.93.0.70:53 (active)        
                                         2 => 10.93.0.48:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.93.0.70:9153 (active)      
                                         2 => 10.93.0.48:9153 (active)      
5    10.100.27.218:2379   ClusterIP      1 => 10.93.0.44:2379 (active)      
