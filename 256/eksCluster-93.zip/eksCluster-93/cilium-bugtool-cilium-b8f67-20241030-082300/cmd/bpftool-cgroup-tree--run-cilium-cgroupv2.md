CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53c2b513_b44a_4bcc_8231_5d53cd1b4400.slice/cri-containerd-1d496b410f5538ee4ed909037dd500bbc8fb7891cf534c2840e32991c1cfe480.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod53c2b513_b44a_4bcc_8231_5d53cd1b4400.slice/cri-containerd-b7a4d1612126c223546af510392c7f79092184a9a6379f864e5cde0998f7004e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9364cb89_bc47_45e1_b277_5c6ba6947e32.slice/cri-containerd-0888b94cf6884c62ae9df4e80dce6d841c35370463d2050afa0c6914631400c7.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9364cb89_bc47_45e1_b277_5c6ba6947e32.slice/cri-containerd-3d4ebaef04803c8f758065b36309953de86e67c72cbb4ac7ccea55bdd8941e22.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9748093_5cd1_45bd_951d_6a94f95f40f4.slice/cri-containerd-2262b21b258327d11a1427b1b00a80b8fdf65f9997a887239807d0e88fc98ca7.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9748093_5cd1_45bd_951d_6a94f95f40f4.slice/cri-containerd-b02be87acde7063472571d023f5de17b1dac8e67b604cb9005379421e0ae5632.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47995792_c145_4d14_9012_9f23743e7df2.slice/cri-containerd-a6f5b749ca04d0caba211a5a5296092f686de4e02d7d0ef1a1b09bd1a0437a87.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47995792_c145_4d14_9012_9f23743e7df2.slice/cri-containerd-e61482bca8214cbafcace2927998b4bf306dee05883360459a5cb0afbcfc598a.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-5bd52f595a222c0d157419e4845d4283feddbc4cf6177e7ceb2b6e16b961915f.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-392630657b6135821a5b32164036934567fa3cb547280b04364c35385cdfd168.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-1f891bf51e23ff3aca2d582932c2845999fda8c05188c0a070df6f07be69527b.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-253eba9d4a1ce5e7f16ff8806031264c72566dfd4158d8bdd8392b3f822996c4.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda9439e2_008b_4588_9af7_2baeddd06724.slice/cri-containerd-36106520c78acf08ddfc924a1c8f1a55a3edbf30b43e8a92d21ab2cdbee78e3f.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podda9439e2_008b_4588_9af7_2baeddd06724.slice/cri-containerd-bf73f38b8d59df1b1acbc052eec506bdd977732060dbf0ee2371af60123ab61b.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229cfba8_18ba_4e33_baec_3922ddcab415.slice/cri-containerd-42d276e797ce0d5c1946446cffa1d9ac6c37b4eda79c5736a9f05d14c6988c10.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229cfba8_18ba_4e33_baec_3922ddcab415.slice/cri-containerd-2b8dd9f92ca57f4b5f1a27b0ccabc5645063bc593b4045232dd9d90b8f6420e0.scope
    95       cgroup_device   multi                                          
