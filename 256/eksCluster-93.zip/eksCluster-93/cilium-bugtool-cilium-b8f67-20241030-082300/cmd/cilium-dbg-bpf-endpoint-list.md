IP ADDRESS         LOCAL ENDPOINT INFO
10.93.0.218:0      (localhost)                                                                                        
172.31.253.50:0    (localhost)                                                                                        
172.31.229.157:0   (localhost)                                                                                        
10.93.0.70:0       id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF   
10.93.0.15:0       id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73     
10.93.0.48:0       id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7   
10.93.0.44:0       id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7   
