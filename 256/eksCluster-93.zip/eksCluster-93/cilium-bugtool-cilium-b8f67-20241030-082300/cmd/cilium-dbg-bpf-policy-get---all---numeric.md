Endpoint ID: 125
Path: /sys/fs/bpf/tc/globals/cilium_policy_00125

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11347097   110877    0        
Allow    Ingress     1          ANY          NONE         disabled    9170218    95659     0        
Allow    Egress      0          ANY          NONE         disabled    10758598   107616    0        


Endpoint ID: 432
Path: /sys/fs/bpf/tc/globals/cilium_policy_00432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150967   1742      0        
Allow    Egress      0          ANY          NONE         disabled    18412    202       0        


Endpoint ID: 522
Path: /sys/fs/bpf/tc/globals/cilium_policy_00522

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1673489   21188     0        
Allow    Ingress     1          ANY          NONE         disabled    23008     270       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 988
Path: /sys/fs/bpf/tc/globals/cilium_policy_00988

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151165   1745      0        
Allow    Egress      0          ANY          NONE         disabled    18355    201       0        


Endpoint ID: 3135
Path: /sys/fs/bpf/tc/globals/cilium_policy_03135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


