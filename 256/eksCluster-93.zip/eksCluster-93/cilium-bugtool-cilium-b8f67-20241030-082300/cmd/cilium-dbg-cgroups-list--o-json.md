[
  {
    "containers": [
      {
        "cgroup-id": 9400,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-392630657b6135821a5b32164036934567fa3cb547280b04364c35385cdfd168.scope"
      },
      {
        "cgroup-id": 9316,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-5bd52f595a222c0d157419e4845d4283feddbc4cf6177e7ceb2b6e16b961915f.scope"
      },
      {
        "cgroup-id": 9232,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod481de8fe_9134_4a72_b518_cbd607b4662a.slice/cri-containerd-1f891bf51e23ff3aca2d582932c2845999fda8c05188c0a070df6f07be69527b.scope"
      }
    ],
    "ips": [
      "10.93.0.44"
    ],
    "name": "clustermesh-apiserver-5c7fc6fc9d-qppd5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7756,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod47995792_c145_4d14_9012_9f23743e7df2.slice/cri-containerd-a6f5b749ca04d0caba211a5a5296092f686de4e02d7d0ef1a1b09bd1a0437a87.scope"
      }
    ],
    "ips": [
      "10.93.0.48"
    ],
    "name": "coredns-cc6ccd49c-w7578",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7840,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd9748093_5cd1_45bd_951d_6a94f95f40f4.slice/cri-containerd-b02be87acde7063472571d023f5de17b1dac8e67b604cb9005379421e0ae5632.scope"
      }
    ],
    "ips": [
      "10.93.0.70"
    ],
    "name": "coredns-cc6ccd49c-dmq8x",
    "namespace": "kube-system"
  }
]

