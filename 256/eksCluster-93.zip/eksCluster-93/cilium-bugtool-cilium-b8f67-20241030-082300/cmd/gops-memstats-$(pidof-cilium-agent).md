alloc: 110.18MB (115530336 bytes)
total-alloc: 2.20GB (2365839104 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 62594133
frees: 61917836
heap-alloc: 110.18MB (115530336 bytes)
heap-sys: 244.04MB (255893504 bytes)
heap-idle: 77.16MB (80912384 bytes)
heap-in-use: 166.88MB (174981120 bytes)
heap-released: 1.97MB (2064384 bytes)
heap-objects: 676297
stack-in-use: 59.94MB (62849024 bytes)
stack-sys: 59.94MB (62849024 bytes)
stack-mspan-inuse: 2.65MB (2780640 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1114665 bytes)
gc-sys: 5.99MB (6284776 bytes)
next-gc: when heap-alloc >= 216.57MB (227091976 bytes)
last-gc: 2024-10-30 08:23:32.275565687 +0000 UTC
gc-pause-total: 9.504419ms
gc-pause: 1498885
gc-pause-end: 1730276612275565687
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0004137223583938161
enable-gc: true
debug-gc: false
