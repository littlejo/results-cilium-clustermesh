Total: 689
TCP:   1860 (estab 437, closed 1404, orphaned 0, timewait 565)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  456       443       13       
INET	  466       449       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.253.50%ens5:68         0.0.0.0:*    uid:192 ino:70391 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33236 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15274 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38023      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:33135 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33235 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15275 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::86a:cfff:fe54:847b]%ens5:546           [::]:*    uid:192 ino:16526 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
