top - 08:23:02 up 34 min,  0 users,  load average: 0.20, 0.20, 0.17
Tasks:  12 total,   1 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 40.6 us, 34.4 sy,  0.0 ni,  6.2 id,  0.0 wa,  0.0 hi, 18.8 si,  0.0 st
MiB Mem :   7814.2 total,   4487.5 free,   1180.7 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6448.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    725 root      20   0 1244340  21924  14268 S  46.7   0.3   0:00.07 hubble
      1 root      20   0 1606080 375372  77636 S  13.3   4.7   0:46.16 cilium-+
    650 root      20   0 1240432  15712  11160 S   6.7   0.2   0:00.03 cilium-+
    406 root      20   0 1229488   8028   3836 S   0.0   0.1   0:01.16 cilium-+
    605 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    659 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    662 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    701 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    714 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    721 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    748 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
