{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.218:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.037Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.229.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.037Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.253.50:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.037Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.524Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.524Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.598Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.707Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:27.767Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.970Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.971Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.972Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:18.001Z",
  "value": "id=283   sec_id=3086850 flags=0x0000 ifindex=16  mac=1E:43:1F:87:5A:B3 nodemac=22:E1:40:0C:F8:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:18.970Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:18.970Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:18.970Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:18.971Z",
  "value": "id=283   sec_id=3086850 flags=0x0000 ifindex=16  mac=1E:43:1F:87:5A:B3 nodemac=22:E1:40:0C:F8:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.667Z",
  "value": "id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.93.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.223Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.089Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.089Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.091Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.091Z",
  "value": "id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.083Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.084Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.084Z",
  "value": "id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.085Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.084Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.084Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.084Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.085Z",
  "value": "id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.084Z",
  "value": "id=988   sec_id=3092137 flags=0x0000 ifindex=14  mac=D2:13:9C:E0:7F:C2 nodemac=96:9B:61:C4:5D:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.084Z",
  "value": "id=125   sec_id=3086850 flags=0x0000 ifindex=18  mac=4A:B6:03:72:17:83 nodemac=66:19:24:BA:97:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.085Z",
  "value": "id=522   sec_id=4     flags=0x0000 ifindex=10  mac=4A:EF:6C:D1:77:19 nodemac=AE:39:5A:43:F0:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.93.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:03.085Z",
  "value": "id=432   sec_id=3092137 flags=0x0000 ifindex=12  mac=1E:1C:BF:7C:E7:6D nodemac=A6:BC:50:E1:7F:F7"
}

