key: 7d 00 00 00  value: 74 02 00 00
key: b0 01 00 00  value: 1c 02 00 00
key: 0a 02 00 00  value: 0b 02 00 00
key: dc 03 00 00  value: 01 02 00 00
Found 4 elements
