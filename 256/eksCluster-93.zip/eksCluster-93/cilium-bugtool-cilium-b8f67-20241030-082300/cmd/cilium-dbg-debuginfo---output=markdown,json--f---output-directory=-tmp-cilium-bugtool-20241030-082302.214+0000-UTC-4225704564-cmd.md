markdown output at /tmp/cilium-bugtool-20241030-082302.214+0000-UTC-4225704564/cmd/cilium-debuginfo-20241030-082333.14+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082302.214+0000-UTC-4225704564/cmd/cilium-debuginfo-20241030-082333.14+0000-UTC.json
