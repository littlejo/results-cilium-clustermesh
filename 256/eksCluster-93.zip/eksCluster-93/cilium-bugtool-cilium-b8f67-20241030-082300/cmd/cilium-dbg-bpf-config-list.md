KEY             VALUE
AgentLiveness   2077594681178
UTimeOffset     3379442453125000
