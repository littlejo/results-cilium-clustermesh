1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6a:cf:54:84:7b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.253.50/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3364sec preferred_lft 3364sec
    inet6 fe80::86a:cfff:fe54:847b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c1:27:63:89:41 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.229.157/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c1:27ff:fe63:8941/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:44:70:a9:3e:5c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3444:70ff:fea9:3e5c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:b1:a5:01:c8:aa brd ff:ff:ff:ff:ff:ff
    inet 10.93.0.218/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b1:a5ff:fe01:c8aa/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:27:d3:83:b7:85 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ec27:d3ff:fe83:b785/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:39:5a:43:f0:73 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ac39:5aff:fe43:f073/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc573dc393d3df@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:bc:50:e1:7f:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a4bc:50ff:fee1:7ff7/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce109b2a00fa9@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:9b:61:c4:5d:cf brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::949b:61ff:fec4:5dcf/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc60c69c5a5754@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:19:24:ba:97:d7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::6419:24ff:feba:97d7/64 scope link 
       valid_lft forever preferred_lft forever
