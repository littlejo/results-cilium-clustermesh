 08:22:48 up 38 min,  0 users,  load average: 0.20, 0.17, 0.13
