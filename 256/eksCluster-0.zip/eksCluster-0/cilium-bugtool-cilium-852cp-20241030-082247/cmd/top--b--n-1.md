top - 08:22:48 up 38 min,  0 users,  load average: 0.20, 0.17, 0.13
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 33.3 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4464.5 free,   1202.4 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6426.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606272 398200  78332 S  73.3   5.0   1:03.68 cilium-+
    692 root      20   0 1240432  16280  11292 S   6.7   0.2   0:00.02 cilium-+
    765 root      20   0 1243764  18036  13124 S   6.7   0.2   0:00.01 hubble
    408 root      20   0 1229488   8012   3836 S   0.0   0.1   0:01.14 cilium-+
    735 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    744 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    758 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    759 root      20   0    2208    788    708 S   0.0   0.0   0:00.00 timeout
    772 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    773 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
    804 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
