filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5181938356f0 direct-action not_in_hw id 521 tag b36388edfe2d48f1 jited 
