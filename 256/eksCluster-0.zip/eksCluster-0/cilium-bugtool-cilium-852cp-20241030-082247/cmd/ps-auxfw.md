USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         692  0.0  0.2 1240432 16280 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         728  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         729  0.0  0.2 1240432 16280 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         691  0.0  0.0      0     0 ?        Zs   08:22   0:00 [gops] <defunct>
root           1  3.4  4.9 1606272 397696 ?      Ssl  07:52   1:03 cilium-agent --config-dir=/tmp/cilium/config-map
root         408  0.0  0.1 1229488 8012 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
