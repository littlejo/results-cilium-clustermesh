Endpoint ID: 240
Path: /sys/fs/bpf/tc/globals/cilium_policy_00240

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176134   2030      0        
Allow    Egress      0          ANY          NONE         disabled    21756    245       0        


Endpoint ID: 1223
Path: /sys/fs/bpf/tc/globals/cilium_policy_01223

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2260
Path: /sys/fs/bpf/tc/globals/cilium_policy_02260

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1628714   20653     0        
Allow    Ingress     1          ANY          NONE         disabled    25620     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2278
Path: /sys/fs/bpf/tc/globals/cilium_policy_02278

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176631   2032      0        
Allow    Egress      0          ANY          NONE         disabled    21450    242       0        


Endpoint ID: 3026
Path: /sys/fs/bpf/tc/globals/cilium_policy_03026

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11410032   115806    0        
Allow    Ingress     1          ANY          NONE         disabled    12567885   130063    0        
Allow    Egress      0          ANY          NONE         disabled    15505268   151511    0        


