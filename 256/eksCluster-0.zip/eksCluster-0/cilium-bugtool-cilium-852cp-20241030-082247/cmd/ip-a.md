1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:71:ec:9b:e0:5b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.129.111/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3127sec preferred_lft 3127sec
    inet6 fe80::471:ecff:fe9b:e05b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:9d:d4:5a:1e:71 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.143.126/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::49d:d4ff:fe5a:1e71/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:7e:57:fa:a6:f9 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c7e:57ff:fefa:a6f9/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 26:c3:62:6d:d4:77 brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.110/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::24c3:62ff:fe6d:d477/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7e:95:c9:ce:45:e7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7c95:c9ff:fece:45e7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:a3:e3:2e:67:51 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::44a3:e3ff:fe2e:6751/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc80f500d9b5e5@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:5f:47:ee:74:1c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::945f:47ff:feee:741c/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc5181938356f0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:1c:b4:98:12:cb brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b01c:b4ff:fe98:12cb/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfe6058c968c5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:38:04:d2:7f:30 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4438:4ff:fed2:7f30/64 scope link 
       valid_lft forever preferred_lft forever
