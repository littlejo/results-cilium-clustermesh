ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.179.0:443 (active)      
                                         2 => 172.31.213.92:443 (active)     
2    10.100.4.11:443      ClusterIP      1 => 172.31.129.111:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.0.0.243:53 (active)         
                                         2 => 10.0.0.22:53 (active)          
4    10.100.0.10:9153     ClusterIP      1 => 10.0.0.243:9153 (active)       
                                         2 => 10.0.0.22:9153 (active)        
5    10.100.89.228:2379   ClusterIP      1 => 10.0.0.253:2379 (active)       
