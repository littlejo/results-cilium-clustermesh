alloc: 174.90MB (183391128 bytes)
total-alloc: 2.59GB (2783042600 bytes)
sys: 328.96MB (344936804 bytes)
lookups: 0
mallocs: 68463381
frees: 66471292
heap-alloc: 174.90MB (183391128 bytes)
heap-sys: 248.08MB (260128768 bytes)
heap-idle: 42.08MB (44122112 bytes)
heap-in-use: 206.00MB (216006656 bytes)
heap-released: 376.00KB (385024 bytes)
heap-objects: 1992089
stack-in-use: 67.88MB (71172096 bytes)
stack-sys: 67.88MB (71172096 bytes)
stack-mspan-inuse: 3.48MB (3645920 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1064161 bytes)
gc-sys: 5.98MB (6274632 bytes)
next-gc: when heap-alloc >= 213.08MB (223428552 bytes)
last-gc: 2024-10-30 08:22:49.740224224 +0000 UTC
gc-pause-total: 15.531843ms
gc-pause: 119255
gc-pause-end: 1730276569740224224
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.0004394433579005018
enable-gc: true
debug-gc: false
