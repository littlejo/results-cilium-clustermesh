key: f0 00 00 00  value: 1e 02 00 00
key: d4 08 00 00  value: 05 02 00 00
key: e6 08 00 00  value: 0b 02 00 00
key: d2 0b 00 00  value: 74 02 00 00
Found 4 elements
