filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc80f500d9b5e5 direct-action not_in_hw id 549 tag 395ac4638c10b054 jited 
