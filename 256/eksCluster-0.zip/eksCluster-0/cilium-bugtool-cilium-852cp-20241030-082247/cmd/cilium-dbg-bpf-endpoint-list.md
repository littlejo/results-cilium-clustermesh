IP ADDRESS         LOCAL ENDPOINT INFO
10.0.0.22:0        id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C   
172.31.143.126:0   (localhost)                                                                                      
10.0.0.243:0       id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB   
10.0.0.253:0       id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30   
172.31.129.111:0   (localhost)                                                                                      
10.0.0.71:0        id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51   
10.0.0.110:0       (localhost)                                                                                      
