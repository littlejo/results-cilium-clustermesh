[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-d7e34e57cd617a5e0e0a68dda134ea3a426fc62789219bc22bab733606ea8b51.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-558fea7f5fc1b6ed9ac5513f191c3a5f0b8b86830fc67571c85eb69412f669ec.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-9010f2e7ec32af3c2b70350833c490fb9887cc4aa3b735c2239161c041a0b400.scope"
      }
    ],
    "ips": [
      "10.0.0.253"
    ],
    "name": "clustermesh-apiserver-769c674b98-bwvnw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda44ee9d_139c_4493_8694_94eaf0b6be8f.slice/cri-containerd-2b5d7bc748744bdeda4a03687d52509d71bea3ef2ee2b84957d9092641259f21.scope"
      }
    ],
    "ips": [
      "10.0.0.243"
    ],
    "name": "coredns-cc6ccd49c-qkpsw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a719e74_32cb_463f_a183_74e5f73ca1a5.slice/cri-containerd-ff86574c84d01abec0f37f1027444fb1780824babbea0fed20d7df61f1aff54f.scope"
      }
    ],
    "ips": [
      "10.0.0.22"
    ],
    "name": "coredns-cc6ccd49c-gc98c",
    "namespace": "kube-system"
  }
]

