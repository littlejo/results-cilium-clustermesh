REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36501     2883463     677    bpf_overlay.c
Interface                 INGRESS     701134    139800274   1132   bpf_host.c
Success                   EGRESS      16519     1300291     1694   bpf_host.c
Success                   EGRESS      314213    38586908    1308   bpf_lxc.c
Success                   EGRESS      37474     2951260     53     encap.h
Success                   INGRESS     359596    40911473    86     l3.h
Success                   INGRESS     380229    42538691    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
