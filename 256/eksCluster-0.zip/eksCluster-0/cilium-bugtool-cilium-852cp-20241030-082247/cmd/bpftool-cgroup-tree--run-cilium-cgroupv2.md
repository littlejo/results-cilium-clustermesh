CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a719e74_32cb_463f_a183_74e5f73ca1a5.slice/cri-containerd-489d0b34ea59a3183a1cfee1712805a3b1c30a41b27ffc40b4b1ff072a137107.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9a719e74_32cb_463f_a183_74e5f73ca1a5.slice/cri-containerd-ff86574c84d01abec0f37f1027444fb1780824babbea0fed20d7df61f1aff54f.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda44ee9d_139c_4493_8694_94eaf0b6be8f.slice/cri-containerd-90edab5b0b94c92cd2dc69310b792eb6e56db8f13c6b6eb75133bb3ffbb808fe.scope
    545      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda44ee9d_139c_4493_8694_94eaf0b6be8f.slice/cri-containerd-2b5d7bc748744bdeda4a03687d52509d71bea3ef2ee2b84957d9092641259f21.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ba5202_c9cb_483a_8b80_a49dd6c71391.slice/cri-containerd-4b6469a75b6572abcb68ebf86cd2f152d2040f5f2fafa355f1255d6549141ac1.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9ba5202_c9cb_483a_8b80_a49dd6c71391.slice/cri-containerd-6856891c342813db2aa49593bf1302e9b81213a233ee35769a95070a47f6972b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fad1f66_ef99_4868_95b5_299bad91d9bf.slice/cri-containerd-dfc2893217fe879e1859469a4ed4998bf3ba6ffda086948d7b4edc53c06c33c4.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8fad1f66_ef99_4868_95b5_299bad91d9bf.slice/cri-containerd-f6f8a5edaf6a3eb2774dd446f8660f8f10ad4d7b07526d5cc0e0f1d4d8ac102f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12e3918b_c8be_4486_9bae_93dfba078c43.slice/cri-containerd-1c4b3154e50e82fea680b323e4dbfd0688d8d3f62474bf1f6740c3894e8e8969.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod12e3918b_c8be_4486_9bae_93dfba078c43.slice/cri-containerd-2e03afb2fc9f9dbd06d1445ccc51d307464d4a44d8f9b5e3932ef1f7d71799cd.scope
    113      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod843b6fed_40ff_42ae_bcfa_b1901689bf59.slice/cri-containerd-d5b6bc5154eda92a153c57165283ef12282acedbaf7803ce30e5d99d50264db6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod843b6fed_40ff_42ae_bcfa_b1901689bf59.slice/cri-containerd-67c1bee17d1016768541f0f9cb407b2029e4f597ef9953df3902034132ee916b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-9010f2e7ec32af3c2b70350833c490fb9887cc4aa3b735c2239161c041a0b400.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-0237a96fa1dc100927e67585ecb33e770d06707eb91a1ca0d343424f44a793dd.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-d7e34e57cd617a5e0e0a68dda134ea3a426fc62789219bc22bab733606ea8b51.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd5485dcf_0069_4b4e_864f_890450fcf9a7.slice/cri-containerd-558fea7f5fc1b6ed9ac5513f191c3a5f0b8b86830fc67571c85eb69412f669ec.scope
    656      cgroup_device   multi                                          
