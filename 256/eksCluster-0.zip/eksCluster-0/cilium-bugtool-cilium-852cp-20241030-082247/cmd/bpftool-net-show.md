xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 578
ens6(5) clsact/ingress cil_from_netdev-ens6 id 584
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 519
lxc80f500d9b5e5(12) clsact/ingress cil_from_container-lxc80f500d9b5e5 id 549
lxc5181938356f0(14) clsact/ingress cil_from_container-lxc5181938356f0 id 521
lxcfe6058c968c5(18) clsact/ingress cil_from_container-lxcfe6058c968c5 id 635

flow_dissector:

netfilter:

