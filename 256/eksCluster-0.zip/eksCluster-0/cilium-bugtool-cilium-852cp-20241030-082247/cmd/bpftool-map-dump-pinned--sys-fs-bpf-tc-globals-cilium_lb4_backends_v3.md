key: 01 00 00 00  value: ac 1f b3 00 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 00 00 16 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 00 00 f3 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 00 00 f3 23 c1 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 00 00 16 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 81 6f 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 00 00 fd 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f d5 5c 01 bb 00 00  00 00 00 00
Found 8 elements
