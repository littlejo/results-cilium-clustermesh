{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.302Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.302Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:25.302Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.866Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.869Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.921Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.977Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:30.041Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:45.530Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:45.530Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:45.531Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:45.564Z",
  "value": "id=2029  sec_id=43573 flags=0x0000 ifindex=16  mac=26:04:10:A6:C5:D6 nodemac=4A:71:C6:C8:31:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:45.565Z",
  "value": "id=2029  sec_id=43573 flags=0x0000 ifindex=16  mac=26:04:10:A6:C5:D6 nodemac=4A:71:C6:C8:31:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:46.531Z",
  "value": "id=2029  sec_id=43573 flags=0x0000 ifindex=16  mac=26:04:10:A6:C5:D6 nodemac=4A:71:C6:C8:31:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:46.531Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:46.531Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:46.531Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:01.327Z",
  "value": "id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.0.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:11.948Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:12.933Z",
  "value": "id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:12.933Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:12.934Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:12.934Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:13.929Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:13.929Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:13.929Z",
  "value": "id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:13.931Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:14.929Z",
  "value": "id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:14.930Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:14.930Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:14.930Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:15.930Z",
  "value": "id=2278  sec_id=38664 flags=0x0000 ifindex=14  mac=7E:8C:38:B3:DC:62 nodemac=B2:1C:B4:98:12:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:15.930Z",
  "value": "id=2260  sec_id=4     flags=0x0000 ifindex=10  mac=FA:EC:7F:01:CA:42 nodemac=46:A3:E3:2E:67:51"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:15.930Z",
  "value": "id=240   sec_id=38664 flags=0x0000 ifindex=12  mac=92:A0:21:F7:73:FE nodemac=96:5F:47:EE:74:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.0.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:15.931Z",
  "value": "id=3026  sec_id=43573 flags=0x0000 ifindex=18  mac=72:13:81:8F:BE:33 nodemac=46:38:04:D2:7F:30"
}

