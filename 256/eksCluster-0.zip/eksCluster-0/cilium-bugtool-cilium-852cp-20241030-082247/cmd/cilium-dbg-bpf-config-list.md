KEY             VALUE
AgentLiveness   2312878744767
UTimeOffset     3379441966796875
