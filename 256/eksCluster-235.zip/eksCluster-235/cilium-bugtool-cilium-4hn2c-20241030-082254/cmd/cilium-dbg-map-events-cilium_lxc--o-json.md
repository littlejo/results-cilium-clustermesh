{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.194:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.970Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.200.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.970Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:00.970Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.281Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.294Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.325Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:05.347Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:06.447Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:06.448Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:06.448Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:06.476Z",
  "value": "id=469   sec_id=7746719 flags=0x0000 ifindex=16  mac=92:44:51:80:8C:7B nodemac=0A:2A:DE:9E:C9:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:06.477Z",
  "value": "id=469   sec_id=7746719 flags=0x0000 ifindex=16  mac=92:44:51:80:8C:7B nodemac=0A:2A:DE:9E:C9:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:07.447Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:07.447Z",
  "value": "id=469   sec_id=7746719 flags=0x0000 ifindex=16  mac=92:44:51:80:8C:7B nodemac=0A:2A:DE:9E:C9:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:07.447Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:07.447Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.881Z",
  "value": "id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.235.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.182Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:51.505Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:51.506Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:51.507Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:51.507Z",
  "value": "id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.518Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.519Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.519Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.519Z",
  "value": "id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.506Z",
  "value": "id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.506Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.507Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.507Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.507Z",
  "value": "id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.508Z",
  "value": "id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.508Z",
  "value": "id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.235.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.508Z",
  "value": "id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31"
}

