markdown output at /tmp/cilium-bugtool-20241030-082255.379+0000-UTC-1447741709/cmd/cilium-debuginfo-20241030-082326.58+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.379+0000-UTC-1447741709/cmd/cilium-debuginfo-20241030-082326.58+0000-UTC.json
