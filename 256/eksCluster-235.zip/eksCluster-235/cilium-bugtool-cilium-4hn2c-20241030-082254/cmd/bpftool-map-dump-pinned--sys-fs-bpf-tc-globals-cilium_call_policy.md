key: 77 02 00 00  value: 44 02 00 00
key: cd 02 00 00  value: 89 02 00 00
key: 81 03 00 00  value: 47 02 00 00
key: 7f 08 00 00  value: 0c 02 00 00
Found 4 elements
