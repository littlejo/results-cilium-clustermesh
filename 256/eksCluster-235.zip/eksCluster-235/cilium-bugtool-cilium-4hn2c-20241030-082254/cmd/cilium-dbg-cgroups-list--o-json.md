[
  {
    "containers": [
      {
        "cgroup-id": 9210,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-d88843103df5e93c7576b90dab434086b965f19af00ae0c771bd74b9b255b8dd.scope"
      },
      {
        "cgroup-id": 9126,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-99f472af4d2c8de31be21c5b9250260f47b1f6cd05c2bcd101126c7604c024f4.scope"
      },
      {
        "cgroup-id": 9294,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-fa1fe9b1efde9d8d02e9a5971cfab43e82069b580050e8a685077e8df0bc4fb0.scope"
      }
    ],
    "ips": [
      "10.235.0.110"
    ],
    "name": "clustermesh-apiserver-756ff9bb9d-hw8cr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3f43ea0_a857_4719_b7e3_1accfc4a24f1.slice/cri-containerd-777ed25aa09aadd464547a17bf0e3bfc6a13913bf651aff9fc1536661ba0986c.scope"
      }
    ],
    "ips": [
      "10.235.0.245"
    ],
    "name": "coredns-cc6ccd49c-ntrnh",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b54e7b6_ca83_4cf0_95dc_4f87d2a4cfa0.slice/cri-containerd-39c1ccffbf3704957769aa34921627ee7ea1a46dc9c5823392af99c630349b6b.scope"
      }
    ],
    "ips": [
      "10.235.0.13"
    ],
    "name": "coredns-cc6ccd49c-kwnb7",
    "namespace": "kube-system"
  }
]

