top - 08:22:55 up 27 min,  0 users,  load average: 0.05, 0.18, 0.21
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 17.2 sy,  0.0 ni, 69.0 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4474.3 free,   1193.1 used,   2146.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 381060  78076 S   6.7   4.8   0:46.22 cilium-+
    689 root      20   0 1240432  16436  11484 S   6.7   0.2   0:00.02 cilium-+
    419 root      20   0 1229744   7004   2864 S   0.0   0.1   0:01.07 cilium-+
    667 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    677 root      20   0 1228744   4032   3392 S   0.0   0.1   0:00.00 gops
    695 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    725 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    743 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
