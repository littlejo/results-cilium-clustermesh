xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 562
ens6(5) clsact/ingress cil_from_netdev-ens6 id 568
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 553
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 544
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 578
lxc5b14850621a8(12) clsact/ingress cil_from_container-lxc5b14850621a8 id 527
lxcd778ef56568f(14) clsact/ingress cil_from_container-lxcd778ef56568f id 537
lxc325326f7f407(18) clsact/ingress cil_from_container-lxc325326f7f407 id 646

flow_dissector:

netfilter:

