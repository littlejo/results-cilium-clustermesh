KEY             VALUE
AgentLiveness   1686526632226
UTimeOffset     3379443203125000
