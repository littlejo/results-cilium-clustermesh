Endpoint ID: 357
Path: /sys/fs/bpf/tc/globals/cilium_policy_00357

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 631
Path: /sys/fs/bpf/tc/globals/cilium_policy_00631

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109763   1259      0        
Allow    Egress      0          ANY          NONE         disabled    14724    157       0        


Endpoint ID: 717
Path: /sys/fs/bpf/tc/globals/cilium_policy_00717

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11509028   116323    0        
Allow    Ingress     1          ANY          NONE         disabled    11387855   120649    0        
Allow    Egress      0          ANY          NONE         disabled    15219548   148412    0        


Endpoint ID: 897
Path: /sys/fs/bpf/tc/globals/cilium_policy_00897

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647764   20810     0        
Allow    Ingress     1          ANY          NONE         disabled    17766     212       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2175
Path: /sys/fs/bpf/tc/globals/cilium_policy_02175

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109924   1258      0        
Allow    Egress      0          ANY          NONE         disabled    16501    178       0        


