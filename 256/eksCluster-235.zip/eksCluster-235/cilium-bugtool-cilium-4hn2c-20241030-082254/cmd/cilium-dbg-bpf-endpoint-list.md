IP ADDRESS         LOCAL ENDPOINT INFO
10.235.0.245:0     id=2175  sec_id=7756777 flags=0x0000 ifindex=12  mac=3E:FA:41:E9:0A:C6 nodemac=F6:21:5D:3A:30:F3   
10.235.0.13:0      id=631   sec_id=7756777 flags=0x0000 ifindex=14  mac=42:97:2F:57:C3:3F nodemac=A6:A4:20:52:96:E2   
10.235.0.110:0     id=717   sec_id=7746719 flags=0x0000 ifindex=18  mac=86:0C:B5:7A:0B:A2 nodemac=9A:3F:8E:B4:1B:58   
10.235.0.42:0      id=897   sec_id=4     flags=0x0000 ifindex=10  mac=B6:56:A1:35:C2:29 nodemac=F2:47:FA:C3:6C:31     
172.31.200.108:0   (localhost)                                                                                        
172.31.201.30:0    (localhost)                                                                                        
10.235.0.194:0     (localhost)                                                                                        
