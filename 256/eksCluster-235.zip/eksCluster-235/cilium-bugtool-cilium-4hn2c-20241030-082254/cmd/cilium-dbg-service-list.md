ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.224.44:443 (active)     
                                         2 => 172.31.181.103:443 (active)    
2    10.100.103.140:443   ClusterIP      1 => 172.31.200.108:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.235.0.13:53 (active)        
                                         2 => 10.235.0.245:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.235.0.13:9153 (active)      
                                         2 => 10.235.0.245:9153 (active)     
5    10.100.38.19:2379    ClusterIP      1 => 10.235.0.110:2379 (active)     
