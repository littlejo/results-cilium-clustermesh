1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:02:b7:50:ce:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.200.108/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1955sec preferred_lft 1955sec
    inet6 fe80::802:b7ff:fe50:ced1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c4:65:48:37:0f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.201.30/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c4:65ff:fe48:370f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:cd:2a:d7:1d:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e4cd:2aff:fed7:1d82/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:ef:36:ce:30:53 brd ff:ff:ff:ff:ff:ff
    inet 10.235.0.194/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::64ef:36ff:fece:3053/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:d7:e6:8d:7e:34 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0d7:e6ff:fe8d:7e34/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:47:fa:c3:6c:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f047:faff:fec3:6c31/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5b14850621a8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:21:5d:3a:30:f3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::f421:5dff:fe3a:30f3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd778ef56568f@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:a4:20:52:96:e2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::a4a4:20ff:fe52:96e2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc325326f7f407@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:3f:8e:b4:1b:58 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::983f:8eff:feb4:1b58/64 scope link 
       valid_lft forever preferred_lft forever
