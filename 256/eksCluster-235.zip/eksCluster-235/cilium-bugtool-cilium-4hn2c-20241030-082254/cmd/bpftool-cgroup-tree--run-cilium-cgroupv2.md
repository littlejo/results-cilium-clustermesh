CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod23c25750_1443_4746_85d6_dd531006ce68.slice/cri-containerd-6f4c4de1fadd5084e5eb62b23157805a0c9ed319ec573613efe23f8ebc4002de.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod23c25750_1443_4746_85d6_dd531006ce68.slice/cri-containerd-33016ea24ce5ddfa00c5f6cb8fa6ea05439ceee0f458d61e41a42eb0bf2dbfbe.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3f43ea0_a857_4719_b7e3_1accfc4a24f1.slice/cri-containerd-777ed25aa09aadd464547a17bf0e3bfc6a13913bf651aff9fc1536661ba0986c.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3f43ea0_a857_4719_b7e3_1accfc4a24f1.slice/cri-containerd-13fae36fcab3ee1083a024482245da3343012ac49d0b262188eb08cffa718437.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f937c3_0447_4508_af23_02cd0b838e2a.slice/cri-containerd-3e3fbbe64814e15af4be7175872f4181cca3187cfbdf86bd12d6b8fc5d4491fc.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6f937c3_0447_4508_af23_02cd0b838e2a.slice/cri-containerd-3a46ddb67e50d35e23bdb2b64ac9528154dd2c4028fd5949f484dd1dfab2d20b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b54e7b6_ca83_4cf0_95dc_4f87d2a4cfa0.slice/cri-containerd-6fb95adab9c6cf7895f3e4fd31e733f49d0c40315ad78fa118906052e4d41726.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1b54e7b6_ca83_4cf0_95dc_4f87d2a4cfa0.slice/cri-containerd-39c1ccffbf3704957769aa34921627ee7ea1a46dc9c5823392af99c630349b6b.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a3bdff0_54d6_4a01_8e6c_d33066850ffd.slice/cri-containerd-fce87dd41511a1c1a0ec86f03738490a955d26cc50e31294ee5dfaa1faa78845.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a3bdff0_54d6_4a01_8e6c_d33066850ffd.slice/cri-containerd-8342e10bdd6527ea6879d118188b96aaa1704a3c62e63e5f1e84232f9dd163e0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-d88843103df5e93c7576b90dab434086b965f19af00ae0c771bd74b9b255b8dd.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-fa1fe9b1efde9d8d02e9a5971cfab43e82069b580050e8a685077e8df0bc4fb0.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-99f472af4d2c8de31be21c5b9250260f47b1f6cd05c2bcd101126c7604c024f4.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8702b44f_bfb1_4b6a_8e15_74b61ec6e4ad.slice/cri-containerd-a79314e60223e158207d1686966bc7043ebbbf75893c47eeda25dabe4a8176e9.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffa6b80e_ba8e_49eb_a23b_c77ad695ea89.slice/cri-containerd-c74c0f72f3241ed1f375e49cf2be8cba90d840c33dd9437fdf127d8fd5ec5f9d.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podffa6b80e_ba8e_49eb_a23b_c77ad695ea89.slice/cri-containerd-29b254997bdb960f2021ed8f343e10814fccfad3e705ada23a142fb08540d251.scope
    105      cgroup_device   multi                                          
