alloc: 201.79MB (211597120 bytes)
total-alloc: 2.36GB (2534087304 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 65430225
frees: 63296531
heap-alloc: 201.79MB (211597120 bytes)
heap-sys: 247.39MB (259407872 bytes)
heap-idle: 21.66MB (22708224 bytes)
heap-in-use: 225.73MB (236699648 bytes)
heap-released: 3.00MB (3145728 bytes)
heap-objects: 2133694
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.55MB (3722400 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1256473 bytes)
gc-sys: 6.01MB (6305184 bytes)
next-gc: when heap-alloc >= 214.44MB (224859544 bytes)
last-gc: 2024-10-30 08:22:56.75857835 +0000 UTC
gc-pause-total: 19.423502ms
gc-pause: 113330
gc-pause-end: 1730276576758578350
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005310174258531151
enable-gc: true
debug-gc: false
