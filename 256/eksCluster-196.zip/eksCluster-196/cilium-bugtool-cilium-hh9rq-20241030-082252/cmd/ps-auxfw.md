USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         709  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         715  0.0  0.1 1242420 11580 ?       Rl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         690  0.0  0.2 1240432 16336 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         717  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         718  0.0  0.2 1240432 16336 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         664  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.9  4.9 1606336 393984 ?      Ssl  08:02   0:47 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.0 1229744 6884 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
