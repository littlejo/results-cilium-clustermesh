CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98e2ddde_bb18_4d5d_8fac_d8bd7fc37840.slice/cri-containerd-e502242309c974c6ec17690d3d0327d9e97bb5a7c4397c901f7a022104ea6de6.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98e2ddde_bb18_4d5d_8fac_d8bd7fc37840.slice/cri-containerd-e3f2800e7be4aabea7d335582c79c4091ea21d013b503c40bf4a173685a70881.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b41304f_7821_49a2_a6a0_8c9828e59e93.slice/cri-containerd-eb0b77541d0c6583d9977a43770ecef9810b8cd1dd96da9fac2754ff6651a374.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7b41304f_7821_49a2_a6a0_8c9828e59e93.slice/cri-containerd-bc37393e95387390873239461a44f603fc9e1b3305d94099c767e111d0aa932c.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f127c85_97a1_40c5_a227_31af1e4ae462.slice/cri-containerd-56f5df7442866a72c99926e6da20eba7782ef1b5f28609b4d972eb2021b93b2f.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f127c85_97a1_40c5_a227_31af1e4ae462.slice/cri-containerd-b14c3f4c1cf5ff9b12ffae8de12faf7ea5dcbc0b5322888b74f184c41c0162ff.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6af54705_bbc5_46ff_a1f9_3455b269a61b.slice/cri-containerd-c2f2099607557008b65b45e057d476e0faae586ffe170b4afde2bf59e36c9f29.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6af54705_bbc5_46ff_a1f9_3455b269a61b.slice/cri-containerd-b2a0cd131ebc54d7f70329b7d57f85a4f5603b88621ae4414afb8f459804d8c6.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6953dc_beb5_4c06_adb7_7a2369570bba.slice/cri-containerd-50f911dfa188bd7379c2bbba41dfedebd945a64d0f6fb671ba9943ba6fe269c7.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b6953dc_beb5_4c06_adb7_7a2369570bba.slice/cri-containerd-80d5b4ad102741004fa7c8a013cb83e370ee5d10004ef0074d6562d1e7b7de11.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f450794_bbd6_4313_8c3d_473dd974d9f1.slice/cri-containerd-9b3178b462b698412710020eb2628d125fec046337cacb6fd86383c937bce035.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f450794_bbd6_4313_8c3d_473dd974d9f1.slice/cri-containerd-3411edb6d581a6f5d2c604874fb264f69c0f117f5119cb5bb64c835ae41bb93f.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-8715f2855d3daea0773a662d7a5206d811d9c2f97f83f382cfdef58cc1e25954.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-e5952d194698b576240081d548c0504cd66f2619dde3be9c9ab8e75877c35f87.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-60d3495f2aee62da1a2989fefd48ebf0c3135890162b17ee59b1e8f86649fc56.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-2e5e8572aeaa284236d952d757c4b7295d2c50993a717f9bc958b8eda567298f.scope
    657      cgroup_device   multi                                          
