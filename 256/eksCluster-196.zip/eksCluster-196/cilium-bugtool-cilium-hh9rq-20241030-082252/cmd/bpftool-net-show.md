xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 577
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 567
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 560
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 515
lxceacb912aefca(12) clsact/ingress cil_from_container-lxceacb912aefca id 543
lxcfc624effe421(14) clsact/ingress cil_from_container-lxcfc624effe421 id 532
lxc95c8d2181174(18) clsact/ingress cil_from_container-lxc95c8d2181174 id 631

flow_dissector:

netfilter:

