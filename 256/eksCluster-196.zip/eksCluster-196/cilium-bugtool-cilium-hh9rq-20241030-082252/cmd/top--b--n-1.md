top - 08:22:53 up 29 min,  0 users,  load average: 0.20, 0.29, 0.23
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 55.2 us, 17.2 sy,  0.0 ni, 10.3 id,  0.0 wa,  0.0 hi, 17.2 si,  0.0 st
MiB Mem :   7814.2 total,   4474.2 free,   1194.9 used,   2145.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6434.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    715 root      20   0 1244596  22792  14524 S  53.3   0.3   0:00.12 hubble
      1 root      20   0 1606336 393984  77952 S  13.3   4.9   0:47.38 cilium-+
    414 root      20   0 1229744   6884   2864 S   0.0   0.1   0:01.13 cilium-+
    664 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0 1240432  16552  11420 S   0.0   0.2   0:00.02 cilium-+
    709 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    742 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    748 root      20   0 1616264   8740   6236 S   0.0   0.1   0:00.00 runc:[2+
    755 root      20   0    3132    984    864 R   0.0   0.0   0:00.00 bpftool
