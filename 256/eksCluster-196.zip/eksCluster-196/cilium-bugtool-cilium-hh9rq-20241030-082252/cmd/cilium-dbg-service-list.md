ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.141.158:443 (active)   
                                         2 => 172.31.232.144:443 (active)   
2    10.100.23.103:443    ClusterIP      1 => 172.31.145.37:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.196.0.188:53 (active)      
                                         2 => 10.196.0.172:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.196.0.188:9153 (active)    
                                         2 => 10.196.0.172:9153 (active)    
5    10.100.40.127:2379   ClusterIP      1 => 10.196.0.149:2379 (active)    
