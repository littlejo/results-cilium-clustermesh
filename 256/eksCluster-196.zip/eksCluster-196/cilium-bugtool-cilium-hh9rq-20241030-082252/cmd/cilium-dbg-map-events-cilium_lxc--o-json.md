{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.132:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:05.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.145.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:05.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.29:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:05.736Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.333Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.339Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.422Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.586Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:10.653Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.540Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.541Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.541Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.570Z",
  "value": "id=2661  sec_id=6480193 flags=0x0000 ifindex=16  mac=BE:72:0A:3E:0D:A4 nodemac=C2:40:72:59:C6:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.541Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.541Z",
  "value": "id=2661  sec_id=6480193 flags=0x0000 ifindex=16  mac=BE:72:0A:3E:0D:A4 nodemac=C2:40:72:59:C6:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.541Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.541Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.738Z",
  "value": "id=1320  sec_id=6480193 flags=0x0000 ifindex=18  mac=D2:5F:FC:2D:5E:D2 nodemac=0A:1C:92:A2:8A:09"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.196.0.17:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.083Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.544Z",
  "value": "id=1320  sec_id=6480193 flags=0x0000 ifindex=18  mac=D2:5F:FC:2D:5E:D2 nodemac=0A:1C:92:A2:8A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.545Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.545Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:35.545Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.640Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.649Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.649Z",
  "value": "id=1320  sec_id=6480193 flags=0x0000 ifindex=18  mac=D2:5F:FC:2D:5E:D2 nodemac=0A:1C:92:A2:8A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.650Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.590Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.591Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.591Z",
  "value": "id=1320  sec_id=6480193 flags=0x0000 ifindex=18  mac=D2:5F:FC:2D:5E:D2 nodemac=0A:1C:92:A2:8A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.591Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.222:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.591Z",
  "value": "id=63    sec_id=4     flags=0x0000 ifindex=10  mac=D6:13:39:43:E9:E6 nodemac=5A:17:45:EA:E2:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.591Z",
  "value": "id=1865  sec_id=6459513 flags=0x0000 ifindex=12  mac=6E:80:36:1B:3A:6B nodemac=B6:B7:91:1E:4E:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.592Z",
  "value": "id=1320  sec_id=6480193 flags=0x0000 ifindex=18  mac=D2:5F:FC:2D:5E:D2 nodemac=0A:1C:92:A2:8A:09"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.196.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.592Z",
  "value": "id=3648  sec_id=6459513 flags=0x0000 ifindex=14  mac=7A:18:06:F8:DF:87 nodemac=8E:BE:9F:F2:FA:D3"
}

