Endpoint ID: 63
Path: /sys/fs/bpf/tc/globals/cilium_policy_00063

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658231   20947     0        
Allow    Ingress     1          ANY          NONE         disabled    17816     208       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1320
Path: /sys/fs/bpf/tc/globals/cilium_policy_01320

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11368706   111568    0        
Allow    Ingress     1          ANY          NONE         disabled    9400921    98436     0        
Allow    Egress      0          ANY          NONE         disabled    11244783   111774    0        


Endpoint ID: 1865
Path: /sys/fs/bpf/tc/globals/cilium_policy_01865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115187   1318      0        
Allow    Egress      0          ANY          NONE         disabled    17494    190       0        


Endpoint ID: 3456
Path: /sys/fs/bpf/tc/globals/cilium_policy_03456

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3648
Path: /sys/fs/bpf/tc/globals/cilium_policy_03648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114013   1302      0        
Allow    Egress      0          ANY          NONE         disabled    17880    194       0        


