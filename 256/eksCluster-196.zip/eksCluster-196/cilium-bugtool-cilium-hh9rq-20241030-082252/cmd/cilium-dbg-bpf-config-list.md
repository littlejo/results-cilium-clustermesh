KEY             VALUE
AgentLiveness   1814296476617
UTimeOffset     3379442949218750
