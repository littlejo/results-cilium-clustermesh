alloc: 105.17MB (110279560 bytes)
total-alloc: 2.18GB (2339207064 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 62309272
frees: 61520623
heap-alloc: 105.17MB (110279560 bytes)
heap-sys: 252.38MB (264642560 bytes)
heap-idle: 89.95MB (94322688 bytes)
heap-in-use: 162.43MB (170319872 bytes)
heap-released: 6.02MB (6316032 bytes)
heap-objects: 788649
stack-in-use: 63.59MB (66682880 bytes)
stack-sys: 63.59MB (66682880 bytes)
stack-mspan-inuse: 2.78MB (2915200 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1264089 bytes)
gc-sys: 6.03MB (6327952 bytes)
next-gc: when heap-alloc >= 215.24MB (225693128 bytes)
last-gc: 2024-10-30 08:23:16.895447948 +0000 UTC
gc-pause-total: 43.395613ms
gc-pause: 123290
gc-pause-end: 1730276596895447948
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005677675348942986
enable-gc: true
debug-gc: false
