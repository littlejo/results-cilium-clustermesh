key: 3f 00 00 00  value: fe 01 00 00
key: 28 05 00 00  value: 73 02 00 00
key: 49 07 00 00  value: 19 02 00 00
key: 40 0e 00 00  value: 16 02 00 00
Found 4 elements
