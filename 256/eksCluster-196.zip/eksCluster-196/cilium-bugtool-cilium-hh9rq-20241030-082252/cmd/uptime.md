 08:22:53 up 29 min,  0 users,  load average: 0.20, 0.29, 0.23
