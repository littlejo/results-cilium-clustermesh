[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-2e5e8572aeaa284236d952d757c4b7295d2c50993a717f9bc958b8eda567298f.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-e5952d194698b576240081d548c0504cd66f2619dde3be9c9ab8e75877c35f87.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ef7513e_bb67_4c68_a0b9_5ac2a39ecd55.slice/cri-containerd-8715f2855d3daea0773a662d7a5206d811d9c2f97f83f382cfdef58cc1e25954.scope"
      }
    ],
    "ips": [
      "10.196.0.149"
    ],
    "name": "clustermesh-apiserver-7cdd8f47bf-bbggp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6af54705_bbc5_46ff_a1f9_3455b269a61b.slice/cri-containerd-c2f2099607557008b65b45e057d476e0faae586ffe170b4afde2bf59e36c9f29.scope"
      }
    ],
    "ips": [
      "10.196.0.188"
    ],
    "name": "coredns-cc6ccd49c-d8r76",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0f127c85_97a1_40c5_a227_31af1e4ae462.slice/cri-containerd-b14c3f4c1cf5ff9b12ffae8de12faf7ea5dcbc0b5322888b74f184c41c0162ff.scope"
      }
    ],
    "ips": [
      "10.196.0.172"
    ],
    "name": "coredns-cc6ccd49c-v745x",
    "namespace": "kube-system"
  }
]

