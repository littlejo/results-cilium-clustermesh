{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.227Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.227Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.222.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.227Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.947Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:09.954Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.009Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.076Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:10.194Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.618Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.618Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.618Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:36.650Z",
  "value": "id=709   sec_id=2364386 flags=0x0000 ifindex=16  mac=E2:14:95:47:2C:35 nodemac=8A:BB:D5:74:FF:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.618Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.618Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.618Z",
  "value": "id=709   sec_id=2364386 flags=0x0000 ifindex=16  mac=E2:14:95:47:2C:35 nodemac=8A:BB:D5:74:FF:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:37.618Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.207Z",
  "value": "id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.71.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:14.515Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.405Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.406Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.406Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.406Z",
  "value": "id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.404Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.405Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.406Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.406Z",
  "value": "id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.404Z",
  "value": "id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.405Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.405Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.405Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.405Z",
  "value": "id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.405Z",
  "value": "id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.405Z",
  "value": "id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.71.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.405Z",
  "value": "id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8"
}

