 08:23:00 up 36 min,  0 users,  load average: 0.76, 0.33, 0.21
