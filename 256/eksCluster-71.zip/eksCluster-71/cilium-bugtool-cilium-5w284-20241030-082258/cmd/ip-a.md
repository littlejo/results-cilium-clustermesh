1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5e:c3:af:ec:2b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.209.21/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3214sec preferred_lft 3214sec
    inet6 fe80::85e:c3ff:feaf:ec2b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:1b:a9:80:d6:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.222.142/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::81b:a9ff:fe80:d675/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:22:8a:4c:13:fe brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8022:8aff:fe4c:13fe/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:e0:d2:92:a4:4f brd ff:ff:ff:ff:ff:ff
    inet 10.71.0.254/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a0e0:d2ff:fe92:a44f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:5d:ce:cf:df:61 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::945d:ceff:fecf:df61/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:71:0d:94:e1:a8 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8071:dff:fe94:e1a8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc56296fa65f8e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:21:5c:bd:c8:ae brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::6421:5cff:febd:c8ae/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc95d8bdfdec62@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:17:1d:b9:ac:cf brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::817:1dff:feb9:accf/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc45d828174b90@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:c8:78:78:ae:bd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::50c8:78ff:fe78:aebd/64 scope link 
       valid_lft forever preferred_lft forever
