ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.160.118:443 (active)   
                                        2 => 172.31.226.207:443 (active)   
2    10.100.91.184:443   ClusterIP      1 => 172.31.209.21:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.71.0.157:53 (active)       
                                        2 => 10.71.0.30:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.71.0.157:9153 (active)     
                                        2 => 10.71.0.30:9153 (active)      
5    10.100.37.8:2379    ClusterIP      1 => 10.71.0.158:2379 (active)     
