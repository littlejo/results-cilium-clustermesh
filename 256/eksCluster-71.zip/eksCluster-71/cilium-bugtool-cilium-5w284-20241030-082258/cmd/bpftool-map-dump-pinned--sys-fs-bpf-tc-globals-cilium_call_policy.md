key: db 02 00 00  value: 17 02 00 00
key: ec 04 00 00  value: 10 02 00 00
key: 08 08 00 00  value: 78 02 00 00
key: 3e 0c 00 00  value: ff 01 00 00
Found 4 elements
