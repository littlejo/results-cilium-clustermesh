Endpoint ID: 427
Path: /sys/fs/bpf/tc/globals/cilium_policy_00427

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 731
Path: /sys/fs/bpf/tc/globals/cilium_policy_00731

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171473   1959      0        
Allow    Egress      0          ANY          NONE         disabled    20405    227       0        


Endpoint ID: 1260
Path: /sys/fs/bpf/tc/globals/cilium_policy_01260

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1668980   21140     0        
Allow    Ingress     1          ANY          NONE         disabled    26168     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2056
Path: /sys/fs/bpf/tc/globals/cilium_policy_02056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11451070   112565    0        
Allow    Ingress     1          ANY          NONE         disabled    9427070    98699     0        
Allow    Egress      0          ANY          NONE         disabled    11397277   113286    0        


Endpoint ID: 3134
Path: /sys/fs/bpf/tc/globals/cilium_policy_03134

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171708   1968      0        
Allow    Egress      0          ANY          NONE         disabled    20869    234       0        


