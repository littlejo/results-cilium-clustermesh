USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         676  0.0  0.2 1240432 16364 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         691  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         692  0.0  0.2 1240432 16364 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         640  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         639  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         625  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         619  0.0  0.0 1228744 3604 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  2.7  4.8 1606080 385504 ?      Ssl  07:52   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229488 7048 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
