IP ADDRESS         LOCAL ENDPOINT INFO
10.71.0.157:0      id=731   sec_id=2362144 flags=0x0000 ifindex=12  mac=82:AF:9F:52:C9:BD nodemac=66:21:5C:BD:C8:AE   
10.71.0.30:0       id=3134  sec_id=2362144 flags=0x0000 ifindex=14  mac=7E:E8:E5:23:34:05 nodemac=0A:17:1D:B9:AC:CF   
172.31.209.21:0    (localhost)                                                                                        
172.31.222.142:0   (localhost)                                                                                        
10.71.0.254:0      (localhost)                                                                                        
10.71.0.41:0       id=1260  sec_id=4     flags=0x0000 ifindex=10  mac=CA:6E:14:6D:F8:88 nodemac=82:71:0D:94:E1:A8     
10.71.0.158:0      id=2056  sec_id=2364386 flags=0x0000 ifindex=18  mac=6E:7B:9F:D4:EE:29 nodemac=52:C8:78:78:AE:BD   
