xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 565
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 558
cilium_host(7) clsact/egress cil_from_host-cilium_host id 557
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 519
lxc56296fa65f8e(12) clsact/ingress cil_from_container-lxc56296fa65f8e id 546
lxc95d8bdfdec62(14) clsact/ingress cil_from_container-lxc95d8bdfdec62 id 515
lxc45d828174b90(18) clsact/ingress cil_from_container-lxc45d828174b90 id 624

flow_dissector:

netfilter:

