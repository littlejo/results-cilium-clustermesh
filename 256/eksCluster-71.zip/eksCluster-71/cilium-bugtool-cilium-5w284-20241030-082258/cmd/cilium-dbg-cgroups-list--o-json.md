[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-7a373efac6b1973c7d15f66114e78c825f001d21ae5be7371d56edaffd96a600.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-bd627c5100352b6170c23c00b0506b77cbb7d3ceec747fc15200f3e5599d433f.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-a6b61d2b2f6c8d7f416c5d8e0ff3cb51cfa1258d8af9468af8f8f44467336a40.scope"
      }
    ],
    "ips": [
      "10.71.0.158"
    ],
    "name": "clustermesh-apiserver-69466f997f-744pc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76ff0b7_40bf_4549_ae96_6aac90f18827.slice/cri-containerd-06e43dee62bb5f3c3cbcfb92d40277415fac120d08685db2da02316ab7d34ca6.scope"
      }
    ],
    "ips": [
      "10.71.0.30"
    ],
    "name": "coredns-cc6ccd49c-r5k9r",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c9d8303_bba8_4e8e_8ad3_db923df9f43d.slice/cri-containerd-12636047231c520781c75d980d3bd54286b35f3885b83647d6c87ce6b7f407ae.scope"
      }
    ],
    "ips": [
      "10.71.0.157"
    ],
    "name": "coredns-cc6ccd49c-v4tl7",
    "namespace": "kube-system"
  }
]

