KEY             VALUE
AgentLiveness   2227790277066
UTimeOffset     3379442156250000
