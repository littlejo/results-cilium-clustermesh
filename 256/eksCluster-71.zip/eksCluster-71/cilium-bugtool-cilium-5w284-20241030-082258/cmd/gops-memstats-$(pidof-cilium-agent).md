alloc: 205.46MB (215441072 bytes)
total-alloc: 2.25GB (2413978424 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 63221073
frees: 60985751
heap-alloc: 205.46MB (215441072 bytes)
heap-sys: 255.20MB (267599872 bytes)
heap-idle: 27.98MB (29335552 bytes)
heap-in-use: 227.23MB (238264320 bytes)
heap-released: 11.84MB (12419072 bytes)
heap-objects: 2235322
stack-in-use: 64.75MB (67895296 bytes)
stack-sys: 64.75MB (67895296 bytes)
stack-mspan-inuse: 3.63MB (3801280 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1055937 bytes)
gc-sys: 6.02MB (6315472 bytes)
next-gc: when heap-alloc >= 233.76MB (245114344 bytes)
last-gc: 2024-10-30 08:23:00.638619551 +0000 UTC
gc-pause-total: 14.216867ms
gc-pause: 162078
gc-pause-end: 1730276580638619551
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0003836292883171687
enable-gc: true
debug-gc: false
