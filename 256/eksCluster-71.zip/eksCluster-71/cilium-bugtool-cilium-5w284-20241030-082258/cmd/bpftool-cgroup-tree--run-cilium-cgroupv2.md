CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeca79e7f_d814_469a_a05c_1902d70a01c4.slice/cri-containerd-4fc95a209e897c71e0ccf4c6c73ae5718b4b9cfd589a118ccb4b5ac047a2c651.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeca79e7f_d814_469a_a05c_1902d70a01c4.slice/cri-containerd-f1d683ac70e0e7e125f0a787fa9948fd269a9cb07e16ff4105186bdf247caa31.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76ff0b7_40bf_4549_ae96_6aac90f18827.slice/cri-containerd-d9837fa9843a3719fa9efa341720f0a201e3851c1b2911cc61e314c80fd0e50f.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda76ff0b7_40bf_4549_ae96_6aac90f18827.slice/cri-containerd-06e43dee62bb5f3c3cbcfb92d40277415fac120d08685db2da02316ab7d34ca6.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c9d8303_bba8_4e8e_8ad3_db923df9f43d.slice/cri-containerd-f8743c3dc76dee8a4314533840e22b7f1bfcc9e1e8dda2e5ec2a2ec6964742b2.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c9d8303_bba8_4e8e_8ad3_db923df9f43d.slice/cri-containerd-12636047231c520781c75d980d3bd54286b35f3885b83647d6c87ce6b7f407ae.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod493b8145_3a04_44f8_b560_227a3c03edb6.slice/cri-containerd-a22a6be9c9dd516b1e071812534180ec0c414f724288e8c3caf46f558254f55b.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod493b8145_3a04_44f8_b560_227a3c03edb6.slice/cri-containerd-cbfdc62dafd240e9bc05b76810bb8b61abe0cf7e0e46c300e9b8f8573eabddc7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-a6b61d2b2f6c8d7f416c5d8e0ff3cb51cfa1258d8af9468af8f8f44467336a40.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-47c7ea63a0b56d0e8e8a9ad54279d5ced66e023690208be3408f35b6c78835d2.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-7a373efac6b1973c7d15f66114e78c825f001d21ae5be7371d56edaffd96a600.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01055c57_086c_464c_b34e_d8aee7833b8b.slice/cri-containerd-bd627c5100352b6170c23c00b0506b77cbb7d3ceec747fc15200f3e5599d433f.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f5f0e0_6dac_4c13_886b_7ec9f8d929b6.slice/cri-containerd-470845fc9339f4024f4b9d4b618428dc23e02cc698013154be8425e1f0dab9f9.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93f5f0e0_6dac_4c13_886b_7ec9f8d929b6.slice/cri-containerd-d5d39169355fddfbfd74652e58d19e7cc275f2898ce8939ced2ee6090d0c43c5.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f7a7cbb_3b84_439e_8b13_ca8b2ec14e06.slice/cri-containerd-38c6979ab2e023d11f342d10adc06db8c112bc1aa2b9d5e250c4301beb197a24.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f7a7cbb_3b84_439e_8b13_ca8b2ec14e06.slice/cri-containerd-692c050140ba2251707f7485bb642e49195db46a0b37d68d393989c2c28ce2c7.scope
    102      cgroup_device   multi                                          
