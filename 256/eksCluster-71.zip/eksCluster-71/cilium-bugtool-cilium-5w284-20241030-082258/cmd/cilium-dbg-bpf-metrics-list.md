REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35754     2822110     677    bpf_overlay.c
Interface                 INGRESS     630451    130556470   1132   bpf_host.c
Success                   EGRESS      15300     1199866     1694   bpf_host.c
Success                   EGRESS      264536    33550316    1308   bpf_lxc.c
Success                   EGRESS      35100     2779158     53     encap.h
Success                   INGRESS     305979    34321646    86     l3.h
Success                   INGRESS     327084    35987936    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
