REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36402     2885374     677    bpf_overlay.c
Interface                 INGRESS     650336    132874604   1132   bpf_host.c
Success                   EGRESS      16520     1300692     1694   bpf_host.c
Success                   EGRESS      276923    34460515    1308   bpf_lxc.c
Success                   EGRESS      36760     2909245     53     encap.h
Success                   INGRESS     318781    36124996    86     l3.h
Success                   INGRESS     339314    37753724    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
