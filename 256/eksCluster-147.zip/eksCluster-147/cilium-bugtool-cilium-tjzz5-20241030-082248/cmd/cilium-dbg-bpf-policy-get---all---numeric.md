Endpoint ID: 515
Path: /sys/fs/bpf/tc/globals/cilium_policy_00515

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631302   20566     0        
Allow    Ingress     1          ANY          NONE         disabled    19210     226       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 865
Path: /sys/fs/bpf/tc/globals/cilium_policy_00865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    122982   1413      0        
Allow    Egress      0          ANY          NONE         disabled    16301    176       0        


Endpoint ID: 1204
Path: /sys/fs/bpf/tc/globals/cilium_policy_01204

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11543361   115658    0        
Allow    Ingress     1          ANY          NONE         disabled    10277229   108304    0        
Allow    Egress      0          ANY          NONE         disabled    13775572   135017    0        


Endpoint ID: 1225
Path: /sys/fs/bpf/tc/globals/cilium_policy_01225

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121596   1392      0        
Allow    Egress      0          ANY          NONE         disabled    16669    180       0        


Endpoint ID: 2135
Path: /sys/fs/bpf/tc/globals/cilium_policy_02135

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


