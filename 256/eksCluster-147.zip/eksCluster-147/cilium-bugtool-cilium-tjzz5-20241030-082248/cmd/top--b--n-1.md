top - 08:22:49 up 31 min,  0 users,  load average: 0.06, 0.19, 0.18
Tasks:  12 total,   1 running,  11 sleeping,   0 stopped,   0 zombie
%Cpu(s): 73.3 us, 20.0 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4483.9 free,   1183.6 used,   2146.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385460  78456 S 100.0   4.8   0:55.25 cilium-+
    636 root      20   0 1240432  16328  11292 S   6.7   0.2   0:00.04 cilium-+
    730 root      20   0 1243764  17912  12672 S   6.7   0.2   0:00.01 hubble
    392 root      20   0 1229744   8012   3836 S   0.0   0.1   0:01.14 cilium-+
    642 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    643 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    653 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    670 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    688 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    714 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    742 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
