CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4030e47_157d_4484_90c2_4f5a44898c85.slice/cri-containerd-c2cae01bfb07b45c4f46d5b6ff42701961d902f46c6f50868e3b2206a4b37caa.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4030e47_157d_4484_90c2_4f5a44898c85.slice/cri-containerd-3eec30e689ad9bbb1fcd8c344a5d1561a7dba2f3fb1c7e1e9d46468deb0c4529.scope
    531      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c5d321c_130d_4127_8e31_ee50f2ad069e.slice/cri-containerd-708efd90cef26a936369452c7a3df14786c659ae64fb275027be7111b539d5de.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5c5d321c_130d_4127_8e31_ee50f2ad069e.slice/cri-containerd-f23b6b9e843dda26ff99173343bad0224e58c975e6954cd5d1c12e97ae228285.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod710b584f_ac1b_4e76_8f67_f6359d06298d.slice/cri-containerd-7a405893f8a44bfc6d9c1c8eb76add1c2acf2cef38b6e8e597c4f7a1e5679770.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod710b584f_ac1b_4e76_8f67_f6359d06298d.slice/cri-containerd-3b4b02300f6f8f48c8a03ffdf04930e00187336a747dc41b292a7c64aacef6e8.scope
    541      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e1bd886_0f3f_4876_8f96_d12b6a627c2b.slice/cri-containerd-e197382a3e29d7a624f1455a39bbcbafcaea0c9d04bb8d0662e69495eeb013ce.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2e1bd886_0f3f_4876_8f96_d12b6a627c2b.slice/cri-containerd-0da47c7e9be11d986225bfd0354982f61526b5877cea0b3842d34549f87ff20f.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707112c8_dd8d_4e9f_af4b_09d858c2cdb5.slice/cri-containerd-d00a744d10e17e411af5fc358d9c28ad393f8f8129e70fca6e478506e06fefa4.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod707112c8_dd8d_4e9f_af4b_09d858c2cdb5.slice/cri-containerd-b92f935a585402ca171e3164a7dccaebc4caeddfcf08d2f46f49a32bbf5f442d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c500db9_089e_4f74_a77d_912f034a8ed8.slice/cri-containerd-73ce7b061eeac3b81704479a663c5c4ac8e3e5d7c0761ea55faed669b78ce625.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4c500db9_089e_4f74_a77d_912f034a8ed8.slice/cri-containerd-df0805cbb0305e9894d7c6d0a482bb024023770e38651b018bb41345344195c7.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-d48a4c0b38ee082c2e3539b45f165b0354ffd4cb067c518dafb8f49bcfd5f23d.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-1f9d0d432727ab7edd40b05a85fdac2b6f7ebf4415a1cda04299faebc6286c0c.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-8da743363071ba7ca4cd2006bdbfe9c23b3179fd6f2a63166c068217bac82317.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-cfa0c640c44acb7e2a51eafa371d4cbf0fcc2986a4f551cdbf94a18b303fbc85.scope
    656      cgroup_device   multi                                          
