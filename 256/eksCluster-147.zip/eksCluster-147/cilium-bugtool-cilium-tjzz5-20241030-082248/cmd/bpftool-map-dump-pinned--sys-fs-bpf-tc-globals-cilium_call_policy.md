key: 03 02 00 00  value: 1e 02 00 00
key: 61 03 00 00  value: 16 02 00 00
key: b4 04 00 00  value: 76 02 00 00
key: c9 04 00 00  value: 01 02 00 00
Found 4 elements
