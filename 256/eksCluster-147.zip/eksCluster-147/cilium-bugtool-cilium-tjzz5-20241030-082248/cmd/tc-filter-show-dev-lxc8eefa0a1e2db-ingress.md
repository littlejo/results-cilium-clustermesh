filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8eefa0a1e2db direct-action not_in_hw id 522 tag 5cc19631b8fa9b98 jited 
