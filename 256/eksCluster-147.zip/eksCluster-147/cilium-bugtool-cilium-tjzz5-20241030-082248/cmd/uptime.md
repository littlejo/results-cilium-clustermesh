 08:22:49 up 31 min,  0 users,  load average: 0.06, 0.19, 0.18
