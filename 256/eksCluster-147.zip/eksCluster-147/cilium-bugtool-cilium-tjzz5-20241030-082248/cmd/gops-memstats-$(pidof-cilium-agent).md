alloc: 192.04MB (201367240 bytes)
total-alloc: 2.27GB (2436407288 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 63841038
frees: 61834186
heap-alloc: 192.04MB (201367240 bytes)
heap-sys: 247.48MB (259506176 bytes)
heap-idle: 27.23MB (28549120 bytes)
heap-in-use: 220.26MB (230957056 bytes)
heap-released: 1.10MB (1155072 bytes)
heap-objects: 2006852
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 3.47MB (3636960 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.17MB (1229457 bytes)
gc-sys: 6.03MB (6319616 bytes)
next-gc: when heap-alloc >= 220.51MB (231216728 bytes)
last-gc: 2024-10-30 08:22:49.504938257 +0000 UTC
gc-pause-total: 32.574459ms
gc-pause: 6595779
gc-pause-end: 1730276569504938257
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005847650282387679
enable-gc: true
debug-gc: false
