filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf7cddb5e4f66 direct-action not_in_hw id 510 tag 5d42e3303e963bb7 jited 
