ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.152.224:443 (active)   
                                         2 => 172.31.193.126:443 (active)   
2    10.100.239.101:443   ClusterIP      1 => 172.31.255.51:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.147.0.89:53 (active)       
                                         2 => 10.147.0.79:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.147.0.89:9153 (active)     
                                         2 => 10.147.0.79:9153 (active)     
5    10.100.219.41:2379   ClusterIP      1 => 10.147.0.232:2379 (active)    
