USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         688  0.0  0.1 1616264 8640 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         670  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         653  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         643  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         642  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         636  0.0  0.2 1240432 16328 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         695  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         696  0.0  0.2 1240432 16332 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  4.3  4.7 1606080 382992 ?      Ssl  08:01   0:55 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1229744 8012 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
