{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.73:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.042Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.236.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.042Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.255.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.042Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:47.705Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:47.713Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:47.802Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:47.885Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:47.938Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:46.944Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:46.947Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:46.948Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:46.974Z",
  "value": "id=1049  sec_id=4859696 flags=0x0000 ifindex=16  mac=52:E8:BC:DE:A1:A1 nodemac=5A:C3:D4:B9:9C:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:46.975Z",
  "value": "id=1049  sec_id=4859696 flags=0x0000 ifindex=16  mac=52:E8:BC:DE:A1:A1 nodemac=5A:C3:D4:B9:9C:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:47.944Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:47.945Z",
  "value": "id=1049  sec_id=4859696 flags=0x0000 ifindex=16  mac=52:E8:BC:DE:A1:A1 nodemac=5A:C3:D4:B9:9C:47"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:47.945Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:47.946Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.569Z",
  "value": "id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.147.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.144Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.618Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.618Z",
  "value": "id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.619Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.619Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.618Z",
  "value": "id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.618Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.619Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.620Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.618Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.618Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.619Z",
  "value": "id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.619Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.155:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.618Z",
  "value": "id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.618Z",
  "value": "id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.619Z",
  "value": "id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.147.0.79:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.619Z",
  "value": "id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21"
}

