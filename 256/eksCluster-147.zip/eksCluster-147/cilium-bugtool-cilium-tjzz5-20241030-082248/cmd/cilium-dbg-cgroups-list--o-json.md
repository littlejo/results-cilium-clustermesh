[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-1f9d0d432727ab7edd40b05a85fdac2b6f7ebf4415a1cda04299faebc6286c0c.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-cfa0c640c44acb7e2a51eafa371d4cbf0fcc2986a4f551cdbf94a18b303fbc85.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6b5f1a91_20c6_4d5f_9aad_215675013047.slice/cri-containerd-8da743363071ba7ca4cd2006bdbfe9c23b3179fd6f2a63166c068217bac82317.scope"
      }
    ],
    "ips": [
      "10.147.0.232"
    ],
    "name": "clustermesh-apiserver-7988b999c5-x95pw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod710b584f_ac1b_4e76_8f67_f6359d06298d.slice/cri-containerd-7a405893f8a44bfc6d9c1c8eb76add1c2acf2cef38b6e8e597c4f7a1e5679770.scope"
      }
    ],
    "ips": [
      "10.147.0.79"
    ],
    "name": "coredns-cc6ccd49c-6chv4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc4030e47_157d_4484_90c2_4f5a44898c85.slice/cri-containerd-c2cae01bfb07b45c4f46d5b6ff42701961d902f46c6f50868e3b2206a4b37caa.scope"
      }
    ],
    "ips": [
      "10.147.0.89"
    ],
    "name": "coredns-cc6ccd49c-mbcr9",
    "namespace": "kube-system"
  }
]

