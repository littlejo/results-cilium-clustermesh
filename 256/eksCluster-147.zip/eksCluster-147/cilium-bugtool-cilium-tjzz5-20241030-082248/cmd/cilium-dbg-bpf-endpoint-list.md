IP ADDRESS        LOCAL ENDPOINT INFO
10.147.0.79:0     id=1225  sec_id=4855570 flags=0x0000 ifindex=14  mac=A6:27:74:56:AC:C0 nodemac=0E:5C:C6:38:02:21   
10.147.0.89:0     id=865   sec_id=4855570 flags=0x0000 ifindex=12  mac=3A:CF:3C:98:5A:7F nodemac=92:DC:6F:E0:B4:C0   
10.147.0.155:0    id=515   sec_id=4     flags=0x0000 ifindex=10  mac=5A:51:6F:1F:06:76 nodemac=B6:49:B6:9B:DD:2E     
172.31.255.51:0   (localhost)                                                                                        
10.147.0.73:0     (localhost)                                                                                        
10.147.0.232:0    id=1204  sec_id=4859696 flags=0x0000 ifindex=18  mac=36:D7:F1:A9:2A:17 nodemac=E6:41:A5:FE:19:36   
172.31.236.31:0   (localhost)                                                                                        
