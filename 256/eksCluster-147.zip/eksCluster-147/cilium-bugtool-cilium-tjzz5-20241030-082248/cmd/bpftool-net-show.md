xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 571
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 564
cilium_host(7) clsact/egress cil_from_host-cilium_host id 565
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 486
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 547
lxc8eefa0a1e2db(12) clsact/ingress cil_from_container-lxc8eefa0a1e2db id 522
lxcf7cddb5e4f66(14) clsact/ingress cil_from_container-lxcf7cddb5e4f66 id 510
lxcb74111a201c4(18) clsact/ingress cil_from_container-lxcb74111a201c4 id 628

flow_dissector:

netfilter:

