markdown output at /tmp/cilium-bugtool-20241030-082249.067+0000-UTC-576745822/cmd/cilium-debuginfo-20241030-082320.461+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.067+0000-UTC-576745822/cmd/cilium-debuginfo-20241030-082320.461+0000-UTC.json
