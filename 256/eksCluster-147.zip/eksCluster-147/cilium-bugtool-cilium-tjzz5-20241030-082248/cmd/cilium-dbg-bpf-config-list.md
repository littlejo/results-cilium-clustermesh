KEY             VALUE
AgentLiveness   1929620323221
UTimeOffset     3379442716796875
