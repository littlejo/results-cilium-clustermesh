alloc: 144.16MB (151162704 bytes)
total-alloc: 2.34GB (2516565800 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64947328
frees: 63425175
heap-alloc: 144.16MB (151162704 bytes)
heap-sys: 251.38MB (263593984 bytes)
heap-idle: 73.79MB (77373440 bytes)
heap-in-use: 177.59MB (186220544 bytes)
heap-released: 5.60MB (5873664 bytes)
heap-objects: 1522153
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.03MB (3177120 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.19MB (1247633 bytes)
gc-sys: 6.00MB (6295088 bytes)
next-gc: when heap-alloc >= 215.04MB (225485032 bytes)
last-gc: 2024-10-30 08:23:01.628604681 +0000 UTC
gc-pause-total: 26.669846ms
gc-pause: 7932829
gc-pause-end: 1730276581628604681
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.000415484089993302
enable-gc: true
debug-gc: false
