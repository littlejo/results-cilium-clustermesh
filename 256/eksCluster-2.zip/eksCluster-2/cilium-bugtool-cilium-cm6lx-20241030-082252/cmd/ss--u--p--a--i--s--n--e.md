Total: 688
TCP:   2386 (estab 435, closed 1932, orphaned 0, timewait 1081)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  454       444       10       
INET	  464       450       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:43853      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=40)) ino:32015 sk:5f6 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.178.139%ens5:68         0.0.0.0:*    uid:192 ino:67938 sk:5f7 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:32882 sk:5f8 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15218 sk:5f9 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:32881 sk:5fa cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15219 sk:5fb cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::426:20ff:fe33:3fa3]%ens5:546           [::]:*    uid:192 ino:16441 sk:5fc cgroup:unreachable:c4e v6only:1 <->                   
