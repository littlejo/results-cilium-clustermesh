markdown output at /tmp/cilium-bugtool-20241030-082253.572+0000-UTC-1147469609/cmd/cilium-debuginfo-20241030-082324.755+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.572+0000-UTC-1147469609/cmd/cilium-debuginfo-20241030-082324.755+0000-UTC.json
