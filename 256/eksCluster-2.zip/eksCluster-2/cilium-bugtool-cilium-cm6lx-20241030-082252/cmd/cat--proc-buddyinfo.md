Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      1      2     19      3      8      3     10      5      6      2    859 
