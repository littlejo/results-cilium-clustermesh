key: d9 01 00 00  value: 26 02 00 00
key: 48 03 00 00  value: 2b 02 00 00
key: 3a 07 00 00  value: 67 02 00 00
key: fe 08 00 00  value: 0f 02 00 00
Found 4 elements
