USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         650  0.0  0.2 1240432 16412 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         664  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         665  0.0  0.2 1240432 16412 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         633  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.4  4.8 1606336 384792 ?      Ssl  07:54   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         397  0.0  0.0 1229488 7020 ?        Sl   07:54   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
