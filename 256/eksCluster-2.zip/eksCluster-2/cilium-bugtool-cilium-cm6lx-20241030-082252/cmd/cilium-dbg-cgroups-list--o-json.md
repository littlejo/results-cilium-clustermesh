[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-3991778e7737956c5a3956b5bc914c8565545c286d7347033b80061b09ee1ae1.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-066c4920cdd13018e1a6353c0c970d81ba83ef89a8ccd027a10f456b119071c7.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-5251790a42ab96d07b29faa79adde5c4e7799f575a60b3fb8ab14faad0ce01ba.scope"
      }
    ],
    "ips": [
      "10.2.0.215"
    ],
    "name": "clustermesh-apiserver-6d858b6856-7p5gj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c5573fe_5d34_4348_b571_ae4223fab495.slice/cri-containerd-bb1ecd95af091738d1289acc0d1dda81480ee271f0a91e9f21b2e136b74fefb7.scope"
      }
    ],
    "ips": [
      "10.2.0.232"
    ],
    "name": "coredns-cc6ccd49c-f5hp5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56283a38_cb10_4643_bb43_9cf8542bed9d.slice/cri-containerd-03b55bc7d1d7a622d0142b4398fdbf228cdab4d3efb7aeef139a3381992edf45.scope"
      }
    ],
    "ips": [
      "10.2.0.30"
    ],
    "name": "coredns-cc6ccd49c-rnw89",
    "namespace": "kube-system"
  }
]

