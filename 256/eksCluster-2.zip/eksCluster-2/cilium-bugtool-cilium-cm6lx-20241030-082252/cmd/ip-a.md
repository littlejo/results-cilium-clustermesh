1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:26:20:33:3f:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.178.139/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3293sec preferred_lft 3293sec
    inet6 fe80::426:20ff:fe33:3fa3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c6:db:58:78:db brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.178.239/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4c6:dbff:fe58:78db/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:14:bc:47:6b:07 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::14:bcff:fe47:6b07/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:70:5d:81:6a:0e brd ff:ff:ff:ff:ff:ff
    inet 10.2.0.170/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::f470:5dff:fe81:6a0e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether c2:85:6e:ba:aa:08 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c085:6eff:feba:aa08/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:86:c6:f0:71:15 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::5086:c6ff:fef0:7115/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca783bdada4bf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:e3:93:8f:71:27 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::50e3:93ff:fe8f:7127/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3a59d99717e8@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:4b:86:9e:37:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9c4b:86ff:fe9e:37b9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf1c9f7ed4250@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:6d:d5:1d:c2:76 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8c6d:d5ff:fe1d:c276/64 scope link 
       valid_lft forever preferred_lft forever
