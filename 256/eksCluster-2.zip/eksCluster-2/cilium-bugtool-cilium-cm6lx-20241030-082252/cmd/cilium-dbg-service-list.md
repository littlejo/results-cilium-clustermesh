ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.141.97:443 (active)     
                                         2 => 172.31.249.66:443 (active)     
2    10.100.206.106:443   ClusterIP      1 => 172.31.178.139:4244 (active)   
3    10.100.0.10:9153     ClusterIP      1 => 10.2.0.30:9153 (active)        
                                         2 => 10.2.0.232:9153 (active)       
4    10.100.0.10:53       ClusterIP      1 => 10.2.0.30:53 (active)          
                                         2 => 10.2.0.232:53 (active)         
5    10.100.227.28:2379   ClusterIP      1 => 10.2.0.215:2379 (active)       
