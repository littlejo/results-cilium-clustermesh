 08:22:53 up 35 min,  0 users,  load average: 0.17, 0.13, 0.10
