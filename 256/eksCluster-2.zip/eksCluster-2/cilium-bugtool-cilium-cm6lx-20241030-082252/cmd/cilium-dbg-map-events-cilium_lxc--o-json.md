{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.170:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:48.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:53.097Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:53.101Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:53.149Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:53.150Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:53.157Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:57.999Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.000Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.000Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.032Z",
  "value": "id=2313  sec_id=101150 flags=0x0000 ifindex=16  mac=D6:4C:89:0B:69:45 nodemac=9E:1D:05:4A:F4:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.033Z",
  "value": "id=2313  sec_id=101150 flags=0x0000 ifindex=16  mac=D6:4C:89:0B:69:45 nodemac=9E:1D:05:4A:F4:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.999Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.999Z",
  "value": "id=2313  sec_id=101150 flags=0x0000 ifindex=16  mac=D6:4C:89:0B:69:45 nodemac=9E:1D:05:4A:F4:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:58.999Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:59.000Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.574Z",
  "value": "id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.2.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.023Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.824Z",
  "value": "id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.825Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.825Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.826Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.824Z",
  "value": "id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.826Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.827Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.827Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.823Z",
  "value": "id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.824Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.824Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.824Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.824Z",
  "value": "id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.824Z",
  "value": "id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.825Z",
  "value": "id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.2.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.825Z",
  "value": "id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27"
}

