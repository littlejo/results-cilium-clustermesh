IP ADDRESS         LOCAL ENDPOINT INFO
172.31.178.139:0   (localhost)                                                                                       
10.2.0.215:0       id=1850  sec_id=101150 flags=0x0000 ifindex=18  mac=A2:5E:D1:8B:53:26 nodemac=8E:6D:D5:1D:C2:76   
10.2.0.232:0       id=2302  sec_id=127806 flags=0x0000 ifindex=12  mac=16:24:1F:85:AE:D5 nodemac=52:E3:93:8F:71:27   
10.2.0.170:0       (localhost)                                                                                       
10.2.0.63:0        id=473   sec_id=4     flags=0x0000 ifindex=10  mac=12:40:32:87:6C:C5 nodemac=52:86:C6:F0:71:15    
10.2.0.30:0        id=840   sec_id=127806 flags=0x0000 ifindex=14  mac=F6:0C:A3:05:22:4E nodemac=9E:4B:86:9E:37:B9   
172.31.178.239:0   (localhost)                                                                                       
