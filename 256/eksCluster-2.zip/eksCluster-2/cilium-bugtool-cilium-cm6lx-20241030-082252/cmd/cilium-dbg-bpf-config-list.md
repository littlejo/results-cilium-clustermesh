KEY             VALUE
AgentLiveness   2149004525798
UTimeOffset     3379442296875000
