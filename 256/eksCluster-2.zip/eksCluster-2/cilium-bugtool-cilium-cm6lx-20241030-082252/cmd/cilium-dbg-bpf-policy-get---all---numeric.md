Endpoint ID: 205
Path: /sys/fs/bpf/tc/globals/cilium_policy_00205

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 473
Path: /sys/fs/bpf/tc/globals/cilium_policy_00473

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644346   20855     0        
Allow    Ingress     1          ANY          NONE         disabled    24742     291       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 840
Path: /sys/fs/bpf/tc/globals/cilium_policy_00840

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    162406   1871      0        
Allow    Egress      0          ANY          NONE         disabled    21272    239       0        


Endpoint ID: 1850
Path: /sys/fs/bpf/tc/globals/cilium_policy_01850

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11558910   116333    0        
Allow    Ingress     1          ANY          NONE         disabled    10610290   112015    0        
Allow    Egress      0          ANY          NONE         disabled    14471311   141319    0        


Endpoint ID: 2302
Path: /sys/fs/bpf/tc/globals/cilium_policy_02302

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    160367   1835      0        
Allow    Egress      0          ANY          NONE         disabled    20951    235       0        


