CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c5573fe_5d34_4348_b571_ae4223fab495.slice/cri-containerd-bb1ecd95af091738d1289acc0d1dda81480ee271f0a91e9f21b2e136b74fefb7.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6c5573fe_5d34_4348_b571_ae4223fab495.slice/cri-containerd-43803a260efe1a6fbcea5b374bad2c38e0122d944a98338e5a32ec0f8b6d8e19.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1049a43d_bede_4833_bbbb_9e7e79b49730.slice/cri-containerd-477a25996f5c953a1e76a5629158e237a7e72272f0eec9ad2f9b3038b789039d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1049a43d_bede_4833_bbbb_9e7e79b49730.slice/cri-containerd-7317228b2f0a89b4ed3ca59663d1fbb2fdf5457fb0ffe2ebdda919111cb4b16a.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec85d998_c7e3_450e_a430_be1b45a347f4.slice/cri-containerd-2e4ac829856baa2ad184f44d7cd4615f6a660bcc42f5d9ac9c09740f627a9499.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podec85d998_c7e3_450e_a430_be1b45a347f4.slice/cri-containerd-aa6f83eb7c44d5cd35c24bbe2581f36eb79480526719afcf149242a08d261a1b.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56283a38_cb10_4643_bb43_9cf8542bed9d.slice/cri-containerd-03b55bc7d1d7a622d0142b4398fdbf228cdab4d3efb7aeef139a3381992edf45.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod56283a38_cb10_4643_bb43_9cf8542bed9d.slice/cri-containerd-c2abddc7cb43b48070b92d3f5b7a7bb94f361b3a521488671796ec099991d74a.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41e8060a_d7a0_4112_b78a_14a22db97c86.slice/cri-containerd-040e3f1e7fe45a3284461b7c63aadfb71721c69c8999a71ba685326c999f7798.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod41e8060a_d7a0_4112_b78a_14a22db97c86.slice/cri-containerd-d5c1eae85f17dc684473afd9f5595796f7a3252328f8c1384f6f83338dfdba46.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd1bfe31_8ad2_4a6a_9996_c65c67e95914.slice/cri-containerd-4c6523b361f5a6736ce4ea3ff6eb72d21366ea73fad4a80e0773046a7f0833a0.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd1bfe31_8ad2_4a6a_9996_c65c67e95914.slice/cri-containerd-0c4c0ffde01cd48290e72c028dcf8e71ec2e8a95c2126250be0ef0c2a89ae036.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-5251790a42ab96d07b29faa79adde5c4e7799f575a60b3fb8ab14faad0ce01ba.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-066c4920cdd13018e1a6353c0c970d81ba83ef89a8ccd027a10f456b119071c7.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-76b09df0691ceab262e4a5c4cfff404ebb6ab1ac01e9d9cb07d3316b83d11dae.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod989b54d4_8833_45bc_99fe_9aa7c7727d93.slice/cri-containerd-3991778e7737956c5a3956b5bc914c8565545c286d7347033b80061b09ee1ae1.scope
    649      cgroup_device   multi                                          
