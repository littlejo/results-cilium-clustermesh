Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_srv6_policy_v6): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_srv6_policy_v6':  exit status 255

