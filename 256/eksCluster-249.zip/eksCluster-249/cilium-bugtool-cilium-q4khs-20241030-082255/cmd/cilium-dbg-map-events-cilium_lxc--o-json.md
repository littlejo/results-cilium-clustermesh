{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.726Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.204.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.726Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.223.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.726Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.383Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.400Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.416Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.417Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:49.449Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.994Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.995Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.996Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:50.026Z",
  "value": "id=282   sec_id=8214172 flags=0x0000 ifindex=16  mac=4A:9E:9D:DE:60:69 nodemac=F2:37:69:1A:FF:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:50.995Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:50.995Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:50.995Z",
  "value": "id=282   sec_id=8214172 flags=0x0000 ifindex=16  mac=4A:9E:9D:DE:60:69 nodemac=F2:37:69:1A:FF:52"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:50.995Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:48.653Z",
  "value": "id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.249.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:59.148Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.125Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.126Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.126Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.126Z",
  "value": "id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.122Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.123Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.123Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.123Z",
  "value": "id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.123Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.123Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.123Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.124Z",
  "value": "id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.123Z",
  "value": "id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.123Z",
  "value": "id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.124Z",
  "value": "id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.249.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.124Z",
  "value": "id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C"
}

