REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35591     2815395     677    bpf_overlay.c
Interface                 INGRESS     640505    131781771   1132   bpf_host.c
Success                   EGRESS      15383     1205576     1694   bpf_host.c
Success                   EGRESS      275131    34286549    1308   bpf_lxc.c
Success                   EGRESS      35152     2780317     53     encap.h
Success                   INGRESS     314892    35585929    86     l3.h
Success                   INGRESS     335751    37239794    235    trace.h
Unsupported L3 protocol   EGRESS      42        3152        1492   bpf_lxc.c
