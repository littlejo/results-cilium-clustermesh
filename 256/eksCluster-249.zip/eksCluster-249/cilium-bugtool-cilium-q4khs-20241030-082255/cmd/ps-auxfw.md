USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         631  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         618  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         617  0.0  0.1 1240432 15928 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         662  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         663  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c hostname
root           1  4.1  4.7 1606080 383068 ?      Ssl  08:03   0:48 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1229744 8204 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
