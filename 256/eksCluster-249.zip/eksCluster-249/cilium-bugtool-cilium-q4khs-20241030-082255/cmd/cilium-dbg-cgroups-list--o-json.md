[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod651c7527_edd2_407e_8f6b_7801d11cecf1.slice/cri-containerd-ce727f573b3328ccad94a60670a4b936302948f3bab9b8a66575045ef63129a2.scope"
      }
    ],
    "ips": [
      "10.249.0.119"
    ],
    "name": "coredns-cc6ccd49c-ztrx4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a18831_d2eb_43b4_8bf3_25d7b5407153.slice/cri-containerd-af242c6a4fdd167f30a7f5fb1ce8320191dee3b38f958aef28fa3c6ec5095bbf.scope"
      }
    ],
    "ips": [
      "10.249.0.236"
    ],
    "name": "coredns-cc6ccd49c-8vntw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-4c2c87fffdb712d3868672b07666ea619ab44520237e6b56c5362f1752273759.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-99835a67d9a5ba00542ac4ae1b20745a56c548d18eecc748bd0fbd0d0afdcb4d.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-37e53606fec94144f7a56ea88bdc4c8d348b26b60d0f27b92df95a66f26f19e9.scope"
      }
    ],
    "ips": [
      "10.249.0.164"
    ],
    "name": "clustermesh-apiserver-64564d9bbf-2tj72",
    "namespace": "kube-system"
  }
]

