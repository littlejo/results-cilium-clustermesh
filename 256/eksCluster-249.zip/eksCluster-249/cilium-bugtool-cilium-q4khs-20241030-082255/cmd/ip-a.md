1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ac:ea:1d:1b:93 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.223.254/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1933sec preferred_lft 1933sec
    inet6 fe80::8ac:eaff:fe1d:1b93/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ea:e1:43:81:b3 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.204.254/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ea:e1ff:fe43:81b3/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:f2:13:cb:fd:2a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30f2:13ff:fecb:fd2a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:43:04:e9:18:c1 brd ff:ff:ff:ff:ff:ff
    inet 10.249.0.57/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5843:4ff:fee9:18c1/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:78:fc:75:98:bd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::78:fcff:fe75:98bd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:6b:dd:d3:b1:be brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::7c6b:ddff:fed3:b1be/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc66166227e99e@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:1c:f9:cd:fe:18 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::601c:f9ff:fecd:fe18/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc9b60bb9504a6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:a4:ee:90:b7:5c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b8a4:eeff:fe90:b75c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3f2c8fac437f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:f9:96:cc:f0:c5 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64f9:96ff:fecc:f0c5/64 scope link 
       valid_lft forever preferred_lft forever
