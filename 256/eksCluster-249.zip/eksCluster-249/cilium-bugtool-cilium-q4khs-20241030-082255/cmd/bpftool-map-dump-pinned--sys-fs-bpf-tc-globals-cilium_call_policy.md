key: 52 00 00 00  value: 15 02 00 00
key: dc 00 00 00  value: 68 02 00 00
key: a5 04 00 00  value: 1c 02 00 00
key: 1d 0f 00 00  value: 27 02 00 00
Found 4 elements
