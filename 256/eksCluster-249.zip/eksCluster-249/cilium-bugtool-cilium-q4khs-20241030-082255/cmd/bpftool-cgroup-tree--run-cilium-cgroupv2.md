CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod651c7527_edd2_407e_8f6b_7801d11cecf1.slice/cri-containerd-ce727f573b3328ccad94a60670a4b936302948f3bab9b8a66575045ef63129a2.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod651c7527_edd2_407e_8f6b_7801d11cecf1.slice/cri-containerd-e72430bed566759097bec264e6a00591d3d79027d938e8dd8b7134cf3958c6d6.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a18831_d2eb_43b4_8bf3_25d7b5407153.slice/cri-containerd-bcb867cd289d5e486156b4e089471de3c7977a3cc2b7d0fd5685f05a79180fe8.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a18831_d2eb_43b4_8bf3_25d7b5407153.slice/cri-containerd-af242c6a4fdd167f30a7f5fb1ce8320191dee3b38f958aef28fa3c6ec5095bbf.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5266584_87e5_4b71_b063_94959f513bb6.slice/cri-containerd-18a043fd090d81dbc20a3db186c5902568f1fd47d458f264486e98ae1a9cdb35.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5266584_87e5_4b71_b063_94959f513bb6.slice/cri-containerd-f72f23a6f6824a4517dbe9a767a7d0539fea4e2741fa26d0c1cb108950707e16.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc12b4cf7_409a_4f7c_8a05_94014118fd0e.slice/cri-containerd-406a8994b8431eb4c7a5b63a0945660b19b49e6860ecce87be037b686890b785.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc12b4cf7_409a_4f7c_8a05_94014118fd0e.slice/cri-containerd-d188bd2b1d7c6ca915297c0141f59b4fb78ac3236d04537f4a5d946db40a059d.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ba4e6db_51f4_4034_930e_368b8c1f05a7.slice/cri-containerd-5e1a58baf9825e18ca5e3c3ec5ad20a5570d4b3a3b126e5a8dea00fa01d1c439.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ba4e6db_51f4_4034_930e_368b8c1f05a7.slice/cri-containerd-37fe1199abcbc250b2be93e52e1e8fc4ba833e356c7f077150ae8d597d6623b4.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-4c2c87fffdb712d3868672b07666ea619ab44520237e6b56c5362f1752273759.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-99835a67d9a5ba00542ac4ae1b20745a56c548d18eecc748bd0fbd0d0afdcb4d.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-d554efa6a097bbc9a201a94ab7ec895bd33f29c31e81afcbdde0d57c37ab37bb.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4e1d5614_9609_4354_a153_192443122649.slice/cri-containerd-37e53606fec94144f7a56ea88bdc4c8d348b26b60d0f27b92df95a66f26f19e9.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod300e6417_7dc3_403a_a787_3d51b71cc0be.slice/cri-containerd-9c0ac3d5de369dfd6abdd434ef50807764a180e51bf7ddd2c4e0b463996a96f0.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod300e6417_7dc3_403a_a787_3d51b71cc0be.slice/cri-containerd-8d2a1cd5d708930f32a3cc63643e73fc2b4be3a23620fd154387c7f6d500f932.scope
    102      cgroup_device   multi                                          
