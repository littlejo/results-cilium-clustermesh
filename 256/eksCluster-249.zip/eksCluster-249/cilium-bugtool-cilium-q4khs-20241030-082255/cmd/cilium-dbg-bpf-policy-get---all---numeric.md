Endpoint ID: 82
Path: /sys/fs/bpf/tc/globals/cilium_policy_00082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112180   1285      0        
Allow    Egress      0          ANY          NONE         disabled    15274    163       0        


Endpoint ID: 220
Path: /sys/fs/bpf/tc/globals/cilium_policy_00220

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11609214   115865    0        
Allow    Ingress     1          ANY          NONE         disabled    9981498    105082    0        
Allow    Egress      0          ANY          NONE         disabled    13221388   130046    0        


Endpoint ID: 1189
Path: /sys/fs/bpf/tc/globals/cilium_policy_01189

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111718   1278      0        
Allow    Egress      0          ANY          NONE         disabled    16874    182       0        


Endpoint ID: 1648
Path: /sys/fs/bpf/tc/globals/cilium_policy_01648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3869
Path: /sys/fs/bpf/tc/globals/cilium_policy_03869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659003   20921     0        
Allow    Ingress     1          ANY          NONE         disabled    16488     191       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


