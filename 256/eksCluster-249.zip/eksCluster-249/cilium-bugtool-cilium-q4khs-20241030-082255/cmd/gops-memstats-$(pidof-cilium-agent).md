alloc: 136.73MB (143370856 bytes)
total-alloc: 2.22GB (2388531920 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63184930
frees: 62101461
heap-alloc: 136.73MB (143370856 bytes)
heap-sys: 247.57MB (259596288 bytes)
heap-idle: 64.02MB (67125248 bytes)
heap-in-use: 183.55MB (192471040 bytes)
heap-released: 3.50MB (3670016 bytes)
heap-objects: 1083469
stack-in-use: 64.41MB (67534848 bytes)
stack-sys: 64.41MB (67534848 bytes)
stack-mspan-inuse: 2.85MB (2993120 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 952.97KB (975841 bytes)
gc-sys: 6.02MB (6307352 bytes)
next-gc: when heap-alloc >= 216.30MB (226809528 bytes)
last-gc: 2024-10-30 08:23:10.923989047 +0000 UTC
gc-pause-total: 18.457439ms
gc-pause: 71722
gc-pause-end: 1730276590923989047
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005257635604239404
enable-gc: true
debug-gc: false
