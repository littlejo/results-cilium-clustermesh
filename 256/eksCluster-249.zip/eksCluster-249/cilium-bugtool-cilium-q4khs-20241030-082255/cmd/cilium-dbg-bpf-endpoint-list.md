IP ADDRESS         LOCAL ENDPOINT INFO
10.249.0.232:0     id=3869  sec_id=4     flags=0x0000 ifindex=10  mac=9A:9B:A2:E2:CD:80 nodemac=7E:6B:DD:D3:B1:BE     
10.249.0.236:0     id=82    sec_id=8212345 flags=0x0000 ifindex=14  mac=62:3E:DC:7E:8D:24 nodemac=BA:A4:EE:90:B7:5C   
10.249.0.164:0     id=220   sec_id=8214172 flags=0x0000 ifindex=18  mac=0E:96:3D:94:C3:5F nodemac=66:F9:96:CC:F0:C5   
172.31.223.254:0   (localhost)                                                                                        
172.31.204.254:0   (localhost)                                                                                        
10.249.0.57:0      (localhost)                                                                                        
10.249.0.119:0     id=1189  sec_id=8212345 flags=0x0000 ifindex=12  mac=2E:18:0F:62:A6:90 nodemac=62:1C:F9:CD:FE:18   
