1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:47:22:4c:76:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.198.209/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3391sec preferred_lft 3391sec
    inet6 fe80::847:22ff:fe4c:7657/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6c:70:01:63:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.201.156/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::86c:70ff:fe01:632f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:e3:4c:32:98:db brd ff:ff:ff:ff:ff:ff
    inet6 fe80::70e3:4cff:fe32:98db/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:1b:b5:77:7e:c0 brd ff:ff:ff:ff:ff:ff
    inet 10.133.0.45/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::101b:b5ff:fe77:7ec0/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:07:83:b8:1a:b7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9407:83ff:feb8:1ab7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:2a:04:f0:bc:33 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8c2a:4ff:fef0:bc33/64 scope link 
       valid_lft forever preferred_lft forever
12: lxce826ed1344cb@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:1b:b3:e3:bc:98 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7c1b:b3ff:fee3:bc98/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce8947c778a48@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:a9:73:7e:88:77 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::34a9:73ff:fe7e:8877/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc284d522f7c33@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:ab:93:31:1e:77 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::40ab:93ff:fe31:1e77/64 scope link 
       valid_lft forever preferred_lft forever
