ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.236.251:443 (active)    
                                          2 => 172.31.174.19:443 (active)     
2    10.100.99.157:443     ClusterIP      1 => 172.31.198.209:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.133.0.71:53 (active)        
                                          2 => 10.133.0.241:53 (active)       
4    10.100.0.10:9153      ClusterIP      1 => 10.133.0.71:9153 (active)      
                                          2 => 10.133.0.241:9153 (active)     
5    10.100.107.154:2379   ClusterIP      1 => 10.133.0.9:2379 (active)       
