{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.45:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.514Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.198.209:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.514Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.201.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:32.515Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.448Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.448Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.487Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:37.509Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:25.589Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:25.589Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:25.590Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:25.621Z",
  "value": "id=1894  sec_id=4402789 flags=0x0000 ifindex=16  mac=A6:AA:45:70:A2:4F nodemac=82:0E:6B:C4:B7:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.589Z",
  "value": "id=1894  sec_id=4402789 flags=0x0000 ifindex=16  mac=A6:AA:45:70:A2:4F nodemac=82:0E:6B:C4:B7:F4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.589Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.589Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:26.590Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.258Z",
  "value": "id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.133.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.669Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.370Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.371Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.371Z",
  "value": "id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.374Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.349Z",
  "value": "id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.351Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.351Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.352Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.346Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.347Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.347Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.347Z",
  "value": "id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.347Z",
  "value": "id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.347Z",
  "value": "id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.347Z",
  "value": "id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.133.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.348Z",
  "value": "id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33"
}

