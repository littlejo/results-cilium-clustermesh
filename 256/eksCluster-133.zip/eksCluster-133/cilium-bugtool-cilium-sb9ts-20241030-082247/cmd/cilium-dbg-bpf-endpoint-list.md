IP ADDRESS         LOCAL ENDPOINT INFO
172.31.201.156:0   (localhost)                                                                                        
10.133.0.45:0      (localhost)                                                                                        
10.133.0.241:0     id=791   sec_id=4406318 flags=0x0000 ifindex=14  mac=F2:8D:EA:5E:73:B0 nodemac=36:A9:73:7E:88:77   
10.133.0.71:0      id=146   sec_id=4406318 flags=0x0000 ifindex=12  mac=9A:72:9B:CB:D7:7C nodemac=7E:1B:B3:E3:BC:98   
172.31.198.209:0   (localhost)                                                                                        
10.133.0.9:0       id=175   sec_id=4402789 flags=0x0000 ifindex=18  mac=C6:5C:C5:06:1D:9E nodemac=42:AB:93:31:1E:77   
10.133.0.84:0      id=4009  sec_id=4     flags=0x0000 ifindex=10  mac=DA:5B:A5:35:7C:28 nodemac=8E:2A:04:F0:BC:33     
