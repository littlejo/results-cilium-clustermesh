CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2136562e_0fec_4e99_90d3_eb4cbe5a60bc.slice/cri-containerd-a0b013b321494b78c98c810284ada99a9d365f152886e85d61111d8ab9c82bcd.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2136562e_0fec_4e99_90d3_eb4cbe5a60bc.slice/cri-containerd-e2fb460b8ea86016ebb24356572d2c8f2591058b6ba08573f5219fff7548d1c9.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1303748_b72f_4e9c_b6cc_111f25abeb5e.slice/cri-containerd-30250c3b4d7b22d3fc545c7d36ce63bce037f530ef1b8b3aa988ee9ad77dc343.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1303748_b72f_4e9c_b6cc_111f25abeb5e.slice/cri-containerd-44c7961d57c632e3607cbaeb7ddc72301037a6236228f8977a664062ca0ff804.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1e9d26f_daca_4662_bc49_2fe80c274085.slice/cri-containerd-1f318037fffa5cf79e137514d7017216fdc3021098e2165d4126cb4ff9b14049.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1e9d26f_daca_4662_bc49_2fe80c274085.slice/cri-containerd-ac2999111a943843ce77c22d5b3566d77ba40ad929522c1b2657826aa5b49e1b.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7192d5a1_f223_4078_8009_8f365ecc9474.slice/cri-containerd-c4ee38f25bf00ac5af980da337dcd489c4b119b971e42a077536c93f51c49a5f.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7192d5a1_f223_4078_8009_8f365ecc9474.slice/cri-containerd-695bf447d34e35702286f7e98840780aceb8ebe4b07892a1931eb97fef2e1577.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-5cef25ae9d935f9638dbb95852a29b96fde13292e8b20233c23683b18cb96c44.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-e5ae85d6e37b7db50546926cc572274356382091dfd966e9b266f98c41eb8396.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-a750b73443ac423b3f12897256c6b76948c6a541d9bb950cae58fba7694c3320.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-505487f673693e94c5cf8adc147fc8d2ea1f05746091132a69db68b32dd14f6d.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17272725_039d_4f81_a487_fda856ff44b3.slice/cri-containerd-ff6a1091ddcaad1c8bde45ab1106e65bfd95601b38cff06fa557395624c974c3.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17272725_039d_4f81_a487_fda856ff44b3.slice/cri-containerd-85d719e135d8850e7be5b0e0a7cd6712ceec2f1d58b210a392ef23e3338fa3d4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod018498e1_6427_4539_9e0a_146b53f5f1d4.slice/cri-containerd-f1f73b324d880ac312d79263866f0cdf54619d2a0d7b0af5a00e5d0844db736e.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod018498e1_6427_4539_9e0a_146b53f5f1d4.slice/cri-containerd-2daf120eac083abcfc6bcb4dbbb5dd6719d567358cd0dbf1761e782f5c509010.scope
    91       cgroup_device   multi                                          
