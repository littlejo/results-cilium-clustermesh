alloc: 109.76MB (115087680 bytes)
total-alloc: 2.25GB (2419075616 bytes)
sys: 324.89MB (340676964 bytes)
lookups: 0
mallocs: 63491775
frees: 62770887
heap-alloc: 109.76MB (115087680 bytes)
heap-sys: 251.98MB (264216576 bytes)
heap-idle: 83.86MB (87932928 bytes)
heap-in-use: 168.12MB (176283648 bytes)
heap-released: 2.47MB (2588672 bytes)
heap-objects: 720888
stack-in-use: 60.00MB (62914560 bytes)
stack-sys: 60.00MB (62914560 bytes)
stack-mspan-inuse: 2.74MB (2868480 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1077337 bytes)
gc-sys: 6.10MB (6395272 bytes)
next-gc: when heap-alloc >= 232.11MB (243388424 bytes)
last-gc: 2024-10-30 08:23:19.044324825 +0000 UTC
gc-pause-total: 24.042542ms
gc-pause: 168184
gc-pause-end: 1730276599044324825
num-gc: 84
num-forced-gc: 0
gc-cpu-fraction: 0.0004591484049155998
enable-gc: true
debug-gc: false
