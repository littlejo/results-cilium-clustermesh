key: 92 00 00 00  value: 03 02 00 00
key: af 00 00 00  value: 6a 02 00 00
key: 17 03 00 00  value: 24 02 00 00
key: a9 0f 00 00  value: 18 02 00 00
Found 4 elements
