[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2136562e_0fec_4e99_90d3_eb4cbe5a60bc.slice/cri-containerd-a0b013b321494b78c98c810284ada99a9d365f152886e85d61111d8ab9c82bcd.scope"
      }
    ],
    "ips": [
      "10.133.0.71"
    ],
    "name": "coredns-cc6ccd49c-bsg4v",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-a750b73443ac423b3f12897256c6b76948c6a541d9bb950cae58fba7694c3320.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-505487f673693e94c5cf8adc147fc8d2ea1f05746091132a69db68b32dd14f6d.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcb66e3ec_6ed8_4c60_87c7_2f5d4b4798a4.slice/cri-containerd-e5ae85d6e37b7db50546926cc572274356382091dfd966e9b266f98c41eb8396.scope"
      }
    ],
    "ips": [
      "10.133.0.9"
    ],
    "name": "clustermesh-apiserver-67576874ff-sdgll",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7192d5a1_f223_4078_8009_8f365ecc9474.slice/cri-containerd-c4ee38f25bf00ac5af980da337dcd489c4b119b971e42a077536c93f51c49a5f.scope"
      }
    ],
    "ips": [
      "10.133.0.241"
    ],
    "name": "coredns-cc6ccd49c-8nhjb",
    "namespace": "kube-system"
  }
]

