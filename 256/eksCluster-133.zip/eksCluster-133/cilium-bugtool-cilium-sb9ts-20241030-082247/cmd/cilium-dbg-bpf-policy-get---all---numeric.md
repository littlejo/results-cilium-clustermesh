Endpoint ID: 146
Path: /sys/fs/bpf/tc/globals/cilium_policy_00146

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147667   1698      0        
Allow    Egress      0          ANY          NONE         disabled    18664    206       0        


Endpoint ID: 175
Path: /sys/fs/bpf/tc/globals/cilium_policy_00175

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11510988   114799    0        
Allow    Ingress     1          ANY          NONE         disabled    9812700    103205    0        
Allow    Egress      0          ANY          NONE         disabled    13067173   128146    0        


Endpoint ID: 290
Path: /sys/fs/bpf/tc/globals/cilium_policy_00290

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 791
Path: /sys/fs/bpf/tc/globals/cilium_policy_00791

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    148696   1709      0        
Allow    Egress      0          ANY          NONE         disabled    18578    205       0        


Endpoint ID: 4009
Path: /sys/fs/bpf/tc/globals/cilium_policy_04009

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642654   20780     0        
Allow    Ingress     1          ANY          NONE         disabled    21990     257       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


