REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35394     2796032     677    bpf_overlay.c
Interface                 INGRESS     637857    132086698   1132   bpf_host.c
Success                   EGRESS      15306     1200742     1694   bpf_host.c
Success                   EGRESS      270924    33815171    1308   bpf_lxc.c
Success                   EGRESS      35074     2772409     53     encap.h
Success                   INGRESS     312845    35389617    86     l3.h
Success                   INGRESS     333584    37028953    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
