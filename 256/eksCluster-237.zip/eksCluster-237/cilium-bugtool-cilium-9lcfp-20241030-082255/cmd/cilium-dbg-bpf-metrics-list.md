REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36192     2861650     677    bpf_overlay.c
Interface                 INGRESS     641423    131683359   1132   bpf_host.c
Success                   EGRESS      15963     1250525     1694   bpf_host.c
Success                   EGRESS      272483    33961362    1308   bpf_lxc.c
Success                   EGRESS      35996     2845149     53     encap.h
Success                   INGRESS     313618    35517915    86     l3.h
Success                   INGRESS     334498    37173086    235    trace.h
Unsupported L3 protocol   EGRESS      37        2742        1492   bpf_lxc.c
