CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaba71fa5_791e_4ab1_aead_e2befce5e0b2.slice/cri-containerd-d33ef4e695ecc894dd4a83f4f42a28fa9dd68004e32ec5a75f66191ce5527dd5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaba71fa5_791e_4ab1_aead_e2befce5e0b2.slice/cri-containerd-90d54436a822d788ee428b114f734018e8d2ddad56f778ea77b856a1252af248.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5a3a20_fb8a_4463_b55c_21b41e256657.slice/cri-containerd-8bade71e96499954a7bcd7a7d8d8cf79e99848789fbf38914112996d732e7347.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5a3a20_fb8a_4463_b55c_21b41e256657.slice/cri-containerd-280a1650a50aa6ae27c60c6fff6d9f8a4aa8387fd4e00a18654f943830d9b971.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa12e0da_1a00_4e84_94d6_f2818a2ca739.slice/cri-containerd-3ffa97d85d7db4433991e15c64105614ea60f2a9c9a39952280052f312d11a9c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa12e0da_1a00_4e84_94d6_f2818a2ca739.slice/cri-containerd-ee929c8eeb918bac569f4a0b72a04314fc05849b2e8530c2c3b8ff0ff3517c4d.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7056a173_7174_4672_b37b_aee66be946d7.slice/cri-containerd-47a1cf81558cf7f0cb0bf84843ac69ff02b2808782f3962e23bcb41129cd706e.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7056a173_7174_4672_b37b_aee66be946d7.slice/cri-containerd-5d84cf67e20e5cee0123ee2bf4020fdb8a86614c6e915d806041702048102258.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e1d3aba_78bf_41e0_8cee_72013cbed49c.slice/cri-containerd-4cfb9fa1efbbc0bae835e54ebbe9710834bd5f3b5982c2e1335b2b8317a15b04.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3e1d3aba_78bf_41e0_8cee_72013cbed49c.slice/cri-containerd-55a3225230fbdc7214bb675b71f84a24310bfef42aca1b9f0e390c3864b0e2a7.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5db6039a_1cfa_4aca_9662_dc661ab7da17.slice/cri-containerd-3c9643e01ae9e49a53f6cdfa71f0591ed1da5881537decea4d9f12ccb00409d1.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5db6039a_1cfa_4aca_9662_dc661ab7da17.slice/cri-containerd-dded8dc5a66fc516314eda8fe3253105bd319f4ee0d06fb08d9e3004e03ac066.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-4fc848201e46f13c263966c9931a4e79bee448e5ac694ba8ae85b80e19cc3c78.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-31844ccd7da496e68b9c3153015322df08182a5aa57c88a34fa75372e669a077.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-5a1c821aa11bb8c15408a23925f5452ba4715217599deed9e713977598a7ce0d.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-9dc621b85e7703a79fa1387994505d0c908d6e4ad3569589eaaf8d1d7bd4e2fa.scope
    650      cgroup_device   multi                                          
