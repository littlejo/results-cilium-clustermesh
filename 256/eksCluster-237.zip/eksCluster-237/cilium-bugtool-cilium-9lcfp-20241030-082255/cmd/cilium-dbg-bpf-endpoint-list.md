IP ADDRESS         LOCAL ENDPOINT INFO
172.31.246.95:0    (localhost)                                                                                        
10.237.0.119:0     id=833   sec_id=7819346 flags=0x0000 ifindex=14  mac=86:BB:76:C9:76:35 nodemac=EE:F5:10:98:89:75   
10.237.0.240:0     (localhost)                                                                                        
10.237.0.151:0     id=2858  sec_id=4     flags=0x0000 ifindex=10  mac=EA:56:31:FD:2F:01 nodemac=06:9E:5F:72:63:C3     
10.237.0.176:0     id=871   sec_id=7819346 flags=0x0000 ifindex=12  mac=CA:AE:7D:CF:38:FC nodemac=46:D5:93:7C:2B:23   
10.237.0.241:0     id=414   sec_id=7806505 flags=0x0000 ifindex=18  mac=7E:56:53:EA:A9:7A nodemac=A6:25:38:6D:A0:75   
172.31.226.233:0   (localhost)                                                                                        
