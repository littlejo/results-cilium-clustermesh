alloc: 168.70MB (176895448 bytes)
total-alloc: 2.23GB (2393245768 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63226385
frees: 61520248
heap-alloc: 168.70MB (176895448 bytes)
heap-sys: 247.63MB (259661824 bytes)
heap-idle: 51.35MB (53846016 bytes)
heap-in-use: 196.28MB (205815808 bytes)
heap-released: 3.87MB (4055040 bytes)
heap-objects: 1706137
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 3.08MB (3227840 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 961.05KB (984113 bytes)
gc-sys: 6.05MB (6340288 bytes)
next-gc: when heap-alloc >= 212.58MB (222908824 bytes)
last-gc: 2024-10-30 08:23:01.780126366 +0000 UTC
gc-pause-total: 11.652343ms
gc-pause: 92031
gc-pause-end: 1730276581780126366
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005011401631682402
enable-gc: true
debug-gc: false
