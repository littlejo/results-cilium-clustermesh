key: 9e 01 00 00  value: 71 02 00 00
key: 41 03 00 00  value: 20 02 00 00
key: 67 03 00 00  value: 10 02 00 00
key: 2a 0b 00 00  value: fb 01 00 00
Found 4 elements
