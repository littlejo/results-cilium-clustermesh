Endpoint ID: 414
Path: /sys/fs/bpf/tc/globals/cilium_policy_00414

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11601254   115830    0        
Allow    Ingress     1          ANY          NONE         disabled    9954006    104438    0        
Allow    Egress      0          ANY          NONE         disabled    13233782   130243    0        


Endpoint ID: 833
Path: /sys/fs/bpf/tc/globals/cilium_policy_00833

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115360   1326      0        
Allow    Egress      0          ANY          NONE         disabled    15163    162       0        


Endpoint ID: 871
Path: /sys/fs/bpf/tc/globals/cilium_policy_00871

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113644   1300      0        
Allow    Egress      0          ANY          NONE         disabled    16255    174       0        


Endpoint ID: 2160
Path: /sys/fs/bpf/tc/globals/cilium_policy_02160

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2858
Path: /sys/fs/bpf/tc/globals/cilium_policy_02858

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660449   20944     0        
Allow    Ingress     1          ANY          NONE         disabled    18170     213       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


