[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-5a1c821aa11bb8c15408a23925f5452ba4715217599deed9e713977598a7ce0d.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-9dc621b85e7703a79fa1387994505d0c908d6e4ad3569589eaaf8d1d7bd4e2fa.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6a679829_802a_4914_b3fe_afef1a68d7af.slice/cri-containerd-4fc848201e46f13c263966c9931a4e79bee448e5ac694ba8ae85b80e19cc3c78.scope"
      }
    ],
    "ips": [
      "10.237.0.241"
    ],
    "name": "clustermesh-apiserver-5bd4466c55-kpb7c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5f5a3a20_fb8a_4463_b55c_21b41e256657.slice/cri-containerd-280a1650a50aa6ae27c60c6fff6d9f8a4aa8387fd4e00a18654f943830d9b971.scope"
      }
    ],
    "ips": [
      "10.237.0.119"
    ],
    "name": "coredns-cc6ccd49c-7xnmw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa12e0da_1a00_4e84_94d6_f2818a2ca739.slice/cri-containerd-3ffa97d85d7db4433991e15c64105614ea60f2a9c9a39952280052f312d11a9c.scope"
      }
    ],
    "ips": [
      "10.237.0.176"
    ],
    "name": "coredns-cc6ccd49c-vd2m2",
    "namespace": "kube-system"
  }
]

