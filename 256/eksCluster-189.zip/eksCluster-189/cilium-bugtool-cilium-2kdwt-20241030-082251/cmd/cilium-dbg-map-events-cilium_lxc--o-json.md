{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.72:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.588Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.194.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.588Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.232.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.588Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.565Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.572Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.621Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.622Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.628Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.341Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.342Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.342Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.372Z",
  "value": "id=374   sec_id=6239718 flags=0x0000 ifindex=16  mac=86:D1:79:1F:E5:43 nodemac=92:F4:16:BF:34:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:52.373Z",
  "value": "id=374   sec_id=6239718 flags=0x0000 ifindex=16  mac=86:D1:79:1F:E5:43 nodemac=92:F4:16:BF:34:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.014Z",
  "value": "id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.189.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.532Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.676Z",
  "value": "id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.678Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.678Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.678Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.677Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.677Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.677Z",
  "value": "id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:59.679Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.676Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.677Z",
  "value": "id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.677Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:00.677Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.677Z",
  "value": "id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.678Z",
  "value": "id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.678Z",
  "value": "id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.189.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.678Z",
  "value": "id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A"
}

