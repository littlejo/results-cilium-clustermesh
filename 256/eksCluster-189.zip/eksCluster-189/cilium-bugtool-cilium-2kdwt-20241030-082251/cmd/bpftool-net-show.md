xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 504
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 484
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 533
lxc22da8e4b7e6f(12) clsact/ingress cil_from_container-lxc22da8e4b7e6f id 530
lxc052ec9141d56(14) clsact/ingress cil_from_container-lxc052ec9141d56 id 549
lxcdc1adb2f4487(18) clsact/ingress cil_from_container-lxcdc1adb2f4487 id 609

flow_dissector:

netfilter:

