Endpoint ID: 295
Path: /sys/fs/bpf/tc/globals/cilium_policy_00295

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1067
Path: /sys/fs/bpf/tc/globals/cilium_policy_01067

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115059   1325      0        
Allow    Egress      0          ANY          NONE         disabled    16006    170       0        


Endpoint ID: 1692
Path: /sys/fs/bpf/tc/globals/cilium_policy_01692

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645692   20798     0        
Allow    Ingress     1          ANY          NONE         disabled    18328     216       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1993
Path: /sys/fs/bpf/tc/globals/cilium_policy_01993

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114634   1315      0        
Allow    Egress      0          ANY          NONE         disabled    15987    172       0        


Endpoint ID: 2530
Path: /sys/fs/bpf/tc/globals/cilium_policy_02530

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11435444   112864    0        
Allow    Ingress     1          ANY          NONE         disabled    9902696    104154    0        
Allow    Egress      0          ANY          NONE         disabled    11908455   117873    0        


