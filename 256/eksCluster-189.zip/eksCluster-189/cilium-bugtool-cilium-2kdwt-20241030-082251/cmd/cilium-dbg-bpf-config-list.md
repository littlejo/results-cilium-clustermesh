KEY             VALUE
AgentLiveness   1826147077223
UTimeOffset     3379442925781250
