USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         673  0.0  0.1 1616264 8748 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         659  0.0  0.2 1240432 16348 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         679  0.0  0.2 1240432 16348 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         680  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         649  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         624  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         623  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         622  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root           1  4.5  4.8 1606080 390672 ?      Ssl  08:03   0:54 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.1  0.1 1229744 8256 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
