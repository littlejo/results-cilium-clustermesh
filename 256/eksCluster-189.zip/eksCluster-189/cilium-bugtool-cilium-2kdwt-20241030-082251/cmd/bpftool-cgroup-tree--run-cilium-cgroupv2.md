CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd833951b_40f3_4687_8ba5_5a30e17ea028.slice/cri-containerd-68e80d76f91564003e6bccb3fe4c411d3a61e59de9a92d8c5aac528dbee4a3cc.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd833951b_40f3_4687_8ba5_5a30e17ea028.slice/cri-containerd-604380609030070412d66a0ec3f8df378f55f02459cc0dae72de930675bcc64e.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1bc7811d_08be_4d43_8073_21e0c6b9fffb.slice/cri-containerd-a515331d6d8d0eb85331fc1ce706324ec81aeacf8c6690d9109bc74c319dd52c.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1bc7811d_08be_4d43_8073_21e0c6b9fffb.slice/cri-containerd-e130988fede6c2647a12b076158d194942f0bbfd2e4b340b8c3f05377edc4821.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff60c5b8_886c_4b2b_9b68_49d6d1945dd5.slice/cri-containerd-636e938e9c4ea71f75ef6d75da760765260bbfc5dc6c50ad1bba434a18139e44.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff60c5b8_886c_4b2b_9b68_49d6d1945dd5.slice/cri-containerd-c1e93aa4ed72e1e3d3ad3105e307a77ba1ec3f9597baaf7f0de202bd4526d637.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9574efa8_c57c_402d_b41e_6ce8c8a26517.slice/cri-containerd-ee0f18c82d63ae919551c4b0b97033649f4ab17710f3e667c9ab1eae9664b039.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9574efa8_c57c_402d_b41e_6ce8c8a26517.slice/cri-containerd-453378cd926109a1d0116faf5eb6af5b23a54c15ff36286195bd952d1e8cc082.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-0faadd52d8a089190520c76602bb2eac92dca4384b5a2d63fc4b0fd2a126b8b4.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-24aa765d8b11d0c4cfc4e8a8720606eb57b1aed8757b8c06725fde3c67d00d5b.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-2408a613cd9772339f81b9df440790c73d0d156eb3efb8e303aa8f14f7118efe.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-1b39c1f56cad430c6c4c7cb1d7d185b99b2242fed8617dbf090ba2b471442ef4.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff7798d2_a773_4858_85cd_c8ce8c35e61b.slice/cri-containerd-8ac197940263c2f985b874968bfec28987e8ea62ac8548525a6c23acb5d7dfef.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podff7798d2_a773_4858_85cd_c8ce8c35e61b.slice/cri-containerd-34872b7aa0de17976920ff1da4c10224c262bd2def65155935e5d1192c06a694.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ab0d960_c7b3_4095_80f3_40f45791245d.slice/cri-containerd-78ef46de9520a9f56127f2ec7b2b296b983f53878f03a21c6801b5c2e25bc925.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5ab0d960_c7b3_4095_80f3_40f45791245d.slice/cri-containerd-56b78bd1526ebef9f4c6c732cebf5a16d240fa969ade9e0f65f028e806aed3ac.scope
    103      cgroup_device   multi                                          
