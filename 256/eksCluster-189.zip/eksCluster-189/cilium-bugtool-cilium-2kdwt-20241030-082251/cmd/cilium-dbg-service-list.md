ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.182.94:443 (active)     
                                         2 => 172.31.224.11:443 (active)     
2    10.100.200.154:443   ClusterIP      1 => 172.31.194.190:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.189.0.16:53 (active)        
                                         2 => 10.189.0.188:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.189.0.16:9153 (active)      
                                         2 => 10.189.0.188:9153 (active)     
5    10.100.26.154:2379   ClusterIP      1 => 10.189.0.207:2379 (active)     
