1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:cd:6a:43:4e:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.194.190/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1816sec preferred_lft 1816sec
    inet6 fe80::8cd:6aff:fe43:4ecd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:df:03:15:0f:0d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.232.206/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8df:3ff:fe15:f0d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:a7:56:c0:dd:e3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::40a7:56ff:fec0:dde3/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:a8:79:53:25:a8 brd ff:ff:ff:ff:ff:ff
    inet 10.189.0.72/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::94a8:79ff:fe53:25a8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ee:a8:85:5d:e7:ac brd ff:ff:ff:ff:ff:ff
    inet6 fe80::eca8:85ff:fe5d:e7ac/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:58:57:ba:ee:64 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a058:57ff:feba:ee64/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc22da8e4b7e6f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:bc:c3:6d:74:1a brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::54bc:c3ff:fe6d:741a/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc052ec9141d56@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3a:3d:fd:aa:d0:4d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::383d:fdff:feaa:d04d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcdc1adb2f4487@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:23:0a:0a:91:97 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::cc23:aff:fe0a:9197/64 scope link 
       valid_lft forever preferred_lft forever
