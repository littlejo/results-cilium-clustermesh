alloc: 209.01MB (219161712 bytes)
total-alloc: 2.22GB (2385623024 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63026404
frees: 60814148
heap-alloc: 209.01MB (219161712 bytes)
heap-sys: 247.36MB (259375104 bytes)
heap-idle: 19.26MB (20193280 bytes)
heap-in-use: 228.10MB (239181824 bytes)
heap-released: 2.77MB (2908160 bytes)
heap-objects: 2212256
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 3.58MB (3756800 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 978.07KB (1001545 bytes)
gc-sys: 6.03MB (6321640 bytes)
next-gc: when heap-alloc >= 225.54MB (236496152 bytes)
last-gc: 2024-10-30 08:22:52.821297536 +0000 UTC
gc-pause-total: 18.295808ms
gc-pause: 122672
gc-pause-end: 1730276572821297536
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005321117165757526
enable-gc: true
debug-gc: false
