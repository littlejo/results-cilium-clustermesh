[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-1b39c1f56cad430c6c4c7cb1d7d185b99b2242fed8617dbf090ba2b471442ef4.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-2408a613cd9772339f81b9df440790c73d0d156eb3efb8e303aa8f14f7118efe.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d109c9f_5818_4ce1_acd9_e4cba994871f.slice/cri-containerd-0faadd52d8a089190520c76602bb2eac92dca4384b5a2d63fc4b0fd2a126b8b4.scope"
      }
    ],
    "ips": [
      "10.189.0.207"
    ],
    "name": "clustermesh-apiserver-68789b4878-p627m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9574efa8_c57c_402d_b41e_6ce8c8a26517.slice/cri-containerd-453378cd926109a1d0116faf5eb6af5b23a54c15ff36286195bd952d1e8cc082.scope"
      }
    ],
    "ips": [
      "10.189.0.16"
    ],
    "name": "coredns-cc6ccd49c-r2qvt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd833951b_40f3_4687_8ba5_5a30e17ea028.slice/cri-containerd-68e80d76f91564003e6bccb3fe4c411d3a61e59de9a92d8c5aac528dbee4a3cc.scope"
      }
    ],
    "ips": [
      "10.189.0.188"
    ],
    "name": "coredns-cc6ccd49c-58vms",
    "namespace": "kube-system"
  }
]

