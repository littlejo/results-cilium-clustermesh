top - 08:22:52 up 29 min,  0 users,  load average: 1.12, 0.45, 0.25
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 51.6 us, 41.9 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4440.8 free,   1227.0 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6402.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 398328  79160 S  80.0   5.0   0:54.45 cilium-+
    623 root      20   0 1229640  32284   4004 S  20.0   0.4   0:00.03 gops
    690 root      20   0 1244084  20272  14208 S  13.3   0.3   0:00.02 hubble
    394 root      20   0 1229744   8256   3836 S   0.0   0.1   0:01.20 cilium-+
    622 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    624 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    649 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    659 root      20   0 1240432  16348  11228 S   0.0   0.2   0:00.03 cilium-+
    673 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    696 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    716 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
