key: 2b 04 00 00  value: 10 02 00 00
key: 9c 06 00 00  value: 18 02 00 00
key: c9 07 00 00  value: 22 02 00 00
key: e2 09 00 00  value: 67 02 00 00
Found 4 elements
