REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36633     2899081     677    bpf_overlay.c
Interface                 INGRESS     634879    130230401   1132   bpf_host.c
Success                   EGRESS      16518     1299915     1694   bpf_host.c
Success                   EGRESS      265952    33604047    1308   bpf_lxc.c
Success                   EGRESS      36785     2912882     53     encap.h
Success                   INGRESS     309883    34771814    86     l3.h
Success                   INGRESS     330649    36415026    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
