IP ADDRESS         LOCAL ENDPOINT INFO
10.189.0.207:0     id=2530  sec_id=6239718 flags=0x0000 ifindex=18  mac=C2:60:BE:CD:C7:51 nodemac=CE:23:0A:0A:91:97   
172.31.194.190:0   (localhost)                                                                                        
10.189.0.35:0      id=1692  sec_id=4     flags=0x0000 ifindex=10  mac=6E:FC:9E:4A:AC:7D nodemac=A2:58:57:BA:EE:64     
10.189.0.16:0      id=1067  sec_id=6227241 flags=0x0000 ifindex=12  mac=2E:C2:A0:3C:BA:31 nodemac=56:BC:C3:6D:74:1A   
172.31.232.206:0   (localhost)                                                                                        
10.189.0.72:0      (localhost)                                                                                        
10.189.0.188:0     id=1993  sec_id=6227241 flags=0x0000 ifindex=14  mac=DA:DD:25:A2:42:6F nodemac=3A:3D:FD:AA:D0:4D   
