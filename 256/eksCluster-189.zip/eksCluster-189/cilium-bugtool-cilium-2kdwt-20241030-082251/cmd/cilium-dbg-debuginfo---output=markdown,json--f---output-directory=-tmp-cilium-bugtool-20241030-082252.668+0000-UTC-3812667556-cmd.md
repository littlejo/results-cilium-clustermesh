markdown output at /tmp/cilium-bugtool-20241030-082252.668+0000-UTC-3812667556/cmd/cilium-debuginfo-20241030-082323.865+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082252.668+0000-UTC-3812667556/cmd/cilium-debuginfo-20241030-082323.865+0000-UTC.json
