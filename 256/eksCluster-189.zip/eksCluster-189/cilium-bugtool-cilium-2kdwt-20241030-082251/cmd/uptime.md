 08:22:52 up 29 min,  0 users,  load average: 1.12, 0.45, 0.25
