[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b5a0fda_9561_4d52_8a9f_a662b0bcd0ed.slice/cri-containerd-71bc19cd83463bffa5e912099ea4fe52476a3c0ad37bd8233dfc6be745f20169.scope"
      }
    ],
    "ips": [
      "10.204.0.96"
    ],
    "name": "coredns-cc6ccd49c-fx9p9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-0f2f630ae7d6bb490761ab0a874cf19d748dcd8733d042ba2d7e3ec4410f69f7.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-99415db9ab6b3b080bc0ceab41f10056b7e7b47656405e867ec2a91ce87e54a7.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-54e6227ac3a00290930ade26317d484adaa6f500f29bec326116237aea94ad10.scope"
      }
    ],
    "ips": [
      "10.204.0.150"
    ],
    "name": "clustermesh-apiserver-64c48755d7-c6jnj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod86ef2676_30f5_4ed6_ba91_5d5e35e685bc.slice/cri-containerd-7be51bfa3921e6f5a2d913d3e72d68c1d2b436301baaf12d241a7fa6b2de9be4.scope"
      }
    ],
    "ips": [
      "10.204.0.180"
    ],
    "name": "coredns-cc6ccd49c-pr9tc",
    "namespace": "kube-system"
  }
]

