REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36153     2855233     677    bpf_overlay.c
Interface                 INGRESS     640219    131419569   1132   bpf_host.c
Success                   EGRESS      15823     1238455     1694   bpf_host.c
Success                   EGRESS      270264    33843137    1308   bpf_lxc.c
Success                   EGRESS      35898     2834202     53     encap.h
Success                   INGRESS     313122    35278642    86     l3.h
Success                   INGRESS     334103    36939466    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
