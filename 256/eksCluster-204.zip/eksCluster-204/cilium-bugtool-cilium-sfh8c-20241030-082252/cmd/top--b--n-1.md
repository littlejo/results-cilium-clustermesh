top - 08:22:54 up 28 min,  0 users,  load average: 0.25, 0.16, 0.13
Tasks:  13 total,   3 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 66.7 us, 33.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4468.2 free,   1199.6 used,   2146.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 377592  78780 S  80.0   4.7   0:48.62 cilium-+
    623 root      20   0 1240432  16596  11484 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   8244   3900 S   0.0   0.1   0:01.21 cilium-+
    618 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    635 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    638 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    652 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    698 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    721 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    722 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    723 root      20   0    2304    836    752 S   0.0   0.0   0:00.00 sh
    738 root      20   0    2232    820    740 R   0.0   0.0   0:00.00 tail
    740 root      20   0    2208     84      0 R   0.0   0.0   0:00.00 timeout
