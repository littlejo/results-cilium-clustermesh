{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.773Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.128.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.773Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.773Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.452Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.460Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.517Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:27.536Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:07.914Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:07.915Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:07.916Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:07.947Z",
  "value": "id=1579  sec_id=6724801 flags=0x0000 ifindex=16  mac=72:34:38:3D:65:2F nodemac=16:41:78:57:89:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.914Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.914Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.914Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:08.914Z",
  "value": "id=1579  sec_id=6724801 flags=0x0000 ifindex=16  mac=72:34:38:3D:65:2F nodemac=16:41:78:57:89:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:02.691Z",
  "value": "id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.204.0.62:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.017Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.948Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.949Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.949Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.950Z",
  "value": "id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.989Z",
  "value": "id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.001Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.002Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.073Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.958Z",
  "value": "id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.958Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.958Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.959Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.958Z",
  "value": "id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.150:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.958Z",
  "value": "id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.959Z",
  "value": "id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.204.0.180:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.959Z",
  "value": "id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D"
}

