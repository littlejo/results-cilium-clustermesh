key: d9 00 00 00  value: 8a 02 00 00
key: 13 01 00 00  value: 14 02 00 00
key: ec 03 00 00  value: 1c 02 00 00
key: 83 05 00 00  value: 4a 02 00 00
Found 4 elements
