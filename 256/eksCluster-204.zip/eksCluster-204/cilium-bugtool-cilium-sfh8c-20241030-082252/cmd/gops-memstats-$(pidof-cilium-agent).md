alloc: 97.92MB (102675488 bytes)
total-alloc: 2.23GB (2389651400 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63146119
frees: 62454910
heap-alloc: 97.92MB (102675488 bytes)
heap-sys: 247.95MB (259989504 bytes)
heap-idle: 89.76MB (94117888 bytes)
heap-in-use: 158.19MB (165871616 bytes)
heap-released: 2.69MB (2818048 bytes)
heap-objects: 691209
stack-in-use: 60.03MB (62947328 bytes)
stack-sys: 60.03MB (62947328 bytes)
stack-mspan-inuse: 2.73MB (2862400 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1071753 bytes)
gc-sys: 6.03MB (6325880 bytes)
next-gc: when heap-alloc >= 213.92MB (224314456 bytes)
last-gc: 2024-10-30 08:23:24.172429419 +0000 UTC
gc-pause-total: 9.87568ms
gc-pause: 66232
gc-pause-end: 1730276604172429419
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005369537238683545
enable-gc: true
debug-gc: false
