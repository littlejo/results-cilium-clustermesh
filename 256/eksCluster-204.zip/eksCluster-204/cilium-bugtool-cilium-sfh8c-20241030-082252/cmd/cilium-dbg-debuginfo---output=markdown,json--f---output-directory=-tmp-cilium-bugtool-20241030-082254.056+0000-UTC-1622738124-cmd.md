markdown output at /tmp/cilium-bugtool-20241030-082254.056+0000-UTC-1622738124/cmd/cilium-debuginfo-20241030-082325.362+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.056+0000-UTC-1622738124/cmd/cilium-debuginfo-20241030-082325.362+0000-UTC.json
