ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.180.17:443 (active)    
                                          2 => 172.31.221.218:443 (active)   
2    10.100.205.109:443    ClusterIP      1 => 172.31.177.23:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.204.0.96:53 (active)       
                                          2 => 10.204.0.180:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.204.0.96:9153 (active)     
                                          2 => 10.204.0.180:9153 (active)    
5    10.100.251.206:2379   ClusterIP      1 => 10.204.0.150:2379 (active)    
