CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod211654ef_2704_4eed_8db4_05f7e3479648.slice/cri-containerd-47562cfa40d06b132c5139c7f4cdfefd161145c1424a87cc4e710c5254d06738.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod211654ef_2704_4eed_8db4_05f7e3479648.slice/cri-containerd-73c11ee77e2de2f5622b007368555ebde9f5606bd3be5b74e25e293a24d07b83.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b5a0fda_9561_4d52_8a9f_a662b0bcd0ed.slice/cri-containerd-3d786192633e02564dd201585ac81df025e9e6dad4fa12e7d229a2b926a49b89.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b5a0fda_9561_4d52_8a9f_a662b0bcd0ed.slice/cri-containerd-71bc19cd83463bffa5e912099ea4fe52476a3c0ad37bd8233dfc6be745f20169.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod86ef2676_30f5_4ed6_ba91_5d5e35e685bc.slice/cri-containerd-0e1d73cf568904f1ef75da573d4118ae556f99631e77f273b853f5346b5c9caf.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod86ef2676_30f5_4ed6_ba91_5d5e35e685bc.slice/cri-containerd-7be51bfa3921e6f5a2d913d3e72d68c1d2b436301baaf12d241a7fa6b2de9be4.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebd402cb_d742_4117_bdf7_cae775f8f240.slice/cri-containerd-f0c0f63c2bb5a5b7a13b7d22d3f153f1d5dde9c0736736dbd1323ebba839d5c4.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebd402cb_d742_4117_bdf7_cae775f8f240.slice/cri-containerd-81be7e3174c8d581e55caa09395b95b2efb33a804a89434e70d98c90e66b5e37.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbbdfdcf_cc6a_4f9d_b371_b0cf9965785e.slice/cri-containerd-a175b3345c4141f5991be83b6694b5dca5655d1845db4c97c4c38c90eadaf042.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbbdfdcf_cc6a_4f9d_b371_b0cf9965785e.slice/cri-containerd-276839f8bf15069b1b72e625c55db4948dbd69104c376077749e3bd519209a4d.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb03d28df_2658_451e_b4fa_6db21d892538.slice/cri-containerd-366c38d41114e7cba8efe76c9ee79dc14ec2140bb7837982a229fb3e06e80f39.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb03d28df_2658_451e_b4fa_6db21d892538.slice/cri-containerd-2a3ac977f6a26935410bde5228835e29d6f12da3626bf88a02022af134f4ed26.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-0f2f630ae7d6bb490761ab0a874cf19d748dcd8733d042ba2d7e3ec4410f69f7.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-54e6227ac3a00290930ade26317d484adaa6f500f29bec326116237aea94ad10.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-99415db9ab6b3b080bc0ceab41f10056b7e7b47656405e867ec2a91ce87e54a7.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod40b9a8b0_6ad0_42e9_9a00_f6e8cf00560f.slice/cri-containerd-54de0957a19a778e071005c945c6c105eb7144f0700c308591534fb86461a4d5.scope
    657      cgroup_device   multi                                          
