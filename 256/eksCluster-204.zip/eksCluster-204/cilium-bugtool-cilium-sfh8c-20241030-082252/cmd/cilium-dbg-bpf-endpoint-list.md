IP ADDRESS         LOCAL ENDPOINT INFO
10.204.0.96:0      id=275   sec_id=6719817 flags=0x0000 ifindex=12  mac=5E:01:86:AE:93:87 nodemac=02:07:95:63:53:CF   
172.31.177.23:0    (localhost)                                                                                        
10.204.0.236:0     id=1411  sec_id=4     flags=0x0000 ifindex=10  mac=3E:A0:D0:3E:C0:C2 nodemac=9A:4E:59:20:98:B8     
172.31.128.239:0   (localhost)                                                                                        
10.204.0.111:0     (localhost)                                                                                        
10.204.0.150:0     id=217   sec_id=6724801 flags=0x0000 ifindex=18  mac=FA:59:05:8F:80:51 nodemac=D2:F1:0D:7E:96:A7   
10.204.0.180:0     id=1004  sec_id=6719817 flags=0x0000 ifindex=14  mac=6E:0B:9D:66:4A:13 nodemac=2A:B4:DE:A0:D7:8D   
