key: 07 00 00 00  value: 0a cc 00 60 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a cc 00 60 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b4 11 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f dd da 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a cc 00 b4 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f b1 17 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a cc 00 96 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a cc 00 b4 23 c1 00 00  00 00 00 00
Found 8 elements
