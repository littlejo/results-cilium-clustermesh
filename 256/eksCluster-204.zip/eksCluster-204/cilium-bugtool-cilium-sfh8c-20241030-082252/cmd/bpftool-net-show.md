xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 557
ens6(5) clsact/ingress cil_from_netdev-ens6 id 567
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 547
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 487
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 583
lxc2ec1dd35d88d(12) clsact/ingress cil_from_container-lxc2ec1dd35d88d id 525
lxc1daed2727bf0(14) clsact/ingress cil_from_container-lxc1daed2727bf0 id 579
lxc5885fadb326b(18) clsact/ingress cil_from_container-lxc5885fadb326b id 653

flow_dissector:

netfilter:

