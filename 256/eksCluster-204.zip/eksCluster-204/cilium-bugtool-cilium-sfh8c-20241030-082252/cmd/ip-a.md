1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:61:3d:80:25:45 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.177.23/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1872sec preferred_lft 1872sec
    inet6 fe80::461:3dff:fe80:2545/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ac:41:4b:04:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.128.239/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ac:41ff:fe4b:48d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:57:21:5c:1d:d6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2057:21ff:fe5c:1dd6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:b6:da:77:33:26 brd ff:ff:ff:ff:ff:ff
    inet 10.204.0.111/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::54b6:daff:fe77:3326/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:1b:d3:36:b5:fa brd ff:ff:ff:ff:ff:ff
    inet6 fe80::681b:d3ff:fe36:b5fa/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:4e:59:20:98:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::984e:59ff:fe20:98b8/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2ec1dd35d88d@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:07:95:63:53:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::7:95ff:fe63:53cf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc1daed2727bf0@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:b4:de:a0:d7:8d brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::28b4:deff:fea0:d78d/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5885fadb326b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:f1:0d:7e:96:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d0f1:dff:fe7e:96a7/64 scope link 
       valid_lft forever preferred_lft forever
