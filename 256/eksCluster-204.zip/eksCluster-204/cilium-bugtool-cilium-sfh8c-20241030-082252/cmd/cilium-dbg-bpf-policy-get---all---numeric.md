Endpoint ID: 217
Path: /sys/fs/bpf/tc/globals/cilium_policy_00217

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11587892   115447    0        
Allow    Ingress     1          ANY          NONE         disabled    9986020    105238    0        
Allow    Egress      0          ANY          NONE         disabled    12813206   126254    0        


Endpoint ID: 275
Path: /sys/fs/bpf/tc/globals/cilium_policy_00275

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115125   1326      0        
Allow    Egress      0          ANY          NONE         disabled    15479    165       0        


Endpoint ID: 1004
Path: /sys/fs/bpf/tc/globals/cilium_policy_01004

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115228   1324      0        
Allow    Egress      0          ANY          NONE         disabled    15831    170       0        


Endpoint ID: 1411
Path: /sys/fs/bpf/tc/globals/cilium_policy_01411

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665603   21039     0        
Allow    Ingress     1          ANY          NONE         disabled    18434     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1891
Path: /sys/fs/bpf/tc/globals/cilium_policy_01891

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


