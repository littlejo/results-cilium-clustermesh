REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35662     2823726     677    bpf_overlay.c
Interface                 INGRESS     635709    130916753   1132   bpf_host.c
Success                   EGRESS      16324     1288780     1694   bpf_host.c
Success                   EGRESS      286693    34896088    1308   bpf_lxc.c
Success                   EGRESS      36399     2878692     53     encap.h
Success                   INGRESS     328925    36684787    86     l3.h
Success                   INGRESS     348914    38263779    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
