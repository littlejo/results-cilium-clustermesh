markdown output at /tmp/cilium-bugtool-20241030-082257.764+0000-UTC-3621354347/cmd/cilium-debuginfo-20241030-082259.854+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.764+0000-UTC-3621354347/cmd/cilium-debuginfo-20241030-082259.854+0000-UTC.json
