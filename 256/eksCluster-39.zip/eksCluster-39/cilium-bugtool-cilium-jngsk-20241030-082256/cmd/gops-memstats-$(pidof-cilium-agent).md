alloc: 103.28MB (108301848 bytes)
total-alloc: 2.41GB (2592366808 bytes)
sys: 320.83MB (336417124 bytes)
lookups: 0
mallocs: 65851776
frees: 65010360
heap-alloc: 103.28MB (108301848 bytes)
heap-sys: 240.56MB (252248064 bytes)
heap-idle: 68.57MB (71901184 bytes)
heap-in-use: 171.99MB (180346880 bytes)
heap-released: 3.31MB (3473408 bytes)
heap-objects: 841416
stack-in-use: 67.44MB (70713344 bytes)
stack-sys: 67.44MB (70713344 bytes)
stack-mspan-inuse: 3.03MB (3181760 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.09MB (1142105 bytes)
gc-sys: 5.82MB (6104816 bytes)
next-gc: when heap-alloc >= 210.14MB (220349192 bytes)
last-gc: 2024-10-30 08:22:51.143141024 +0000 UTC
gc-pause-total: 24.301673ms
gc-pause: 123596
gc-pause-end: 1730276571143141024
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.000503261184130332
enable-gc: true
debug-gc: false
