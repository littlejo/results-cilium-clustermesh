USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         584  0.0  0.2 1240432 16360 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         609  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root           1  3.6  4.9 1606144 396120 ?      Ssl  07:56   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         402  0.0  0.0 1229744 7844 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
