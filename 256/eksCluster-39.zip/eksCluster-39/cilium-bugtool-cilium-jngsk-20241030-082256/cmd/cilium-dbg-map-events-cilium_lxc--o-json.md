{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:59.361Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.204.239:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:59.361Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.252.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:59.361Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:03.861Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:03.895Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:03.899Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:03.958Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:04.080Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.117Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.118Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.119Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.149Z",
  "value": "id=137   sec_id=1312515 flags=0x0000 ifindex=16  mac=C6:73:9D:78:9B:DF nodemac=AE:5E:99:D1:D1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:07.118Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:07.118Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:07.119Z",
  "value": "id=137   sec_id=1312515 flags=0x0000 ifindex=16  mac=C6:73:9D:78:9B:DF nodemac=AE:5E:99:D1:D1:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:07.119Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.389Z",
  "value": "id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.39.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.929Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.614Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.614Z",
  "value": "id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.615Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.616Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.613Z",
  "value": "id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.615Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.618Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.619Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.609Z",
  "value": "id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.610Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.611Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.611Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.610Z",
  "value": "id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.56:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.610Z",
  "value": "id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.49:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.610Z",
  "value": "id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.39.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:12.610Z",
  "value": "id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91"
}

