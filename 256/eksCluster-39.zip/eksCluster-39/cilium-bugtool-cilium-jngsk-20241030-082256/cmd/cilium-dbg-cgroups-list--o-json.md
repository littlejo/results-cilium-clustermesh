[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-d1aee29524387edb1820e42df026dcf2d9e9eb335848c8bbbe44bc9fc961e7ae.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-e38eb27709ac7f681a57bf1c881278ef6383f71d267ec8747ccd33e1364cf002.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-329161a35dbddaef1609113c19eb35d90da29ec1adc949544e69e4e05b209465.scope"
      }
    ],
    "ips": [
      "10.39.0.56"
    ],
    "name": "clustermesh-apiserver-7d786f856-cdmbp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286fb008_eb9e_42c3_97d9_9a92b0a262ad.slice/cri-containerd-48dbfa36f93357c7cbfd5e043af4b2a38e8679c9018af023096b8597780823b3.scope"
      }
    ],
    "ips": [
      "10.39.0.49"
    ],
    "name": "coredns-cc6ccd49c-jj9kt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc14bba9f_ca06_463c_b855_d0732f6de718.slice/cri-containerd-6cc72caabe2a3432a7efbf8ae5eae7477504d9a41c42267f53dcfc84558c9c6e.scope"
      }
    ],
    "ips": [
      "10.39.0.103"
    ],
    "name": "coredns-cc6ccd49c-mpvr6",
    "namespace": "kube-system"
  }
]

