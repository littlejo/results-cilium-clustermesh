IP ADDRESS         LOCAL ENDPOINT INFO
10.39.0.31:0       id=3682  sec_id=4     flags=0x0000 ifindex=10  mac=16:4D:67:97:05:4F nodemac=D2:57:4F:30:A2:A0     
10.39.0.103:0      id=94    sec_id=1310728 flags=0x0000 ifindex=12  mac=82:A4:17:F9:5F:06 nodemac=6A:33:A9:3F:99:91   
10.39.0.49:0       id=297   sec_id=1310728 flags=0x0000 ifindex=14  mac=76:2C:D6:5B:59:2A nodemac=CA:DA:A8:25:92:3D   
172.31.252.16:0    (localhost)                                                                                        
172.31.204.239:0   (localhost)                                                                                        
10.39.0.24:0       (localhost)                                                                                        
10.39.0.56:0       id=869   sec_id=1312515 flags=0x0000 ifindex=18  mac=02:9F:35:A4:F1:B1 nodemac=A6:01:11:96:02:66   
