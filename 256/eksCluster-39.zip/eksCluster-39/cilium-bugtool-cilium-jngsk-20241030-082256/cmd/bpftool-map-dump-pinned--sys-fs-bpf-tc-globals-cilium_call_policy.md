key: 5e 00 00 00  value: 10 02 00 00
key: 29 01 00 00  value: 1f 02 00 00
key: 65 03 00 00  value: 74 02 00 00
key: 62 0e 00 00  value: fa 01 00 00
Found 4 elements
