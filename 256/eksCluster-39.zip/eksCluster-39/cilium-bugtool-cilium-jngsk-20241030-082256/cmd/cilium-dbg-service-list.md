ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.131:443 (active)   
                                          2 => 172.31.229.7:443 (active)     
2    10.100.82.35:443      ClusterIP      1 => 172.31.252.16:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.39.0.103:53 (active)       
                                          2 => 10.39.0.49:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.39.0.103:9153 (active)     
                                          2 => 10.39.0.49:9153 (active)      
5    10.100.172.226:2379   ClusterIP      1 => 10.39.0.56:2379 (active)      
