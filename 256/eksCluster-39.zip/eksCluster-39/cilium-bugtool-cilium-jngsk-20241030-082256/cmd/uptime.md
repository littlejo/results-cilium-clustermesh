 08:22:57 up 34 min,  0 users,  load average: 0.21, 0.21, 0.18
