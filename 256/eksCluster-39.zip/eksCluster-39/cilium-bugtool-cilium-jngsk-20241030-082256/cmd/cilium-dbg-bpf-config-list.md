KEY             VALUE
AgentLiveness   2060930876827
UTimeOffset     3379442419921875
