Endpoint ID: 94
Path: /sys/fs/bpf/tc/globals/cilium_policy_00094

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147345   1686      0        
Allow    Egress      0          ANY          NONE         disabled    19134    210       0        


Endpoint ID: 297
Path: /sys/fs/bpf/tc/globals/cilium_policy_00297

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147632   1695      0        
Allow    Egress      0          ANY          NONE         disabled    18423    201       0        


Endpoint ID: 869
Path: /sys/fs/bpf/tc/globals/cilium_policy_00869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10378992   107998    0        
Allow    Ingress     1          ANY          NONE         disabled    11689878   120346    0        
Allow    Egress      0          ANY          NONE         disabled    13102275   131775    0        


Endpoint ID: 1987
Path: /sys/fs/bpf/tc/globals/cilium_policy_01987

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3682
Path: /sys/fs/bpf/tc/globals/cilium_policy_03682

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1583761   20047     0        
Allow    Ingress     1          ANY          NONE         disabled    22585     265       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


