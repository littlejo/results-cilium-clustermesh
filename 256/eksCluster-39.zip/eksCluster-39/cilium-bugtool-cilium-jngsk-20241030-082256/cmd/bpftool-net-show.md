xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 570
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 559
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 510
lxc2ac55662ff2e(12) clsact/ingress cil_from_container-lxc2ac55662ff2e id 522
lxcce6e239d3d34(14) clsact/ingress cil_from_container-lxcce6e239d3d34 id 542
lxcdc1106414b23(18) clsact/ingress cil_from_container-lxcdc1106414b23 id 624

flow_dissector:

netfilter:

