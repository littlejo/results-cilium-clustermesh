# Cilium debug information

#### Cilium environment keys

```
enable-icmp-rules:true
dnsproxy-concurrency-processing-grace-period:0s
monitor-queue-size:0
bpf-lb-mode:snat
local-router-ipv4:
enable-monitor:true
service-no-backend-response:reject
restore:true
clustermesh-ip-identities-sync-timeout:1m0s
mesh-auth-gc-interval:5m0s
dns-policy-unload-on-shutdown:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
use-full-tls-context:false
cni-log-file:/var/run/cilium/cilium-cni.log
identity-change-grace-period:5s
enable-ipv6:false
enable-pmtu-discovery:false
log-driver:
enable-hubble:true
bpf-lb-acceleration:disabled
ipv6-mcast-device:
enable-bgp-control-plane:false
mke-cgroup-mount:
envoy-config-retry-interval:15s
enable-envoy-config:false
hubble-redact-http-headers-allow:
vtep-mask:
annotate-k8s-node:false
enable-nat46x64-gateway:false
enable-bpf-tproxy:false
k8s-service-cache-size:128
bpf-events-policy-verdict-enabled:true
datapath-mode:veth
hubble-event-queue-size:0
egress-masquerade-interfaces:ens+
bypass-ip-availability-upon-restore:false
hubble-export-file-max-backups:5
mesh-auth-rotated-identities-queue-size:1024
bpf-ct-timeout-regular-tcp-fin:10s
exclude-node-label-patterns:
dnsproxy-enable-transparent-mode:true
enable-ipv4-egress-gateway:false
trace-payloadlen:128
mesh-auth-spiffe-trust-domain:spiffe.cilium
monitor-aggregation-flags:all
proxy-admin-port:0
srv6-encap-mode:reduced
agent-health-port:9879
auto-create-cilium-node-resource:true
clustermesh-sync-timeout:1m0s
config-sources:config-map:kube-system/cilium-config
mesh-auth-mutual-connect-timeout:5s
bpf-ct-global-any-max:262144
enable-gateway-api:false
hubble-drop-events-interval:2m0s
disable-endpoint-crd:false
bpf-ct-timeout-service-tcp-grace:1m0s
enable-l2-pod-announcements:false
bpf-nat-global-max:524288
tofqdns-dns-reject-response-code:refused
enable-bpf-masquerade:false
node-port-bind-protection:true
clustermesh-enable-mcs-api:false
hubble-redact-http-headers-deny:
enable-cilium-api-server-access:
ipv4-pod-subnets:
bpf-ct-timeout-regular-tcp-syn:1m0s
bpf-lb-sock-hostns-only:false
bpf-map-dynamic-size-ratio:0.0025
cni-external-routing:false
bpf-lb-sock-terminate-pod-connections:false
enable-k8s-terminating-endpoint:true
install-no-conntrack-iptables-rules:false
enable-metrics:true
endpoint-bpf-prog-watchdog-interval:30s
envoy-log:
http-request-timeout:3600
enable-external-ips:false
bpf-lb-dsr-dispatch:opt
enable-cilium-endpoint-slice:false
hubble-redact-enabled:false
enable-identity-mark:true
state-dir:/var/run/cilium
bpf-auth-map-max:524288
vtep-endpoint:
log-opt:
cgroup-root:/run/cilium/cgroupv2
cluster-id:40
disable-external-ip-mitigation:false
ipam-default-ip-pool:default
bpf-lb-service-backend-map-max:0
enable-ipsec:false
debug:false
mtu:0
enable-ipv4-big-tcp:false
l2-announcements-lease-duration:15s
kvstore:
enable-ipsec-key-watcher:true
enable-local-redirect-policy:false
bpf-lb-rev-nat-map-max:0
enable-endpoint-routes:false
dnsproxy-insecure-skip-transparent-mode-check:false
max-connected-clusters:511
proxy-connect-timeout:2
enable-health-check-nodeport:true
proxy-max-connection-duration-seconds:0
bpf-events-trace-enabled:true
tunnel-port:0
bpf-lb-external-clusterip:false
mesh-auth-signal-backoff-duration:1s
bpf-policy-map-max:16384
egress-gateway-reconciliation-trigger-interval:1s
crd-wait-timeout:5m0s
cmdref:
envoy-secrets-namespace:
iptables-random-fully:false
cni-exclusive:true
direct-routing-skip-unreachable:false
node-labels:
bpf-ct-timeout-service-any:1m0s
tofqdns-idle-connection-grace-period:0s
hubble-metrics-server:
monitor-aggregation:medium
hubble-recorder-sink-queue-size:1024
enable-host-firewall:false
enable-k8s-networkpolicy:true
bpf-lb-source-range-map-max:0
bpf-lb-rss-ipv6-src-cidr:
identity-restore-grace-period:30s
api-rate-limit:
force-device-detection:false
hubble-export-denylist:
vtep-cidr:
enable-bbr:false
policy-audit-mode:false
k8s-client-connection-timeout:30s
prometheus-serve-addr:
k8s-api-server:
ipv6-range:auto
encryption-strict-mode-cidr:
allow-icmp-frag-needed:true
ipv6-node:auto
ipv4-node:auto
k8s-client-connection-keep-alive:30s
proxy-max-requests-per-connection:0
enable-tcx:true
remove-cilium-node-taints:true
cluster-pool-ipv4-cidr:10.39.0.0/16
ipv4-range:auto
labels:
hubble-skip-unknown-cgroup-ids:true
bpf-root:/sys/fs/bpf
mesh-auth-queue-size:1024
enable-service-topology:false
synchronize-k8s-nodes:true
http-idle-timeout:0
bpf-lb-service-map-max:0
enable-ipv4-fragment-tracking:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-recorder:false
k8s-client-burst:20
preallocate-bpf-maps:false
enable-sctp:false
cflags:
k8s-client-qps:10
enable-custom-calls:false
ipv4-service-range:auto
controller-group-metrics:
proxy-idle-timeout-seconds:60
prepend-iptables-chains:true
enable-ipv4-masquerade:true
enable-cilium-health-api-server-access:
nodeport-addresses:
enable-node-selector-labels:false
lib-dir:/var/lib/cilium
enable-xdp-prefilter:false
operator-api-serve-addr:127.0.0.1:9234
endpoint-queue-size:25
version:false
kvstore-connectivity-timeout:2m0s
tofqdns-min-ttl:0
exclude-local-address:
enable-xt-socket-fallback:true
cluster-health-port:4240
enable-bandwidth-manager:false
bpf-map-event-buffers:
ipv4-native-routing-cidr:
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
hubble-monitor-events:
identity-allocation-mode:crd
enable-tracing:false
hubble-event-buffer-capacity:4095
max-internal-timer-delay:0s
clustermesh-config:/var/lib/cilium/clustermesh/
hubble-recorder-storage-path:/var/run/cilium/pcaps
enable-k8s:true
ipam:cluster-pool
config:
wireguard-persistent-keepalive:0s
tofqdns-endpoint-max-ip-per-hostname:50
identity-gc-interval:15m0s
hubble-listen-address::4244
allocator-list-timeout:3m0s
routing-mode:tunnel
http-normalize-path:true
agent-liveness-update-interval:1s
enable-l2-neigh-discovery:true
proxy-xff-num-trusted-hops-ingress:0
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
mesh-auth-mutual-listener-port:0
tofqdns-proxy-port:0
fqdn-regex-compile-lru-size:1024
encrypt-interface:
set-cilium-is-up-condition:true
hubble-redact-http-urlquery:false
bgp-announce-pod-cidr:false
policy-queue-size:100
hubble-disable-tls:false
set-cilium-node-taints:true
bpf-lb-algorithm:random
enable-health-checking:true
ipam-cilium-node-update-rate:15s
ipam-multi-pool-pre-allocation:
disable-envoy-version-check:false
dnsproxy-concurrency-limit:0
external-envoy-proxy:true
proxy-gid:1337
ipv6-native-routing-cidr:
egress-gateway-policy-map-max:16384
enable-ipv6-ndp:false
k8s-require-ipv6-pod-cidr:false
keep-config:false
node-port-mode:snat
hubble-flowlogs-config-path:
enable-ipip-termination:false
procfs:/host/proc
mesh-auth-enabled:true
local-router-ipv6:
enable-active-connection-tracking:false
bpf-lb-dsr-l4-xlate:frontend
enable-masquerade-to-route-source:false
enable-node-port:false
container-ip-local-reserved-ports:auto
hubble-export-file-max-size-mb:10
ipsec-key-file:
metrics:
enable-ipv6-big-tcp:false
bpf-filter-priority:1
enable-encryption-strict-mode:false
enable-well-known-identities:false
operator-prometheus-serve-addr::9963
ingress-secrets-namespace:
enable-hubble-recorder-api:true
bpf-policy-map-full-reconciliation-interval:15m0s
enable-ingress-controller:false
l2-announcements-renew-deadline:5s
bpf-ct-timeout-service-tcp:2h13m20s
pprof:false
hubble-export-fieldmask:
kube-proxy-replacement:false
policy-trigger-interval:1s
enable-health-check-loadbalancer-ip:false
enable-ipv4:true
k8s-kubeconfig-path:
agent-labels:
k8s-service-proxy-name:
enable-ipsec-encrypted-overlay:false
gateway-api-secrets-namespace:
bpf-lb-map-max:65536
hubble-redact-kafka-apikey:false
hubble-export-file-path:
enable-k8s-api-discovery:false
bpf-ct-timeout-regular-any:1m0s
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
read-cni-conf:
ipv4-service-loopback-address:169.254.42.1
hubble-prefer-ipv6:false
kube-proxy-replacement-healthz-bind-address:
devices:
socket-path:/var/run/cilium/cilium.sock
egress-multi-home-ip-rule-compat:false
config-dir:/tmp/cilium/config-map
enable-stale-cilium-endpoint-cleanup:true
enable-ip-masq-agent:false
debug-verbose:
enable-runtime-device-detection:true
enable-svc-source-range-check:true
enable-l2-announcements:false
endpoint-gc-interval:5m0s
arping-refresh-period:30s
enable-srv6:false
direct-routing-device:
multicast-enabled:false
kvstore-lease-ttl:15m0s
envoy-config-timeout:2m0s
ipv6-cluster-alloc-cidr:f00d::/64
http-retry-count:3
install-iptables-rules:true
enable-ipv6-masquerade:true
policy-accounting:true
hubble-drop-events:false
conntrack-gc-interval:0s
encryption-strict-mode-allow-remote-node-identities:false
join-cluster:false
bpf-ct-timeout-regular-tcp:2h13m20s
dnsproxy-lock-count:131
k8s-sync-timeout:3m0s
enable-auto-protect-node-port-range:true
mesh-auth-spire-admin-socket:
bgp-announce-lb-ip:false
tofqdns-enable-dns-compression:true
auto-direct-node-routes:false
local-max-addr-scope:252
nat-map-stats-interval:30s
unmanaged-pod-watcher-interval:15
log-system-load:false
use-cilium-internal-ip-for-ipsec:false
k8s-heartbeat-timeout:30s
bpf-lb-sock:false
kvstore-max-consecutive-quorum-errors:2
cni-chaining-mode:none
policy-cidr-match-mode:
node-port-range:
http-retry-timeout:0
dnsproxy-lock-timeout:500ms
nat-map-stats-entries:32
bpf-lb-rss-ipv4-src-cidr:
enable-ipsec-xfrm-state-caching:true
hubble-drop-events-reasons:auth_required,policy_denied
tofqdns-max-deferred-connection-deletes:10000
dnsproxy-socket-linger-timeout:10
enable-endpoint-health-checking:true
proxy-prometheus-port:0
enable-bpf-clock-probe:false
tunnel-protocol:vxlan
identity-heartbeat-timeout:30m0s
enable-vtep:false
nodes-gc-interval:5m0s
k8s-namespace:kube-system
derive-masq-ip-addr-from-device:
pprof-port:6060
hubble-redact-http-userinfo:true
enable-wireguard:false
enable-unreachable-routes:false
ipsec-key-rotation-duration:5m0s
bpf-lb-affinity-map-max:0
gops-port:9890
bpf-events-drop-enabled:true
trace-sock:true
enable-local-node-route:true
bpf-sock-rev-map-max:262144
node-port-algorithm:random
hubble-export-file-compress:false
l2-pod-announcements-interface:
tofqdns-proxy-response-max-delay:100ms
max-controller-interval:0
enable-mke:false
vtep-mac:
cluster-pool-ipv4-mask-size:24
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
node-port-acceleration:disabled
enable-policy:default
envoy-keep-cap-netbindservice:false
tofqdns-pre-cache:
cilium-endpoint-gc-interval:5m0s
ipv6-pod-subnets:
enable-l7-proxy:true
cluster-name:cmesh40
enable-wireguard-userspace-fallback:false
hubble-metrics:
http-max-grpc-timeout:0
pprof-address:localhost
enable-high-scale-ipcache:false
conntrack-gc-max-interval:0s
vlan-bpf-bypass:
clustermesh-enable-endpoint-sync:false
bpf-lb-maglev-map-max:0
bpf-lb-maglev-table-size:16381
enable-k8s-endpoint-slice:true
label-prefix-file:
proxy-portrange-min:10000
ipv6-service-range:auto
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
bpf-ct-global-tcp-max:524288
hubble-export-allowlist:
k8s-require-ipv4-pod-cidr:false
bpf-fragments-map-max:8192
l2-announcements-retry-period:2s
enable-host-port:false
certificates-directory:/var/run/cilium/certs
static-cnp-path:
dns-max-ips-per-restored-rule:1000
hubble-socket-path:/var/run/cilium/hubble.sock
enable-host-legacy-routing:false
bpf-neigh-global-max:524288
allow-localhost:auto
bgp-config-path:/var/lib/cilium/bgp/config.yaml
route-metric:0
envoy-base-id:0
cni-chaining-target:
monitor-aggregation-interval:5s
encrypt-node:false
iptables-lock-timeout:5s
bpf-node-map-max:16384
kvstore-opt:
fixed-identity-mapping:
proxy-portrange-max:20000
disable-iptables-feeder-rules:
enable-route-mtu-for-cni-chaining:false
proxy-xff-num-trusted-hops-egress:0
custom-cni-conf:false
enable-session-affinity:false
kvstore-periodic-sync:5m0s
```


#### Service list

```
ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.131:443 (active)   
                                          2 => 172.31.229.7:443 (active)     
2    10.100.82.35:443      ClusterIP      1 => 172.31.252.16:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.39.0.103:53 (active)       
                                          2 => 10.39.0.49:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.39.0.103:9153 (active)     
                                          2 => 10.39.0.49:9153 (active)      
5    10.100.172.226:2379   ClusterIP      1 => 10.39.0.56:2379 (active)      
```

#### Policy get

```
:
 []
Revision: 1

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=10) "10.39.0.31": (string) (len=6) "health",
  (string) (len=11) "10.39.0.103": (string) (len=35) "kube-system/coredns-cc6ccd49c-mpvr6",
  (string) (len=10) "10.39.0.49": (string) (len=35) "kube-system/coredns-cc6ccd49c-jj9kt",
  (string) (len=10) "10.39.0.56": (string) (len=49) "kube-system/clustermesh-apiserver-7d786f856-cdmbp",
  (string) (len=10) "10.39.0.24": (string) (len=6) "router"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.252.16": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x40023613f0)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001bc2240,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001bc2240,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4002360160)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4002360210)(frontends:[10.100.82.35]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4002360370)(frontends:[10.100.0.10]/ports=[dns dns-tcp metrics]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001be2e70)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4001be2f20)(frontends:[10.100.172.226]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4000dd1650)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-bfjgv": (*k8s.Endpoints)(0x4006cc0410)(10.39.0.56:2379/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001624450)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002335d40)(172.31.159.131:443/TCP,172.31.229.7:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001624458)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-4tkds": (*k8s.Endpoints)(0x4001527ad0)(172.31.252.16:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001624460)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-d4nms": (*k8s.Endpoints)(0x4002c30d00)(10.39.0.103:53/TCP[eu-west-3b],10.39.0.103:53/UDP[eu-west-3b],10.39.0.103:9153/TCP[eu-west-3b],10.39.0.49:53/TCP[eu-west-3b],10.39.0.49:53/UDP[eu-west-3b],10.39.0.49:9153/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40005a6d20)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x4000664b90)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400471e780
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400159f4a0,
  gcExited: (chan struct {}) 0x400159f500,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001029380)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e2a758)({
      MetricVec: (*prometheus.MetricVec)(0x4002241b90)({
       metricMap: (*prometheus.metricMap)(0x4002241bc0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83380)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001029400)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e2a760)({
      MetricVec: (*prometheus.MetricVec)(0x4002241c20)({
       metricMap: (*prometheus.metricMap)(0x4002241c50)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b833e0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001029480)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a768)({
      MetricVec: (*prometheus.MetricVec)(0x4002241cb0)({
       metricMap: (*prometheus.metricMap)(0x4002241ce0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83440)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001029500)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a770)({
      MetricVec: (*prometheus.MetricVec)(0x4002241d40)({
       metricMap: (*prometheus.metricMap)(0x4002241d70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b834a0)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001029580)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a778)({
      MetricVec: (*prometheus.MetricVec)(0x4002241dd0)({
       metricMap: (*prometheus.metricMap)(0x4002241e00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83560)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001029600)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a780)({
      MetricVec: (*prometheus.MetricVec)(0x4002241e60)({
       metricMap: (*prometheus.metricMap)(0x4002241e90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83620)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001029680)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a788)({
      MetricVec: (*prometheus.MetricVec)(0x4002241ef0)({
       metricMap: (*prometheus.metricMap)(0x4002241f20)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83680)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001029700)({
     GaugeVec: (*prometheus.GaugeVec)(0x4000e2a790)({
      MetricVec: (*prometheus.MetricVec)(0x400224a000)({
       metricMap: (*prometheus.metricMap)(0x400224a030)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b836e0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001029780)({
     ObserverVec: (*prometheus.HistogramVec)(0x4000e2a798)({
      MetricVec: (*prometheus.MetricVec)(0x400224a090)({
       metricMap: (*prometheus.metricMap)(0x400224a0c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4000b83740)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40005a6d20)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x40005c0000)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x40005ab008)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 377ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1
  }
 })
})

```


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.39.0.0/24, 
Allocated addresses:
  10.39.0.103 (kube-system/coredns-cc6ccd49c-mpvr6)
  10.39.0.24 (router)
  10.39.0.31 (health)
  10.39.0.49 (kube-system/coredns-cc6ccd49c-jj9kt)
  10.39.0.56 (kube-system/clustermesh-apiserver-7d786f856-cdmbp)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh234: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=234, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m51s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m50s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 1 reconnections (last: 12m52s ago)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: d30719f320c405b4
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                               Last success   Last error   Count   Message
  cilium-health-ep                                                   58s ago        never        0       no error   
  ct-map-pressure                                                    0s ago         never        0       no error   
  daemon-validate-config                                             35s ago        never        0       no error   
  dns-garbage-collector-job                                          2s ago         never        0       no error   
  endpoint-1987-regeneration-recovery                                never          never        0       no error   
  endpoint-297-regeneration-recovery                                 never          never        0       no error   
  endpoint-3682-regeneration-recovery                                never          never        0       no error   
  endpoint-869-regeneration-recovery                                 never          never        0       no error   
  endpoint-94-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                        1m2s ago       never        0       no error   
  ep-bpf-prog-watchdog                                               0s ago         never        0       no error   
  ipcache-inject-labels                                              0s ago         never        0       no error   
  k8s-heartbeat                                                      3s ago         never        0       no error   
  link-cache                                                         0s ago         never        0       no error   
  local-identity-checkpoint                                          26m0s ago      never        0       no error   
  node-neighbor-link-updater                                         0s ago         never        0       no error   
  remote-etcd-cmesh1                                                 12m50s ago     never        0       no error   
  remote-etcd-cmesh10                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh100                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh101                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh102                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh103                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh104                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh105                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh106                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh107                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh108                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh109                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh11                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh110                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh111                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh112                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh113                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh114                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh115                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh116                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh117                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh118                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh119                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh12                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh120                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh121                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh122                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh123                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh124                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh125                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh126                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh127                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh128                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh129                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh13                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh130                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh131                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh132                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh133                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh134                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh135                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh136                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh137                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh138                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh139                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh14                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh140                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh141                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh142                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh143                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh144                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh145                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh146                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh147                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh148                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh149                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh15                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh150                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh151                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh152                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh153                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh154                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh155                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh156                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh157                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh158                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh159                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh16                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh160                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh161                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh162                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh163                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh164                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh165                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh166                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh167                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh168                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh169                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh17                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh170                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh171                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh172                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh173                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh174                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh175                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh176                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh177                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh178                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh179                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh18                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh180                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh181                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh182                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh183                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh184                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh185                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh186                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh187                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh188                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh189                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh19                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh190                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh191                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh192                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh193                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh194                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh195                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh196                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh197                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh198                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh199                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh2                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh20                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh200                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh201                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh202                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh203                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh204                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh205                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh206                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh207                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh208                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh209                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh21                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh210                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh211                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh212                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh213                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh214                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh215                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh216                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh217                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh218                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh219                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh22                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh220                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh221                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh222                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh223                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh224                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh225                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh226                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh227                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh228                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh229                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh23                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh230                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh231                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh232                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh233                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh234                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh235                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh236                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh237                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh238                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh239                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh24                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh240                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh241                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh242                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh243                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh244                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh245                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh246                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh247                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh248                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh249                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh25                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh250                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh251                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh252                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh253                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh254                                               12m50s ago     never        0       no error   
  remote-etcd-cmesh255                                               12m49s ago     never        0       no error   
  remote-etcd-cmesh256                                               12m48s ago     never        0       no error   
  remote-etcd-cmesh26                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh27                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh28                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh29                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh3                                                 12m48s ago     never        0       no error   
  remote-etcd-cmesh30                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh31                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh32                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh33                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh34                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh35                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh36                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh37                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh38                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh39                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh4                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh41                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh42                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh43                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh44                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh45                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh46                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh47                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh48                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh49                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh5                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh50                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh51                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh52                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh53                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh54                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh55                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh56                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh57                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh58                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh59                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh6                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh60                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh61                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh62                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh63                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh64                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh65                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh66                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh67                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh68                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh69                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh7                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh70                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh71                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh72                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh73                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh74                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh75                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh76                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh77                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh78                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh79                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh8                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh80                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh81                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh82                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh83                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh84                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh85                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh86                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh87                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh88                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh89                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh9                                                 12m49s ago     never        0       no error   
  remote-etcd-cmesh90                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh91                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh92                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh93                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh94                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh95                                                12m50s ago     never        0       no error   
  remote-etcd-cmesh96                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh97                                                12m48s ago     never        0       no error   
  remote-etcd-cmesh98                                                12m49s ago     never        0       no error   
  remote-etcd-cmesh99                                                12m50s ago     never        0       no error   
  resolve-identity-1987                                              1m0s ago       never        0       no error   
  resolve-identity-297                                               59s ago        never        0       no error   
  resolve-identity-3682                                              59s ago        never        0       no error   
  resolve-identity-869                                               3m2s ago       never        0       no error   
  resolve-identity-94                                                59s ago        never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-7d786f856-cdmbp   13m2s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jj9kt                 25m59s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-mpvr6                 25m59s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                     26m0s ago      never        0       no error   
  sync-policymap-1987                                                10m59s ago     never        0       no error   
  sync-policymap-297                                                 10m55s ago     never        0       no error   
  sync-policymap-3682                                                10m55s ago     never        0       no error   
  sync-policymap-869                                                 13m2s ago      never        0       no error   
  sync-policymap-94                                                  10m55s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (297)                                   9s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (869)                                   2s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (94)                                    9s ago         never        0       no error   
  sync-utime                                                         0s ago         never        0       no error   
  write-cni-file                                                     26m2s ago      never        0       no error   
Proxy Status:            OK, ip 10.39.0.24, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 1310720, max 1343487
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 131.42   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
94         Disabled           Disabled          1310728    k8s:eks.amazonaws.com/component=coredns                                             10.39.0.103   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh40                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
297        Disabled           Disabled          1310728    k8s:eks.amazonaws.com/component=coredns                                             10.39.0.49    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh40                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
869        Disabled           Disabled          1312515    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.39.0.56    ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh40                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1987       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                    ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
3682       Disabled           Disabled          4          reserved:health                                                                     10.39.0.31    ready   
```

#### BPF Policy Get 94

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    146384   1675      0        
Allow    Egress      0          ANY          NONE         disabled    19134    210       0        

```


#### BPF CT List 94

```
Invalid argument: unknown type 94
```


#### Endpoint Get 94

```
[
  {
    "id": 94,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-94-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bcedd01f-afa6-49a1-94b0-39d436dd056a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:00.452Z",
            "success-count": 6
          },
          "uuid": "70f2894a-1b0a-48ec-872b-651eba2d7487"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-mpvr6",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:57:00.449Z",
            "success-count": 1
          },
          "uuid": "7328cc2f-9eb4-4cec-b21b-13e876c9b95a"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-94",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:12:03.865Z",
            "success-count": 2
          },
          "uuid": "99130fd7-54ca-4385-b236-3ccc439a04cc"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (94)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:50.584Z",
            "success-count": 157
          },
          "uuid": "246d4cfe-1c43-454e-86b7-8391c25ba911"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "3e458df41af7f9452e34a74bcc8951e96d9a22de8acc80c507b90d41752b5807:eth0",
        "container-id": "3e458df41af7f9452e34a74bcc8951e96d9a22de8acc80c507b90d41752b5807",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-mpvr6",
        "pod-name": "kube-system/coredns-cc6ccd49c-mpvr6"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1310728,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.39.0.103",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "6a:33:a9:3f:99:91",
        "interface-index": 12,
        "interface-name": "lxc2ac55662ff2e",
        "mac": "82:a4:17:f9:5f:06"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1310728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1310728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 94

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 94

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:57:00Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:57:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1310728

```
ID        LABELS
1310728   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh40
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 297

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    147632   1695      0        
Allow    Egress      0          ANY          NONE         disabled    18357    200       0        

```


#### BPF CT List 297

```
Invalid argument: unknown type 297
```


#### Endpoint Get 297

```
[
  {
    "id": 297,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-297-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "5f997de5-3d74-48b1-9b04-abf3a9710c91"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-297",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:00.512Z",
            "success-count": 6
          },
          "uuid": "a5632395-e963-4c30-bad6-72c4fb6a0051"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jj9kt",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T07:57:00.509Z",
            "success-count": 1
          },
          "uuid": "faedda7a-0906-44d3-95f9-bbd51fb72b2e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-297",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:12:03.904Z",
            "success-count": 2
          },
          "uuid": "30bc0e0c-b350-4d23-8f51-86f070aacf15"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (297)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:50.632Z",
            "success-count": 157
          },
          "uuid": "be038f7b-665f-4eb9-91d3-c85b9d5ec7a4"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "d475e55761338ce3972edc7ef0258fb3cba55a18655c954cbd4d4bcdbd4a212a:eth0",
        "container-id": "d475e55761338ce3972edc7ef0258fb3cba55a18655c954cbd4d4bcdbd4a212a",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jj9kt",
        "pod-name": "kube-system/coredns-cc6ccd49c-jj9kt"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1310728,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.39.0.49",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "ca:da:a8:25:92:3d",
        "interface-index": 14,
        "interface-name": "lxcce6e239d3d34",
        "mac": "76:2c:d6:5b:59:2a"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            1,
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1310728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1310728,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 297

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 297

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:03Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:00Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:57:00Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:57:00Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1310728

```
ID        LABELS
1310728   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh40
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 869

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    10266985   106916    0        
Allow    Ingress     1          ANY          NONE         disabled    11626128   119581    0        
Allow    Egress      0          ANY          NONE         disabled    13088079   131614    0        

```


#### BPF CT List 869

```
Invalid argument: unknown type 869
```


#### Endpoint Get 869

```
[
  {
    "id": 869,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-869-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a1622f4b-0885-4d80-b5ea-1c86b260ccaf"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-869",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:19:57.360Z",
            "success-count": 3
          },
          "uuid": "a9aff5fe-f41b-4d1f-8ba8-396705e8c026"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-7d786f856-cdmbp",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:09:57.359Z",
            "success-count": 1
          },
          "uuid": "a5e315e4-7a46-4831-9812-37247ba1d960"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-869",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:09:57.389Z",
            "success-count": 1
          },
          "uuid": "d846857e-2dc3-4890-a8e1-2f8323f2e1a9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (869)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:57.447Z",
            "success-count": 80
          },
          "uuid": "81297291-7f16-4e8d-af50-17da644bf4ed"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "da26878f73e6a8d25b761a71d4643c4f1040fd2cc7a238afe20adf0f8c1f3b5f:eth0",
        "container-id": "da26878f73e6a8d25b761a71d4643c4f1040fd2cc7a238afe20adf0f8c1f3b5f",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-7d786f856-cdmbp",
        "pod-name": "kube-system/clustermesh-apiserver-7d786f856-cdmbp"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1312515,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=7d786f856"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh40",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.39.0.56",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "a6:01:11:96:02:66",
        "interface-index": 18,
        "interface-name": "lxcdc1106414b23",
        "mac": "02:9f:35:a4:f1:b1"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1312515,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1312515,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 869

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 869

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:09:57Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:09:57Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:09:57Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:09:57Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:09:57Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:09:57Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1312515

```
ID        LABELS
1312515   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh40
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1987

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 1987

```
Invalid argument: unknown type 1987
```


#### Endpoint Get 1987

```
[
  {
    "id": 1987,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1987-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "6a27727c-ab16-4463-b349-fc1417f15d6b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1987",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:59.523Z",
            "success-count": 6
          },
          "uuid": "e13021fb-a8fc-44aa-afcc-a04e5e6ab467"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1987",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:12:00.717Z",
            "success-count": 2
          },
          "uuid": "d6649aeb-df4e-49a1-832c-8293ecf3f73f"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "b6:90:61:a4:6c:cb",
        "interface-name": "cilium_host",
        "mac": "b6:90:61:a4:6c:cb"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1987

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1987

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:05Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T07:57:05Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:03Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:56:59Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:56:59Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:56:59Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:56:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 3682

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1582270   20029     0        
Allow    Ingress     1          ANY          NONE         disabled    22154     260       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 3682

```
Invalid argument: unknown type 3682
```


#### Endpoint Get 3682

```
[
  {
    "id": 3682,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-3682-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "18217213-c703-4b1c-bb01-a683cf197c52"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-3682",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:22:00.590Z",
            "success-count": 6
          },
          "uuid": "f468bb1e-3ca5-4b76-b6a3-b17a3955b778"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-3682",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:12:03.897Z",
            "success-count": 2
          },
          "uuid": "49efa70f-1114-4c4f-8ee3-5b5d90839e6e"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:10:12Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.39.0.31",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "d2:57:4f:30:a2:a0",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "16:4d:67:97:05:4f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 3682

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 3682

```
Timestamp              Status   State                   Message
2024-10-30T08:10:12Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:10:12Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:12Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:10:12Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:10:11Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:11Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:11Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:11Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:10Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:10Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:10Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:10Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:10:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:10:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:10:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:10:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:07Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:07Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:07Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:07Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:02:06Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:02:06Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:02:06Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:02:06Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T07:57:03Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T07:57:03Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T07:57:03Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T07:57:01Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T07:57:00Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T07:57:00Z   OK       ready                   Set identity for this endpoint
2024-10-30T07:56:59Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33616089                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33616089                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33616089                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4014400000 rw-p 00000000 00:00 0 
4014400000-4018000000 ---p 00000000 00:00 0 
ffff6de5e000-ffff6e1f7000 rw-p 00000000 00:00 0 
ffff6e1fb000-ffff6e2ac000 rw-p 00000000 00:00 0 
ffff6e2b4000-ffff6e3d5000 rw-p 00000000 00:00 0 
ffff6e3d5000-ffff6e416000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e416000-ffff6e457000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e457000-ffff6e497000 rw-p 00000000 00:00 0 
ffff6e497000-ffff6e499000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e499000-ffff6e49b000 rw-s 00000000 00:0d 1033                       anon_inode:[perf_event]
ffff6e49b000-ffff6ea62000 rw-p 00000000 00:00 0 
ffff6ea62000-ffff6eb62000 rw-p 00000000 00:00 0 
ffff6eb62000-ffff6eb73000 rw-p 00000000 00:00 0 
ffff6eb73000-ffff70b73000 rw-p 00000000 00:00 0 
ffff70b73000-ffff70bf3000 ---p 00000000 00:00 0 
ffff70bf3000-ffff70bf4000 rw-p 00000000 00:00 0 
ffff70bf4000-ffff90bf3000 ---p 00000000 00:00 0 
ffff90bf3000-ffff90bf4000 rw-p 00000000 00:00 0 
ffff90bf4000-ffffb0b83000 ---p 00000000 00:00 0 
ffffb0b83000-ffffb0b84000 rw-p 00000000 00:00 0 
ffffb0b84000-ffffb4b75000 ---p 00000000 00:00 0 
ffffb4b75000-ffffb4b76000 rw-p 00000000 00:00 0 
ffffb4b76000-ffffb5373000 ---p 00000000 00:00 0 
ffffb5373000-ffffb5374000 rw-p 00000000 00:00 0 
ffffb5374000-ffffb5473000 ---p 00000000 00:00 0 
ffffb5473000-ffffb54d3000 rw-p 00000000 00:00 0 
ffffb54d3000-ffffb54d5000 r--p 00000000 00:00 0                          [vvar]
ffffb54d5000-ffffb54d6000 r-xp 00000000 00:00 0                          [vdso]
ffffc306f000-ffffc3090000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```

