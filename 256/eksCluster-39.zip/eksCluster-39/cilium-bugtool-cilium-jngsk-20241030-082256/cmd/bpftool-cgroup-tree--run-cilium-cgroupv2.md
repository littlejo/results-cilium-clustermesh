CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc14bba9f_ca06_463c_b855_d0732f6de718.slice/cri-containerd-6cc72caabe2a3432a7efbf8ae5eae7477504d9a41c42267f53dcfc84558c9c6e.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc14bba9f_ca06_463c_b855_d0732f6de718.slice/cri-containerd-3e458df41af7f9452e34a74bcc8951e96d9a22de8acc80c507b90d41752b5807.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286fb008_eb9e_42c3_97d9_9a92b0a262ad.slice/cri-containerd-d475e55761338ce3972edc7ef0258fb3cba55a18655c954cbd4d4bcdbd4a212a.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod286fb008_eb9e_42c3_97d9_9a92b0a262ad.slice/cri-containerd-48dbfa36f93357c7cbfd5e043af4b2a38e8679c9018af023096b8597780823b3.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe89246f_fd8a_4cdd_8bb2_e29accb08316.slice/cri-containerd-1a6ce534d2482fabe2ef7fc6b4f9363aad0e2614f21390eeb2414f78d5f47f11.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe89246f_fd8a_4cdd_8bb2_e29accb08316.slice/cri-containerd-f089981e7a5d16e9cec9b1fd5a59c30b067b22153ee69d5bb769d18b7f2724b3.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode21a9567_4d77_4e21_b608_3243fe635012.slice/cri-containerd-7df8abac2b0b1b44b142ce576522c55b5508d0a0876e333dcee9f3d2b0c16b3d.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode21a9567_4d77_4e21_b608_3243fe635012.slice/cri-containerd-93e3fccbd183e8421fcf5bb669f85845511f52bf408c234575b7fad35b266a29.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-d1aee29524387edb1820e42df026dcf2d9e9eb335848c8bbbe44bc9fc961e7ae.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-da26878f73e6a8d25b761a71d4643c4f1040fd2cc7a238afe20adf0f8c1f3b5f.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-e38eb27709ac7f681a57bf1c881278ef6383f71d267ec8747ccd33e1364cf002.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod684aaf23_86d4_4e19_8cca_1df4481895e1.slice/cri-containerd-329161a35dbddaef1609113c19eb35d90da29ec1adc949544e69e4e05b209465.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2995988e_bda0_469a_b0b0_4390f09907fe.slice/cri-containerd-e8b7c6e3f3fd5a0166cd58d92955c94ae7ad14804228b226f98f645879e11e2c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2995988e_bda0_469a_b0b0_4390f09907fe.slice/cri-containerd-b31a80e7439b423d295e5328302141c53fca12c8d6f5b00f957232b7bb2af071.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8804791_51cd_4eb8_9647_be5d07ff6961.slice/cri-containerd-3c141902749b7318cb835b99d58d43a62c641ff553559dff2b685340ba28e60a.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode8804791_51cd_4eb8_9647_be5d07ff6961.slice/cri-containerd-d70b18ee1fc66ee148173a39a7805899e28d8148d34484b5398abcafc4a679d5.scope
    106      cgroup_device   multi                                          
