[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e46b69_809c_4d16_9efb_0f7a01ab2de9.slice/cri-containerd-610e04ae8e90f1a069ec8de2dd82a4a46573995b9d58c472bfb354e2a0c2514f.scope"
      }
    ],
    "ips": [
      "10.195.0.101"
    ],
    "name": "coredns-cc6ccd49c-vsk84",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-98d5464f8622133bee0f1ed50d814a83afd147cdd8101f71e1bb8b55a346c91b.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-1c45fdd464a130532f2b3316397743c772c43ebf1ec2c650368ebb08c5a3d0d7.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-b59c079953e446b46327e2a78add3a4c2eb79fa21b441b17fbd52d19a98a1899.scope"
      }
    ],
    "ips": [
      "10.195.0.179"
    ],
    "name": "clustermesh-apiserver-5dfd8ff949-vpbl6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeff3406_fc9e_4cc1_a887_d14e2792611b.slice/cri-containerd-67c9e8f7e42f6eda71b088d4f06c9f617e8afd16ee3d3b01c65f4efb17bf2981.scope"
      }
    ],
    "ips": [
      "10.195.0.168"
    ],
    "name": "coredns-cc6ccd49c-ts4gs",
    "namespace": "kube-system"
  }
]

