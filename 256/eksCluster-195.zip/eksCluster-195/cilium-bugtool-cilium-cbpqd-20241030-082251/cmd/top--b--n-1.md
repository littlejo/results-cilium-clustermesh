top - 08:22:53 up 30 min,  0 users,  load average: 0.40, 0.27, 0.15
Tasks:   9 total,   2 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 44.8 us, 37.9 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi, 17.2 si,  0.0 st
MiB Mem :   7814.2 total,   4467.2 free,   1200.8 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6428.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    677 root      20   0 1244596  21792  14140 S  40.0   0.3   0:00.23 hubble
      1 root      20   0 1606080 392444  77688 S   6.7   4.9   0:44.54 cilium-+
    685 root      20   0 1240432  16472  11548 S   6.7   0.2   0:00.03 cilium-+
    397 root      20   0 1229744   6780   2924 S   0.0   0.1   0:01.13 cilium-+
    651 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    658 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    663 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    711 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    722 root      20   0    5276   2624   2120 R   0.0   0.0   0:00.00 iptable+
