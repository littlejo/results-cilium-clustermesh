key: b8 01 00 00  value: 40 02 00 00
key: 53 03 00 00  value: 24 02 00 00
key: d5 07 00 00  value: 0a 02 00 00
key: a4 0c 00 00  value: 8d 02 00 00
Found 4 elements
