REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34181     2698335     677    bpf_overlay.c
Interface                 INGRESS     613846    128021465   1132   bpf_host.c
Success                   EGRESS      14000     1094981     1694   bpf_host.c
Success                   EGRESS      257950    32916332    1308   bpf_lxc.c
Success                   EGRESS      33054     2616014     53     encap.h
Success                   INGRESS     299418    33643531    86     l3.h
Success                   INGRESS     320250    35290931    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
