Total: 665
TCP:   1870 (estab 430, closed 1421, orphaned 0, timewait 579)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  449       438       11       
INET	  459       444       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                          
UNCONN 0      0                   172.31.211.96%ens5:68         0.0.0.0:*    uid:192 ino:77388 sk:1213 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35598 sk:1214 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15601 sk:1215 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:41887      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36370 sk:1216 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35597 sk:1217 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15602 sk:1218 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8d4:fbff:fe85:59b1]%ens5:546           [::]:*    uid:192 ino:15803 sk:1219 cgroup:unreachable:c4e v6only:1 <->                   
