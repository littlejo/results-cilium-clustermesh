IP ADDRESS         LOCAL ENDPOINT INFO
172.31.211.96:0    (localhost)                                                                                        
10.195.0.203:0     (localhost)                                                                                        
10.195.0.179:0     id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2   
10.195.0.20:0      id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C     
10.195.0.101:0     id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0   
10.195.0.168:0     id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B   
172.31.233.189:0   (localhost)                                                                                        
