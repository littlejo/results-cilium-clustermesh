1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d4:fb:85:59:b1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.211.96/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3586sec preferred_lft 3586sec
    inet6 fe80::8d4:fbff:fe85:59b1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3a:bf:11:70:75 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.233.189/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:bfff:fe11:7075/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:65:91:e0:c8:78 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c65:91ff:fee0:c878/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:19:be:8a:ed:91 brd ff:ff:ff:ff:ff:ff
    inet 10.195.0.203/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::3019:beff:fe8a:ed91/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:94:56:68:e2:18 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c894:56ff:fe68:e218/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:25:f9:80:a6:4c brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f425:f9ff:fe80:a64c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc649889a0c928@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:ba:cd:c6:aa:e0 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::34ba:cdff:fec6:aae0/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc145c8690b57b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:db:97:d7:e0:1b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::8db:97ff:fed7:e01b/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc83dcbe226c9c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:e1:7d:c8:65:c2 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2ce1:7dff:fec8:65c2/64 scope link 
       valid_lft forever preferred_lft forever
