Endpoint ID: 67
Path: /sys/fs/bpf/tc/globals/cilium_policy_00067

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 440
Path: /sys/fs/bpf/tc/globals/cilium_policy_00440

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1650694   20873     0        
Allow    Ingress     1          ANY          NONE         disabled    17496     204       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 851
Path: /sys/fs/bpf/tc/globals/cilium_policy_00851

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    117694   1347      0        
Allow    Egress      0          ANY          NONE         disabled    16511    179       0        


Endpoint ID: 2005
Path: /sys/fs/bpf/tc/globals/cilium_policy_02005

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118024   1352      0        
Allow    Egress      0          ANY          NONE         disabled    16299    177       0        


Endpoint ID: 3236
Path: /sys/fs/bpf/tc/globals/cilium_policy_03236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11305288   110864    0        
Allow    Ingress     1          ANY          NONE         disabled    9198668    96036     0        
Allow    Egress      0          ANY          NONE         disabled    11122502   110538    0        


