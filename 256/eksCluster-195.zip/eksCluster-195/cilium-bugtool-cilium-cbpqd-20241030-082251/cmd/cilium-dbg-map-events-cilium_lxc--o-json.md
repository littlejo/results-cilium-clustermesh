{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.254Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.211.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.254Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.233.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:41.254Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:46.037Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:46.043Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:46.101Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:46.118Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.310Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.310Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.311Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.341Z",
  "value": "id=1238  sec_id=6430652 flags=0x0000 ifindex=16  mac=DA:3A:11:FA:FE:D2 nodemac=82:D5:3C:0B:DB:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:25.309Z",
  "value": "id=1238  sec_id=6430652 flags=0x0000 ifindex=16  mac=DA:3A:11:FA:FE:D2 nodemac=82:D5:3C:0B:DB:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:25.310Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:25.310Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:25.310Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.428Z",
  "value": "id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.195.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.839Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.265Z",
  "value": "id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.268Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.269Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.269Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.265Z",
  "value": "id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.267Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.267Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.268Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.265Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.265Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.266Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.266Z",
  "value": "id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.20:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.266Z",
  "value": "id=440   sec_id=4     flags=0x0000 ifindex=10  mac=96:15:B5:EC:B2:F0 nodemac=F6:25:F9:80:A6:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.101:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.266Z",
  "value": "id=2005  sec_id=6452110 flags=0x0000 ifindex=12  mac=62:5B:05:8A:97:73 nodemac=36:BA:CD:C6:AA:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.168:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.266Z",
  "value": "id=851   sec_id=6452110 flags=0x0000 ifindex=14  mac=36:DB:2E:CE:35:FC nodemac=0A:DB:97:D7:E0:1B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.195.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:02.267Z",
  "value": "id=3236  sec_id=6430652 flags=0x0000 ifindex=18  mac=36:3F:EE:98:DF:80 nodemac=2E:E1:7D:C8:65:C2"
}

