alloc: 111.99MB (117426792 bytes)
total-alloc: 2.15GB (2307258264 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 61846456
frees: 60995428
heap-alloc: 111.99MB (117426792 bytes)
heap-sys: 243.77MB (255606784 bytes)
heap-idle: 77.27MB (81027072 bytes)
heap-in-use: 166.49MB (174579712 bytes)
heap-released: 0 bytes
heap-objects: 851028
stack-in-use: 64.19MB (67305472 bytes)
stack-sys: 64.19MB (67305472 bytes)
stack-mspan-inuse: 2.80MB (2936640 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 961.38KB (984457 bytes)
gc-sys: 6.04MB (6334024 bytes)
next-gc: when heap-alloc >= 216.78MB (227308680 bytes)
last-gc: 2024-10-30 08:23:17.35835116 +0000 UTC
gc-pause-total: 8.865522ms
gc-pause: 85679
gc-pause-end: 1730276597358351160
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004100063688384588
enable-gc: true
debug-gc: false
