ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.197.56:443 (active)    
                                         2 => 172.31.162.47:443 (active)    
2    10.100.254.201:443   ClusterIP      1 => 172.31.211.96:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.195.0.168:53 (active)      
                                         2 => 10.195.0.101:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.195.0.168:9153 (active)    
                                         2 => 10.195.0.101:9153 (active)    
5    10.100.67.218:2379   ClusterIP      1 => 10.195.0.179:2379 (active)    
