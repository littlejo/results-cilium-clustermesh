markdown output at /tmp/cilium-bugtool-20241030-082253.22+0000-UTC-1334199131/cmd/cilium-debuginfo-20241030-082323.918+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.22+0000-UTC-1334199131/cmd/cilium-debuginfo-20241030-082323.918+0000-UTC.json
