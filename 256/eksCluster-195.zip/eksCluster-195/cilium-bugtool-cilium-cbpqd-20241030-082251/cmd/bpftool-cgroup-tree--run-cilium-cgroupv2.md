CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeff3406_fc9e_4cc1_a887_d14e2792611b.slice/cri-containerd-67c9e8f7e42f6eda71b088d4f06c9f617e8afd16ee3d3b01c65f4efb17bf2981.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbeff3406_fc9e_4cc1_a887_d14e2792611b.slice/cri-containerd-18a8d325e7eecc6038f469da648ac78c9b496c2732eb20ab4f37055de24fd2cf.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e46b69_809c_4d16_9efb_0f7a01ab2de9.slice/cri-containerd-610e04ae8e90f1a069ec8de2dd82a4a46573995b9d58c472bfb354e2a0c2514f.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7e46b69_809c_4d16_9efb_0f7a01ab2de9.slice/cri-containerd-dc626749ea8ac11ea9d2ec8c8ac754fa50fd82e426f8fbc9a52d484d154d2857.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4024c314_fd97_4991_bb38_b2574ba951f0.slice/cri-containerd-1925661a2e186a4d4735731976ee195f9015f39d58f9a8efc33e88ae8a7c78cd.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4024c314_fd97_4991_bb38_b2574ba951f0.slice/cri-containerd-e1d724c15341e4fc0187ed973b670e6a45d1a211d1030a40595b2de6eb97b67d.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbd728dab_1ada_4e6f_8a1a_0ed80a58ffc2.slice/cri-containerd-ca36793a68a2e696a3b00182f05b76cb9ef9627d4cf46b5eb4f163f47d08821d.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbd728dab_1ada_4e6f_8a1a_0ed80a58ffc2.slice/cri-containerd-3d69ec1de7b8a3e7a98a085a26d77b8528c47b22cb371a8f5b21dae58ff7083b.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80d3cd60_6556_4200_a704_03c2b966b889.slice/cri-containerd-404dff95ea6110a8bc832709e3bb3ad682df9697044cba14a7066c202f8d974a.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod80d3cd60_6556_4200_a704_03c2b966b889.slice/cri-containerd-1786ffba4e758b99b8c97aa044ca600be4afd86953f3075e57c5fd21ece180b6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod134a7d59_d2a8_4352_bf66_7b8d50746bc7.slice/cri-containerd-710688371ca918c5142ec35428148dec1d03e9098e197c93722e8f812ef83d3e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod134a7d59_d2a8_4352_bf66_7b8d50746bc7.slice/cri-containerd-095ac0388c66ee4fe8449327df008cb2895c99de3702f8d18863fba9450f42c5.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-98d5464f8622133bee0f1ed50d814a83afd147cdd8101f71e1bb8b55a346c91b.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-3c4c688208d168393c5857d0560c6f7384cab5380660ea5d1607be04afe4a666.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-b59c079953e446b46327e2a78add3a4c2eb79fa21b441b17fbd52d19a98a1899.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf7d53391_9cde_48eb_a9e4_33a0eba34157.slice/cri-containerd-1c45fdd464a130532f2b3316397743c772c43ebf1ec2c650368ebb08c5a3d0d7.scope
    673      cgroup_device   multi                                          
