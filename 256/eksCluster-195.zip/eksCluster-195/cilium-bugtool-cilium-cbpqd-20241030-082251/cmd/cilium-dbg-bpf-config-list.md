KEY             VALUE
AgentLiveness   1855813487497
UTimeOffset     3379442867187500
