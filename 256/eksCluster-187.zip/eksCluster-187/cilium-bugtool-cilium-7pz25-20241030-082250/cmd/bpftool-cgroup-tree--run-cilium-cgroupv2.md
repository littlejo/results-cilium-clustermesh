CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda325fd43_b2a0_4f66_b6e4_41c75a68656a.slice/cri-containerd-894798f8bfc612f89faa3872ba5783dfef758496e171a2ca4abfa33228b034ae.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda325fd43_b2a0_4f66_b6e4_41c75a68656a.slice/cri-containerd-ac05fe592d9e8ceae6ac05f0ad6c636125bbd366fdd960d15968fd733c9b614c.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad9827aa_67e8_4ad0_b434_a82396b59768.slice/cri-containerd-178bec73d610fa07a5ab7b9e3eafc757dc6c462803999a8ebf58a724cc717cea.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podad9827aa_67e8_4ad0_b434_a82396b59768.slice/cri-containerd-68c14649ca0862c514fbe46724897eab13f06bf4456ce549d455bc0283cbc631.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa187b80_f7d3_42d1_9027_097b2ee8d570.slice/cri-containerd-43d037399633d8e494b34565c05aced5bbbabcef3aa00f450f216e0982a65c91.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa187b80_f7d3_42d1_9027_097b2ee8d570.slice/cri-containerd-1b7ff270d2c5135d51a7738806fd341dac5b51973d7082ab47f52578e8d6f226.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ff55ec4_cc22_4b8f_aaae_8ef159c0a78e.slice/cri-containerd-423e6109b99ce3f8c790053ba1d075e81d04ab5244a66b5ab28bb2ef1fea5292.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4ff55ec4_cc22_4b8f_aaae_8ef159c0a78e.slice/cri-containerd-b795587c030e1a89120c635d1e3a2160c2bba3ba61255e678c01167d65b620bb.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67fb5899_ec9e_4a88_bc80_fa7dc557d2cb.slice/cri-containerd-acb840d98f80c59c117205376c46c78f59895031413638c8be56e42d9ba8320c.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod67fb5899_ec9e_4a88_bc80_fa7dc557d2cb.slice/cri-containerd-6334d777deaa880a08e2a034d2281ea5b558a5a25be3552e37abba5c863b4a9b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62a93809_e321_4bc3_87ce_6f162652d193.slice/cri-containerd-5949956bc9f7248d2a1ca3755cd911028cd4b339879f680b81fea3bce992222c.scope
    125      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod62a93809_e321_4bc3_87ce_6f162652d193.slice/cri-containerd-8f0fa5647d05c5a223b5f9c04232f795dafd02669d52ea177fc5ce406afc1867.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-a0c3e61e0843d10f1af74683c94a40c9b450e7b7e465b51fb9321da4e5982dd0.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-215b0acf6e2af320872e6ae22b8e34ef1d6255e6ffaeb7aa53e20dcf882e4987.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-6a579c35f2805042c1b391903b7a4cca5d2d88d22805a55b47abadbc33cca658.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-a4f58f8fb6c0f793fd0b066db70c5be00b06d4a7ae680fcaaf15229a39b287fd.scope
    650      cgroup_device   multi                                          
