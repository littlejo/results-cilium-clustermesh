xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 503
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 556
lxc22bad75ceb2a(12) clsact/ingress cil_from_container-lxc22bad75ceb2a id 515
lxc42c26851d6d6(14) clsact/ingress cil_from_container-lxc42c26851d6d6 id 550
lxc3e90ac09c3e8(18) clsact/ingress cil_from_container-lxc3e90ac09c3e8 id 617

flow_dissector:

netfilter:

