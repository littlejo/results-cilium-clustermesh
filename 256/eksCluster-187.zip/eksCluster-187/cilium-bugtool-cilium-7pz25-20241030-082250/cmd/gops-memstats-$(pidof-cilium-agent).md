alloc: 197.93MB (207544744 bytes)
total-alloc: 2.29GB (2462934080 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 63678113
frees: 61542254
heap-alloc: 197.93MB (207544744 bytes)
heap-sys: 248.89MB (260980736 bytes)
heap-idle: 26.48MB (27770880 bytes)
heap-in-use: 222.41MB (233209856 bytes)
heap-released: 2.00MB (2097152 bytes)
heap-objects: 2135859
stack-in-use: 67.06MB (70320128 bytes)
stack-sys: 67.06MB (70320128 bytes)
stack-mspan-inuse: 3.61MB (3780800 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.15MB (1210697 bytes)
gc-sys: 6.02MB (6307280 bytes)
next-gc: when heap-alloc >= 227.37MB (238413592 bytes)
last-gc: 2024-10-30 08:22:51.837563912 +0000 UTC
gc-pause-total: 20.923807ms
gc-pause: 10835530
gc-pause-end: 1730276571837563912
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005567861639798574
enable-gc: true
debug-gc: false
