 08:22:51 up 29 min,  0 users,  load average: 1.46, 0.42, 0.22
