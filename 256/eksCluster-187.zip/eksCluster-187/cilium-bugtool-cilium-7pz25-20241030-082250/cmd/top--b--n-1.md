top - 08:22:51 up 29 min,  0 users,  load average: 1.46, 0.42, 0.22
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 53.3 us, 23.3 sy,  0.0 ni, 23.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4467.5 free,   1200.1 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 407176  77880 R  93.3   5.1   0:38.04 cilium-+
    651 root      20   0 1240432  16768  11356 S   6.7   0.2   0:00.03 cilium-+
    394 root      20   0 1229744   8000   3900 S   0.0   0.1   0:00.97 cilium-+
    611 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    617 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    618 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    623 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1229000   4164   3456 S   0.0   0.1   0:00.00 gops
    693 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    711 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
