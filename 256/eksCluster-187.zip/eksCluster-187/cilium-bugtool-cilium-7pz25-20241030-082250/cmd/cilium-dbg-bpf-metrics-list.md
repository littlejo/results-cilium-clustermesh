REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35371     2798322     677    bpf_overlay.c
Interface                 INGRESS     628959    130169167   1132   bpf_host.c
Success                   EGRESS      15227     1195008     1694   bpf_host.c
Success                   EGRESS      272359    34917671    1308   bpf_lxc.c
Success                   EGRESS      34779     2755190     53     encap.h
Success                   INGRESS     312235    35357919    86     l3.h
Success                   INGRESS     333030    37005279    235    trace.h
Unsupported L3 protocol   EGRESS      42        3136        1492   bpf_lxc.c
