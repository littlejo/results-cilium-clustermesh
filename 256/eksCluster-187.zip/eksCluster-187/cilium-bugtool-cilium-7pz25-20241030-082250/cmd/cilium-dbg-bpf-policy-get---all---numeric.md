Endpoint ID: 239
Path: /sys/fs/bpf/tc/globals/cilium_policy_00239

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 922
Path: /sys/fs/bpf/tc/globals/cilium_policy_00922

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115558   1329      0        
Allow    Egress      0          ANY          NONE         disabled    16537    179       0        


Endpoint ID: 1626
Path: /sys/fs/bpf/tc/globals/cilium_policy_01626

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11282899   110027    0        
Allow    Ingress     1          ANY          NONE         disabled    9952932    100501    0        
Allow    Egress      0          ANY          NONE         disabled    10608579   105952    0        


Endpoint ID: 2899
Path: /sys/fs/bpf/tc/globals/cilium_policy_02899

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1651859   20849     0        
Allow    Ingress     1          ANY          NONE         disabled    18336     216       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3932
Path: /sys/fs/bpf/tc/globals/cilium_policy_03932

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115201   1320      0        
Allow    Egress      0          ANY          NONE         disabled    16529    177       0        


