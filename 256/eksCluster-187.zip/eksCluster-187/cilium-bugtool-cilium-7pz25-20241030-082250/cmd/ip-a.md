1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:91:ce:74:b5:a3 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.242.2/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1836sec preferred_lft 1836sec
    inet6 fe80::891:ceff:fe74:b5a3/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e9:7d:af:2f:07 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.234.255/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8e9:7dff:feaf:2f07/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:29:ec:71:90:d5 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a029:ecff:fe71:90d5/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:d7:7b:06:7b:49 brd ff:ff:ff:ff:ff:ff
    inet 10.187.0.76/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::40d7:7bff:fe06:7b49/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:6f:3f:cb:86:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::946f:3fff:fecb:86f1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:c5:27:e4:0c:bf brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::c4c5:27ff:fee4:cbf/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc22bad75ceb2a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:27:1c:2c:0d:10 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::1c27:1cff:fe2c:d10/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc42c26851d6d6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:f5:52:68:db:e5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d0f5:52ff:fe68:dbe5/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3e90ac09c3e8@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:e7:83:c8:39:2c brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9ce7:83ff:fec8:392c/64 scope link 
       valid_lft forever preferred_lft forever
