key: 9a 03 00 00  value: 1e 02 00 00
key: 5a 06 00 00  value: 6e 02 00 00
key: 53 0b 00 00  value: 1b 02 00 00
key: 5c 0f 00 00  value: 07 02 00 00
Found 4 elements
