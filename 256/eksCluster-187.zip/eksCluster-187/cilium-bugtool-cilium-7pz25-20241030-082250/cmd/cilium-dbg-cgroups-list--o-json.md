[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-215b0acf6e2af320872e6ae22b8e34ef1d6255e6ffaeb7aa53e20dcf882e4987.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-a0c3e61e0843d10f1af74683c94a40c9b450e7b7e465b51fb9321da4e5982dd0.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9bee2302_b833_4786_90ca_3bb2d9028651.slice/cri-containerd-a4f58f8fb6c0f793fd0b066db70c5be00b06d4a7ae680fcaaf15229a39b287fd.scope"
      }
    ],
    "ips": [
      "10.187.0.61"
    ],
    "name": "clustermesh-apiserver-69794cbdf5-m9fr7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda325fd43_b2a0_4f66_b6e4_41c75a68656a.slice/cri-containerd-ac05fe592d9e8ceae6ac05f0ad6c636125bbd366fdd960d15968fd733c9b614c.scope"
      }
    ],
    "ips": [
      "10.187.0.89"
    ],
    "name": "coredns-cc6ccd49c-gqpfd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa187b80_f7d3_42d1_9027_097b2ee8d570.slice/cri-containerd-43d037399633d8e494b34565c05aced5bbbabcef3aa00f450f216e0982a65c91.scope"
      }
    ],
    "ips": [
      "10.187.0.179"
    ],
    "name": "coredns-cc6ccd49c-vgn9t",
    "namespace": "kube-system"
  }
]

