filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3e90ac09c3e8 direct-action not_in_hw id 617 tag cd1c215b3b409075 jited 
