KEY             VALUE
AgentLiveness   1805265494602
UTimeOffset     3379442962890625
