ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.164.6:443 (active)     
                                         2 => 172.31.209.163:443 (active)   
2    10.100.66.243:443    ClusterIP      1 => 172.31.242.2:4244 (active)    
3    10.100.0.10:53       ClusterIP      1 => 10.187.0.179:53 (active)      
                                         2 => 10.187.0.89:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.187.0.179:9153 (active)    
                                         2 => 10.187.0.89:9153 (active)     
5    10.100.252.93:2379   ClusterIP      1 => 10.187.0.61:2379 (active)     
