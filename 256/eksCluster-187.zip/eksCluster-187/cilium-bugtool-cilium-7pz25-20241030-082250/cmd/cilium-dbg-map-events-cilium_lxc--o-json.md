{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:08.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:08.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.242.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:08.705Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.987Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.987Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:12.989Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.036Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.043Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:43.978Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:43.979Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:43.979Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:44.006Z",
  "value": "id=843   sec_id=6172518 flags=0x0000 ifindex=16  mac=66:79:3F:DB:B0:F7 nodemac=FE:4C:58:0E:DF:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:44.979Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:44.979Z",
  "value": "id=843   sec_id=6172518 flags=0x0000 ifindex=16  mac=66:79:3F:DB:B0:F7 nodemac=FE:4C:58:0E:DF:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:44.979Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:44.979Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.482Z",
  "value": "id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.187.0.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.399Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.369Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.370Z",
  "value": "id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.370Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.371Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.365Z",
  "value": "id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.366Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.367Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.367Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.366Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.366Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.367Z",
  "value": "id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.367Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.367Z",
  "value": "id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.367Z",
  "value": "id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.367Z",
  "value": "id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.187.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.367Z",
  "value": "id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10"
}

