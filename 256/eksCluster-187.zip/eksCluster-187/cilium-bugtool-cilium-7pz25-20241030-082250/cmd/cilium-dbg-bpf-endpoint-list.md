IP ADDRESS         LOCAL ENDPOINT INFO
172.31.242.2:0     (localhost)                                                                                        
10.187.0.232:0     id=2899  sec_id=4     flags=0x0000 ifindex=10  mac=6A:04:46:85:DC:3B nodemac=C6:C5:27:E4:0C:BF     
10.187.0.89:0      id=922   sec_id=6173651 flags=0x0000 ifindex=14  mac=6E:14:1C:A7:2C:4F nodemac=D2:F5:52:68:DB:E5   
172.31.234.255:0   (localhost)                                                                                        
10.187.0.76:0      (localhost)                                                                                        
10.187.0.179:0     id=3932  sec_id=6173651 flags=0x0000 ifindex=12  mac=B2:22:E7:59:4B:F8 nodemac=1E:27:1C:2C:0D:10   
10.187.0.61:0      id=1626  sec_id=6172518 flags=0x0000 ifindex=18  mac=EE:97:12:E7:E8:33 nodemac=9E:E7:83:C8:39:2C   
