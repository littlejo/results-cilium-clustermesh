Endpoint ID: 82
Path: /sys/fs/bpf/tc/globals/cilium_policy_00082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 516
Path: /sys/fs/bpf/tc/globals/cilium_policy_00516

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1664098   20999     0        
Allow    Ingress     1          ANY          NONE         disabled    23068     270       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 986
Path: /sys/fs/bpf/tc/globals/cilium_policy_00986

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11480676   113381    0        
Allow    Ingress     1          ANY          NONE         disabled    9752269    102239    0        
Allow    Egress      0          ANY          NONE         disabled    12010711   119104    0        


Endpoint ID: 1542
Path: /sys/fs/bpf/tc/globals/cilium_policy_01542

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150521   1727      0        
Allow    Egress      0          ANY          NONE         disabled    18910    209       0        


Endpoint ID: 1604
Path: /sys/fs/bpf/tc/globals/cilium_policy_01604

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150474   1731      0        
Allow    Egress      0          ANY          NONE         disabled    19733    219       0        


