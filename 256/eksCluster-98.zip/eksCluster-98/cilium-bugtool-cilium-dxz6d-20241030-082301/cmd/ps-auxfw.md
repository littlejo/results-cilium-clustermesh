USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         681  0.0  0.1 1616264 8872 ?        Ssl  08:23   0:00 /usr/sbin/runc init
root         667  0.0  0.1 1240432 15944 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         687  0.0  0.0   6408  1648 ?        R    08:23   0:00  \_ ps auxfw
root         688  0.0  0.1 1240432 15944 ?       R    08:23   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         657  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops stats 1
root         625  0.0  0.0 1228744 3776 ?        Ssl  08:23   0:00 /bin/gops memstats 1
root         623  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         619  0.0  0.0 1228744 4044 ?        Ssl  08:23   0:00 /bin/gops pprof-heap 1
root         613  0.0  0.0 1228744 3660 ?        Ssl  08:23   0:00 /bin/gops stack 1
root           1  3.2  4.8 1606336 389892 ?      Ssl  07:56   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229744 7828 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
