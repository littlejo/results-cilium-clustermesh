ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.231.147:443 (active)    
                                        2 => 172.31.134.175:443 (active)    
2    10.100.229.29:443   ClusterIP      1 => 172.31.139.133:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.98.0.81:53 (active)         
                                        2 => 10.98.0.241:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.98.0.81:9153 (active)       
                                        2 => 10.98.0.241:9153 (active)      
5    10.100.21.72:2379   ClusterIP      1 => 10.98.0.3:2379 (active)        
