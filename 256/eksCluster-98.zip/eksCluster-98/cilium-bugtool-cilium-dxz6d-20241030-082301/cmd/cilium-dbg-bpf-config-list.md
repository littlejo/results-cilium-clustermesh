KEY             VALUE
AgentLiveness   2091993471426
UTimeOffset     3379442425781250
