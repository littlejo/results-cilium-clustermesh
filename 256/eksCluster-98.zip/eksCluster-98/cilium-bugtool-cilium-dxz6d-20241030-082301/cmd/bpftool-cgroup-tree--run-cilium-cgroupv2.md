CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ccb7f5c_6f6c_400f_9a67_037b732c49d1.slice/cri-containerd-e7d46521c5309e5e1f22168d2cbc6c4eed4e0e8f6943057329c11e36d1cf9265.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ccb7f5c_6f6c_400f_9a67_037b732c49d1.slice/cri-containerd-239c311692083b4c07c3ae25c820ac8feaeede864a8cbe817fab11e7c66c51f2.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7086543_4ae8_4498_8a28_2f03e5c6f650.slice/cri-containerd-ddcd2fa45bb451e5a204f2103c04554adda15424e469d924d0dbf32b402ca140.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7086543_4ae8_4498_8a28_2f03e5c6f650.slice/cri-containerd-009ef957177d459992304d46d476cd69562d34605960e52a1eabcc567ea60228.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaac91d2_eeda_44bf_85fd_bdf1625615df.slice/cri-containerd-04d020230a9c2cd769f6f3e190c7a0ccab0f86ff32c095fcfe998da2602063de.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbaac91d2_eeda_44bf_85fd_bdf1625615df.slice/cri-containerd-1d06ae0603bf6f32510ceecd5a717d9d025dab4cdd4a010062b7bcf5e57fcd08.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46fcafc6_812f_43e3_aa8b_f374396ce84f.slice/cri-containerd-2b5c166bda7f063fc60dc4271499f8b9517145f2b7bf1e53c3fc496133f57f5f.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46fcafc6_812f_43e3_aa8b_f374396ce84f.slice/cri-containerd-6cb10ec1113e3578563f76cb5c1cc9e6af1f5384d34bb26f682d7813915f9aa8.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod174e4491_ea1a_4f5e_b531_33defbe20b70.slice/cri-containerd-ad752dcabae6b26de33bb7ccfe2db48c2b00f2303b22cb93aa9ddd0dfd750244.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod174e4491_ea1a_4f5e_b531_33defbe20b70.slice/cri-containerd-f1cd0a8a3b6393d287f2b747f27ea61f47be7cd805e849bbc2451091ffd52ab0.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda368d45c_c0e0_4726_bfae_1a53fadb1d7d.slice/cri-containerd-0600093aafe77aa851abdb931bd39d88adbf85dd289cde2c6272ddaba3b6a45b.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda368d45c_c0e0_4726_bfae_1a53fadb1d7d.slice/cri-containerd-38cc394aaf685428c201c9c3d630b0880552c0fb252ec8e4f17379e85cacab6a.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-905e5faa4582b0f5fd9cc41f8bf45243ab59b9dcba4a4e2857f0a066e6764984.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-1064d3b323cf142aa106988e45329e908096462a5b83b4c8e536d8fe5a5ac80b.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-4a8bc65f8584fe1431b32c5e591bc668f6005b68aa1ef5a95d5b112c8a0d00c3.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-8bd4bcf63bfa6e7f6d887f540c338bd2c0634c31c6064e01150d920496f8277f.scope
    629      cgroup_device   multi                                          
