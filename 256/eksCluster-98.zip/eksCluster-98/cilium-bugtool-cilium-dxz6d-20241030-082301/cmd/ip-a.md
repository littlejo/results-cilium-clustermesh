1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:31:66:82:68:bb brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.139.133/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3350sec preferred_lft 3350sec
    inet6 fe80::431:66ff:fe82:68bb/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:90:24:2e:d6:cb brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.253/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::490:24ff:fe2e:d6cb/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:3d:bc:51:31:32 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::143d:bcff:fe51:3132/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:d2:a3:ab:2d:de brd ff:ff:ff:ff:ff:ff
    inet 10.98.0.68/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4cd2:a3ff:feab:2dde/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 12:96:76:c0:1c:a7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1096:76ff:fec0:1ca7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:fb:64:87:7b:2b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f4fb:64ff:fe87:7b2b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcfe6fefd3e431@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:ca:2c:dd:26:8b brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::3cca:2cff:fedd:268b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxccea09450313a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2a:4b:03:b8:0a:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::284b:3ff:feb8:af5/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb9b12cf1e9a3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:4e:95:de:24:94 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::784e:95ff:fede:2494/64 scope link 
       valid_lft forever preferred_lft forever
