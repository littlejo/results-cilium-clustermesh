filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxccea09450313a direct-action not_in_hw id 540 tag 0821482ee815a7c5 jited 
