key: 04 02 00 00  value: 22 02 00 00
key: da 03 00 00  value: 6b 02 00 00
key: 06 06 00 00  value: 29 02 00 00
key: 44 06 00 00  value: 12 02 00 00
Found 4 elements
