{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:05.434Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.139.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:05.434Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:05.434Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.249Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.260Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.263Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.311Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:10.320Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.962Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.963Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.963Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.996Z",
  "value": "id=3010  sec_id=3251172 flags=0x0000 ifindex=16  mac=46:AD:76:BE:95:EA nodemac=D6:26:91:75:52:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.961Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.962Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.962Z",
  "value": "id=3010  sec_id=3251172 flags=0x0000 ifindex=16  mac=46:AD:76:BE:95:EA nodemac=D6:26:91:75:52:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.962Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:41.305Z",
  "value": "id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.98.0.112:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.693Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.948Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.948Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.949Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.949Z",
  "value": "id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.963Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.986Z",
  "value": "id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.988Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.990Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.954Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.954Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.954Z",
  "value": "id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.955Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.954Z",
  "value": "id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.241:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.954Z",
  "value": "id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.3:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.954Z",
  "value": "id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.98.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.955Z",
  "value": "id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B"
}

