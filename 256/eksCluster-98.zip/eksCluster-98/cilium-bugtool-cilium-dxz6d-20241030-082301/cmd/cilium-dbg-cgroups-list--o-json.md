[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-4a8bc65f8584fe1431b32c5e591bc668f6005b68aa1ef5a95d5b112c8a0d00c3.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-905e5faa4582b0f5fd9cc41f8bf45243ab59b9dcba4a4e2857f0a066e6764984.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb64f11d4_97ef_4500_a204_eb2acac0ecf8.slice/cri-containerd-1064d3b323cf142aa106988e45329e908096462a5b83b4c8e536d8fe5a5ac80b.scope"
      }
    ],
    "ips": [
      "10.98.0.3"
    ],
    "name": "clustermesh-apiserver-6b574588fd-m99w4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46fcafc6_812f_43e3_aa8b_f374396ce84f.slice/cri-containerd-2b5c166bda7f063fc60dc4271499f8b9517145f2b7bf1e53c3fc496133f57f5f.scope"
      }
    ],
    "ips": [
      "10.98.0.81"
    ],
    "name": "coredns-cc6ccd49c-td8x7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2ccb7f5c_6f6c_400f_9a67_037b732c49d1.slice/cri-containerd-239c311692083b4c07c3ae25c820ac8feaeede864a8cbe817fab11e7c66c51f2.scope"
      }
    ],
    "ips": [
      "10.98.0.241"
    ],
    "name": "coredns-cc6ccd49c-fmjmf",
    "namespace": "kube-system"
  }
]

