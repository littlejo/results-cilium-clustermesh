alloc: 131.98MB (138394568 bytes)
total-alloc: 2.26GB (2421389584 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 63460674
frees: 62266854
heap-alloc: 131.98MB (138394568 bytes)
heap-sys: 255.73MB (268156928 bytes)
heap-idle: 82.69MB (86704128 bytes)
heap-in-use: 173.05MB (181452800 bytes)
heap-released: 12.57MB (13180928 bytes)
heap-objects: 1193820
stack-in-use: 64.22MB (67338240 bytes)
stack-sys: 64.22MB (67338240 bytes)
stack-mspan-inuse: 2.88MB (3021920 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1269801 bytes)
gc-sys: 6.02MB (6311400 bytes)
next-gc: when heap-alloc >= 213.17MB (223525992 bytes)
last-gc: 2024-10-30 08:23:13.604234234 +0000 UTC
gc-pause-total: 12.867589ms
gc-pause: 89520
gc-pause-end: 1730276593604234234
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00039474149962215603
enable-gc: true
debug-gc: false
