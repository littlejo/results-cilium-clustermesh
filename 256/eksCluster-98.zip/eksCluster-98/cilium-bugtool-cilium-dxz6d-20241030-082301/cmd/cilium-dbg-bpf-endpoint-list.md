IP ADDRESS         LOCAL ENDPOINT INFO
10.98.0.149:0      id=516   sec_id=4     flags=0x0000 ifindex=10  mac=4A:62:6B:FE:5A:44 nodemac=F6:FB:64:87:7B:2B     
10.98.0.68:0       (localhost)                                                                                        
10.98.0.81:0       id=1604  sec_id=3253370 flags=0x0000 ifindex=12  mac=06:39:30:B3:71:CD nodemac=3E:CA:2C:DD:26:8B   
172.31.139.133:0   (localhost)                                                                                        
10.98.0.3:0        id=986   sec_id=3251172 flags=0x0000 ifindex=18  mac=A6:8A:2B:1F:55:C5 nodemac=7A:4E:95:DE:24:94   
172.31.174.253:0   (localhost)                                                                                        
10.98.0.241:0      id=1542  sec_id=3253370 flags=0x0000 ifindex=14  mac=A2:7D:DC:47:5C:3B nodemac=2A:4B:03:B8:0A:F5   
