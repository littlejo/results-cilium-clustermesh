REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35601     2816102     677    bpf_overlay.c
Interface                 INGRESS     637262    131507067   1132   bpf_host.c
Success                   EGRESS      15303     1200072     1694   bpf_host.c
Success                   EGRESS      268507    33760394    1308   bpf_lxc.c
Success                   EGRESS      35048     2775985     53     encap.h
Success                   INGRESS     309669    34825333    86     l3.h
Success                   INGRESS     330618    36485409    235    trace.h
Unsupported L3 protocol   EGRESS      39        2886        1492   bpf_lxc.c
