1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:d2:79:0f:44:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.235.129/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3298sec preferred_lft 3298sec
    inet6 fe80::8d2:79ff:fe0f:44ad/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2d:69:4d:f9:51 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.209.111/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::82d:69ff:fe4d:f951/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:f6:63:74:01:5f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cf6:63ff:fe74:15f/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:b6:37:c5:ed:f6 brd ff:ff:ff:ff:ff:ff
    inet 10.53.0.2/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e0b6:37ff:fec5:edf6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:3f:55:f8:63:d2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6c3f:55ff:fef8:63d2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:44:8a:cf:58:32 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b444:8aff:fecf:5832/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8910be62ce19@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:30:f0:ee:81:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::430:f0ff:feee:81b2/64 scope link 
       valid_lft forever preferred_lft forever
14: lxca90059d9f7d6@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c6:6c:06:78:34:43 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::c46c:6ff:fe78:3443/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc9a07bc21db22@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:51:d0:86:45:43 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f851:d0ff:fe86:4543/64 scope link 
       valid_lft forever preferred_lft forever
