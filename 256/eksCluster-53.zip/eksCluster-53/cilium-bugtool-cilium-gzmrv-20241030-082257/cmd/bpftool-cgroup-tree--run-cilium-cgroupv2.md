CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e48d95_2966_456b_9de3_36b3e92e6341.slice/cri-containerd-a3493b0a323f27e869086645c80a8c13070af89fe7adf40ddec3ef93e88a18a0.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e48d95_2966_456b_9de3_36b3e92e6341.slice/cri-containerd-cf8a343809ae1f727c101e7f7ee48a59d23f6166fdfd54f5e673343602b86055.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda994faca_58c9_4f3c_9600_434e4c2ad4e0.slice/cri-containerd-5f3ef35172ebac799a5a38258767c0ae76106e999357d7851e5e52cbef3d5830.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda994faca_58c9_4f3c_9600_434e4c2ad4e0.slice/cri-containerd-f09b3d90fd558ebd44bafecda34c670603ac81d2e1b6bcf283ad74aef185a566.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5583cb31_5dce_4f1c_85fb_2c33f822fc33.slice/cri-containerd-90bab4e406bba38b9cd47340a54f29b6a8f31229e84c817b235112997f05677d.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5583cb31_5dce_4f1c_85fb_2c33f822fc33.slice/cri-containerd-c3809af9e2c401269bf3ebd6b5fd31d51a4b87ec18e1bc40b43818220fb687c5.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf9e5fad_dfee_4a67_acec_acfc2b7c8631.slice/cri-containerd-7b476655d569a5414dacf0ab3c9fdcb7736852b14ff5ee0bd99a7602fbd14e4b.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf9e5fad_dfee_4a67_acec_acfc2b7c8631.slice/cri-containerd-21dfa8fde0c12e7bbd34f0dcbc6189ed133442dddb2f1464d9ababa1dfb7199d.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-ff9317cb02bdfd5ba6ff978aee6b808c5c5da6cb21fb1198e3d9316733c3ac43.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-315ec7e0babaa06ee7b943073176c569b1cdef7068ed0a29acf12eb0fc7bf3dc.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-fc0f92c26d13ba4510441eb34672bb82080639ee097ae3acd424a9665a430bc9.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-80ac8432c85739b616862b2811eb1f368da982040948cd5d420bc9bbee5cb064.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e07da0b_7042_448a_9b9a_beb923f5cd2b.slice/cri-containerd-0b77accaecaa7ec254535b5b59713d28d2a482174c036cac6895d625e34aab0c.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e07da0b_7042_448a_9b9a_beb923f5cd2b.slice/cri-containerd-fdc1c2e63c89a8f0a19e3ff7ccbee2542391eaf633128966fb3e113162ab3f86.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a36fdb_de18_49be_a26f_c6ea1d0a72b0.slice/cri-containerd-2aec216fd240bbc5c26fdead3cd80dfd7f3e599d7efd340e3a02d3eb0a6b788c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda5a36fdb_de18_49be_a26f_c6ea1d0a72b0.slice/cri-containerd-918f9020a0bf62cd486071de5b3fa9f2c8c5cdfc94548fb7e7ff121b1e3a54c2.scope
    109      cgroup_device   multi                                          
