IP ADDRESS         LOCAL ENDPOINT INFO
172.31.209.111:0   (localhost)                                                                                        
10.53.0.127:0      id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32     
10.53.0.44:0       id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43   
10.53.0.197:0      id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2   
10.53.0.30:0       id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43   
10.53.0.2:0        (localhost)                                                                                        
172.31.235.129:0   (localhost)                                                                                        
