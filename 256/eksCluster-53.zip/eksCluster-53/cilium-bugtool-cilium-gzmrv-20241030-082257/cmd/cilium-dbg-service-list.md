ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.181.162:443 (active)    
                                          2 => 172.31.252.218:443 (active)    
2    10.100.200.219:443    ClusterIP      1 => 172.31.235.129:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.53.0.44:53 (active)         
                                          2 => 10.53.0.197:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.53.0.44:9153 (active)       
                                          2 => 10.53.0.197:9153 (active)      
5    10.100.153.211:2379   ClusterIP      1 => 10.53.0.30:2379 (active)       
