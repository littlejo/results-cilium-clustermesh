REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34242     2705023     677    bpf_overlay.c
Interface                 INGRESS     613440    128999516   1132   bpf_host.c
Success                   EGRESS      13880     1086997     1694   bpf_host.c
Success                   EGRESS      258405    32900321    1308   bpf_lxc.c
Success                   EGRESS      32933     2610289     53     encap.h
Success                   INGRESS     299312    33533793    86     l3.h
Success                   INGRESS     320325    35195865    235    trace.h
Unsupported L3 protocol   EGRESS      41        3022        1492   bpf_lxc.c
