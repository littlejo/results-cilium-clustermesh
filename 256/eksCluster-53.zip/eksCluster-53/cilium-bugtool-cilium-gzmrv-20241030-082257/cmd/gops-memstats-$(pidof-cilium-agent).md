alloc: 125.25MB (131333448 bytes)
total-alloc: 2.19GB (2346199584 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62234072
frees: 61417520
heap-alloc: 125.25MB (131333448 bytes)
heap-sys: 254.08MB (266420224 bytes)
heap-idle: 70.16MB (73564160 bytes)
heap-in-use: 183.92MB (192856064 bytes)
heap-released: 896.00KB (917504 bytes)
heap-objects: 816552
stack-in-use: 61.88MB (64880640 bytes)
stack-sys: 61.88MB (64880640 bytes)
stack-mspan-inuse: 2.84MB (2980160 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 979.59KB (1003097 bytes)
gc-sys: 6.02MB (6315496 bytes)
next-gc: when heap-alloc >= 214.86MB (225301608 bytes)
last-gc: 2024-10-30 08:23:22.225640743 +0000 UTC
gc-pause-total: 14.918966ms
gc-pause: 124744
gc-pause-end: 1730276602225640743
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003712419540338218
enable-gc: true
debug-gc: false
