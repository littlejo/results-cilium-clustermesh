Endpoint ID: 199
Path: /sys/fs/bpf/tc/globals/cilium_policy_00199

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164451   1890      0        
Allow    Egress      0          ANY          NONE         disabled    21124    234       0        


Endpoint ID: 405
Path: /sys/fs/bpf/tc/globals/cilium_policy_00405

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11293625   110273    0        
Allow    Ingress     1          ANY          NONE         disabled    8989073    93991     0        
Allow    Egress      0          ANY          NONE         disabled    10758798   107446    0        


Endpoint ID: 603
Path: /sys/fs/bpf/tc/globals/cilium_policy_00603

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 688
Path: /sys/fs/bpf/tc/globals/cilium_policy_00688

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    164723   1901      0        
Allow    Egress      0          ANY          NONE         disabled    20927    234       0        


Endpoint ID: 1003
Path: /sys/fs/bpf/tc/globals/cilium_policy_01003

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1663874   21034     0        
Allow    Ingress     1          ANY          NONE         disabled    24014     279       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


