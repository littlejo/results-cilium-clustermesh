KEY             VALUE
AgentLiveness   2145477832697
UTimeOffset     3379442314453125
