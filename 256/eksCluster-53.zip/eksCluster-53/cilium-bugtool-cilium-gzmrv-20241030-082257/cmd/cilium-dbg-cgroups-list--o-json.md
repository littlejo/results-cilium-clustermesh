[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbf9e5fad_dfee_4a67_acec_acfc2b7c8631.slice/cri-containerd-21dfa8fde0c12e7bbd34f0dcbc6189ed133442dddb2f1464d9ababa1dfb7199d.scope"
      }
    ],
    "ips": [
      "10.53.0.44"
    ],
    "name": "coredns-cc6ccd49c-qsk7w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-ff9317cb02bdfd5ba6ff978aee6b808c5c5da6cb21fb1198e3d9316733c3ac43.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-fc0f92c26d13ba4510441eb34672bb82080639ee097ae3acd424a9665a430bc9.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod73af900b_37d8_4389_bcfd_2b4fb1a40bbd.slice/cri-containerd-315ec7e0babaa06ee7b943073176c569b1cdef7068ed0a29acf12eb0fc7bf3dc.scope"
      }
    ],
    "ips": [
      "10.53.0.30"
    ],
    "name": "clustermesh-apiserver-5698dc4979-c9cb4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod78e48d95_2966_456b_9de3_36b3e92e6341.slice/cri-containerd-cf8a343809ae1f727c101e7f7ee48a59d23f6166fdfd54f5e673343602b86055.scope"
      }
    ],
    "ips": [
      "10.53.0.197"
    ],
    "name": "coredns-cc6ccd49c-77smf",
    "namespace": "kube-system"
  }
]

