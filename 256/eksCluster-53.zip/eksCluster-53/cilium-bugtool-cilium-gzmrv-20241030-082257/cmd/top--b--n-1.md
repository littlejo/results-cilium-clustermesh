top - 08:22:59 up 35 min,  0 users,  load average: 0.14, 0.17, 0.14
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 33.3 us, 37.0 sy,  0.0 ni, 22.2 id,  0.0 wa,  0.0 hi,  7.4 si,  0.0 st
MiB Mem :   7814.2 total,   4486.0 free,   1182.3 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6446.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    718 root      20   0 1244340  21396  13860 S  33.3   0.3   0:00.05 hubble
      1 root      20   0 1606080 390696  78648 S  13.3   4.9   0:53.82 cilium-+
    661 root      20   0 1240176  16144  11420 S   6.7   0.2   0:00.03 cilium-+
    393 root      20   0 1229744   8172   3836 S   0.0   0.1   0:01.19 cilium-+
    629 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    630 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    650 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    656 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    697 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    703 root      20   0    2208    784    704 S   0.0   0.0   0:00.00 timeout
    726 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
