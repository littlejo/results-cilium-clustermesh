{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:58.911Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.111:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:58.911Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.235.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:54:58.911Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:03.814Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:03.825Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:03.856Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:03.903Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.618Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.618Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.619Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:19.649Z",
  "value": "id=82    sec_id=1779146 flags=0x0000 ifindex=16  mac=A6:F4:3F:C3:BE:74 nodemac=7E:69:A0:12:DC:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:20.617Z",
  "value": "id=82    sec_id=1779146 flags=0x0000 ifindex=16  mac=A6:F4:3F:C3:BE:74 nodemac=7E:69:A0:12:DC:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:20.617Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:20.617Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:20.618Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:30.428Z",
  "value": "id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.53.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.012Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.351Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.352Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.353Z",
  "value": "id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.354Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.367Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.367Z",
  "value": "id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.368Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.368Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.341Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.341Z",
  "value": "id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.342Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.342Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.342Z",
  "value": "id=688   sec_id=1769515 flags=0x0000 ifindex=14  mac=E2:C4:58:26:6F:98 nodemac=C6:6C:06:78:34:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.343Z",
  "value": "id=405   sec_id=1779146 flags=0x0000 ifindex=18  mac=F6:E5:90:05:90:58 nodemac=FA:51:D0:86:45:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.197:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.343Z",
  "value": "id=199   sec_id=1769515 flags=0x0000 ifindex=12  mac=CE:72:84:6B:79:70 nodemac=06:30:F0:EE:81:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.343Z",
  "value": "id=1003  sec_id=4     flags=0x0000 ifindex=10  mac=AA:C1:74:50:FF:93 nodemac=B6:44:8A:CF:58:32"
}

