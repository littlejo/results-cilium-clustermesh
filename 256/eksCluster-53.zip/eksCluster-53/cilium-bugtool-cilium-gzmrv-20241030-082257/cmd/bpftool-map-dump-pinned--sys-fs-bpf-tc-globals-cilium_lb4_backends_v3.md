key: 02 00 00 00  value: ac 1f fc da 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f eb 81 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 35 00 c5 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b5 a2 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 35 00 2c 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 35 00 2c 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 35 00 1e 09 4b 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 35 00 c5 00 35 00 00  00 00 00 00
Found 8 elements
