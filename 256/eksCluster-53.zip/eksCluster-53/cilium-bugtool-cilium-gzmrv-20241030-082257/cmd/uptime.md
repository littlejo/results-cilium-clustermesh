 08:22:59 up 35 min,  0 users,  load average: 0.14, 0.17, 0.14
