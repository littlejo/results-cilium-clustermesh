KEY             VALUE
AgentLiveness   1855474565400
UTimeOffset     3379442871093750
