Endpoint ID: 504
Path: /sys/fs/bpf/tc/globals/cilium_policy_00504

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 505
Path: /sys/fs/bpf/tc/globals/cilium_policy_00505

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    423162   3808      0        
Allow    Ingress     1          ANY          NONE         disabled    116533   1333      0        
Allow    Egress      0          ANY          NONE         disabled    113698   1090      0        


Endpoint ID: 2086
Path: /sys/fs/bpf/tc/globals/cilium_policy_02086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11560726   115558    0        
Allow    Ingress     1          ANY          NONE         disabled    10068758   106017    0        
Allow    Egress      0          ANY          NONE         disabled    13196185   129778    0        


Endpoint ID: 2974
Path: /sys/fs/bpf/tc/globals/cilium_policy_02974

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    439988   3942      0        
Allow    Ingress     1          ANY          NONE         disabled    115962   1328      0        
Allow    Egress      0          ANY          NONE         disabled    112768   1072      0        


Endpoint ID: 3215
Path: /sys/fs/bpf/tc/globals/cilium_policy_03215

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658268   20931     0        
Allow    Ingress     1          ANY          NONE         disabled    18294     215       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


