{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.157:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:53.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.52:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:53.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.251.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:53.916Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:58.129Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:58.130Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:58.184Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:58.202Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.827Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.828Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.829Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.856Z",
  "value": "id=37    sec_id=6816887 flags=0x0000 ifindex=16  mac=F6:EE:BD:39:2D:89 nodemac=92:3F:32:9C:F4:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.828Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.828Z",
  "value": "id=37    sec_id=6816887 flags=0x0000 ifindex=16  mac=F6:EE:BD:39:2D:89 nodemac=92:3F:32:9C:F4:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.828Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.828Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.315Z",
  "value": "id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.207.0.185:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:00.825Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.188Z",
  "value": "id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.188Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.189Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.189Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.192Z",
  "value": "id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.194Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.194Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:45.195Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.189Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.189Z",
  "value": "id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.189Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:46.189Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.189Z",
  "value": "id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.190Z",
  "value": "id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.71:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.190Z",
  "value": "id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.207.0.114:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:47.190Z",
  "value": "id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F"
}

