key: f9 01 00 00  value: 37 02 00 00
key: 26 08 00 00  value: 85 02 00 00
key: 9e 0b 00 00  value: 07 02 00 00
key: 8f 0c 00 00  value: 35 02 00 00
Found 4 elements
