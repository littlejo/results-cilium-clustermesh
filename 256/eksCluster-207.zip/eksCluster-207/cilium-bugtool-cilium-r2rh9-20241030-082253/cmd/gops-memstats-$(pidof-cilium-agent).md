alloc: 173.92MB (182370856 bytes)
total-alloc: 2.31GB (2481065904 bytes)
sys: 345.09MB (361848180 bytes)
lookups: 0
mallocs: 64469760
frees: 62939352
heap-alloc: 173.92MB (182370856 bytes)
heap-sys: 267.66MB (280666112 bytes)
heap-idle: 59.40MB (62283776 bytes)
heap-in-use: 208.27MB (218382336 bytes)
heap-released: 5.98MB (6266880 bytes)
heap-objects: 1530408
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.04MB (3185920 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1271553 bytes)
gc-sys: 6.06MB (6355400 bytes)
next-gc: when heap-alloc >= 213.37MB (223735528 bytes)
last-gc: 2024-10-30 08:23:00.664438249 +0000 UTC
gc-pause-total: 11.794538ms
gc-pause: 156071
gc-pause-end: 1730276580664438249
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005211363339419513
enable-gc: true
debug-gc: false
