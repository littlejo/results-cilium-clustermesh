markdown output at /tmp/cilium-bugtool-20241030-082254.183+0000-UTC-791160675/cmd/cilium-debuginfo-20241030-082325.397+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.183+0000-UTC-791160675/cmd/cilium-debuginfo-20241030-082325.397+0000-UTC.json
