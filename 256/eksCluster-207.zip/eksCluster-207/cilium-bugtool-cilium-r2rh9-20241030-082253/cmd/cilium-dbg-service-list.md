ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.251.8:443 (active)     
                                          2 => 172.31.149.166:443 (active)   
2    10.100.109.232:443    ClusterIP      1 => 172.31.244.52:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.207.0.71:53 (active)       
                                          2 => 10.207.0.236:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.207.0.71:9153 (active)     
                                          2 => 10.207.0.236:9153 (active)    
5    10.100.151.212:2379   ClusterIP      1 => 10.207.0.114:2379 (active)    
