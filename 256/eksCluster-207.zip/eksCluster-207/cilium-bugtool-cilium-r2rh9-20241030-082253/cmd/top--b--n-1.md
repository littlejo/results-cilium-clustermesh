top - 08:22:54 up 30 min,  0 users,  load average: 0.18, 0.22, 0.18
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 43.3 us, 50.0 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4448.7 free,   1218.5 used,   2147.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6410.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    710 root      20   0 1244596  22112  14208 S  40.0   0.3   0:00.06 hubble
      1 root      20   0 1606336 385000  78784 S   6.7   4.8   0:44.37 cilium-+
    602 root      20   0 1240432  16848  11548 S   6.7   0.2   0:00.03 cilium-+
    392 root      20   0 1229744   8008   3836 S   0.0   0.1   0:01.08 cilium-+
    651 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    660 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    683 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    696 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    703 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    735 root      20   0    2884    424    352 R   0.0   0.0   0:00.00 ip6tabl+
