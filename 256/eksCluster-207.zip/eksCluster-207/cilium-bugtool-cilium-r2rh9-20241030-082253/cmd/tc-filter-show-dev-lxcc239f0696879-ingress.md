filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc239f0696879 direct-action not_in_hw id 571 tag 60e52a5de240bdcd jited 
