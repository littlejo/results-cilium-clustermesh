[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71da4c23_2208_4475_a220_b0474d4bd619.slice/cri-containerd-f5294d29bb3ea1c41b4e9ecd2e4dd875a5b3d6a5fa3744000cc78ccdcbfe0a87.scope"
      }
    ],
    "ips": [
      "10.207.0.236"
    ],
    "name": "coredns-cc6ccd49c-2b7qv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-1fed4bca070c5a1699e8fd17edb2313cf58fe0ae2012e1a09a7233ff27d924e3.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-d1e772da4dd5667ac4e84df66c47a03cf20d8f81a692d577a8b43737a90c6ad7.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-e0a84d28b6db8fdf5722d944aa62ac5ca647ee68b963b67b2471703b75ced110.scope"
      }
    ],
    "ips": [
      "10.207.0.114"
    ],
    "name": "clustermesh-apiserver-77c9997bc5-7gfz7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37de687c_61ee_4052_93e3_33898b85c165.slice/cri-containerd-14e659810925c40eba27aa8c3cd6c03acb3a9350ee56902d23d4bcae2d3515e3.scope"
      }
    ],
    "ips": [
      "10.207.0.71"
    ],
    "name": "coredns-cc6ccd49c-8n5xg",
    "namespace": "kube-system"
  }
]

