IP ADDRESS        LOCAL ENDPOINT INFO
172.31.251.63:0   (localhost)                                                                                        
10.207.0.236:0    id=505   sec_id=6823085 flags=0x0000 ifindex=14  mac=2E:04:10:33:89:D1 nodemac=2A:E9:25:26:4D:4F   
10.207.0.160:0    id=3215  sec_id=4     flags=0x0000 ifindex=10  mac=92:6F:BB:F6:37:DC nodemac=D2:5A:4D:B4:61:E0     
172.31.244.52:0   (localhost)                                                                                        
10.207.0.71:0     id=2974  sec_id=6823085 flags=0x0000 ifindex=12  mac=2A:11:CE:1E:05:72 nodemac=CE:90:53:F0:DA:08   
10.207.0.157:0    (localhost)                                                                                        
10.207.0.114:0    id=2086  sec_id=6816887 flags=0x0000 ifindex=18  mac=8E:78:6B:2F:D0:9E nodemac=6E:E6:E6:E2:66:9F   
