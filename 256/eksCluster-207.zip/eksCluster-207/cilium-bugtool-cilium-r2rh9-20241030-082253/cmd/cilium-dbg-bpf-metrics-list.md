REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36700     2907257     677    bpf_overlay.c
Interface                 INGRESS     649861    132915687   1132   bpf_host.c
Success                   EGRESS      15500     2456350     86     l3.h
Success                   EGRESS      16474     1297352     1694   bpf_host.c
Success                   EGRESS      275532    34418428    1308   bpf_lxc.c
Success                   EGRESS      36930     2922663     53     encap.h
Success                   INGRESS     317584    35944820    86     l3.h
Success                   INGRESS     353961    40055121    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
