USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         602  0.0  0.2 1240176 16644 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         647  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         648  0.0  0.0      0     0 ?        Z    08:22   0:00  \_ [cat] <defunct>
root           1  3.6  4.7 1606336 383720 ?      Ssl  08:02   0:44 cilium-agent --config-dir=/tmp/cilium/config-map
root         392  0.0  0.1 1229744 8008 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
