CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod90ddca87_8a14_412c_abe4_bffb45ea8148.slice/cri-containerd-5a0dd8b7336f4433e09581cf89a8804cd8b7a6214a12a1f061d52afd42699b0c.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod90ddca87_8a14_412c_abe4_bffb45ea8148.slice/cri-containerd-8a31563bd2b93c5e096e444efd29f4bbd01b187d960db95ebe820e7dcdc644ca.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71da4c23_2208_4475_a220_b0474d4bd619.slice/cri-containerd-f5294d29bb3ea1c41b4e9ecd2e4dd875a5b3d6a5fa3744000cc78ccdcbfe0a87.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71da4c23_2208_4475_a220_b0474d4bd619.slice/cri-containerd-ad05492a81bc31a5913443e48c32f025f0134cc4a3c8ffb3f73bbdb5d1159180.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1769659_0f1d_48ab_93ea_651bdec30943.slice/cri-containerd-497c45cbd05721ac7dc79061e7d29377a71133c79543e6af5f467308eaae250c.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1769659_0f1d_48ab_93ea_651bdec30943.slice/cri-containerd-81dcee6d245a71a5c154b6053bb815b9a91aeba5c07b6cbd47b97dc749ce0388.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37de687c_61ee_4052_93e3_33898b85c165.slice/cri-containerd-14e659810925c40eba27aa8c3cd6c03acb3a9350ee56902d23d4bcae2d3515e3.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37de687c_61ee_4052_93e3_33898b85c165.slice/cri-containerd-a7c1161bb228140f217b09a93c2905cfd2b68345e9763838b97af3cd0216d711.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaca8a776_6b9a_47b7_a6a1_110369b9494f.slice/cri-containerd-4bfb71141a5850265cb595480f28fda798799c6fea209f6ccdc165489166c6db.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaca8a776_6b9a_47b7_a6a1_110369b9494f.slice/cri-containerd-2f95b7dfa43e568f40167a3dd4573d19801bfe633c09be7f000786c30a4f21ee.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ce6b6e8_48cd_486d_87d4_d7402bc07ae1.slice/cri-containerd-54f71684e9dd6d426455db99fe58bb10c757c03f012097f93b9c2fb2fa1c6a61.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ce6b6e8_48cd_486d_87d4_d7402bc07ae1.slice/cri-containerd-0d1a92ee4272c7ff33e9fd37f0a5df93262f5b402720280cadd70a54c93f3088.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-1fed4bca070c5a1699e8fd17edb2313cf58fe0ae2012e1a09a7233ff27d924e3.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-e0a84d28b6db8fdf5722d944aa62ac5ca647ee68b963b67b2471703b75ced110.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-d1e772da4dd5667ac4e84df66c47a03cf20d8f81a692d577a8b43737a90c6ad7.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8c1d507d_d445_4ff5_8f3c_dae324eba4b7.slice/cri-containerd-6bd549942f4ed062ee5acaba5b40a4658d32f0a5d265d67b0fa3fc2eb3672e2b.scope
    654      cgroup_device   multi                                          
