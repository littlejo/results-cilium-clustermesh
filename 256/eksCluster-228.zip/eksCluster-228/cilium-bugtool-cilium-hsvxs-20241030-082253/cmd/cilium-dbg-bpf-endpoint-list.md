IP ADDRESS         LOCAL ENDPOINT INFO
10.228.0.144:0     id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20     
10.228.0.59:0      id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11   
10.228.0.171:0     id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA   
172.31.177.159:0   (localhost)                                                                                        
10.228.0.2:0       id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72   
172.31.148.66:0    (localhost)                                                                                        
10.228.0.67:0      (localhost)                                                                                        
