REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34172     2701677     677    bpf_overlay.c
Interface                 INGRESS     607848    127363253   1132   bpf_host.c
Success                   EGRESS      13997     1094695     1694   bpf_host.c
Success                   EGRESS      256703    32658982    1308   bpf_lxc.c
Success                   EGRESS      32969     2611121     53     encap.h
Success                   INGRESS     297565    33387043    86     l3.h
Success                   INGRESS     318391    35038071    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
