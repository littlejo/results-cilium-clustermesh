Endpoint ID: 201
Path: /sys/fs/bpf/tc/globals/cilium_policy_00201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655165   20878     0        
Allow    Ingress     1          ANY          NONE         disabled    16736     195       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 479
Path: /sys/fs/bpf/tc/globals/cilium_policy_00479

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11337617   111181    0        
Allow    Ingress     1          ANY          NONE         disabled    9082452    94950     0        
Allow    Egress      0          ANY          NONE         disabled    11010609   109645    0        


Endpoint ID: 977
Path: /sys/fs/bpf/tc/globals/cilium_policy_00977

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1921
Path: /sys/fs/bpf/tc/globals/cilium_policy_01921

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113636   1307      0        
Allow    Egress      0          ANY          NONE         disabled    16533    178       0        


Endpoint ID: 3497
Path: /sys/fs/bpf/tc/globals/cilium_policy_03497

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    113737   1305      0        
Allow    Egress      0          ANY          NONE         disabled    16653    180       0        


