key: 0b 00 00 00  value: 0a e4 00 02 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 94 42 10 94 00 00  00 00 00 00
key: 07 00 00 00  value: 0a e4 00 3b 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a e4 00 3b 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 8e bb 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a e4 00 ab 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f cf ba 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a e4 00 ab 00 35 00 00  00 00 00 00
Found 8 elements
