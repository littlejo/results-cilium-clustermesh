markdown output at /tmp/cilium-bugtool-20241030-082255.167+0000-UTC-2325469428/cmd/cilium-debuginfo-20241030-082326.425+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.167+0000-UTC-2325469428/cmd/cilium-debuginfo-20241030-082326.425+0000-UTC.json
