[
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-23db48b28dfcceab8929de17aaad304a64ba6246c261d9124afd9a121b453d5f.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-4fc65e5d0b1ad8cb09dcbd6bf68b08d1a4b3dfa86bab23b6477298488994c3e5.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-c23e8ba1551b336d959d2fedca7ace0c37e3a0c391f9fd2dd0719460f49783a2.scope"
      }
    ],
    "ips": [
      "10.228.0.2"
    ],
    "name": "clustermesh-apiserver-5dd766f96b-7gfc2",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod275ed9ae_2984_412f_bd92_edc7fa1c3117.slice/cri-containerd-97554e5c01bed08a1f9c78d86193384faf65717b96aa325ff332019e1c1b3df3.scope"
      }
    ],
    "ips": [
      "10.228.0.59"
    ],
    "name": "coredns-cc6ccd49c-mtdjr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9a91c93_d603_4e87_b644_0de81c6f2f42.slice/cri-containerd-c171096669421528197e557d6531321b9220b7ad8b37fa5cba22f3611c909778.scope"
      }
    ],
    "ips": [
      "10.228.0.171"
    ],
    "name": "coredns-cc6ccd49c-94k74",
    "namespace": "kube-system"
  }
]

