CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod275ed9ae_2984_412f_bd92_edc7fa1c3117.slice/cri-containerd-d39a4971c1bb9f0dc83c81da51d49cf4dce692af2070e59649615d4aa03a8f01.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod275ed9ae_2984_412f_bd92_edc7fa1c3117.slice/cri-containerd-97554e5c01bed08a1f9c78d86193384faf65717b96aa325ff332019e1c1b3df3.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9a91c93_d603_4e87_b644_0de81c6f2f42.slice/cri-containerd-c171096669421528197e557d6531321b9220b7ad8b37fa5cba22f3611c909778.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda9a91c93_d603_4e87_b644_0de81c6f2f42.slice/cri-containerd-829fa17c5a2f8de4874610a94e0b3f5c0ec5f59c512faba18309ddfc5add1172.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96b977b7_8037_4487_98a0_1b7376963324.slice/cri-containerd-53c2f47a612dae7e5326faf4506c4d2d96cd668ea3142d512c53a5dfb5a38d2a.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod96b977b7_8037_4487_98a0_1b7376963324.slice/cri-containerd-00c07d7d52619a0aa8d435ba1078f787eee5d39a66618c9b451fbaebf7a7ba27.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f928579_ddc4_4094_8078_15aae1ec1127.slice/cri-containerd-f0401147545050ab9a68f5ab0a8912776a525bf8a960aabebaf49b1218975828.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f928579_ddc4_4094_8078_15aae1ec1127.slice/cri-containerd-d61869090bfffe46c8698566d2f100c023c631d55a8d2312016764bd1fe53c69.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb04e12c_c0c9_4886_834e_e65185dd80a1.slice/cri-containerd-ac554e45f3e5392d2c41bede91f3072cd2db539b28547fb78121dc0ff9a18f06.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfb04e12c_c0c9_4886_834e_e65185dd80a1.slice/cri-containerd-eff1521872cf9cda1ac9bb680c828ac286f3b135a3b195499feacbe3f7ce872c.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-23db48b28dfcceab8929de17aaad304a64ba6246c261d9124afd9a121b453d5f.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-39d501640cbd414219ae2da8cda2582eb894d8ac06645bea7d7f12c9a004f30d.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-c23e8ba1551b336d959d2fedca7ace0c37e3a0c391f9fd2dd0719460f49783a2.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ef968db_d92b_4559_8166_f54424c4d35e.slice/cri-containerd-4fc65e5d0b1ad8cb09dcbd6bf68b08d1a4b3dfa86bab23b6477298488994c3e5.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf74fe796_dfaf_4675_9241_b5f37308f0a9.slice/cri-containerd-1171dd925c4b629faa25ca18ad59f191737823164ec447650fe7d7467e15f704.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf74fe796_dfaf_4675_9241_b5f37308f0a9.slice/cri-containerd-39d3efe517a82a6a02c7c50541b6e9835f20879b329cdd1568cb5181cf7d046d.scope
    101      cgroup_device   multi                                          
