{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:30.566Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.66:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:30.566Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:30.566Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:33.596Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.647Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.685Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.746Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.782Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.877Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.231Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.232Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.233Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:18.270Z",
  "value": "id=411   sec_id=7533401 flags=0x0000 ifindex=16  mac=12:71:F2:08:30:15 nodemac=AA:B5:9D:B7:91:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:19.232Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:19.232Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:19.233Z",
  "value": "id=411   sec_id=7533401 flags=0x0000 ifindex=16  mac=12:71:F2:08:30:15 nodemac=AA:B5:9D:B7:91:48"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:19.233Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:13.698Z",
  "value": "id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.228.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.140Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.655Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.656Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.656Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.656Z",
  "value": "id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.605Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.605Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.608Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.608Z",
  "value": "id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.602Z",
  "value": "id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.602Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.603Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:00.603Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.602Z",
  "value": "id=479   sec_id=7533401 flags=0x0000 ifindex=18  mac=82:81:B2:2E:C4:0C nodemac=6A:2E:9C:8B:20:72"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.59:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.603Z",
  "value": "id=1921  sec_id=7535434 flags=0x0000 ifindex=12  mac=AA:DD:4F:F5:8D:58 nodemac=EE:03:30:85:97:11"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.603Z",
  "value": "id=3497  sec_id=7535434 flags=0x0000 ifindex=14  mac=16:9C:8E:1D:E5:BD nodemac=CA:32:88:34:F2:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.228.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:01.604Z",
  "value": "id=201   sec_id=4     flags=0x0000 ifindex=10  mac=3A:21:1B:CA:7E:34 nodemac=BE:E9:5C:4B:20:20"
}

