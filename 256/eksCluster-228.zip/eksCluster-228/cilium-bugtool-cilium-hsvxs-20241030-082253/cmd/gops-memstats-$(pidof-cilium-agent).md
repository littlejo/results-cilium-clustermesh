alloc: 177.10MB (185704216 bytes)
total-alloc: 2.15GB (2305595440 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 61812748
frees: 59812548
heap-alloc: 177.10MB (185704216 bytes)
heap-sys: 243.73MB (255574016 bytes)
heap-idle: 44.31MB (46465024 bytes)
heap-in-use: 199.42MB (209108992 bytes)
heap-released: 3.61MB (3784704 bytes)
heap-objects: 2000200
stack-in-use: 64.22MB (67338240 bytes)
stack-sys: 64.22MB (67338240 bytes)
stack-mspan-inuse: 3.32MB (3484640 bytes)
stack-mspan-sys: 3.75MB (3933120 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1092601 bytes)
gc-sys: 6.05MB (6348384 bytes)
next-gc: when heap-alloc >= 221.45MB (232206776 bytes)
last-gc: 2024-10-30 08:22:55.77209979 +0000 UTC
gc-pause-total: 11.938606ms
gc-pause: 127881
gc-pause-end: 1730276575772099790
num-gc: 79
num-forced-gc: 0
gc-cpu-fraction: 0.0005318279612614359
enable-gc: true
debug-gc: false
