key: c9 00 00 00  value: 1c 02 00 00
key: df 01 00 00  value: 85 02 00 00
key: 81 07 00 00  value: 16 02 00 00
key: a9 0d 00 00  value: 31 02 00 00
Found 4 elements
