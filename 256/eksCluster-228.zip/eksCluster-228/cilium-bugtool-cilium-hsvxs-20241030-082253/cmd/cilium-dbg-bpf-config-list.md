KEY             VALUE
AgentLiveness   1738123747362
UTimeOffset     3379443101562500
