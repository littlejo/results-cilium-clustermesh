USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         692  0.0  0.2 1240432 16400 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         712  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c cat /proc/net/xfrm_stat
root         713  0.0  0.0   6408  1648 ?        R    08:22   0:00  \_ ps auxfw
root         686  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         698  0.0  0.2 1243764 17672 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         666  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         656  0.0  0.0 1228744 3656 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         655  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         641  0.0  0.0 1229000 4000 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         636  0.0  0.0 1228744 3568 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  4.7 1606080 378952 ?      Ssl  08:03   0:38 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229488 8100 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
