1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:5f:76:bb:5e:15 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.130.97/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 2010sec preferred_lft 2010sec
    inet6 fe80::45f:76ff:febb:5e15/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:4c:21:64:c1:cf brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.148.30/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::44c:21ff:fe64:c1cf/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:51:d2:4f:58:95 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::451:d2ff:fe4f:5895/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:05:01:90:ae:7a brd ff:ff:ff:ff:ff:ff
    inet 10.250.0.83/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e805:1ff:fe90:ae7a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:80:ed:fc:dc:7b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::80:edff:fefc:dc7b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:cd:65:7a:f3:71 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::58cd:65ff:fe7a:f371/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc7159c19ce116@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:2c:ea:69:d3:61 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::b82c:eaff:fe69:d361/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc7d0f7746502d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:f7:3c:60:67:42 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::18f7:3cff:fe60:6742/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7277f58808c6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ce:6b:77:d2:97 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b4ce:6bff:fe77:d297/64 scope link 
       valid_lft forever preferred_lft forever
