{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.294Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.294Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.30:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.294Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.812Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.843Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.903Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:18.960Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:19.065Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:21.457Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:21.458Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:21.458Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:21.490Z",
  "value": "id=501   sec_id=8250075 flags=0x0000 ifindex=16  mac=62:57:05:05:F2:C9 nodemac=CA:BE:28:DE:EE:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:21.491Z",
  "value": "id=501   sec_id=8250075 flags=0x0000 ifindex=16  mac=62:57:05:05:F2:C9 nodemac=CA:BE:28:DE:EE:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:22.457Z",
  "value": "id=501   sec_id=8250075 flags=0x0000 ifindex=16  mac=62:57:05:05:F2:C9 nodemac=CA:BE:28:DE:EE:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:22.458Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:22.458Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:22.458Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.284Z",
  "value": "id=547   sec_id=8250075 flags=0x0000 ifindex=18  mac=2A:D9:3D:79:00:89 nodemac=B6:CE:6B:77:D2:97"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.250.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.729Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.973Z",
  "value": "id=547   sec_id=8250075 flags=0x0000 ifindex=18  mac=2A:D9:3D:79:00:89 nodemac=B6:CE:6B:77:D2:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.976Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.977Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:54.978Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.925Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.925Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.926Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:55.926Z",
  "value": "id=547   sec_id=8250075 flags=0x0000 ifindex=18  mac=2A:D9:3D:79:00:89 nodemac=B6:CE:6B:77:D2:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.925Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.925Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.925Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.926Z",
  "value": "id=547   sec_id=8250075 flags=0x0000 ifindex=18  mac=2A:D9:3D:79:00:89 nodemac=B6:CE:6B:77:D2:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.926Z",
  "value": "id=2792  sec_id=4     flags=0x0000 ifindex=10  mac=36:DD:2A:59:67:F9 nodemac=5A:CD:65:7A:F3:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.926Z",
  "value": "id=3559  sec_id=8230228 flags=0x0000 ifindex=12  mac=CA:AF:81:4F:3F:21 nodemac=BA:2C:EA:69:D3:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.107:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.926Z",
  "value": "id=547   sec_id=8250075 flags=0x0000 ifindex=18  mac=2A:D9:3D:79:00:89 nodemac=B6:CE:6B:77:D2:97"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.250.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.926Z",
  "value": "id=837   sec_id=8230228 flags=0x0000 ifindex=14  mac=1A:FB:D3:24:60:54 nodemac=1A:F7:3C:60:67:42"
}

