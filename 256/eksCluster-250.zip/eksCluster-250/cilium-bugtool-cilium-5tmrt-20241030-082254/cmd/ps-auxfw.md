USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         643  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         637  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         630  0.0  0.2 1240432 16268 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         666  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         667  0.0  0.0      0     0 ?        Z    08:22   0:00  \_ [hostname] <defunct>
root           1  3.3  4.7 1606080 382644 ?      Ssl  08:04   0:38 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.0 1229744 7032 ?        Sl   08:04   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
