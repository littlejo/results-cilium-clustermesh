[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46489118_6658_40de_90f6_7762691d333c.slice/cri-containerd-59e0393b4700ff3b0231037c6ee506ba2c0d85258c656d0513d5e2db47296db1.scope"
      }
    ],
    "ips": [
      "10.250.0.64"
    ],
    "name": "coredns-cc6ccd49c-j2b2l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda4c59f5_b148_4d06_8a46_bd4652e5342c.slice/cri-containerd-ef9496c78d3a6dd51db1cd5e9577213a8834664e6c5ad81245d798c12eb7517c.scope"
      }
    ],
    "ips": [
      "10.250.0.143"
    ],
    "name": "coredns-cc6ccd49c-7q9ct",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-8870ecf5d9f56c55a29beb2f6b58709ad03f5e5af24ac155c03437d1ac36e3fb.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-b988d762be00ec1d5b0991faec5ec3c364330b262fa3feead03e0c0803019a72.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-6768ed7a38bbdf0812345899f943f04333e98fc04171d473f617aa3294886bf5.scope"
      }
    ],
    "ips": [
      "10.250.0.107"
    ],
    "name": "clustermesh-apiserver-86944b998-6bpg7",
    "namespace": "kube-system"
  }
]

