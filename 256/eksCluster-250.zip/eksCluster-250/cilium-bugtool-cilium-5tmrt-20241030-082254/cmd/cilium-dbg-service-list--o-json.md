[
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.199.25",
          "port": 443,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "172.31.177.47",
          "port": 443,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kubernetes",
        "namespace": "default",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.1",
        "port": 443,
        "scope": "external"
      },
      "id": 1
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.199.25",
            "port": 443,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "172.31.177.47",
            "port": 443,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kubernetes",
          "namespace": "default",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.1",
          "port": 443,
          "scope": "external"
        },
        "id": 1
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "172.31.130.97",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 4244,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Local",
        "name": "hubble-peer",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.182.186",
        "port": 443,
        "scope": "external"
      },
      "id": 2
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "172.31.130.97",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 4244,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Local",
          "name": "hubble-peer",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.182.186",
          "port": 443,
          "scope": "external"
        },
        "id": 2
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.250.0.64",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.250.0.143",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 9153,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 9153,
        "scope": "external"
      },
      "id": 3
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.250.0.64",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.250.0.143",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 9153,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 9153,
          "scope": "external"
        },
        "id": 3
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.250.0.64",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        },
        {
          "ip": "10.250.0.143",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 53,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "kube-dns",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.0.10",
        "port": 53,
        "scope": "external"
      },
      "id": 4
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.250.0.64",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          },
          {
            "ip": "10.250.0.143",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 53,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "kube-dns",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.0.10",
          "port": 53,
          "scope": "external"
        },
        "id": 4
      }
    }
  },
  {
    "spec": {
      "backend-addresses": [
        {
          "ip": "10.250.0.107",
          "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
          "port": 2379,
          "state": "active",
          "weight": 100
        }
      ],
      "flags": {
        "extTrafficPolicy": "Cluster",
        "intTrafficPolicy": "Cluster",
        "name": "clustermesh-apiserver",
        "namespace": "kube-system",
        "trafficPolicy": "Cluster",
        "type": "ClusterIP"
      },
      "frontend-address": {
        "ip": "10.100.117.229",
        "port": 2379,
        "scope": "external"
      },
      "id": 5
    },
    "status": {
      "realized": {
        "backend-addresses": [
          {
            "ip": "10.250.0.107",
            "nodeName": "ip-172-31-130-97.eu-west-3.compute.internal",
            "port": 2379,
            "state": "active",
            "weight": 100
          }
        ],
        "flags": {
          "extTrafficPolicy": "Cluster",
          "intTrafficPolicy": "Cluster",
          "name": "clustermesh-apiserver",
          "namespace": "kube-system",
          "trafficPolicy": "Cluster",
          "type": "ClusterIP"
        },
        "frontend-address": {
          "ip": "10.100.117.229",
          "port": 2379,
          "scope": "external"
        },
        "id": 5
      }
    }
  }
]

