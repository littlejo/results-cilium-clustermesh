ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.199.25:443 (active)    
                                          2 => 172.31.177.47:443 (active)    
2    10.100.182.186:443    ClusterIP      1 => 172.31.130.97:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.250.0.64:9153 (active)     
                                          2 => 10.250.0.143:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.250.0.64:53 (active)       
                                          2 => 10.250.0.143:53 (active)      
5    10.100.117.229:2379   ClusterIP      1 => 10.250.0.107:2379 (active)    
