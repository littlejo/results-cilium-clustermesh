key: 23 02 00 00  value: 73 02 00 00
key: 45 03 00 00  value: 24 02 00 00
key: e8 0a 00 00  value: ff 01 00 00
key: e7 0d 00 00  value: 1a 02 00 00
Found 4 elements
