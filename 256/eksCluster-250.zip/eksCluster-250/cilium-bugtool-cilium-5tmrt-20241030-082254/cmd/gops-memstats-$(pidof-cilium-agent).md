alloc: 188.60MB (197761112 bytes)
total-alloc: 2.16GB (2315597368 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 61988855
frees: 60056381
heap-alloc: 188.60MB (197761112 bytes)
heap-sys: 247.33MB (259342336 bytes)
heap-idle: 33.65MB (35282944 bytes)
heap-in-use: 213.68MB (224059392 bytes)
heap-released: 2.22MB (2326528 bytes)
heap-objects: 1932474
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 3.35MB (3515360 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1258737 bytes)
gc-sys: 6.05MB (6340144 bytes)
next-gc: when heap-alloc >= 215.88MB (226371464 bytes)
last-gc: 2024-10-30 08:23:00.287314261 +0000 UTC
gc-pause-total: 12.689637ms
gc-pause: 678289
gc-pause-end: 1730276580287314261
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0004735995128109456
enable-gc: true
debug-gc: false
