 08:22:55 up 26 min,  0 users,  load average: 0.26, 0.34, 0.26
