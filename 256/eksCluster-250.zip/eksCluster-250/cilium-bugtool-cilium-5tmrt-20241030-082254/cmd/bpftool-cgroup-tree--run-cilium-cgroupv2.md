CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf4a3abc_b4a1_4ef5_ab49_842ca1ac615e.slice/cri-containerd-b619e7ef57daf5509c7e6ea76515c6d2828d903149c7fc98bb6357acc2c397cb.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaf4a3abc_b4a1_4ef5_ab49_842ca1ac615e.slice/cri-containerd-10ee274343ab9b780ff59a96fcb6b9e2b9e7adfd0d55d41147c44cdf76a07b24.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46489118_6658_40de_90f6_7762691d333c.slice/cri-containerd-59e0393b4700ff3b0231037c6ee506ba2c0d85258c656d0513d5e2db47296db1.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod46489118_6658_40de_90f6_7762691d333c.slice/cri-containerd-9e19984c89ab1f6a2a239c166d3001f72e722a57e86b2e9806abbffb40da3f71.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda4c59f5_b148_4d06_8a46_bd4652e5342c.slice/cri-containerd-8c69470b33e3f7e62358b70f0313132a13b314a0b3ec1af29bcb4422904e588c.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podda4c59f5_b148_4d06_8a46_bd4652e5342c.slice/cri-containerd-ef9496c78d3a6dd51db1cd5e9577213a8834664e6c5ad81245d798c12eb7517c.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9954cb3_fdd1_463f_bb66_1d4c9c5647d4.slice/cri-containerd-0c8370e111ba852db0f4faa0f2bf57e0bb19896b1af937b69b1fa28d0e0e8339.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc9954cb3_fdd1_463f_bb66_1d4c9c5647d4.slice/cri-containerd-9ccd492c867731438465a944b366328022a3729305b1222d97034d69f9c5107e.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49ddbbc8_8f09_49d9_b30a_256f27e80341.slice/cri-containerd-f22f722adb6b8ac8834f4b43e53e8b38aea1660ea6cf129010d8fb5d6af08165.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod49ddbbc8_8f09_49d9_b30a_256f27e80341.slice/cri-containerd-3e38aacab7d6a96cd3646267c81946db48745b5f8daf66fe4c9a00d7c9be5228.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode80a8215_106b_404d_931c_e85b4c89d2d3.slice/cri-containerd-d754d85e71bb114ead122ea8886ad5b42deb70088c6e03b9cbd7aaf73e7adce5.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode80a8215_106b_404d_931c_e85b4c89d2d3.slice/cri-containerd-716956fe938aea2d6b43e4b28db8ffe9e49abe2e43e897e16614c19465b48375.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-8870ecf5d9f56c55a29beb2f6b58709ad03f5e5af24ac155c03437d1ac36e3fb.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-e89b5a4fc73bb1b624ec87701a018b33dfae7ccfbb00e9c27bfcbce57c29d87e.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-b988d762be00ec1d5b0991faec5ec3c364330b262fa3feead03e0c0803019a72.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod85fa2011_6806_4683_bf27_d244efb4475d.slice/cri-containerd-6768ed7a38bbdf0812345899f943f04333e98fc04171d473f617aa3294886bf5.scope
    664      cgroup_device   multi                                          
