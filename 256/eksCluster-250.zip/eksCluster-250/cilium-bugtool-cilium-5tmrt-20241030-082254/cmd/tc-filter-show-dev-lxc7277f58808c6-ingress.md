filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7277f58808c6 direct-action not_in_hw id 635 tag bf443d215ef01a96 jited 
