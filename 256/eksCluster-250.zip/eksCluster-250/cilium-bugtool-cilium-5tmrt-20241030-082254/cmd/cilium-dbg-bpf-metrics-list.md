REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35496     2808133     677    bpf_overlay.c
Interface                 INGRESS     614811    127832214   1132   bpf_host.c
Success                   EGRESS      15251     1196620     1694   bpf_host.c
Success                   EGRESS      256091    32728230    1308   bpf_lxc.c
Success                   EGRESS      34845     2760895     53     encap.h
Success                   INGRESS     297643    33398418    86     l3.h
Success                   INGRESS     318538    35053907    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
