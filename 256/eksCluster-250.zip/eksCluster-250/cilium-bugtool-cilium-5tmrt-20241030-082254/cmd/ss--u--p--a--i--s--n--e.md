Total: 676
TCP:   1838 (estab 430, closed 1389, orphaned 0, timewait 553)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  449       436       13       
INET	  459       442       17       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:40015      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:32939 sk:3de fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.130.97%ens5:68         0.0.0.0:*    uid:192 ino:15330 sk:3df cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:34251 sk:3e0 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15092 sk:3e1 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:34250 sk:3e2 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15093 sk:3e3 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::45f:76ff:febb:5e15]%ens5:546           [::]:*    uid:192 ino:15328 sk:3e4 cgroup:unreachable:c4e v6only:1 <->                   
