filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7159c19ce116 direct-action not_in_hw id 536 tag a86e79352da9ca67 jited 
