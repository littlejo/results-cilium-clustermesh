Endpoint ID: 547
Path: /sys/fs/bpf/tc/globals/cilium_policy_00547

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11303427   110710    0        
Allow    Ingress     1          ANY          NONE         disabled    9125619    95220     0        
Allow    Egress      0          ANY          NONE         disabled    10911375   108544    0        


Endpoint ID: 837
Path: /sys/fs/bpf/tc/globals/cilium_policy_00837

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109660   1261      0        
Allow    Egress      0          ANY          NONE         disabled    16240    174       0        


Endpoint ID: 1067
Path: /sys/fs/bpf/tc/globals/cilium_policy_01067

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2792
Path: /sys/fs/bpf/tc/globals/cilium_policy_02792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1661084   20962     0        
Allow    Ingress     1          ANY          NONE         disabled    17148     201       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3559
Path: /sys/fs/bpf/tc/globals/cilium_policy_03559

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109489   1255      0        
Allow    Egress      0          ANY          NONE         disabled    16670    180       0        


