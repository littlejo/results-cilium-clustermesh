REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35886     2833906     677    bpf_overlay.c
Interface                 INGRESS     628486    130213185   1132   bpf_host.c
Success                   EGRESS      15396     1206394     1694   bpf_host.c
Success                   EGRESS      262326    33179888    1308   bpf_lxc.c
Success                   EGRESS      35265     2790284     53     encap.h
Success                   INGRESS     304625    34158844    86     l3.h
Success                   INGRESS     325766    35830402    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
