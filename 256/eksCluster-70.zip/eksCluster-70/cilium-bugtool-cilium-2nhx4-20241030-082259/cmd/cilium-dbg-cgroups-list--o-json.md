[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14604609_44e7_4d0a_a45d_0542f54ff268.slice/cri-containerd-4ee2c755553812cf5b8f9394b2c9b5984cc1d5ccfc3a27ea0d66cf1132a34b44.scope"
      }
    ],
    "ips": [
      "10.70.0.216"
    ],
    "name": "coredns-cc6ccd49c-2ksxb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b337c5_805a_48aa_989b_51fce07b71c9.slice/cri-containerd-2babd58c651c1dc79a8e051d7c2b840f2f9ba4be02b69171905d2becaaf00d09.scope"
      }
    ],
    "ips": [
      "10.70.0.88"
    ],
    "name": "coredns-cc6ccd49c-z97wp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-6bc8a3b7d86506baa928e4cc289f514a3d4dd7db74edca5188d00b18c6b99349.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-2d246ac1b5a7a93451c889e40e539ffab150f24e00385ae7a4f16a4ba0cb9572.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-ac7b4527234458e2802b1ea599b1c9441d26e4d1dfcc076728308a8dfda791d9.scope"
      }
    ],
    "ips": [
      "10.70.0.98"
    ],
    "name": "clustermesh-apiserver-6886cff76c-ksbg7",
    "namespace": "kube-system"
  }
]

