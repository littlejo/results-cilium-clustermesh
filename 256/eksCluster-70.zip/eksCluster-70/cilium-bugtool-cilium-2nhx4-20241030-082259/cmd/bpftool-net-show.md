xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 507
ens6(5) clsact/ingress cil_from_netdev-ens6 id 512
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 499
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(7) clsact/egress cil_from_host-cilium_host id 490
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 540
lxcdf275f3adee6(12) clsact/ingress cil_from_container-lxcdf275f3adee6 id 535
lxce3c5c8f94c6a(14) clsact/ingress cil_from_container-lxce3c5c8f94c6a id 538
lxc289473d32c94(18) clsact/ingress cil_from_container-lxc289473d32c94 id 623

flow_dissector:

netfilter:

