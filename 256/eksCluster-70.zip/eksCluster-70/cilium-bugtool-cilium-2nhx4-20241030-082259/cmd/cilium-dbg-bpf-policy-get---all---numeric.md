Endpoint ID: 542
Path: /sys/fs/bpf/tc/globals/cilium_policy_00542

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1674186   21175     0        
Allow    Ingress     1          ANY          NONE         disabled    22780     266       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 796
Path: /sys/fs/bpf/tc/globals/cilium_policy_00796

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151402   1738      0        
Allow    Egress      0          ANY          NONE         disabled    19698    217       0        


Endpoint ID: 2822
Path: /sys/fs/bpf/tc/globals/cilium_policy_02822

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11409811   112228    0        
Allow    Ingress     1          ANY          NONE         disabled    9441954    99044     0        
Allow    Egress      0          ANY          NONE         disabled    11380916   112978    0        


Endpoint ID: 3116
Path: /sys/fs/bpf/tc/globals/cilium_policy_03116

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    152604   1755      0        
Allow    Egress      0          ANY          NONE         disabled    19468    215       0        


Endpoint ID: 3822
Path: /sys/fs/bpf/tc/globals/cilium_policy_03822

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


