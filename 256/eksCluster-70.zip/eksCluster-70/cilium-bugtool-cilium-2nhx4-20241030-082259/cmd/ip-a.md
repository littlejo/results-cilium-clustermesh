1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c8:b6:cc:cc:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.32/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3338sec preferred_lft 3338sec
    inet6 fe80::4c8:b6ff:fecc:cc23/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:83:ee:55:a2:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.138.61/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::483:eeff:fe55:a22f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:dd:93:d2:df:8d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d4dd:93ff:fed2:df8d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:aa:d9:fe:28:de brd ff:ff:ff:ff:ff:ff
    inet 10.70.0.126/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d4aa:d9ff:fefe:28de/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:2e:11:c4:2d:1b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3c2e:11ff:fec4:2d1b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:0f:d4:47:5b:23 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::ac0f:d4ff:fe47:5b23/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdf275f3adee6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:de:a5:39:2b:88 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::10de:a5ff:fe39:2b88/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce3c5c8f94c6a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:63:10:c8:7e:2c brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5c63:10ff:fec8:7e2c/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc289473d32c94@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:22:0e:3b:8c:e4 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8822:eff:fe3b:8ce4/64 scope link 
       valid_lft forever preferred_lft forever
