alloc: 138.21MB (144928712 bytes)
total-alloc: 2.22GB (2383944344 bytes)
sys: 332.83MB (349000036 bytes)
lookups: 0
mallocs: 62898328
frees: 61843558
heap-alloc: 138.21MB (144928712 bytes)
heap-sys: 255.95MB (268386304 bytes)
heap-idle: 76.56MB (80281600 bytes)
heap-in-use: 179.39MB (188104704 bytes)
heap-released: 10.34MB (10846208 bytes)
heap-objects: 1054770
stack-in-use: 64.00MB (67108864 bytes)
stack-sys: 64.00MB (67108864 bytes)
stack-mspan-inuse: 2.72MB (2851200 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1017.75KB (1042177 bytes)
gc-sys: 6.09MB (6381080 bytes)
next-gc: when heap-alloc >= 211.93MB (222226792 bytes)
last-gc: 2024-10-30 08:23:16.174786681 +0000 UTC
gc-pause-total: 7.033716ms
gc-pause: 96953
gc-pause-end: 1730276596174786681
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0003523040842657877
enable-gc: true
debug-gc: false
