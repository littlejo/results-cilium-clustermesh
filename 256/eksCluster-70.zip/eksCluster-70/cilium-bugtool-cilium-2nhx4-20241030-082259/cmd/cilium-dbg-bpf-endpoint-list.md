IP ADDRESS        LOCAL ENDPOINT INFO
10.70.0.88:0      id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88   
10.70.0.98:0      id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4   
10.70.0.216:0     id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C   
172.31.138.61:0   (localhost)                                                                                        
172.31.181.32:0   (localhost)                                                                                        
10.70.0.126:0     (localhost)                                                                                        
10.70.0.195:0     id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23     
