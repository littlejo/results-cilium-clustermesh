CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58689600_79d8_4712_9ae4_b087ebb44d47.slice/cri-containerd-19e09a48cee10b9a8c7e09f11937327ff54e250c6148b1ffbb56d7b544529188.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod58689600_79d8_4712_9ae4_b087ebb44d47.slice/cri-containerd-c19f0794bb4561efb7d4782ce935735286df286d1adab0c003670bab1f219fa7.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b337c5_805a_48aa_989b_51fce07b71c9.slice/cri-containerd-2babd58c651c1dc79a8e051d7c2b840f2f9ba4be02b69171905d2becaaf00d09.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4b337c5_805a_48aa_989b_51fce07b71c9.slice/cri-containerd-72715f09a3b54a6a0efb02f3c74eed70f6e18a964e5417b094c665899b966020.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14604609_44e7_4d0a_a45d_0542f54ff268.slice/cri-containerd-dc87c76b2794471b308bd95dbdce3dd149b6fe4dbb8ef0623bff559bd3bf2e54.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod14604609_44e7_4d0a_a45d_0542f54ff268.slice/cri-containerd-4ee2c755553812cf5b8f9394b2c9b5984cc1d5ccfc3a27ea0d66cf1132a34b44.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ef3010b_adbf_468b_adf4_7380bb8c4ea9.slice/cri-containerd-661274330d8dc156ce08ffa79a25e4e3f86684b68e356312215fdc4f99e4b378.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ef3010b_adbf_468b_adf4_7380bb8c4ea9.slice/cri-containerd-06e7584896b31ccab3be4131e7e69c4ca9c71e46cb6a04510263602a883e7e66.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-e6c9449b322660270310de6ecfbba73bc518d1d040aeb53d49e3af0082186ca1.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-6bc8a3b7d86506baa928e4cc289f514a3d4dd7db74edca5188d00b18c6b99349.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-2d246ac1b5a7a93451c889e40e539ffab150f24e00385ae7a4f16a4ba0cb9572.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb14d86a_7acd_4c53_9fdc_015a2f764c58.slice/cri-containerd-ac7b4527234458e2802b1ea599b1c9441d26e4d1dfcc076728308a8dfda791d9.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7780ad4_8277_46c0_9b6e_ed7e2f5206a0.slice/cri-containerd-56b0b7a84b179e5962953ce2bc4478b46d8b2713f11c338bafac50bd5b7551d4.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd7780ad4_8277_46c0_9b6e_ed7e2f5206a0.slice/cri-containerd-e870f67bf3e4f7a75b8defc64c3d2387310d1b6152fe2f7406f89cd69fb2cf1e.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c807b96_7409_476c_9fca_46168340bfd4.slice/cri-containerd-521e3e0211b90ce78c04c6818bbef1969d39e0687fc1cf982cfa04105022777c.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c807b96_7409_476c_9fca_46168340bfd4.slice/cri-containerd-84a6410d04b5997498eaabd2421f9faca5bee124c835b53a3e9f0626eb6164bf.scope
    105      cgroup_device   multi                                          
