filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce3c5c8f94c6a direct-action not_in_hw id 538 tag ff1c624de9482cba jited 
