{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:50.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.138.61:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:50.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.181.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:50.524Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.069Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.074Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.132Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.132Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:55.134Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.917Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.918Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.918Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.952Z",
  "value": "id=1097  sec_id=2346546 flags=0x0000 ifindex=16  mac=BA:DB:5E:E8:D7:86 nodemac=02:72:81:6B:B5:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.918Z",
  "value": "id=1097  sec_id=2346546 flags=0x0000 ifindex=16  mac=BA:DB:5E:E8:D7:86 nodemac=02:72:81:6B:B5:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.918Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.918Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.918Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.404Z",
  "value": "id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.70.0.164:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:11.678Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.957Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.957Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.958Z",
  "value": "id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:41.958Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.971Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.972Z",
  "value": "id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.958Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.958Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.959Z",
  "value": "id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:43.959Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.959Z",
  "value": "id=542   sec_id=4     flags=0x0000 ifindex=10  mac=8E:57:AB:85:ED:BD nodemac=AE:0F:D4:47:5B:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.88:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.959Z",
  "value": "id=796   sec_id=2333886 flags=0x0000 ifindex=12  mac=8E:9E:12:A3:4E:A5 nodemac=12:DE:A5:39:2B:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.959Z",
  "value": "id=2822  sec_id=2346546 flags=0x0000 ifindex=18  mac=F2:1F:3F:17:44:2A nodemac=8A:22:0E:3B:8C:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.70.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:44.959Z",
  "value": "id=3116  sec_id=2333886 flags=0x0000 ifindex=14  mac=82:BA:B1:F7:E5:9E nodemac=5E:63:10:C8:7E:2C"
}

