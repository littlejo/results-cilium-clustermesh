key: 1e 02 00 00  value: 23 02 00 00
key: 1c 03 00 00  value: 16 02 00 00
key: 06 0b 00 00  value: 6a 02 00 00
key: 2c 0c 00 00  value: 2e 02 00 00
Found 4 elements
