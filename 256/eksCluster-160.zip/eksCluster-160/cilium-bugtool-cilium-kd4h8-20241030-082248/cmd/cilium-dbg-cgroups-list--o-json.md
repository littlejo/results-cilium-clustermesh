[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-28555d86f7bdfa2bf8fc6034f8296c96d217cadd61f4b8077bc0cc2259f231f1.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-c2978dd370f4454775112b0ea535dc944bdcb4a43c5a8bd519711dc0b59db261.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-746af2e13049fbba56386706c9cc74e7320cec8277527bce8922fcab2dfa327b.scope"
      }
    ],
    "ips": [
      "10.160.0.235"
    ],
    "name": "clustermesh-apiserver-65767bff8d-5p24b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c05c278_0694_4a71_9a54_69c4ed126b7a.slice/cri-containerd-e0b9af512b47f3fb0cbbe0032c28bc07e08577a776be6a323e0d0c904d6508eb.scope"
      }
    ],
    "ips": [
      "10.160.0.2"
    ],
    "name": "coredns-cc6ccd49c-vj8nd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd74116f_1b3c_4c26_97bb_5d2c8de3e1e5.slice/cri-containerd-47318d331bfc860896a09acf4e2d10c3039a892c47e33818cfbd94660b8aa977.scope"
      }
    ],
    "ips": [
      "10.160.0.200"
    ],
    "name": "coredns-cc6ccd49c-4682h",
    "namespace": "kube-system"
  }
]

