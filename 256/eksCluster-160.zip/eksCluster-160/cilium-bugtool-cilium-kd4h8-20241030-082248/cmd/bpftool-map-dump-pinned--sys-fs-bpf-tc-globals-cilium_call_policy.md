key: 3a 00 00 00  value: 13 02 00 00
key: 7c 03 00 00  value: 19 02 00 00
key: 24 06 00 00  value: 22 02 00 00
key: 1a 0c 00 00  value: 65 02 00 00
Found 4 elements
