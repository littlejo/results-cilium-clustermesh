KEY             VALUE
AgentLiveness   1973004068576
UTimeOffset     3379442632812500
