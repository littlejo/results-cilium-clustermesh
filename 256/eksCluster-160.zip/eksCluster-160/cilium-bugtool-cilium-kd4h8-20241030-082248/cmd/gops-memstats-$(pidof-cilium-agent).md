alloc: 210.38MB (220601784 bytes)
total-alloc: 2.50GB (2684142448 bytes)
sys: 361.09MB (378625396 bytes)
lookups: 0
mallocs: 66880814
frees: 64809592
heap-alloc: 210.38MB (220601784 bytes)
heap-sys: 274.92MB (288276480 bytes)
heap-idle: 37.88MB (39723008 bytes)
heap-in-use: 237.04MB (248553472 bytes)
heap-released: 13.90MB (14573568 bytes)
heap-objects: 2071222
stack-in-use: 72.59MB (76120064 bytes)
stack-sys: 72.59MB (76120064 bytes)
stack-mspan-inuse: 3.55MB (3718400 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1115009 bytes)
gc-sys: 6.53MB (6847016 bytes)
next-gc: when heap-alloc >= 213.98MB (224373688 bytes)
last-gc: 2024-10-30 08:22:52.442756875 +0000 UTC
gc-pause-total: 15.468225ms
gc-pause: 1961970
gc-pause-end: 1730276572442756875
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005790571457019449
enable-gc: true
debug-gc: false
