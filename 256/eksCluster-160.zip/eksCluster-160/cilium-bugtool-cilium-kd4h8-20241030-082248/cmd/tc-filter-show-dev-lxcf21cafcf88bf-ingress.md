filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf21cafcf88bf direct-action not_in_hw id 612 tag d293f988fa5beb11 jited 
