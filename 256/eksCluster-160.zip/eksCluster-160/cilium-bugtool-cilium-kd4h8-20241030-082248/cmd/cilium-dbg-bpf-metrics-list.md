REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37852     2995431     677    bpf_overlay.c
Interface                 INGRESS     688362    137801411   1132   bpf_host.c
Success                   EGRESS      17698     1397911     1694   bpf_host.c
Success                   EGRESS      303524    37737053    1308   bpf_lxc.c
Success                   EGRESS      39117     3088377     53     encap.h
Success                   INGRESS     347049    39576873    86     l3.h
Success                   INGRESS     367854    41218439    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
