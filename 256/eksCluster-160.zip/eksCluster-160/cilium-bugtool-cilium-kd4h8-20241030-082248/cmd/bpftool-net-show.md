xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 496
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 484
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 479
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 480
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 535
lxc197ecdac836a(12) clsact/ingress cil_from_container-lxc197ecdac836a id 544
lxc8e91ec1da341(14) clsact/ingress cil_from_container-lxc8e91ec1da341 id 522
lxcf21cafcf88bf(18) clsact/ingress cil_from_container-lxcf21cafcf88bf id 612

flow_dissector:

netfilter:

