top - 08:22:50 up 32 min,  0 users,  load average: 0.12, 0.14, 0.12
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 38.7 us, 41.9 sy,  0.0 ni,  3.2 id,  0.0 wa,  0.0 hi, 16.1 si,  0.0 st
MiB Mem :   7814.2 total,   4463.2 free,   1204.4 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6424.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    735 root      20   0 1244340  23484  14396 S  53.3   0.3   0:00.15 hubble
      1 root      20   0 1606336 395960  78456 S  13.3   4.9   0:54.77 cilium-+
    417 root      20   0 1229744   8052   3840 S   0.0   0.1   0:01.18 cilium-+
    653 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    666 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    695 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    700 root      20   0 1240432  15976  10768 S   0.0   0.2   0:00.03 cilium-+
    706 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    729 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    755 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    769 root      20   0    1008    288    248 R   0.0   0.0   0:00.00 ip6tabl+
