Endpoint ID: 58
Path: /sys/fs/bpf/tc/globals/cilium_policy_00058

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    126631   1458      0        
Allow    Egress      0          ANY          NONE         disabled    18843    206       0        


Endpoint ID: 892
Path: /sys/fs/bpf/tc/globals/cilium_policy_00892

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    127351   1461      0        
Allow    Egress      0          ANY          NONE         disabled    17241    187       0        


Endpoint ID: 1195
Path: /sys/fs/bpf/tc/globals/cilium_policy_01195

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1572
Path: /sys/fs/bpf/tc/globals/cilium_policy_01572

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1647286   20876     0        
Allow    Ingress     1          ANY          NONE         disabled    19359     228       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3098
Path: /sys/fs/bpf/tc/globals/cilium_policy_03098

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11593328   116767    0        
Allow    Ingress     1          ANY          NONE         disabled    11893227   122483    0        
Allow    Egress      0          ANY          NONE         disabled    14490093   141553    0        


