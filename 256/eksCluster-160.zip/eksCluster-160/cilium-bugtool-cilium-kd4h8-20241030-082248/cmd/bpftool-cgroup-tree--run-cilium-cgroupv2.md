CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd74116f_1b3c_4c26_97bb_5d2c8de3e1e5.slice/cri-containerd-47318d331bfc860896a09acf4e2d10c3039a892c47e33818cfbd94660b8aa977.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd74116f_1b3c_4c26_97bb_5d2c8de3e1e5.slice/cri-containerd-bf8e604d8f87a050ce76e24d6664004dc19e570087f747fd083484f9809f11d7.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9fc5b42e_6900_4f01_8f32_89ca54e9435b.slice/cri-containerd-5c255ddebc76966ebf4ec0242ed0442135e8ea97a398cc5340a34221c8717345.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9fc5b42e_6900_4f01_8f32_89ca54e9435b.slice/cri-containerd-2937e9e8b5ca8c5d2c84108849e505480c2a884f8d602f61d165bd9f3f6c1b13.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a3fb7b8_463d_4ec9_9639_bb92e2f0bc3a.slice/cri-containerd-73624df9c2a3564d82cbe2121c590ed6ee19b285b83e6239fd8cdb45248b6b09.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1a3fb7b8_463d_4ec9_9639_bb92e2f0bc3a.slice/cri-containerd-34c180f67a3090dc843f5a7a9b86740e4fd6d37ecbbb5e381f2d5ca14f3d149b.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c05c278_0694_4a71_9a54_69c4ed126b7a.slice/cri-containerd-e0b9af512b47f3fb0cbbe0032c28bc07e08577a776be6a323e0d0c904d6508eb.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1c05c278_0694_4a71_9a54_69c4ed126b7a.slice/cri-containerd-89ec45072cdf7e84dd579af5db1ac4f877e20f44c7b0082ab89c50b0a4fdee3e.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-2c16e6aa8a4d5050095c1092ebd79b1b0e9a8ff44b0b617d8e3dc705962e74b1.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-c2978dd370f4454775112b0ea535dc944bdcb4a43c5a8bd519711dc0b59db261.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-28555d86f7bdfa2bf8fc6034f8296c96d217cadd61f4b8077bc0cc2259f231f1.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf1567cd4_260e_4cbc_8e78_8e58d727f350.slice/cri-containerd-746af2e13049fbba56386706c9cc74e7320cec8277527bce8922fcab2dfa327b.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df516b4_c0ed_4c5d_afdc_4bec963a64d2.slice/cri-containerd-e0db8470e9bc441380482e38e8c4bb3fbf64026f5fc2cebf4de56c5787607551.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4df516b4_c0ed_4c5d_afdc_4bec963a64d2.slice/cri-containerd-9417bfff36954fd1c9ff39bd17bbe3a2b418a4a875c5e540458e70faea6c9937.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3222de55_69b7_4257_a6b4_fbe123f6a3ff.slice/cri-containerd-0a0ac90dc913917b8e2f9992a5549d6e13f3ea01db58573527307e15b2638868.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3222de55_69b7_4257_a6b4_fbe123f6a3ff.slice/cri-containerd-1c892161b70ec8d61f324431ad1bcfab59f5c25c79a7ec5d52516a837abfdc85.scope
    99       cgroup_device   multi                                          
