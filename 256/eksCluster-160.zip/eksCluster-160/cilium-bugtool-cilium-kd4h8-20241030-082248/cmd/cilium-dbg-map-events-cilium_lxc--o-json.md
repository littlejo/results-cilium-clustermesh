{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.167.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:10.445Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:15.537Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:15.542Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:15.590Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:15.593Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.339Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.339Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.340Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:01.370Z",
  "value": "id=3005  sec_id=5280273 flags=0x0000 ifindex=16  mac=42:44:2A:F7:AC:F7 nodemac=4E:96:A5:10:E5:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.337Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.337Z",
  "value": "id=3005  sec_id=5280273 flags=0x0000 ifindex=16  mac=42:44:2A:F7:AC:F7 nodemac=4E:96:A5:10:E5:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.337Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:02.337Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.658Z",
  "value": "id=3098  sec_id=5280273 flags=0x0000 ifindex=18  mac=4E:81:7B:E5:86:F8 nodemac=2E:37:68:00:C8:D7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.160.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.381Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.647Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.647Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.648Z",
  "value": "id=3098  sec_id=5280273 flags=0x0000 ifindex=18  mac=4E:81:7B:E5:86:F8 nodemac=2E:37:68:00:C8:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.648Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.647Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.650Z",
  "value": "id=3098  sec_id=5280273 flags=0x0000 ifindex=18  mac=4E:81:7B:E5:86:F8 nodemac=2E:37:68:00:C8:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.651Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.652Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.647Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.647Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.647Z",
  "value": "id=3098  sec_id=5280273 flags=0x0000 ifindex=18  mac=4E:81:7B:E5:86:F8 nodemac=2E:37:68:00:C8:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.648Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.647Z",
  "value": "id=1572  sec_id=4     flags=0x0000 ifindex=10  mac=26:AD:14:35:85:AB nodemac=9E:B7:F4:E3:DD:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.647Z",
  "value": "id=3098  sec_id=5280273 flags=0x0000 ifindex=18  mac=4E:81:7B:E5:86:F8 nodemac=2E:37:68:00:C8:D7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.647Z",
  "value": "id=58    sec_id=5289128 flags=0x0000 ifindex=14  mac=0E:7E:07:71:3C:2F nodemac=F2:CC:0D:97:10:C4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.160.0.200:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:11.648Z",
  "value": "id=892   sec_id=5289128 flags=0x0000 ifindex=12  mac=BE:48:90:3E:53:47 nodemac=F2:62:44:B5:BB:82"
}

