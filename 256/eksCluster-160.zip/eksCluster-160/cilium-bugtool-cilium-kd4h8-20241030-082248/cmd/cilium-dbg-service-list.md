ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.164.102:443 (active)   
                                          2 => 172.31.228.45:443 (active)    
2    10.100.183.131:443    ClusterIP      1 => 172.31.169.97:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.160.0.200:53 (active)      
                                          2 => 10.160.0.2:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.160.0.200:9153 (active)    
                                          2 => 10.160.0.2:9153 (active)      
5    10.100.121.195:2379   ClusterIP      1 => 10.160.0.235:2379 (active)    
