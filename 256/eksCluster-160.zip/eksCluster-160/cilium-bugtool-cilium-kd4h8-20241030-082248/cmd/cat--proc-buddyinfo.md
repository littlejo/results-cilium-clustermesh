Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      2     90     42     35     14      7      2      5      3      0    861 
