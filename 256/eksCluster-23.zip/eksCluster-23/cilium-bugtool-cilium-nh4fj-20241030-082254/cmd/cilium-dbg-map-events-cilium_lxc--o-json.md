{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.683Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.198.128:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.683Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.200.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:23.683Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:28.650Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:28.671Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:28.708Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:28.798Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:28.898Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:40.758Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:40.758Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:40.758Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:40.791Z",
  "value": "id=1245  sec_id=802820 flags=0x0000 ifindex=16  mac=62:DA:59:4D:FD:25 nodemac=FA:6A:01:76:F0:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:41.758Z",
  "value": "id=1245  sec_id=802820 flags=0x0000 ifindex=16  mac=62:DA:59:4D:FD:25 nodemac=FA:6A:01:76:F0:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:41.758Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:41.758Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:41.759Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.439Z",
  "value": "id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.23.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.806Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.680Z",
  "value": "id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.682Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.682Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:06.682Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.652Z",
  "value": "id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.658Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.659Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:07.660Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.649Z",
  "value": "id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.649Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.650Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:08.650Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.649Z",
  "value": "id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.649Z",
  "value": "id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.649Z",
  "value": "id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.23.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:09.650Z",
  "value": "id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A"
}

