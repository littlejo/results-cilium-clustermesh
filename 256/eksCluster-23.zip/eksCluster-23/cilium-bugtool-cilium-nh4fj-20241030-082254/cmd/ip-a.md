1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:5c:a1:7f:38:a5 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.198.128/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3105sec preferred_lft 3105sec
    inet6 fe80::85c:a1ff:fe7f:38a5/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:bb:b7:17:4c:5d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.200.190/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8bb:b7ff:fe17:4c5d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:ed:2f:52:f7:a8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::74ed:2fff:fe52:f7a8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:48:f6:a1:6f:3f brd ff:ff:ff:ff:ff:ff
    inet 10.23.0.219/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1848:f6ff:fea1:6f3f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:5a:19:b0:24:e2 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::345a:19ff:feb0:24e2/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:3d:93:1b:4f:8a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3d:93ff:fe1b:4f8a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca322f33601d4@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:2b:cf:02:8a:7f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c2b:cfff:fe02:8a7f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce31d44c3c43a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:c9:d0:d5:fb:ca brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b0c9:d0ff:fed5:fbca/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca0f8f380169b@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:d8:6d:04:43:98 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9cd8:6dff:fe04:4398/64 scope link 
       valid_lft forever preferred_lft forever
