xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 574
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 560
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 554
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 505
lxca322f33601d4(12) clsact/ingress cil_from_container-lxca322f33601d4 id 518
lxce31d44c3c43a(14) clsact/ingress cil_from_container-lxce31d44c3c43a id 544
lxca0f8f380169b(18) clsact/ingress cil_from_container-lxca0f8f380169b id 629

flow_dissector:

netfilter:

