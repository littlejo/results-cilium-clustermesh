[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98db6175_da99_4946_a9c8_1d05d12281d3.slice/cri-containerd-36506dacba2f436e860a33d340338019c3b3fcae16bc5a63b8196b7b8fc18072.scope"
      }
    ],
    "ips": [
      "10.23.0.13"
    ],
    "name": "coredns-cc6ccd49c-6t7dq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-d59a90c81f493c3a3a274049948c21eb0424a250361a4cf5aca0893bc8fa4a1a.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-ca2f9d02d7eaae02452b6087ea76cda3cf74114e7c79eb91de9805ddbd68600a.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-7243d558c8223cba146135e0277cc94eba4553c98fc74ff300603d92758572f0.scope"
      }
    ],
    "ips": [
      "10.23.0.195"
    ],
    "name": "clustermesh-apiserver-78fc77ffc5-qwtvg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeebb506_a336_4263_bce6_be7aceeab864.slice/cri-containerd-6b9ad8d8e9cbbf73f2d0e170a3a378c6d18e70bc9f632360020b02b84da4143e.scope"
      }
    ],
    "ips": [
      "10.23.0.253"
    ],
    "name": "coredns-cc6ccd49c-p6j92",
    "namespace": "kube-system"
  }
]

