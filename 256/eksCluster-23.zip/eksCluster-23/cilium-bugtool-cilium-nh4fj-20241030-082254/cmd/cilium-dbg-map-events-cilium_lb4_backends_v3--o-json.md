{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:21.568Z",
  "value": "ANY://172.31.155.135"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:21.568Z",
  "value": "ANY://172.31.209.243"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:24.356Z",
  "value": "ANY://172.31.198.128"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.905Z",
  "value": "ANY://10.23.0.13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.905Z",
  "value": "ANY://10.23.0.13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.935Z",
  "value": "ANY://10.23.0.253"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:29.935Z",
  "value": "ANY://10.23.0.253"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:51.501Z",
  "value": "ANY://10.23.0.233"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.299Z",
  "value": "ANY://10.23.0.195"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.410Z",
  "value": "ANY://10.23.0.233"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.897Z",
  "value": "\u003cnil\u003e"
}

