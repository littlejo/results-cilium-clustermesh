filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca0f8f380169b direct-action not_in_hw id 629 tag 94c724f5191f28ca jited 
