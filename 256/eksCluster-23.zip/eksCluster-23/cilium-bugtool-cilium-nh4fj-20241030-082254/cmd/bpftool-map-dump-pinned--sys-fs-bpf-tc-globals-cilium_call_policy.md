key: b6 00 00 00  value: 1b 02 00 00
key: e5 00 00 00  value: 6d 02 00 00
key: 19 03 00 00  value: f8 01 00 00
key: 31 03 00 00  value: 04 02 00 00
Found 4 elements
