KEY             VALUE
AgentLiveness   2338246543007
UTimeOffset     3379441929687500
