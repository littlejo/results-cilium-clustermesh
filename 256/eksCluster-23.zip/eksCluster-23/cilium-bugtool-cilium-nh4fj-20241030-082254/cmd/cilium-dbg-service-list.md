ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.155.135:443 (active)    
                                         2 => 172.31.209.243:443 (active)    
2    10.100.110.177:443   ClusterIP      1 => 172.31.198.128:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.23.0.13:53 (active)         
                                         2 => 10.23.0.253:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.23.0.13:9153 (active)       
                                         2 => 10.23.0.253:9153 (active)      
5    10.100.60.125:2379   ClusterIP      1 => 10.23.0.195:2379 (active)      
