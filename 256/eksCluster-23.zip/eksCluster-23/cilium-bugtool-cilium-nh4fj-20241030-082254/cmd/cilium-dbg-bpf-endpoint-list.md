IP ADDRESS         LOCAL ENDPOINT INFO
172.31.198.128:0   (localhost)                                                                                       
10.23.0.253:0      id=182   sec_id=799615 flags=0x0000 ifindex=14  mac=26:C4:FF:7B:87:AB nodemac=B2:C9:D0:D5:FB:CA   
10.23.0.195:0      id=229   sec_id=802820 flags=0x0000 ifindex=18  mac=CE:7E:FF:1F:EA:98 nodemac=9E:D8:6D:04:43:98   
10.23.0.219:0      (localhost)                                                                                       
10.23.0.13:0       id=817   sec_id=799615 flags=0x0000 ifindex=12  mac=5E:C3:1D:75:25:65 nodemac=4E:2B:CF:02:8A:7F   
172.31.200.190:0   (localhost)                                                                                       
10.23.0.199:0      id=793   sec_id=4     flags=0x0000 ifindex=10  mac=9E:6A:B1:88:D5:26 nodemac=02:3D:93:1B:4F:8A    
