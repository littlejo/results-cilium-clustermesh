CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeebb506_a336_4263_bce6_be7aceeab864.slice/cri-containerd-6b9ad8d8e9cbbf73f2d0e170a3a378c6d18e70bc9f632360020b02b84da4143e.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddeebb506_a336_4263_bce6_be7aceeab864.slice/cri-containerd-db9df159a65f54475626c880d9a8e9663e70d08bf6bcb4f95d8d994083036a9d.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c492a2d_e4c3_476f_982d_906ba00c3ac8.slice/cri-containerd-383ce8b5d373a5bafc8edad45888c0e72e2b4fe2a74b91323cfb36ec3349b74a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c492a2d_e4c3_476f_982d_906ba00c3ac8.slice/cri-containerd-556e398abf1ffdbc71b4cd909615704a05e51ef8d47d4623e705f28289e01ebd.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf70696b2_5e2d_41ec_9dd7_534670e6532d.slice/cri-containerd-4431159fa52f5721ef1a5feb98163a385221330cd3486e97fd8f352985d9c83a.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf70696b2_5e2d_41ec_9dd7_534670e6532d.slice/cri-containerd-01857e101c5868b969e41e275c7984262f123ef66a1cbd15a913769d69f71eb7.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98db6175_da99_4946_a9c8_1d05d12281d3.slice/cri-containerd-c774a8868a49b0d723cf1beb385bbaba40862111b92cb7da2dc97ac29c6c3d94.scope
    527      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98db6175_da99_4946_a9c8_1d05d12281d3.slice/cri-containerd-36506dacba2f436e860a33d340338019c3b3fcae16bc5a63b8196b7b8fc18072.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a4614dd_3b02_4e60_b2c1_e4e056ef1d51.slice/cri-containerd-64dfff07e837403cc8f8b4f320cb2c0c62f36f074a7d3a71d27c1e3f382a68d8.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a4614dd_3b02_4e60_b2c1_e4e056ef1d51.slice/cri-containerd-77d615fbca23195ac5235c244f661aa4bf24587db3502bdda4b3c5058e2ccb6b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ff696e3_6a19_4b1b_8a2a_05fc9fa4ad58.slice/cri-containerd-91a2ad3d2d594702c5df6f65b5c174e8d6b27e4578aa4c1266933b0b54530d7d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0ff696e3_6a19_4b1b_8a2a_05fc9fa4ad58.slice/cri-containerd-3f901422e5d009c6c086f1d7ed9b28c9bd08aa7a748764b6b89341db92883e88.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-d09639b322dfa938ce40f7458e243cda74fd7bbe4084a6b75dde13303511744f.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-7243d558c8223cba146135e0277cc94eba4553c98fc74ff300603d92758572f0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-d59a90c81f493c3a3a274049948c21eb0424a250361a4cf5aca0893bc8fa4a1a.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7a8a3db1_4da0_4143_94c6_ea216bc18350.slice/cri-containerd-ca2f9d02d7eaae02452b6087ea76cda3cf74114e7c79eb91de9805ddbd68600a.scope
    650      cgroup_device   multi                                          
