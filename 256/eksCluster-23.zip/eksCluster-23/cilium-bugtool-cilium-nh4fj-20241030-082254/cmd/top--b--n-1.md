top - 08:22:55 up 38 min,  0 users,  load average: 0.21, 0.32, 0.25
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.3 us, 23.3 sy,  0.0 ni, 63.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4466.9 free,   1199.8 used,   2147.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380536  77692 S   6.7   4.8   1:05.69 cilium-+
    406 root      20   0 1229488   7864   3900 S   0.0   0.1   0:01.19 cilium-+
    647 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    648 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    657 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    663 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1240432  15516  10640 S   0.0   0.2   0:00.02 cilium-+
    710 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    728 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
