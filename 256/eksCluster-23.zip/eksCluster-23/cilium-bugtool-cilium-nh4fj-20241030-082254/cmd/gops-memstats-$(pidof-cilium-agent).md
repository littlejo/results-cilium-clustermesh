alloc: 173.91MB (182359600 bytes)
total-alloc: 2.36GB (2529980256 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 65081748
frees: 63356446
heap-alloc: 173.91MB (182359600 bytes)
heap-sys: 243.70MB (255541248 bytes)
heap-idle: 44.25MB (46399488 bytes)
heap-in-use: 199.45MB (209141760 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 1725302
stack-in-use: 64.25MB (67371008 bytes)
stack-sys: 64.25MB (67371008 bytes)
stack-mspan-inuse: 3.08MB (3234080 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1271025 bytes)
gc-sys: 6.03MB (6327856 bytes)
next-gc: when heap-alloc >= 212.65MB (222977592 bytes)
last-gc: 2024-10-30 08:22:59.656089826 +0000 UTC
gc-pause-total: 14.063881ms
gc-pause: 76536
gc-pause-end: 1730276579656089826
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003946456041289699
enable-gc: true
debug-gc: false
