Endpoint ID: 178
Path: /sys/fs/bpf/tc/globals/cilium_policy_00178

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 182
Path: /sys/fs/bpf/tc/globals/cilium_policy_00182

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178221   2047      0        
Allow    Egress      0          ANY          NONE         disabled    20815    233       0        


Endpoint ID: 229
Path: /sys/fs/bpf/tc/globals/cilium_policy_00229

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11579166   116602    0        
Allow    Ingress     1          ANY          NONE         disabled    10593781   111894    0        
Allow    Egress      0          ANY          NONE         disabled    14512849   141887    0        


Endpoint ID: 793
Path: /sys/fs/bpf/tc/globals/cilium_policy_00793

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669634   21134     0        
Allow    Ingress     1          ANY          NONE         disabled    27056     317       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 817
Path: /sys/fs/bpf/tc/globals/cilium_policy_00817

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    178118   2051      0        
Allow    Egress      0          ANY          NONE         disabled    21874    245       0        


