markdown output at /tmp/cilium-bugtool-20241030-082255.204+0000-UTC-2934889185/cmd/cilium-debuginfo-20241030-082326.316+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.204+0000-UTC-2934889185/cmd/cilium-debuginfo-20241030-082326.316+0000-UTC.json
