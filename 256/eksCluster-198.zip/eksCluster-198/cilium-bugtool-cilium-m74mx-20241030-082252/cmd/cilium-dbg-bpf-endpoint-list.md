IP ADDRESS         LOCAL ENDPOINT INFO
10.198.0.133:0     id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27   
172.31.146.99:0    (localhost)                                                                                        
10.198.0.167:0     (localhost)                                                                                        
10.198.0.190:0     id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18   
10.198.0.201:0     id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A     
10.198.0.138:0     id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC   
172.31.171.254:0   (localhost)                                                                                        
