[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a32289_c2bd_4ca2_8b3e_3ea9070628f8.slice/cri-containerd-e541b5f3701d8935574bbd46e9e54d9c484d133b8702fa6e1a93c072d0dfd8f3.scope"
      }
    ],
    "ips": [
      "10.198.0.133"
    ],
    "name": "coredns-cc6ccd49c-hpdv9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-bc3840814a17acca64a404e434b49fb001836c0081e7462657f91eb6c86040c6.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-c1853ba41c2d891300f5f5f6e5edc5e32794686cfe723988a322935ccd889adb.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-f499ae891c73531f4c06fb48fcaf324c5b86f9db9a4cbfed21e0f9566aef8ac8.scope"
      }
    ],
    "ips": [
      "10.198.0.138"
    ],
    "name": "clustermesh-apiserver-58c9b64c8-gtmkv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod272f66cf_7145_4cb3_ba6d_e5f610030e35.slice/cri-containerd-75abfb64a11f336fe8fa490e6abfd30c5ce4397c0ec77b34f83db058d8c11dd3.scope"
      }
    ],
    "ips": [
      "10.198.0.190"
    ],
    "name": "coredns-cc6ccd49c-x8t5l",
    "namespace": "kube-system"
  }
]

