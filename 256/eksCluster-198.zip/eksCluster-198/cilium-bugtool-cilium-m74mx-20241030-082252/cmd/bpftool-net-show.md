xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 556
ens6(5) clsact/ingress cil_from_netdev-ens6 id 565
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 547
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 542
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 572
lxc802da3752687(12) clsact/ingress cil_from_container-lxc802da3752687 id 532
lxcb49431397616(14) clsact/ingress cil_from_container-lxcb49431397616 id 555
lxc8ac64e5c9a4f(18) clsact/ingress cil_from_container-lxc8ac64e5c9a4f id 648

flow_dissector:

netfilter:

