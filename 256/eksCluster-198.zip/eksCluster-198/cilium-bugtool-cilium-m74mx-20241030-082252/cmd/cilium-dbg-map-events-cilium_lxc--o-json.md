{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.194Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.146.99:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.194Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.171.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.194Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.832Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.835Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.886Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:22.902Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.337Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.338Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.339Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:04.375Z",
  "value": "id=958   sec_id=6542885 flags=0x0000 ifindex=16  mac=A6:AC:98:25:1C:48 nodemac=5A:B7:AB:28:AE:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.338Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.339Z",
  "value": "id=958   sec_id=6542885 flags=0x0000 ifindex=16  mac=A6:AC:98:25:1C:48 nodemac=5A:B7:AB:28:AE:A7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.339Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:05.339Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:57.376Z",
  "value": "id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.198.0.250:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.696Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.658Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.659Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.659Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:55.670Z",
  "value": "id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.659Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.660Z",
  "value": "id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.661Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:56.661Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.658Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.658Z",
  "value": "id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.658Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:57.658Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.138:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.658Z",
  "value": "id=500   sec_id=6542885 flags=0x0000 ifindex=18  mac=C2:CF:14:11:5F:EF nodemac=E2:FB:92:C4:0C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.659Z",
  "value": "id=1841  sec_id=4     flags=0x0000 ifindex=10  mac=A2:6E:27:A1:EC:32 nodemac=3A:E4:E3:50:70:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.659Z",
  "value": "id=319   sec_id=6539077 flags=0x0000 ifindex=12  mac=D6:92:0D:4A:2E:17 nodemac=52:0F:35:7F:3B:18"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.198.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:58.659Z",
  "value": "id=8     sec_id=6539077 flags=0x0000 ifindex=14  mac=C6:3B:94:C2:05:69 nodemac=8A:1F:21:65:16:27"
}

