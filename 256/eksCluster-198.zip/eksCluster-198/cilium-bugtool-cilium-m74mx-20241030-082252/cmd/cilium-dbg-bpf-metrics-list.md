REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37941     3008467     677    bpf_overlay.c
Interface                 INGRESS     666265    134618094   1132   bpf_host.c
Success                   EGRESS      17745     1401056     1694   bpf_host.c
Success                   EGRESS      284458    35226480    1308   bpf_lxc.c
Success                   EGRESS      38864     3075158     53     encap.h
Success                   INGRESS     326512    37079417    86     l3.h
Success                   INGRESS     347359    38730874    235    trace.h
Unsupported L3 protocol   EGRESS      37        2726        1492   bpf_lxc.c
