key: 08 00 00 00  value: 3e 02 00 00
key: 3f 01 00 00  value: 06 02 00 00
key: f4 01 00 00  value: 85 02 00 00
key: 31 07 00 00  value: 3f 02 00 00
Found 4 elements
