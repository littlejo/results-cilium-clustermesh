 08:22:53 up 29 min,  0 users,  load average: 0.18, 0.25, 0.22
