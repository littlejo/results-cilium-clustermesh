alloc: 149.38MB (156634112 bytes)
total-alloc: 2.30GB (2473912832 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64471873
frees: 63019508
heap-alloc: 149.38MB (156634112 bytes)
heap-sys: 243.08MB (254885888 bytes)
heap-idle: 58.59MB (61431808 bytes)
heap-in-use: 184.49MB (193454080 bytes)
heap-released: 0 bytes
heap-objects: 1452365
stack-in-use: 64.88MB (68026368 bytes)
stack-sys: 64.88MB (68026368 bytes)
stack-mspan-inuse: 3.10MB (3255680 bytes)
stack-mspan-sys: 3.89MB (4080000 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.86KB (1006449 bytes)
gc-sys: 6.00MB (6286680 bytes)
next-gc: when heap-alloc >= 218.21MB (228807432 bytes)
last-gc: 2024-10-30 08:23:04.576969602 +0000 UTC
gc-pause-total: 17.924131ms
gc-pause: 66430
gc-pause-end: 1730276584576969602
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005527015331160736
enable-gc: true
debug-gc: false
