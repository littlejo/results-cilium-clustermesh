markdown output at /tmp/cilium-bugtool-20241030-082253.441+0000-UTC-694608250/cmd/cilium-debuginfo-20241030-082324.689+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082253.441+0000-UTC-694608250/cmd/cilium-debuginfo-20241030-082324.689+0000-UTC.json
