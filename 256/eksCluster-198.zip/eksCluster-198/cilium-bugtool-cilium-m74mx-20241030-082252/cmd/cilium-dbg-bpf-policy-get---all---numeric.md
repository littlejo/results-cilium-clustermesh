Endpoint ID: 8
Path: /sys/fs/bpf/tc/globals/cilium_policy_00008

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114370   1311      0        
Allow    Egress      0          ANY          NONE         disabled    17206    186       0        


Endpoint ID: 319
Path: /sys/fs/bpf/tc/globals/cilium_policy_00319

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114106   1307      0        
Allow    Egress      0          ANY          NONE         disabled    16543    177       0        


Endpoint ID: 500
Path: /sys/fs/bpf/tc/globals/cilium_policy_00500

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11589056   116615    0        
Allow    Ingress     1          ANY          NONE         disabled    10711550   113131    0        
Allow    Egress      0          ANY          NONE         disabled    14509197   141777    0        


Endpoint ID: 502
Path: /sys/fs/bpf/tc/globals/cilium_policy_00502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1841
Path: /sys/fs/bpf/tc/globals/cilium_policy_01841

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1653838   20879     0        
Allow    Ingress     1          ANY          NONE         disabled    18154     213       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


