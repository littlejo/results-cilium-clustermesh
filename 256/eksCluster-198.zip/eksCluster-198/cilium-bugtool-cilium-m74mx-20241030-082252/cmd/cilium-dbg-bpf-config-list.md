KEY             VALUE
AgentLiveness   1779753734873
UTimeOffset     3379443017578125
