ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.172.132:443 (active)   
                                          2 => 172.31.213.3:443 (active)     
2    10.100.196.56:443     ClusterIP      1 => 172.31.146.99:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.198.0.190:53 (active)      
                                          2 => 10.198.0.133:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.198.0.190:9153 (active)    
                                          2 => 10.198.0.133:9153 (active)    
5    10.100.135.167:2379   ClusterIP      1 => 10.198.0.138:2379 (active)    
