CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc48735de_7f18_464f_9f3a_39dbb95957cf.slice/cri-containerd-036d504330aedf867234cc9177520664de936255d0a80f6e71f6fb69273a306b.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc48735de_7f18_464f_9f3a_39dbb95957cf.slice/cri-containerd-2d42d3146f376da84bc9eb26f5f0762665fbd17d341f136c71157e27074731c6.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod589ab602_64f0_4411_8856_839f16e3ca04.slice/cri-containerd-2c8fe2eeb8fab3f07bd42e6edb8cf6d13482dee50feecb82194a41cc3aacfcf5.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod589ab602_64f0_4411_8856_839f16e3ca04.slice/cri-containerd-848cb3b9900098052750a0031896d92406958235c41c6e98dcb72216bc204145.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a32289_c2bd_4ca2_8b3e_3ea9070628f8.slice/cri-containerd-e541b5f3701d8935574bbd46e9e54d9c484d133b8702fa6e1a93c072d0dfd8f3.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4a32289_c2bd_4ca2_8b3e_3ea9070628f8.slice/cri-containerd-6d78e89aca29d1ab3cb9888ecfd1a413c923686fe14b5744cc60fdaf6f41f282.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod272f66cf_7145_4cb3_ba6d_e5f610030e35.slice/cri-containerd-75abfb64a11f336fe8fa490e6abfd30c5ce4397c0ec77b34f83db058d8c11dd3.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod272f66cf_7145_4cb3_ba6d_e5f610030e35.slice/cri-containerd-1188bf3f09c5ef265fed7073f9baed784e18e26dcbef567513d28601f95a7869.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-7f9c9a9a730e639217ed24cf0d6d2d207a867b1164ac2288572992a205732e4f.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-bc3840814a17acca64a404e434b49fb001836c0081e7462657f91eb6c86040c6.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-f499ae891c73531f4c06fb48fcaf324c5b86f9db9a4cbfed21e0f9566aef8ac8.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0edf4f61_47e1_4648_ad4e_8aa5e99a2322.slice/cri-containerd-c1853ba41c2d891300f5f5f6e5edc5e32794686cfe723988a322935ccd889adb.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22b226c9_d2d9_42b5_8cb1_3ddc1ed4bce7.slice/cri-containerd-b2b896638873d2d5691d62ffc5643bd6627c0839381408e3eb3e397226f8798d.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod22b226c9_d2d9_42b5_8cb1_3ddc1ed4bce7.slice/cri-containerd-595e9f78289ea7daca903f42f5ddee09270efcbd994faf244b42b1b270a74939.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68908411_366c_4c1a_8caf_3d9e11d0aa92.slice/cri-containerd-8d92a2fb7ceb70db9b6356cb3846629418cbd95045ba9868d58174c5d74e80f2.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod68908411_366c_4c1a_8caf_3d9e11d0aa92.slice/cri-containerd-523b9f19b5bd68c6b278bc0090283fc454c43bc75c76be61ea52ccb9b4340392.scope
    102      cgroup_device   multi                                          
