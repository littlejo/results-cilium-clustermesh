KEY             VALUE
AgentLiveness   2134428152586
UTimeOffset     3379442341796875
