Endpoint ID: 31
Path: /sys/fs/bpf/tc/globals/cilium_policy_00031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 179
Path: /sys/fs/bpf/tc/globals/cilium_policy_00179

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1675362   21170     0        
Allow    Ingress     1          ANY          NONE         disabled    24574     287       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 206
Path: /sys/fs/bpf/tc/globals/cilium_policy_00206

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    160263   1839      0        
Allow    Egress      0          ANY          NONE         disabled    19985    223       0        


Endpoint ID: 763
Path: /sys/fs/bpf/tc/globals/cilium_policy_00763

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11524144   113908    0        
Allow    Ingress     1          ANY          NONE         disabled    9885913    103941    0        
Allow    Egress      0          ANY          NONE         disabled    12025166   119310    0        


Endpoint ID: 956
Path: /sys/fs/bpf/tc/globals/cilium_policy_00956

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    161649   1860      0        
Allow    Egress      0          ANY          NONE         disabled    19295    214       0        


