{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.202.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.221.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:34.414Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:34.414Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:34.469Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:34.516Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:34.601Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:36.364Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:36.364Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:36.364Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:36.396Z",
  "value": "id=1187  sec_id=3293300 flags=0x0000 ifindex=16  mac=EE:18:4B:0B:6B:A6 nodemac=C6:FA:3D:B7:07:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:37.364Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:37.364Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:37.364Z",
  "value": "id=1187  sec_id=3293300 flags=0x0000 ifindex=16  mac=EE:18:4B:0B:6B:A6 nodemac=C6:FA:3D:B7:07:92"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:37.364Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.708Z",
  "value": "id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.99.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.205Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.791Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.791Z",
  "value": "id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.792Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.793Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.877Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.884Z",
  "value": "id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.885Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.886Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.797Z",
  "value": "id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.798Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.799Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.799Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.798Z",
  "value": "id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.799Z",
  "value": "id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.799Z",
  "value": "id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.99.0.84:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.800Z",
  "value": "id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD"
}

