 08:23:02 up 35 min,  0 users,  load average: 0.45, 0.38, 0.23
