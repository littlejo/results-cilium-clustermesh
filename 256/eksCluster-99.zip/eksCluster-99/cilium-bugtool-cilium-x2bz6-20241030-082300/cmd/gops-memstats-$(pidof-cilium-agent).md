alloc: 192.63MB (201982736 bytes)
total-alloc: 2.28GB (2445882344 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63783819
frees: 61850372
heap-alloc: 192.63MB (201982736 bytes)
heap-sys: 243.45MB (255279104 bytes)
heap-idle: 26.61MB (27901952 bytes)
heap-in-use: 216.84MB (227377152 bytes)
heap-released: 888.00KB (909312 bytes)
heap-objects: 1933447
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.35MB (3513440 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.01MB (1060721 bytes)
gc-sys: 6.01MB (6301064 bytes)
next-gc: when heap-alloc >= 215.51MB (225982696 bytes)
last-gc: 2024-10-30 08:23:01.504343435 +0000 UTC
gc-pause-total: 23.341725ms
gc-pause: 2178474
gc-pause-end: 1730276581504343435
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004482710181573084
enable-gc: true
debug-gc: false
