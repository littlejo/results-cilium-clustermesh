ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.144.113:443 (active)    
                                         2 => 172.31.248.172:443 (active)    
2    10.100.100.151:443   ClusterIP      1 => 172.31.202.187:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.99.0.198:53 (active)        
                                         2 => 10.99.0.139:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.99.0.198:9153 (active)      
                                         2 => 10.99.0.139:9153 (active)      
5    10.100.18.247:2379   ClusterIP      1 => 10.99.0.84:2379 (active)       
