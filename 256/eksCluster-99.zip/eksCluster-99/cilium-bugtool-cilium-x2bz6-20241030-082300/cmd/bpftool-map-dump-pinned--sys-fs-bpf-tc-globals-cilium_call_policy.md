key: b3 00 00 00  value: 13 02 00 00
key: ce 00 00 00  value: 03 02 00 00
key: fb 02 00 00  value: 70 02 00 00
key: bc 03 00 00  value: 02 02 00 00
Found 4 elements
