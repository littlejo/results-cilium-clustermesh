Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      6      6      1     19    132    125     63     23      7      4    858 
