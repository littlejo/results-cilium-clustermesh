[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod649a019d_e537_49f7_82a4_76c71f001229.slice/cri-containerd-7893cd13c97e0ffae2fd8d23953044583b3ac885123cd206f2753198d38ae2d6.scope"
      }
    ],
    "ips": [
      "10.99.0.198"
    ],
    "name": "coredns-cc6ccd49c-vwkfr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-12f385d05718b6264daf30db7d105c9dfb1b602fe93c71a08ce915b85187962c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-0ca58e0f96d68ed6bf648de1841bb9ed616b0730b34eb3a43fcb100aeac6b8ec.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-3b0c5d4f45d532e5b7c1615ef641338987f0ef23f18d0dbe354d264cd0c0bdf4.scope"
      }
    ],
    "ips": [
      "10.99.0.84"
    ],
    "name": "clustermesh-apiserver-84b46dbd69-q99cd",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01715c1e_bdbf_4a8f_bdff_77b8ece5d8ce.slice/cri-containerd-153d32958df8353515d46d5034b094bc17d51494db1c377bc1321abb4b3df19c.scope"
      }
    ],
    "ips": [
      "10.99.0.139"
    ],
    "name": "coredns-cc6ccd49c-96mxk",
    "namespace": "kube-system"
  }
]

