REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37047     2930711     677    bpf_overlay.c
Interface                 INGRESS     643483    132174499   1132   bpf_host.c
Success                   EGRESS      16594     1304795     1694   bpf_host.c
Success                   EGRESS      269523    34035387    1308   bpf_lxc.c
Success                   EGRESS      37080     2935737     53     encap.h
Success                   INGRESS     313464    35122906    86     l3.h
Success                   INGRESS     334568    36792868    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
