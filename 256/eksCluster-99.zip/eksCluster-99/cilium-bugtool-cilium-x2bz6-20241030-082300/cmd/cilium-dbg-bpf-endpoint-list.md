IP ADDRESS         LOCAL ENDPOINT INFO
172.31.221.188:0   (localhost)                                                                                        
10.99.0.198:0      id=206   sec_id=3278065 flags=0x0000 ifindex=12  mac=96:83:46:BD:90:17 nodemac=06:49:64:C0:40:57   
10.99.0.191:0      (localhost)                                                                                        
10.99.0.84:0       id=763   sec_id=3293300 flags=0x0000 ifindex=18  mac=8E:5B:1C:F1:5A:CD nodemac=76:B5:78:27:C0:BD   
172.31.202.187:0   (localhost)                                                                                        
10.99.0.143:0      id=179   sec_id=4     flags=0x0000 ifindex=10  mac=CA:3A:E8:C3:B2:C5 nodemac=9E:0E:00:B1:A2:FA     
10.99.0.139:0      id=956   sec_id=3278065 flags=0x0000 ifindex=14  mac=C2:CB:C3:6D:D2:D5 nodemac=5E:7F:53:E0:54:66   
