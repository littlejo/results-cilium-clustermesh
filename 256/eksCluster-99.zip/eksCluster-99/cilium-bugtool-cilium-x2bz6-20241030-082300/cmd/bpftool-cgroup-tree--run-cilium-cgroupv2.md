CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb260d1e0_b0f4_4e6b_989c_98e00adc2aea.slice/cri-containerd-cbc8cd12a1c8418e86e510bba59a220f51e7abdf641ab7f046090534a84068ca.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb260d1e0_b0f4_4e6b_989c_98e00adc2aea.slice/cri-containerd-ef23ee74b2b3b7b115c9de7c31cd72b38a09aec800e84c2e71c93d025a5c2f62.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod649a019d_e537_49f7_82a4_76c71f001229.slice/cri-containerd-7893cd13c97e0ffae2fd8d23953044583b3ac885123cd206f2753198d38ae2d6.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod649a019d_e537_49f7_82a4_76c71f001229.slice/cri-containerd-96d4ecda032b15e309ab935f43fc345a91e96432da3485d7a1b4bfb2b19705a5.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0200de3c_d6ff_4aa2_8050_9f9b856f1bad.slice/cri-containerd-e1857a267d740fea385fa1fd7141661dd21ec29c8036f5d843e0743d6ea03db0.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0200de3c_d6ff_4aa2_8050_9f9b856f1bad.slice/cri-containerd-14996bb1eaa0814e84edbb6b36d0d772d96a0f86d48b292dd73d01989340c96d.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01715c1e_bdbf_4a8f_bdff_77b8ece5d8ce.slice/cri-containerd-4f3c3b29f71c87979dd6111c131b5d1f813e659565402532e53e988ab00d6078.scope
    544      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod01715c1e_bdbf_4a8f_bdff_77b8ece5d8ce.slice/cri-containerd-153d32958df8353515d46d5034b094bc17d51494db1c377bc1321abb4b3df19c.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-2a6dd2e0def85a2aff50186e5cce6132baae2c16eb071887705beed6cd64168d.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-3b0c5d4f45d532e5b7c1615ef641338987f0ef23f18d0dbe354d264cd0c0bdf4.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-0ca58e0f96d68ed6bf648de1841bb9ed616b0730b34eb3a43fcb100aeac6b8ec.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf537f736_1cce_4335_8021_4abb437cb989.slice/cri-containerd-12f385d05718b6264daf30db7d105c9dfb1b602fe93c71a08ce915b85187962c.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cf9b49f_64d0_46d6_903b_963c48ec85cd.slice/cri-containerd-255a9f4cbbb03c1786597f217df20e8cb40f8af1575029c3e2ea3088bd3c5314.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5cf9b49f_64d0_46d6_903b_963c48ec85cd.slice/cri-containerd-1d264ebb8a438263850c145d4b12093a9f47313dd29a848e7cb6e4c09fbca5a8.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74bf3619_d684_42b9_b122_1c34e7dc858b.slice/cri-containerd-1d39c59c1d6f2b3d13625605a5cd922202b570291db4b4d53f52697dd9f6e747.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod74bf3619_d684_42b9_b122_1c34e7dc858b.slice/cri-containerd-16d32b46fd3a79cb41fc667daafc8d4ee578732c6dc0ddaf3f3bb5cefd8d3467.scope
    91       cgroup_device   multi                                          
