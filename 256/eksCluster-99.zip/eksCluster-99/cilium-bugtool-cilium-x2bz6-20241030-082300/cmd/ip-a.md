1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9c:da:34:fa:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.202.187/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3311sec preferred_lft 3311sec
    inet6 fe80::89c:daff:fe34:fa9b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:2f:96:34:93:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.221.188/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::82f:96ff:fe34:939b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:cb:ec:87:f8:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cccb:ecff:fe87:f8af/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:41:d8:40:9f:55 brd ff:ff:ff:ff:ff:ff
    inet 10.99.0.191/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::c041:d8ff:fe40:9f55/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 86:82:65:dd:b2:f4 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::8482:65ff:fedd:b2f4/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:0e:00:b1:a2:fa brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9c0e:ff:feb1:a2fa/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc8d12e67df360@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:49:64:c0:40:57 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::449:64ff:fec0:4057/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc811bfecabb3a@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:7f:53:e0:54:66 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5c7f:53ff:fee0:5466/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb16729d6f57e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:b5:78:27:c0:bd brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::74b5:78ff:fe27:c0bd/64 scope link 
       valid_lft forever preferred_lft forever
