REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36744     2908760     677    bpf_overlay.c
Interface                 INGRESS     670493    136341433   1132   bpf_host.c
Success                   EGRESS      16661     1309656     1694   bpf_host.c
Success                   EGRESS      23912     3789880     86     l3.h
Success                   EGRESS      292005    35734002    1308   bpf_lxc.c
Success                   EGRESS      37394     2949229     53     encap.h
Success                   INGRESS     334214    38118496    86     l3.h
Success                   INGRESS     378860    43551526    235    trace.h
Unsupported L3 protocol   EGRESS      42        3136        1492   bpf_lxc.c
