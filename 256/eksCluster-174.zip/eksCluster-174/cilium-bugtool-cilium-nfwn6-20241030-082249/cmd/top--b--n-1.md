top - 08:22:51 up 31 min,  0 users,  load average: 1.12, 0.36, 0.17
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 54.8 us, 29.0 sy,  0.0 ni,  9.7 id,  0.0 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   7814.2 total,   4447.5 free,   1221.0 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6408.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 396844  78264 S  86.7   5.0   0:53.91 cilium-+
    619 root      20   0 1229640  13488   4004 R   6.7   0.2   0:00.01 gops
    655 root      20   0 1240432  16612  11420 S   6.7   0.2   0:00.03 cilium-+
    678 root      20   0 1244340  20644  14144 S   6.7   0.3   0:00.02 hubble
    394 root      20   0 1229488   7872   3836 S   0.0   0.1   0:01.18 cilium-+
    637 root      20   0 1229000   4056   3392 R   0.0   0.1   0:00.00 gops
    664 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    669 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    702 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    721 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
