ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.144.232:443 (active)    
                                         2 => 172.31.220.241:443 (active)    
2    10.100.175.249:443   ClusterIP      1 => 172.31.129.133:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.174.0.207:53 (active)       
                                         2 => 10.174.0.131:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.174.0.207:9153 (active)     
                                         2 => 10.174.0.131:9153 (active)     
5    10.100.229.75:2379   ClusterIP      1 => 10.174.0.206:2379 (active)     
