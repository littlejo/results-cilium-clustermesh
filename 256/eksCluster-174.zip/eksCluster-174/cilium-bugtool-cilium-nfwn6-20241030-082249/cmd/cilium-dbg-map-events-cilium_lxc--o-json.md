{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.620Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.129.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.620Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.158.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:36.620Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.278Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.290Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.321Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.322Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:41.365Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:25.712Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:25.712Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:25.713Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:25.748Z",
  "value": "id=3236  sec_id=5752437 flags=0x0000 ifindex=16  mac=F6:E7:BA:67:5D:AE nodemac=3A:BA:F8:7A:F0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:26.713Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:26.714Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:26.714Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:26.714Z",
  "value": "id=3236  sec_id=5752437 flags=0x0000 ifindex=16  mac=F6:E7:BA:67:5D:AE nodemac=3A:BA:F8:7A:F0:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.965Z",
  "value": "id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.174.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.595Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.582Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.583Z",
  "value": "id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.585Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:27.585Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.569Z",
  "value": "id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.570Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.570Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:28.570Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.569Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.570Z",
  "value": "id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.571Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.571Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.206:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.570Z",
  "value": "id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.570Z",
  "value": "id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.207:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.570Z",
  "value": "id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.174.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.571Z",
  "value": "id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6"
}

