USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         669  0.0  0.0   2208   792 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         678  0.0  0.2 1243764 18100 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         664  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         655  0.0  0.2 1240432 16612 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         691  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         692  0.0  0.2 1240432 16612 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         637  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         620  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         619  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  4.1  4.8 1606336 387340 ?      Ssl  08:01   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229488 7872 ?        Sl   08:01   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
