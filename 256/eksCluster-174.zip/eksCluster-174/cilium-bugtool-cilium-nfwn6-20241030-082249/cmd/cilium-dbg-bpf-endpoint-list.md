IP ADDRESS         LOCAL ENDPOINT INFO
172.31.129.133:0   (localhost)                                                                                        
172.31.158.95:0    (localhost)                                                                                        
10.174.0.131:0     id=2776  sec_id=5757073 flags=0x0000 ifindex=12  mac=0A:28:B7:19:50:D9 nodemac=4E:29:8E:9A:CB:65   
10.174.0.206:0     id=3331  sec_id=5752437 flags=0x0000 ifindex=18  mac=32:C4:43:67:8A:90 nodemac=DA:50:7B:92:63:88   
10.174.0.207:0     id=1166  sec_id=5757073 flags=0x0000 ifindex=14  mac=5A:FF:B5:C2:05:EB nodemac=7A:73:39:C0:D1:C0   
10.174.0.181:0     id=88    sec_id=4     flags=0x0000 ifindex=10  mac=8E:4F:5C:DE:5B:1C nodemac=42:C0:1F:3B:80:A6     
10.174.0.109:0     (localhost)                                                                                        
