CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6ba4385_f2c5_4b06_b961_5cd9670c8e5e.slice/cri-containerd-bd1d29926c706bfccad801b31e761a2ef7d875c8ff6648b10a68c2f9a4ca8b1b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6ba4385_f2c5_4b06_b961_5cd9670c8e5e.slice/cri-containerd-e38fb097b14f9e4eba8d4921040b629b980a794a759cfc4e17c7102f3b1a77c9.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f9844e3_e7dd_446e_974b_852574fca460.slice/cri-containerd-ec52a5a6107b07febd5677e5a5bd7a66b3d5e87aaa9751ed01ac88552d00745f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f9844e3_e7dd_446e_974b_852574fca460.slice/cri-containerd-05090680b2ae88c858e97621a3754e70ed48cf1fa7a44b99389fe5b5e2ffd043.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod82bfc9d4_ee0d_4971_90cf_c99b49337133.slice/cri-containerd-395f80a71b44d5119f7f02eda15a834e3bf05a8fa7506d8cfdc40a11f5eb8f52.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod82bfc9d4_ee0d_4971_90cf_c99b49337133.slice/cri-containerd-c53cbef08aa833ed30d0ab07f9d73e0731b79bf9fd4135f14ce4488721c35724.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod579a6c13_deed_4555_94b8_f35e0e00128c.slice/cri-containerd-ac73d36266416ad3b418fca1d9d46e7e3781b0165c08cffc838843c17e877f6a.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod579a6c13_deed_4555_94b8_f35e0e00128c.slice/cri-containerd-90fa6db88578ee41bf833d4dfd0907a7d010b4dfae10e7fdb3229cd2c4500f23.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e799283_247e_4f09_a8e1_96560fc8b0b8.slice/cri-containerd-8314db03ece5df2f96b59c114b9b1949899fd94a85d9b11da93f9f0201ee6f3e.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8e799283_247e_4f09_a8e1_96560fc8b0b8.slice/cri-containerd-c8632c406e2de631da221c790d89c65154e460b730f8a61cdea8b3e082a58bad.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod135c5da8_4b4e_4371_a037_cc9e9ffccd19.slice/cri-containerd-3d3f65459632c5a57c58342eb64732b34b6658083f62e79302936a883deda816.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod135c5da8_4b4e_4371_a037_cc9e9ffccd19.slice/cri-containerd-8bb1285318510e7ee1ffe074f4af6495e4eb4ac5db3f58c97a8850f3915b6cdc.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-2997150f8c7f3f508c220c6141e66ea2d8d51c25aa27ab39183b44e79a124e84.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-238dd1b73bc0e93556160339e083d3622ea93748bb76f3b8a1ffc9d064f65b03.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-ca4ef8eab45f1108000cbdb34c5bce55956466971c34ce1ecf7d0578358ddcb8.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-d53abf0203d6bb0ebee9281ecd837d6762bc32c6ac5d123f0e2c864715755c05.scope
    643      cgroup_device   multi                                          
