alloc: 143.23MB (150190472 bytes)
total-alloc: 2.40GB (2572993024 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 66249862
frees: 64735270
heap-alloc: 143.23MB (150190472 bytes)
heap-sys: 255.60MB (268017664 bytes)
heap-idle: 76.63MB (80355328 bytes)
heap-in-use: 178.97MB (187662336 bytes)
heap-released: 8.75MB (9175040 bytes)
heap-objects: 1514592
stack-in-use: 64.38MB (67502080 bytes)
stack-sys: 64.38MB (67502080 bytes)
stack-mspan-inuse: 3.05MB (3201760 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1241601 bytes)
gc-sys: 6.00MB (6295064 bytes)
next-gc: when heap-alloc >= 212.99MB (223332568 bytes)
last-gc: 2024-10-30 08:22:58.635675324 +0000 UTC
gc-pause-total: 20.365831ms
gc-pause: 124933
gc-pause-end: 1730276578635675324
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0005021813517544781
enable-gc: true
debug-gc: false
