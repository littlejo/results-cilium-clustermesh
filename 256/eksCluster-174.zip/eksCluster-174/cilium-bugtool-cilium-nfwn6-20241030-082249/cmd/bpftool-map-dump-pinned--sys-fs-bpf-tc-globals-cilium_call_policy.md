key: 58 00 00 00  value: 23 02 00 00
key: 8e 04 00 00  value: 1c 02 00 00
key: d8 0a 00 00  value: 0e 02 00 00
key: 03 0d 00 00  value: 67 02 00 00
Found 4 elements
