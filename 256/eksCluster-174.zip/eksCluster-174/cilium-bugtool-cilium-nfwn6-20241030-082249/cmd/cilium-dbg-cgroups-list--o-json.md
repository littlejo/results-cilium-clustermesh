[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-d53abf0203d6bb0ebee9281ecd837d6762bc32c6ac5d123f0e2c864715755c05.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-2997150f8c7f3f508c220c6141e66ea2d8d51c25aa27ab39183b44e79a124e84.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf0a4956_4b4f_41ac_b392_5a29b062a4f1.slice/cri-containerd-238dd1b73bc0e93556160339e083d3622ea93748bb76f3b8a1ffc9d064f65b03.scope"
      }
    ],
    "ips": [
      "10.174.0.206"
    ],
    "name": "clustermesh-apiserver-76dd6cd68-4xl6d",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod82bfc9d4_ee0d_4971_90cf_c99b49337133.slice/cri-containerd-c53cbef08aa833ed30d0ab07f9d73e0731b79bf9fd4135f14ce4488721c35724.scope"
      }
    ],
    "ips": [
      "10.174.0.207"
    ],
    "name": "coredns-cc6ccd49c-bvh4x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod579a6c13_deed_4555_94b8_f35e0e00128c.slice/cri-containerd-90fa6db88578ee41bf833d4dfd0907a7d010b4dfae10e7fdb3229cd2c4500f23.scope"
      }
    ],
    "ips": [
      "10.174.0.131"
    ],
    "name": "coredns-cc6ccd49c-mw8kg",
    "namespace": "kube-system"
  }
]

