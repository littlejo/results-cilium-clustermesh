Endpoint ID: 88
Path: /sys/fs/bpf/tc/globals/cilium_policy_00088

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1646371   20775     0        
Allow    Ingress     1          ANY          NONE         disabled    19403     230       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 160
Path: /sys/fs/bpf/tc/globals/cilium_policy_00160

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1166
Path: /sys/fs/bpf/tc/globals/cilium_policy_01166

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    668502   5999      0        
Allow    Ingress     1          ANY          NONE         disabled    124132   1423      0        
Allow    Egress      0          ANY          NONE         disabled    121325   1161      0        


Endpoint ID: 2776
Path: /sys/fs/bpf/tc/globals/cilium_policy_02776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    663306   5957      0        
Allow    Ingress     1          ANY          NONE         disabled    124330   1426      0        
Allow    Egress      0          ANY          NONE         disabled    122406   1168      0        


Endpoint ID: 3331
Path: /sys/fs/bpf/tc/globals/cilium_policy_03331

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11487947   116048    0        
Allow    Ingress     1          ANY          NONE         disabled    11038461   116803    0        
Allow    Egress      0          ANY          NONE         disabled    15149999   147674    0        


