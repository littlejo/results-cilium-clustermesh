KEY             VALUE
AgentLiveness   1931194137215
UTimeOffset     3379442718750000
