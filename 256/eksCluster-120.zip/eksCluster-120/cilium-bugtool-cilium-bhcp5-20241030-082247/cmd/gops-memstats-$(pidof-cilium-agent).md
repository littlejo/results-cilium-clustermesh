alloc: 203.69MB (213583448 bytes)
total-alloc: 2.16GB (2324356008 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 61958783
frees: 59804997
heap-alloc: 203.69MB (213583448 bytes)
heap-sys: 247.39MB (259407872 bytes)
heap-idle: 25.76MB (27009024 bytes)
heap-in-use: 221.63MB (232398848 bytes)
heap-released: 5.65MB (5922816 bytes)
heap-objects: 2153786
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 3.47MB (3640960 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1086657 bytes)
gc-sys: 6.04MB (6338048 bytes)
next-gc: when heap-alloc >= 221.26MB (232010216 bytes)
last-gc: 2024-10-30 08:22:49.256209633 +0000 UTC
gc-pause-total: 17.277897ms
gc-pause: 6238021
gc-pause-end: 1730276569256209633
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00041118758632829904
enable-gc: true
debug-gc: false
