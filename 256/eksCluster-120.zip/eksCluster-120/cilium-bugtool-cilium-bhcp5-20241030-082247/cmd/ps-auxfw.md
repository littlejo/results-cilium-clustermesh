USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         687  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         678  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         677  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         657  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         639  0.0  0.2 1240432 16288 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         705  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         706  0.0  0.0   3728   488 ?        R    08:22   0:00  \_ bash -c hostname
root           1  3.1  4.7 1606080 376480 ?      Ssl  07:56   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.1 1229744 8132 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
