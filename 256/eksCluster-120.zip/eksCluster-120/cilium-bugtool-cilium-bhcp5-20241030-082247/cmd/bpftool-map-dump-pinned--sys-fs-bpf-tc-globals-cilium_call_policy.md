key: 78 01 00 00  value: 24 02 00 00
key: a8 02 00 00  value: 02 02 00 00
key: 4d 07 00 00  value: 1a 02 00 00
key: 9d 0f 00 00  value: 62 02 00 00
Found 4 elements
