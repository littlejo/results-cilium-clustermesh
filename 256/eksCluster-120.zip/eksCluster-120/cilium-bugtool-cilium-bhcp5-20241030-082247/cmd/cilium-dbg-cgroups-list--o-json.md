[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261ecc9b_b0c4_484c_adb4_21e40b081b47.slice/cri-containerd-e3ef3ef5daf10396b20dc3c0bcd99fc332a32b1fd2b248a48e7b80779f6cb451.scope"
      }
    ],
    "ips": [
      "10.120.0.32"
    ],
    "name": "coredns-cc6ccd49c-28mkj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-59cea40154f3214b29cec0d26d03a04d823ac2e802957ae21e730268580c3e31.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-fb6f6ea7f342ea2b0cfd2c9f229a68dc00ffd7b83b1fa64ea74a6484cf1f39d9.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-2c23141fc497bcd14fe59fdc9f59f29a01a07197de34381227f0df4872385260.scope"
      }
    ],
    "ips": [
      "10.120.0.19"
    ],
    "name": "clustermesh-apiserver-64f8b96f44-mhq5l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddc1931e_f739_416c_8241_42380aa033d1.slice/cri-containerd-f27c1648a31cd52408342ac0c4e7aaad265e1a2350883e47aafebbdca7861d58.scope"
      }
    ],
    "ips": [
      "10.120.0.8"
    ],
    "name": "coredns-cc6ccd49c-s56br",
    "namespace": "kube-system"
  }
]

