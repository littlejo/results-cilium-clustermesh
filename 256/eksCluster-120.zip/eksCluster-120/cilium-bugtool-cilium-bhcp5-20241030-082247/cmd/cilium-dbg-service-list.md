ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.164.13:443 (active)    
                                          2 => 172.31.200.218:443 (active)   
2    10.100.25.22:443      ClusterIP      1 => 172.31.138.53:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.120.0.8:9153 (active)      
                                          2 => 10.120.0.32:9153 (active)     
4    10.100.0.10:53        ClusterIP      1 => 10.120.0.8:53 (active)        
                                          2 => 10.120.0.32:53 (active)       
5    10.100.248.201:2379   ClusterIP      1 => 10.120.0.19:2379 (active)     
