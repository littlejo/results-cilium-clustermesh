CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37375437_ae9d_402a_88cd_7b7043439d87.slice/cri-containerd-92bd5ad9ce805fcb341c129432b625de7b422d69d35ba7ce5409c8d9a00a4d8f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod37375437_ae9d_402a_88cd_7b7043439d87.slice/cri-containerd-052d4b537abf19a3b1fd5c2a1115c780bc595cda52801a79adf7906181737a22.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddc1931e_f739_416c_8241_42380aa033d1.slice/cri-containerd-f27c1648a31cd52408342ac0c4e7aaad265e1a2350883e47aafebbdca7861d58.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podddc1931e_f739_416c_8241_42380aa033d1.slice/cri-containerd-61cfae49a54906b563abeea0ac54173e269d9979315fa1b40c66a7da41a6edf3.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261ecc9b_b0c4_484c_adb4_21e40b081b47.slice/cri-containerd-547ed236aad691e4bb534017e2b4647462a728fffa74b553235b3e35b3efd823.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod261ecc9b_b0c4_484c_adb4_21e40b081b47.slice/cri-containerd-e3ef3ef5daf10396b20dc3c0bcd99fc332a32b1fd2b248a48e7b80779f6cb451.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc205bce1_16e6_47f5_96f6_27331675b0ef.slice/cri-containerd-081b1c8179020f08c99aa2aa9100d28e1b35229d1a636a21b99873a7580eb34d.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc205bce1_16e6_47f5_96f6_27331675b0ef.slice/cri-containerd-873e48b36314f5a8580098db4a805077bb50ffb243c04464df48d68090fc70c5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod823b1e89_6486_4fdf_8106_0983c79b1936.slice/cri-containerd-c620f55d51aaa5ec8a4e1add2136b693662ac32c77bff3d227f5b888c8ac43e0.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod823b1e89_6486_4fdf_8106_0983c79b1936.slice/cri-containerd-388ee9af4a26e98614458570b8d9eb516a04fbc0583d5f3de3f4ede9e2c582a6.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-2c23141fc497bcd14fe59fdc9f59f29a01a07197de34381227f0df4872385260.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-fb6f6ea7f342ea2b0cfd2c9f229a68dc00ffd7b83b1fa64ea74a6484cf1f39d9.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-59cea40154f3214b29cec0d26d03a04d823ac2e802957ae21e730268580c3e31.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1caff401_ad4c_4f3e_b1fd_5882c248ae2b.slice/cri-containerd-fe0701e4e2cc4f9f94582bbb5f47afd62951579777f925938b22dc14f1d23992.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a882c2b_1108_487a_9d38_7fcc550ba195.slice/cri-containerd-04ca3f7b79908d0e4429b9d2e4b12b90f7869aa67e24f441988b2bf123902600.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a882c2b_1108_487a_9d38_7fcc550ba195.slice/cri-containerd-06ac7c63ff310124bd2caff9bde3c35e1d567d2130d359be088cdfcf5d76f901.scope
    95       cgroup_device   multi                                          
