KEY             VALUE
AgentLiveness   2091754530181
UTimeOffset     3379442400390625
