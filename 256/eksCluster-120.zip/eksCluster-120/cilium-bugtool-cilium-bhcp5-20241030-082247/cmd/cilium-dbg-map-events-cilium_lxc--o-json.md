{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.195Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.138.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.195Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.155.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.195Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:52.990Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:52.999Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.035Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.037Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:53.065Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.623Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.623Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.623Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:38.657Z",
  "value": "id=3068  sec_id=3971526 flags=0x0000 ifindex=16  mac=06:60:D2:E6:F2:17 nodemac=92:03:41:51:23:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.623Z",
  "value": "id=3068  sec_id=3971526 flags=0x0000 ifindex=16  mac=06:60:D2:E6:F2:17 nodemac=92:03:41:51:23:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.623Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.624Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.624Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.518Z",
  "value": "id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.120.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:12.780Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.628Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.628Z",
  "value": "id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.628Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:17.628Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.642Z",
  "value": "id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.654Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.659Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:18.661Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.628Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.628Z",
  "value": "id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.629Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:19.629Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.628Z",
  "value": "id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.8:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.628Z",
  "value": "id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.628Z",
  "value": "id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.120.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:20.628Z",
  "value": "id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB"
}

