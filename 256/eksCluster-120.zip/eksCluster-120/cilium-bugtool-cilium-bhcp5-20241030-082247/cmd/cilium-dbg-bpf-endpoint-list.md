IP ADDRESS        LOCAL ENDPOINT INFO
10.120.0.8:0      id=680   sec_id=3975981 flags=0x0000 ifindex=12  mac=E2:28:99:3A:C4:06 nodemac=FA:41:87:F8:9F:D2   
172.31.155.63:0   (localhost)                                                                                        
10.120.0.19:0     id=3997  sec_id=3971526 flags=0x0000 ifindex=18  mac=BA:80:9E:AA:5D:65 nodemac=8A:11:BE:D7:4A:E4   
10.120.0.223:0    id=376   sec_id=4     flags=0x0000 ifindex=10  mac=3E:95:BA:F6:60:F5 nodemac=0A:F0:45:E7:84:2A     
172.31.138.53:0   (localhost)                                                                                        
10.120.0.27:0     (localhost)                                                                                        
10.120.0.32:0     id=1869  sec_id=3975981 flags=0x0000 ifindex=14  mac=3A:B1:8E:8E:E4:32 nodemac=EE:06:3E:3F:F7:EB   
