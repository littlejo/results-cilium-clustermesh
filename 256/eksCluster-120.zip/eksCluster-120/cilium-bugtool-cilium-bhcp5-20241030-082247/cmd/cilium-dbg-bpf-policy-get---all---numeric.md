Endpoint ID: 376
Path: /sys/fs/bpf/tc/globals/cilium_policy_00376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1640127   20690     0        
Allow    Ingress     1          ANY          NONE         disabled    22272     258       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 680
Path: /sys/fs/bpf/tc/globals/cilium_policy_00680

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    150311   1725      0        
Allow    Egress      0          ANY          NONE         disabled    19437    214       0        


Endpoint ID: 1869
Path: /sys/fs/bpf/tc/globals/cilium_policy_01869

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151152   1733      0        
Allow    Egress      0          ANY          NONE         disabled    19610    218       0        


Endpoint ID: 3563
Path: /sys/fs/bpf/tc/globals/cilium_policy_03563

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3997
Path: /sys/fs/bpf/tc/globals/cilium_policy_03997

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11303688   110937    0        
Allow    Ingress     1          ANY          NONE         disabled    8802148    92005     0        
Allow    Egress      0          ANY          NONE         disabled    11203571   111162    0        


