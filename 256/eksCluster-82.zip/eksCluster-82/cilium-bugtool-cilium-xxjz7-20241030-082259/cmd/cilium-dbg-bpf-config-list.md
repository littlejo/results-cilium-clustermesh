KEY             VALUE
AgentLiveness   2085723585390
UTimeOffset     3379442433593750
