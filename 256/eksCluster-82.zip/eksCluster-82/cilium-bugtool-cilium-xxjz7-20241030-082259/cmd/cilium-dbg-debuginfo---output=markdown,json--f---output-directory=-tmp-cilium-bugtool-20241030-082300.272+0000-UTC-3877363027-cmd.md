markdown output at /tmp/cilium-bugtool-20241030-082300.272+0000-UTC-3877363027/cmd/cilium-debuginfo-20241030-082331.47+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.272+0000-UTC-3877363027/cmd/cilium-debuginfo-20241030-082331.47+0000-UTC.json
