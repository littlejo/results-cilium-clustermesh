ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.196.248:443 (active)   
                                          2 => 172.31.173.197:443 (active)   
2    10.100.248.33:443     ClusterIP      1 => 172.31.164.11:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.82.0.28:53 (active)        
                                          2 => 10.82.0.46:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.82.0.28:9153 (active)      
                                          2 => 10.82.0.46:9153 (active)      
5    10.100.104.196:2379   ClusterIP      1 => 10.82.0.204:2379 (active)     
