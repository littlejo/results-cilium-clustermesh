 08:23:00 up 34 min,  0 users,  load average: 0.44, 0.45, 0.29
