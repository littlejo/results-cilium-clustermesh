Endpoint ID: 835
Path: /sys/fs/bpf/tc/globals/cilium_policy_00835

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149911   1726      0        
Allow    Egress      0          ANY          NONE         disabled    18354    201       0        


Endpoint ID: 1776
Path: /sys/fs/bpf/tc/globals/cilium_policy_01776

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    149779   1724      0        
Allow    Egress      0          ANY          NONE         disabled    20019    221       0        


Endpoint ID: 2122
Path: /sys/fs/bpf/tc/globals/cilium_policy_02122

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1669227   21147     0        
Allow    Ingress     1          ANY          NONE         disabled    22472     262       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2716
Path: /sys/fs/bpf/tc/globals/cilium_policy_02716

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3311
Path: /sys/fs/bpf/tc/globals/cilium_policy_03311

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11473659   112390    0        
Allow    Ingress     1          ANY          NONE         disabled    9307995    97465     0        
Allow    Egress      0          ANY          NONE         disabled    11393668   113358    0        


