CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3e50b28_7ae6_48c6_9efb_1054a9241c2b.slice/cri-containerd-e1ad1dca5b442bea99afc6921edb2a9ae080ae55f21bd8ee022b528e15550a8e.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3e50b28_7ae6_48c6_9efb_1054a9241c2b.slice/cri-containerd-9db27ab1c9e42e8b44abc0405383e1bb7edb4af7703fecaadc81c88d9908bdee.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb32e0c0e_22d8_4094_9028_bf36d3d90e14.slice/cri-containerd-47f69b91773709f44b74589dd826f7f06390a320f40ad25aa0d267a998148eea.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb32e0c0e_22d8_4094_9028_bf36d3d90e14.slice/cri-containerd-6117973fa5a248a43300f13b020eb001c76116d2da8402fabf29cd8c39b2ad24.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52650130_378d_4788_8a61_c7de85c989d2.slice/cri-containerd-dc56568666637ab517524d8d361930934215b588a0bc26441f165382df160862.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod52650130_378d_4788_8a61_c7de85c989d2.slice/cri-containerd-bd175e158f0c398545cd44fa65adcfb712e75e4c0c84205f56026518700af78a.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68c49216_57d4_4294_8af5_171086a45e6d.slice/cri-containerd-362936fc5b6c34d4061ee556899b13411c1f01e0a5f01d5b3535eebc6a3aa14d.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod68c49216_57d4_4294_8af5_171086a45e6d.slice/cri-containerd-b87effa0cb38fde114d2448533b986b81ccc0ade3b6eaf003aa771c3d2741486.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf2c6e91_1b72_4cd2_ace9_23477563fb24.slice/cri-containerd-2a6200685961580084e587416d1448954fdea766c2b5e44520c63423ea286454.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaf2c6e91_1b72_4cd2_ace9_23477563fb24.slice/cri-containerd-7327ac64882f367d52c66696736e48ee38ab155d28844fdfe0af6f99d10c7f12.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-6f9f7c70f58aa4009a267cf1ffc76c0d540f7ae160edcc3974eee7ad257407f5.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-77189098828b441120118c895a4dc78ad848fae7af76712e5738d327e3f10038.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-b3289d474427969d8fba57031306b3da29cd5162e8171c3e777e43cb1ad74492.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-074d681c074653548dce4d72fdc68c4e6c9f4e8985b692f2e0cca36037ee6c5d.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod63b48d42_9e79_4c46_a363_458c74b74de6.slice/cri-containerd-e9137a2d86543e79e6057f496332d660f97d7219f61b100cd1bfb82b2d1f736d.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod63b48d42_9e79_4c46_a363_458c74b74de6.slice/cri-containerd-da0acbfe2fd90621a66157cf71b0a7f6dcac79ada53eaa87496050b4e78c21d0.scope
    99       cgroup_device   multi                                          
