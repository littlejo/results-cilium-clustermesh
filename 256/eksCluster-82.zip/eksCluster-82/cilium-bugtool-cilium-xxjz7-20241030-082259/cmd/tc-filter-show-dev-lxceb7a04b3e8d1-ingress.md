filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxceb7a04b3e8d1 direct-action not_in_hw id 543 tag 4ad61ed96d5ad142 jited 
