{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.149:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.164Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.164.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.164Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.164Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:17.901Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:17.901Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:17.953Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:17.961Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.039Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.040Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.041Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:10.069Z",
  "value": "id=642   sec_id=2721042 flags=0x0000 ifindex=16  mac=62:F2:5C:F5:E0:87 nodemac=26:97:16:95:BA:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.038Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.038Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.039Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.039Z",
  "value": "id=642   sec_id=2721042 flags=0x0000 ifindex=16  mac=62:F2:5C:F5:E0:87 nodemac=26:97:16:95:BA:AF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.793Z",
  "value": "id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.82.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:16.203Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.873Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.873Z",
  "value": "id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.875Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.875Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.873Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.873Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.874Z",
  "value": "id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.875Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.873Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.874Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.874Z",
  "value": "id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:51.874Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.874Z",
  "value": "id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.874Z",
  "value": "id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.875Z",
  "value": "id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.82.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:52.875Z",
  "value": "id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24"
}

