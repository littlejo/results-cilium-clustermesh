USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         686  0.0  0.2 1240432 16196 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.2 1240432 16196 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         670  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         660  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         651  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         637  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         631  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  3.1  4.7 1606144 379168 ?      Ssl  07:57   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.1 1229744 8296 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
