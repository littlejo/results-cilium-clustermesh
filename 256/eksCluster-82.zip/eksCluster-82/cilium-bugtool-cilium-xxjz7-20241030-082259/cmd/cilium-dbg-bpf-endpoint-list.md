IP ADDRESS        LOCAL ENDPOINT INFO
172.31.186.76:0   (localhost)                                                                                        
10.82.0.149:0     (localhost)                                                                                        
172.31.164.11:0   (localhost)                                                                                        
10.82.0.28:0      id=1776  sec_id=2726527 flags=0x0000 ifindex=14  mac=E6:42:70:64:6F:D5 nodemac=DA:5F:61:AC:19:AA   
10.82.0.204:0     id=3311  sec_id=2721042 flags=0x0000 ifindex=18  mac=A6:7A:7A:A5:37:88 nodemac=82:AF:B5:9B:75:88   
10.82.0.46:0      id=835   sec_id=2726527 flags=0x0000 ifindex=12  mac=F6:79:78:D8:C8:4C nodemac=A2:9B:1A:39:16:24   
10.82.0.97:0      id=2122  sec_id=4     flags=0x0000 ifindex=10  mac=46:B1:FF:BA:64:02 nodemac=8E:B0:51:FC:32:49     
