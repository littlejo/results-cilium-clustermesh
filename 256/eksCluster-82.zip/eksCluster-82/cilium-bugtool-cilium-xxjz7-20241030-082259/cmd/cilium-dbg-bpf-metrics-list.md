REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35738     2820860     677    bpf_overlay.c
Interface                 INGRESS     629343    130486581   1132   bpf_host.c
Success                   EGRESS      15277     1198244     1694   bpf_host.c
Success                   EGRESS      263388    33639134    1308   bpf_lxc.c
Success                   EGRESS      35029     2774562     53     encap.h
Success                   INGRESS     304122    34212212    86     l3.h
Success                   INGRESS     325234    35878874    235    trace.h
Unsupported L3 protocol   EGRESS      44        3292        1492   bpf_lxc.c
