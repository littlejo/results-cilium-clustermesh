29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:48+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:53+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:49:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:49:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:49:03+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:49+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:56:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:56:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:57:15+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 124
479: sched_cls  name tail_handle_ipv4  tag 2c8bde5e0eb98fda  gpl
	loaded_at 2024-10-30T07:57:15+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 125
480: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:57:15+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 126
481: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:57:15+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 127
483: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,102
	btf_id 130
485: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 132
486: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 133
487: sched_cls  name __send_drop_notify  tag 6f67295f1dca8fdf  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 134
488: sched_cls  name tail_handle_ipv4_from_host  tag a83458e845651d2a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 135
489: sched_cls  name tail_handle_ipv4_from_host  tag a83458e845651d2a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,104
	btf_id 137
493: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 141
494: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,104
	btf_id 142
495: sched_cls  name __send_drop_notify  tag 6f67295f1dca8fdf  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 143
496: sched_cls  name tail_handle_ipv4_from_host  tag a83458e845651d2a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,106
	btf_id 145
497: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,106,75
	btf_id 146
501: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,106
	btf_id 150
502: sched_cls  name __send_drop_notify  tag 6f67295f1dca8fdf  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 151
506: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 156
507: sched_cls  name __send_drop_notify  tag 6f67295f1dca8fdf  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 157
508: sched_cls  name tail_handle_ipv4_from_host  tag a83458e845651d2a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 158
509: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:57:16+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 159
513: sched_cls  name handle_policy  tag 3c93e3b4546bf474  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 163
514: sched_cls  name tail_handle_arp  tag 4994b6b9bbf1febf  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 167
515: sched_cls  name cil_from_container  tag 85d943250f4faef8  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 168
518: sched_cls  name tail_ipv4_ct_egress  tag 830ace734572bc8e  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,113,84
	btf_id 169
519: sched_cls  name tail_handle_ipv4_cont  tag d643a57f7ac8b9d4  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,110,40,37,38,81
	btf_id 172
523: sched_cls  name tail_ipv4_to_endpoint  tag 1cca6ad0a0e95166  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,110,40,37,38
	btf_id 173
524: sched_cls  name tail_handle_ipv4  tag 6c730bca047fe2dd  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 177
525: sched_cls  name __send_drop_notify  tag 44ca09a41e473add  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 178
528: sched_cls  name tail_ipv4_ct_ingress  tag 8341c938bb958592  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,113,84
	btf_id 180
529: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 182
532: sched_cls  name tail_ipv4_ct_ingress  tag c9dc60958ff3a4d0  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 185
533: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 186
534: sched_cls  name tail_ipv4_to_endpoint  tag b8ce7162b48d947e  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,117,41,82,83,80,114,39,118,40,37,38
	btf_id 189
535: sched_cls  name tail_handle_ipv4_cont  tag 3ad47ea6789d920d  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,117,41,114,82,83,39,76,74,77,118,40,37,38,81
	btf_id 190
536: sched_cls  name tail_handle_ipv4  tag 9aa52cf9eb2d89c3  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 188
537: sched_cls  name tail_handle_arp  tag 0159e1ff7ddcce47  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 192
538: sched_cls  name tail_handle_ipv4  tag cdbfaf9f9ab5f26e  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 191
540: sched_cls  name handle_policy  tag 8f8e222868e3cc26  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,116,82,83,115,41,80,100,39,84,75,40,37,38
	btf_id 193
541: sched_cls  name __send_drop_notify  tag b56220c7db44e3f9  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
542: sched_cls  name cil_from_container  tag 139e28b9a7b2897b  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 116,76
	btf_id 196
543: sched_cls  name cil_from_container  tag 4ad61ed96d5ad142  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 118,76
	btf_id 198
544: sched_cls  name tail_handle_ipv4_cont  tag ab74ec2c8623c82f  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,115,41,100,82,83,39,76,74,77,116,40,37,38,81
	btf_id 197
545: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 199
546: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 200
547: sched_cls  name __send_drop_notify  tag 85e6cfd591e6d03e  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
548: sched_cls  name tail_ipv4_to_endpoint  tag 9561d585c0104e69  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,115,41,82,83,80,100,39,116,40,37,38
	btf_id 202
549: sched_cls  name tail_ipv4_ct_egress  tag 830ace734572bc8e  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 203
550: sched_cls  name tail_ipv4_ct_ingress  tag e97ebe8d3ca7f61f  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 204
551: sched_cls  name tail_handle_arp  tag da9ff8843eebe9cc  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 205
553: sched_cls  name handle_policy  tag a2cdf397e86e1d8d  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,118,82,83,117,41,80,114,39,84,75,40,37,38
	btf_id 206
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:57:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_handle_ipv4_cont  tag add21a6cfc079fb6  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,134,41,133,82,83,39,76,74,77,135,40,37,38,81
	btf_id 221
610: sched_cls  name tail_handle_arp  tag 2938b2b3fc16ced1  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,135
	btf_id 222
611: sched_cls  name tail_ipv4_to_endpoint  tag 23c7284f9c432135  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,134,41,82,83,80,133,39,135,40,37,38
	btf_id 223
612: sched_cls  name tail_handle_ipv4  tag f5140ae8eeff9dfb  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,135
	btf_id 224
613: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,135
	btf_id 225
614: sched_cls  name tail_ipv4_ct_ingress  tag 10625a19acafde0a  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 226
615: sched_cls  name tail_ipv4_ct_egress  tag 3f002a3dccc9a666  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,135,82,83,134,84
	btf_id 227
616: sched_cls  name handle_policy  tag ed7094f913c00359  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,135,82,83,134,41,80,133,39,84,75,40,37,38
	btf_id 228
617: sched_cls  name cil_from_container  tag 8e1ae690144bbfe3  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 135,76
	btf_id 229
618: sched_cls  name __send_drop_notify  tag dc18c59b9630f46f  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:05+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
