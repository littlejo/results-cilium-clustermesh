1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d8:b8:c4:af:3d brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.164.11/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3356sec preferred_lft 3356sec
    inet6 fe80::4d8:b8ff:fec4:af3d/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:d0:1f:d1:c5:d5 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.186.76/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4d0:1fff:fed1:c5d5/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:78:fa:78:2a:8c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6878:faff:fe78:2a8c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:18:ab:c3:ed:2a brd ff:ff:ff:ff:ff:ff
    inet 10.82.0.149/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9c18:abff:fec3:ed2a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 76:bf:34:22:88:f7 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::74bf:34ff:fe22:88f7/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:b0:51:fc:32:49 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::8cb0:51ff:fefc:3249/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc63a71f93b193@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:9b:1a:39:16:24 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a09b:1aff:fe39:1624/64 scope link 
       valid_lft forever preferred_lft forever
14: lxceb7a04b3e8d1@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:5f:61:ac:19:aa brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d85f:61ff:feac:19aa/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc833050299c0f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:af:b5:9b:75:88 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::80af:b5ff:fe9b:7588/64 scope link 
       valid_lft forever preferred_lft forever
