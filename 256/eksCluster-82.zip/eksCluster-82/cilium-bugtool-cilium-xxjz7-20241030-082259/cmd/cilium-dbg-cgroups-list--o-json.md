[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-77189098828b441120118c895a4dc78ad848fae7af76712e5738d327e3f10038.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-b3289d474427969d8fba57031306b3da29cd5162e8171c3e777e43cb1ad74492.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9d3170e_1269_4ae7_9d85_637b77d0eb3c.slice/cri-containerd-074d681c074653548dce4d72fdc68c4e6c9f4e8985b692f2e0cca36037ee6c5d.scope"
      }
    ],
    "ips": [
      "10.82.0.204"
    ],
    "name": "clustermesh-apiserver-69d85ff5c6-nznfq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb32e0c0e_22d8_4094_9028_bf36d3d90e14.slice/cri-containerd-47f69b91773709f44b74589dd826f7f06390a320f40ad25aa0d267a998148eea.scope"
      }
    ],
    "ips": [
      "10.82.0.28"
    ],
    "name": "coredns-cc6ccd49c-m4rnz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3e50b28_7ae6_48c6_9efb_1054a9241c2b.slice/cri-containerd-9db27ab1c9e42e8b44abc0405383e1bb7edb4af7703fecaadc81c88d9908bdee.scope"
      }
    ],
    "ips": [
      "10.82.0.46"
    ],
    "name": "coredns-cc6ccd49c-m2lzv",
    "namespace": "kube-system"
  }
]

