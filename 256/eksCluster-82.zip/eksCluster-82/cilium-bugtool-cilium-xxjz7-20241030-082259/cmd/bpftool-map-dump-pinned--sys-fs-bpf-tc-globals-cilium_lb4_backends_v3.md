key: 01 00 00 00  value: ac 1f c4 f8 01 bb 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 52 00 2e 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f a4 0b 10 94 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 52 00 cc 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 52 00 1c 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 52 00 1c 23 c1 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ad c5 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 52 00 2e 00 35 00 00  00 00 00 00
Found 8 elements
