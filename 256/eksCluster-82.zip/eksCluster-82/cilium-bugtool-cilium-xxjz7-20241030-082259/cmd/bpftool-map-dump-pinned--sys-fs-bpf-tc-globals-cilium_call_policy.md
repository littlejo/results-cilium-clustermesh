key: 43 03 00 00  value: 01 02 00 00
key: f0 06 00 00  value: 29 02 00 00
key: 4a 08 00 00  value: 1c 02 00 00
key: ef 0c 00 00  value: 68 02 00 00
Found 4 elements
