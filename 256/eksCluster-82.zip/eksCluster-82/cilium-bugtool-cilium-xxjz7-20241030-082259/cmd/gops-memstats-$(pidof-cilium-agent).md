alloc: 114.45MB (120014368 bytes)
total-alloc: 2.21GB (2376061712 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 62787998
frees: 61809593
heap-alloc: 114.45MB (120014368 bytes)
heap-sys: 247.63MB (259661824 bytes)
heap-idle: 88.80MB (93110272 bytes)
heap-in-use: 158.84MB (166551552 bytes)
heap-released: 2.09MB (2195456 bytes)
heap-objects: 978405
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 2.69MB (2824800 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1020.18KB (1044665 bytes)
gc-sys: 6.06MB (6350312 bytes)
next-gc: when heap-alloc >= 213.64MB (224016312 bytes)
last-gc: 2024-10-30 08:23:19.510786976 +0000 UTC
gc-pause-total: 11.126519ms
gc-pause: 117400
gc-pause-end: 1730276599510786976
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.00041825360794449086
enable-gc: true
debug-gc: false
