REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35417     2800229     677    bpf_overlay.c
Interface                 INGRESS     645860    131679720   1132   bpf_host.c
Success                   EGRESS      15272     1198431     1694   bpf_host.c
Success                   EGRESS      284276    35949513    1308   bpf_lxc.c
Success                   EGRESS      35015     2770546     53     encap.h
Success                   INGRESS     324934    36680230    86     l3.h
Success                   INGRESS     345730    38326074    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
