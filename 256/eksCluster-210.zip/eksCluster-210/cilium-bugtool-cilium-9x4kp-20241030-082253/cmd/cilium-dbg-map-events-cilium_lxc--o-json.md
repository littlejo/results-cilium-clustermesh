{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.4:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.153.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.156.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.105Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.687Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.693Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.769Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.817Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.864Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.156Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.156Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.157Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:11.186Z",
  "value": "id=2551  sec_id=6925434 flags=0x0000 ifindex=16  mac=66:84:DE:EC:DF:06 nodemac=4A:A6:F4:72:3C:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:12.156Z",
  "value": "id=2551  sec_id=6925434 flags=0x0000 ifindex=16  mac=66:84:DE:EC:DF:06 nodemac=4A:A6:F4:72:3C:53"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:12.156Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:12.156Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:12.157Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:50.794Z",
  "value": "id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.210.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:01.399Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.456Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.457Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.458Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.458Z",
  "value": "id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.456Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.456Z",
  "value": "id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.457Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.458Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.457Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.457Z",
  "value": "id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.457Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.457Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.456Z",
  "value": "id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.81:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.457Z",
  "value": "id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.34:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.457Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.210.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.457Z",
  "value": "id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73"
}

