CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94d159cc_781e_4295_b368_e09f4d06155d.slice/cri-containerd-8e7c3157d6686fb5e9aa2795e3be102a763ce8c08946d5be8c982a5187e4f9e8.scope
    59       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod94d159cc_781e_4295_b368_e09f4d06155d.slice/cri-containerd-68225c0be46068d0673d674fac593cec04eae19d9a0ef667cd7f367341f12e09.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2708220a_af70_4f7f_973e_69c3f94d701a.slice/cri-containerd-6cb607542a0a74b04d430b070db3e5558434e3b90120ad3edf28df4a3da9489a.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2708220a_af70_4f7f_973e_69c3f94d701a.slice/cri-containerd-378d3824b66fcbfa07aee4afb81c0255ae5e5f2095a0a08d5d6e93a75cfb16ac.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod640d8d6e_7dd7_4d84_9185_35ce7f8d951d.slice/cri-containerd-9ecd7294d0cd0bec8a9a2928d0eccbfd76c081f9fe99e5e48e6f847cdf49b2a4.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod640d8d6e_7dd7_4d84_9185_35ce7f8d951d.slice/cri-containerd-03683406f1849617483e67285ff3129c5c6d0e290b832c56f7d2bb8c0cf973ef.scope
    550      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb1cac43_35d8_4091_a4b5_3673286b98c3.slice/cri-containerd-ef2a99d16c2eb1da01628d76469d62bd88446033c999f2793f059ca39f9c5e1f.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb1cac43_35d8_4091_a4b5_3673286b98c3.slice/cri-containerd-d329456a69e5e91306bb067e8c0b23322778e4803b025e9ce33d124dd493d330.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda57e7ac5_5e2c_4168_8342_c7d009376c02.slice/cri-containerd-ec3900565a2cd5ff1af89aefad66143728b222be193e0d69dacd66c87cfebbb6.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda57e7ac5_5e2c_4168_8342_c7d009376c02.slice/cri-containerd-c3d3c85c465c872f11813f902431d961bf6a30d5b1de7992b45632f4d9eda40b.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-cb4da437fe7f041b89fb6754d9b2e42f1e6e529b1f4a89cef8fe8c622ea09583.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-e2a9d8caa68a7557d99ab0bb4feda896ad171f9d7cde6e955f2bead00824c1f9.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-1b17f187841c6ece39730bc6a79b95b0b1cf4a89fef0629fda447001ff0aab89.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-6145fabe63469f478d69adb22827299476ac6da9da164fe660c799b7d4368f85.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ac76d3f_e996_4e5b_a7e8_3f3204f8ead8.slice/cri-containerd-2f5b447d8fd66ea2b30d3ea3dd3524b0d8945b4c68cc923186e2fe438ac38fcd.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9ac76d3f_e996_4e5b_a7e8_3f3204f8ead8.slice/cri-containerd-f44309658c79e4daabf7322e3c945c6d43b0ec20cd03811fdec14d72a3bf2301.scope
    109      cgroup_device   multi                                          
