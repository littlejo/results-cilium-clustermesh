Endpoint ID: 716
Path: /sys/fs/bpf/tc/globals/cilium_policy_00716

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 898
Path: /sys/fs/bpf/tc/globals/cilium_policy_00898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1649516   20842     0        
Allow    Ingress     1          ANY          NONE         disabled    16846     197       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1656
Path: /sys/fs/bpf/tc/globals/cilium_policy_01656

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114040   1306      0        
Allow    Egress      0          ANY          NONE         disabled    17069    185       0        


Endpoint ID: 2236
Path: /sys/fs/bpf/tc/globals/cilium_policy_02236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114861   1322      0        
Allow    Egress      0          ANY          NONE         disabled    16467    177       0        


Endpoint ID: 2376
Path: /sys/fs/bpf/tc/globals/cilium_policy_02376

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11536325   113887    0        
Allow    Ingress     1          ANY          NONE         disabled    10575522   107648    0        
Allow    Egress      0          ANY          NONE         disabled    11655112   115687    0        


