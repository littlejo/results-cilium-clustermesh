USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         698  0.0  0.2 1240432 16216 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         716  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         680  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.5  5.0 1606336 403976 ?      Ssl  08:03   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         402  0.0  0.0 1229744 7004 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
