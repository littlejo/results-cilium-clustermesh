1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f7:3d:21:b8:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.156.152/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1889sec preferred_lft 1889sec
    inet6 fe80::4f7:3dff:fe21:b8b7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:12:c0:a7:2f:95 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.153.158/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::412:c0ff:fea7:2f95/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:e4:d9:7f:90:8a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::54e4:d9ff:fe7f:908a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:ae:99:38:99:d4 brd ff:ff:ff:ff:ff:ff
    inet 10.210.0.4/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d4ae:99ff:fe38:99d4/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:ff:25:22:84:38 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::cff:25ff:fe22:8438/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:e3:0c:8c:64:10 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4e3:cff:fe8c:6410/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb5bb8b736d44@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:8b:5d:66:fd:73 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::d88b:5dff:fe66:fd73/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc06eee93379e7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:68:30:e8:c0:c7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d468:30ff:fee8:c0c7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxce0ac3937e5a4@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:90:67:9a:a1:9a brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::a490:67ff:fe9a:a19a/64 scope link 
       valid_lft forever preferred_lft forever
