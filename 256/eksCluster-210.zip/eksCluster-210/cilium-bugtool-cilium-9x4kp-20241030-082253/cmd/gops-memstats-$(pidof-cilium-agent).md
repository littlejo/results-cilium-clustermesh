alloc: 194.06MB (203488024 bytes)
total-alloc: 2.34GB (2515165472 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 64514687
frees: 62495546
heap-alloc: 194.06MB (203488024 bytes)
heap-sys: 250.95MB (263143424 bytes)
heap-idle: 28.67MB (30064640 bytes)
heap-in-use: 222.28MB (233078784 bytes)
heap-released: 3.97MB (4161536 bytes)
heap-objects: 2019141
stack-in-use: 69.00MB (72351744 bytes)
stack-sys: 69.00MB (72351744 bytes)
stack-mspan-inuse: 3.48MB (3650240 bytes)
stack-mspan-sys: 3.97MB (4161600 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.07MB (1117713 bytes)
gc-sys: 6.02MB (6317544 bytes)
next-gc: when heap-alloc >= 210.28MB (220492008 bytes)
last-gc: 2024-10-30 08:22:51.425509759 +0000 UTC
gc-pause-total: 9.449631ms
gc-pause: 92280
gc-pause-end: 1730276571425509759
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005381960530174881
enable-gc: true
debug-gc: false
