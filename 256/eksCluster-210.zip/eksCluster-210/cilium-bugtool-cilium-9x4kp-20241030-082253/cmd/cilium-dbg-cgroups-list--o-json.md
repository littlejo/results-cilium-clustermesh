[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod640d8d6e_7dd7_4d84_9185_35ce7f8d951d.slice/cri-containerd-9ecd7294d0cd0bec8a9a2928d0eccbfd76c081f9fe99e5e48e6f847cdf49b2a4.scope"
      }
    ],
    "ips": [
      "10.210.0.47"
    ],
    "name": "coredns-cc6ccd49c-m2krz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-e2a9d8caa68a7557d99ab0bb4feda896ad171f9d7cde6e955f2bead00824c1f9.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-6145fabe63469f478d69adb22827299476ac6da9da164fe660c799b7d4368f85.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3583e2c5_8cb6_4453_be87_df3ab7a1a853.slice/cri-containerd-cb4da437fe7f041b89fb6754d9b2e42f1e6e529b1f4a89cef8fe8c622ea09583.scope"
      }
    ],
    "ips": [
      "10.210.0.81"
    ],
    "name": "clustermesh-apiserver-7f85d44c78-4qsmb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2708220a_af70_4f7f_973e_69c3f94d701a.slice/cri-containerd-6cb607542a0a74b04d430b070db3e5558434e3b90120ad3edf28df4a3da9489a.scope"
      }
    ],
    "ips": [
      "10.210.0.172"
    ],
    "name": "coredns-cc6ccd49c-npqj9",
    "namespace": "kube-system"
  }
]

