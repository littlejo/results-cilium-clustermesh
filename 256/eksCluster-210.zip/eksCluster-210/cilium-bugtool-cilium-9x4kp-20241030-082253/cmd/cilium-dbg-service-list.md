ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.182.217:443 (active)    
                                        2 => 172.31.239.212:443 (active)    
2    10.100.72.169:443   ClusterIP      1 => 172.31.156.152:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.210.0.172:53 (active)       
                                        2 => 10.210.0.47:53 (active)        
4    10.100.0.10:9153    ClusterIP      1 => 10.210.0.172:9153 (active)     
                                        2 => 10.210.0.47:9153 (active)      
5    10.100.22.83:2379   ClusterIP      1 => 10.210.0.81:2379 (active)      
