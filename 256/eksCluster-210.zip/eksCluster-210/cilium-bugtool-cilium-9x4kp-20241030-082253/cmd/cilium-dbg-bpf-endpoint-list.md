IP ADDRESS         LOCAL ENDPOINT INFO
172.31.156.152:0   (localhost)                                                                                        
10.210.0.47:0      id=2236  sec_id=6937157 flags=0x0000 ifindex=14  mac=8E:94:50:17:83:85 nodemac=D6:68:30:E8:C0:C7   
10.210.0.172:0     id=1656  sec_id=6937157 flags=0x0000 ifindex=12  mac=5E:9D:77:8E:98:42 nodemac=DA:8B:5D:66:FD:73   
10.210.0.34:0      id=898   sec_id=4     flags=0x0000 ifindex=10  mac=9E:33:CB:4B:EA:36 nodemac=06:E3:0C:8C:64:10     
172.31.153.158:0   (localhost)                                                                                        
10.210.0.4:0       (localhost)                                                                                        
10.210.0.81:0      id=2376  sec_id=6925434 flags=0x0000 ifindex=18  mac=06:B4:2E:95:5E:B3 nodemac=A6:90:67:9A:A1:9A   
