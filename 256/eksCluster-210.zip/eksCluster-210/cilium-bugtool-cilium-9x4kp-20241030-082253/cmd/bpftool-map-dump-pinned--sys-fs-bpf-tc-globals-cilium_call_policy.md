key: 82 03 00 00  value: 19 02 00 00
key: 78 06 00 00  value: 12 02 00 00
key: bc 08 00 00  value: 03 02 00 00
key: 48 09 00 00  value: 7a 02 00 00
Found 4 elements
