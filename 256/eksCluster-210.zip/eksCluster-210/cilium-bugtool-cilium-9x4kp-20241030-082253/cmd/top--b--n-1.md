top - 08:22:54 up 28 min,  0 users,  load average: 0.15, 0.17, 0.13
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 44.8 us, 37.9 sy,  0.0 ni,  3.4 id,  0.0 wa,  0.0 hi, 13.8 si,  0.0 st
MiB Mem :   7814.2 total,   4454.9 free,   1212.4 used,   2146.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6416.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    736 root      20   0 1244340  22820  14144 S  40.0   0.3   0:00.06 hubble
      1 root      20   0 1606336 403976  77312 S  13.3   5.0   0:42.31 cilium-+
    698 root      20   0 1240432  16220  11484 S   6.7   0.2   0:00.03 cilium-+
    402 root      20   0 1229744   7004   2864 S   0.0   0.1   0:01.06 cilium-+
    680 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    726 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    732 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    752 root      20   0    2304    816    732 D   0.0   0.0   0:00.00 sh
    758 root      20   0    2304    816    732 R   0.0   0.0   0:00.00 sh
    759 root      20   0 1240432  16220  11484 R   0.0   0.2   0:00.00 cilium-+
