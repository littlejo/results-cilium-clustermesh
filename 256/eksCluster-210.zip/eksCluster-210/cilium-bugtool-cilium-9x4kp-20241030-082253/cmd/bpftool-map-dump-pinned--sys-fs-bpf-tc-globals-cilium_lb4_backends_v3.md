key: 08 00 00 00  value: 0a d2 00 2f 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a d2 00 ac 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a d2 00 51 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 9c 98 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a d2 00 2f 23 c1 00 00  00 00 00 00
key: 06 00 00 00  value: 0a d2 00 ac 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ef d4 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f b6 d9 01 bb 00 00  00 00 00 00
Found 8 elements
