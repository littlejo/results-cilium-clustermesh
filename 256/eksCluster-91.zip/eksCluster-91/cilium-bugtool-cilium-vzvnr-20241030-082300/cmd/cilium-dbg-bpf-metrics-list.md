REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38181     3023273     677    bpf_overlay.c
Interface                 INGRESS     672045    136825493   1132   bpf_host.c
Success                   EGRESS      17655     1395476     1694   bpf_host.c
Success                   EGRESS      289414    35605957    1308   bpf_lxc.c
Success                   EGRESS      3376      535616      86     l3.h
Success                   EGRESS      39092     3093117     53     encap.h
Success                   INGRESS     332046    37654110    86     l3.h
Success                   INGRESS     356599    39861569    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
