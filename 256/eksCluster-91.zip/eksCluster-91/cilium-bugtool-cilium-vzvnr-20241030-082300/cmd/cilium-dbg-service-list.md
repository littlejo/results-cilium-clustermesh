ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.203.23:443 (active)    
                                         2 => 172.31.186.225:443 (active)   
2    10.100.26.254:443    ClusterIP      1 => 172.31.250.18:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.91.0.187:53 (active)       
                                         2 => 10.91.0.39:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.91.0.187:9153 (active)     
                                         2 => 10.91.0.39:9153 (active)      
5    10.100.61.244:2379   ClusterIP      1 => 10.91.0.23:2379 (active)      
