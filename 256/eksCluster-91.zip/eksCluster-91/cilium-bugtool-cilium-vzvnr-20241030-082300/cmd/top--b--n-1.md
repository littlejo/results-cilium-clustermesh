top - 08:23:02 up 37 min,  0 users,  load average: 0.14, 0.29, 0.22
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 61.3 us, 35.5 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4467.1 free,   1200.0 used,   2147.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6429.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    742 root      20   0 1244596  21448  13944 S  31.2   0.3   0:00.05 hubble
      1 root      20   0 1606080 380572  78716 S  12.5   4.8   0:57.79 cilium-+
    657 root      20   0 1240432  16540  11292 S  12.5   0.2   0:00.04 cilium-+
    415 root      20   0 1229744   6820   2864 S   0.0   0.1   0:01.17 cilium-+
    658 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    687 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    688 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    723 root      20   0    6576   2416   2092 R   0.0   0.0   0:00.00 top
    735 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    766 root      20   0    3720   1292   1136 R   0.0   0.0   0:00.00 bash
