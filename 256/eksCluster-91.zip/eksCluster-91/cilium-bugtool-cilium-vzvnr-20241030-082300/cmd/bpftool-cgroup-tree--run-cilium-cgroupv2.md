CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2876746b_e740_470a_941a_c5581b8ec65d.slice/cri-containerd-3cd4b926b7e6482b1ebd32aabdabe04a2262d25d4ee46d493621492c8f0e1601.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2876746b_e740_470a_941a_c5581b8ec65d.slice/cri-containerd-cdd34c76e587c4fc057bc798f3e527ce2518b80725af11d46da4499b96fe748c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod66ab3966_ac37_43b3_a461_f1a37ca47a2f.slice/cri-containerd-7d26fb6333bdd847c8a84ee095ceaad695cda6477ec9699d1bdf0df15dbb5952.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod66ab3966_ac37_43b3_a461_f1a37ca47a2f.slice/cri-containerd-749eb75c53cd84517668dc056fa7139d427979a95a8fabb572bfcef59df7e576.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee0642ec_e893_4657_8370_9ee3784b8085.slice/cri-containerd-28647e8ca23952529ae20c587e17b26c15d7bdd7d8523d94428b4b9c495e8a89.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee0642ec_e893_4657_8370_9ee3784b8085.slice/cri-containerd-c944b9e2024855e4d25271effdde5a0ed69861ef433703116174698f1ee172d1.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a632271_e230_484a_bb86_05ef43ca8412.slice/cri-containerd-85758c65a440d325b3cfd21f38920130175533d2ec30a47116efee0211f7f44f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a632271_e230_484a_bb86_05ef43ca8412.slice/cri-containerd-668b844f5c48511086898598c0569cc471e2b2164df6e60b198c0a9be97d4e37.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d28cf0a_8203_4588_84f4_6fc6ceb8195d.slice/cri-containerd-a56f1bc5d085e0e60f2379be484289fd8e08e616a35fd786b1b7de7cb2484c42.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d28cf0a_8203_4588_84f4_6fc6ceb8195d.slice/cri-containerd-0f1e71cfcec93efe4f0bffd7ea6a8d887eaf6c371951ada3e8cf831070d035d1.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e5f59e7_8e6f_4abe_825f_e92f8e877092.slice/cri-containerd-5620835884e9a795a8fa7d844a21c0e95a9738082d323c28c45a8d7a187877eb.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1e5f59e7_8e6f_4abe_825f_e92f8e877092.slice/cri-containerd-fc79028c4616f0b8e3772c72b4c4238a6d75d69d78f0407ec16ddb902c42b169.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-0b293f4d9c2f4621b8d0dd6ace4b1a89b8753f9f982c3ee2db642142e14977a9.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-ec633b5a3aff284be88f10d092fdb605adb7074ba2b5a2dae022ab3a5b29dbe0.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-0f2118a06a2edd8f9153057a86347df37af352c528b8f5c569764aaa1667557d.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-872985821f952086b54ea479ef2bdbad3189313f3c45468704dbc2744f7e76f9.scope
    647      cgroup_device   multi                                          
