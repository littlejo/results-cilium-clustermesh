Endpoint ID: 108
Path: /sys/fs/bpf/tc/globals/cilium_policy_00108

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 423
Path: /sys/fs/bpf/tc/globals/cilium_policy_00423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    95223    853       0        
Allow    Ingress     1          ANY          NONE         disabled    175800   2021      0        
Allow    Egress      0          ANY          NONE         disabled    58043    577       0        


Endpoint ID: 489
Path: /sys/fs/bpf/tc/globals/cilium_policy_00489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    93063    835       0        
Allow    Ingress     1          ANY          NONE         disabled    173855   1997      0        
Allow    Egress      0          ANY          NONE         disabled    54890    554       0        


Endpoint ID: 1595
Path: /sys/fs/bpf/tc/globals/cilium_policy_01595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11629040   117058    0        
Allow    Ingress     1          ANY          NONE         disabled    10870598   114873    0        
Allow    Egress      0          ANY          NONE         disabled    14604467   142996    0        


Endpoint ID: 1652
Path: /sys/fs/bpf/tc/globals/cilium_policy_01652

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1676379   21233     0        
Allow    Ingress     1          ANY          NONE         disabled    26506     311       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


