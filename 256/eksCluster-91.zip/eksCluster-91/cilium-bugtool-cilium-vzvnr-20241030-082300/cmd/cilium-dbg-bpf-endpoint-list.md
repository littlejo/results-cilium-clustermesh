IP ADDRESS        LOCAL ENDPOINT INFO
172.31.250.18:0   (localhost)                                                                                        
10.91.0.187:0     id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B   
10.91.0.42:0      id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F     
10.91.0.39:0      id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9   
10.91.0.23:0      id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06   
10.91.0.70:0      (localhost)                                                                                        
172.31.238.46:0   (localhost)                                                                                        
