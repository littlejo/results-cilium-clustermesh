1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:49:4c:54:27:09 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.18/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3188sec preferred_lft 3188sec
    inet6 fe80::849:4cff:fe54:2709/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:bc:43:c9:81 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.238.46/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::899:bcff:fe43:c981/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:46:97:db:44:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6846:97ff:fedb:44cd/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:fb:e0:f5:77:ea brd ff:ff:ff:ff:ff:ff
    inet 10.91.0.70/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d0fb:e0ff:fef5:77ea/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether da:c0:9e:93:4c:d3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8c0:9eff:fe93:4cd3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 16:8e:46:ca:2f:7f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::148e:46ff:feca:2f7f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc4c76530c1040@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:52:04:21:d9:6b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f852:4ff:fe21:d96b/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc02a45896a570@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:da:66:ed:37:d9 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4cda:66ff:feed:37d9/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc982bf3a06d5c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:1f:41:aa:d4:06 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::2c1f:41ff:feaa:d406/64 scope link 
       valid_lft forever preferred_lft forever
