KEY             VALUE
AgentLiveness   2253533954048
UTimeOffset     3379442109375000
