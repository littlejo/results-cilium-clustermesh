alloc: 198.69MB (208342304 bytes)
total-alloc: 2.40GB (2573740320 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 65816095
frees: 63681259
heap-alloc: 198.69MB (208342304 bytes)
heap-sys: 243.26MB (255074304 bytes)
heap-idle: 24.62MB (25812992 bytes)
heap-in-use: 218.64MB (229261312 bytes)
heap-released: 1.27MB (1335296 bytes)
heap-objects: 2134836
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 3.47MB (3634400 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.23MB (1286425 bytes)
gc-sys: 6.03MB (6321808 bytes)
next-gc: when heap-alloc >= 214.43MB (224843640 bytes)
last-gc: 2024-10-30 08:23:02.461638891 +0000 UTC
gc-pause-total: 21.09033ms
gc-pause: 122160
gc-pause-end: 1730276582461638891
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.0003770739057145008
enable-gc: true
debug-gc: false
