USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         688  0.0  0.1 1616264 8852 ?        Ssl  08:23   0:00 /bin/gops stats 1
root         687  0.0  0.1 1539912 8312 ?        Ssl  08:23   0:00 /usr/sbin/runc init
root         681  0.0  0.1 1616264 8864 ?        Ssl  08:23   0:00 /usr/sbin/runc init
root         658  0.0  0.0 1228744 3600 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         657  0.0  0.2 1240432 16540 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         699  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root           1  3.1  4.7 1606080 380572 ?      Ssl  07:52   0:57 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.0 1229744 6820 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
