[
  {
    "containers": [
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-0b293f4d9c2f4621b8d0dd6ace4b1a89b8753f9f982c3ee2db642142e14977a9.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-0f2118a06a2edd8f9153057a86347df37af352c528b8f5c569764aaa1667557d.scope"
      },
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod89403fd1_555c_46fa_a128_7024361d01fc.slice/cri-containerd-872985821f952086b54ea479ef2bdbad3189313f3c45468704dbc2744f7e76f9.scope"
      }
    ],
    "ips": [
      "10.91.0.23"
    ],
    "name": "clustermesh-apiserver-7b5f8975c9-glmph",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podee0642ec_e893_4657_8370_9ee3784b8085.slice/cri-containerd-28647e8ca23952529ae20c587e17b26c15d7bdd7d8523d94428b4b9c495e8a89.scope"
      }
    ],
    "ips": [
      "10.91.0.187"
    ],
    "name": "coredns-cc6ccd49c-vwzdk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod66ab3966_ac37_43b3_a461_f1a37ca47a2f.slice/cri-containerd-7d26fb6333bdd847c8a84ee095ceaad695cda6477ec9699d1bdf0df15dbb5952.scope"
      }
    ],
    "ips": [
      "10.91.0.39"
    ],
    "name": "coredns-cc6ccd49c-rzqdg",
    "namespace": "kube-system"
  }
]

