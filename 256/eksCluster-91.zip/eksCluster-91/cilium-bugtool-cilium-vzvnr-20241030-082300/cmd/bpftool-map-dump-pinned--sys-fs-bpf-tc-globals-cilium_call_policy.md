key: a7 01 00 00  value: 06 02 00 00
key: e9 01 00 00  value: 25 02 00 00
key: 3b 06 00 00  value: 61 02 00 00
key: 74 06 00 00  value: 23 02 00 00
Found 4 elements
