{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.975Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.975Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:00.975Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.836Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.839Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.895Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.896Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:05.897Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:26.445Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:26.446Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:26.446Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:26.478Z",
  "value": "id=357   sec_id=3022028 flags=0x0000 ifindex=16  mac=BE:F5:5E:7F:D2:B2 nodemac=26:8A:BF:17:37:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:27.446Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:27.447Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:27.447Z",
  "value": "id=357   sec_id=3022028 flags=0x0000 ifindex=16  mac=BE:F5:5E:7F:D2:B2 nodemac=26:8A:BF:17:37:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:27.447Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.841Z",
  "value": "id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.91.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.723Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.813Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.814Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.814Z",
  "value": "id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.815Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.812Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.813Z",
  "value": "id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.815Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.815Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.813Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.813Z",
  "value": "id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.814Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.814Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.39:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.812Z",
  "value": "id=489   sec_id=3018768 flags=0x0000 ifindex=14  mac=7E:45:B5:D7:9C:14 nodemac=4E:DA:66:ED:37:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.812Z",
  "value": "id=1652  sec_id=4     flags=0x0000 ifindex=10  mac=46:6E:A1:61:DE:FF nodemac=16:8E:46:CA:2F:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.23:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.813Z",
  "value": "id=1595  sec_id=3022028 flags=0x0000 ifindex=18  mac=26:20:82:41:9B:FC nodemac=2E:1F:41:AA:D4:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.91.0.187:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.813Z",
  "value": "id=423   sec_id=3018768 flags=0x0000 ifindex=12  mac=AE:03:0E:CA:AB:2A nodemac=FA:52:04:21:D9:6B"
}

