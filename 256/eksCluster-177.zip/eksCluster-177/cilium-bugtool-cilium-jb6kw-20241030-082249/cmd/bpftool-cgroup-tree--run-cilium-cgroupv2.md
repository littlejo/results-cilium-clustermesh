CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3966584_74ea_4a39_9548_309e49301916.slice/cri-containerd-7d2c1d62e3e49a9cb491d0a7febb3db20f0e795394d54d5858a41f74865e5803.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb3966584_74ea_4a39_9548_309e49301916.slice/cri-containerd-bcfdb6f21e2ccd593500b0b6cb9200f57d57255a60b5b1dc0bf1f10031479851.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51dbf7ec_4eca_4337_86ab_1a250323fcb8.slice/cri-containerd-a253a10c87e551dea04f9050917ca883b9b6c8f4934ab9ea96c4dda345b3e9ce.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51dbf7ec_4eca_4337_86ab_1a250323fcb8.slice/cri-containerd-aaf5cd67f46b01075ad2299c8b8098f92181e5fc069493db3f59e0350e276d0b.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61043e67_8763_4b96_8f53_8139c86a454c.slice/cri-containerd-2bb51e89e1732f9568c4c7eb85018aca336a5e10106baa7ca4fc688cdfc3b47c.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61043e67_8763_4b96_8f53_8139c86a454c.slice/cri-containerd-4ea33b3902b0c2f8809f56ce7a1a3f4ebab2a118137a89b265e7c0371f032c8e.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dd82972_02c9_4feb_b4fa_82c9efb49a9a.slice/cri-containerd-68bcaa3247e9895682c1165aadda9f588290408d6623839f9f162252402254b0.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1dd82972_02c9_4feb_b4fa_82c9efb49a9a.slice/cri-containerd-26709fa3edfc76f3b6352a722ed6aedec7f7ff7c6584d925b8d84d825d8404b8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-1015de7b594079e80c79ca6a296dae6a1bafe1ccf31265dbdbc94aeeb73a9b46.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-739dd7be2733c49aeb84bf41ec2b7536bc9a7906d8b4e540c004307cb4dd3778.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-15f9c6d5f77eee6dfd5aa59d980d9368dd93ec63b33f8f905150aa1c0feac4a0.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-47c919a9719810ba6a061bb935537ccfc00a6218ad74d4f24910d181dec9e59f.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod133dcaf0_9fa2_4273_82b5_545bd8687694.slice/cri-containerd-3102178561c8ed09a10d148c7505573ef8e59b8704d5709ee19aaaea44a3ecc3.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod133dcaf0_9fa2_4273_82b5_545bd8687694.slice/cri-containerd-c7334b4482047aea807a5a58e49b035962ea041ca59c94ee5bbc9488fba5d6a0.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e3bca59_9b19_4c3b_b8fc_3d226739ebbb.slice/cri-containerd-620bcef47ed7a8de11e8a0eefd79d6119dcdced579adcfb23ba4377da2a54186.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2e3bca59_9b19_4c3b_b8fc_3d226739ebbb.slice/cri-containerd-35da3154e94458c3c52c5bf4b8ae91a3ad499a7f87a741713ac9561d4caffe61.scope
    102      cgroup_device   multi                                          
