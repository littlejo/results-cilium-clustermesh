USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         674  0.0  0.0  13060  1228 ?        Rs   08:22   0:00 /usr/sbin/runc init
root         654  0.0  0.0 1229000 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         648  0.0  0.2 1240432 16064 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         672  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         673  0.0  0.0   1764     4 ?        R    08:22   0:00  \_ bash -c hostname
root         616  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.2  4.7 1606080 381976 ?      Ssl  08:03   0:39 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229744 7036 ?        Sl   08:03   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
