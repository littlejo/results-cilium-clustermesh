alloc: 169.52MB (177750168 bytes)
total-alloc: 2.24GB (2406427176 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63387495
frees: 61539535
heap-alloc: 169.52MB (177750168 bytes)
heap-sys: 247.30MB (259309568 bytes)
heap-idle: 55.99MB (58712064 bytes)
heap-in-use: 191.30MB (200597504 bytes)
heap-released: 2.06MB (2162688 bytes)
heap-objects: 1847960
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.21MB (3369120 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 961.02KB (984089 bytes)
gc-sys: 6.04MB (6329880 bytes)
next-gc: when heap-alloc >= 212.27MB (222580904 bytes)
last-gc: 2024-10-30 08:22:56.104266834 +0000 UTC
gc-pause-total: 6.904976ms
gc-pause: 140000
gc-pause-end: 1730276576104266834
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.00041954254958664574
enable-gc: true
debug-gc: false
