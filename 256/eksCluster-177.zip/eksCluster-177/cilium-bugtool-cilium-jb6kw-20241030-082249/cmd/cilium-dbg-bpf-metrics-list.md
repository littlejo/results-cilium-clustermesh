REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36405     2885450     677    bpf_overlay.c
Interface                 INGRESS     643175    131679170   1132   bpf_host.c
Success                   EGRESS      16464     1296383     1694   bpf_host.c
Success                   EGRESS      269548    33967985    1308   bpf_lxc.c
Success                   EGRESS      36643     2902060     53     encap.h
Success                   INGRESS     314056    35335337    86     l3.h
Success                   INGRESS     334648    36968450    235    trace.h
Unsupported L3 protocol   EGRESS      45        3382        1492   bpf_lxc.c
