Total: 671
TCP:   1838 (estab 421, closed 1398, orphaned 0, timewait 567)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  440       430       10       
INET	  450       436       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:40285      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35916 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.201.97%ens5:68         0.0.0.0:*    uid:192 ino:15590 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35588 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15397 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35587 sk:100b cgroup:/ v6only:1 <->                                      
UNCONN 0      0                                [::1]:323           [::]:*    ino:15398 sk:100c cgroup:unreachable:f0c v6only:1 <->                        
UNCONN 0      0      [fe80::894:7bff:fe11:e9a7]%ens5:546           [::]:*    uid:192 ino:15582 sk:100d cgroup:unreachable:c4e v6only:1 <->                
