ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.183.93:443 (active)    
                                         2 => 172.31.220.56:443 (active)    
2    10.100.238.252:443   ClusterIP      1 => 172.31.201.97:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.177.0.36:53 (active)       
                                         2 => 10.177.0.7:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.177.0.36:9153 (active)     
                                         2 => 10.177.0.7:9153 (active)      
5    10.100.84.160:2379   ClusterIP      1 => 10.177.0.84:2379 (active)     
