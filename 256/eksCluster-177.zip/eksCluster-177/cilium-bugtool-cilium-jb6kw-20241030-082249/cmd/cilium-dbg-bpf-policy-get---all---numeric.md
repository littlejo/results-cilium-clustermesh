Endpoint ID: 86
Path: /sys/fs/bpf/tc/globals/cilium_policy_00086

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114692   1323      0        
Allow    Egress      0          ANY          NONE         disabled    16470    177       0        


Endpoint ID: 141
Path: /sys/fs/bpf/tc/globals/cilium_policy_00141

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2514
Path: /sys/fs/bpf/tc/globals/cilium_policy_02514

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1638037   20654     0        
Allow    Ingress     1          ANY          NONE         disabled    17882     209       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3106
Path: /sys/fs/bpf/tc/globals/cilium_policy_03106

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11562289   114852    0        
Allow    Ingress     1          ANY          NONE         disabled    10124505   106462    0        
Allow    Egress      0          ANY          NONE         disabled    12528089   123555    0        


Endpoint ID: 3966
Path: /sys/fs/bpf/tc/globals/cilium_policy_03966

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114399   1315      0        
Allow    Egress      0          ANY          NONE         disabled    16208    173       0        


