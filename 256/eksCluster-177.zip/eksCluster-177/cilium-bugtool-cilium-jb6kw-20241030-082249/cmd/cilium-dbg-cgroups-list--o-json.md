[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-1015de7b594079e80c79ca6a296dae6a1bafe1ccf31265dbdbc94aeeb73a9b46.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-47c919a9719810ba6a061bb935537ccfc00a6218ad74d4f24910d181dec9e59f.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podab21928b_4c6c_49ee_933e_f49e4af8a7f2.slice/cri-containerd-739dd7be2733c49aeb84bf41ec2b7536bc9a7906d8b4e540c004307cb4dd3778.scope"
      }
    ],
    "ips": [
      "10.177.0.84"
    ],
    "name": "clustermesh-apiserver-6667b8d7f9-grxqf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod51dbf7ec_4eca_4337_86ab_1a250323fcb8.slice/cri-containerd-a253a10c87e551dea04f9050917ca883b9b6c8f4934ab9ea96c4dda345b3e9ce.scope"
      }
    ],
    "ips": [
      "10.177.0.36"
    ],
    "name": "coredns-cc6ccd49c-p5pdl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod61043e67_8763_4b96_8f53_8139c86a454c.slice/cri-containerd-4ea33b3902b0c2f8809f56ce7a1a3f4ebab2a118137a89b265e7c0371f032c8e.scope"
      }
    ],
    "ips": [
      "10.177.0.7"
    ],
    "name": "coredns-cc6ccd49c-xvgbq",
    "namespace": "kube-system"
  }
]

