1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:94:7b:11:e9:a7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.201.97/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1838sec preferred_lft 1838sec
    inet6 fe80::894:7bff:fe11:e9a7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:f9:84:fc:54:8d brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.61/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8f9:84ff:fefc:548d/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:b0:f1:8e:37:32 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::54b0:f1ff:fe8e:3732/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:2c:47:1d:73:92 brd ff:ff:ff:ff:ff:ff
    inet 10.177.0.9/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::7c2c:47ff:fe1d:7392/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ae:0f:19:ee:81:0d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::ac0f:19ff:feee:810d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:0b:c4:63:b5:39 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::580b:c4ff:fe63:b539/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc401d36194127@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:5d:64:90:43:1d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::185d:64ff:fe90:431d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcabe942c15451@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:a5:1d:75:fd:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::eca5:1dff:fe75:fdd6/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5bb924353393@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:46:d0:34:6d:63 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::446:d0ff:fe34:6d63/64 scope link 
       valid_lft forever preferred_lft forever
