KEY             VALUE
AgentLiveness   1806033137768
UTimeOffset     3379442960937500
