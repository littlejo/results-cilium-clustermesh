key: 56 00 00 00  value: 12 02 00 00
key: d2 09 00 00  value: 25 02 00 00
key: 22 0c 00 00  value: 6a 02 00 00
key: 7e 0f 00 00  value: 24 02 00 00
Found 4 elements
