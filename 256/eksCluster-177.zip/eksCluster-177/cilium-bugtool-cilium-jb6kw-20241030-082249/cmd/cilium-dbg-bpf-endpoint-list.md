IP ADDRESS        LOCAL ENDPOINT INFO
10.177.0.139:0    id=2514  sec_id=4     flags=0x0000 ifindex=10  mac=EE:F3:DE:6A:4A:F2 nodemac=5A:0B:C4:63:B5:39     
10.177.0.7:0      id=86    sec_id=5854175 flags=0x0000 ifindex=12  mac=92:0A:CC:D8:BF:50 nodemac=1A:5D:64:90:43:1D   
10.177.0.9:0      (localhost)                                                                                        
10.177.0.84:0     id=3106  sec_id=5837999 flags=0x0000 ifindex=18  mac=A2:97:7D:7C:DA:81 nodemac=06:46:D0:34:6D:63   
172.31.245.61:0   (localhost)                                                                                        
10.177.0.36:0     id=3966  sec_id=5854175 flags=0x0000 ifindex=14  mac=9A:54:E1:BC:ED:58 nodemac=EE:A5:1D:75:FD:D6   
172.31.201.97:0   (localhost)                                                                                        
