xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 496
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 490
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 482
cilium_host(7) clsact/egress cil_from_host-cilium_host id 486
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 480
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 521
lxcdffe4ec92e3e(12) clsact/ingress cil_from_container-lxcdffe4ec92e3e id 538
lxc9115ee5ab5e5(14) clsact/ingress cil_from_container-lxc9115ee5ab5e5 id 550
lxc02b893ee454b(18) clsact/ingress cil_from_container-lxc02b893ee454b id 616

flow_dissector:

netfilter:

