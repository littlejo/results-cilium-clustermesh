Endpoint ID: 240
Path: /sys/fs/bpf/tc/globals/cilium_policy_00240

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11380122   111754    0        
Allow    Ingress     1          ANY          NONE         disabled    9630513    100807    0        
Allow    Egress      0          ANY          NONE         disabled    11154521   110773    0        


Endpoint ID: 308
Path: /sys/fs/bpf/tc/globals/cilium_policy_00308

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1646254   20817     0        
Allow    Ingress     1          ANY          NONE         disabled    18558     217       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 898
Path: /sys/fs/bpf/tc/globals/cilium_policy_00898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2090
Path: /sys/fs/bpf/tc/globals/cilium_policy_02090

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    120862   1390      0        
Allow    Egress      0          ANY          NONE         disabled    17787    193       0        


Endpoint ID: 2291
Path: /sys/fs/bpf/tc/globals/cilium_policy_02291

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    121442   1395      0        
Allow    Egress      0          ANY          NONE         disabled    16001    173       0        


