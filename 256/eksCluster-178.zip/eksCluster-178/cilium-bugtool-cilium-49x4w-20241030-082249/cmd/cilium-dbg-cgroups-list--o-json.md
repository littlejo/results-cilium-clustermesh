[
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-a9dc863fd5e6c39b5ca4dd9a9d3ee29990e54e5e81829210a32177165a269274.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-dd2b31456bfa52172515fcb336875ccc5c8e3c0f4a791813c780e9311c32818f.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-a0ab25024caf00e1cd7c0556aa946b5ca83a7572c1b8dc31d56932e5e54ce960.scope"
      }
    ],
    "ips": [
      "10.178.0.27"
    ],
    "name": "clustermesh-apiserver-556bf76f99-pttfb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6c546f8_6c64_435b_b4e4_60b4f7737c57.slice/cri-containerd-350d0bb40a799dc3008111777221af8eadcc3d5a950162dab50ed07500d21a22.scope"
      }
    ],
    "ips": [
      "10.178.0.7"
    ],
    "name": "coredns-cc6ccd49c-6zv5x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65953fea_63f3_43e4_9b7e_163e76592ff5.slice/cri-containerd-4cac182a0f1037bb51e1adcffa5c7a266313ddb551d20f675a9e46ef55746643.scope"
      }
    ],
    "ips": [
      "10.178.0.65"
    ],
    "name": "coredns-cc6ccd49c-5w5sz",
    "namespace": "kube-system"
  }
]

