IP ADDRESS         LOCAL ENDPOINT INFO
10.178.0.63:0      (localhost)                                                                                        
10.178.0.27:0      id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14   
10.178.0.12:0      id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27     
172.31.169.223:0   (localhost)                                                                                        
172.31.169.181:0   (localhost)                                                                                        
10.178.0.65:0      id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC   
10.178.0.7:0       id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D   
