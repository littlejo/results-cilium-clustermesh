{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "1 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "2 0 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.1:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "0 2 (1) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.6.194:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "0 0 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:06.403Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.6.194:443 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.201Z",
  "value": "3 0 (2) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.6.194:443 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:11.201Z",
  "value": "0 1 (2) [0x0 0x10]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.127Z",
  "value": "0 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.127Z",
  "value": "0 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.172Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.172Z",
  "value": "0 1 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.172Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.172Z",
  "value": "0 1 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "4 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "6 0 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:53 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "0 2 (3) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "5 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "7 0 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.0.10:9153 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:15.191Z",
  "value": "0 2 (4) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:00.340Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:21.493Z",
  "value": "0 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.512Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.512Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.324Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:10.324Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.437Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.437Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.437Z",
  "value": "0 2 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.546Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.546Z",
  "value": "8 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.546Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (1)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.153Z",
  "value": "9 0 (5) [0x0 0x0]"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.100.53.11:2379 (0)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.153Z",
  "value": "0 1 (5) [0x0 0x0]"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.100.53.11:2379 (2)",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.153Z",
  "value": "\u003cnil\u003e"
}

