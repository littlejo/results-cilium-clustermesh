filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcdffe4ec92e3e direct-action not_in_hw id 538 tag 74e86b885b959d88 jited 
