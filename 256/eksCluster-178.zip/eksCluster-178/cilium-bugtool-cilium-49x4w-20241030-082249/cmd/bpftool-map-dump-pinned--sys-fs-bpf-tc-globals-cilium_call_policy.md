key: f0 00 00 00  value: 63 02 00 00
key: 34 01 00 00  value: 0b 02 00 00
key: 2a 08 00 00  value: 23 02 00 00
key: f3 08 00 00  value: 1c 02 00 00
Found 4 elements
