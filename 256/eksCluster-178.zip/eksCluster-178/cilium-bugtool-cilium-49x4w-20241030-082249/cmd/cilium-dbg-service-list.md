ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.243.21:443 (active)     
                                        2 => 172.31.188.123:443 (active)    
2    10.100.6.194:443    ClusterIP      1 => 172.31.169.181:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.178.0.65:53 (active)        
                                        2 => 10.178.0.7:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.178.0.65:9153 (active)      
                                        2 => 10.178.0.7:9153 (active)       
5    10.100.53.11:2379   ClusterIP      1 => 10.178.0.27:2379 (active)      
