{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.169.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:08.585Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:12.914Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:12.952Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.315Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.328Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:13.363Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.223Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.224Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:14.224Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.944Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.944Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.945Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:08.979Z",
  "value": "id=377   sec_id=5868971 flags=0x0000 ifindex=16  mac=FE:0F:3F:C5:E6:45 nodemac=3A:BB:F1:0E:37:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:09.945Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:09.946Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:09.946Z",
  "value": "id=377   sec_id=5868971 flags=0x0000 ifindex=16  mac=FE:0F:3F:C5:E6:45 nodemac=3A:BB:F1:0E:37:2E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:09.946Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:09.484Z",
  "value": "id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.178.0.106:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.031Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.311Z",
  "value": "id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.313Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.313Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:21.314Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.311Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.311Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.311Z",
  "value": "id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:22.311Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.310Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.311Z",
  "value": "id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.311Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:23.312Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.7:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.311Z",
  "value": "id=2090  sec_id=5884035 flags=0x0000 ifindex=14  mac=DA:96:50:FC:DC:05 nodemac=2E:C4:F8:F5:4E:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.12:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.312Z",
  "value": "id=308   sec_id=4     flags=0x0000 ifindex=10  mac=5E:82:27:EE:6B:9B nodemac=BA:08:7F:FE:2D:27"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.27:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.312Z",
  "value": "id=240   sec_id=5868971 flags=0x0000 ifindex=18  mac=6A:CB:11:D0:33:44 nodemac=0A:2A:8B:1F:1C:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.178.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:24.312Z",
  "value": "id=2291  sec_id=5884035 flags=0x0000 ifindex=12  mac=6A:C8:2E:7F:A0:08 nodemac=0A:01:82:02:9C:BC"
}

