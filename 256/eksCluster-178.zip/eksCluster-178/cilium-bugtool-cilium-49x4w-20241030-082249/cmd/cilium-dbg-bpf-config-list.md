KEY             VALUE
AgentLiveness   1882144169931
UTimeOffset     3379442812500000
