USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         695  0.0  0.1 1240432 15876 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         720  0.0  0.0   6408  1632 ?        R    08:22   0:00  \_ ps auxfw
root         721  0.0  0.1 1240432 15876 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         694  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         680  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         674  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         663  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.5  4.7 1606336 378676 ?      Ssl  08:01   0:43 cilium-agent --config-dir=/tmp/cilium/config-map
root         418  0.0  0.0 1229744 7260 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
