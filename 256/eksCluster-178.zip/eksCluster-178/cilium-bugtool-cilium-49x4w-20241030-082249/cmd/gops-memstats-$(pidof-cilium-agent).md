alloc: 133.14MB (139605472 bytes)
total-alloc: 2.19GB (2351658608 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 62470007
frees: 61292678
heap-alloc: 133.14MB (139605472 bytes)
heap-sys: 247.42MB (259440640 bytes)
heap-idle: 74.27MB (77873152 bytes)
heap-in-use: 173.16MB (181567488 bytes)
heap-released: 3.12MB (3276800 bytes)
heap-objects: 1177329
stack-in-use: 64.53MB (67665920 bytes)
stack-sys: 64.53MB (67665920 bytes)
stack-mspan-inuse: 2.91MB (3048160 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1261713 bytes)
gc-sys: 6.03MB (6323760 bytes)
next-gc: when heap-alloc >= 217.86MB (228442776 bytes)
last-gc: 2024-10-30 08:23:09.553672101 +0000 UTC
gc-pause-total: 11.952309ms
gc-pause: 91382
gc-pause-end: 1730276589553672101
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.00043712668620241827
enable-gc: true
debug-gc: false
