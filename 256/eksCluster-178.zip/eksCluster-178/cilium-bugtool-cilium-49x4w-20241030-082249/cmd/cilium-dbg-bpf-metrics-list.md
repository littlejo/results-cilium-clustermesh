REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35358     2794106     677    bpf_overlay.c
Interface                 INGRESS     626986    129615714   1132   bpf_host.c
Success                   EGRESS      15241     1195948     1694   bpf_host.c
Success                   EGRESS      262277    33307834    1308   bpf_lxc.c
Success                   EGRESS      34875     2760414     53     encap.h
Success                   INGRESS     305282    34184197    86     l3.h
Success                   INGRESS     326050    35826401    235    trace.h
Unsupported L3 protocol   EGRESS      48        3648        1492   bpf_lxc.c
