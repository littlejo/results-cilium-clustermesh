CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod165a9792_2b23_4a35_b50f_51310489b7b6.slice/cri-containerd-7e1defb3b75d2fbd6a1c1466a179a45998b21cf06cf51a5d059eb881ef0cc702.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod165a9792_2b23_4a35_b50f_51310489b7b6.slice/cri-containerd-a4c29a5b5d070bea4744895ee99680e4d6c23967b21bccbf67121fe8473bb08c.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65953fea_63f3_43e4_9b7e_163e76592ff5.slice/cri-containerd-02d1d4de4b3f58c27a493372c08d9b3900c213b15e3c9c9ae14a74defbc85a8f.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod65953fea_63f3_43e4_9b7e_163e76592ff5.slice/cri-containerd-4cac182a0f1037bb51e1adcffa5c7a266313ddb551d20f675a9e46ef55746643.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod281f6365_2500_432a_b3f5_438255b1267f.slice/cri-containerd-f7cf016c249d8c52546cbda306c5ed002171ca87f5f2fa4ec2179a62c54f4d89.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod281f6365_2500_432a_b3f5_438255b1267f.slice/cri-containerd-f4d67493d0c97d428e63e90245c09f6a089238da15cc4251910468a110f9fffb.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6c546f8_6c64_435b_b4e4_60b4f7737c57.slice/cri-containerd-350d0bb40a799dc3008111777221af8eadcc3d5a950162dab50ed07500d21a22.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6c546f8_6c64_435b_b4e4_60b4f7737c57.slice/cri-containerd-fe060d24a8d18667b9f1b83d93058c03324f6379abe089c1a3e70129fb139573.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-bf8fca337d58a7c4addebb6697539f83d04ea677103a4d721d81231da1395cac.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-dd2b31456bfa52172515fcb336875ccc5c8e3c0f4a791813c780e9311c32818f.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-a0ab25024caf00e1cd7c0556aa946b5ca83a7572c1b8dc31d56932e5e54ce960.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbbe6f80c_84d4_4874_bf83_39411a27e534.slice/cri-containerd-a9dc863fd5e6c39b5ca4dd9a9d3ee29990e54e5e81829210a32177165a269274.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50700e6d_8cc6_4f6e_aeb7_0bdf3e636892.slice/cri-containerd-6cb2c4ffc87c79bbe50552eb8ae534813d59ef17a04495c23c616d6244cc410b.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod50700e6d_8cc6_4f6e_aeb7_0bdf3e636892.slice/cri-containerd-95f92f419866ecf85e17fccda7cea6d4a0452387ed2f4d73a3053fd4cf88b0b9.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcaf5010e_1ee5_46e1_84ee_b442ee0b198f.slice/cri-containerd-a75b66aad852e9995c18213a2b470148014d66d0df5bc8a4c8aabc2e52535120.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcaf5010e_1ee5_46e1_84ee_b442ee0b198f.slice/cri-containerd-fef855d6bb81727b4f3cdac818cf1f27a8bf8a6512e2842c6239ef055c2fff51.scope
    99       cgroup_device   multi                                          
