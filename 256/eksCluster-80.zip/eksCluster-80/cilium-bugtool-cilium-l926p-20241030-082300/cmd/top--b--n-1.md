top - 08:23:01 up 35 min,  0 users,  load average: 1.32, 0.39, 0.18
Tasks:  10 total,   2 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 56.7 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4499.8 free,   1180.6 used,   2133.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6448.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 385100  78720 S  73.3   4.8   0:49.23 cilium-+
    671 root      20   0 1240432  16520  11292 S   6.7   0.2   0:00.03 cilium-+
    751 root      20   0 1243764  17736  12680 S   6.7   0.2   0:00.01 hubble
    394 root      20   0 1229744   8072   3836 S   0.0   0.1   0:01.16 cilium-+
    683 root      20   0 1228744   3584   2896 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1229000   3996   3336 S   0.0   0.0   0:00.00 gops
    726 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    744 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    764 root      20   0 1228744   2720   2216 R   0.0   0.0   0:00.00 gops
    766 root      20   0 1550472   8356   6288 S   0.0   0.1   0:00.00 runc:[2+
