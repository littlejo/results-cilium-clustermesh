Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170446   1963      0        
Allow    Egress      0          ANY          NONE         disabled    19597    219       0        


Endpoint ID: 390
Path: /sys/fs/bpf/tc/globals/cilium_policy_00390

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671684   21126     0        
Allow    Ingress     1          ANY          NONE         disabled    25200     294       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1557
Path: /sys/fs/bpf/tc/globals/cilium_policy_01557

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2100
Path: /sys/fs/bpf/tc/globals/cilium_policy_02100

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171061   1967      0        
Allow    Egress      0          ANY          NONE         disabled    19608    219       0        


Endpoint ID: 2680
Path: /sys/fs/bpf/tc/globals/cilium_policy_02680

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11251176   109701    0        
Allow    Ingress     1          ANY          NONE         disabled    9111654    95099     0        
Allow    Egress      0          ANY          NONE         disabled    10712090   106995    0        


