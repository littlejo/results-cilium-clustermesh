{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.244:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:49.117Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.140.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:49.117Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.191.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:49.117Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.304Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.346Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.395Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.467Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:54.525Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.780Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.780Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.780Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:20.809Z",
  "value": "id=148   sec_id=2686301 flags=0x0000 ifindex=16  mac=2A:C6:88:6D:72:0B nodemac=4E:CF:5C:9A:1E:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.780Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.781Z",
  "value": "id=148   sec_id=2686301 flags=0x0000 ifindex=16  mac=2A:C6:88:6D:72:0B nodemac=4E:CF:5C:9A:1E:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.781Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.781Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:32.357Z",
  "value": "id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.80.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.825Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.407Z",
  "value": "id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.407Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.408Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:56.408Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.416Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.417Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.417Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:57.417Z",
  "value": "id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.415Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.416Z",
  "value": "id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.416Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.416Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.416Z",
  "value": "id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.416Z",
  "value": "id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.251:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.416Z",
  "value": "id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.80.0.32:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:59.416Z",
  "value": "id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57"
}

