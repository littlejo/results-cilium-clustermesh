1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:96:71:dd:98:b9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.140.137/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3255sec preferred_lft 3255sec
    inet6 fe80::496:71ff:fedd:98b9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:45:83:95:5b:f7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.191.237/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::445:83ff:fe95:5bf7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:de:1c:c8:30:7c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::dcde:1cff:fec8:307c/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:c6:0d:2a:99:6a brd ff:ff:ff:ff:ff:ff
    inet 10.80.0.244/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::40c6:dff:fe2a:996a/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:ea:04:19:62:29 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2cea:4ff:fe19:6229/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 82:5f:f4:3e:17:2c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::805f:f4ff:fe3e:172c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcdfeb94b9d9fd@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:72:a6:db:5a:31 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4872:a6ff:fedb:5a31/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc7b82457c00d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ea:75:4e:46:4b:57 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e875:4eff:fe46:4b57/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3548fca6768f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:04:e4:90:a2:99 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1004:e4ff:fe90:a299/64 scope link 
       valid_lft forever preferred_lft forever
