filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc7b82457c00d direct-action not_in_hw id 515 tag 48330a5a78b1a9e5 jited 
