CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podafd7fe14_e9fa_4fa1_8f0c_7c54eb4b06a7.slice/cri-containerd-e957d9a9c70f183a3cf07a3c578c9f326dfd205cf2b967173bad70e9fb057ed2.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podafd7fe14_e9fa_4fa1_8f0c_7c54eb4b06a7.slice/cri-containerd-d5dfdc6a544b1bc963973748440d42b4ec37a5a3b8afd1b20c4634062cdb5c89.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a8ade6c_8ee7_4746_a1ee_97e98f2d57d0.slice/cri-containerd-b279e0ff638bc6e15a20f6fd63978bd7d2ff92633afc3f5bd042a7d1122740d9.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a8ade6c_8ee7_4746_a1ee_97e98f2d57d0.slice/cri-containerd-d6978cc8d762a8ccc4c68ed29a400d12307cf55ca1761de2c25b41241a409eb0.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e34d32e_3efa_427a_b653_eb8ca1a0c77a.slice/cri-containerd-056a9079b882b813ec0a7c36cdcc25c6e5f0a4c7ade243554172d1d93bfe1310.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7e34d32e_3efa_427a_b653_eb8ca1a0c77a.slice/cri-containerd-7f92090b524721669e4213fb1d02506df6eae5dcd49706f515a70ce2e520fc37.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba3c4206_9f6f_425d_83b6_507b37147965.slice/cri-containerd-75187eeb123c2df997f7fd956f0b3efec84d8eb839eb69f343d65ee358eaacac.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podba3c4206_9f6f_425d_83b6_507b37147965.slice/cri-containerd-b4b9eba177b840d83f35e25e267a01e9ebfbd2beacee30ae5475339960024fe1.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8f361_45f6_4abc_81ab_f4484ea3f9a7.slice/cri-containerd-ba33e792bed66e982fbfde5c6f4f6b6bf1586e8f0c784ad069145919a85f4a86.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2ec8f361_45f6_4abc_81ab_f4484ea3f9a7.slice/cri-containerd-475a774fb4df9f17ae8590fbf77374768901c2779eaa30270f9109c424256541.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-7d87a289dfbc633f06dcc1fd3820b9b9fcba619be44107debfc508089ce9bfc9.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-add35a670bfd6a81451a775da87221e2c9416f9954b18eb30c1444fd1f8e94a4.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-418942ad626b43d8230e7ae1ed375c0f9d7e02562d8e27d2d5c7624607669fc0.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-8abcc14ed30bcb79625f11c3a9e1f276cc5ede1413576e3b908a6c056bbe5f4d.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c2acfaa_d381_4f91_b384_817be28c17a7.slice/cri-containerd-64399e43bc769d1d10ef5b5426031af37e7d2df643e8f828466cd50d1782adbb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1c2acfaa_d381_4f91_b384_817be28c17a7.slice/cri-containerd-6d0d418090b7e6b74d22f6e90e903815e192297cf1d1e0d02e538275f11094b6.scope
    102      cgroup_device   multi                                          
