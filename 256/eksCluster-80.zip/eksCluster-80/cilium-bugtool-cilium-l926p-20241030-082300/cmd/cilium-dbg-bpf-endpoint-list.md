IP ADDRESS         LOCAL ENDPOINT INFO
10.80.0.129:0      id=390   sec_id=4     flags=0x0000 ifindex=10  mac=CE:29:89:12:D1:99 nodemac=82:5F:F4:3E:17:2C     
10.80.0.46:0       id=2680  sec_id=2686301 flags=0x0000 ifindex=18  mac=3E:B4:03:0F:A9:4F nodemac=12:04:E4:90:A2:99   
10.80.0.251:0      id=2100  sec_id=2655536 flags=0x0000 ifindex=12  mac=46:44:ED:A0:93:6C nodemac=4A:72:A6:DB:5A:31   
172.31.140.137:0   (localhost)                                                                                        
10.80.0.32:0       id=234   sec_id=2655536 flags=0x0000 ifindex=14  mac=62:13:58:23:8E:CB nodemac=EA:75:4E:46:4B:57   
172.31.191.237:0   (localhost)                                                                                        
10.80.0.244:0      (localhost)                                                                                        
