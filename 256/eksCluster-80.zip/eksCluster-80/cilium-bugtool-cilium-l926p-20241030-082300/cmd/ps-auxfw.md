USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         684  0.0  0.0 1229000 3996 ?        Ssl  08:23   0:00 /bin/gops stack 1
root         683  0.0  0.0 1228744 3584 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         671  0.0  0.2 1240432 16204 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         709  0.0  0.2 1240432 16204 ?       R    08:23   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  2.7  4.7 1606080 382664 ?      Ssl  07:53   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.1 1229744 8072 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
