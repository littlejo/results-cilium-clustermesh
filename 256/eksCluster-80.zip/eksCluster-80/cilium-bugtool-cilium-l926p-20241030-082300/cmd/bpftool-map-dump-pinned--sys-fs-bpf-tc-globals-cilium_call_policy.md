key: ea 00 00 00  value: fb 01 00 00
key: 86 01 00 00  value: 0c 02 00 00
key: 34 08 00 00  value: 23 02 00 00
key: 78 0a 00 00  value: 79 02 00 00
Found 4 elements
