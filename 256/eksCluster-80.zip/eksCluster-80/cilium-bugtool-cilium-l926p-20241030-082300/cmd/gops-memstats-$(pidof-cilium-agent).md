alloc: 146.78MB (153914848 bytes)
total-alloc: 2.21GB (2377731664 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 62676163
frees: 61121024
heap-alloc: 146.78MB (153914848 bytes)
heap-sys: 255.66MB (268083200 bytes)
heap-idle: 77.23MB (80977920 bytes)
heap-in-use: 178.44MB (187105280 bytes)
heap-released: 5.92MB (6209536 bytes)
heap-objects: 1555139
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.02MB (3165280 bytes)
stack-mspan-sys: 3.91MB (4096320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 927.62KB (949881 bytes)
gc-sys: 6.01MB (6297136 bytes)
next-gc: when heap-alloc >= 214.44MB (224854984 bytes)
last-gc: 2024-10-30 08:23:06.981711018 +0000 UTC
gc-pause-total: 29.102678ms
gc-pause: 67700
gc-pause-end: 1730276586981711018
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003433465711913205
enable-gc: true
debug-gc: false
