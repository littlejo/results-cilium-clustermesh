[
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podafd7fe14_e9fa_4fa1_8f0c_7c54eb4b06a7.slice/cri-containerd-e957d9a9c70f183a3cf07a3c578c9f326dfd205cf2b967173bad70e9fb057ed2.scope"
      }
    ],
    "ips": [
      "10.80.0.251"
    ],
    "name": "coredns-cc6ccd49c-ltpgp",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-418942ad626b43d8230e7ae1ed375c0f9d7e02562d8e27d2d5c7624607669fc0.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-7d87a289dfbc633f06dcc1fd3820b9b9fcba619be44107debfc508089ce9bfc9.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15a87760_046a_43d6_8cba_9095beb4bd3f.slice/cri-containerd-8abcc14ed30bcb79625f11c3a9e1f276cc5ede1413576e3b908a6c056bbe5f4d.scope"
      }
    ],
    "ips": [
      "10.80.0.46"
    ],
    "name": "clustermesh-apiserver-5d85755b89-l75kx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0a8ade6c_8ee7_4746_a1ee_97e98f2d57d0.slice/cri-containerd-d6978cc8d762a8ccc4c68ed29a400d12307cf55ca1761de2c25b41241a409eb0.scope"
      }
    ],
    "ips": [
      "10.80.0.32"
    ],
    "name": "coredns-cc6ccd49c-zwzqx",
    "namespace": "kube-system"
  }
]

