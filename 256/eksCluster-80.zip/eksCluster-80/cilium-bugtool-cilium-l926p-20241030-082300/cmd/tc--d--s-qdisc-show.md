qdisc noqueue 0: dev lo root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc mq 0: dev ens5 root 
 Sent 67521811 bytes 333936 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq_codel 0: dev ens5 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 32115387 bytes 168777 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 1394 drop_overlimit 0 new_flow_count 439 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc fq_codel 0: dev ens5 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 35406424 bytes 165159 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 25738 drop_overlimit 0 new_flow_count 430 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc clsact ffff: dev ens5 parent ffff:fff1 
 Sent 89376971 bytes 331117 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc mq 0: dev ens6 root 
 Sent 2616 bytes 50 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc fq_codel 0: dev ens6 parent :2 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 86 bytes 1 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 0 drop_overlimit 0 new_flow_count 0 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc fq_codel 0: dev ens6 parent :1 limit 10240p flows 1024 quantum 9015 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
 Sent 2530 bytes 49 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
  maxpacket 0 drop_overlimit 0 new_flow_count 0 ecn_mark 0
  new_flows_len 0 old_flows_len 0
qdisc clsact ffff: dev ens6 parent ffff:fff1 
 Sent 812 bytes 29 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_net root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
 Sent 34540 bytes 644 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_host root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
 Sent 35874478 bytes 331549 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
 Sent 4854210 bytes 67456 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc_health root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc_health parent ffff:fff1 
 Sent 1035023 bytes 15932 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxcdfeb94b9d9fd root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxcdfeb94b9d9fd parent ffff:fff1 
 Sent 148877 bytes 1785 pkt (dropped 8, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxcc7b82457c00d root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxcc7b82457c00d parent ffff:fff1 
 Sent 149438 bytes 1796 pkt (dropped 8, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc noqueue 0: dev lxc3548fca6768f root refcnt 2 
 Sent 0 bytes 0 pkt (dropped 0, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
qdisc clsact ffff: dev lxc3548fca6768f parent ffff:fff1 
 Sent 25741548 bytes 233431 pkt (dropped 12, overlimits 0 requeues 0) 
 backlog 0b 0p requeues 0
