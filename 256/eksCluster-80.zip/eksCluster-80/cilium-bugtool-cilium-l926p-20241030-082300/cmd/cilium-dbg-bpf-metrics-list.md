REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34359     2713831     677    bpf_overlay.c
Interface                 INGRESS     612334    128600435   1132   bpf_host.c
Success                   EGRESS      13954     1091829     1694   bpf_host.c
Success                   EGRESS      259131    33073825    1308   bpf_lxc.c
Success                   EGRESS      33131     2623732     53     encap.h
Success                   INGRESS     300107    33607167    86     l3.h
Success                   INGRESS     321164    35273285    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
