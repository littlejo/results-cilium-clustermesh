ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.190.42:443 (active)     
                                         2 => 172.31.198.44:443 (active)     
2    10.100.43.149:443    ClusterIP      1 => 172.31.140.137:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.80.0.32:53 (active)         
                                         2 => 10.80.0.251:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.80.0.32:9153 (active)       
                                         2 => 10.80.0.251:9153 (active)      
5    10.100.51.220:2379   ClusterIP      1 => 10.80.0.46:2379 (active)       
