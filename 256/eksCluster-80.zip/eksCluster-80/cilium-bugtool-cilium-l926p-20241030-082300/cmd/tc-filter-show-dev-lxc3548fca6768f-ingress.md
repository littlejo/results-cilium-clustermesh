filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc3548fca6768f direct-action not_in_hw id 625 tag b9327104a13362cd jited 
