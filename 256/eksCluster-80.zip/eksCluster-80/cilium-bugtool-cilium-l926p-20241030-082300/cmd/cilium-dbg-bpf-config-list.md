KEY             VALUE
AgentLiveness   2186676806700
UTimeOffset     3379442238281250
