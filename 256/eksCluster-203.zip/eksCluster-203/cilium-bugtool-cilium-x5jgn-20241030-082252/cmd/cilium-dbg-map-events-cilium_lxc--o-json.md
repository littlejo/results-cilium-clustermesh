{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.879Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.879Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.244.196:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:13.879Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.049Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.055Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.098Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.159Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:18.229Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.363Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.364Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.364Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.391Z",
  "value": "id=454   sec_id=6705445 flags=0x0000 ifindex=16  mac=92:BA:4C:72:D0:5D nodemac=CA:52:A9:CD:5D:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:53.392Z",
  "value": "id=454   sec_id=6705445 flags=0x0000 ifindex=16  mac=92:BA:4C:72:D0:5D nodemac=CA:52:A9:CD:5D:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.920Z",
  "value": "id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.203.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:58.325Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:33.375Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:33.379Z",
  "value": "id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:33.381Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:33.382Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:34.340Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:34.341Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:34.341Z",
  "value": "id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:34.341Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:35.304Z",
  "value": "id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:35.305Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:35.305Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:35.305Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.304Z",
  "value": "id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.64:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.305Z",
  "value": "id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.46:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.305Z",
  "value": "id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.203.0.44:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:13:36.306Z",
  "value": "id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D"
}

