REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34050     2690325     677    bpf_overlay.c
Interface                 INGRESS     607281    127428254   1132   bpf_host.c
Success                   EGRESS      13810     1082313     1694   bpf_host.c
Success                   EGRESS      254607    32473145    1308   bpf_lxc.c
Success                   EGRESS      30600     4849380     86     l3.h
Success                   EGRESS      32651     2590448     53     encap.h
Success                   INGRESS     293209    32963058    86     l3.h
Success                   INGRESS     344700    39464496    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
