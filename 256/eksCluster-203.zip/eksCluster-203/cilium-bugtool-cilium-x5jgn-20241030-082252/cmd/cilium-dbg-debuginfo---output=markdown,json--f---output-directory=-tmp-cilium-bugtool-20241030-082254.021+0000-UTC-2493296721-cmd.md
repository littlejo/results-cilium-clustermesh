markdown output at /tmp/cilium-bugtool-20241030-082254.021+0000-UTC-2493296721/cmd/cilium-debuginfo-20241030-082325.178+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.021+0000-UTC-2493296721/cmd/cilium-debuginfo-20241030-082325.178+0000-UTC.json
