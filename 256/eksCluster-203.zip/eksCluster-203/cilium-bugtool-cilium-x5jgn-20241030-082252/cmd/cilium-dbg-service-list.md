ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.188.207:443 (active)    
                                          2 => 172.31.239.101:443 (active)    
2    10.100.29.28:443      ClusterIP      1 => 172.31.244.196:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.203.0.60:53 (active)        
                                          2 => 10.203.0.64:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.203.0.60:9153 (active)      
                                          2 => 10.203.0.64:9153 (active)      
5    10.100.177.120:2379   ClusterIP      1 => 10.203.0.46:2379 (active)      
