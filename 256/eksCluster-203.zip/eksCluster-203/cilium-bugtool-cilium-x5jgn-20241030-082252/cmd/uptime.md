 08:22:54 up 29 min,  0 users,  load average: 0.37, 0.16, 0.11
