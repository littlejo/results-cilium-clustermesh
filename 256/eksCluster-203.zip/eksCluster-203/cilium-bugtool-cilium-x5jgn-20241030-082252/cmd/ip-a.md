1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:0a:ab:44:2c:a9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.244.196/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1834sec preferred_lft 1834sec
    inet6 fe80::80a:abff:fe44:2ca9/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:9f:c4:e2:c4:3b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.244.15/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::89f:c4ff:fee2:c43b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:1f:4e:5d:4a:1d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f01f:4eff:fe5d:4a1d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e6:e8:9c:06:48:9f brd ff:ff:ff:ff:ff:ff
    inet 10.203.0.213/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::e4e8:9cff:fe06:489f/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0e:8b:cf:b2:08:7f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8b:cfff:feb2:87f/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:22:7a:94:38:5d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f822:7aff:fe94:385d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc275627499cfa@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:fd:61:b2:ee:10 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::18fd:61ff:feb2:ee10/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc150cc90c9b96@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:f6:a3:85:4e:b2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10f6:a3ff:fe85:4eb2/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc2e7080574474@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:05:c6:1a:d1:41 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ac05:c6ff:fe1a:d141/64 scope link 
       valid_lft forever preferred_lft forever
