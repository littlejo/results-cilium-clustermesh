CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60891496_5351_4665_a8bd_949213a8722a.slice/cri-containerd-f06356d7c3a753f5ab9d42512505a1da13f3fbdbbe0c886a34281800c2214533.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod60891496_5351_4665_a8bd_949213a8722a.slice/cri-containerd-f232603e0b86a2f6d852f3f8046269d9121667b6fbd42a4ae50b854dd372991e.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35de1107_3481_452c_ac75_ff538dcedc93.slice/cri-containerd-5690f3d1fd3b362164aecb5c11175fcdb10325b8b0b39251b8e21439fdc1ca8e.scope
    538      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35de1107_3481_452c_ac75_ff538dcedc93.slice/cri-containerd-671bf23de75b26b5edc404ab13d410952574375db73372e887179635ec5172fe.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6485e8f6_a1d5_4a51_a8b0_80500bec1c41.slice/cri-containerd-d7584bbabce993082eae28dc0545c163658271f608ee85cb3eb4b09454ca3c25.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6485e8f6_a1d5_4a51_a8b0_80500bec1c41.slice/cri-containerd-6c7826d8ed4db7a986f8ec0e3a61bc8953ca9f88cca9f42cfdb50da327637615.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ac9349_4712_4f07_a4d6_345da32958ab.slice/cri-containerd-7c8ac65fcb2ec45bd4b2fad26885d9a370efb8228c0379b0559786f2b124e163.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ac9349_4712_4f07_a4d6_345da32958ab.slice/cri-containerd-b03419f19e9303be638f3d71fd394e681caad6eadbbfb33a8bd75536e5f848ac.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd7b83e_4b71_4889_96f4_5981ad5766aa.slice/cri-containerd-51899dda9cd8fa64a41de698136fe189265f1bff303056c677f8648055a3282b.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6dd7b83e_4b71_4889_96f4_5981ad5766aa.slice/cri-containerd-216b05d63dd256d9e37600fd61cfbd4cda445c0f550f4a014ab0eee0e648b30d.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-e107d449c226e0bf74c682ab2ddb77228dc6714d0d338af6ee72bdc19e437ed1.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-0950ffc2ce1c8ffddc5b1c812129d91ef61e104cc7d47b359c2d8f607edd482c.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-3cf7a5fc17a09be4a3e0720b1009b1d260ece59d4221b573c8a9240859f92395.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-b3eb1dc04eb9eac21d0f11658051736fac40846d953f8ad3fb77183b062de08f.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod502adcdb_2c4f_4fe5_a6c9_2c4e83aee722.slice/cri-containerd-c613d04126f40524b5940eec7a1376e3e68f75e3f4a8558334d093293d47eb8d.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod502adcdb_2c4f_4fe5_a6c9_2c4e83aee722.slice/cri-containerd-200e3cacdbc1d3e85855cedadf06b83b64c3f0d494a7d881cf1349c511a5d2a4.scope
    87       cgroup_device   multi                                          
