Endpoint ID: 126
Path: /sys/fs/bpf/tc/globals/cilium_policy_00126

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655400   20932     0        
Allow    Ingress     1          ANY          NONE         disabled    18040     212       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 371
Path: /sys/fs/bpf/tc/globals/cilium_policy_00371

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 549
Path: /sys/fs/bpf/tc/globals/cilium_policy_00549

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    845713   7596      0        
Allow    Ingress     1          ANY          NONE         disabled    116482   1343      0        
Allow    Egress      0          ANY          NONE         disabled    121201   1150      0        


Endpoint ID: 844
Path: /sys/fs/bpf/tc/globals/cilium_policy_00844

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11018203   106924    0        
Allow    Ingress     1          ANY          NONE         disabled    8673173    90517     0        
Allow    Egress      0          ANY          NONE         disabled    10358558   103571    0        


Endpoint ID: 3697
Path: /sys/fs/bpf/tc/globals/cilium_policy_03697

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    858347   7704      0        
Allow    Ingress     1          ANY          NONE         disabled    116680   1346      0        
Allow    Egress      0          ANY          NONE         disabled    124050   1184      0        


