top - 08:22:54 up 29 min,  0 users,  load average: 0.37, 0.16, 0.11
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 65.6 us, 15.6 sy,  0.0 ni, 15.6 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   7814.2 total,   4482.0 free,   1186.9 used,   2145.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6442.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 387372  78912 S  81.2   4.8   0:35.82 cilium-+
    713 root      20   0 1243508  18116  13120 S   6.2   0.2   0:00.01 hubble
    394 root      20   0 1229488   7284   2924 S   0.0   0.1   0:00.97 cilium-+
    620 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    627 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    633 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    639 root      20   0 1240432  16068  10832 S   0.0   0.2   0:00.03 cilium-+
    651 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    702 root      20   0    6576   2432   2104 R   0.0   0.0   0:00.00 top
    704 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    734 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
