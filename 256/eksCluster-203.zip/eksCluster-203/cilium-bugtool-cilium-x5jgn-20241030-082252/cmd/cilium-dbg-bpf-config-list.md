KEY             VALUE
AgentLiveness   1807442581737
UTimeOffset     3379442964843750
