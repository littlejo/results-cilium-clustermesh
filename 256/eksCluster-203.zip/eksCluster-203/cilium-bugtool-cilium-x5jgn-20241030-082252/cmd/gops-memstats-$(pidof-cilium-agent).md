alloc: 148.34MB (155544624 bytes)
total-alloc: 2.21GB (2370774416 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63071196
frees: 61546719
heap-alloc: 148.34MB (155544624 bytes)
heap-sys: 247.38MB (259399680 bytes)
heap-idle: 72.69MB (76218368 bytes)
heap-in-use: 174.70MB (183181312 bytes)
heap-released: 4.53MB (4751360 bytes)
heap-objects: 1524477
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 2.96MB (3102080 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 985.99KB (1009649 bytes)
gc-sys: 6.00MB (6295040 bytes)
next-gc: when heap-alloc >= 214.07MB (224463512 bytes)
last-gc: 2024-10-30 08:23:03.578816987 +0000 UTC
gc-pause-total: 7.929543ms
gc-pause: 77011
gc-pause-end: 1730276583578816987
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004368678070835217
enable-gc: true
debug-gc: false
