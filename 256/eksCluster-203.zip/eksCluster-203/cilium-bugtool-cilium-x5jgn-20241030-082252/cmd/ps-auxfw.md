USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         651  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         639  0.0  0.1 1240432 15760 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         690  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         691  0.0  0.1 1240432 15760 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         633  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         627  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         620  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  2.9  4.7 1606080 382320 ?      Ssl  08:03   0:35 cilium-agent --config-dir=/tmp/cilium/config-map
root         394  0.0  0.0 1229488 7284 ?        Sl   08:03   0:00 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
