key: 7e 00 00 00  value: 20 02 00 00
key: 25 02 00 00  value: fb 01 00 00
key: 4c 03 00 00  value: 6c 02 00 00
key: 71 0e 00 00  value: 07 02 00 00
Found 4 elements
