[
  {
    "containers": [
      {
        "cgroup-id": 7802,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35de1107_3481_452c_ac75_ff538dcedc93.slice/cri-containerd-671bf23de75b26b5edc404ab13d410952574375db73372e887179635ec5172fe.scope"
      }
    ],
    "ips": [
      "10.203.0.60"
    ],
    "name": "coredns-cc6ccd49c-4rsj6",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7718,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod98ac9349_4712_4f07_a4d6_345da32958ab.slice/cri-containerd-b03419f19e9303be638f3d71fd394e681caad6eadbbfb33a8bd75536e5f848ac.scope"
      }
    ],
    "ips": [
      "10.203.0.64"
    ],
    "name": "coredns-cc6ccd49c-5w9d4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-b3eb1dc04eb9eac21d0f11658051736fac40846d953f8ad3fb77183b062de08f.scope"
      },
      {
        "cgroup-id": 9194,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-3cf7a5fc17a09be4a3e0720b1009b1d260ece59d4221b573c8a9240859f92395.scope"
      },
      {
        "cgroup-id": 9362,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod93eab683_8ae1_4564_818f_2e5df414dd82.slice/cri-containerd-e107d449c226e0bf74c682ab2ddb77228dc6714d0d338af6ee72bdc19e437ed1.scope"
      }
    ],
    "ips": [
      "10.203.0.46"
    ],
    "name": "clustermesh-apiserver-8585d79f84-4zt7l",
    "namespace": "kube-system"
  }
]

