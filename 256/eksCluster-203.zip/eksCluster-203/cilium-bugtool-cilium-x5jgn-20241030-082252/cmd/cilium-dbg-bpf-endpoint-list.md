IP ADDRESS         LOCAL ENDPOINT INFO
10.203.0.60:0      id=3697  sec_id=6694740 flags=0x0000 ifindex=12  mac=FA:B2:CB:F0:CF:08 nodemac=1A:FD:61:B2:EE:10   
10.203.0.213:0     (localhost)                                                                                        
10.203.0.44:0      id=126   sec_id=4     flags=0x0000 ifindex=10  mac=E2:19:28:6E:50:B4 nodemac=FA:22:7A:94:38:5D     
172.31.244.196:0   (localhost)                                                                                        
172.31.244.15:0    (localhost)                                                                                        
10.203.0.46:0      id=844   sec_id=6705445 flags=0x0000 ifindex=18  mac=DA:56:1B:0B:B8:71 nodemac=AE:05:C6:1A:D1:41   
10.203.0.64:0      id=549   sec_id=6694740 flags=0x0000 ifindex=14  mac=3A:4A:EC:BD:E4:A8 nodemac=12:F6:A3:85:4E:B2   
