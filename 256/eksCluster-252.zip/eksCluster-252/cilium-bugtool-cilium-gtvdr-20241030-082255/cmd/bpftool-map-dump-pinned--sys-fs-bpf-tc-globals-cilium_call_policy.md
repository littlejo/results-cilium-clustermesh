key: 39 01 00 00  value: 04 02 00 00
key: 00 04 00 00  value: 1b 02 00 00
key: cf 05 00 00  value: fe 01 00 00
key: 1c 0d 00 00  value: 6c 02 00 00
Found 4 elements
