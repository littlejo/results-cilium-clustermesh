filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5f09c58f5c68 direct-action not_in_hw id 625 tag 28a2de914332c570 jited 
