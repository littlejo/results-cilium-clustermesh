Endpoint ID: 313
Path: /sys/fs/bpf/tc/globals/cilium_policy_00313

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658591   20924     0        
Allow    Ingress     1          ANY          NONE         disabled    18054     214       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1024
Path: /sys/fs/bpf/tc/globals/cilium_policy_01024

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109198   1254      0        
Allow    Egress      0          ANY          NONE         disabled    17177    184       0        


Endpoint ID: 1487
Path: /sys/fs/bpf/tc/globals/cilium_policy_01487

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    109621   1257      0        
Allow    Egress      0          ANY          NONE         disabled    15535    167       0        


Endpoint ID: 3356
Path: /sys/fs/bpf/tc/globals/cilium_policy_03356

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11554236   113983    0        
Allow    Ingress     1          ANY          NONE         disabled    10547791   107179    0        
Allow    Egress      0          ANY          NONE         disabled    11875283   117538    0        


Endpoint ID: 3582
Path: /sys/fs/bpf/tc/globals/cilium_policy_03582

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


