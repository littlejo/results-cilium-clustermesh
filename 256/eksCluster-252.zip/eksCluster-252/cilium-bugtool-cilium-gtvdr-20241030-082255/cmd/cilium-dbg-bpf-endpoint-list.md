IP ADDRESS         LOCAL ENDPOINT INFO
10.252.0.179:0     id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8   
172.31.190.227:0   (localhost)                                                                                        
172.31.156.255:0   (localhost)                                                                                        
10.252.0.231:0     id=3356  sec_id=8297421 flags=0x0000 ifindex=18  mac=B6:23:0B:E6:FE:3C nodemac=EE:11:FB:60:2D:29   
10.252.0.219:0     id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5     
10.252.0.57:0      id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50   
10.252.0.246:0     (localhost)                                                                                        
