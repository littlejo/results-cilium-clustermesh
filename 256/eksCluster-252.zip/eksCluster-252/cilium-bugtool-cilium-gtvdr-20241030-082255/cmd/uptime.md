 08:22:56 up 26 min,  0 users,  load average: 0.14, 0.21, 0.17
