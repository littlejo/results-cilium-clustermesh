CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38b4df8b_3028_48fa_8d7d_b96b5f908cd8.slice/cri-containerd-809db6be713efa45f02209299a32a24f2ba12331ae298e3d87408985b124398a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod38b4df8b_3028_48fa_8d7d_b96b5f908cd8.slice/cri-containerd-b4892af42793ef0aa802ea9b5f7bf62b9a59bcb288a31d36c4517b9289167de0.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode025801b_fff2_4abd_8e50_56138c2c91c8.slice/cri-containerd-b179d49bbda8d9d7371bdbdf4b1206ead2671c5f16f2e216d570a4bade6dd8d8.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode025801b_fff2_4abd_8e50_56138c2c91c8.slice/cri-containerd-7ccc640097334ec320818d9a6f0ae8775c91c5efbffeb22f6626cb9e60206d04.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bb62fdd_62c1_4f16_a4fe_cd081433923f.slice/cri-containerd-36594b24927f175a634c2f149a9699de8a314cac72bd25fe7ba1a039e0ab782c.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bb62fdd_62c1_4f16_a4fe_cd081433923f.slice/cri-containerd-1ac72ca141c57231ac4a0dc12a81643b2f43f541c1d25381afea11dc451bc28a.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode271cb98_f031_44b9_bd25_c6725e617684.slice/cri-containerd-82dde04a762a1c352c2d6de5e09162c30855d7aa2b6f9d5ffd9734c699272cb1.scope
    522      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode271cb98_f031_44b9_bd25_c6725e617684.slice/cri-containerd-3b17860e8d81972f7f614b36a785101e3b06a1fcd1a125fe8b83069926f4b1e4.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2d59b5_aaa8_4812_80d8_3aea08bb59db.slice/cri-containerd-2a77b90fa026d519780775f068c6426d57a755b1a54445260bfca4c210b7e8b9.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddb2d59b5_aaa8_4812_80d8_3aea08bb59db.slice/cri-containerd-0e888d085070f88d5e88b088bf33d431c7bb0792e09a551c89362ae5545a618e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-d728913faf8f9cb811d48692cbdbe5164ebd8fe0bbe2893fc0e5b25446f5f8d7.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-d0c70450eb33e30e4477ff69e53f21ce3c17dd8c7693523cac85f0b92b7b14cc.scope
    638      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-a16387ed8937474ca83d217e01ba8395f55b09580e725b8cb09e9b3d7d7a34b4.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-269911829880337d11ead00e76f44b0b623322057aeb8aedfb04c76130176ca7.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21421402_abc2_4e20_ac9b_1d549c908147.slice/cri-containerd-e379aef2b34c90696b41983b5c7f8ef2871f1d3d9984d2ed9abce90dd3242b3c.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod21421402_abc2_4e20_ac9b_1d549c908147.slice/cri-containerd-019e70fc60207c2345e257947970aa837fd4cd1556808bb5375376ec2a39007d.scope
    87       cgroup_device   multi                                          
