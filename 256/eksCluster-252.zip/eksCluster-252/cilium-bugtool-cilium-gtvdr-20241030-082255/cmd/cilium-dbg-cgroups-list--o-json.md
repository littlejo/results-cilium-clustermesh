[
  {
    "containers": [
      {
        "cgroup-id": 9273,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-a16387ed8937474ca83d217e01ba8395f55b09580e725b8cb09e9b3d7d7a34b4.scope"
      },
      {
        "cgroup-id": 9189,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-269911829880337d11ead00e76f44b0b623322057aeb8aedfb04c76130176ca7.scope"
      },
      {
        "cgroup-id": 9357,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod15030fe2_81e6_4abb_8690_fca05443eea9.slice/cri-containerd-d728913faf8f9cb811d48692cbdbe5164ebd8fe0bbe2893fc0e5b25446f5f8d7.scope"
      }
    ],
    "ips": [
      "10.252.0.231"
    ],
    "name": "clustermesh-apiserver-7fc58f97d5-h9l7w",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7797,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8bb62fdd_62c1_4f16_a4fe_cd081433923f.slice/cri-containerd-1ac72ca141c57231ac4a0dc12a81643b2f43f541c1d25381afea11dc451bc28a.scope"
      }
    ],
    "ips": [
      "10.252.0.179"
    ],
    "name": "coredns-cc6ccd49c-cgjk7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7713,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode271cb98_f031_44b9_bd25_c6725e617684.slice/cri-containerd-3b17860e8d81972f7f614b36a785101e3b06a1fcd1a125fe8b83069926f4b1e4.scope"
      }
    ],
    "ips": [
      "10.252.0.57"
    ],
    "name": "coredns-cc6ccd49c-bpfc6",
    "namespace": "kube-system"
  }
]

