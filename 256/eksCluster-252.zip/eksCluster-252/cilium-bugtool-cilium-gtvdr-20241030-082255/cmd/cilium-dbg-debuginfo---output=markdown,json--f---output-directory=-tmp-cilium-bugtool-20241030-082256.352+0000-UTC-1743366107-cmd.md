markdown output at /tmp/cilium-bugtool-20241030-082256.352+0000-UTC-1743366107/cmd/cilium-debuginfo-20241030-082327.327+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082256.352+0000-UTC-1743366107/cmd/cilium-debuginfo-20241030-082327.327+0000-UTC.json
