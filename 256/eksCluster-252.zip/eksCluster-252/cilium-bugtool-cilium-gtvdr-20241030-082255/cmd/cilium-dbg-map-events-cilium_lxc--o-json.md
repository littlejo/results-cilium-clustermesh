{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.594Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.156.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.594Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.190.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:10.594Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.965Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:14.967Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.039Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.115Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:15.187Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:19.590Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:19.591Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:19.591Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:19.620Z",
  "value": "id=2474  sec_id=8297421 flags=0x0000 ifindex=16  mac=AA:FE:56:23:B9:CB nodemac=A2:F8:BD:2F:1C:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:19.620Z",
  "value": "id=2474  sec_id=8297421 flags=0x0000 ifindex=16  mac=AA:FE:56:23:B9:CB nodemac=A2:F8:BD:2F:1C:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:20.590Z",
  "value": "id=2474  sec_id=8297421 flags=0x0000 ifindex=16  mac=AA:FE:56:23:B9:CB nodemac=A2:F8:BD:2F:1C:DD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:20.591Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:20.591Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:07:20.592Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:44.051Z",
  "value": "id=3356  sec_id=8297421 flags=0x0000 ifindex=18  mac=B6:23:0B:E6:FE:3C nodemac=EE:11:FB:60:2D:29"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.252.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.285Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.771Z",
  "value": "id=3356  sec_id=8297421 flags=0x0000 ifindex=18  mac=B6:23:0B:E6:FE:3C nodemac=EE:11:FB:60:2D:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.791Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.791Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:56.792Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.698Z",
  "value": "id=3356  sec_id=8297421 flags=0x0000 ifindex=18  mac=B6:23:0B:E6:FE:3C nodemac=EE:11:FB:60:2D:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.699Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.699Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:57.699Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.219:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.697Z",
  "value": "id=313   sec_id=4     flags=0x0000 ifindex=10  mac=7E:04:55:95:EF:BA nodemac=5A:2B:35:E2:9C:F5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.57:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.698Z",
  "value": "id=1024  sec_id=8318348 flags=0x0000 ifindex=12  mac=DE:1D:F9:AA:8A:88 nodemac=B2:65:CE:E7:F4:50"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.231:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.698Z",
  "value": "id=3356  sec_id=8297421 flags=0x0000 ifindex=18  mac=B6:23:0B:E6:FE:3C nodemac=EE:11:FB:60:2D:29"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.252.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:58.698Z",
  "value": "id=1487  sec_id=8318348 flags=0x0000 ifindex=14  mac=F6:AC:5C:33:1E:A4 nodemac=9A:7F:7A:19:57:D8"
}

