alloc: 157.23MB (164866848 bytes)
total-alloc: 2.37GB (2545413848 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 64942600
frees: 63591304
heap-alloc: 157.23MB (164866848 bytes)
heap-sys: 255.42MB (267829248 bytes)
heap-idle: 53.13MB (55713792 bytes)
heap-in-use: 202.29MB (212115456 bytes)
heap-released: 2.50MB (2621440 bytes)
heap-objects: 1351296
stack-in-use: 68.53MB (71860224 bytes)
stack-sys: 68.53MB (71860224 bytes)
stack-mspan-inuse: 3.18MB (3333280 bytes)
stack-mspan-sys: 4.02MB (4210560 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1095233 bytes)
gc-sys: 6.09MB (6384072 bytes)
next-gc: when heap-alloc >= 212.72MB (223056008 bytes)
last-gc: 2024-10-30 08:23:08.80674941 +0000 UTC
gc-pause-total: 8.653593ms
gc-pause: 72301
gc-pause-end: 1730276588806749410
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0006117600311752708
enable-gc: true
debug-gc: false
