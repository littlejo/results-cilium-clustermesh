1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:bd:dc:41:70:99 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.190.227/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1991sec preferred_lft 1991sec
    inet6 fe80::4bd:dcff:fe41:7099/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:ec:04:14:f4:9b brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.156.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4ec:4ff:fe14:f49b/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:5a:72:e3:5a:91 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::45a:72ff:fee3:5a91/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:d4:a0:c4:53:90 brd ff:ff:ff:ff:ff:ff
    inet 10.252.0.246/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d0d4:a0ff:fec4:5390/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether a6:0e:c2:b0:63:97 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a40e:c2ff:feb0:6397/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:2b:35:e2:9c:f5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::582b:35ff:fee2:9cf5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2f7c402c63f0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:65:ce:e7:f4:50 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::b065:ceff:fee7:f450/64 scope link 
       valid_lft forever preferred_lft forever
14: lxced5f8518b9ee@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:7f:7a:19:57:d8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::987f:7aff:fe19:57d8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5f09c58f5c68@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:11:fb:60:2d:29 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::ec11:fbff:fe60:2d29/64 scope link 
       valid_lft forever preferred_lft forever
