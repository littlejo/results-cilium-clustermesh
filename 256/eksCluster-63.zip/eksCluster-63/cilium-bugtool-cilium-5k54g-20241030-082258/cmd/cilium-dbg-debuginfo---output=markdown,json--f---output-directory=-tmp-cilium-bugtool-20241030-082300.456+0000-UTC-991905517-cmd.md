markdown output at /tmp/cilium-bugtool-20241030-082300.456+0000-UTC-991905517/cmd/cilium-debuginfo-20241030-082331.242+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.456+0000-UTC-991905517/cmd/cilium-debuginfo-20241030-082331.242+0000-UTC.json
