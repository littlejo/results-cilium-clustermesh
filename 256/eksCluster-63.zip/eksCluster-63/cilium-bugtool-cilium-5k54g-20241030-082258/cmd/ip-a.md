1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:97:67:e8:49:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.232.42/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3311sec preferred_lft 3311sec
    inet6 fe80::897:67ff:fee8:4963/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b0:1f:76:92:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.227.189/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8b0:1fff:fe76:927f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:f9:22:f4:5a:99 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a8f9:22ff:fef4:5a99/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:af:a6:3c:af:76 brd ff:ff:ff:ff:ff:ff
    inet 10.63.0.235/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::acaf:a6ff:fe3c:af76/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:58:b0:21:c0:9e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3858:b0ff:fe21:c09e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 3e:2c:ed:85:11:3b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::3c2c:edff:fe85:113b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcb6e518b68718@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:0a:ae:84:b4:89 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::dc0a:aeff:fe84:b489/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc6355968d2189@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:23:60:66:ee:b8 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4823:60ff:fe66:eeb8/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8d0059a67ecc@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:4d:b8:4f:7f:4f brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::544d:b8ff:fe4f:7f4f/64 scope link 
       valid_lft forever preferred_lft forever
