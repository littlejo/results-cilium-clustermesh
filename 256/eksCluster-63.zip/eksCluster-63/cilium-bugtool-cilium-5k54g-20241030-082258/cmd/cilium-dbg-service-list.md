ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.179.6:443 (active)     
                                         2 => 172.31.204.220:443 (active)   
2    10.100.182.239:443   ClusterIP      1 => 172.31.232.42:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.63.0.142:53 (active)       
                                         2 => 10.63.0.199:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.63.0.142:9153 (active)     
                                         2 => 10.63.0.199:9153 (active)     
5    10.100.250.6:2379    ClusterIP      1 => 10.63.0.135:2379 (active)     
