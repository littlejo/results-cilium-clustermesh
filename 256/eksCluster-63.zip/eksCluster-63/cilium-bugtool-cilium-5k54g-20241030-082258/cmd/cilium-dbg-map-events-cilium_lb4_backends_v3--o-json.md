{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:39.256Z",
  "value": "ANY://172.31.179.6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:39.256Z",
  "value": "ANY://172.31.204.220"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:39.256Z",
  "value": "ANY://172.31.213.249"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:39.256Z",
  "value": "ANY://172.31.213.249"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.901Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.901Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:42.367Z",
  "value": "ANY://172.31.232.42"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.025Z",
  "value": "ANY://10.63.0.142"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.025Z",
  "value": "ANY://10.63.0.142"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.047Z",
  "value": "ANY://10.63.0.199"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:47.047Z",
  "value": "ANY://10.63.0.199"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:52.638Z",
  "value": "ANY://10.63.0.173"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "11",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.723Z",
  "value": "ANY://10.63.0.135"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.812Z",
  "value": "ANY://10.63.0.173"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.562Z",
  "value": "\u003cnil\u003e"
}

