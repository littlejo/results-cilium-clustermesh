alloc: 187.02MB (196109816 bytes)
total-alloc: 2.48GB (2661346024 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 67465164
frees: 65456835
heap-alloc: 187.02MB (196109816 bytes)
heap-sys: 239.11MB (250724352 bytes)
heap-idle: 29.17MB (30588928 bytes)
heap-in-use: 209.94MB (220135424 bytes)
heap-released: 400.00KB (409600 bytes)
heap-objects: 2008329
stack-in-use: 64.84MB (67993600 bytes)
stack-sys: 64.84MB (67993600 bytes)
stack-mspan-inuse: 3.38MB (3539680 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1077961 bytes)
gc-sys: 6.03MB (6323736 bytes)
next-gc: when heap-alloc >= 229.55MB (240704616 bytes)
last-gc: 2024-10-30 08:23:00.39616688 +0000 UTC
gc-pause-total: 24.967357ms
gc-pause: 105840
gc-pause-end: 1730276580396166880
num-gc: 87
num-forced-gc: 0
gc-cpu-fraction: 0.0004622468905861028
enable-gc: true
debug-gc: false
