IP ADDRESS         LOCAL ENDPOINT INFO
172.31.227.189:0   (localhost)                                                                                        
10.63.0.199:0      id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89   
10.63.0.142:0      id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8   
10.63.0.235:0      (localhost)                                                                                        
10.63.0.135:0      id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F   
172.31.232.42:0    (localhost)                                                                                        
10.63.0.110:0      id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B     
