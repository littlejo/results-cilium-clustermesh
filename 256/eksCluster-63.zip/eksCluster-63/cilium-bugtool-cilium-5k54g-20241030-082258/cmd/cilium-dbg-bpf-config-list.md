KEY             VALUE
AgentLiveness   2129103039647
UTimeOffset     3379442347656250
