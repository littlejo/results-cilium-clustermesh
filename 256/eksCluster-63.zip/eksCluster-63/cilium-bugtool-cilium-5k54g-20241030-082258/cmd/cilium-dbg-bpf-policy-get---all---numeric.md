Endpoint ID: 147
Path: /sys/fs/bpf/tc/globals/cilium_policy_00147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 234
Path: /sys/fs/bpf/tc/globals/cilium_policy_00234

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1659810   20968     0        
Allow    Ingress     1          ANY          NONE         disabled    23418     274       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 856
Path: /sys/fs/bpf/tc/globals/cilium_policy_00856

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    678748   6096      0        
Allow    Ingress     1          ANY          NONE         disabled    160820   1851      0        
Allow    Egress      0          ANY          NONE         disabled    123650   1187      0        


Endpoint ID: 1872
Path: /sys/fs/bpf/tc/globals/cilium_policy_01872

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11534411   116410    0        
Allow    Ingress     1          ANY          NONE         disabled    11547724   122404    0        
Allow    Egress      0          ANY          NONE         disabled    15300414   149549    0        


Endpoint ID: 1970
Path: /sys/fs/bpf/tc/globals/cilium_policy_01970

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    711748   6388      0        
Allow    Ingress     1          ANY          NONE         disabled    161612   1863      0        
Allow    Egress      0          ANY          NONE         disabled    126711   1219      0        


