32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:48:05+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:06+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:09+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
50: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:20+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:14+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:55:43+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
482: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:55:43+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
483: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:55:43+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
484: sched_cls  name tail_handle_ipv4  tag c93a5ba40289373d  gpl
	loaded_at 2024-10-30T07:55:43+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
505: sched_cls  name tail_ipv4_ct_ingress  tag f5a95b564c4a4127  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 149
508: sched_cls  name handle_policy  tag abfa4aeb645bc752  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 154
509: sched_cls  name tail_ipv4_to_endpoint  tag 0f31316e0db53ca0  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 155
510: sched_cls  name tail_handle_arp  tag 9467acc654ce4f71  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 156
511: sched_cls  name tail_ipv4_ct_egress  tag 84adfb16acc28d1d  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 157
512: sched_cls  name tail_handle_ipv4  tag 137980924912d56a  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 158
514: sched_cls  name cil_from_container  tag 4884a2d0c06bb25f  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 107,76
	btf_id 160
515: sched_cls  name __send_drop_notify  tag a7e884359de2df17  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 161
516: sched_cls  name tail_handle_ipv4_cont  tag 74964a887fd7fbf3  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 162
517: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 163
518: sched_cls  name tail_handle_arp  tag c63644525feb44b6  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,109
	btf_id 165
519: sched_cls  name handle_policy  tag fa8525e0bc37fda5  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,109,82,83,110,41,80,100,39,84,75,40,37,38
	btf_id 166
520: sched_cls  name tail_ipv4_ct_ingress  tag e4adb9d59078ea85  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 167
521: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
524: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
525: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,109
	btf_id 168
526: sched_cls  name cil_from_container  tag 6882bad4dcb17013  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 109,76
	btf_id 169
527: sched_cls  name __send_drop_notify  tag adcd6352d39f0cc9  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 170
528: sched_cls  name tail_ipv4_to_endpoint  tag 50b121e72981fbe5  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,110,41,82,83,80,100,39,109,40,37,38
	btf_id 171
529: sched_cls  name tail_handle_ipv4  tag 8f97d48bf82f0676  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,109
	btf_id 172
530: sched_cls  name tail_ipv4_ct_egress  tag 84adfb16acc28d1d  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,109,82,83,110,84
	btf_id 173
531: sched_cls  name tail_handle_ipv4_cont  tag e6d512640809dae4  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,110,41,100,82,83,39,76,74,77,109,40,37,38,81
	btf_id 174
533: sched_cls  name tail_handle_ipv4_cont  tag 0989ae0bb87664f1  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 177
534: sched_cls  name tail_ipv4_to_endpoint  tag e81aaf40f2bb7615  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,112,40,37,38
	btf_id 178
535: sched_cls  name __send_drop_notify  tag cd768d883269ba38  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 179
537: sched_cls  name tail_ipv4_ct_ingress  tag 8a591e70287b78be  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 181
538: sched_cls  name handle_policy  tag 5ed2fd21a1d3515a  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,112,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 182
539: sched_cls  name tail_handle_arp  tag 02523bc085b952fa  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 183
540: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 184
541: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 185
542: sched_cls  name cil_from_container  tag e4bc8212c9dac354  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 112,76
	btf_id 186
543: sched_cls  name tail_handle_ipv4  tag 1e2caef23031009b  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 187
544: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
547: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
548: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
551: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
552: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
555: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:46+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
556: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 189
557: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 190
559: sched_cls  name __send_drop_notify  tag 49fe9ccc51b6c03f  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 192
561: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 194
562: sched_cls  name tail_handle_ipv4_from_host  tag be3720724bdf97d3  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 195
564: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
566: sched_cls  name __send_drop_notify  tag 49fe9ccc51b6c03f  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 200
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
569: sched_cls  name tail_handle_ipv4_from_host  tag be3720724bdf97d3  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
571: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 206
572: sched_cls  name __send_drop_notify  tag 49fe9ccc51b6c03f  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
574: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 209
575: sched_cls  name tail_handle_ipv4_from_host  tag be3720724bdf97d3  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 210
578: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 214
579: sched_cls  name __send_drop_notify  tag 49fe9ccc51b6c03f  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 215
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 217
582: sched_cls  name tail_handle_ipv4_from_host  tag be3720724bdf97d3  gpl
	loaded_at 2024-10-30T07:55:47+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 218
623: sched_cls  name tail_handle_ipv4_cont  tag 2d0a91bcbced5823  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 233
624: sched_cls  name handle_policy  tag 747cf3d964764df2  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 234
625: sched_cls  name tail_handle_ipv4  tag 30a9ebbe7564fbbb  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 235
626: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 236
627: sched_cls  name cil_from_container  tag 3fcf09a8be14f40b  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 237
629: sched_cls  name tail_ipv4_to_endpoint  tag 94322aa7cbd58a7e  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 239
630: sched_cls  name tail_ipv4_ct_egress  tag e25ae4d492da09ba  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 240
631: sched_cls  name tail_handle_arp  tag 88438f0e05ec3091  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 241
632: sched_cls  name __send_drop_notify  tag 6d94472a3a9d992a  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 242
633: sched_cls  name tail_ipv4_ct_ingress  tag 0442e24853e57b28  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 243
634: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
637: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
650: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
653: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
654: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
657: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:09:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
