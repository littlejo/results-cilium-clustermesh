CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6329505_37af_4968_92fa_561ad044a5cc.slice/cri-containerd-955be01847405ab5eae9608c5a7c5ddf8fc0afe0b73711927ccee6ea9ae9b354.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6329505_37af_4968_92fa_561ad044a5cc.slice/cri-containerd-260274033dfe335e08ee3b8c9ce848f0307d2c1b671e326a73aab3a83d729ae9.scope
    524      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod514c14b0_43ec_4095_aa0a_483062d62c01.slice/cri-containerd-38dd9998da6033f4f92cab0c777d376a9dbf19e400d3abb6a94287a22b8f9584.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod514c14b0_43ec_4095_aa0a_483062d62c01.slice/cri-containerd-fc4238d0b059efb80ab5b8e14560397479cf6cb98ae96b3c49d113f93b3b6af7.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ec55aad_1b9a_48f6_81ab_4423a668cc0b.slice/cri-containerd-4cb41911d467bed48b388e55e0407d2266c33ca3c435d0ba1fba742ef66b7635.scope
    547      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ec55aad_1b9a_48f6_81ab_4423a668cc0b.slice/cri-containerd-b9e27165ac99d0e942ff9b9312d18d14d5dcd381ac5d50ec71669abed65015ea.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac7a14cb_06fd_4fc2_af60_517f87aaf8e7.slice/cri-containerd-e5eb9b8cccede0607a1d8e092c106fa44772de9112993a6299dd588517492927.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podac7a14cb_06fd_4fc2_af60_517f87aaf8e7.slice/cri-containerd-dea0a6d2084cb263d68a673c8565da701aba23e5e81e5bcf7d6339697ee3d05f.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92a06c2c_bbb3_4c5e_a858_0384ed705357.slice/cri-containerd-173d463eedef81a2dcc2793e0d6b4d776f5cb064ec30eb1b059e41da27737ce8.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod92a06c2c_bbb3_4c5e_a858_0384ed705357.slice/cri-containerd-33d820a7f1c9ac86062662c9d1567b34a78b8b7c2cd07ba9258b35f34315dfdb.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04f8853e_a8a0_4f31_b0e2_e7024c9207e3.slice/cri-containerd-b744c3c47e50aa83348cb1508c398789207a96309157ea83d22a7c87473c501e.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod04f8853e_a8a0_4f31_b0e2_e7024c9207e3.slice/cri-containerd-54eebcd1dab61fae06f5a3c862667c1c1e82bfc7938c73dcb6370741366bbe42.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-165f0ade23bb7da7df45e7529aa84c20e8caa6e17dd956ae3b896d09a91b8961.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-9a968d87536de47c4f53078bba49a50958829808b80facf20b1b4614f6d6acba.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-93dadbdceaa7fa4983c5ca7de2ea4843ce61a56b9087e3f641b057facd2c5a9c.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-94bcd0f49128440589dacc80b6dd96bdd42ade339c676910200905e12ef7694d.scope
    661      cgroup_device   multi                                          
