filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcb6e518b68718 direct-action not_in_hw id 526 tag 6882bad4dcb17013 jited 
