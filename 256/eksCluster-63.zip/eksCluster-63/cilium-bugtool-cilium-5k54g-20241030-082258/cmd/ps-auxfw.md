USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         702  2.0  0.2 1240432 16432 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         715  0.0  0.2 1240432 16432 ?       R    08:23   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         716  0.0  0.0   6408  1644 ?        R    08:23   0:00  \_ ps auxfw
root         688  0.0  0.0 1229000 3996 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         682  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root           1  3.5  4.9 1606080 393500 ?      Ssl  07:55   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.0 1229744 6988 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
