{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.544Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.227.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.544Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.232.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:41.544Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.440Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.490Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.538Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.620Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:46.690Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.859Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.859Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.859Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.888Z",
  "value": "id=677   sec_id=2102016 flags=0x0000 ifindex=16  mac=E2:EB:9D:13:C1:41 nodemac=C2:50:98:8F:7E:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.889Z",
  "value": "id=677   sec_id=2102016 flags=0x0000 ifindex=16  mac=E2:EB:9D:13:C1:41 nodemac=C2:50:98:8F:7E:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.860Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.860Z",
  "value": "id=677   sec_id=2102016 flags=0x0000 ifindex=16  mac=E2:EB:9D:13:C1:41 nodemac=C2:50:98:8F:7E:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.860Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.860Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.827Z",
  "value": "id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.63.0.173:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:40.293Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.935Z",
  "value": "id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.936Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.936Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:52.937Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.983Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.984Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.984Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:53.985Z",
  "value": "id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.947Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.947Z",
  "value": "id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.947Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:54.948Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.135:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.947Z",
  "value": "id=1872  sec_id=2102016 flags=0x0000 ifindex=18  mac=02:BD:8D:8C:25:4D nodemac=56:4D:B8:4F:7F:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.947Z",
  "value": "id=234   sec_id=4     flags=0x0000 ifindex=10  mac=52:A2:45:68:B3:73 nodemac=3E:2C:ED:85:11:3B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.948Z",
  "value": "id=1970  sec_id=2106239 flags=0x0000 ifindex=12  mac=8A:E4:45:2A:D4:EB nodemac=DE:0A:AE:84:B4:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.63.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.948Z",
  "value": "id=856   sec_id=2106239 flags=0x0000 ifindex=14  mac=82:C4:99:3D:CD:B8 nodemac=4A:23:60:66:EE:B8"
}

