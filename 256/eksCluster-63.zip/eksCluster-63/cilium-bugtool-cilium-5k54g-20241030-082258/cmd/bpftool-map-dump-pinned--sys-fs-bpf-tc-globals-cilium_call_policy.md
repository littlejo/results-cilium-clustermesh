key: ea 00 00 00  value: 1a 02 00 00
key: 58 03 00 00  value: fc 01 00 00
key: 50 07 00 00  value: 70 02 00 00
key: b2 07 00 00  value: 07 02 00 00
Found 4 elements
