xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 571
ens6(5) clsact/ingress cil_from_netdev-ens6 id 578
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 557
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxcb6e518b68718(12) clsact/ingress cil_from_container-lxcb6e518b68718 id 526
lxc6355968d2189(14) clsact/ingress cil_from_container-lxc6355968d2189 id 514
lxc8d0059a67ecc(18) clsact/ingress cil_from_container-lxc8d0059a67ecc id 627

flow_dissector:

netfilter:

