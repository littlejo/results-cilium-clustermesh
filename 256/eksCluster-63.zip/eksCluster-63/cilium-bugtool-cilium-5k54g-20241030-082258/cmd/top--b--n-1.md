top - 08:23:00 up 34 min,  0 users,  load average: 0.19, 0.28, 0.21
Tasks:   8 total,   1 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 18.2 us, 30.3 sy,  0.0 ni, 45.5 id,  0.0 wa,  0.0 hi,  6.1 si,  0.0 st
MiB Mem :   7814.2 total,   4472.1 free,   1195.5 used,   2146.6 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    702 root      20   0 1240432  16432  11484 S   6.2   0.2   0:00.03 cilium-+
      1 root      20   0 1606080 393500  78268 S   0.0   4.9   0:58.93 cilium-+
    405 root      20   0 1229744   6988   2924 S   0.0   0.1   0:01.17 cilium-+
    682 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    688 root      20   0 1229000   3996   3328 S   0.0   0.0   0:00.00 gops
    728 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    747 root      20   0 1228744   3976   3328 S   0.0   0.0   0:00.00 gops
    752 root      20   0 1616008   8300   6228 S   0.0   0.1   0:00.00 runc:[2+
