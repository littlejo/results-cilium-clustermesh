[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-94bcd0f49128440589dacc80b6dd96bdd42ade339c676910200905e12ef7694d.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-93dadbdceaa7fa4983c5ca7de2ea4843ce61a56b9087e3f641b057facd2c5a9c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc681fe58_8dd4_40cf_b028_287a767b2e4c.slice/cri-containerd-9a968d87536de47c4f53078bba49a50958829808b80facf20b1b4614f6d6acba.scope"
      }
    ],
    "ips": [
      "10.63.0.135"
    ],
    "name": "clustermesh-apiserver-569d67d76c-rh5gc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8ec55aad_1b9a_48f6_81ab_4423a668cc0b.slice/cri-containerd-b9e27165ac99d0e942ff9b9312d18d14d5dcd381ac5d50ec71669abed65015ea.scope"
      }
    ],
    "ips": [
      "10.63.0.142"
    ],
    "name": "coredns-cc6ccd49c-wjc4x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb6329505_37af_4968_92fa_561ad044a5cc.slice/cri-containerd-955be01847405ab5eae9608c5a7c5ddf8fc0afe0b73711927ccee6ea9ae9b354.scope"
      }
    ],
    "ips": [
      "10.63.0.199"
    ],
    "name": "coredns-cc6ccd49c-fnszr",
    "namespace": "kube-system"
  }
]

