[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-9fb6d42466a6c52d45b3ffeec8f99d8abe850bd2c2bf7f0f328f16b07924998c.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-dea7542a2c7e268b38716395ae9a715d2654abc6ec8ff4b77f1d3ef7a7d1b331.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-e404bf0181d1853e2258a035a7fb2e470538ee884c748942aa67599ce086f09f.scope"
      }
    ],
    "ips": [
      "10.5.0.152"
    ],
    "name": "clustermesh-apiserver-5f5c68b45c-nq8dz",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5dec689_5e54_465f_a15e_5a1deaa6c28d.slice/cri-containerd-073b972480d131de552cde38cd2243c4e8c51136a75a388bfdb1812a4d2aeab6.scope"
      }
    ],
    "ips": [
      "10.5.0.198"
    ],
    "name": "coredns-cc6ccd49c-4hhn4",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2e552ce_0c7e_468c_b02f_17432aa3b319.slice/cri-containerd-c16cd9761c957a9252344d0bd20a242c2d8963855b6f3567958ee678eb13e944.scope"
      }
    ],
    "ips": [
      "10.5.0.217"
    ],
    "name": "coredns-cc6ccd49c-hjfn4",
    "namespace": "kube-system"
  }
]

