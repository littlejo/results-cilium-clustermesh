{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.300Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.300Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.219.104:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:08.300Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:13.233Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:13.257Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:13.308Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:13.342Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.988Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.988Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:41.989Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.021Z",
  "value": "id=490   sec_id=228548 flags=0x0000 ifindex=16  mac=76:73:74:EF:CD:DF nodemac=12:4C:45:68:8B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.988Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.988Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.988Z",
  "value": "id=490   sec_id=228548 flags=0x0000 ifindex=16  mac=76:73:74:EF:CD:DF nodemac=12:4C:45:68:8B:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:42.989Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.528Z",
  "value": "id=1124  sec_id=228548 flags=0x0000 ifindex=18  mac=F2:88:2B:D9:57:08 nodemac=76:7F:88:70:B6:FC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.5.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.928Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.218Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.219Z",
  "value": "id=1124  sec_id=228548 flags=0x0000 ifindex=18  mac=F2:88:2B:D9:57:08 nodemac=76:7F:88:70:B6:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.219Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:49.220Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.220Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.222Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.223Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.224Z",
  "value": "id=1124  sec_id=228548 flags=0x0000 ifindex=18  mac=F2:88:2B:D9:57:08 nodemac=76:7F:88:70:B6:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.218Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.218Z",
  "value": "id=1124  sec_id=228548 flags=0x0000 ifindex=18  mac=F2:88:2B:D9:57:08 nodemac=76:7F:88:70:B6:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.219Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:51.219Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.218Z",
  "value": "id=1124  sec_id=228548 flags=0x0000 ifindex=18  mac=F2:88:2B:D9:57:08 nodemac=76:7F:88:70:B6:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.225:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.218Z",
  "value": "id=974   sec_id=4     flags=0x0000 ifindex=10  mac=56:01:4B:42:C6:3E nodemac=42:F7:20:74:CB:1C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.198:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.219Z",
  "value": "id=423   sec_id=199537 flags=0x0000 ifindex=12  mac=3E:DB:81:20:41:E1 nodemac=6E:6D:63:CF:70:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.5.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:52.219Z",
  "value": "id=1824  sec_id=199537 flags=0x0000 ifindex=14  mac=8A:21:2B:2D:54:F9 nodemac=12:91:84:2E:B6:84"
}

