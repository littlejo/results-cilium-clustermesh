top - 08:22:59 up 36 min,  0 users,  load average: 0.18, 0.31, 0.27
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 54.8 us, 35.5 sy,  0.0 ni,  6.5 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4469.6 free,   1197.3 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6431.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 395208  79292 S  80.0   4.9   1:05.35 cilium-+
    663 root      20   0 1229640  15788   4004 S  13.3   0.2   0:00.02 gops
    696 root      20   0 1240432  16056  11292 S   6.7   0.2   0:00.03 cilium-+
    724 root      20   0 1243764  19416  13884 S   6.7   0.2   0:00.02 hubble
    415 root      20   0 1229744   7892   3836 S   0.0   0.1   0:01.20 cilium-+
    667 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    710 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    742 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    767 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
