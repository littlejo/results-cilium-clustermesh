USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         711  0.0  0.0   2304   832 ?        Ds   08:22   0:00 sh -c tail -c+0 /tmp/heap_profile3206013654
root         710  0.0  0.0   2208   796 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         724  0.0  0.0   2208    88 ?        R    08:22   0:00  \_ timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         696  0.0  0.2 1240432 16056 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         722  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         723  0.0  0.0   3728   468 ?        R    08:22   0:00  \_ bash -c hostname
root         667  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         663  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.6  4.8 1606336 384120 ?      Ssl  07:52   1:05 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.0 1229744 7892 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
