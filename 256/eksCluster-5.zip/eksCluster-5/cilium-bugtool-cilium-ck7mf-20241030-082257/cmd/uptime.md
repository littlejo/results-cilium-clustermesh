 08:22:58 up 36 min,  0 users,  load average: 0.18, 0.31, 0.27
