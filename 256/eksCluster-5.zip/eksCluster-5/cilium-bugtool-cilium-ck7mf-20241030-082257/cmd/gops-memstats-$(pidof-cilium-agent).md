alloc: 162.83MB (170743016 bytes)
total-alloc: 2.38GB (2552955200 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 65419051
frees: 63607224
heap-alloc: 162.83MB (170743016 bytes)
heap-sys: 251.20MB (263397376 bytes)
heap-idle: 63.18MB (66248704 bytes)
heap-in-use: 188.02MB (197148672 bytes)
heap-released: 5.52MB (5783552 bytes)
heap-objects: 1811827
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 3.21MB (3363040 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.19MB (1245873 bytes)
gc-sys: 5.99MB (6284776 bytes)
next-gc: when heap-alloc >= 212.37MB (222691112 bytes)
last-gc: 2024-10-30 08:23:04.27715467 +0000 UTC
gc-pause-total: 14.23903ms
gc-pause: 110644
gc-pause-end: 1730276584277154670
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00038300039050819884
enable-gc: true
debug-gc: false
