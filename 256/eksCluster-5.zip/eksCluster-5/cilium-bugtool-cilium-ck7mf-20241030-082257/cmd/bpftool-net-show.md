xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 561
ens6(5) clsact/ingress cil_from_netdev-ens6 id 566
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 554
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 546
cilium_host(7) clsact/egress cil_from_host-cilium_host id 545
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 581
lxc0059a72095a0(12) clsact/ingress cil_from_container-lxc0059a72095a0 id 531
lxc876a0284a2cd(14) clsact/ingress cil_from_container-lxc876a0284a2cd id 529
lxca14cb77321ff(18) clsact/ingress cil_from_container-lxca14cb77321ff id 646

flow_dissector:

netfilter:

