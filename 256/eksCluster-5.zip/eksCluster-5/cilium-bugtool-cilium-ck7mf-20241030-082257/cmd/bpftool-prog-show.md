32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:46:29+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:46:30+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:46:34+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:46:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:46:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:46:46+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:59+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:59+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
481: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:53:10+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
482: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:53:10+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
483: sched_cls  name tail_handle_ipv4  tag 76f98b2dcbe7c477  gpl
	loaded_at 2024-10-30T07:53:10+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:53:10+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
514: sched_cls  name tail_ipv4_to_endpoint  tag c372f8abb348d622  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,112,40,37,38
	btf_id 163
522: sched_cls  name handle_policy  tag 9ac1eea28ac9a83b  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 165
525: sched_cls  name tail_handle_ipv4  tag f55a4b9a56b2d149  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 173
527: sched_cls  name __send_drop_notify  tag 54fcfbc2caa43cf7  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 176
528: sched_cls  name tail_handle_arp  tag f2cecb9d9c93d9eb  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 179
529: sched_cls  name cil_from_container  tag a6500dc8b7e85733  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,76
	btf_id 180
530: sched_cls  name tail_ipv4_ct_egress  tag d5bef7cb5e3201f2  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 177
531: sched_cls  name cil_from_container  tag 389d0b990c2cb810  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 182
533: sched_cls  name tail_handle_ipv4  tag bc887d15066f4996  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 181
534: sched_cls  name tail_ipv4_ct_ingress  tag 8d986717a2213880  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 184
535: sched_cls  name tail_handle_ipv4_cont  tag 2f44daf6ca7d660b  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,112,40,37,38,81
	btf_id 186
536: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 187
537: sched_cls  name tail_handle_arp  tag c2d5cc70153c6570  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 188
538: sched_cls  name handle_policy  tag d947285a06ed6026  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,115,82,83,116,41,80,114,39,84,75,40,37,38
	btf_id 185
539: sched_cls  name tail_ipv4_ct_ingress  tag b4dd6a0ebc842237  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 189
540: sched_cls  name __send_drop_notify  tag 63d5c6574019f63d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 191
541: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 192
545: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 197
546: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 198
547: sched_cls  name tail_handle_ipv4_from_host  tag 27bccf3ef3263f48  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 199
548: sched_cls  name __send_drop_notify  tag 63d5c6574019f63d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
549: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 202
550: sched_cls  name tail_handle_ipv4_cont  tag 34e5965481dd7397  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,116,41,114,82,83,39,76,74,77,115,40,37,38,81
	btf_id 195
554: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 207
555: sched_cls  name tail_handle_ipv4_from_host  tag 27bccf3ef3263f48  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 208
558: sched_cls  name tail_handle_ipv4_from_host  tag 27bccf3ef3263f48  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 212
559: sched_cls  name __send_drop_notify  tag 63d5c6574019f63d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
560: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 214
561: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 215
563: sched_cls  name tail_handle_ipv4_from_host  tag 27bccf3ef3263f48  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 218
564: sched_cls  name __send_drop_notify  tag 63d5c6574019f63d  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
565: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 220
566: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 221
570: sched_cls  name tail_ipv4_to_endpoint  tag 4e5c5826dedcc02c  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,116,41,82,83,80,114,39,115,40,37,38
	btf_id 204
571: sched_cls  name __send_drop_notify  tag 95be48966d7f5a86  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 227
572: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 228
573: sched_cls  name tail_ipv4_ct_egress  tag d5bef7cb5e3201f2  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 229
574: sched_cls  name handle_policy  tag 7b286847e561497e  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,125,82,83,126,41,80,100,39,84,75,40,37,38
	btf_id 226
576: sched_cls  name tail_ipv4_to_endpoint  tag 626157ba69d63146  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,126,41,82,83,80,100,39,125,40,37,38
	btf_id 231
577: sched_cls  name tail_handle_arp  tag 7032a534d038cd57  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,125
	btf_id 232
578: sched_cls  name tail_handle_ipv4_cont  tag 187ba48aa5bab9a9  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,126,41,100,82,83,39,76,74,77,125,40,37,38,81
	btf_id 233
579: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,125
	btf_id 234
580: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 235
581: sched_cls  name cil_from_container  tag 5a39e899f0b17cf4  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 125,76
	btf_id 236
582: sched_cls  name tail_ipv4_ct_ingress  tag be1a7cb7fbc3564b  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,125,82,83,126,84
	btf_id 237
583: sched_cls  name tail_handle_ipv4  tag 88e818b635e74cb9  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,125
	btf_id 238
584: sched_cls  name __send_drop_notify  tag 17a555d466f6158a  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 239
585: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
588: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
589: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
592: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
593: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
596: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
597: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
600: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: sched_cls  name handle_policy  tag 8dbf8710f4fae18f  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,143,82,83,142,41,80,141,39,84,75,40,37,38
	btf_id 253
641: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,143
	btf_id 254
642: sched_cls  name tail_ipv4_ct_egress  tag 2ae7820f6afd9243  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 255
643: sched_cls  name tail_handle_ipv4_cont  tag f744c4c788bc16bf  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,142,41,141,82,83,39,76,74,77,143,40,37,38,81
	btf_id 256
644: sched_cls  name tail_ipv4_to_endpoint  tag 0cc62910d2a38e37  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,142,41,82,83,80,141,39,143,40,37,38
	btf_id 257
645: sched_cls  name tail_handle_arp  tag 5f2eb53a2fad981e  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,143
	btf_id 258
646: sched_cls  name cil_from_container  tag 7039928289c96896  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 143,76
	btf_id 259
647: sched_cls  name tail_ipv4_ct_ingress  tag 0721e53c61268bfb  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,143,82,83,142,84
	btf_id 260
648: sched_cls  name __send_drop_notify  tag 7226d17e2335c7a8  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 261
650: sched_cls  name tail_handle_ipv4  tag dd57313b92ae5b3e  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,143
	btf_id 263
651: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
654: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
667: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
670: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
671: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
674: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
675: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
678: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
