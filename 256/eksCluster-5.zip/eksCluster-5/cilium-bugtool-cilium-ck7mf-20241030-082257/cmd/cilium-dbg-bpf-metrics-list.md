REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     38137     3018954     677    bpf_overlay.c
Interface                 INGRESS     668726    135542542   1132   bpf_host.c
Success                   EGRESS      17755     1401849     1694   bpf_host.c
Success                   EGRESS      284256    35308237    1308   bpf_lxc.c
Success                   EGRESS      39036     3088455     53     encap.h
Success                   INGRESS     329723    37135391    86     l3.h
Success                   INGRESS     350756    38796542    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
