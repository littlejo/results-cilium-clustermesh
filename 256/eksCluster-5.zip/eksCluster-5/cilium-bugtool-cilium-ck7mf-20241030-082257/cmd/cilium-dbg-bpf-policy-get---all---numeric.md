Endpoint ID: 423
Path: /sys/fs/bpf/tc/globals/cilium_policy_00423

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    174678   2013      0        
Allow    Egress      0          ANY          NONE         disabled    22435    252       0        


Endpoint ID: 502
Path: /sys/fs/bpf/tc/globals/cilium_policy_00502

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 974
Path: /sys/fs/bpf/tc/globals/cilium_policy_00974

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1661838   21042     0        
Allow    Ingress     1          ANY          NONE         disabled    26910     317       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1124
Path: /sys/fs/bpf/tc/globals/cilium_policy_01124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11659044   116998    0        
Allow    Ingress     1          ANY          NONE         disabled    10922280   115467    0        
Allow    Egress      0          ANY          NONE         disabled    13897125   136371    0        


Endpoint ID: 1824
Path: /sys/fs/bpf/tc/globals/cilium_policy_01824

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    172434   1979      0        
Allow    Egress      0          ANY          NONE         disabled    20973    235       0        


