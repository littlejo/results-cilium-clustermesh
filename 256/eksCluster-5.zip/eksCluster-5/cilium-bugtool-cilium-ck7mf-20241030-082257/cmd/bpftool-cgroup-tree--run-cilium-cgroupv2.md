CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod172fb3c9_701e_4228_828b_896e6dc02a02.slice/cri-containerd-417d7e185448ca8fb4483991a1856d352a93fc35f6172f9d081359d3dbb294d0.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod172fb3c9_701e_4228_828b_896e6dc02a02.slice/cri-containerd-63c37a78fab0d57d0d3e029c4387d233c8d7da706ba8419d95399cedd2948f27.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2e552ce_0c7e_468c_b02f_17432aa3b319.slice/cri-containerd-4506d690f9b2272d1c788b5c2a22ff89a83bc2123e84eb9317af06a29c16d715.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf2e552ce_0c7e_468c_b02f_17432aa3b319.slice/cri-containerd-c16cd9761c957a9252344d0bd20a242c2d8963855b6f3567958ee678eb13e944.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5dec689_5e54_465f_a15e_5a1deaa6c28d.slice/cri-containerd-073b972480d131de552cde38cd2243c4e8c51136a75a388bfdb1812a4d2aeab6.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda5dec689_5e54_465f_a15e_5a1deaa6c28d.slice/cri-containerd-79acd11e5d5dbf3fda07095de875aec19b4ecee7f5360c194782702c5c9d6919.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99410fcc_48ca_42d1_8b96_b3004889a24f.slice/cri-containerd-7576241bfc674323ebea88ef01a418847f8d7f88f3bceb0f24ecd79eaa420cc2.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod99410fcc_48ca_42d1_8b96_b3004889a24f.slice/cri-containerd-4450b06233bff34c5029514193f71883e8224b8027323a049d7db56bfa8e3782.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d4421e_a4a4_4235_9105_8c3f15922127.slice/cri-containerd-cedb84b2d8a804419130f27782675fed362461e410d8e9613c3104acebf431d7.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6d4421e_a4a4_4235_9105_8c3f15922127.slice/cri-containerd-e9e7766817705e9253920d104a34445834937f9915125a7ef46bcc66dfbe95ca.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod956b2cc4_bf45_4ec0_8ab6_3cacc582bae2.slice/cri-containerd-fcf6b0696ea04132351a0517eb1fd06a400861d5522fd26018a77ab4749f5b5c.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod956b2cc4_bf45_4ec0_8ab6_3cacc582bae2.slice/cri-containerd-0cc6313c2e67ff767f0ea749ccbc53a3410bee0516f57f2565daf640fc365e27.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-e404bf0181d1853e2258a035a7fb2e470538ee884c748942aa67599ce086f09f.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-820dcc0ffb28184dd65b99ec2e905a3445904712fb6a2d47f89397c0d01a3de2.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-9fb6d42466a6c52d45b3ffeec8f99d8abe850bd2c2bf7f0f328f16b07924998c.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode67cf60b_6906_485b_b653_f469fc948f10.slice/cri-containerd-dea7542a2c7e268b38716395ae9a715d2654abc6ec8ff4b77f1d3ef7a7d1b331.scope
    670      cgroup_device   multi                                          
