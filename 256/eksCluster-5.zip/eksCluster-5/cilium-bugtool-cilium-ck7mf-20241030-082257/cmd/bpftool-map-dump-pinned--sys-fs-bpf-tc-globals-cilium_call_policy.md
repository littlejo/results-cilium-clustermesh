key: a7 01 00 00  value: 0a 02 00 00
key: ce 03 00 00  value: 3e 02 00 00
key: 64 04 00 00  value: 80 02 00 00
key: 20 07 00 00  value: 1a 02 00 00
Found 4 elements
