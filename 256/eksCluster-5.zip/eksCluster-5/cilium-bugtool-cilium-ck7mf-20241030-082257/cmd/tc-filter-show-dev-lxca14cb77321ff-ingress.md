filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca14cb77321ff direct-action not_in_hw id 646 tag 7039928289c96896 jited 
