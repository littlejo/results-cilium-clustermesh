1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:6b:30:08:09:b7 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.219.104/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3218sec preferred_lft 3218sec
    inet6 fe80::86b:30ff:fe08:9b7/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:ce:74:d8:6a:25 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.209.109/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8ce:74ff:fed8:6a25/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b2:e9:39:83:e7:50 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b0e9:39ff:fe83:e750/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:d4:bb:b7:ea:ff brd ff:ff:ff:ff:ff:ff
    inet 10.5.0.183/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ecd4:bbff:feb7:eaff/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 9a:3a:6c:ee:0d:5c brd ff:ff:ff:ff:ff:ff
    inet6 fe80::983a:6cff:feee:d5c/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:f7:20:74:cb:1c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::40f7:20ff:fe74:cb1c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc0059a72095a0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:6d:63:cf:70:dc brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6c6d:63ff:fecf:70dc/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc876a0284a2cd@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:91:84:2e:b6:84 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1091:84ff:fe2e:b684/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca14cb77321ff@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 76:7f:88:70:b6:fc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::747f:88ff:fe70:b6fc/64 scope link 
       valid_lft forever preferred_lft forever
