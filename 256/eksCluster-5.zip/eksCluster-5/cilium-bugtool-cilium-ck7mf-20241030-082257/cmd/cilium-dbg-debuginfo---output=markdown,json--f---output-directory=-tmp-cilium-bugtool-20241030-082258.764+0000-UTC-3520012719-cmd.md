markdown output at /tmp/cilium-bugtool-20241030-082258.764+0000-UTC-3520012719/cmd/cilium-debuginfo-20241030-082329.866+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.764+0000-UTC-3520012719/cmd/cilium-debuginfo-20241030-082329.866+0000-UTC.json
