IP ADDRESS         LOCAL ENDPOINT INFO
172.31.178.158:0   (localhost)                                                                                        
10.142.0.131:0     id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45   
10.142.0.233:0     id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA     
10.142.0.77:0      id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45   
10.142.0.2:0       id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF   
10.142.0.248:0     (localhost)                                                                                        
172.31.136.110:0   (localhost)                                                                                        
