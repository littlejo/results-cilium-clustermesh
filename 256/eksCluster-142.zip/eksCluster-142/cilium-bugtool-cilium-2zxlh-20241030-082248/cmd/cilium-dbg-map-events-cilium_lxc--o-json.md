{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.248:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:38.285Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.136.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:38.286Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:38.286Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.944Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.948Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.997Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.064Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:43.162Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.458Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.458Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.458Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.489Z",
  "value": "id=411   sec_id=4688979 flags=0x0000 ifindex=16  mac=7A:D6:B6:96:6B:27 nodemac=F2:12:B9:6F:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.457Z",
  "value": "id=411   sec_id=4688979 flags=0x0000 ifindex=16  mac=7A:D6:B6:96:6B:27 nodemac=F2:12:B9:6F:8D:37"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.457Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.458Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.458Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.750Z",
  "value": "id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.142.0.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.214Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.176Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.176Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.177Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:52.180Z",
  "value": "id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.270Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.272Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.273Z",
  "value": "id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:53.273Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.171Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.171Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.171Z",
  "value": "id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:54.171Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.172Z",
  "value": "id=3189  sec_id=4706966 flags=0x0000 ifindex=14  mac=02:4F:04:E9:D6:76 nodemac=56:98:F6:DD:36:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.172Z",
  "value": "id=207   sec_id=4688979 flags=0x0000 ifindex=18  mac=BA:0C:45:B8:83:A9 nodemac=7E:18:EF:D6:2F:45"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.172Z",
  "value": "id=3368  sec_id=4     flags=0x0000 ifindex=10  mac=AA:CB:51:6F:33:D5 nodemac=42:41:49:DA:E8:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.142.0.77:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.173Z",
  "value": "id=1686  sec_id=4706966 flags=0x0000 ifindex=12  mac=26:73:DA:8C:0C:42 nodemac=96:33:3E:08:A1:45"
}

