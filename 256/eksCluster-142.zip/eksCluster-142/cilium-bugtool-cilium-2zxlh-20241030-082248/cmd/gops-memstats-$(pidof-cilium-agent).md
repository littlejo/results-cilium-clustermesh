alloc: 191.79MB (201111352 bytes)
total-alloc: 2.24GB (2400305304 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 63250180
frees: 61276446
heap-alloc: 191.79MB (201111352 bytes)
heap-sys: 251.64MB (263864320 bytes)
heap-idle: 35.54MB (37265408 bytes)
heap-in-use: 216.10MB (226598912 bytes)
heap-released: 2.34MB (2457600 bytes)
heap-objects: 1973734
stack-in-use: 64.31MB (67436544 bytes)
stack-sys: 64.31MB (67436544 bytes)
stack-mspan-inuse: 3.37MB (3538240 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.21MB (1264801 bytes)
gc-sys: 6.07MB (6369008 bytes)
next-gc: when heap-alloc >= 221.62MB (232389832 bytes)
last-gc: 2024-10-30 08:22:49.076139852 +0000 UTC
gc-pause-total: 14.76694ms
gc-pause: 98078
gc-pause-end: 1730276569076139852
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004931001401552654
enable-gc: true
debug-gc: false
