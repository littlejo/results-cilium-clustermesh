CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c5961c_9185_4568_807d_03c94f5190bd.slice/cri-containerd-030126bb52f770b04e7017d61b98ba1ce9ee823047fea484806f54dac55f0858.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c5961c_9185_4568_807d_03c94f5190bd.slice/cri-containerd-8de3f7b8a0bb85f578d390e183b252d6e400f7836ee4fd1bca3db1919f8dec15.scope
    536      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4147ea13_b579_4f03_bb72_a030c04adf80.slice/cri-containerd-9434ba42c377fc8dcab8ef879918a4262dbce7cc5e87cce91f477b40b2daaf2e.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4147ea13_b579_4f03_bb72_a030c04adf80.slice/cri-containerd-ba5f8a1f03ed2fa6f7cde6d578c6d78b330f987c856a3a2436911179c0bf11f5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3176d437_e9dc_47dd_99a0_618fb133fa76.slice/cri-containerd-3f52f39e707cfc98a8ab1d32d7436026b7f7bcd0c518faf9a213eac47a6da2e1.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3176d437_e9dc_47dd_99a0_618fb133fa76.slice/cri-containerd-badf03d9034ee1163630cda8a25c8b0cdacc0249877be432a8d758e38d1f235e.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ed6c4cc_7d24_496a_969e_756f2661e3e7.slice/cri-containerd-5959f5f21893945cf5dd6d9872246ed72fa8e89fd1a638457f4d1ec2970b9514.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ed6c4cc_7d24_496a_969e_756f2661e3e7.slice/cri-containerd-c5e2b79efaa709e3b4693ffaf8298a5b037e68bcbd1d8b295f2139c2b1369ea9.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-2775aff224086aaa28d43d79cb4df1ef790af23c2e47620c114895e0380077e2.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-f9eed12633540f10f7651608604995abf9002a79cb76f25106c14b39662bd959.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-f9e37dfe96d0cfdec8d5a6d8373f033505ce5a90caeed0750f221875b6d8892d.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-afab84fddd6849cf3522387c43908050bfa2c6b80f879273ff13e037c842c240.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55af61c8_221d_43d0_a39f_f61f9339f929.slice/cri-containerd-c92f4ce03e0ba37c166a4fdda5e1611c875c7ec970fc3cb7b02c30b260d90ac8.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod55af61c8_221d_43d0_a39f_f61f9339f929.slice/cri-containerd-8f92c551622e4a1778c6f4d3a09f4b7b6943296bf57a40a2e745144b461edb06.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4f2d340_ed2e_443d_9524_dd6bc781813c.slice/cri-containerd-95feb8b69f4d835219f7706335413fa6bdf07b7627f3e8c748f8d01106200d49.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd4f2d340_ed2e_443d_9524_dd6bc781813c.slice/cri-containerd-e8f69d76b109198e6306fc39eeed46eb54b8bffc92e3a0526fd352518d2da7b0.scope
    98       cgroup_device   multi                                          
