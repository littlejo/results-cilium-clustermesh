USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         671  0.0  0.0  13060  1228 ?        R    08:22   0:00 /usr/sbin/runc init
root         663  0.0  0.1 1616264 8720 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         647  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         628  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         604  0.0  0.2 1240432 16744 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         670  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         672  0.0  0.2 1240432 16744 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.7  4.7 1606336 382796 ?      Ssl  08:00   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 6972 ?        Sl   08:00   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
