[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd6c5961c_9185_4568_807d_03c94f5190bd.slice/cri-containerd-030126bb52f770b04e7017d61b98ba1ce9ee823047fea484806f54dac55f0858.scope"
      }
    ],
    "ips": [
      "10.142.0.2"
    ],
    "name": "coredns-cc6ccd49c-sfgpm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-f9e37dfe96d0cfdec8d5a6d8373f033505ce5a90caeed0750f221875b6d8892d.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-afab84fddd6849cf3522387c43908050bfa2c6b80f879273ff13e037c842c240.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf17e1a5c_4e39_42f1_a731_5574d4c35936.slice/cri-containerd-f9eed12633540f10f7651608604995abf9002a79cb76f25106c14b39662bd959.scope"
      }
    ],
    "ips": [
      "10.142.0.131"
    ],
    "name": "clustermesh-apiserver-77fcddbf86-txpnm",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9ed6c4cc_7d24_496a_969e_756f2661e3e7.slice/cri-containerd-c5e2b79efaa709e3b4693ffaf8298a5b037e68bcbd1d8b295f2139c2b1369ea9.scope"
      }
    ],
    "ips": [
      "10.142.0.77"
    ],
    "name": "coredns-cc6ccd49c-vq5jc",
    "namespace": "kube-system"
  }
]

