Endpoint ID: 207
Path: /sys/fs/bpf/tc/globals/cilium_policy_00207

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11502944   115099    0        
Allow    Ingress     1          ANY          NONE         disabled    9873751    103658    0        
Allow    Egress      0          ANY          NONE         disabled    13262196   130166    0        


Endpoint ID: 1075
Path: /sys/fs/bpf/tc/globals/cilium_policy_01075

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1686
Path: /sys/fs/bpf/tc/globals/cilium_policy_01686

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128719   1475      0        
Allow    Egress      0          ANY          NONE         disabled    19060    208       0        


Endpoint ID: 3189
Path: /sys/fs/bpf/tc/globals/cilium_policy_03189

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128716   1479      0        
Allow    Egress      0          ANY          NONE         disabled    18263    199       0        


Endpoint ID: 3368
Path: /sys/fs/bpf/tc/globals/cilium_policy_03368

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642520   20729     0        
Allow    Ingress     1          ANY          NONE         disabled    20224     238       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


