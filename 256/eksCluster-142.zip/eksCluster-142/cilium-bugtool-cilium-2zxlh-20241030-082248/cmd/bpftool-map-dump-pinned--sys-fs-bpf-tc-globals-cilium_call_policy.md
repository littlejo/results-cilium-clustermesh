key: cf 00 00 00  value: 72 02 00 00
key: 96 06 00 00  value: 1d 02 00 00
key: 75 0c 00 00  value: 02 02 00 00
key: 28 0d 00 00  value: 0b 02 00 00
Found 4 elements
