key: 07 00 00 00  value: 0a 8e 00 4d 00 35 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 8e 00 4d 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 8e 00 02 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 8e 00 83 09 4b 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f e6 be 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 88 6e 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 8e 00 02 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f bb f3 01 bb 00 00  00 00 00 00
Found 8 elements
