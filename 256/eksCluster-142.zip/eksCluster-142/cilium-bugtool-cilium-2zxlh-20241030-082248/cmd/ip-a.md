1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:a0:23:4f:84:8b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.136.110/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3446sec preferred_lft 3446sec
    inet6 fe80::4a0:23ff:fe4f:848b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6c:ce:5e:66:d7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.178.158/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::46c:ceff:fe5e:66d7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:f5:c3:84:41:07 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4cf5:c3ff:fe84:4107/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:c6:7b:6d:38:a8 brd ff:ff:ff:ff:ff:ff
    inet 10.142.0.248/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d4c6:7bff:fe6d:38a8/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 36:a0:43:86:46:31 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::34a0:43ff:fe86:4631/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:41:49:da:e8:ea brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4041:49ff:feda:e8ea/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcad8934817f92@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 96:33:3e:08:a1:45 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9433:3eff:fe08:a145/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc80e9398da0b2@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 56:98:f6:dd:36:ff brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::5498:f6ff:fedd:36ff/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcf5560fcdc02f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7e:18:ef:d6:2f:45 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::7c18:efff:fed6:2f45/64 scope link 
       valid_lft forever preferred_lft forever
