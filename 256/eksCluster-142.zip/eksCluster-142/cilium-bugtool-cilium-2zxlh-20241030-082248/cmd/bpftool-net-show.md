xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 576
ens6(5) clsact/ingress cil_from_netdev-ens6 id 583
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 568
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 561
cilium_host(7) clsact/egress cil_from_host-cilium_host id 556
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 522
lxcad8934817f92(12) clsact/ingress cil_from_container-lxcad8934817f92 id 531
lxc80e9398da0b2(14) clsact/ingress cil_from_container-lxc80e9398da0b2 id 510
lxcf5560fcdc02f(18) clsact/ingress cil_from_container-lxcf5560fcdc02f id 633

flow_dissector:

netfilter:

