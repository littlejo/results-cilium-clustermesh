Total: 669
TCP:   1853 (estab 436, closed 1398, orphaned 0, timewait 554)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  455       444       11       
INET	  465       450       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                            127.0.0.1:38331      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36083 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.136.110%ens5:68         0.0.0.0:*    uid:192 ino:73391 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36158 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14923 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36157 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14924 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::4a0:23ff:fe4f:848b]%ens5:546           [::]:*    uid:192 ino:15150 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
