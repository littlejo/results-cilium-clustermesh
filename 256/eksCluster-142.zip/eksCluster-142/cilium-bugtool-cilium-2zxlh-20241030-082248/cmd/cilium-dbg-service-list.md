ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.187.243:443 (active)    
                                          2 => 172.31.230.190:443 (active)    
2    10.100.123.57:443     ClusterIP      1 => 172.31.136.110:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.142.0.77:53 (active)        
                                          2 => 10.142.0.2:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.142.0.77:9153 (active)      
                                          2 => 10.142.0.2:9153 (active)       
5    10.100.113.253:2379   ClusterIP      1 => 10.142.0.131:2379 (active)     
