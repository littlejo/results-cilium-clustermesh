REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35399     2799159     677    bpf_overlay.c
Interface                 INGRESS     636860    131595335   1132   bpf_host.c
Success                   EGRESS      15372     1205002     1694   bpf_host.c
Success                   EGRESS      270514    33756688    1308   bpf_lxc.c
Success                   EGRESS      35061     2771651     53     encap.h
Success                   INGRESS     311762    35298262    86     l3.h
Success                   INGRESS     332440    36936465    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
