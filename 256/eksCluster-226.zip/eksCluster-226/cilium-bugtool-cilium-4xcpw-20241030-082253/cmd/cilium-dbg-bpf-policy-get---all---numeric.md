Endpoint ID: 99
Path: /sys/fs/bpf/tc/globals/cilium_policy_00099

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    115360   1326      0        
Allow    Egress      0          ANY          NONE         disabled    16468    177       0        


Endpoint ID: 568
Path: /sys/fs/bpf/tc/globals/cilium_policy_00568

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655271   20886     0        
Allow    Ingress     1          ANY          NONE         disabled    18080     212       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2686
Path: /sys/fs/bpf/tc/globals/cilium_policy_02686

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2989
Path: /sys/fs/bpf/tc/globals/cilium_policy_02989

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11381650   112135    0        
Allow    Ingress     1          ANY          NONE         disabled    9469755    99240     0        
Allow    Egress      0          ANY          NONE         disabled    11491976   114050    0        


Endpoint ID: 3001
Path: /sys/fs/bpf/tc/globals/cilium_policy_03001

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    114898   1319      0        
Allow    Egress      0          ANY          NONE         disabled    16382    177       0        


