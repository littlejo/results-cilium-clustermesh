 08:22:54 up 29 min,  0 users,  load average: 0.03, 0.16, 0.18
