USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         673  0.0  0.1 1616264 8724 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         635  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         629  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         620  0.0  0.2 1240432 16860 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         680  0.0  0.0   6408  1636 ?        R    08:22   0:00  \_ ps auxfw
root         681  0.0  0.0   3852  1292 ?        R    08:22   0:00  \_ bash -c hostname
root         619  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         618  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root           1  3.3  4.7 1606080 383716 ?      Ssl  08:03   0:39 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.0 1229744 7960 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
