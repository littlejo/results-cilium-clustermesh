ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.228.47:443 (active)    
                                         2 => 172.31.172.222:443 (active)   
2    10.100.56.27:443     ClusterIP      1 => 172.31.177.98:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.226.0.217:53 (active)      
                                         2 => 10.226.0.131:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.226.0.217:9153 (active)    
                                         2 => 10.226.0.131:9153 (active)    
5    10.100.41.255:2379   ClusterIP      1 => 10.226.0.236:2379 (active)    
