REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35192     2782625     677    bpf_overlay.c
Interface                 INGRESS     619918    128884527   1132   bpf_host.c
Success                   EGRESS      15000     1174840     1694   bpf_host.c
Success                   EGRESS      260490    33053094    1308   bpf_lxc.c
Success                   EGRESS      34473     2728930     53     encap.h
Success                   INGRESS     302891    33997891    86     l3.h
Success                   INGRESS     323734    35649722    235    trace.h
Unsupported L3 protocol   EGRESS      40        2992        1492   bpf_lxc.c
