IP ADDRESS         LOCAL ENDPOINT INFO
10.226.0.131:0     id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70   
172.31.143.143:0   (localhost)                                                                                        
10.226.0.130:0     (localhost)                                                                                        
10.226.0.230:0     id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10     
10.226.0.236:0     id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F   
10.226.0.217:0     id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB   
172.31.177.98:0    (localhost)                                                                                        
