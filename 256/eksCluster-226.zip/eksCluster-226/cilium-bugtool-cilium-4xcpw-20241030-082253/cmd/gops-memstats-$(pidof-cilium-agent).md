alloc: 185.79MB (194813840 bytes)
total-alloc: 2.17GB (2331061888 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62206601
frees: 60277876
heap-alloc: 185.79MB (194813840 bytes)
heap-sys: 250.95MB (263143424 bytes)
heap-idle: 39.20MB (41099264 bytes)
heap-in-use: 211.76MB (222044160 bytes)
heap-released: 3.22MB (3375104 bytes)
heap-objects: 1928725
stack-in-use: 65.00MB (68157440 bytes)
stack-sys: 65.00MB (68157440 bytes)
stack-mspan-inuse: 3.33MB (3490720 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 981.51KB (1005065 bytes)
gc-sys: 6.03MB (6323712 bytes)
next-gc: when heap-alloc >= 212.19MB (222495624 bytes)
last-gc: 2024-10-30 08:22:57.86508318 +0000 UTC
gc-pause-total: 18.435529ms
gc-pause: 205771
gc-pause-end: 1730276577865083180
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0004803033269633606
enable-gc: true
debug-gc: false
