[
  {
    "containers": [
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-1710ca7e0ab07a783d6a3e0fbc65f46ff9d64534f1a1af2e5fb27648252454f5.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-b7a9031627888320a7099410f8868abaf9ab5f506b647fab55b82527a0ce260e.scope"
      },
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-39e175852a47ca0575ca7f076d07f7b4938dfd5d7c6e60d7a7d5c337567532ad.scope"
      }
    ],
    "ips": [
      "10.226.0.236"
    ],
    "name": "clustermesh-apiserver-7c9ddc9c57-rwgtk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6edd1e7_9be6_4911_94d9_5af9531f693a.slice/cri-containerd-abb90116e39463ab1f61f551787a5b3565bf9fbf3b55dbd1310bd89e99b597d6.scope"
      }
    ],
    "ips": [
      "10.226.0.131"
    ],
    "name": "coredns-cc6ccd49c-vt94c",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36cb9de7_9b35_4cc4_b725_988d338662a4.slice/cri-containerd-adf9ad05a19fcf78e5382c1f7585056d0d4a6d5822603225c8e114346294f13b.scope"
      }
    ],
    "ips": [
      "10.226.0.217"
    ],
    "name": "coredns-cc6ccd49c-dd87c",
    "namespace": "kube-system"
  }
]

