{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.130:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.005Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.005Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.177.98:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:21.005Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.271Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.273Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.335Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.391Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:25.464Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:01.731Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:01.732Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:01.732Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:01.761Z",
  "value": "id=2892  sec_id=7449542 flags=0x0000 ifindex=16  mac=7E:52:EF:26:E5:C0 nodemac=66:99:45:F7:EC:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:02.730Z",
  "value": "id=2892  sec_id=7449542 flags=0x0000 ifindex=16  mac=7E:52:EF:26:E5:C0 nodemac=66:99:45:F7:EC:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:02.731Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:02.731Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:02.731Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:55.474Z",
  "value": "id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.226.0.24:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.935Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.371Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.371Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.372Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.373Z",
  "value": "id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.378Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.381Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.382Z",
  "value": "id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.382Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.371Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.371Z",
  "value": "id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.371Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.371Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.230:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.371Z",
  "value": "id=568   sec_id=4     flags=0x0000 ifindex=10  mac=76:C7:15:04:16:A5 nodemac=86:D7:90:AC:9E:10"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.372Z",
  "value": "id=2989  sec_id=7449542 flags=0x0000 ifindex=18  mac=4E:2F:33:1A:E2:22 nodemac=82:3C:F1:65:E0:9F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.131:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.372Z",
  "value": "id=3001  sec_id=7467195 flags=0x0000 ifindex=12  mac=72:B8:73:6C:DC:05 nodemac=5E:08:8A:87:0B:70"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.226.0.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:40.372Z",
  "value": "id=99    sec_id=7467195 flags=0x0000 ifindex=14  mac=0E:7F:F2:99:57:1B nodemac=B2:B3:ED:84:7A:EB"
}

