CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36cb9de7_9b35_4cc4_b725_988d338662a4.slice/cri-containerd-adf9ad05a19fcf78e5382c1f7585056d0d4a6d5822603225c8e114346294f13b.scope
    549      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod36cb9de7_9b35_4cc4_b725_988d338662a4.slice/cri-containerd-00bfc1c95c1e9935d0800968d53bf188b1f947060af8a57b48ef1b60d9ca4af0.scope
    537      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6edd1e7_9be6_4911_94d9_5af9531f693a.slice/cri-containerd-abb90116e39463ab1f61f551787a5b3565bf9fbf3b55dbd1310bd89e99b597d6.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6edd1e7_9be6_4911_94d9_5af9531f693a.slice/cri-containerd-8ee0a3f1db1a7c081455d7dc9293d85d38b5b7aba1d9f458e018c5766d36f69c.scope
    529      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0179d2aa_b0fb_473e_b4bb_d416cfcb2fe0.slice/cri-containerd-0e38c3824139a62a82663028595c987c6cf0167cbb57810fab7881a7fc11df4b.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0179d2aa_b0fb_473e_b4bb_d416cfcb2fe0.slice/cri-containerd-5898972114ed007620361de2e313e669c2967766dc57dcdf0ac57e9f9c08fc85.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f554749_34c1_4996_bd6e_cb5a832b6232.slice/cri-containerd-3ca60066f28b8e9a2b1726420404b7551d6c5234773ceda785e50aabc0022cca.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2f554749_34c1_4996_bd6e_cb5a832b6232.slice/cri-containerd-1538812ecc0fa3591e429f8b3cac643f92092259c965b36fbb47400c6acea5ff.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode796d742_896f_472d_a538_f83a1980a4ca.slice/cri-containerd-eae6e1689a7cc5862b84e85f170d31ada5a558f4611a74db858367d375d3c106.scope
    107      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode796d742_896f_472d_a538_f83a1980a4ca.slice/cri-containerd-e44c7d46e09a6ffcd30a0c6ec2e01ffaacc1e7dcdebc639edd321f2c9e95bc73.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-1710ca7e0ab07a783d6a3e0fbc65f46ff9d64534f1a1af2e5fb27648252454f5.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-00eb2597d400f467db400cad013ac686717fcc35eabd7485cea89b7b06f93bc8.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-b7a9031627888320a7099410f8868abaf9ab5f506b647fab55b82527a0ce260e.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod714570b1_f9a0_4752_97f9_ecfdae1ccb43.slice/cri-containerd-39e175852a47ca0575ca7f076d07f7b4938dfd5d7c6e60d7a7d5c337567532ad.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c5fdbbf_1d65_4399_a8eb_7f74f1718d38.slice/cri-containerd-a762549ecfe7a1bb769a9e6194389e8d2e97b23421977c1a69e1e509d451a5d9.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c5fdbbf_1d65_4399_a8eb_7f74f1718d38.slice/cri-containerd-e190ba1d615abaa1edfbd1af10e278470c2df54f9383762747ee453702fc107c.scope
    99       cgroup_device   multi                                          
