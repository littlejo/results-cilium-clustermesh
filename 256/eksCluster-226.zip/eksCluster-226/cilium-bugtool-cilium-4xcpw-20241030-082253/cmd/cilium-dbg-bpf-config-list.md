KEY             VALUE
AgentLiveness   1771591698590
UTimeOffset     3379443035156250
