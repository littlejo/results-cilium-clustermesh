markdown output at /tmp/cilium-bugtool-20241030-082254.619+0000-UTC-1352342511/cmd/cilium-debuginfo-20241030-082325.833+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082254.619+0000-UTC-1352342511/cmd/cilium-debuginfo-20241030-082325.833+0000-UTC.json
