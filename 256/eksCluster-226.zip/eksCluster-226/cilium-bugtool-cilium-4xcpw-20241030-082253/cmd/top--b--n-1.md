top - 08:22:54 up 29 min,  0 users,  load average: 0.03, 0.16, 0.18
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 16.7 us, 23.3 sy,  0.0 ni, 60.0 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4492.4 free,   1176.2 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6453.1 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383716  77564 S   6.7   4.8   0:39.40 cilium-+
    620 root      20   0 1240432  16860  11544 S   6.7   0.2   0:00.02 cilium-+
    396 root      20   0 1229744   7960   3836 S   0.0   0.1   0:01.06 cilium-+
    618 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    619 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    629 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    635 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    673 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    695 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    713 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
