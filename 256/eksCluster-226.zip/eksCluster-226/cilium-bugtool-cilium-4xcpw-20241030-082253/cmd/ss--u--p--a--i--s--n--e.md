Total: 693
TCP:   1867 (estab 440, closed 1408, orphaned 0, timewait 564)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  459       447       12       
INET	  469       453       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:13307 sk:100 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:42899      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:35220 sk:101 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                   172.31.177.98%ens5:68         0.0.0.0:*    uid:192 ino:15527 sk:102 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:35361 sk:103 cgroup:/ <->                                                  
UNCONN 0      0                                [::1]:323           [::]:*    ino:13308 sk:104 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::41a:4dff:fe16:f90d]%ens5:546           [::]:*    uid:192 ino:15519 sk:105 cgroup:unreachable:c4e v6only:1 <->                   
UNCONN 0      0                                 [::]:8472          [::]:*    ino:35360 sk:106 cgroup:/ v6only:1 <->                                         
