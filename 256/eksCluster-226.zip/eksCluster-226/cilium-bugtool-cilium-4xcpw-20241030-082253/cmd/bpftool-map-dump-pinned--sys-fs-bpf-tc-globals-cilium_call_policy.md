key: 63 00 00 00  value: f8 01 00 00
key: 38 02 00 00  value: 14 02 00 00
key: ad 0b 00 00  value: 6d 02 00 00
key: b9 0b 00 00  value: 0c 02 00 00
Found 4 elements
