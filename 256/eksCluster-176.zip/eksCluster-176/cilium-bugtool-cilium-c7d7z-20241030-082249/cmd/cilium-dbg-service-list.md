ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.190.36:443 (active)    
                                         2 => 172.31.193.83:443 (active)    
2    10.100.114.200:443   ClusterIP      1 => 172.31.181.74:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.176.0.156:53 (active)      
                                         2 => 10.176.0.142:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.176.0.156:9153 (active)    
                                         2 => 10.176.0.142:9153 (active)    
5    10.100.19.44:2379    ClusterIP      1 => 10.176.0.121:2379 (active)    
