KEY             VALUE
AgentLiveness   1861703198176
UTimeOffset     3379442853515625
