REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36657     2900129     677    bpf_overlay.c
Interface                 INGRESS     688806    137753647   1132   bpf_host.c
Success                   EGRESS      16598     1305685     1694   bpf_host.c
Success                   EGRESS      304939    37960746    1308   bpf_lxc.c
Success                   EGRESS      37325     2944530     53     encap.h
Success                   INGRESS     351187    39986932    86     l3.h
Success                   INGRESS     371897    41625422    235    trace.h
Unsupported L3 protocol   EGRESS      44        3312        1492   bpf_lxc.c
