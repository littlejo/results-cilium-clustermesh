key: b0 00 00 00  value: 1c 02 00 00
key: da 00 00 00  value: 1b 02 00 00
key: 2a 01 00 00  value: 6a 02 00 00
key: dd 05 00 00  value: 05 02 00 00
Found 4 elements
