USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         680  0.0  0.2 1240432 16260 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         694  0.0  0.0   6408  1644 ?        R    08:22   0:00  \_ ps auxfw
root         696  0.0  0.2 1240432 16260 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         660  0.0  0.0 1228744 3712 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         653  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  4.3  5.0 1606336 405340 ?      Ssl  08:02   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         396  0.0  0.1 1229488 8232 ?        Sl   08:02   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
