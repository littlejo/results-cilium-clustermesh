markdown output at /tmp/cilium-bugtool-20241030-082251.247+0000-UTC-3418953376/cmd/cilium-debuginfo-20241030-082322.229+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082251.247+0000-UTC-3418953376/cmd/cilium-debuginfo-20241030-082322.229+0000-UTC.json
