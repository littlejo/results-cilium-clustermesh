{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.21:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.144Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.178.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.144Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.181.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:34.144Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:38.474Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:38.479Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:38.518Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:38.519Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:38.533Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.858Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.859Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.859Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.889Z",
  "value": "id=644   sec_id=5809651 flags=0x0000 ifindex=16  mac=7A:BD:AA:B2:F6:CB nodemac=F6:0E:97:D9:3E:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:23.890Z",
  "value": "id=644   sec_id=5809651 flags=0x0000 ifindex=16  mac=7A:BD:AA:B2:F6:CB nodemac=F6:0E:97:D9:3E:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.858Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.859Z",
  "value": "id=644   sec_id=5809651 flags=0x0000 ifindex=16  mac=7A:BD:AA:B2:F6:CB nodemac=F6:0E:97:D9:3E:94"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.859Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:24.859Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:55.546Z",
  "value": "id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.176.0.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:06.032Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.283Z",
  "value": "id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.285Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.285Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:07.286Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.287Z",
  "value": "id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.302Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.303Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:08.303Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.284Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.284Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.284Z",
  "value": "id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:09.284Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.284Z",
  "value": "id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.121:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.284Z",
  "value": "id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.284Z",
  "value": "id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.176.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:10.285Z",
  "value": "id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23"
}

