[
  {
    "containers": [
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-1a78dbdc9618394b7669b926c98f2b54748f4efe586dcfa1bd4c1d13de2636c0.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-b2ea469193ddfa02ba7a1c1e9156bba4985951d37079f6b67d4ec4f7caa096e9.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-4662bf434e290525d65c0766e06795d7291cf4678d74ab653658d341038db85e.scope"
      }
    ],
    "ips": [
      "10.176.0.121"
    ],
    "name": "clustermesh-apiserver-5747bb5bbb-sw86q",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce83abf0_9b91_4dd5_92cf_7bd0393b75d3.slice/cri-containerd-18f8ca0c7011898f816dd485eebd279449ad2430ffb74cc59dd52222a07fc3f0.scope"
      }
    ],
    "ips": [
      "10.176.0.156"
    ],
    "name": "coredns-cc6ccd49c-9gr7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c103270_adeb_4e53_9c42_b69a7391de45.slice/cri-containerd-f3d3b4bc0bdbf3d0cc5b05cfad0349dbf77b8359ecb0d207f1e6c75c21cc5f0b.scope"
      }
    ],
    "ips": [
      "10.176.0.142"
    ],
    "name": "coredns-cc6ccd49c-zzq75",
    "namespace": "kube-system"
  }
]

