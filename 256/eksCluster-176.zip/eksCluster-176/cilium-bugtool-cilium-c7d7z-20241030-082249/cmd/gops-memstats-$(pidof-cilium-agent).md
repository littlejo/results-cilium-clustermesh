alloc: 157.56MB (165218064 bytes)
total-alloc: 2.48GB (2665334448 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 66837459
frees: 65065534
heap-alloc: 157.56MB (165218064 bytes)
heap-sys: 252.48MB (264740864 bytes)
heap-idle: 62.81MB (65863680 bytes)
heap-in-use: 189.66MB (198877184 bytes)
heap-released: 1.00MB (1048576 bytes)
heap-objects: 1771925
stack-in-use: 67.50MB (70778880 bytes)
stack-sys: 67.50MB (70778880 bytes)
stack-mspan-inuse: 3.22MB (3381600 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.09MB (1145161 bytes)
gc-sys: 6.00MB (6288848 bytes)
next-gc: when heap-alloc >= 212.88MB (223224504 bytes)
last-gc: 2024-10-30 08:22:54.978727716 +0000 UTC
gc-pause-total: 18.277618ms
gc-pause: 128396
gc-pause-end: 1730276574978727716
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0006127770122168614
enable-gc: true
debug-gc: false
