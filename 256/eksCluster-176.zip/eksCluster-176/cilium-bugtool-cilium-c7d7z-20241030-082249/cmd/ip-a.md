1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:b5:f5:20:a5:87 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.181.74/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3579sec preferred_lft 3579sec
    inet6 fe80::4b5:f5ff:fe20:a587/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:65:08:b3:cd:83 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.178.95/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::465:8ff:feb3:cd83/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:24:77:09:2f:ff brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d024:77ff:fe09:2fff/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:86:24:79:6e:2d brd ff:ff:ff:ff:ff:ff
    inet 10.176.0.21/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::9886:24ff:fe79:6e2d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 1e:8a:71:b9:a4:88 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1c8a:71ff:feb9:a488/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5a:b0:63:6c:34:ed brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::58b0:63ff:fe6c:34ed/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc21952ebabff8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:03:7d:6e:ce:5e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9003:7dff:fe6e:ce5e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc316a7b35aead@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:ac:17:d0:ba:23 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::64ac:17ff:fed0:ba23/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcc8fc80c6fe26@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:a3:06:3e:e4:da brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bca3:6ff:fe3e:e4da/64 scope link 
       valid_lft forever preferred_lft forever
