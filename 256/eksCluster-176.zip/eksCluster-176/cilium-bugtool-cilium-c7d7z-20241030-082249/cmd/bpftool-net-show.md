xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 499
ens6(5) clsact/ingress cil_from_netdev-ens6 id 505
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 492
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 487
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 543
lxc21952ebabff8(12) clsact/ingress cil_from_container-lxc21952ebabff8 id 526
lxc316a7b35aead(14) clsact/ingress cil_from_container-lxc316a7b35aead id 535
lxcc8fc80c6fe26(18) clsact/ingress cil_from_container-lxcc8fc80c6fe26 id 609

flow_dissector:

netfilter:

