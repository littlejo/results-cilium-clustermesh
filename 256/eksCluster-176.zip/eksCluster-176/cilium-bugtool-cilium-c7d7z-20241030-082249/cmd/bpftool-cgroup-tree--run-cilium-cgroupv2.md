CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04bfccef_a026_4da0_a470_cdccc09ec8c6.slice/cri-containerd-a38c1e9948dd1d276b629e9b2ac0126c1e372b5a0eddca7379b33f5bb2c5e866.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod04bfccef_a026_4da0_a470_cdccc09ec8c6.slice/cri-containerd-1f54a30ea563013b1f0a5fe25f282e5566c4b4e5c592edf879ef857e1dc19c06.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce83abf0_9b91_4dd5_92cf_7bd0393b75d3.slice/cri-containerd-18f8ca0c7011898f816dd485eebd279449ad2430ffb74cc59dd52222a07fc3f0.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podce83abf0_9b91_4dd5_92cf_7bd0393b75d3.slice/cri-containerd-8eb89cb5233e76539d76a7b6427caab49f1a028faf07b53516368a46284ddfa7.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c103270_adeb_4e53_9c42_b69a7391de45.slice/cri-containerd-76cc4ff42aacc69c3f82089cfbee3164710617b0af6e16a0a4c48d58c6d410ec.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c103270_adeb_4e53_9c42_b69a7391de45.slice/cri-containerd-f3d3b4bc0bdbf3d0cc5b05cfad0349dbf77b8359ecb0d207f1e6c75c21cc5f0b.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7efce8c_5ba7_4e4c_b1cd_12177b4a5cef.slice/cri-containerd-26044b491115574d408cdda9cce173b12d28d75648f1b3d54d2e3c37e925e157.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd7efce8c_5ba7_4e4c_b1cd_12177b4a5cef.slice/cri-containerd-4bde35d806aba00d285d8183902d9a4bb716f3c76e1d26810cca993fbfb1ad70.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod60ea58b3_7bac_49a8_84dc_ed7b9b6e2cdd.slice/cri-containerd-747b2fb23577b2282f8f370d267cfb1353ab435ce0195d70de0038d6cf5342d0.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod60ea58b3_7bac_49a8_84dc_ed7b9b6e2cdd.slice/cri-containerd-8fd16a8064b1bade9328033a775916ad1551db5b190766b36aea7b654ac6dc46.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-dda82c69f3340de74baaadf4ebf7dcf4ddd086fe8cd6a0b74bafc534049dc260.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-1a78dbdc9618394b7669b926c98f2b54748f4efe586dcfa1bd4c1d13de2636c0.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-b2ea469193ddfa02ba7a1c1e9156bba4985951d37079f6b67d4ec4f7caa096e9.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod229145b5_1ec4_4f0e_82a9_4ec3cebc0fc9.slice/cri-containerd-4662bf434e290525d65c0766e06795d7291cf4678d74ab653658d341038db85e.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ebcf611_3c99_4d64_86a8_da36b76db9a7.slice/cri-containerd-0f4ebcc982fd77ed388299e6088e957ed74eb330cd6e2ff26e214b1dfef1df04.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ebcf611_3c99_4d64_86a8_da36b76db9a7.slice/cri-containerd-82964b6adf451a276772e579ca37a375a46fea3d69ce232575499e854072a8ef.scope
    107      cgroup_device   multi                                          
