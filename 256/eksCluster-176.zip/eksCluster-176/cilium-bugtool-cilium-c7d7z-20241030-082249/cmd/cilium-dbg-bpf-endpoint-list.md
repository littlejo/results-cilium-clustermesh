IP ADDRESS        LOCAL ENDPOINT INFO
10.176.0.156:0    id=1501  sec_id=5814729 flags=0x0000 ifindex=12  mac=62:2A:27:5F:50:8A nodemac=92:03:7D:6E:CE:5E   
10.176.0.142:0    id=218   sec_id=5814729 flags=0x0000 ifindex=14  mac=22:27:5B:C9:51:1B nodemac=66:AC:17:D0:BA:23   
172.31.181.74:0   (localhost)                                                                                        
10.176.0.21:0     (localhost)                                                                                        
172.31.178.95:0   (localhost)                                                                                        
10.176.0.28:0     id=176   sec_id=4     flags=0x0000 ifindex=10  mac=F6:04:54:2E:CD:20 nodemac=5A:B0:63:6C:34:ED     
10.176.0.121:0    id=298   sec_id=5809651 flags=0x0000 ifindex=18  mac=86:18:7A:29:1D:55 nodemac=BE:A3:06:3E:E4:DA   
