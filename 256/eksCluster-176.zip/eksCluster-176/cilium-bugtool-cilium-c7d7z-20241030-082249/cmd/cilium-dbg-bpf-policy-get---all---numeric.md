Endpoint ID: 176
Path: /sys/fs/bpf/tc/globals/cilium_policy_00176

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1642356   20758     0        
Allow    Ingress     1          ANY          NONE         disabled    17534     206       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 218
Path: /sys/fs/bpf/tc/globals/cilium_policy_00218

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    118032   1352      0        
Allow    Egress      0          ANY          NONE         disabled    16486    177       0        


Endpoint ID: 298
Path: /sys/fs/bpf/tc/globals/cilium_policy_00298

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11617182   117052    0        
Allow    Ingress     1          ANY          NONE         disabled    12002349   123619    0        
Allow    Egress      0          ANY          NONE         disabled    14530782   141826    0        


Endpoint ID: 422
Path: /sys/fs/bpf/tc/globals/cilium_policy_00422

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1501
Path: /sys/fs/bpf/tc/globals/cilium_policy_01501

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    119088   1368      0        
Allow    Egress      0          ANY          NONE         disabled    16166    173       0        


