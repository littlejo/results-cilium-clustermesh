key: 22 01 00 00  value: 73 02 00 00
key: b4 01 00 00  value: 17 02 00 00
key: 60 02 00 00  value: 08 02 00 00
key: 9b 07 00 00  value: 00 02 00 00
Found 4 elements
