IP ADDRESS        LOCAL ENDPOINT INFO
10.65.0.74:0      (localhost)                                                                                        
10.65.0.41:0      id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D   
10.65.0.96:0      id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05   
172.31.209.31:0   (localhost)                                                                                        
10.65.0.42:0      id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D     
10.65.0.236:0     id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A   
172.31.208.31:0   (localhost)                                                                                        
