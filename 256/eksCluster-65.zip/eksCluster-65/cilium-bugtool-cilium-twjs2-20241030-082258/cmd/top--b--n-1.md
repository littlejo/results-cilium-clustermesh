top - 08:22:59 up 37 min,  0 users,  load average: 0.01, 0.16, 0.16
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 23.3 us, 30.0 sy,  0.0 ni, 43.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4514.2 free,   1183.8 used,   2116.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 378644  78400 S   0.0   4.7   0:42.89 cilium-+
    414 root      20   0 1229488   7000   2924 S   0.0   0.1   0:01.10 cilium-+
    644 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    649 root      20   0 1240432  16388  11420 S   0.0   0.2   0:00.02 cilium-+
    651 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    652 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    658 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    708 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    733 root      20   0 1228744   3656   2976 S   0.0   0.0   0:00.00 gops
