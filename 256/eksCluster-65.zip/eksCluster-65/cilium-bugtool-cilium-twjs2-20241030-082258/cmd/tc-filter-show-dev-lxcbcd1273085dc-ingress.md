filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcbcd1273085dc direct-action not_in_hw id 625 tag 24c0f55c11ab884d jited 
