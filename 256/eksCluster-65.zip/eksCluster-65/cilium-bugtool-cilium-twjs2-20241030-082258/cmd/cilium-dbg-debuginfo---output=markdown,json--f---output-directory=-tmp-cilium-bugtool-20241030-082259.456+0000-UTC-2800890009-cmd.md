markdown output at /tmp/cilium-bugtool-20241030-082259.456+0000-UTC-2800890009/cmd/cilium-debuginfo-20241030-082330.56+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.456+0000-UTC-2800890009/cmd/cilium-debuginfo-20241030-082330.56+0000-UTC.json
