ID   Frontend           Service Type   Backend                            
1    10.100.0.1:443     ClusterIP      1 => 172.31.170.137:443 (active)   
                                       2 => 172.31.209.123:443 (active)   
2    10.100.32.13:443   ClusterIP      1 => 172.31.209.31:4244 (active)   
3    10.100.0.10:53     ClusterIP      1 => 10.65.0.96:53 (active)        
                                       2 => 10.65.0.41:53 (active)        
4    10.100.0.10:9153   ClusterIP      1 => 10.65.0.96:9153 (active)      
                                       2 => 10.65.0.41:9153 (active)      
5    10.100.72.8:2379   ClusterIP      1 => 10.65.0.236:2379 (active)     
