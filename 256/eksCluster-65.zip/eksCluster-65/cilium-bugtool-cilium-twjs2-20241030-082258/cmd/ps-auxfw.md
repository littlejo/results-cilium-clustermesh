USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         658  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         652  0.0  0.0 1229000 4052 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         651  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         649  2.0  0.2 1240432 16388 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         696  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         698  0.0  0.0   3852  1272 ?        R    08:22   0:00  \_ bash -c hostname
root         644  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  2.3  4.7 1606336 378644 ?      Ssl  07:52   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         414  0.0  0.0 1229488 7000 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
