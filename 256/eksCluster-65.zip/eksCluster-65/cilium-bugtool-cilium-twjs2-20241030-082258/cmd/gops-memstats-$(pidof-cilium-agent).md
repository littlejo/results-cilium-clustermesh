alloc: 135.89MB (142487048 bytes)
total-alloc: 2.26GB (2425901184 bytes)
sys: 333.02MB (349196644 bytes)
lookups: 0
mallocs: 63421285
frees: 62347977
heap-alloc: 135.89MB (142487048 bytes)
heap-sys: 255.38MB (267788288 bytes)
heap-idle: 76.50MB (80216064 bytes)
heap-in-use: 178.88MB (187572224 bytes)
heap-released: 2.09MB (2195456 bytes)
heap-objects: 1073308
stack-in-use: 64.59MB (67731456 bytes)
stack-sys: 64.59MB (67731456 bytes)
stack-mspan-inuse: 2.77MB (2906080 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.24MB (1301217 bytes)
gc-sys: 6.00MB (6295040 bytes)
next-gc: when heap-alloc >= 217.02MB (227560072 bytes)
last-gc: 2024-10-30 08:23:13.493992375 +0000 UTC
gc-pause-total: 8.576914ms
gc-pause: 103664
gc-pause-end: 1730276593493992375
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00030014177152734215
enable-gc: true
debug-gc: false
