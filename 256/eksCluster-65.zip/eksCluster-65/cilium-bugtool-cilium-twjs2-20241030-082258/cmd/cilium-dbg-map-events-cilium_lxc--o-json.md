{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.74:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.143Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.208.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.143Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.209.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:42.143Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.479Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.482Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.541Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.614Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:46.685Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.548Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.548Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.548Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:07.577Z",
  "value": "id=3527  sec_id=2172459 flags=0x0000 ifindex=16  mac=06:86:11:E7:5C:08 nodemac=2E:19:87:8F:39:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.547Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.548Z",
  "value": "id=3527  sec_id=2172459 flags=0x0000 ifindex=16  mac=06:86:11:E7:5C:08 nodemac=2E:19:87:8F:39:67"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.548Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:08.548Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.961Z",
  "value": "id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.65.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.348Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.262Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.262Z",
  "value": "id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.262Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:36.262Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.262Z",
  "value": "id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.262Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.263Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:37.264Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.262Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.262Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.263Z",
  "value": "id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:38.263Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.41:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.263Z",
  "value": "id=1947  sec_id=2193497 flags=0x0000 ifindex=14  mac=7A:E0:FF:55:F9:A8 nodemac=16:B0:36:DC:A4:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.263Z",
  "value": "id=608   sec_id=4     flags=0x0000 ifindex=10  mac=DA:E6:37:1C:A9:A2 nodemac=AE:5E:38:12:4E:8D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.263Z",
  "value": "id=290   sec_id=2172459 flags=0x0000 ifindex=18  mac=86:B3:70:EA:1D:E5 nodemac=DE:BA:FF:E5:7C:7A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.65.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:39.263Z",
  "value": "id=436   sec_id=2193497 flags=0x0000 ifindex=12  mac=5A:08:53:C5:2C:09 nodemac=82:8C:0E:F6:E3:05"
}

