Endpoint ID: 290
Path: /sys/fs/bpf/tc/globals/cilium_policy_00290

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11491646   113619    0        
Allow    Ingress     1          ANY          NONE         disabled    9514954    99840     0        
Allow    Egress      0          ANY          NONE         disabled    11974473   118476    0        


Endpoint ID: 436
Path: /sys/fs/bpf/tc/globals/cilium_policy_00436

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176530   2034      0        
Allow    Egress      0          ANY          NONE         disabled    21811    244       0        


Endpoint ID: 608
Path: /sys/fs/bpf/tc/globals/cilium_policy_00608

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1662190   21040     0        
Allow    Ingress     1          ANY          NONE         disabled    25880     302       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1280
Path: /sys/fs/bpf/tc/globals/cilium_policy_01280

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1947
Path: /sys/fs/bpf/tc/globals/cilium_policy_01947

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    175672   2021      0        
Allow    Egress      0          ANY          NONE         disabled    21355    239       0        


