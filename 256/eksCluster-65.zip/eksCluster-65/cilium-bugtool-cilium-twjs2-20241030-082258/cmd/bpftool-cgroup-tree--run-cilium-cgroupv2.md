CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1412ef14_86e5_4add_8bc7_2f59f01b5297.slice/cri-containerd-9950848f974ab3139089f06c52b30024c0934d16497898bea9cc1ab379ffe8f9.scope
    526      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1412ef14_86e5_4add_8bc7_2f59f01b5297.slice/cri-containerd-190c8f38d96c2d1ef62324c0275d2a596818481621c5f6975edf765a055a7471.scope
    548      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddbac3382_6f63_4aab_9317_3beff17bdc2a.slice/cri-containerd-890e667c4a28283899782846ddab606ba735917d5f37b0ef3843fd7492202fe9.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddbac3382_6f63_4aab_9317_3beff17bdc2a.slice/cri-containerd-73039d0f46bcc4fff892598fc4aa42718778e51041bf693ca37f523a3fd76f92.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e654e5_1596_434e_9231_8646624b6b52.slice/cri-containerd-61b52f1583f9161a57fff727ec2748c4930d7d9e599ea4e34289250f6c8d2c05.scope
    552      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e654e5_1596_434e_9231_8646624b6b52.slice/cri-containerd-64b8e7e2ff013509d8da56b2c4db4d79940327b1a51263e9ae6cb0b537d0eb51.scope
    533      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d8622d_5ae4_422f_aa8d_688b4592ff2f.slice/cri-containerd-6aecb285984fb346df5f234b2d32c94f860bf97f1db3c1c7785ce39a8030d4f3.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d8622d_5ae4_422f_aa8d_688b4592ff2f.slice/cri-containerd-cefa9095d25955fa577b0d21ca9d908ad0403a480f98295bfe7b1cea917aa213.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00cacb97_0c7c_4c07_8068_852d01b2bb22.slice/cri-containerd-e606d52ae959336560cb0d152a9ff56204258d7ba58dabbd90e757cfa7bf0211.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod00cacb97_0c7c_4c07_8068_852d01b2bb22.slice/cri-containerd-45824acea35b20b746681fa520a89fdec0369d1f969ea93d5ac0ee7844724e1a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc1deb03_fd47_4554_ac83_1e4e113066b3.slice/cri-containerd-95949f4830932559f769b29177ad844de0bbda5bfd719a4754a155ffd24e9c5f.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbc1deb03_fd47_4554_ac83_1e4e113066b3.slice/cri-containerd-5ec658d654cfcb40e8a7f858de0edb7dd662d4a2818e3ac3b46a3a659e7e5e43.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-6c043d05628f6a6d4257e05b9bc1be830214db4a8893fbecd09d77782b0789d4.scope
    634      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-8346e203d2ae19b2ee67c8118e5d195d4983ee7211fd8978b13ae09d07e4e5fd.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-c0d256c0ea8580eaf804ec0832c9ce139ebc76b58082a036cf708424119695e0.scope
    658      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-82d5d24765e08bdd3d8263a7feaa195ef393039ad6a8202e7150ca23a43aef45.scope
    650      cgroup_device   multi                                          
