REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35702     2818789     677    bpf_overlay.c
Interface                 INGRESS     629428    131310283   1132   bpf_host.c
Success                   EGRESS      15337     1202524     1694   bpf_host.c
Success                   EGRESS      265999    33492135    1308   bpf_lxc.c
Success                   EGRESS      35109     2779509     53     encap.h
Success                   INGRESS     307611    34588020    86     l3.h
Success                   INGRESS     328627    36248331    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
