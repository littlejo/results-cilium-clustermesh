KEY             VALUE
AgentLiveness   2285703043068
UTimeOffset     3379442041015625
