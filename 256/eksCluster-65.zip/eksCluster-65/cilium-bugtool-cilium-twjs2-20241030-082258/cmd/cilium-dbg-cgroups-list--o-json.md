[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1412ef14_86e5_4add_8bc7_2f59f01b5297.slice/cri-containerd-190c8f38d96c2d1ef62324c0275d2a596818481621c5f6975edf765a055a7471.scope"
      }
    ],
    "ips": [
      "10.65.0.41"
    ],
    "name": "coredns-cc6ccd49c-4cqvr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-8346e203d2ae19b2ee67c8118e5d195d4983ee7211fd8978b13ae09d07e4e5fd.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-82d5d24765e08bdd3d8263a7feaa195ef393039ad6a8202e7150ca23a43aef45.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd3d0d16f_a47d_42d8_9a62_55693218a9a0.slice/cri-containerd-c0d256c0ea8580eaf804ec0832c9ce139ebc76b58082a036cf708424119695e0.scope"
      }
    ],
    "ips": [
      "10.65.0.236"
    ],
    "name": "clustermesh-apiserver-5854ccd6b7-mnvt8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod27e654e5_1596_434e_9231_8646624b6b52.slice/cri-containerd-61b52f1583f9161a57fff727ec2748c4930d7d9e599ea4e34289250f6c8d2c05.scope"
      }
    ],
    "ips": [
      "10.65.0.96"
    ],
    "name": "coredns-cc6ccd49c-dt72z",
    "namespace": "kube-system"
  }
]

