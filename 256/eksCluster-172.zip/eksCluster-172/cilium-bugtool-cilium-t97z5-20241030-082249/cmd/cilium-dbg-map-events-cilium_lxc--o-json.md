{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.534Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.136.100:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.534Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.181.78:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:34.534Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.379Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.386Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.419Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:39.442Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.709Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.710Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.714Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:16.739Z",
  "value": "id=124   sec_id=5696176 flags=0x0000 ifindex=16  mac=F2:02:91:78:D2:C6 nodemac=C2:21:B5:5A:22:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.709Z",
  "value": "id=124   sec_id=5696176 flags=0x0000 ifindex=16  mac=F2:02:91:78:D2:C6 nodemac=C2:21:B5:5A:22:5E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.709Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.709Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:17.710Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:50.435Z",
  "value": "id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.172.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:56.302Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.529Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.530Z",
  "value": "id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.530Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:29.531Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.530Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.531Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.531Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:30.531Z",
  "value": "id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.530Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.530Z",
  "value": "id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.530Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:31.531Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.530Z",
  "value": "id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.530Z",
  "value": "id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.108:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.531Z",
  "value": "id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.172.0.215:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.531Z",
  "value": "id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1"
}

