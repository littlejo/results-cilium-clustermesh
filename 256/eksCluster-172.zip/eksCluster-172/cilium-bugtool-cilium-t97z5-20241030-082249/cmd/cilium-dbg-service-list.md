ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.134.141:443 (active)    
                                         2 => 172.31.244.24:443 (active)     
2    10.100.160.243:443   ClusterIP      1 => 172.31.136.100:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.172.0.137:53 (active)       
                                         2 => 10.172.0.31:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.172.0.137:9153 (active)     
                                         2 => 10.172.0.31:9153 (active)      
5    10.100.249.41:2379   ClusterIP      1 => 10.172.0.108:2379 (active)     
