top - 08:22:51 up 31 min,  0 users,  load average: 0.22, 0.17, 0.11
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 24.1 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4478.1 free,   1189.8 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6439.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 380556  77936 S   6.7   4.8   0:50.23 cilium-+
    645 root      20   0 1240432  15996  10768 S   6.7   0.2   0:00.03 cilium-+
    396 root      20   0 1229488   6932   2864 S   0.0   0.1   0:01.11 cilium-+
    619 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    633 root      20   0 1229000   4048   3392 S   0.0   0.1   0:00.00 gops
    644 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    651 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    667 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    700 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    718 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
