key: 01 00 00 00  value: ac 1f 86 8d 01 bb 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 88 64 10 94 00 00  00 00 00 00
key: 09 00 00 00  value: 0a ac 00 1f 23 c1 00 00  00 00 00 00
key: 07 00 00 00  value: 0a ac 00 89 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a ac 00 6c 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a ac 00 89 00 35 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f f4 18 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a ac 00 1f 00 35 00 00  00 00 00 00
Found 8 elements
