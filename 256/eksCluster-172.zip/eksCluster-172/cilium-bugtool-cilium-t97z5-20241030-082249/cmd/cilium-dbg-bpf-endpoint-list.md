IP ADDRESS         LOCAL ENDPOINT INFO
10.172.0.215:0     id=1170  sec_id=4     flags=0x0000 ifindex=10  mac=3E:FC:49:9E:6B:C6 nodemac=0A:AF:FF:CB:84:F1     
172.31.181.78:0    (localhost)                                                                                        
172.31.136.100:0   (localhost)                                                                                        
10.172.0.31:0      id=3074  sec_id=5689702 flags=0x0000 ifindex=12  mac=5A:48:F1:8A:50:95 nodemac=6E:29:00:93:8A:82   
10.172.0.108:0     id=809   sec_id=5696176 flags=0x0000 ifindex=18  mac=8A:2C:0F:04:25:D6 nodemac=2E:C1:F2:E1:9C:F3   
10.172.0.137:0     id=458   sec_id=5689702 flags=0x0000 ifindex=14  mac=D6:CA:2F:40:C9:3D nodemac=D2:12:F2:4B:9B:EE   
10.172.0.86:0      (localhost)                                                                                        
