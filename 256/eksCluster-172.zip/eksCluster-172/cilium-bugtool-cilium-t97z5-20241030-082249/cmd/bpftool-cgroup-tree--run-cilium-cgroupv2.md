CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1a45f8d_4b8d_4665_984e_bcbfc220be68.slice/cri-containerd-210275eb64d2456c27b5bb8c0c388cad048f6cd9ba01bb8d0188335c12ec722f.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1a45f8d_4b8d_4665_984e_bcbfc220be68.slice/cri-containerd-de9861bcfefd343a2ca0dad11cca3f6f38500ee8be637efd0e580ed1dc54ea47.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3b77c0b_9ba7_4a65_9d5b_7b9d6d760021.slice/cri-containerd-59fa84600529a967849f8ce034219a669dddb30987b569444958659666c4c221.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3b77c0b_9ba7_4a65_9d5b_7b9d6d760021.slice/cri-containerd-11be83b014f21ae01388943b140cec7897bf5074e02c6dae3d4c261cfb41f11d.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d2977e1_7823_4c79_8881_8261279ac284.slice/cri-containerd-956e72d364168bb942a691abd390c043abeddd25a9095b430c93789dfc8f2c9a.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1d2977e1_7823_4c79_8881_8261279ac284.slice/cri-containerd-8e108dc0065311ad1f5cf8aa1ecc1e170504a9690117c0efd8663dd53b3abf03.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod840ff3d5_091d_4d92_b7b4_4af4c71e638a.slice/cri-containerd-2c7030ef2b330a04688b795e4fa094d69f37581ae07bc8014d5980ccf9f99204.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod840ff3d5_091d_4d92_b7b4_4af4c71e638a.slice/cri-containerd-7451f1a2d125fa506c24efe588ba2c93f98302ab61e9903afed131a74e604dba.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82b6f0be_4839_4f5a_a6c7_da76dbd0f7c2.slice/cri-containerd-88f377594eabc7edf9b188a6969d5781de292626ae965dbd9d242e41858e4879.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod82b6f0be_4839_4f5a_a6c7_da76dbd0f7c2.slice/cri-containerd-660f4ab38f4f97bd3267f668402d6e05ca07aae70cb7b4ee14846014394d42d8.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2e58fb9_333d_4922_8dbe_64c823a887e9.slice/cri-containerd-99405adc549591d962c5fe94a7d485caa85d3d00ac3bff18a453b9f3f4a6d9fd.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd2e58fb9_333d_4922_8dbe_64c823a887e9.slice/cri-containerd-7383556982ca6d235aed6adc9f0a3bf2563d82db445e7f29ef981886b11f6992.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-d6d815b53da7440e7188faf0d0dc5d1fd27478a987593ea2930684731483eee0.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-b16ccd90901d59d5c82821c7527d28695284ee7f0d7befac9845009336da84a7.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-b437b049ec0a55d34ab5355d74fa24c197687a831b4afe4f6a8e97c591b464ab.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-92ce04e8fe848b2fea7ecdad77f4216ced2ecf941a22b5dd0fb97d04bd6c48d2.scope
    650      cgroup_device   multi                                          
