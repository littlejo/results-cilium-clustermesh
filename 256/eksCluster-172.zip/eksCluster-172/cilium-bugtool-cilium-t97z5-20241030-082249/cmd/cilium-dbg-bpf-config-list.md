KEY             VALUE
AgentLiveness   1932093954449
UTimeOffset     3379442714843750
