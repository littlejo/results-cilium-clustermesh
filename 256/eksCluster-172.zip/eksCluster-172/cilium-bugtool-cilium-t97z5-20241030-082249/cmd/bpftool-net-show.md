xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 504
ens6(5) clsact/ingress cil_from_netdev-ens6 id 508
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 489
cilium_host(7) clsact/egress cil_from_host-cilium_host id 485
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 481
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 553
lxcdec21cf6e58d(12) clsact/ingress cil_from_container-lxcdec21cf6e58d id 517
lxcd33439c95f37(14) clsact/ingress cil_from_container-lxcd33439c95f37 id 543
lxc53983026d545(18) clsact/ingress cil_from_container-lxc53983026d545 id 612

flow_dissector:

netfilter:

