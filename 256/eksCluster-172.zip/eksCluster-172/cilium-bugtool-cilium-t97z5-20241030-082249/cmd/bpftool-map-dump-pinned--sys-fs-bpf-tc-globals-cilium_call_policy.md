key: ca 01 00 00  value: 1a 02 00 00
key: 29 03 00 00  value: 6c 02 00 00
key: 92 04 00 00  value: 2b 02 00 00
key: 02 0c 00 00  value: 0e 02 00 00
Found 4 elements
