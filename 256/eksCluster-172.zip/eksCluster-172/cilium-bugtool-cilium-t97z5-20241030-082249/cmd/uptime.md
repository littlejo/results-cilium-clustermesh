 08:22:50 up 31 min,  0 users,  load average: 0.22, 0.17, 0.11
