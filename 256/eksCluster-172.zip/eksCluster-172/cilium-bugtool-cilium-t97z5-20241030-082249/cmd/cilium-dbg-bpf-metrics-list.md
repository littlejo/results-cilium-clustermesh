REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36539     2894771     677    bpf_overlay.c
Interface                 INGRESS     659132    134494033   1132   bpf_host.c
Success                   EGRESS      16494     1298586     1694   bpf_host.c
Success                   EGRESS      284531    34940602    1308   bpf_lxc.c
Success                   EGRESS      37178     2934625     53     encap.h
Success                   INGRESS     327264    37068896    86     l3.h
Success                   INGRESS     347960    38709127    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
