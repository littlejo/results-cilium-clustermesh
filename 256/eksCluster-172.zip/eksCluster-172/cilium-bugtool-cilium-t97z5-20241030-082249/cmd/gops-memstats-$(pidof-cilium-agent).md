alloc: 207.21MB (217274752 bytes)
total-alloc: 2.32GB (2489417336 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 64690177
frees: 62275132
heap-alloc: 207.21MB (217274752 bytes)
heap-sys: 247.10MB (259104768 bytes)
heap-idle: 22.24MB (23322624 bytes)
heap-in-use: 224.86MB (235782144 bytes)
heap-released: 888.00KB (909312 bytes)
heap-objects: 2415045
stack-in-use: 60.47MB (63406080 bytes)
stack-sys: 60.47MB (63406080 bytes)
stack-mspan-inuse: 3.58MB (3757440 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1022.28KB (1046817 bytes)
gc-sys: 6.42MB (6729264 bytes)
next-gc: when heap-alloc >= 224.50MB (235403608 bytes)
last-gc: 2024-10-30 08:23:21.117965321 +0000 UTC
gc-pause-total: 15.958909ms
gc-pause: 111714
gc-pause-end: 1730276601117965321
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0004885717011588778
enable-gc: true
debug-gc: false
