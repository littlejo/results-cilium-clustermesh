[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod840ff3d5_091d_4d92_b7b4_4af4c71e638a.slice/cri-containerd-7451f1a2d125fa506c24efe588ba2c93f98302ab61e9903afed131a74e604dba.scope"
      }
    ],
    "ips": [
      "10.172.0.31"
    ],
    "name": "coredns-cc6ccd49c-dnztf",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-b16ccd90901d59d5c82821c7527d28695284ee7f0d7befac9845009336da84a7.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-b437b049ec0a55d34ab5355d74fa24c197687a831b4afe4f6a8e97c591b464ab.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod84b9153f_e856_4132_a890_91e2e634d943.slice/cri-containerd-92ce04e8fe848b2fea7ecdad77f4216ced2ecf941a22b5dd0fb97d04bd6c48d2.scope"
      }
    ],
    "ips": [
      "10.172.0.108"
    ],
    "name": "clustermesh-apiserver-7df9759fd-r7b47",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode3b77c0b_9ba7_4a65_9d5b_7b9d6d760021.slice/cri-containerd-11be83b014f21ae01388943b140cec7897bf5074e02c6dae3d4c261cfb41f11d.scope"
      }
    ],
    "ips": [
      "10.172.0.137"
    ],
    "name": "coredns-cc6ccd49c-kgrfb",
    "namespace": "kube-system"
  }
]

