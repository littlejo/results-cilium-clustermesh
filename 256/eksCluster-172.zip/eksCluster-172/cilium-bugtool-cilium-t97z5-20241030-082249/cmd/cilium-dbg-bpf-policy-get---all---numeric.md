Endpoint ID: 458
Path: /sys/fs/bpf/tc/globals/cilium_policy_00458

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    124198   1424      0        
Allow    Egress      0          ANY          NONE         disabled    17172    186       0        


Endpoint ID: 809
Path: /sys/fs/bpf/tc/globals/cilium_policy_00809

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11502798   116219    0        
Allow    Ingress     1          ANY          NONE         disabled    10879796   115057    0        
Allow    Egress      0          ANY          NONE         disabled    14649089   143260    0        


Endpoint ID: 1101
Path: /sys/fs/bpf/tc/globals/cilium_policy_01101

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1170
Path: /sys/fs/bpf/tc/globals/cilium_policy_01170

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644125   20746     0        
Allow    Ingress     1          ANY          NONE         disabled    18637     219       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3074
Path: /sys/fs/bpf/tc/globals/cilium_policy_03074

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    123151   1412      0        
Allow    Egress      0          ANY          NONE         disabled    17858    194       0        


