IP ADDRESS         LOCAL ENDPOINT INFO
10.46.0.186:0      id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE   
10.46.0.226:0      id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF     
10.46.0.220:0      (localhost)                                                                                        
172.31.144.255:0   (localhost)                                                                                        
10.46.0.245:0      id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9   
10.46.0.76:0       id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96   
172.31.130.28:0    (localhost)                                                                                        
