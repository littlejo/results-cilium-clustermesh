top - 08:22:57 up 34 min,  0 users,  load average: 0.35, 0.39, 0.29
Tasks:   8 total,   2 running,   6 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 30.0 sy,  0.0 ni,  3.3 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4469.6 free,   1198.5 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6430.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 391296  81080 S  93.3   4.9   0:52.93 cilium-+
    416 root      20   0 1229744   8240   3836 S   0.0   0.1   0:01.14 cilium-+
    662 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    665 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    666 root      20   0 1240432  16588  11420 S   0.0   0.2   0:00.02 cilium-+
    712 root      20   0    6576   2424   2100 R   0.0   0.0   0:00.00 top
    737 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    743 root      20   0 1484936   8812   6536 R   0.0   0.1   0:00.00 runc:[2+
