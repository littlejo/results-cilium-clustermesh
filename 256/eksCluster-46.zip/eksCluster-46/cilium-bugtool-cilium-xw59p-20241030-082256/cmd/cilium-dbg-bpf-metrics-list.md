REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37010     2925737     677    bpf_overlay.c
Interface                 INGRESS     654023    133625529   1132   bpf_host.c
Success                   EGRESS      16622     1306723     1694   bpf_host.c
Success                   EGRESS      25400     4025420     86     l3.h
Success                   EGRESS      275125    34531593    1308   bpf_lxc.c
Success                   EGRESS      37165     2938789     53     encap.h
Success                   INGRESS     318897    35935949    86     l3.h
Success                   INGRESS     365336    41624429    235    trace.h
Unsupported L3 protocol   EGRESS      46        3452        1492   bpf_lxc.c
