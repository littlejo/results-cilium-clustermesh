alloc: 179.58MB (188298464 bytes)
total-alloc: 2.37GB (2545417304 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65627611
frees: 63497797
heap-alloc: 179.58MB (188298464 bytes)
heap-sys: 251.07MB (263266304 bytes)
heap-idle: 50.90MB (53370880 bytes)
heap-in-use: 200.17MB (209895424 bytes)
heap-released: 5.25MB (5505024 bytes)
heap-objects: 2129814
stack-in-use: 64.91MB (68059136 bytes)
stack-sys: 64.91MB (68059136 bytes)
stack-mspan-inuse: 3.43MB (3596960 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 984.82KB (1008457 bytes)
gc-sys: 6.01MB (6299184 bytes)
next-gc: when heap-alloc >= 213.01MB (223360376 bytes)
last-gc: 2024-10-30 08:22:59.288965388 +0000 UTC
gc-pause-total: 18.172468ms
gc-pause: 116315
gc-pause-end: 1730276579288965388
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00043470971374571897
enable-gc: true
debug-gc: false
