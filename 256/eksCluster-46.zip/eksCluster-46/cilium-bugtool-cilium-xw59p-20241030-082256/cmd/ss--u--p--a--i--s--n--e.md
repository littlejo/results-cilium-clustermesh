Total: 673
TCP:   1838 (estab 422, closed 1397, orphaned 0, timewait 560)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  441       431       10       
INET	  451       437       14       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.130.28%ens5:68         0.0.0.0:*    uid:192 ino:83855 sk:3e0 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:33788 sk:3e1 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:14262 sk:3e2 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38257      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=41)) ino:34038 sk:3e3 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:33787 sk:3e4 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:14263 sk:3e5 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::413:20ff:fe4e:d5cd]%ens5:546           [::]:*    uid:192 ino:15486 sk:3e6 cgroup:unreachable:c4e v6only:1 <->                   
