Endpoint ID: 288
Path: /sys/fs/bpf/tc/globals/cilium_policy_00288

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11608876   115251    0        
Allow    Ingress     1          ANY          NONE         disabled    10234585   107603    0        
Allow    Egress      0          ANY          NONE         disabled    12538409   123841    0        


Endpoint ID: 939
Path: /sys/fs/bpf/tc/globals/cilium_policy_00939

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1667046   21085     0        
Allow    Ingress     1          ANY          NONE         disabled    22796     266       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1511
Path: /sys/fs/bpf/tc/globals/cilium_policy_01511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    694699   6238      0        
Allow    Ingress     1          ANY          NONE         disabled    149127   1713      0        
Allow    Egress      0          ANY          NONE         disabled    125261   1205      0        


Endpoint ID: 1818
Path: /sys/fs/bpf/tc/globals/cilium_policy_01818

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    719841   6462      0        
Allow    Ingress     1          ANY          NONE         disabled    149876   1729      0        
Allow    Egress      0          ANY          NONE         disabled    125505   1208      0        


Endpoint ID: 2592
Path: /sys/fs/bpf/tc/globals/cilium_policy_02592

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


