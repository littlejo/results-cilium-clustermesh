1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:13:20:4e:d5:cd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.130.28/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3367sec preferred_lft 3367sec
    inet6 fe80::413:20ff:fe4e:d5cd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:f0:65:1e:c2:71 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.144.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4f0:65ff:fe1e:c271/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:e5:8f:7e:3c:bf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::98e5:8fff:fe7e:3cbf/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:18:dc:43:f5:ca brd ff:ff:ff:ff:ff:ff
    inet 10.46.0.220/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::6418:dcff:fe43:f5ca/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 7a:0a:e4:f8:e0:93 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::780a:e4ff:fef8:e093/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:72:be:06:4f:bf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4c72:beff:fe06:4fbf/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5fe57c4de031@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d6:69:2c:99:d6:b9 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d469:2cff:fe99:d6b9/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0473c287c1ad@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:84:27:8a:87:96 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::1084:27ff:fe8a:8796/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc701d4f7994c5@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:ac:b7:ed:15:de brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::fcac:b7ff:feed:15de/64 scope link 
       valid_lft forever preferred_lft forever
