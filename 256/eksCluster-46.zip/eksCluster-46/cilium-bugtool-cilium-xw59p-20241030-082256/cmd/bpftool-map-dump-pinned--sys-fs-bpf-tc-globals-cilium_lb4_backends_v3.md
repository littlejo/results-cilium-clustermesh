key: 0b 00 00 00  value: 0a 2e 00 ba 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 2e 00 f5 00 35 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f 82 1c 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f bd cd 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2e 00 4c 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2e 00 4c 23 c1 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f fe 0b 01 bb 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2e 00 f5 23 c1 00 00  00 00 00 00
Found 8 elements
