CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff749bfe_9719_49d2_ae95_c7f9806f9ff2.slice/cri-containerd-f3bb0bc3c8042d87d463b15ad0f7ae8aa9f671fd5b6eaa930b7e56fdd42d9142.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff749bfe_9719_49d2_ae95_c7f9806f9ff2.slice/cri-containerd-cd833fb367a5cfaa919228260474fbab0f7941d3f23e837c90f68a7af6c72c3a.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43231edf_b287_4cf3_a7fc_4b830480c259.slice/cri-containerd-525a4d511f3f29b44612c7b0736717cbeff466878b6a11af22bb39fb2997a5ac.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod43231edf_b287_4cf3_a7fc_4b830480c259.slice/cri-containerd-b55f057dcfa9a3f6eb83d655b432f60c36238b7fda4b5502805d30577247453f.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc7900bee_d1ab_4f19_b978_78801aad8861.slice/cri-containerd-1ad06bd1a2ff2d60af0c078aafbef100ff2bd9a95305771022c887bfb90e002d.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc7900bee_d1ab_4f19_b978_78801aad8861.slice/cri-containerd-faac6a51b3e5c3c28df60a00e8ee90940e2e8cd300259686803d8e27b763cfe6.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod386ce074_7dc0_4dfe_9f47_ee6bdbdb8150.slice/cri-containerd-682cbaec8088d6dd63d84e045185dd110d60c4a7cb433cd1e048c4c394480429.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod386ce074_7dc0_4dfe_9f47_ee6bdbdb8150.slice/cri-containerd-d5dba3a8549ff8aa992098a062e05c4db6722d6fa3e332d622b75c60d1d7c81e.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad27101d_72c5_434d_a9b5_e3d3808b69f4.slice/cri-containerd-471f26899004af94d8545672a79f52f7261fcaba9d6d92f42ed96f8f67ae3c3c.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podad27101d_72c5_434d_a9b5_e3d3808b69f4.slice/cri-containerd-c2f2e67f14dd68454d3fcf1910fdfed78a90efff0c24cbbd2499667da25bc3c9.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-1593acf46a8c09fb1197c7a48585e5bb520d5f2120795db7285e4a844b49974c.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-0bdc831fbdeab9acebf6d2f93408da93b644a1b74af47946be2c7a08d034109f.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-444109a845bdb0caaffe00cea052913a2f2961b95d8acf2144900426f6b1c809.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-6dbbfa3afd33506d23d6dcaf27bf71b34fbf720d701603f8906890e8dbe7d98a.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a48d300_dcf6_4209_a5fa_d982b500446b.slice/cri-containerd-7e00929dae98311b494a1ba0ec3fc127f9ea871fcff91e6f5dbdf6873452a104.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0a48d300_dcf6_4209_a5fa_d982b500446b.slice/cri-containerd-728468c21b79d7a80526127892eda9f08fe94c91a6892b75744c7ab535300532.scope
    97       cgroup_device   multi                                          
