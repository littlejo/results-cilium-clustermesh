 08:22:57 up 34 min,  0 users,  load average: 0.35, 0.39, 0.29
