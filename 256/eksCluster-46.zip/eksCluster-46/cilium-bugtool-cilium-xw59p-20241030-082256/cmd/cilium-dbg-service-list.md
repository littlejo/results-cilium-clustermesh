ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.254.11:443 (active)    
                                         2 => 172.31.189.205:443 (active)   
2    10.100.46.143:443    ClusterIP      1 => 172.31.130.28:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.46.0.245:53 (active)       
                                         2 => 10.46.0.76:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.46.0.245:9153 (active)     
                                         2 => 10.46.0.76:9153 (active)      
5    10.100.208.16:2379   ClusterIP      1 => 10.46.0.186:2379 (active)     
