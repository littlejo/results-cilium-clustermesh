USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         666  0.0  0.2 1240432 16588 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         700  0.0  0.2 1240432 16588 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         665  0.0  0.0 1228744 3660 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         662  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.4  4.8 1606080 385224 ?      Ssl  07:57   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.1 1229744 8240 ?        Sl   07:57   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
