{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.220:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.092Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.130.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.092Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.144.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:19.092Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.672Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.673Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.727Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.732Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.816Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.816Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:23.816Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.611Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.611Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.612Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.643Z",
  "value": "id=505   sec_id=1544201 flags=0x0000 ifindex=16  mac=96:BB:6F:A5:A1:1D nodemac=E2:E0:6E:31:C8:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:16.643Z",
  "value": "id=505   sec_id=1544201 flags=0x0000 ifindex=16  mac=96:BB:6F:A5:A1:1D nodemac=E2:E0:6E:31:C8:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.612Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.612Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.612Z",
  "value": "id=505   sec_id=1544201 flags=0x0000 ifindex=16  mac=96:BB:6F:A5:A1:1D nodemac=E2:E0:6E:31:C8:4C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:17.613Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.411Z",
  "value": "id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.46.0.38:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:27.923Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.464Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.464Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.464Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:29.465Z",
  "value": "id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.466Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.467Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.467Z",
  "value": "id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:30.468Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.467Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.467Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.467Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.467Z",
  "value": "id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.467Z",
  "value": "id=1818  sec_id=1572452 flags=0x0000 ifindex=14  mac=56:0D:8F:46:AD:D6 nodemac=12:84:27:8A:87:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.226:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.467Z",
  "value": "id=939   sec_id=4     flags=0x0000 ifindex=10  mac=AA:0E:3A:93:D6:AB nodemac=4E:72:BE:06:4F:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.186:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.467Z",
  "value": "id=288   sec_id=1544201 flags=0x0000 ifindex=18  mac=DA:F8:7D:5F:ED:8C nodemac=FE:AC:B7:ED:15:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.46.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:32.467Z",
  "value": "id=1511  sec_id=1572452 flags=0x0000 ifindex=12  mac=FA:84:76:A9:C1:7B nodemac=D6:69:2C:99:D6:B9"
}

