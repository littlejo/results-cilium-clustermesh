KEY             VALUE
AgentLiveness   2075654181028
UTimeOffset     3379442447265625
