[
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-0bdc831fbdeab9acebf6d2f93408da93b644a1b74af47946be2c7a08d034109f.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-444109a845bdb0caaffe00cea052913a2f2961b95d8acf2144900426f6b1c809.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod17cbf3f1_4b85_4deb_b225_438ee7c0ee31.slice/cri-containerd-6dbbfa3afd33506d23d6dcaf27bf71b34fbf720d701603f8906890e8dbe7d98a.scope"
      }
    ],
    "ips": [
      "10.46.0.186"
    ],
    "name": "clustermesh-apiserver-745b6bb769-mwthb",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc7900bee_d1ab_4f19_b978_78801aad8861.slice/cri-containerd-faac6a51b3e5c3c28df60a00e8ee90940e2e8cd300259686803d8e27b763cfe6.scope"
      }
    ],
    "ips": [
      "10.46.0.245"
    ],
    "name": "coredns-cc6ccd49c-p72k5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podff749bfe_9719_49d2_ae95_c7f9806f9ff2.slice/cri-containerd-cd833fb367a5cfaa919228260474fbab0f7941d3f23e837c90f68a7af6c72c3a.scope"
      }
    ],
    "ips": [
      "10.46.0.76"
    ],
    "name": "coredns-cc6ccd49c-jmkgt",
    "namespace": "kube-system"
  }
]

