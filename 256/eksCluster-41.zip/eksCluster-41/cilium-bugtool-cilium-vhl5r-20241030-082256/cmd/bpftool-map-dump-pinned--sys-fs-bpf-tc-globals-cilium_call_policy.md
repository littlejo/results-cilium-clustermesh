key: 18 00 00 00  value: fd 01 00 00
key: af 00 00 00  value: 6f 02 00 00
key: f2 01 00 00  value: 08 02 00 00
key: c2 05 00 00  value: 1d 02 00 00
Found 4 elements
