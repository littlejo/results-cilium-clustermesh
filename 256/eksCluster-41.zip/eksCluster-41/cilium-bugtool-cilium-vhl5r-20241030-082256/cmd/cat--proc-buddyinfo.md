Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal      1     32     50      0     11      9      6      2      0      3    857 
