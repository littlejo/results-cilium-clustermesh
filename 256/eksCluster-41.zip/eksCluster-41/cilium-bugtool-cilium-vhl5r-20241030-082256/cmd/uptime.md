 08:22:57 up 35 min,  0 users,  load average: 0.22, 0.31, 0.23
