markdown output at /tmp/cilium-bugtool-20241030-082257.606+0000-UTC-3711923043/cmd/cilium-debuginfo-20241030-082328.452+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082257.606+0000-UTC-3711923043/cmd/cilium-debuginfo-20241030-082328.452+0000-UTC.json
