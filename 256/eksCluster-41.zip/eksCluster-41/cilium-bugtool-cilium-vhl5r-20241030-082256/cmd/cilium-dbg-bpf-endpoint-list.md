IP ADDRESS         LOCAL ENDPOINT INFO
10.41.0.42:0       (localhost)                                                                                        
10.41.0.203:0      id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D   
172.31.202.126:0   (localhost)                                                                                        
10.41.0.199:0      id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62   
172.31.192.60:0    (localhost)                                                                                        
10.41.0.40:0       id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79   
10.41.0.254:0      id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E     
