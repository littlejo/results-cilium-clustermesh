{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.42:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:13.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.192.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:13.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.202.126:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:13.526Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:18.106Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:18.115Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:18.156Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:18.245Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:18.305Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.447Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.448Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.448Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.479Z",
  "value": "id=773   sec_id=1383428 flags=0x0000 ifindex=16  mac=E2:69:2D:CA:3A:BD nodemac=3E:A0:C7:4E:76:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.447Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.448Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.448Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.448Z",
  "value": "id=773   sec_id=1383428 flags=0x0000 ifindex=16  mac=E2:69:2D:CA:3A:BD nodemac=3E:A0:C7:4E:76:0F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.166Z",
  "value": "id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.41.0.145:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.128Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.274Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.275Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.276Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.281Z",
  "value": "id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.332Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.332Z",
  "value": "id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.334Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.335Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.282Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.282Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.282Z",
  "value": "id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.282Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.282Z",
  "value": "id=498   sec_id=1380587 flags=0x0000 ifindex=12  mac=5E:1F:78:42:5F:25 nodemac=2E:FD:E9:26:B7:1D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.199:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.283Z",
  "value": "id=175   sec_id=1383428 flags=0x0000 ifindex=18  mac=96:17:50:E5:AB:F9 nodemac=9A:03:03:23:65:62"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.283Z",
  "value": "id=1474  sec_id=4     flags=0x0000 ifindex=10  mac=C2:CF:6D:CF:78:EA nodemac=8A:C8:DF:2F:B7:4E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.41.0.40:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.284Z",
  "value": "id=24    sec_id=1380587 flags=0x0000 ifindex=14  mac=3A:CC:8E:B3:9B:56 nodemac=7A:4A:0D:A2:C1:79"
}

