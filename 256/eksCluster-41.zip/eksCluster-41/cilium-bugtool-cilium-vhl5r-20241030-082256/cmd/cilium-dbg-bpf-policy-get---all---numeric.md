Endpoint ID: 24
Path: /sys/fs/bpf/tc/globals/cilium_policy_00024

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    297919   2674      0        
Allow    Ingress     1          ANY          NONE         disabled    160693   1847      0        
Allow    Egress      0          ANY          NONE         disabled    103702   1007      0        


Endpoint ID: 175
Path: /sys/fs/bpf/tc/globals/cilium_policy_00175

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11440849   111944    0        
Allow    Ingress     1          ANY          NONE         disabled    10167949   103088    0        
Allow    Egress      0          ANY          NONE         disabled    10739393   107393    0        


Endpoint ID: 358
Path: /sys/fs/bpf/tc/globals/cilium_policy_00358

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 498
Path: /sys/fs/bpf/tc/globals/cilium_policy_00498

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    301833   2710      0        
Allow    Ingress     1          ANY          NONE         disabled    159640   1826      0        
Allow    Egress      0          ANY          NONE         disabled    103997   1009      0        


Endpoint ID: 1474
Path: /sys/fs/bpf/tc/globals/cilium_policy_01474

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1655194   20907     0        
Allow    Ingress     1          ANY          NONE         disabled    24088     280       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


