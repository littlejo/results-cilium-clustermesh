key: 02 00 00 00  value: ac 1f c1 e5 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 9c 5f 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 29 00 cb 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 29 00 cb 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 29 00 28 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f c0 3c 10 94 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 29 00 28 00 35 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 29 00 c7 09 4b 00 00  00 00 00 00
Found 8 elements
