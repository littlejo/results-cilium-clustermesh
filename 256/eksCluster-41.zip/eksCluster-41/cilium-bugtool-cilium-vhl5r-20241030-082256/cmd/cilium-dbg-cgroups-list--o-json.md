[
  {
    "containers": [
      {
        "cgroup-id": 9390,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-8ca0382f6d134a0c252222ef9319988d7cf9b182f76ee56a39f69639c7f540d6.scope"
      },
      {
        "cgroup-id": 9306,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-93674c8529f19f9faadffe4ebf104609e84a9c184f7f2decca998dcf5b026fe0.scope"
      },
      {
        "cgroup-id": 9222,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-d2aace00ced7cd882940dbe760cc86e89dcc3c1aae215c4d219d4d8eb8e3cbdf.scope"
      }
    ],
    "ips": [
      "10.41.0.199"
    ],
    "name": "clustermesh-apiserver-795677c76b-lggtw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5ee04a6_1471_44f2_954f_d0dd1ed699a9.slice/cri-containerd-40c4af2d61308c9e3848742bead3fa1f9f3b24437f8bd5bd3e9a7286cbe3cb2f.scope"
      }
    ],
    "ips": [
      "10.41.0.40"
    ],
    "name": "coredns-cc6ccd49c-84r85",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bed03cb_d58e_47db_98d9_f98c855791d7.slice/cri-containerd-73c2a70ee60eb135152a82158fde5065d8818028b0a6c2d6203c90f35b901e2f.scope"
      }
    ],
    "ips": [
      "10.41.0.203"
    ],
    "name": "coredns-cc6ccd49c-9rj29",
    "namespace": "kube-system"
  }
]

