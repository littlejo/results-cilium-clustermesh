alloc: 180.26MB (189012904 bytes)
total-alloc: 2.40GB (2572392896 bytes)
sys: 341.09MB (357653876 bytes)
lookups: 0
mallocs: 65271836
frees: 63423004
heap-alloc: 180.26MB (189012904 bytes)
heap-sys: 259.35MB (271949824 bytes)
heap-idle: 48.49MB (50847744 bytes)
heap-in-use: 210.86MB (221102080 bytes)
heap-released: 3.65MB (3825664 bytes)
heap-objects: 1848832
stack-in-use: 68.62MB (71958528 bytes)
stack-sys: 68.62MB (71958528 bytes)
stack-mspan-inuse: 3.38MB (3549120 bytes)
stack-mspan-sys: 3.92MB (4112640 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.07MB (1121041 bytes)
gc-sys: 6.10MB (6398672 bytes)
next-gc: when heap-alloc >= 214.25MB (224656680 bytes)
last-gc: 2024-10-30 08:23:02.963384453 +0000 UTC
gc-pause-total: 15.721677ms
gc-pause: 112469
gc-pause-end: 1730276582963384453
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00045867459690808785
enable-gc: true
debug-gc: false
