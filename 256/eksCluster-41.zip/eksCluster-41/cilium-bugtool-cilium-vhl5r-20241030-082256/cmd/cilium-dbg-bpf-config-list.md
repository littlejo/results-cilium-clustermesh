KEY             VALUE
AgentLiveness   2140089626554
UTimeOffset     3379442322265625
