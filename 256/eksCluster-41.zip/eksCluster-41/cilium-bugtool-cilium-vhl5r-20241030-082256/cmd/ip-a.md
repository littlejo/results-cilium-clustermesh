1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:b7:69:3f:b4:49 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.192.60/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3305sec preferred_lft 3305sec
    inet6 fe80::8b7:69ff:fe3f:b449/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:dc:5d:f4:05:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.202.126/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8dc:5dff:fef4:52f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:9e:3d:35:c6:6e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::649e:3dff:fe35:c66e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:c6:9b:a2:6b:9e brd ff:ff:ff:ff:ff:ff
    inet 10.41.0.42/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5cc6:9bff:fea2:6b9e/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 96:e9:c4:61:15:fe brd ff:ff:ff:ff:ff:ff
    inet6 fe80::94e9:c4ff:fe61:15fe/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:c8:df:2f:b7:4e brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88c8:dfff:fe2f:b74e/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca757b4dd1ebf@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:fd:e9:26:b7:1d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::2cfd:e9ff:fe26:b71d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcdaffab53a253@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 7a:4a:0d:a2:c1:79 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::784a:dff:fea2:c179/64 scope link 
       valid_lft forever preferred_lft forever
18: lxca91beca7387a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:03:03:23:65:62 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::9803:3ff:fe23:6562/64 scope link 
       valid_lft forever preferred_lft forever
