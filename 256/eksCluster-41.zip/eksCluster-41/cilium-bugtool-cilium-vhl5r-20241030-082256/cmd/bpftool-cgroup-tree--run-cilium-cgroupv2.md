CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c838aa8_81b3_4e6d_90ea_589850697f07.slice/cri-containerd-249fe458fc765728b0621ece58c8d6a0b929e0a586ff8de9919bbc0f569ed903.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2c838aa8_81b3_4e6d_90ea_589850697f07.slice/cri-containerd-b86cb823411fb184edf2e560c5493dd6749b9c84f7e19f394cea37b23141d2a5.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2dceb2a8_6977_4b05_bcda_736c6bb5529a.slice/cri-containerd-0b0150ee72575a2c38c33136905d54a3d106b7009e19cca27bded3abd0fef3e8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2dceb2a8_6977_4b05_bcda_736c6bb5529a.slice/cri-containerd-0be8c25ebe50d1bdcc6bab4f3519e12be15d8dc561f7eeb42e7dc136fdc29d1f.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5ee04a6_1471_44f2_954f_d0dd1ed699a9.slice/cri-containerd-4b8e17258cf872d18f4f42343c2294aa30086ce040f524032de347cc0fef5c69.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf5ee04a6_1471_44f2_954f_d0dd1ed699a9.slice/cri-containerd-40c4af2d61308c9e3848742bead3fa1f9f3b24437f8bd5bd3e9a7286cbe3cb2f.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bed03cb_d58e_47db_98d9_f98c855791d7.slice/cri-containerd-73c2a70ee60eb135152a82158fde5065d8818028b0a6c2d6203c90f35b901e2f.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7bed03cb_d58e_47db_98d9_f98c855791d7.slice/cri-containerd-f8f6c867fbaafc8c096d8f726f41a25ea4b2edafc019996408fbf84c07f553ee.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod193bc5c3_a74c_4800_8a93_cf7c1e3be7cb.slice/cri-containerd-62de646b0c37ed4dbe8bc44eeb535186b624a1c87bea2b39cdbbc59f0c643eab.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod193bc5c3_a74c_4800_8a93_cf7c1e3be7cb.slice/cri-containerd-d4feba95fb372dd2ade94269555d11c32af3814ab616e528c2d1dc162c40c3e3.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7fc1cdb_a8d8_4f14_804e_bf22e55454d2.slice/cri-containerd-1dd587b0febe6d0e8a5e8ead50bed31924a23b8920fd0a73f14c46073a8596f4.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb7fc1cdb_a8d8_4f14_804e_bf22e55454d2.slice/cri-containerd-ec39e23b4983b04a5c754806ca89c18efbd49a0ef761af09e1cf2e384356dbef.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-8ca0382f6d134a0c252222ef9319988d7cf9b182f76ee56a39f69639c7f540d6.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-d2aace00ced7cd882940dbe760cc86e89dcc3c1aae215c4d219d4d8eb8e3cbdf.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-732163a5116a1559667b2fc51306c6d030e4ebc8c833aba27d0c020395c96a6d.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6c719dfa_0578_41f2_bd17_7de66e44085e.slice/cri-containerd-93674c8529f19f9faadffe4ebf104609e84a9c184f7f2decca998dcf5b026fe0.scope
    657      cgroup_device   multi                                          
