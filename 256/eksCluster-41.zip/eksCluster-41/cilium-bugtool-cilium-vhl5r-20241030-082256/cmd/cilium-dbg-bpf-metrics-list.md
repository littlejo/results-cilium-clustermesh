REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35489     2806028     677    bpf_overlay.c
Interface                 INGRESS     644324    132250360   1132   bpf_host.c
Success                   EGRESS      10768     1706688     86     l3.h
Success                   EGRESS      15276     1198330     1694   bpf_host.c
Success                   EGRESS      283521    35988542    1308   bpf_lxc.c
Success                   EGRESS      34881     2763882     53     encap.h
Success                   INGRESS     322273    36372295    86     l3.h
Success                   INGRESS     353905    39730727    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
