ip-172-31-192-60.eu-west-3.compute.internal
