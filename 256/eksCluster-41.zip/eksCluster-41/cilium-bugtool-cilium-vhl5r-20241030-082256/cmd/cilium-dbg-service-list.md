ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.156.95:443 (active)    
                                         2 => 172.31.193.229:443 (active)   
2    10.100.202.169:443   ClusterIP      1 => 172.31.192.60:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.41.0.203:53 (active)       
                                         2 => 10.41.0.40:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.41.0.203:9153 (active)     
                                         2 => 10.41.0.40:9153 (active)      
5    10.100.99.199:2379   ClusterIP      1 => 10.41.0.199:2379 (active)     
