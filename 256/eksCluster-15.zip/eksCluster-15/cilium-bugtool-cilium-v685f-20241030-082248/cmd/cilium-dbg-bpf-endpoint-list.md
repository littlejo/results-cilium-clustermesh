IP ADDRESS         LOCAL ENDPOINT INFO
10.15.0.203:0      id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71    
172.31.241.253:0   (localhost)                                                                                       
172.31.254.63:0    (localhost)                                                                                       
10.15.0.15:0       id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C   
10.15.0.16:0       (localhost)                                                                                       
10.15.0.254:0      id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34   
10.15.0.60:0       id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1   
