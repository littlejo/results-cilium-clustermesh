ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.199.240:443 (active)    
                                         2 => 172.31.144.231:443 (active)    
2    10.100.236.248:443   ClusterIP      1 => 172.31.241.253:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.15.0.254:53 (active)        
                                         2 => 10.15.0.15:53 (active)         
4    10.100.0.10:9153     ClusterIP      1 => 10.15.0.254:9153 (active)      
                                         2 => 10.15.0.15:9153 (active)       
5    10.100.22.224:2379   ClusterIP      1 => 10.15.0.60:2379 (active)       
