{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:33.341Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.241.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:33.341Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.254.63:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:33.341Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:37.980Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:37.985Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:38.021Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:38.062Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:08.568Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:08.569Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:08.569Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:08.599Z",
  "value": "id=3260  sec_id=539343 flags=0x0000 ifindex=16  mac=42:7B:44:3A:6A:67 nodemac=DE:7F:33:58:72:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:09.568Z",
  "value": "id=3260  sec_id=539343 flags=0x0000 ifindex=16  mac=42:7B:44:3A:6A:67 nodemac=DE:7F:33:58:72:BD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:09.568Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:09.568Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:09.569Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:07.948Z",
  "value": "id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.15.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.463Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.836Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.836Z",
  "value": "id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.836Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.837Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.836Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.837Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.837Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.838Z",
  "value": "id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.837Z",
  "value": "id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.837Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.837Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.838Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.60:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.838Z",
  "value": "id=1901  sec_id=539343 flags=0x0000 ifindex=18  mac=9A:6C:B9:3B:D1:70 nodemac=9A:83:C6:F7:53:A1"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.838Z",
  "value": "id=1215  sec_id=4     flags=0x0000 ifindex=10  mac=7E:D9:DE:DE:07:A5 nodemac=96:E1:35:3A:7D:71"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.254:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.838Z",
  "value": "id=1545  sec_id=537679 flags=0x0000 ifindex=12  mac=82:58:C6:68:82:29 nodemac=02:81:19:11:B3:34"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.15.0.15:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:50.838Z",
  "value": "id=531   sec_id=537679 flags=0x0000 ifindex=14  mac=76:64:89:C7:84:48 nodemac=86:F0:2A:0A:EF:9C"
}

