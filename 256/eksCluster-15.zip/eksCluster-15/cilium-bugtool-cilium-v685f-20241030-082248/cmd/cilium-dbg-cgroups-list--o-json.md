[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod155e0bef_b1a0_4c67_99d5_0c74cfcf363d.slice/cri-containerd-eceda5fc7910f8eff48def0c968537c04680d788ff5f315cd342a684987a8b20.scope"
      }
    ],
    "ips": [
      "10.15.0.254"
    ],
    "name": "coredns-cc6ccd49c-zbbxr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-fc9d2f8c302ffcb905a726bad1dc572ae108455071c8339ef91060138745c091.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-967dbc192a79b796792e5c68b9f99664dc52892a640e5eabda3c1798521ac5fd.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-ddb51739963a6783f0819b398966cbb1130254e51744de36d6c785fa56fac1c9.scope"
      }
    ],
    "ips": [
      "10.15.0.60"
    ],
    "name": "clustermesh-apiserver-69d7684b48-jsggv",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcffe3009_ee25_4eee_85bc_c969154d9088.slice/cri-containerd-7d3014dffb81f545e52efd703183ecb5cef587682566d67cac642559ad07efa5.scope"
      }
    ],
    "ips": [
      "10.15.0.15"
    ],
    "name": "coredns-cc6ccd49c-wrwm2",
    "namespace": "kube-system"
  }
]

