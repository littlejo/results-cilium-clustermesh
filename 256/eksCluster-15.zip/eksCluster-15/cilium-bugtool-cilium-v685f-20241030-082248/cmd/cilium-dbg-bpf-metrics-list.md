REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     33853     2674737     677    bpf_overlay.c
Interface                 INGRESS     618772    129466831   1132   bpf_host.c
Success                   EGRESS      13928     1090101     1694   bpf_host.c
Success                   EGRESS      259484    33036843    1308   bpf_lxc.c
Success                   EGRESS      32761     2594827     53     encap.h
Success                   INGRESS     301897    33888613    86     l3.h
Success                   INGRESS     322473    35517295    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
