CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcffe3009_ee25_4eee_85bc_c969154d9088.slice/cri-containerd-3f9bcf6a6bd5ed86a5cd64c9a01a3675ae80289ddc47d4b77f6b6abd5b320dbf.scope
    592      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcffe3009_ee25_4eee_85bc_c969154d9088.slice/cri-containerd-7d3014dffb81f545e52efd703183ecb5cef587682566d67cac642559ad07efa5.scope
    600      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b7cf266_1f07_4f60_849a_41f4a1bbcd33.slice/cri-containerd-a5e7c5da8cec9d81589a9735282404f3c823c6e49026a114463b50ae59712031.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8b7cf266_1f07_4f60_849a_41f4a1bbcd33.slice/cri-containerd-92a307ef48faeecbf009ce4121e74c4c113b0f86251b1def7e8227ba988c9799.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod155e0bef_b1a0_4c67_99d5_0c74cfcf363d.slice/cri-containerd-eceda5fc7910f8eff48def0c968537c04680d788ff5f315cd342a684987a8b20.scope
    596      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod155e0bef_b1a0_4c67_99d5_0c74cfcf363d.slice/cri-containerd-b5b0d5e43d2a5b5dc2f9f16b46baa260017011505f471aa6f49c87f8f6b231c1.scope
    588      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fd49f68_63b0_41d9_ba1f_0c6dba9f6559.slice/cri-containerd-ffb0e932affada55526a27a8c640e9b2988e799b21ddd43ef0d05f243542e312.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5fd49f68_63b0_41d9_ba1f_0c6dba9f6559.slice/cri-containerd-556e0e5106f97359730c2a5123af780568230776d3581c99a9d8e2c348f767a9.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bcd9b01_f948_4bfb_a444_f577e04f27db.slice/cri-containerd-b0fa4a664a5249cfab66b1b90fc76f03b1ac4d98680ce619ddb81774467db366.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7bcd9b01_f948_4bfb_a444_f577e04f27db.slice/cri-containerd-b5185ad1ddd882e8d7c964162a0c6ec541fc069c72b4abae95c2bc677874bd57.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-fc9d2f8c302ffcb905a726bad1dc572ae108455071c8339ef91060138745c091.scope
    674      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-81cda9c56c116fb4b293a49d4368647b7f9a38f4de41cfb2524a09af1991a7db.scope
    654      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-ddb51739963a6783f0819b398966cbb1130254e51744de36d6c785fa56fac1c9.scope
    678      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6d91821_1d3a_4be9_b92f_5bbbd24310e5.slice/cri-containerd-967dbc192a79b796792e5c68b9f99664dc52892a640e5eabda3c1798521ac5fd.scope
    670      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb89f1094_bffc_4399_8f72_a99e597848d7.slice/cri-containerd-db454239eb8b405d82dda88f2976a5b77b81ea864dde684a5b91ce0bb67313e6.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb89f1094_bffc_4399_8f72_a99e597848d7.slice/cri-containerd-332edbbb1eba309ad20cea2f163a058f6b451a97537539138a6c61ec639e241f.scope
    94       cgroup_device   multi                                          
