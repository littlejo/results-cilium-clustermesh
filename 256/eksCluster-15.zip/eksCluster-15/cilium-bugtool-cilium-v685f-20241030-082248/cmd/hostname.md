ip-172-31-241-253.eu-west-3.compute.internal
