xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 558
ens6(5) clsact/ingress cil_from_netdev-ens6 id 562
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 551
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 539
cilium_host(7) clsact/egress cil_from_host-cilium_host id 543
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 482
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 578
lxcaba5d17865a2(12) clsact/ingress cil_from_container-lxcaba5d17865a2 id 532
lxcc649a6c2754a(14) clsact/ingress cil_from_container-lxcc649a6c2754a id 572
lxcb56cc5ee324c(18) clsact/ingress cil_from_container-lxcb56cc5ee324c id 645

flow_dissector:

netfilter:

