key: 13 02 00 00  value: 3d 02 00 00
key: bf 04 00 00  value: 46 02 00 00
key: 09 06 00 00  value: 10 02 00 00
key: 6d 07 00 00  value: 86 02 00 00
Found 4 elements
