Endpoint ID: 56
Path: /sys/fs/bpf/tc/globals/cilium_policy_00056

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 531
Path: /sys/fs/bpf/tc/globals/cilium_policy_00531

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170314   1961      0        
Allow    Egress      0          ANY          NONE         disabled    22004    246       0        


Endpoint ID: 1215
Path: /sys/fs/bpf/tc/globals/cilium_policy_01215

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1631186   20608     0        
Allow    Ingress     1          ANY          NONE         disabled    24854     289       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1545
Path: /sys/fs/bpf/tc/globals/cilium_policy_01545

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    170863   1964      0        
Allow    Egress      0          ANY          NONE         disabled    20255    226       0        


Endpoint ID: 1901
Path: /sys/fs/bpf/tc/globals/cilium_policy_01901

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11284954   110674    0        
Allow    Ingress     1          ANY          NONE         disabled    9197167    96152     0        
Allow    Egress      0          ANY          NONE         disabled    11161820   110706    0        


