alloc: 149.46MB (156718240 bytes)
total-alloc: 2.21GB (2374047360 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 62629148
frees: 60995795
heap-alloc: 149.46MB (156718240 bytes)
heap-sys: 243.70MB (255533056 bytes)
heap-idle: 65.61MB (68796416 bytes)
heap-in-use: 178.09MB (186736640 bytes)
heap-released: 1.77MB (1859584 bytes)
heap-objects: 1633353
stack-in-use: 64.28MB (67403776 bytes)
stack-sys: 64.28MB (67403776 bytes)
stack-mspan-inuse: 3.03MB (3172160 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.20MB (1258113 bytes)
gc-sys: 6.02MB (6311472 bytes)
next-gc: when heap-alloc >= 213.97MB (224361528 bytes)
last-gc: 2024-10-30 08:22:54.784333456 +0000 UTC
gc-pause-total: 14.189223ms
gc-pause: 124490
gc-pause-end: 1730276574784333456
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00031391956051575264
enable-gc: true
debug-gc: false
