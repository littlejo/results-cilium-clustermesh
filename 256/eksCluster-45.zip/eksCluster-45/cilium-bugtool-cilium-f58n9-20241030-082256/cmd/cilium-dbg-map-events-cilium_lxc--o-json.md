{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.2:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.649Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.218.14:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.649Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.237.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:47.649Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.932Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:51.967Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.000Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.054Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:52.108Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.637Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.638Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.638Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:21.668Z",
  "value": "id=2730  sec_id=1511546 flags=0x0000 ifindex=16  mac=D6:10:45:DF:9A:6C nodemac=CE:7D:59:56:32:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.637Z",
  "value": "id=2730  sec_id=1511546 flags=0x0000 ifindex=16  mac=D6:10:45:DF:9A:6C nodemac=CE:7D:59:56:32:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.638Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.638Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:22.638Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.452Z",
  "value": "id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.45.0.117:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.873Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.663Z",
  "value": "id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.675Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.675Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.675Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.650Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.650Z",
  "value": "id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.651Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.651Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.651Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.651Z",
  "value": "id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.651Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.651Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.22:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.651Z",
  "value": "id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.119:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.652Z",
  "value": "id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.253:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.652Z",
  "value": "id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.45.0.18:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.652Z",
  "value": "id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75"
}

