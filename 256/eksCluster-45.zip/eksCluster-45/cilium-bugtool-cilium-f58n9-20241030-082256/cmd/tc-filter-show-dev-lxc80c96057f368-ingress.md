filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc80c96057f368 direct-action not_in_hw id 536 tag 2ec2246fc53fdbd9 jited 
