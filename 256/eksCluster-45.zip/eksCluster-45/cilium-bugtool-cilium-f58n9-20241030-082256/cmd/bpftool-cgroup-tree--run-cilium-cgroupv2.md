CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a1686a_98ca_4eda_a5a2_ad27bd5760a5.slice/cri-containerd-8863dfb0b60273f1d2ff545bd6cfc3cf4fcecfc32b3687e0037f91301ed766d1.scope
    542      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a1686a_98ca_4eda_a5a2_ad27bd5760a5.slice/cri-containerd-0809cf59e0490f72736b900f53fca114121b5c7fcfbeb598094a23a0657d38eb.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode00aa089_02a5_4027_88d8_3989f74bceda.slice/cri-containerd-31862124d7ce67d33c230d2d0ce8474485f09b0e3b9fe603c6ec956b7efac782.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode00aa089_02a5_4027_88d8_3989f74bceda.slice/cri-containerd-1e91862bf22a429eb8178d4f605be57066cf0bf38ae81125931a547d4e49d409.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75b0bd86_690b_49f3_84f0_513a0bf6fa13.slice/cri-containerd-95ccffdd794c7ad6657a1545ad28f6b4e09bf5a4110cac7007f5d92e3220b62d.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75b0bd86_690b_49f3_84f0_513a0bf6fa13.slice/cri-containerd-068a0989e5ac64872587bd00a2e8260aec3e07b2ae15b8c772302fc2ef65f92e.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35c3e85c_3520_44c6_9c51_b883bc8fc2c7.slice/cri-containerd-6f6923a0e824c9bc653682f1cff060a01091b7a68d30cbbff1ee4e4723df6357.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod35c3e85c_3520_44c6_9c51_b883bc8fc2c7.slice/cri-containerd-865f4db29fab4d0e5176c50c3d3edd9c87878a07afdb1ce20a35e70d09e0dfe0.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd75937e_85e5_4947_bd94_aca3af34ca0b.slice/cri-containerd-b13fb607c23b8b274b8aeae195e539a2412534eb90b1bd8486d4e81cd9534b4a.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbd75937e_85e5_4947_bd94_aca3af34ca0b.slice/cri-containerd-8c0522b70899157055d022b344120d779091618b84238300d03f38e5aa72532a.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-f1e940f595e0ad4a3c95a1fa59845297497eb099d8fba2ddf8c7c9d4abda60d9.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-e7d8c9287d4ed32edc1fb1c0d6d7e30856ddc87d6a8d425bfbb14a6378993c53.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-8bb2ed50a60c08686ab10ff6731b0a6fc27b3c9e3872700fbdad75be94e55143.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-90fde17bbaa4983434fa707365b98c139b34bee790ca38e1a333985f68ddcef5.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod634fd949_6b55_4725_95a8_1762e937ad64.slice/cri-containerd-ea408d78e4186893c88703f280cf5a733b0925daadfc073d9a5bfda74ff84d2c.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod634fd949_6b55_4725_95a8_1762e937ad64.slice/cri-containerd-cbb1993aef25602ab5fabe6993a52e4a2c373f0544ba66f5f7ec49e54d7046f3.scope
    106      cgroup_device   multi                                          
