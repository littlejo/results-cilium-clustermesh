Endpoint ID: 100
Path: /sys/fs/bpf/tc/globals/cilium_policy_00100

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171523   1974      0        
Allow    Egress      0          ANY          NONE         disabled    19931    220       0        


Endpoint ID: 462
Path: /sys/fs/bpf/tc/globals/cilium_policy_00462

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 654
Path: /sys/fs/bpf/tc/globals/cilium_policy_00654

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171238   1975      0        
Allow    Egress      0          ANY          NONE         disabled    19889    222       0        


Endpoint ID: 749
Path: /sys/fs/bpf/tc/globals/cilium_policy_00749

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1658116   20990     0        
Allow    Ingress     1          ANY          NONE         disabled    25990     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 4095
Path: /sys/fs/bpf/tc/globals/cilium_policy_04095

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11608575   115495    0        
Allow    Ingress     1          ANY          NONE         disabled    10122991   106437    0        
Allow    Egress      0          ANY          NONE         disabled    12612162   124413    0        


