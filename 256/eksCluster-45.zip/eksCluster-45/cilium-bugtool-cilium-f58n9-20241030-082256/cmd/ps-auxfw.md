USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         732  0.0  0.1 1616264 8788 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         714  0.0  0.2 1240176 16316 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         731  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         738  0.0  0.2 1240176 16316 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         693  0.0  0.0   2208   780 ?        Ss   08:22   0:00 timeout --signal SIGINT --preserve-status 5 bash -c hubble observe --last 10000 --debug -o jsonpb
root         699  0.0  0.2 1244340 22912 ?       Sl   08:22   0:00  \_ hubble observe --last 10000 --debug -o jsonpb
root         676  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  2.5  4.9 1606080 398880 ?      Ssl  07:53   0:45 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.1 1229744 8016 ?        Sl   07:53   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
