REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36860     2913996     677    bpf_overlay.c
Interface                 INGRESS     646554    132547749   1132   bpf_host.c
Success                   EGRESS      16567     1303713     1694   bpf_host.c
Success                   EGRESS      272321    34265374    1308   bpf_lxc.c
Success                   EGRESS      37107     2935416     53     encap.h
Success                   INGRESS     316910    35607797    86     l3.h
Success                   INGRESS     337855    37262196    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
