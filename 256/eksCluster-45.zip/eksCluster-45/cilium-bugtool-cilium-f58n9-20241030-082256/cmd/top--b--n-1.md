top - 08:22:58 up 35 min,  0 users,  load average: 0.22, 0.21, 0.18
Tasks:   6 total,   2 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 43.3 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4416.8 free,   1251.2 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6377.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 398880  78652 S   6.7   5.0   0:45.53 cilium-+
    405 root      20   0 1229744   8016   3840 S   6.7   0.1   0:01.10 cilium-+
    676 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    714 root      20   0 1240432  16592  11356 S   0.0   0.2   0:00.02 cilium-+
    755 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    760 root      20   0    3132   1000    880 R   0.0   0.0   0:00.00 bpftool
