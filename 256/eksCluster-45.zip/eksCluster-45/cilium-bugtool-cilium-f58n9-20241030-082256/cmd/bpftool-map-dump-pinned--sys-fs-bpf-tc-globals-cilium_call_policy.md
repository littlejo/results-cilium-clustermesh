key: 64 00 00 00  value: 1f 02 00 00
key: 8e 02 00 00  value: 0d 02 00 00
key: ed 02 00 00  value: fe 01 00 00
key: ff 0f 00 00  value: 72 02 00 00
Found 4 elements
