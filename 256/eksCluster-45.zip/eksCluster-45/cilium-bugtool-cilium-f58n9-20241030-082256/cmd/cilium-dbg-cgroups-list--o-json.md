[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75b0bd86_690b_49f3_84f0_513a0bf6fa13.slice/cri-containerd-068a0989e5ac64872587bd00a2e8260aec3e07b2ae15b8c772302fc2ef65f92e.scope"
      }
    ],
    "ips": [
      "10.45.0.22"
    ],
    "name": "coredns-cc6ccd49c-mgqp8",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-8bb2ed50a60c08686ab10ff6731b0a6fc27b3c9e3872700fbdad75be94e55143.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-e7d8c9287d4ed32edc1fb1c0d6d7e30856ddc87d6a8d425bfbb14a6378993c53.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod91f2b79b_4607_476c_8697_3c96e2e1503a.slice/cri-containerd-90fde17bbaa4983434fa707365b98c139b34bee790ca38e1a333985f68ddcef5.scope"
      }
    ],
    "ips": [
      "10.45.0.119"
    ],
    "name": "clustermesh-apiserver-84497c9698-whgpx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod50a1686a_98ca_4eda_a5a2_ad27bd5760a5.slice/cri-containerd-0809cf59e0490f72736b900f53fca114121b5c7fcfbeb598094a23a0657d38eb.scope"
      }
    ],
    "ips": [
      "10.45.0.253"
    ],
    "name": "coredns-cc6ccd49c-n5wcg",
    "namespace": "kube-system"
  }
]

