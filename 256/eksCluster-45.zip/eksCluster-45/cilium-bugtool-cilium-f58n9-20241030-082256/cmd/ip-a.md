1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:40:6c:31:c7:db brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.218.14/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3252sec preferred_lft 3252sec
    inet6 fe80::840:6cff:fe31:c7db/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a9:e2:03:d7:59 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.237.143/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8a9:e2ff:fe03:d759/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:ab:42:35:9c:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a0ab:42ff:fe35:9caf/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:9c:1f:b8:23:b9 brd ff:ff:ff:ff:ff:ff
    inet 10.45.0.2/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::109c:1fff:feb8:23b9/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3a:b8:74:bf:42:c3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::38b8:74ff:febf:42c3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:a4:26:19:05:75 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a4a4:26ff:fe19:575/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcfcbbaf24dcb0@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:20:23:04:56:ff brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f420:23ff:fe04:56ff/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc80c96057f368@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:97:89:76:eb:58 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ac97:89ff:fe76:eb58/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc5aede80441f9@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:90:f7:ab:7d:46 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1c90:f7ff:feab:7d46/64 scope link 
       valid_lft forever preferred_lft forever
