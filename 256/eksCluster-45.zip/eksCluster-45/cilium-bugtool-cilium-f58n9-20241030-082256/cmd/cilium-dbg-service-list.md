ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.177.142:443 (active)   
                                         2 => 172.31.254.100:443 (active)   
2    10.100.185.115:443   ClusterIP      1 => 172.31.218.14:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.45.0.22:53 (active)        
                                         2 => 10.45.0.253:53 (active)       
4    10.100.0.10:9153     ClusterIP      1 => 10.45.0.22:9153 (active)      
                                         2 => 10.45.0.253:9153 (active)     
5    10.100.44.73:2379    ClusterIP      1 => 10.45.0.119:2379 (active)     
