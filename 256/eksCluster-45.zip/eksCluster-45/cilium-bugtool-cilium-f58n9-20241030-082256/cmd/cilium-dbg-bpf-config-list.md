KEY             VALUE
AgentLiveness   2189209940611
UTimeOffset     3379442226562500
