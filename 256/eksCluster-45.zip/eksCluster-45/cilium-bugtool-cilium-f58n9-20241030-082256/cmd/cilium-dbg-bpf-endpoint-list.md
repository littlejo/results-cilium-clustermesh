IP ADDRESS         LOCAL ENDPOINT INFO
10.45.0.22:0       id=654   sec_id=1520062 flags=0x0000 ifindex=12  mac=1A:82:83:D6:5D:F1 nodemac=F6:20:23:04:56:FF   
10.45.0.119:0      id=4095  sec_id=1511546 flags=0x0000 ifindex=18  mac=76:CD:65:01:35:02 nodemac=1E:90:F7:AB:7D:46   
10.45.0.253:0      id=100   sec_id=1520062 flags=0x0000 ifindex=14  mac=06:FD:57:76:30:D5 nodemac=AE:97:89:76:EB:58   
172.31.218.14:0    (localhost)                                                                                        
10.45.0.2:0        (localhost)                                                                                        
10.45.0.18:0       id=749   sec_id=4     flags=0x0000 ifindex=10  mac=12:AA:A1:F1:32:27 nodemac=A6:A4:26:19:05:75     
172.31.237.143:0   (localhost)                                                                                        
