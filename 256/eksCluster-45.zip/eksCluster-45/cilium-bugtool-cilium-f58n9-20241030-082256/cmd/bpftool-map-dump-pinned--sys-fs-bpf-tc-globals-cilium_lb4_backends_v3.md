key: 01 00 00 00  value: ac 1f b1 8e 01 bb 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 2d 00 fd 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 2d 00 fd 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 2d 00 77 09 4b 00 00  00 00 00 00
key: 05 00 00 00  value: ac 1f da 0e 10 94 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f fe 64 01 bb 00 00  00 00 00 00
key: 06 00 00 00  value: 0a 2d 00 16 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: 0a 2d 00 16 23 c1 00 00  00 00 00 00
Found 8 elements
