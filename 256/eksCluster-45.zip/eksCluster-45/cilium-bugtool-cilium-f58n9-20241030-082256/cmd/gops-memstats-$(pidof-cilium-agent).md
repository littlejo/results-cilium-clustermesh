alloc: 137.75MB (144437280 bytes)
total-alloc: 2.33GB (2499842824 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 64333450
frees: 63222380
heap-alloc: 137.75MB (144437280 bytes)
heap-sys: 255.35MB (267755520 bytes)
heap-idle: 73.33MB (76890112 bytes)
heap-in-use: 182.02MB (190865408 bytes)
heap-released: 5.53MB (5799936 bytes)
heap-objects: 1111070
stack-in-use: 64.62MB (67764224 bytes)
stack-sys: 64.62MB (67764224 bytes)
stack-mspan-inuse: 2.83MB (2966560 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 947.26KB (969993 bytes)
gc-sys: 6.02MB (6315640 bytes)
next-gc: when heap-alloc >= 213.08MB (223430760 bytes)
last-gc: 2024-10-30 08:23:09.332580195 +0000 UTC
gc-pause-total: 36.0735ms
gc-pause: 129485
gc-pause-end: 1730276589332580195
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00035999101381726167
enable-gc: true
debug-gc: false
