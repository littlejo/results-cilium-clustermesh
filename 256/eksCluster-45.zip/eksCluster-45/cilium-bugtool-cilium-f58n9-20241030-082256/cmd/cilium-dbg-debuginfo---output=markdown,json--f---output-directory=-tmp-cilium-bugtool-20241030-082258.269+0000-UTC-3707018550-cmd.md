markdown output at /tmp/cilium-bugtool-20241030-082258.269+0000-UTC-3707018550/cmd/cilium-debuginfo-20241030-082328.761+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082258.269+0000-UTC-3707018550/cmd/cilium-debuginfo-20241030-082328.761+0000-UTC.json
