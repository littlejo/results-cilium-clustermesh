Total: 673
TCP:   1875 (estab 440, closed 1416, orphaned 1, timewait 571)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  459       445       14       
INET	  469       451       18       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                   172.31.218.14%ens5:68         0.0.0.0:*    uid:192 ino:67104 sk:1 cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:31960 sk:2 cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15505 sk:3 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:34979      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:31414 sk:4 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:31959 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15506 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::840:6cff:fe31:c7db]%ens5:546           [::]:*    uid:192 ino:15686 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
