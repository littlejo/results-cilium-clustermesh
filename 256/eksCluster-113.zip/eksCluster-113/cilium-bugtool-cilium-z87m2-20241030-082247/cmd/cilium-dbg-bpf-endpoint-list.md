IP ADDRESS         LOCAL ENDPOINT INFO
10.113.0.67:0      (localhost)                                                                                        
172.31.203.47:0    (localhost)                                                                                        
10.113.0.179:0     id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED   
172.31.234.247:0   (localhost)                                                                                        
10.113.0.152:0     id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32   
10.113.0.139:0     id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7   
10.113.0.25:0      id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D     
