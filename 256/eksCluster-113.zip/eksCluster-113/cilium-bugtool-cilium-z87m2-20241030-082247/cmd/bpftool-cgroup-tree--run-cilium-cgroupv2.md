CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62e80c94_da93_4017_ac9e_13684f85a15d.slice/cri-containerd-beeb03c40b8756fd3d22279f0f7eaff3a83f41e9e10ca4edf2f6dfe7e4f1e63d.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62e80c94_da93_4017_ac9e_13684f85a15d.slice/cri-containerd-2c4ef5df0cd5e999ad9e41289f49c4a5c215ce41ad6ab9fc54cd7bd0ee2ff9aa.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d1b875c_8bd5_48c8_ab55_ba985ca05f78.slice/cri-containerd-ca1bba555c5fb97f074fc5ee0685fe71db5c8d5b709d283cae02a9ff06469a8c.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d1b875c_8bd5_48c8_ab55_ba985ca05f78.slice/cri-containerd-5ef0c7d714305a616eb1fbc7cf1f58a79b9350dbe1c139b88b54180681f6d43a.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80203e86_9c63_4175_bc0f_64a6fd1cbd23.slice/cri-containerd-df3ba689b8a718ff27e96fc7b74518a75610a9e14ed7f224ce74090ac2fe9822.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80203e86_9c63_4175_bc0f_64a6fd1cbd23.slice/cri-containerd-0e4d576b789f67e5ee5d86f92f3c4d6088c490a4799955badfbf73e0a475eaa8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5797830_4982_47d1_9033_5f7b756c11d5.slice/cri-containerd-703029031cec577a2c23692e57229c9dad4093e6b9fd7914b4132b0f2a2f2076.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc5797830_4982_47d1_9033_5f7b756c11d5.slice/cri-containerd-3032fec86b24dbd81a036440d83d602f37a293d56ee5dd0fbc2e95db0b969234.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-f08594c0480a6ee1ae61dc661a6cca85bc35893ad3558ad8df4a399668b1e685.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-efeb5abf02afb7bf654c335fa56024f31957f6f7780cbbd9f7c2a9d4646a7fe3.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-c9b6fe291beb656bd7bd0558c605854d43397ec8da10544034d256b74d83bdaa.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-a6ccde2202dd72ea37598a5a35b4baaed565545b1aa0af8c81cc5b1930884def.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod943131d0_9cdd_47a2_94ff_45d3d818e6b4.slice/cri-containerd-5338c44560331d85dac925cc0cf9d39d66cb5ce91367bfc0be3fb577af418624.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod943131d0_9cdd_47a2_94ff_45d3d818e6b4.slice/cri-containerd-e0bfbb560fd04a38cd86889538756970a8c4540d04e818f0c9c1b0200baccc14.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7e0c160_23c2_4ab1_ae7d_b405fa6b5f3d.slice/cri-containerd-c00ec270c949ea61974328b0956b323124feac73aa47ac1e39075ee2bfeab98d.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode7e0c160_23c2_4ab1_ae7d_b405fa6b5f3d.slice/cri-containerd-0ebd8b711a3e7cf4002490e8948484947572b056d673bbf6629a9b67f8995582.scope
    87       cgroup_device   multi                                          
