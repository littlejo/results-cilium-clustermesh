{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.67:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:00.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.203.47:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:00.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.234.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:00.844Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:05.751Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:05.755Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:05.794Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:05.801Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:05.808Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.851Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.852Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.852Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:50.887Z",
  "value": "id=168   sec_id=3751382 flags=0x0000 ifindex=16  mac=DA:43:67:C3:4A:CD nodemac=7E:60:8A:6B:75:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:51.852Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:51.852Z",
  "value": "id=168   sec_id=3751382 flags=0x0000 ifindex=16  mac=DA:43:67:C3:4A:CD nodemac=7E:60:8A:6B:75:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:51.852Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:51.853Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:31.781Z",
  "value": "id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.113.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:42.871Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.586Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.586Z",
  "value": "id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.587Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:45.587Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.587Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.587Z",
  "value": "id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.605Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.605Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.587Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.587Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.588Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.588Z",
  "value": "id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.25:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.588Z",
  "value": "id=745   sec_id=4     flags=0x0000 ifindex=10  mac=82:CC:BA:B2:A4:18 nodemac=42:13:BB:4B:03:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.179:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.589Z",
  "value": "id=648   sec_id=3738097 flags=0x0000 ifindex=12  mac=8A:83:38:75:86:A4 nodemac=4A:41:5D:E7:F3:ED"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.152:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.589Z",
  "value": "id=1537  sec_id=3751382 flags=0x0000 ifindex=18  mac=5A:83:F3:77:1B:E3 nodemac=B6:2A:FA:37:F5:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.113.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.589Z",
  "value": "id=2009  sec_id=3738097 flags=0x0000 ifindex=14  mac=9E:F8:97:2E:58:ED nodemac=22:77:43:7D:BD:F7"
}

