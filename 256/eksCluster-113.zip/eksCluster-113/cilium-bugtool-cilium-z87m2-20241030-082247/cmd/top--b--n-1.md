top - 08:22:48 up 34 min,  0 users,  load average: 0.09, 0.32, 0.26
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 13.8 us, 41.4 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  3.4 st
MiB Mem :   7814.2 total,   4464.1 free,   1202.8 used,   2147.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6426.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    699 root      20   0 1240432  16512  11484 S   6.7   0.2   0:00.03 cilium-+
      1 root      20   0 1606592 396996  79224 S   0.0   5.0   0:50.15 cilium-+
    416 root      20   0 1229744   7940   3836 S   0.0   0.1   0:01.15 cilium-+
    648 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    655 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    673 root      20   0 1228744   4044   3392 S   0.0   0.1   0:00.00 gops
    674 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    725 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    750 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
