USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         699  0.0  0.2 1240432 16512 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         714  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         715  0.0  0.0    352     4 ?        R    08:22   0:00  \_ hostname
root         674  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         673  0.0  0.0 1228744 4044 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         655  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         648  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.1  4.9 1606592 396996 ?      Ssl  07:55   0:50 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.0 1229744 7940 ?        Sl   07:56   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
