[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-f08594c0480a6ee1ae61dc661a6cca85bc35893ad3558ad8df4a399668b1e685.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-efeb5abf02afb7bf654c335fa56024f31957f6f7780cbbd9f7c2a9d4646a7fe3.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9a7d47d8_d4b8_4103_88b5_0019dd4028d5.slice/cri-containerd-c9b6fe291beb656bd7bd0558c605854d43397ec8da10544034d256b74d83bdaa.scope"
      }
    ],
    "ips": [
      "10.113.0.152"
    ],
    "name": "clustermesh-apiserver-5d4dfcb5f8-x84hk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6d1b875c_8bd5_48c8_ab55_ba985ca05f78.slice/cri-containerd-5ef0c7d714305a616eb1fbc7cf1f58a79b9350dbe1c139b88b54180681f6d43a.scope"
      }
    ],
    "ips": [
      "10.113.0.139"
    ],
    "name": "coredns-cc6ccd49c-n9srw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod62e80c94_da93_4017_ac9e_13684f85a15d.slice/cri-containerd-2c4ef5df0cd5e999ad9e41289f49c4a5c215ce41ad6ab9fc54cd7bd0ee2ff9aa.scope"
      }
    ],
    "ips": [
      "10.113.0.179"
    ],
    "name": "coredns-cc6ccd49c-qkwvj",
    "namespace": "kube-system"
  }
]

