KEY             VALUE
AgentLiveness   2112404281644
UTimeOffset     3379442357421875
