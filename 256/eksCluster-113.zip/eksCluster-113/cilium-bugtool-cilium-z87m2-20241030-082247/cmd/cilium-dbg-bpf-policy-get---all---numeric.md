Endpoint ID: 648
Path: /sys/fs/bpf/tc/globals/cilium_policy_00648

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    157283   1805      0        
Allow    Egress      0          ANY          NONE         disabled    21212    237       0        


Endpoint ID: 745
Path: /sys/fs/bpf/tc/globals/cilium_policy_00745

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1638534   20719     0        
Allow    Ingress     1          ANY          NONE         disabled    23306     271       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1537
Path: /sys/fs/bpf/tc/globals/cilium_policy_01537

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11320620   110562    0        
Allow    Ingress     1          ANY          NONE         disabled    9988700    101144    0        
Allow    Egress      0          ANY          NONE         disabled    10526689   104894    0        


Endpoint ID: 2009
Path: /sys/fs/bpf/tc/globals/cilium_policy_02009

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    157943   1815      0        
Allow    Egress      0          ANY          NONE         disabled    18699    206       0        


Endpoint ID: 2070
Path: /sys/fs/bpf/tc/globals/cilium_policy_02070

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


