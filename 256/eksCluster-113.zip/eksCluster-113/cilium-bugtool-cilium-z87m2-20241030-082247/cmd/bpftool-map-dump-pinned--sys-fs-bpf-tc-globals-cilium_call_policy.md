key: 88 02 00 00  value: 14 02 00 00
key: e9 02 00 00  value: 25 02 00 00
key: 01 06 00 00  value: 65 02 00 00
key: d9 07 00 00  value: 1e 02 00 00
Found 4 elements
