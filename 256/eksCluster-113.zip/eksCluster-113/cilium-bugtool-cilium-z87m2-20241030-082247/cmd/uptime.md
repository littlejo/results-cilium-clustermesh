 08:22:48 up 34 min,  0 users,  load average: 0.09, 0.32, 0.26
