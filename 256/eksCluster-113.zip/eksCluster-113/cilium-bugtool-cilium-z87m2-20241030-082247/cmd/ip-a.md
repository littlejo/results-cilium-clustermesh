1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:8f:32:1b:79:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.234.247/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3329sec preferred_lft 3329sec
    inet6 fe80::88f:32ff:fe1b:7991/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:3a:ed:c9:d6:57 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.203.47/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::83a:edff:fec9:d657/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:56:3b:84:29:60 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4c56:3bff:fe84:2960/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:db:31:60:29:3d brd ff:ff:ff:ff:ff:ff
    inet 10.113.0.67/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8db:31ff:fe60:293d/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 3e:c2:34:42:74:00 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3cc2:34ff:fe42:7400/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:13:bb:4b:03:0d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::4013:bbff:fe4b:30d/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc1f2bbc921bfb@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:41:5d:e7:f3:ed brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4841:5dff:fee7:f3ed/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc80ff220d8348@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:77:43:7d:bd:f7 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::2077:43ff:fe7d:bdf7/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc12564762bec0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:2a:fa:37:f5:32 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::b42a:faff:fe37:f532/64 scope link 
       valid_lft forever preferred_lft forever
