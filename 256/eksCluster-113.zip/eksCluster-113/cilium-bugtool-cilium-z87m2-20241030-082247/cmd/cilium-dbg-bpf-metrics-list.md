REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35359     2793558     677    bpf_overlay.c
Interface                 INGRESS     639821    131698962   1132   bpf_host.c
Success                   EGRESS      15317     1201076     1694   bpf_host.c
Success                   EGRESS      276061    35205010    1308   bpf_lxc.c
Success                   EGRESS      34788     2754853     53     encap.h
Success                   INGRESS     315502    35619102    86     l3.h
Success                   INGRESS     336195    37255630    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
