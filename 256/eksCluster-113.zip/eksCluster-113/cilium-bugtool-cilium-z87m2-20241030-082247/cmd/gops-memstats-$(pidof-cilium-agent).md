alloc: 129.63MB (135923008 bytes)
total-alloc: 2.34GB (2509594848 bytes)
sys: 333.27MB (349458788 bytes)
lookups: 0
mallocs: 64200224
frees: 63217222
heap-alloc: 129.63MB (135923008 bytes)
heap-sys: 251.76MB (263987200 bytes)
heap-idle: 60.71MB (63660032 bytes)
heap-in-use: 191.05MB (200327168 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 983002
stack-in-use: 68.22MB (71532544 bytes)
stack-sys: 68.22MB (71532544 bytes)
stack-mspan-inuse: 3.03MB (3181280 bytes)
stack-mspan-sys: 4.00MB (4194240 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.25MB (1308537 bytes)
gc-sys: 6.03MB (6325952 bytes)
next-gc: when heap-alloc >= 215.43MB (225893416 bytes)
last-gc: 2024-10-30 08:23:07.35712632 +0000 UTC
gc-pause-total: 11.764892ms
gc-pause: 83276
gc-pause-end: 1730276587357126320
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0004460915398568708
enable-gc: true
debug-gc: false
