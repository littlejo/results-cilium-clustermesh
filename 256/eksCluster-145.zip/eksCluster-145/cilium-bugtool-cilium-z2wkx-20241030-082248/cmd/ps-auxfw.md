USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         734  0.0  0.1 1616264 8788 ?        Ssl  08:22   0:00 /usr/sbin/runc init
root         717  0.0  0.0 1228744 3592 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         711  0.0  0.2 1240432 16300 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         740  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         741  0.0  0.2 1240432 16300 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         701  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         687  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         681  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.8  4.7 1606080 381664 ?      Ssl  08:00   0:51 cilium-agent --config-dir=/tmp/cilium/config-map
root         415  0.0  0.1 1229744 8112 ?        Sl   08:00   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
