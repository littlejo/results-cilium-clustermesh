KEY             VALUE
AgentLiveness   1988196417816
UTimeOffset     3379442601562500
