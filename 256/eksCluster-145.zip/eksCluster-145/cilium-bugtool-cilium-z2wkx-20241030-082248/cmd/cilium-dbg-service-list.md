ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.248.65:443 (active)     
                                          2 => 172.31.175.121:443 (active)    
2    10.100.221.36:443     ClusterIP      1 => 172.31.238.193:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.145.0.192:53 (active)       
                                          2 => 10.145.0.5:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.145.0.192:9153 (active)     
                                          2 => 10.145.0.5:9153 (active)       
5    10.100.137.156:2379   ClusterIP      1 => 10.145.0.92:2379 (active)      
