top - 08:22:49 up 32 min,  0 users,  load average: 0.19, 0.26, 0.18
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 58.1 us, 22.6 sy,  0.0 ni, 16.1 id,  0.0 wa,  0.0 hi,  3.2 si,  0.0 st
MiB Mem :   7814.2 total,   4480.6 free,   1187.1 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6442.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 387712  78140 S 100.0   4.8   0:51.72 cilium-+
    711 root      20   0 1240432  16508  11036 S   6.7   0.2   0:00.03 cilium-+
    415 root      20   0 1229744   8112   3836 S   0.0   0.1   0:01.14 cilium-+
    681 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    687 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    701 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    717 root      20   0 1228744   3592   2912 S   0.0   0.0   0:00.00 gops
    734 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    756 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    774 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
