xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 513
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 501
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 493
cilium_host(7) clsact/egress cil_from_host-cilium_host id 489
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 485
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 486
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 555
lxc0f0c10102a62(12) clsact/ingress cil_from_container-lxc0f0c10102a62 id 526
lxce6cc975dc03a(14) clsact/ingress cil_from_container-lxce6cc975dc03a id 551
lxc1e3393d4f052(18) clsact/ingress cil_from_container-lxc1e3393d4f052 id 619

flow_dissector:

netfilter:

