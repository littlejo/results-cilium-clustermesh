alloc: 129.96MB (136275008 bytes)
total-alloc: 2.25GB (2419254320 bytes)
sys: 320.77MB (336351588 bytes)
lookups: 0
mallocs: 63493754
frees: 62314506
heap-alloc: 129.96MB (136275008 bytes)
heap-sys: 243.67MB (255508480 bytes)
heap-idle: 76.05MB (79740928 bytes)
heap-in-use: 167.62MB (175767552 bytes)
heap-released: 2.51MB (2629632 bytes)
heap-objects: 1179248
stack-in-use: 64.28MB (67403776 bytes)
stack-sys: 64.28MB (67403776 bytes)
stack-mspan-inuse: 2.78MB (2915520 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1018.60KB (1043049 bytes)
gc-sys: 6.02MB (6317544 bytes)
next-gc: when heap-alloc >= 211.91MB (222200520 bytes)
last-gc: 2024-10-30 08:23:04.607231747 +0000 UTC
gc-pause-total: 17.140683ms
gc-pause: 151756
gc-pause-end: 1730276584607231747
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004408710513577256
enable-gc: true
debug-gc: false
