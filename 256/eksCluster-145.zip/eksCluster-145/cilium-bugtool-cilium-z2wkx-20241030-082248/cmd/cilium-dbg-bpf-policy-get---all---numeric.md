Endpoint ID: 898
Path: /sys/fs/bpf/tc/globals/cilium_policy_00898

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1633736   20643     0        
Allow    Ingress     1          ANY          NONE         disabled    20436     242       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 956
Path: /sys/fs/bpf/tc/globals/cilium_policy_00956

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1466
Path: /sys/fs/bpf/tc/globals/cilium_policy_01466

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11533781   114603    0        
Allow    Ingress     1          ANY          NONE         disabled    9970304    104567    0        
Allow    Egress      0          ANY          NONE         disabled    12516514   123445    0        


Endpoint ID: 1886
Path: /sys/fs/bpf/tc/globals/cilium_policy_01886

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129077   1488      0        
Allow    Egress      0          ANY          NONE         disabled    17911    196       0        


Endpoint ID: 2774
Path: /sys/fs/bpf/tc/globals/cilium_policy_02774

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    129409   1485      0        
Allow    Egress      0          ANY          NONE         disabled    18157    199       0        


