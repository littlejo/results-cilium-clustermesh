[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c8ad27f_445c_4047_a50c_6ec6ccd14938.slice/cri-containerd-ef6b2385eb6cf38cc15de5e3cf2e8d4838e31b54e0b01f4b7731c8043033d96b.scope"
      }
    ],
    "ips": [
      "10.145.0.192"
    ],
    "name": "coredns-cc6ccd49c-hdt9x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-7505672f7fbd3b7c562d2f2828131a47e6bb00adaea2ef4a664238683da8aa8d.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-f211ffb07920fbd2164b28b2042598189d60deba6a41cd3d6c3cfd490e95d86c.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-613327f1afc9d8c5d5374edac20ae236690ab327be3a05ca3db2d1009bc21b2c.scope"
      }
    ],
    "ips": [
      "10.145.0.92"
    ],
    "name": "clustermesh-apiserver-7d47f4b45c-42bpx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc1f7de7_1aed_4110_b905_ead4b2d1491a.slice/cri-containerd-571dc359369c9de4d0f12723aa114c712505305fe88d17b2270ff901ed66847c.scope"
      }
    ],
    "ips": [
      "10.145.0.5"
    ],
    "name": "coredns-cc6ccd49c-mrnrh",
    "namespace": "kube-system"
  }
]

