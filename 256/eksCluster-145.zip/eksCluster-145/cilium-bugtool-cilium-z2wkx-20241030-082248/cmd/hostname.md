ip-172-31-238-193.eu-west-3.compute.internal
