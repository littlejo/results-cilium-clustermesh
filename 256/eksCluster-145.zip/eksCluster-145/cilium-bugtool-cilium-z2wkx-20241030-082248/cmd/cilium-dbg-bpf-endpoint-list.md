IP ADDRESS         LOCAL ENDPOINT INFO
10.145.0.5:0       id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20   
10.145.0.109:0     (localhost)                                                                                        
10.145.0.70:0      id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14     
172.31.225.191:0   (localhost)                                                                                        
10.145.0.192:0     id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC   
172.31.238.193:0   (localhost)                                                                                        
10.145.0.92:0      id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C   
