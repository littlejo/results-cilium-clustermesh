markdown output at /tmp/cilium-bugtool-20241030-082249.388+0000-UTC-3174706888/cmd/cilium-debuginfo-20241030-082320.6+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082249.388+0000-UTC-3174706888/cmd/cilium-debuginfo-20241030-082320.6+0000-UTC.json
