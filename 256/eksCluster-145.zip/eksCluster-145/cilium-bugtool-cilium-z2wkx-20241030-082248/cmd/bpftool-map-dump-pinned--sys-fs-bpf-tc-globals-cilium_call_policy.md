key: 82 03 00 00  value: 1c 02 00 00
key: ba 05 00 00  value: 68 02 00 00
key: 5e 07 00 00  value: 0c 02 00 00
key: d6 0a 00 00  value: 1d 02 00 00
Found 4 elements
