{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.109:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.225.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.238.193:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:44.637Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:49.260Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:49.275Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:49.331Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:49.332Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:49.334Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.080Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.081Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.082Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:53.109Z",
  "value": "id=1243  sec_id=4803202 flags=0x0000 ifindex=16  mac=1A:5A:71:E3:C6:A9 nodemac=72:E3:35:6F:7C:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.080Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.080Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.080Z",
  "value": "id=1243  sec_id=4803202 flags=0x0000 ifindex=16  mac=1A:5A:71:E3:C6:A9 nodemac=72:E3:35:6F:7C:E2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:54.081Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.782Z",
  "value": "id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.145.0.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.824Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.794Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.794Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.795Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:37.795Z",
  "value": "id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.786Z",
  "value": "id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.788Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.789Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:38.789Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.783Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.784Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.784Z",
  "value": "id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:39.784Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.784Z",
  "value": "id=1466  sec_id=4803202 flags=0x0000 ifindex=18  mac=1A:CC:DD:36:39:5B nodemac=9E:13:4D:BF:6D:3C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.784Z",
  "value": "id=898   sec_id=4     flags=0x0000 ifindex=10  mac=26:29:E6:9F:62:57 nodemac=12:6F:5F:BC:5F:14"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.192:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.785Z",
  "value": "id=2774  sec_id=4786910 flags=0x0000 ifindex=14  mac=BE:E2:25:09:96:6E nodemac=BA:0A:39:BF:99:DC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.145.0.5:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.785Z",
  "value": "id=1886  sec_id=4786910 flags=0x0000 ifindex=12  mac=26:CA:D8:09:6D:6B nodemac=0A:ED:C7:78:BF:20"
}

