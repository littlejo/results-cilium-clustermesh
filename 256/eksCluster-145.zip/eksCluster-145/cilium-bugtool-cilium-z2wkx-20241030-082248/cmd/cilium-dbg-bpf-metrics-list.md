REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36524     2890402     677    bpf_overlay.c
Interface                 INGRESS     639773    131781921   1132   bpf_host.c
Success                   EGRESS      16574     1304096     1694   bpf_host.c
Success                   EGRESS      269694    33911415    1308   bpf_lxc.c
Success                   EGRESS      36845     2914927     53     encap.h
Success                   INGRESS     312549    35201189    86     l3.h
Success                   INGRESS     333150    36831541    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
