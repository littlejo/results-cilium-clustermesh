CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ca9d0a9_2af5_42ad_8109_960433c78d58.slice/cri-containerd-990c75c2b0161e437aab20dcd706ad281c7014a7405146a13d44b2af8b033a93.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1ca9d0a9_2af5_42ad_8109_960433c78d58.slice/cri-containerd-2ed471c853746fd68f2fad10360973228357d36377f4296b4a22b1dff528a89c.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c8ad27f_445c_4047_a50c_6ec6ccd14938.slice/cri-containerd-ef6b2385eb6cf38cc15de5e3cf2e8d4838e31b54e0b01f4b7731c8043033d96b.scope
    575      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3c8ad27f_445c_4047_a50c_6ec6ccd14938.slice/cri-containerd-d128ec70e97aeb08e7b933ad98e4f571b26f3091c62a3ff9ff9d3d8ac06198af.scope
    567      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc4e80c6_f9ad_4f17_803f_d6a0c9ec9e74.slice/cri-containerd-b026cbdb29c3120ba81172839695ae0f568e887c483d8682d13ad7f1007d393b.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcc4e80c6_f9ad_4f17_803f_d6a0c9ec9e74.slice/cri-containerd-2e4046ce570f49e54e72226e16524963f9fe39600d8071d69f77e202f3edf581.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc1f7de7_1aed_4110_b905_ead4b2d1491a.slice/cri-containerd-571dc359369c9de4d0f12723aa114c712505305fe88d17b2270ff901ed66847c.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbc1f7de7_1aed_4110_b905_ead4b2d1491a.slice/cri-containerd-2b4d5c5fecc9418ea7fee31d8cbaa06ae3c35726c7823b85d5cb3522106cb442.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe4da6e2_ee3b_4a96_ac49_db1b115ed471.slice/cri-containerd-b6bac70e96b20229bbd3e3010a25539fa0c56f9ca8fd8628172b14f0a7cf4d8d.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe4da6e2_ee3b_4a96_ac49_db1b115ed471.slice/cri-containerd-479c68586f9dea5b07d83d9f9ea95d2e2773910e6c533f25ba967d363c5f2981.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-613327f1afc9d8c5d5374edac20ae236690ab327be3a05ca3db2d1009bc21b2c.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-f211ffb07920fbd2164b28b2042598189d60deba6a41cd3d6c3cfd490e95d86c.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-2a1883012d377f39e4799dc804efa0a00a1e5c8003fa488b68dde431b55a0a12.scope
    629      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod26ff2d15_84de_45e1_b8b7_216773e84e53.slice/cri-containerd-7505672f7fbd3b7c562d2f2828131a47e6bb00adaea2ef4a664238683da8aa8d.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524a4326_f5a0_4b36_b6c5_c06be89b6e89.slice/cri-containerd-1f23399e1a098f73d313d32ecaff79c5236f57ef949ee20e0cb541d20c7b9ef7.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod524a4326_f5a0_4b36_b6c5_c06be89b6e89.slice/cri-containerd-8cbcfeea0c4839143eee83d0898622c16a28417b16af85a1ba537a56c91efad2.scope
    105      cgroup_device   multi                                          
