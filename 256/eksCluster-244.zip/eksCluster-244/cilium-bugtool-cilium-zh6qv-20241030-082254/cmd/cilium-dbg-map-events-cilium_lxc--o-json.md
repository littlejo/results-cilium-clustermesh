{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.533Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.97:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.533Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.186.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.533Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:48.786Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:48.786Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:48.832Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:48.839Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:48.839Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.157Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.159Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.159Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:48.188Z",
  "value": "id=73    sec_id=8035853 flags=0x0000 ifindex=16  mac=4A:B5:D5:A1:D2:EE nodemac=CA:F0:A8:D7:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.158Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.159Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.159Z",
  "value": "id=73    sec_id=8035853 flags=0x0000 ifindex=16  mac=4A:B5:D5:A1:D2:EE nodemac=CA:F0:A8:D7:76:D9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:49.159Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.653Z",
  "value": "id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.244.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.063Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.943Z",
  "value": "id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.944Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.945Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.945Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.149Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.172Z",
  "value": "id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.173Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.174Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.944Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.944Z",
  "value": "id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.945Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:24.945Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.159:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.944Z",
  "value": "id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.204:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.945Z",
  "value": "id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.945Z",
  "value": "id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.244.0.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.946Z",
  "value": "id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26"
}

