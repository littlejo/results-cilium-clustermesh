USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         615  0.0  0.1 1240432 15912 ?       Dsl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         639  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         640  0.0  0.1 1240432 15912 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root           1  3.6  4.7 1605824 380172 ?      Ssl  08:03   0:42 cilium-agent --config-dir=/tmp/cilium/config-map
root         395  0.0  0.0 1229744 7152 ?        Sl   08:03   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
