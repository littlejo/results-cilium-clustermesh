[
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda564af91_df64_43f7_8ef7_34ded8fe7fb0.slice/cri-containerd-96521a06a7f0118ecb78698ee83b33828c49243094b988f875a3c0421270f426.scope"
      }
    ],
    "ips": [
      "10.244.0.159"
    ],
    "name": "coredns-cc6ccd49c-s26q5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod637988f5_d614_4949_8ed2_29bdf57f0cc5.slice/cri-containerd-14c493dfb9adb50f4b678059ac99844b3cf31085eb03629c555b1c6df8a6cdcf.scope"
      }
    ],
    "ips": [
      "10.244.0.204"
    ],
    "name": "coredns-cc6ccd49c-rdz9k",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-6152f7eb009b482a297154b007fb904651ec84bfe1d9e09f5ee36db21c67ecf4.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-05ab38f121ca4041490c9d921ab834d20878873d21979ec92f1b56694777b0ee.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-708b31ebee2d07d1a46f7d498060e42725b58d8ae4363f3b2efab1551d94b244.scope"
      }
    ],
    "ips": [
      "10.244.0.183"
    ],
    "name": "clustermesh-apiserver-6f49c9979f-bb6bk",
    "namespace": "kube-system"
  }
]

