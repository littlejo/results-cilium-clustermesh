KEY             VALUE
AgentLiveness   1694092356653
UTimeOffset     3379443189453125
