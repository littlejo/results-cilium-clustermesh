IP ADDRESS         LOCAL ENDPOINT INFO
172.31.143.97:0    (localhost)                                                                                        
10.244.0.184:0     (localhost)                                                                                        
10.244.0.204:0     id=1082  sec_id=8055674 flags=0x0000 ifindex=14  mac=72:BA:BB:EF:6C:10 nodemac=02:E0:F4:33:C7:22   
172.31.186.238:0   (localhost)                                                                                        
10.244.0.183:0     id=476   sec_id=8035853 flags=0x0000 ifindex=18  mac=96:1A:89:B8:B1:14 nodemac=BE:26:7C:BD:56:D3   
10.244.0.137:0     id=1342  sec_id=4     flags=0x0000 ifindex=10  mac=A2:D5:76:54:89:02 nodemac=22:F9:21:29:E0:26     
10.244.0.159:0     id=348   sec_id=8055674 flags=0x0000 ifindex=12  mac=6E:61:EB:47:7D:3D nodemac=FE:6E:63:83:D3:7F   
