Endpoint ID: 329
Path: /sys/fs/bpf/tc/globals/cilium_policy_00329

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 348
Path: /sys/fs/bpf/tc/globals/cilium_policy_00348

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112774   1294      0        
Allow    Egress      0          ANY          NONE         disabled    15329    165       0        


Endpoint ID: 476
Path: /sys/fs/bpf/tc/globals/cilium_policy_00476

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11629723   116151    0        
Allow    Ingress     1          ANY          NONE         disabled    10295170   108410    0        
Allow    Egress      0          ANY          NONE         disabled    13504623   132765    0        


Endpoint ID: 1082
Path: /sys/fs/bpf/tc/globals/cilium_policy_01082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112444   1289      0        
Allow    Egress      0          ANY          NONE         disabled    15839    170       0        


Endpoint ID: 1342
Path: /sys/fs/bpf/tc/globals/cilium_policy_01342

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1671149   21112     0        
Allow    Ingress     1          ANY          NONE         disabled    17634     208       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


