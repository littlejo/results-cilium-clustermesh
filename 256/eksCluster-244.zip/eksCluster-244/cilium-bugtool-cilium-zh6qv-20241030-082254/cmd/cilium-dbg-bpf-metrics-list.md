REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36993     2927830     677    bpf_overlay.c
Interface                 INGRESS     649441    132873621   1132   bpf_host.c
Success                   EGRESS      16590     1305379     1694   bpf_host.c
Success                   EGRESS      276869    34671905    1308   bpf_lxc.c
Success                   EGRESS      37275     2945904     53     encap.h
Success                   INGRESS     318592    36044760    86     l3.h
Success                   INGRESS     339646    37711257    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
