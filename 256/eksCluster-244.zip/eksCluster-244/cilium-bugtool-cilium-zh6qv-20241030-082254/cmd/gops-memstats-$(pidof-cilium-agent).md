alloc: 185.18MB (194172072 bytes)
total-alloc: 2.26GB (2428266384 bytes)
sys: 321.02MB (336613732 bytes)
lookups: 0
mallocs: 63786859
frees: 61798494
heap-alloc: 185.18MB (194172072 bytes)
heap-sys: 243.27MB (255082496 bytes)
heap-idle: 36.57MB (38346752 bytes)
heap-in-use: 206.70MB (216735744 bytes)
heap-released: 1.98MB (2080768 bytes)
heap-objects: 1988365
stack-in-use: 64.69MB (67829760 bytes)
stack-sys: 64.69MB (67829760 bytes)
stack-mspan-inuse: 3.33MB (3487520 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.27MB (1329265 bytes)
gc-sys: 6.02MB (6307232 bytes)
next-gc: when heap-alloc >= 229.13MB (240261240 bytes)
last-gc: 2024-10-30 08:22:56.718978797 +0000 UTC
gc-pause-total: 23.749833ms
gc-pause: 145342
gc-pause-end: 1730276576718978797
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005979878204943401
enable-gc: true
debug-gc: false
