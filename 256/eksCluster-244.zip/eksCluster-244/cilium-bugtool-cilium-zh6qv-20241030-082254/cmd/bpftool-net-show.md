xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 494
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 487
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 543
lxca2e72518d883(12) clsact/ingress cil_from_container-lxca2e72518d883 id 513
lxcc9531370bc6c(14) clsact/ingress cil_from_container-lxcc9531370bc6c id 550
lxc543c33e260c2(18) clsact/ingress cil_from_container-lxc543c33e260c2 id 612

flow_dissector:

netfilter:

