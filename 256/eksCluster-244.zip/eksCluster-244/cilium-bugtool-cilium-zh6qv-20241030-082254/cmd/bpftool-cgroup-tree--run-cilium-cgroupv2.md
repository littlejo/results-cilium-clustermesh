CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d46af7_5f7d_4fe2_948d_45939a508078.slice/cri-containerd-b56e6069f09e0262d02e52d07beac3c9287df4e74b5c2712294395ab32d32fa8.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d46af7_5f7d_4fe2_948d_45939a508078.slice/cri-containerd-08cb5c419137688533ee7de3f887f31500f0ec4998a986e4006f52ec6cd9dabc.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda564af91_df64_43f7_8ef7_34ded8fe7fb0.slice/cri-containerd-96521a06a7f0118ecb78698ee83b33828c49243094b988f875a3c0421270f426.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda564af91_df64_43f7_8ef7_34ded8fe7fb0.slice/cri-containerd-45e9f1ab532fe54379924ccbf2030c4a6e0a6689f06aa9a15cd5c65e67e3b60b.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod637988f5_d614_4949_8ed2_29bdf57f0cc5.slice/cri-containerd-ced662fcaf017adc3e814192498cbbac9c2cd19004d4229f5d3a37fec10db527.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod637988f5_d614_4949_8ed2_29bdf57f0cc5.slice/cri-containerd-14c493dfb9adb50f4b678059ac99844b3cf31085eb03629c555b1c6df8a6cdcf.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2fc1967c_8d07_4ef4_8a89_9ff1cac412b9.slice/cri-containerd-d4e58b10e4a166cadba1da792af724f8c68da31b071eb2f56998c364615dc1ae.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod2fc1967c_8d07_4ef4_8a89_9ff1cac412b9.slice/cri-containerd-3daf2b8667bb8b0099d83e393f23748ba2b953498b03911a4e5aa2ea582b59fa.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb30ed628_b89d_4d31_95a9_3283caf25486.slice/cri-containerd-082e75bba5edbed49c91a9f063035aed00db3e43f75a5482cd8e0e038aff3a99.scope
    110      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb30ed628_b89d_4d31_95a9_3283caf25486.slice/cri-containerd-f2be63da8efba02f9bf0ac8f1003a50f221c4e48221fd2910b28a2295d2c857b.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-b9d20cddeef0326c568def4d14d89062adf54e36906c5ae01bcfb5af68b5c4c1.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-05ab38f121ca4041490c9d921ab834d20878873d21979ec92f1b56694777b0ee.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-708b31ebee2d07d1a46f7d498060e42725b58d8ae4363f3b2efab1551d94b244.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3add5624_7fd0_4e65_b50b_a67bfc621760.slice/cri-containerd-6152f7eb009b482a297154b007fb904651ec84bfe1d9e09f5ee36db21c67ecf4.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9a85659_3d97_4c11_80a8_be3e164979e6.slice/cri-containerd-52899dbbd3bbf7121de8ee7daff0bed8e77631608d7d1b42a61740138bd76a74.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc9a85659_3d97_4c11_80a8_be3e164979e6.slice/cri-containerd-b51e304b8a730f65abc5032f44b691ce5e4d239d61c497c6b3d8f3dc947dec76.scope
    94       cgroup_device   multi                                          
