1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3a:49:80:8a:2b brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.97/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1946sec preferred_lft 1946sec
    inet6 fe80::43a:49ff:fe80:8a2b/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:81:ac:b0:5e:d1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.186.238/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::481:acff:feb0:5ed1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:96:6f:8c:80:46 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e096:6fff:fe8c:8046/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 2e:54:f2:a6:db:56 brd ff:ff:ff:ff:ff:ff
    inet 10.244.0.184/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::2c54:f2ff:fea6:db56/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 72:83:45:f8:43:7d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::7083:45ff:fef8:437d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:f9:21:29:e0:26 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::20f9:21ff:fe29:e026/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca2e72518d883@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:6e:63:83:d3:7f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc6e:63ff:fe83:d37f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcc9531370bc6c@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:e0:f4:33:c7:22 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::e0:f4ff:fe33:c722/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc543c33e260c2@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:26:7c:bd:56:d3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bc26:7cff:febd:56d3/64 scope link 
       valid_lft forever preferred_lft forever
