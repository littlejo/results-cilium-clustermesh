markdown output at /tmp/cilium-bugtool-20241030-082255.991+0000-UTC-3386913297/cmd/cilium-debuginfo-20241030-082327.525+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082255.991+0000-UTC-3386913297/cmd/cilium-debuginfo-20241030-082327.525+0000-UTC.json
