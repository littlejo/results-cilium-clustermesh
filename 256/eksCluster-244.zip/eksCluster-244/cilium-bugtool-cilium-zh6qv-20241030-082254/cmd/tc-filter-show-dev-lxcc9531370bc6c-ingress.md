filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc9531370bc6c direct-action not_in_hw id 550 tag fbcf9bccba5fc23d jited 
