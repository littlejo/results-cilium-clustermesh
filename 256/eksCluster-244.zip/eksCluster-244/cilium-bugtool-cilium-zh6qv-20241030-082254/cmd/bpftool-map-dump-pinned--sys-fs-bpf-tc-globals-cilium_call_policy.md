key: 5c 01 00 00  value: 16 02 00 00
key: dc 01 00 00  value: 6d 02 00 00
key: 3a 04 00 00  value: 21 02 00 00
key: 3e 05 00 00  value: 27 02 00 00
Found 4 elements
