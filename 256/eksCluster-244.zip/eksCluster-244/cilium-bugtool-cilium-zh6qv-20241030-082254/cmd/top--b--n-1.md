top - 08:22:56 up 27 min,  0 users,  load average: 0.02, 0.15, 0.15
Tasks:  11 total,   1 running,  10 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 43.3 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4473.4 free,   1195.3 used,   2145.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6433.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1605824 381792  78508 S  93.3   4.8   0:42.68 cilium-+
    615 root      20   0 1240432  15912  11164 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229744   7152   2864 S   0.0   0.1   0:01.07 cilium-+
    649 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    657 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    664 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    665 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    688 root      20   0    6576   2412   2088 R   0.0   0.0   0:00.00 top
    703 root      20   0    2208    792    716 S   0.0   0.0   0:00.00 timeout
    717 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    723 root      20   0 1243764  18128  13124 S   0.0   0.2   0:00.00 hubble
