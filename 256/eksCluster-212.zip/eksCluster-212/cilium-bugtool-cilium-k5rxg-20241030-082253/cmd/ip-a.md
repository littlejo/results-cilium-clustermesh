1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:de:a1:d0:14:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.176.70/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1809sec preferred_lft 1809sec
    inet6 fe80::4de:a1ff:fed0:14ad/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:6d:7a:e1:ab:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.149.237/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::46d:7aff:fee1:abc9/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:df:59:e0:58:4e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::e0df:59ff:fee0:584e/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:18:9b:13:6b:28 brd ff:ff:ff:ff:ff:ff
    inet 10.212.0.1/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::cc18:9bff:fe13:6b28/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2e:d5:db:5e:b0:af brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2cd5:dbff:fe5e:b0af/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:29:6e:d9:7e:59 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::5c29:6eff:fed9:7e59/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcbe456e9a10e6@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:53:28:e4:f9:8e brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4053:28ff:fee4:f98e/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcb712c79fbf5d@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:c0:b2:87:de:59 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f4c0:b2ff:fe87:de59/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb978c6bd1af0@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ca:86:3a:85:14:79 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::c886:3aff:fe85:1479/64 scope link 
       valid_lft forever preferred_lft forever
