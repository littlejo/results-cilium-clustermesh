ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.198.95:443 (active)    
                                        2 => 172.31.140.191:443 (active)   
2    10.100.39.55:443    ClusterIP      1 => 172.31.176.70:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.212.0.83:53 (active)       
                                        2 => 10.212.0.113:53 (active)      
4    10.100.0.10:9153    ClusterIP      1 => 10.212.0.83:9153 (active)     
                                        2 => 10.212.0.113:9153 (active)    
5    10.100.5.221:2379   ClusterIP      1 => 10.212.0.28:2379 (active)     
