KEY             VALUE
AgentLiveness   1832440157851
UTimeOffset     3379442916015625
