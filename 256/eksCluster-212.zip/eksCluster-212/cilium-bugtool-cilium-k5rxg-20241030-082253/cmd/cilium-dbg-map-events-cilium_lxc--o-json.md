{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.1:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.874Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.874Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.176.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:02:59.874Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:02.941Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.286Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.287Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.356Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.391Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:06.434Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.846Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.847Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.848Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:35.877Z",
  "value": "id=3763  sec_id=6985061 flags=0x0000 ifindex=16  mac=6A:51:5C:B5:49:77 nodemac=DA:DF:CC:95:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.847Z",
  "value": "id=3763  sec_id=6985061 flags=0x0000 ifindex=16  mac=6A:51:5C:B5:49:77 nodemac=DA:DF:CC:95:8F:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.847Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.847Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:05:36.847Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.720Z",
  "value": "id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.212.0.96:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.289Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.270Z",
  "value": "id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.271Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.271Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:46.271Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.270Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.271Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.271Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:47.271Z",
  "value": "id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.271Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.271Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.271Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:48.271Z",
  "value": "id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.65:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.271Z",
  "value": "id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.28:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.271Z",
  "value": "id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.83:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.272Z",
  "value": "id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.212.0.113:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:49.272Z",
  "value": "id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59"
}

