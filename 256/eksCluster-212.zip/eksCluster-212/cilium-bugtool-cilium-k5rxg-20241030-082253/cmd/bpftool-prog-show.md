35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:52:56+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:52:57+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:53:01+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
57: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:53:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
60: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:53:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
63: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:53:12+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:33+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:33+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:34+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:34+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:37+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:37+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:02:51+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:02:51+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
495: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
498: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
499: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
502: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
503: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 136
504: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 137
505: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 138
506: sched_cls  name tail_handle_ipv4  tag 6e3c7fee97ca092b  gpl
	loaded_at 2024-10-30T08:03:03+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 139
529: sched_cls  name cil_from_container  tag 0215060cc0ec3b3b  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 165
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 167
532: sched_cls  name tail_handle_ipv4  tag 9f6af8a7cfee9c4c  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 168
533: sched_cls  name tail_ipv4_ct_egress  tag 610d3485cb4012c6  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 169
534: sched_cls  name tail_handle_ipv4_cont  tag 642ee6d77fde4d5c  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 170
535: sched_cls  name tail_ipv4_to_endpoint  tag 5dc483e024520843  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 171
536: sched_cls  name tail_handle_arp  tag 0fac4724d97217a5  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 172
537: sched_cls  name tail_ipv4_ct_ingress  tag e916bbd4df3492f8  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 173
538: sched_cls  name handle_policy  tag 301bdc33adfd2447  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 174
539: sched_cls  name __send_drop_notify  tag 238325510fe756a5  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 175
540: sched_cls  name tail_handle_ipv4  tag 51078eda06337092  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,114
	btf_id 177
542: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,114
	btf_id 179
543: sched_cls  name tail_ipv4_ct_ingress  tag 37aaa507a2b644e8  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 180
544: sched_cls  name tail_handle_arp  tag 2209a48c1a8e84b4  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,114
	btf_id 181
545: sched_cls  name tail_ipv4_to_endpoint  tag ec6562aeaaa8873f  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,106,39,114,40,37,38
	btf_id 182
546: sched_cls  name cil_from_container  tag 1f04a18b6a9e3ab8  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 114,76
	btf_id 183
547: sched_cls  name handle_policy  tag a6f07e8cc18fd981  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,114,82,83,113,41,80,106,39,84,75,40,37,38
	btf_id 184
548: sched_cls  name __send_drop_notify  tag 2df7ba23afb9369c  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 185
549: sched_cls  name tail_ipv4_ct_egress  tag 610d3485cb4012c6  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,114,82,83,113,84
	btf_id 186
550: sched_cls  name tail_handle_ipv4_cont  tag cf363e7b1dd8b663  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,106,82,83,39,76,74,77,114,40,37,38,81
	btf_id 187
551: sched_cls  name handle_policy  tag 99698d6a07fb8a08  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,115,82,83,116,41,80,105,39,84,75,40,37,38
	btf_id 189
552: sched_cls  name cil_from_container  tag fd7c2461664774ad  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 115,76
	btf_id 190
553: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 191
554: sched_cls  name tail_ipv4_ct_ingress  tag afa5ff44f1de0921  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,115,82,83,116,84
	btf_id 192
555: sched_cls  name tail_ipv4_to_endpoint  tag 841eaeaf39225639  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,116,41,82,83,80,105,39,115,40,37,38
	btf_id 193
556: sched_cls  name __send_drop_notify  tag bf4305e97e83bad8  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
557: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,115
	btf_id 195
558: sched_cls  name tail_handle_arp  tag 695bc860c97592ba  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,115
	btf_id 196
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
564: sched_cls  name tail_handle_ipv4_cont  tag 67e4d59dcc75d00a  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,116,41,105,82,83,39,76,74,77,115,40,37,38,81
	btf_id 198
565: sched_cls  name tail_handle_ipv4  tag 478c571b78d57972  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,115
	btf_id 199
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:03:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
570: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,120
	btf_id 201
573: sched_cls  name tail_handle_ipv4_from_host  tag abc8a22cf6eb5cb3  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,120
	btf_id 204
574: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,120
	btf_id 205
575: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 206
576: sched_cls  name __send_drop_notify  tag 5734d3d244a48958  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 207
577: sched_cls  name tail_handle_ipv4_from_host  tag abc8a22cf6eb5cb3  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 209
579: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
580: sched_cls  name __send_drop_notify  tag 5734d3d244a48958  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
581: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 213
585: sched_cls  name __send_drop_notify  tag 5734d3d244a48958  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 218
586: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 219
587: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 220
589: sched_cls  name tail_handle_ipv4_from_host  tag abc8a22cf6eb5cb3  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 222
591: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,125,75
	btf_id 225
593: sched_cls  name tail_handle_ipv4_from_host  tag abc8a22cf6eb5cb3  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,125
	btf_id 227
596: sched_cls  name __send_drop_notify  tag 5734d3d244a48958  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
597: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:03:07+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,125
	btf_id 231
637: sched_cls  name cil_from_container  tag 6c76c618214c120c  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 138,76
	btf_id 245
638: sched_cls  name tail_ipv4_ct_ingress  tag ff5584c5b888e741  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 246
639: sched_cls  name __send_drop_notify  tag 43bd02b199fa5878  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 247
640: sched_cls  name tail_handle_ipv4_cont  tag ce6b287b6948b1bf  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,139,41,137,82,83,39,76,74,77,138,40,37,38,81
	btf_id 248
641: sched_cls  name tail_handle_arp  tag b242bbb9852e19fd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,138
	btf_id 249
643: sched_cls  name tail_handle_ipv4  tag 562669e2a88d166f  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,138
	btf_id 251
644: sched_cls  name tail_ipv4_ct_egress  tag fc2f4754a2434203  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,138,82,83,139,84
	btf_id 252
645: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,138
	btf_id 253
646: sched_cls  name handle_policy  tag 6e26e09234ddc93d  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,138,82,83,139,41,80,137,39,84,75,40,37,38
	btf_id 254
647: sched_cls  name tail_ipv4_to_endpoint  tag ba895d56559e2015  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,139,41,82,83,80,137,39,138,40,37,38
	btf_id 255
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:06+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:12:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
