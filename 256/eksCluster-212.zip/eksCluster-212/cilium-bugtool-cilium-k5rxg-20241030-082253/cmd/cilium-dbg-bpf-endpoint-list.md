IP ADDRESS         LOCAL ENDPOINT INFO
10.212.0.65:0      id=2025  sec_id=4     flags=0x0000 ifindex=10  mac=1A:E4:8D:80:97:3A nodemac=5E:29:6E:D9:7E:59     
10.212.0.83:0      id=1638  sec_id=6981095 flags=0x0000 ifindex=12  mac=DA:CA:64:BD:11:A0 nodemac=42:53:28:E4:F9:8E   
10.212.0.113:0     id=142   sec_id=6981095 flags=0x0000 ifindex=14  mac=22:C8:8C:BE:53:E0 nodemac=F6:C0:B2:87:DE:59   
172.31.149.237:0   (localhost)                                                                                        
10.212.0.28:0      id=1099  sec_id=6985061 flags=0x0000 ifindex=18  mac=AA:BB:AA:E7:75:B0 nodemac=CA:86:3A:85:14:79   
10.212.0.1:0       (localhost)                                                                                        
172.31.176.70:0    (localhost)                                                                                        
