top - 08:22:54 up 30 min,  0 users,  load average: 0.08, 0.11, 0.12
Tasks:  11 total,   4 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 50.0 us, 36.7 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  6.7 si,  0.0 st
MiB Mem :   7814.2 total,   4491.0 free,   1177.2 used,   2146.0 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6451.9 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    751 root      20   0 1244340  22884  14524 R  46.7   0.3   0:00.07 hubble
      1 root      20   0 1606144 382468  78584 S  20.0   4.8   0:42.46 cilium-+
    396 root      20   0 1229744   8196   3900 S   0.0   0.1   0:01.12 cilium-+
    670 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    680 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    690 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    694 root      20   0 1240432  15992  10768 S   0.0   0.2   0:00.02 cilium-+
    733 root      20   0    6576   2420   2096 R   0.0   0.0   0:00.00 top
    734 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    767 root      20   0 1616008   7372   5500 R   0.0   0.1   0:00.00 runc:[2+
    770 root      20   0    1748      4      0 R   0.0   0.0   0:00.00 bash
