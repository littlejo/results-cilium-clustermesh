alloc: 106.51MB (111679536 bytes)
total-alloc: 2.17GB (2332958488 bytes)
sys: 320.83MB (336417124 bytes)
lookups: 0
mallocs: 62217094
frees: 61532384
heap-alloc: 106.51MB (111679536 bytes)
heap-sys: 246.50MB (258473984 bytes)
heap-idle: 79.74MB (83615744 bytes)
heap-in-use: 166.76MB (174858240 bytes)
heap-released: 1.98MB (2072576 bytes)
heap-objects: 684710
stack-in-use: 61.50MB (64487424 bytes)
stack-sys: 61.50MB (64487424 bytes)
stack-mspan-inuse: 2.72MB (2855360 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 956.37KB (979321 bytes)
gc-sys: 6.08MB (6379200 bytes)
next-gc: when heap-alloc >= 218.63MB (229254504 bytes)
last-gc: 2024-10-30 08:23:24.641763219 +0000 UTC
gc-pause-total: 9.960967ms
gc-pause: 133680
gc-pause-end: 1730276604641763219
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0005607867102072144
enable-gc: true
debug-gc: false
