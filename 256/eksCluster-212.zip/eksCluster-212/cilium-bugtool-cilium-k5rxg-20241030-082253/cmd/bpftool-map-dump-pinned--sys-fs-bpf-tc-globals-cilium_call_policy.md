key: 8e 00 00 00  value: 23 02 00 00
key: 4b 04 00 00  value: 86 02 00 00
key: 66 06 00 00  value: 1a 02 00 00
key: e9 07 00 00  value: 27 02 00 00
Found 4 elements
