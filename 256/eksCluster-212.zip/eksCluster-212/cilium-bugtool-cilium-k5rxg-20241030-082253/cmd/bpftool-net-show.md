xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 587
ens6(5) clsact/ingress cil_from_netdev-ens6 id 591
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 579
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 575
cilium_host(7) clsact/egress cil_from_host-cilium_host id 574
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 504
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 503
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 552
lxcbe456e9a10e6(12) clsact/ingress cil_from_container-lxcbe456e9a10e6 id 529
lxcb712c79fbf5d(14) clsact/ingress cil_from_container-lxcb712c79fbf5d id 546
lxcb978c6bd1af0(18) clsact/ingress cil_from_container-lxcb978c6bd1af0 id 637

flow_dissector:

netfilter:

