Endpoint ID: 142
Path: /sys/fs/bpf/tc/globals/cilium_policy_00142

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116494   1336      0        
Allow    Egress      0          ANY          NONE         disabled    16466    178       0        


Endpoint ID: 1099
Path: /sys/fs/bpf/tc/globals/cilium_policy_01099

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11350518   111443    0        
Allow    Ingress     1          ANY          NONE         disabled    9280554    97199     0        
Allow    Egress      0          ANY          NONE         disabled    11246624   111685    0        


Endpoint ID: 1638
Path: /sys/fs/bpf/tc/globals/cilium_policy_01638

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    116387   1338      0        
Allow    Egress      0          ANY          NONE         disabled    17668    193       0        


Endpoint ID: 2025
Path: /sys/fs/bpf/tc/globals/cilium_policy_02025

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1645598   20783     0        
Allow    Ingress     1          ANY          NONE         disabled    18320     216       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3332
Path: /sys/fs/bpf/tc/globals/cilium_policy_03332

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


