[
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71a6f9a9_8474_487b_b095_80e48e390cef.slice/cri-containerd-67c8c21d02c8eb20b04079d8a66bea4409fe76ad020e30fa991ba8b785afc4a9.scope"
      }
    ],
    "ips": [
      "10.212.0.113"
    ],
    "name": "coredns-cc6ccd49c-psxlk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-dcee847337c1ba7394352ad765e4cf6e124578842cee966da9ba2923dac6c140.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-5fa1ae1a78ee462ce815496b310ff1fcf3544b7937cef4fce6e1308a4d81969b.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-cfc9cf796ff0447770aba60e163df1ef5ac527131c6195cc222a101bd51953bf.scope"
      }
    ],
    "ips": [
      "10.212.0.28"
    ],
    "name": "clustermesh-apiserver-7f7f8b5d95-vmh2z",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7619,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod826355b3_d285_45bb_912b_dadd904c3d60.slice/cri-containerd-bd06fdb98e1b16ab31c9b753152991b08a53d21bb678b4d0bdf14c6c8946068b.scope"
      }
    ],
    "ips": [
      "10.212.0.83"
    ],
    "name": "coredns-cc6ccd49c-lrr4j",
    "namespace": "kube-system"
  }
]

