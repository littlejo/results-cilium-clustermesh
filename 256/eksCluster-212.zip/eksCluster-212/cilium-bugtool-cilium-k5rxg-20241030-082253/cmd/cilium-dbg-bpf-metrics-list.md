REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35348     2795112     677    bpf_overlay.c
Interface                 INGRESS     624981    128989744   1132   bpf_host.c
Success                   EGRESS      15268     1197722     1694   bpf_host.c
Success                   EGRESS      259415    33006581    1308   bpf_lxc.c
Success                   EGRESS      34756     2754419     53     encap.h
Success                   INGRESS     301979    33883664    86     l3.h
Success                   INGRESS     322710    35525100    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
