 08:22:54 up 30 min,  0 users,  load average: 0.08, 0.11, 0.12
