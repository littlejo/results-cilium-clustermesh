CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod826355b3_d285_45bb_912b_dadd904c3d60.slice/cri-containerd-f4ace134aa4b3c0b4b34a2a2685beabda7acbf4d9a43cd5f0adef0ac5b6bbe6b.scope
    498      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod826355b3_d285_45bb_912b_dadd904c3d60.slice/cri-containerd-bd06fdb98e1b16ab31c9b753152991b08a53d21bb678b4d0bdf14c6c8946068b.scope
    502      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71a6f9a9_8474_487b_b095_80e48e390cef.slice/cri-containerd-67c8c21d02c8eb20b04079d8a66bea4409fe76ad020e30fa991ba8b785afc4a9.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod71a6f9a9_8474_487b_b095_80e48e390cef.slice/cri-containerd-9bca1d60561082da627adabf2566ca12b23a728555574705e7cbb98331f290c2.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d9d723_9337_4f2e_ae66_2e3d255d6ddd.slice/cri-containerd-22822cfc967f959f0313505b27610d1d521179a14f8186616a8ec63cdad521f9.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb9d9d723_9337_4f2e_ae66_2e3d255d6ddd.slice/cri-containerd-a7dab1b7be97e142a29cd12fbc5898f3fe29e27eed8f8f22aabb36eeb106d6d8.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode6ebc176_8c7c_48aa_9078_ed967b0ef6d8.slice/cri-containerd-494526554d591aef82ce62274a58bed0185efbf8f675be3b5777b3e14a13f189.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode6ebc176_8c7c_48aa_9078_ed967b0ef6d8.slice/cri-containerd-d3740eb25a66b76135b09466d3a504f86872a708a006e221a0ffe8056b42f131.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf52609a_d313_4ab9_84ba_58b723389cf5.slice/cri-containerd-4436b7be2cfec1145189e4368649c1852de7c32eec6b1121712edff96fb8ef1b.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbf52609a_d313_4ab9_84ba_58b723389cf5.slice/cri-containerd-29774bdc35468f7c7ec52f8c2680e9b59a63b57378a6ad043adcd999689e0e51.scope
    101      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d0e071a_b9a1_4d59_90b6_422d96ed48f4.slice/cri-containerd-538bfb050a757c68b8a2176f15e52e5074186682cb91d6d4730cc22dd3c263c8.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1d0e071a_b9a1_4d59_90b6_422d96ed48f4.slice/cri-containerd-8db6c60c2a9177559162f2eec9e4b7521cf2c05c6d678e849975997865f48929.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-dcee847337c1ba7394352ad765e4cf6e124578842cee966da9ba2923dac6c140.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-5fa1ae1a78ee462ce815496b310ff1fcf3544b7937cef4fce6e1308a4d81969b.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-7ad38baf3d9a92e55582f92b438e43a71e38b11816bdf190c5421563fa3a3e99.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7e57726a_bbbf_494d_b733_59d014c522ce.slice/cri-containerd-cfc9cf796ff0447770aba60e163df1ef5ac527131c6195cc222a101bd51953bf.scope
    675      cgroup_device   multi                                          
