{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:03.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.143.246:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:03.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.161.158:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:03.927Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:07.262Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:10.962Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:10.968Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:11.025Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:11.059Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:11.106Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.453Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.454Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.454Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:13.487Z",
  "value": "id=3156  sec_id=563197 flags=0x0000 ifindex=16  mac=7A:4A:51:C4:2D:BC nodemac=E6:1A:86:A6:06:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.454Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.454Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.454Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:57:14.455Z",
  "value": "id=3156  sec_id=563197 flags=0x0000 ifindex=16  mac=7A:4A:51:C4:2D:BC nodemac=E6:1A:86:A6:06:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.965Z",
  "value": "id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.16.0.183:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:26.328Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.794Z",
  "value": "id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.796Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.796Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:17.797Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.795Z",
  "value": "id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.796Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.796Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:18.796Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.795Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.796Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.796Z",
  "value": "id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:19.797Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.54:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.796Z",
  "value": "id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.796Z",
  "value": "id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.796Z",
  "value": "id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.16.0.238:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:20.797Z",
  "value": "id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5"
}

