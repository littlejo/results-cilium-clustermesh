 08:22:50 up 39 min,  0 users,  load average: 0.10, 0.15, 0.13
