[
  {
    "containers": [
      {
        "cgroup-id": 9311,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-7941fce8c6f7bb1e83c9eabb21e4b56cfff978cbb47e0c4dcbc4e8fc818810fc.scope"
      },
      {
        "cgroup-id": 9227,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-9b981f03bedbbe0232cefdf88e1087b87364c2bfb0f01a94f34e095f600902e7.scope"
      },
      {
        "cgroup-id": 9395,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-781d2eaea9db56a026427d31417f3320cd39853fd9a7de28983e0434469eff8e.scope"
      }
    ],
    "ips": [
      "10.16.0.171"
    ],
    "name": "clustermesh-apiserver-ddcfcd868-96bcs",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7667,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0546cbf7_e4da_4387_94c0_f1a094a66d41.slice/cri-containerd-3cba453b6a94cec89ae1783630f3eff6cb8ae76250533a327c8ce086795c6255.scope"
      }
    ],
    "ips": [
      "10.16.0.54"
    ],
    "name": "coredns-cc6ccd49c-f5kv5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7835,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40d43f5a_9928_48a3_ba2f_ee0a1a15e848.slice/cri-containerd-c50604a4754730acce33d570ee9bf41eb3b3eaf1a9d8a2e9d70ef77d68a9fac5.scope"
      }
    ],
    "ips": [
      "10.16.0.172"
    ],
    "name": "coredns-cc6ccd49c-lgzrr",
    "namespace": "kube-system"
  }
]

