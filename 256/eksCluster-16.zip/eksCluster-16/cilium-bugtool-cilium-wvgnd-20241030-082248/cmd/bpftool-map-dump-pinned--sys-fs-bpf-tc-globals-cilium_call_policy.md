key: 1f 00 00 00  value: 17 02 00 00
key: 66 03 00 00  value: 7a 02 00 00
key: c2 09 00 00  value: 0d 02 00 00
key: df 0f 00 00  value: 2e 02 00 00
Found 4 elements
