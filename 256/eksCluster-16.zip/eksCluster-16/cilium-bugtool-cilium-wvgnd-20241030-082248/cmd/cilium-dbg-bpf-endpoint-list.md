IP ADDRESS         LOCAL ENDPOINT INFO
10.16.0.172:0      id=4063  sec_id=558731 flags=0x0000 ifindex=14  mac=2A:2E:15:60:15:FA nodemac=DA:ED:23:86:69:78   
10.16.0.142:0      (localhost)                                                                                       
10.16.0.54:0       id=2498  sec_id=558731 flags=0x0000 ifindex=12  mac=F2:5F:78:C1:25:9C nodemac=92:9B:DB:BB:EF:E0   
172.31.161.158:0   (localhost)                                                                                       
10.16.0.238:0      id=31    sec_id=4     flags=0x0000 ifindex=10  mac=2E:CE:95:52:CD:A6 nodemac=02:70:69:FF:3E:D5    
172.31.143.246:0   (localhost)                                                                                       
10.16.0.171:0      id=870   sec_id=563197 flags=0x0000 ifindex=18  mac=A6:C4:A4:1F:BD:B7 nodemac=BE:F0:CC:6D:D4:BB   
