ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.244.138:443 (active)    
                                          2 => 172.31.169.179:443 (active)    
2    10.100.91.110:443     ClusterIP      1 => 172.31.143.246:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.16.0.172:53 (active)        
                                          2 => 10.16.0.54:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.16.0.172:9153 (active)      
                                          2 => 10.16.0.54:9153 (active)       
5    10.100.129.216:2379   ClusterIP      1 => 10.16.0.171:2379 (active)      
