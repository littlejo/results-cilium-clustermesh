CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0546cbf7_e4da_4387_94c0_f1a094a66d41.slice/cri-containerd-e8a6e840788883b5098ac2a9da646503760fe864a55d4216198d7d897957309f.scope
    492      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0546cbf7_e4da_4387_94c0_f1a094a66d41.slice/cri-containerd-3cba453b6a94cec89ae1783630f3eff6cb8ae76250533a327c8ce086795c6255.scope
    496      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40d43f5a_9928_48a3_ba2f_ee0a1a15e848.slice/cri-containerd-0d4f4be7f81aca58d9abd5ab3ec613698af894bba47333139bae6e34c303a89a.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod40d43f5a_9928_48a3_ba2f_ee0a1a15e848.slice/cri-containerd-c50604a4754730acce33d570ee9bf41eb3b3eaf1a9d8a2e9d70ef77d68a9fac5.scope
    563      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0d1d63e_7eb0_4285_baa1_18c4c40b6419.slice/cri-containerd-604341ee3708d00592c0d5e01ef906b305881cd15a29b1e3b3ba4d3b4fb9dfec.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd0d1d63e_7eb0_4285_baa1_18c4c40b6419.slice/cri-containerd-7e0711e00eb11c92072121bebb5321f0f247ac427d4cb5c8542549a08c1eaea2.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd695cb5d_8fff_4a52_8bec_14622674a001.slice/cri-containerd-93c9cab3916dcd394fa88dfb294d3086d289542a99db6ffcda205fb384ed423a.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podd695cb5d_8fff_4a52_8bec_14622674a001.slice/cri-containerd-b551a5516498977e327cf465ae7c0bf79ed5aff60680fecc2d6edae6084a4a3d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-3d75adecf5bae4cc9b9ad8ffd5f9d88694c2c9ea7ba65a08cf549fbf3397b71b.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-7941fce8c6f7bb1e83c9eabb21e4b56cfff978cbb47e0c4dcbc4e8fc818810fc.scope
    665      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-781d2eaea9db56a026427d31417f3320cd39853fd9a7de28983e0434469eff8e.scope
    669      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod768b90ca_e7c0_4913_b5f8_dee6c33d2b63.slice/cri-containerd-9b981f03bedbbe0232cefdf88e1087b87364c2bfb0f01a94f34e095f600902e7.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa24f2b4_20bf_4945_a3ff_ab6f22b23c57.slice/cri-containerd-a5e33ab4bca57ff51d0d62bade5929f85575ca2c7f934914c28cd33f63204d5b.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaa24f2b4_20bf_4945_a3ff_ab6f22b23c57.slice/cri-containerd-bd2e657f2e05a39ad43c27496f7835f4fcca065d40901cd9bd74e8002bdd3c0b.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5c006d5_09c6_4025_9d6e_afdb6ee1a13e.slice/cri-containerd-f95fb25bb6753fdd6611c7ff8bced550fe869c7599c172c6e861d90209826e0e.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb5c006d5_09c6_4025_9d6e_afdb6ee1a13e.slice/cri-containerd-f7abc6736767007308f2ab6e1f81ca09a409a44f05f0e9b9a5338dc1b70f514c.scope
    103      cgroup_device   multi                                          
