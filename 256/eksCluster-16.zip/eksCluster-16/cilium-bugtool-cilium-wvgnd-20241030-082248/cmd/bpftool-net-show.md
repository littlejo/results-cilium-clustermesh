xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 583
ens6(5) clsact/ingress cil_from_netdev-ens6 id 588
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 575
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 565
cilium_host(7) clsact/egress cil_from_host-cilium_host id 570
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 499
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 500
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 542
lxc2c07331820e8(12) clsact/ingress cil_from_container-lxc2c07331820e8 id 530
lxc8c5d3b70931b(14) clsact/ingress cil_from_container-lxc8c5d3b70931b id 546
lxc15419ecd87ed(18) clsact/ingress cil_from_container-lxc15419ecd87ed id 637

flow_dissector:

netfilter:

