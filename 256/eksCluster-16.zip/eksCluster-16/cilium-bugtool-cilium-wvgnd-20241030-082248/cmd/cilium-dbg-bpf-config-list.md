KEY             VALUE
AgentLiveness   2374485896082
UTimeOffset     3379441849609375
