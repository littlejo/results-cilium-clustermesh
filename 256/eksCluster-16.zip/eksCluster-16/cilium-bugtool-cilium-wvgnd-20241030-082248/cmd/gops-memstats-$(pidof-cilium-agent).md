alloc: 200.85MB (210611344 bytes)
total-alloc: 2.28GB (2443411960 bytes)
sys: 337.09MB (353459572 bytes)
lookups: 0
mallocs: 63651843
frees: 61496757
heap-alloc: 200.85MB (210611344 bytes)
heap-sys: 259.17MB (271761408 bytes)
heap-idle: 35.10MB (36806656 bytes)
heap-in-use: 224.07MB (234954752 bytes)
heap-released: 12.79MB (13410304 bytes)
heap-objects: 2155086
stack-in-use: 64.78MB (67928064 bytes)
stack-sys: 64.78MB (67928064 bytes)
stack-mspan-inuse: 3.55MB (3717440 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.18MB (1232993 bytes)
gc-sys: 6.13MB (6427296 bytes)
next-gc: when heap-alloc >= 213.81MB (224191192 bytes)
last-gc: 2024-10-30 08:22:51.793422114 +0000 UTC
gc-pause-total: 8.697897ms
gc-pause: 154784
gc-pause-end: 1730276571793422114
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003680501971825331
enable-gc: true
debug-gc: false
