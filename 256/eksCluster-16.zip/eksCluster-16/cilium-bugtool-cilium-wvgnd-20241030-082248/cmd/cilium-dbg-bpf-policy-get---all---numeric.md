Endpoint ID: 31
Path: /sys/fs/bpf/tc/globals/cilium_policy_00031

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1644748   20795     0        
Allow    Ingress     1          ANY          NONE         disabled    26376     306       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 515
Path: /sys/fs/bpf/tc/globals/cilium_policy_00515

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 870
Path: /sys/fs/bpf/tc/globals/cilium_policy_00870

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11570688   115008    0        
Allow    Ingress     1          ANY          NONE         disabled    9778968    102800    0        
Allow    Egress      0          ANY          NONE         disabled    12469834   122955    0        


Endpoint ID: 2498
Path: /sys/fs/bpf/tc/globals/cilium_policy_02498

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    179935   2075      0        
Allow    Egress      0          ANY          NONE         disabled    21801    246       0        


Endpoint ID: 4063
Path: /sys/fs/bpf/tc/globals/cilium_policy_04063

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    180304   2075      0        
Allow    Egress      0          ANY          NONE         disabled    22590    253       0        


