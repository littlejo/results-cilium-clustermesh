1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:cd:68:4e:bd:45 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.143.246/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3067sec preferred_lft 3067sec
    inet6 fe80::4cd:68ff:fe4e:bd45/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:87:de:d5:87:27 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.161.158/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::487:deff:fed5:8727/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:91:65:81:bf:b6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::a491:65ff:fe81:bfb6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:a0:30:4a:48:20 brd ff:ff:ff:ff:ff:ff
    inet 10.16.0.142/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dca0:30ff:fe4a:4820/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 92:1c:d5:87:cf:5b brd ff:ff:ff:ff:ff:ff
    inet6 fe80::901c:d5ff:fe87:cf5b/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:70:69:ff:3e:d5 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::70:69ff:feff:3ed5/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc2c07331820e8@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:9b:db:bb:ef:e0 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::909b:dbff:febb:efe0/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8c5d3b70931b@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:ed:23:86:69:78 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::d8ed:23ff:fe86:6978/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc15419ecd87ed@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:f0:cc:6d:d4:bb brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::bcf0:ccff:fe6d:d4bb/64 scope link 
       valid_lft forever preferred_lft forever
