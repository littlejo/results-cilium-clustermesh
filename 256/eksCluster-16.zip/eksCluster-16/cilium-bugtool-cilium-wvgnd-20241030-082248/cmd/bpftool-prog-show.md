29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:43:49+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:43:50+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:43:54+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:44:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:44:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:44:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:36+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:39+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:39+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
489: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
492: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
493: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:07+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
496: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:07+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
497: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:52:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
498: sched_cls  name tail_handle_ipv4  tag f17f7fa57a3bda3e  gpl
	loaded_at 2024-10-30T07:52:08+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
499: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:52:08+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 138
500: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:52:08+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 139
523: sched_cls  name tail_ipv4_ct_egress  tag a40717aba62f6dc3  gpl
	loaded_at 2024-10-30T07:52:10+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 165
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:10+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 166
525: sched_cls  name handle_policy  tag 3a316c2fa7d6e6b9  gpl
	loaded_at 2024-10-30T07:52:10+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,112,41,80,91,39,84,75,40,37,38
	btf_id 167
526: sched_cls  name __send_drop_notify  tag 2dec304102331db2  gpl
	loaded_at 2024-10-30T07:52:10+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 168
527: sched_cls  name tail_handle_ipv4  tag 7d812bcf301e4669  gpl
	loaded_at 2024-10-30T07:52:10+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 169
529: sched_cls  name tail_ipv4_ct_ingress  tag 56e3bfb931303703  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,112,84
	btf_id 171
530: sched_cls  name cil_from_container  tag 810f45dd7f2aac96  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 172
531: sched_cls  name tail_handle_ipv4_cont  tag d556c9ce3bddc1ba  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,91,82,83,39,76,74,77,111,40,37,38,81
	btf_id 173
532: sched_cls  name tail_handle_arp  tag b7a36f064fd4e739  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 174
533: sched_cls  name tail_ipv4_to_endpoint  tag 147b56b831c71c92  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,91,39,111,40,37,38
	btf_id 175
534: sched_cls  name tail_handle_arp  tag b1a34f9c62017bca  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 177
535: sched_cls  name handle_policy  tag de788e0844501a99  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,114,41,80,106,39,84,75,40,37,38
	btf_id 178
536: sched_cls  name tail_ipv4_to_endpoint  tag abb0e627a808a27f  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,106,39,113,40,37,38
	btf_id 179
537: sched_cls  name tail_handle_ipv4_cont  tag 09d92db5775d12ed  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,114,41,106,82,83,39,76,74,77,113,40,37,38,81
	btf_id 180
539: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 182
540: sched_cls  name tail_handle_ipv4  tag dcf0d8589ad7cba8  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 183
541: sched_cls  name __send_drop_notify  tag eff14bcf174ad570  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 184
542: sched_cls  name cil_from_container  tag c4ddcb84b222aedb  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 185
543: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 186
544: sched_cls  name tail_ipv4_ct_ingress  tag 610a1a926b2a3860  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 187
545: sched_cls  name __send_drop_notify  tag 2113bd83ef9f44e3  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 189
546: sched_cls  name cil_from_container  tag 89d95ee47143a7e3  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 190
547: sched_cls  name tail_ipv4_to_endpoint  tag f43d2a4a87d55c26  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,105,39,116,40,37,38
	btf_id 191
548: sched_cls  name tail_ipv4_ct_ingress  tag 7178ac991f80dff9  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 192
549: sched_cls  name tail_ipv4_ct_egress  tag a40717aba62f6dc3  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 193
550: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
553: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
554: sched_cls  name tail_handle_ipv4_cont  tag 7ff0585058f238ff  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,105,82,83,39,76,74,77,116,40,37,38,81
	btf_id 194
555: sched_cls  name tail_handle_arp  tag ea4cd71100ce16ec  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 195
556: sched_cls  name tail_handle_ipv4  tag 88886d53bafe25f4  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 196
557: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 197
558: sched_cls  name handle_policy  tag 8bf1c1b58b9fbabb  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,105,39,84,75,40,37,38
	btf_id 198
560: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
563: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:11+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
566: sched_cls  name __send_drop_notify  tag 4ac3dfe0a493204e  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
567: sched_cls  name tail_handle_ipv4_from_host  tag fe3605366f71da8b  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 204
568: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 205
570: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,119
	btf_id 207
571: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 209
575: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 213
576: sched_cls  name __send_drop_notify  tag 4ac3dfe0a493204e  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
577: sched_cls  name tail_handle_ipv4_from_host  tag fe3605366f71da8b  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 215
580: sched_cls  name __send_drop_notify  tag 4ac3dfe0a493204e  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
581: sched_cls  name tail_handle_ipv4_from_host  tag fe3605366f71da8b  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,123
	btf_id 220
582: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,123
	btf_id 221
583: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,123,75
	btf_id 222
585: sched_cls  name __send_drop_notify  tag 4ac3dfe0a493204e  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 225
586: sched_cls  name tail_handle_ipv4_from_host  tag fe3605366f71da8b  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 226
587: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 227
588: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:12+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 228
631: sched_cls  name __send_drop_notify  tag 3c79a42f7e0eb42c  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 245
633: sched_cls  name tail_handle_ipv4_cont  tag 30f467d1b83008e2  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 247
634: sched_cls  name handle_policy  tag 76c217ad1eb085f7  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 248
635: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 249
636: sched_cls  name tail_handle_arp  tag 2bc72d5fae97910f  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 250
637: sched_cls  name cil_from_container  tag d634975c9e3ee2a7  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 251
638: sched_cls  name tail_handle_ipv4  tag ffd1cfad36fc2c07  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 252
639: sched_cls  name tail_ipv4_ct_ingress  tag eae8fbe32a2058c8  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 253
640: sched_cls  name tail_ipv4_ct_egress  tag 81bd2c3ccf4a0b00  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 254
641: sched_cls  name tail_ipv4_to_endpoint  tag 683b9f332e240b25  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 255
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
658: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
661: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
662: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
665: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
666: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
669: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
