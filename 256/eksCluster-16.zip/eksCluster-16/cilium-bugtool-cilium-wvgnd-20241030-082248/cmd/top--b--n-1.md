top - 08:22:50 up 39 min,  0 users,  load average: 0.10, 0.15, 0.13
Tasks:  11 total,   2 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 39.3 us, 42.9 sy,  0.0 ni, 17.9 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4453.2 free,   1214.5 used,   2146.5 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6414.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    745 root      20   0 1243828  19740  13952 S  13.3   0.2   0:00.02 hubble
      1 root      20   0 1606080 382564  78396 S   6.7   4.8   0:57.09 cilium-+
    416 root      20   0 1229744   8008   3836 S   0.0   0.1   0:01.15 cilium-+
    645 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    674 root      20   0 1240432  16504  11292 S   0.0   0.2   0:00.02 cilium-+
    687 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    692 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    719 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    723 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    729 root      20   0    2208    780    700 S   0.0   0.0   0:00.00 timeout
    764 root      20   0 1240432  16504  11292 R   0.0   0.2   0:00.00 cilium-+
