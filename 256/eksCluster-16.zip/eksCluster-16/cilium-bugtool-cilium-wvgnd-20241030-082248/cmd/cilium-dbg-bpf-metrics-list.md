REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35344     2793208     677    bpf_overlay.c
Interface                 INGRESS     636829    131807033   1132   bpf_host.c
Success                   EGRESS      15261     1197344     1694   bpf_host.c
Success                   EGRESS      270857    33923508    1308   bpf_lxc.c
Success                   EGRESS      34865     2759711     53     encap.h
Success                   INGRESS     311947    35135819    86     l3.h
Success                   INGRESS     332682    36775799    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
