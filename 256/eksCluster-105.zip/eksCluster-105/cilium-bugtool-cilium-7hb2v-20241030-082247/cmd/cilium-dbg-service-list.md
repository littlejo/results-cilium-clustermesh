ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.171.125:443 (active)   
                                         2 => 172.31.193.61:443 (active)    
2    10.100.216.166:443   ClusterIP      1 => 172.31.250.86:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.105.0.167:53 (active)      
                                         2 => 10.105.0.216:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.105.0.167:9153 (active)    
                                         2 => 10.105.0.216:9153 (active)    
5    10.100.31.69:2379    ClusterIP      1 => 10.105.0.43:2379 (active)     
