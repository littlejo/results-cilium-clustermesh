xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 505
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 493
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 491
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 556
lxca03022f0ed21(12) clsact/ingress cil_from_container-lxca03022f0ed21 id 523
lxc8fb87b5fab49(14) clsact/ingress cil_from_container-lxc8fb87b5fab49 id 553
lxc150f87570083(18) clsact/ingress cil_from_container-lxc150f87570083 id 621

flow_dissector:

netfilter:

