Endpoint ID: 26
Path: /sys/fs/bpf/tc/globals/cilium_policy_00026

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173851   1986      0        
Allow    Egress      0          ANY          NONE         disabled    20169    225       0        


Endpoint ID: 587
Path: /sys/fs/bpf/tc/globals/cilium_policy_00587

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 647
Path: /sys/fs/bpf/tc/globals/cilium_policy_00647

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    173125   1975      0        
Allow    Egress      0          ANY          NONE         disabled    20922    234       0        


Endpoint ID: 1640
Path: /sys/fs/bpf/tc/globals/cilium_policy_01640

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1627268   20508     0        
Allow    Ingress     1          ANY          NONE         disabled    26317     308       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2689
Path: /sys/fs/bpf/tc/globals/cilium_policy_02689

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11469852   115801    0        
Allow    Ingress     1          ANY          NONE         disabled    11160591   118060    0        
Allow    Egress      0          ANY          NONE         disabled    15150952   147476    0        


