 08:22:48 up 37 min,  0 users,  load average: 0.06, 0.16, 0.17
