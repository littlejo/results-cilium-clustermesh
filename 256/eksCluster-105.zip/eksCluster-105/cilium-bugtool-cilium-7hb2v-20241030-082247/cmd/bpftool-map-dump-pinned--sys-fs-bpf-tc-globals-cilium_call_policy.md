key: 1a 00 00 00  value: 0d 02 00 00
key: 87 02 00 00  value: 1b 02 00 00
key: 68 06 00 00  value: 22 02 00 00
key: 81 0a 00 00  value: 69 02 00 00
Found 4 elements
