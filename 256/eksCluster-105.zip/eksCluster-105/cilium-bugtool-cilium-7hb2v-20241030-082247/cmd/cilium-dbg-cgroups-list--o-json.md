[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-b88f936e08481ebe1874142098df4e60be4c7d8bc0192e1ad2f4ab1d450ae279.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-bab8e750dfaccf9e3c7fa9c5c7f4c55edd34d831cc30ffc901799bd18585d675.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-df24190bcefe2f1e9194ddc7e798073149cc15061bd0143187b2c0a549bf97a7.scope"
      }
    ],
    "ips": [
      "10.105.0.43"
    ],
    "name": "clustermesh-apiserver-7f7cd476f8-8wdhg",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91b37355_971d_4e85_b3e6_f965973b33c3.slice/cri-containerd-0b4ebf605e0067c83d3441788133b4346154d69343decd938dbd3d5fc0427a0c.scope"
      }
    ],
    "ips": [
      "10.105.0.216"
    ],
    "name": "coredns-cc6ccd49c-78h48",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6d412ac_4bee_4bec_a502_dc3944d7a81a.slice/cri-containerd-ac16e40e74f90d57d908eefb10ddf19beec00a800cec355bbebbb1e7e01749b8.scope"
      }
    ],
    "ips": [
      "10.105.0.167"
    ],
    "name": "coredns-cc6ccd49c-x2crz",
    "namespace": "kube-system"
  }
]

