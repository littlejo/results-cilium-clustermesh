KEY             VALUE
AgentLiveness   2277287196985
UTimeOffset     3379442037109375
