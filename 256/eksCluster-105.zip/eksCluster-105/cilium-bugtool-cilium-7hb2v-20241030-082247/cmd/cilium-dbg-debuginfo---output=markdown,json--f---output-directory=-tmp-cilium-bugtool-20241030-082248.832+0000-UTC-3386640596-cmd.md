markdown output at /tmp/cilium-bugtool-20241030-082248.832+0000-UTC-3386640596/cmd/cilium-debuginfo-20241030-082319.981+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.832+0000-UTC-3386640596/cmd/cilium-debuginfo-20241030-082319.981+0000-UTC.json
