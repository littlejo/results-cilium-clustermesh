REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36422     2885938     677    bpf_overlay.c
Interface                 INGRESS     673639    137155375   1132   bpf_host.c
Success                   EGRESS      16588     1304630     1694   bpf_host.c
Success                   EGRESS      291603    35887287    1308   bpf_lxc.c
Success                   EGRESS      37070     2926745     53     encap.h
Success                   INGRESS     335166    38091197    86     l3.h
Success                   INGRESS     355651    39716551    235    trace.h
Unsupported L3 protocol   EGRESS      46        3452        1492   bpf_lxc.c
