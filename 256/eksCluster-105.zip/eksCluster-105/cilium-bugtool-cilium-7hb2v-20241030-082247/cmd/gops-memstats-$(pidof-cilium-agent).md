alloc: 128.64MB (134887584 bytes)
total-alloc: 2.39GB (2566242992 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65651090
frees: 64435170
heap-alloc: 128.64MB (134887584 bytes)
heap-sys: 247.41MB (259432448 bytes)
heap-idle: 74.23MB (77840384 bytes)
heap-in-use: 173.18MB (181592064 bytes)
heap-released: 2.45MB (2572288 bytes)
heap-objects: 1215920
stack-in-use: 64.56MB (67698688 bytes)
stack-sys: 64.56MB (67698688 bytes)
stack-mspan-inuse: 2.94MB (3085120 bytes)
stack-mspan-sys: 3.88MB (4063680 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 963.60KB (986729 bytes)
gc-sys: 6.00MB (6292968 bytes)
next-gc: when heap-alloc >= 214.18MB (224582792 bytes)
last-gc: 2024-10-30 08:23:02.187737683 +0000 UTC
gc-pause-total: 18.04184ms
gc-pause: 117459
gc-pause-end: 1730276582187737683
num-gc: 86
num-forced-gc: 0
gc-cpu-fraction: 0.00033533376087762804
enable-gc: true
debug-gc: false
