{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.110:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.708Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.198.190:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.708Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:40.708Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:45.484Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:45.487Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:45.561Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:45.562Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:45.566Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:04.599Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:04.599Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:04.600Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:04.631Z",
  "value": "id=1968  sec_id=3504220 flags=0x0000 ifindex=16  mac=2A:2B:B9:ED:56:DD nodemac=2A:9D:05:14:F8:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:05.599Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:05.599Z",
  "value": "id=1968  sec_id=3504220 flags=0x0000 ifindex=16  mac=2A:2B:B9:ED:56:DD nodemac=2A:9D:05:14:F8:56"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:05.599Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:05.599Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:29.378Z",
  "value": "id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.105.0.91:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:09:39.605Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.744Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.744Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.744Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:15.745Z",
  "value": "id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.807Z",
  "value": "id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.809Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.809Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:16.810Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.740Z",
  "value": "id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.741Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.741Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.741Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.742Z",
  "value": "id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.743Z",
  "value": "id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.744Z",
  "value": "id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.105.0.216:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:18.744Z",
  "value": "id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE"
}

