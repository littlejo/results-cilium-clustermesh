CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe85d068_b70c_4ef2_b85d_2df1e795fcd5.slice/cri-containerd-2a0008866f97f99c6c5ec039486f5ac736b472265f141bf6310c1c86288f5c48.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfe85d068_b70c_4ef2_b85d_2df1e795fcd5.slice/cri-containerd-ca9c8639cf1018c7800e9008c3ff3a7ffe936e3e4b30d3a337b3134bbe58e495.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91b37355_971d_4e85_b3e6_f965973b33c3.slice/cri-containerd-d0a9913e1d383da101674b9f2e0cbfbed728de697ff1f9522699b6b61a368760.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod91b37355_971d_4e85_b3e6_f965973b33c3.slice/cri-containerd-0b4ebf605e0067c83d3441788133b4346154d69343decd938dbd3d5fc0427a0c.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fa1b3b7_4a9a_4349_beeb_b0d9293dcfdf.slice/cri-containerd-c820eec632484442fd78e93b258e5c009f655bbed6f1b4e86fcbab760dc35cda.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod7fa1b3b7_4a9a_4349_beeb_b0d9293dcfdf.slice/cri-containerd-a39cab842f3ca696415136cc42d06212df9edfed23e883b5e3a5343e2b492c81.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6d412ac_4bee_4bec_a502_dc3944d7a81a.slice/cri-containerd-364b08f71d55bb9a2ad276e2c67b3c64d27854f9679f1e351a0311220c80b22f.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf6d412ac_4bee_4bec_a502_dc3944d7a81a.slice/cri-containerd-ac16e40e74f90d57d908eefb10ddf19beec00a800cec355bbebbb1e7e01749b8.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-df24190bcefe2f1e9194ddc7e798073149cc15061bd0143187b2c0a549bf97a7.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-bf75ae91ede4410d50f3b9a6b3c81c4db285f44c96f0ceba9a63bfd5b2163164.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-b88f936e08481ebe1874142098df4e60be4c7d8bc0192e1ad2f4ab1d450ae279.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1eb9791c_4e55_406b_964f_5a9f8e115416.slice/cri-containerd-bab8e750dfaccf9e3c7fa9c5c7f4c55edd34d831cc30ffc901799bd18585d675.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c3f726d_ec49_4213_bca3_3ca0d801ecf1.slice/cri-containerd-a12adc7c5e4456fa7e33f9196ae3730a4ec70c80f6b905716204c87e9746ab31.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9c3f726d_ec49_4213_bca3_3ca0d801ecf1.slice/cri-containerd-c0afaa676c15da1c01a3b27cc8137efa5c1c55ef15348d7541186bc00c3e84b2.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3caf4bbb_cd68_4ff8_a767_e1a0c017301d.slice/cri-containerd-7e89746a479052f8e745213db79040eca7f84cc9cb9bbf058e307cfa519de681.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3caf4bbb_cd68_4ff8_a767_e1a0c017301d.slice/cri-containerd-19e70833e6c4155ba95ba682352caf6ec44b48b4e3b14a554a0cd2971aa37302.scope
    106      cgroup_device   multi                                          
