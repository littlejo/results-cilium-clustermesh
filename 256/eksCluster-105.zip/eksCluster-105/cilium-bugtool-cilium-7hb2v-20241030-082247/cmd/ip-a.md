1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:a8:87:0f:c8:bf brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.86/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3165sec preferred_lft 3165sec
    inet6 fe80::8a8:87ff:fe0f:c8bf/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c7:8f:af:87:91 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.198.190/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::8c7:8fff:feaf:8791/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 46:27:df:81:4e:0a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::4427:dfff:fe81:4e0a/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:58:c6:69:30:07 brd ff:ff:ff:ff:ff:ff
    inet 10.105.0.110/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::458:c6ff:fe69:3007/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f2:c5:cf:3b:4c:4a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0c5:cfff:fe3b:4c4a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:0d:1e:2c:df:83 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c00d:1eff:fe2c:df83/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca03022f0ed21@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:7e:65:75:5a:b5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::d87e:65ff:fe75:5ab5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc8fb87b5fab49@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:8a:d1:4b:0e:ae brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4c8a:d1ff:fe4b:eae/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc150f87570083@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:6b:98:d6:18:f6 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::1c6b:98ff:fed6:18f6/64 scope link 
       valid_lft forever preferred_lft forever
