IP ADDRESS         LOCAL ENDPOINT INFO
172.31.250.86:0    (localhost)                                                                                        
10.105.0.124:0     id=1640  sec_id=4     flags=0x0000 ifindex=10  mac=2E:9D:14:A2:49:23 nodemac=C2:0D:1E:2C:DF:83     
172.31.198.190:0   (localhost)                                                                                        
10.105.0.43:0      id=2689  sec_id=3504220 flags=0x0000 ifindex=18  mac=7A:D4:80:8A:7C:17 nodemac=1E:6B:98:D6:18:F6   
10.105.0.167:0     id=26    sec_id=3489174 flags=0x0000 ifindex=12  mac=1A:A9:16:92:A3:9C nodemac=DA:7E:65:75:5A:B5   
10.105.0.110:0     (localhost)                                                                                        
10.105.0.216:0     id=647   sec_id=3489174 flags=0x0000 ifindex=14  mac=0A:93:36:B4:3D:7B nodemac=4E:8A:D1:4B:0E:AE   
