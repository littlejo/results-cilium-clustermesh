filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc15a32c7a4d80 direct-action not_in_hw id 532 tag 36b4ac18b49f3fb1 jited 
