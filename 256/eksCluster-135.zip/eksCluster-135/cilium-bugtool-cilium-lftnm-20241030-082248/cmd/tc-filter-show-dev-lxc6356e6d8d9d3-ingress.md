filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6356e6d8d9d3 direct-action not_in_hw id 617 tag dc697d27882241d7 jited 
