Total: 684
TCP:   1847 (estab 434, closed 1394, orphaned 0, timewait 557)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  453       441       12       
INET	  463       447       16       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                  Local Address:Port  Peer Address:PortProcess                                                                       
UNCONN 0      0                           127.0.0.1:40669      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:37126 sk:1 fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                  172.31.197.13%ens5:68         0.0.0.0:*    uid:192 ino:74528 sk:2 cgroup:unreachable:c4e <->                            
UNCONN 0      0                             0.0.0.0:8472       0.0.0.0:*    ino:36162 sk:3 cgroup:/ <->                                                  
UNCONN 0      0                           127.0.0.1:323        0.0.0.0:*    ino:15445 sk:4 cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                [::]:8472          [::]:*    ino:36161 sk:5 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                               [::1]:323           [::]:*    ino:15446 sk:6 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8e7:dff:fe19:d7ef]%ens5:546           [::]:*    uid:192 ino:16411 sk:7 cgroup:unreachable:c4e v6only:1 <->                   
