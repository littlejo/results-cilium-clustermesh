CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf820dc47_98b3_4de1_8291_fa2841371420.slice/cri-containerd-9fadbe8efbeb4167b24fbc10702d51303c50ad66e7ab54bf5c25e4981f8e61af.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf820dc47_98b3_4de1_8291_fa2841371420.slice/cri-containerd-1ab57fb78b2b3ee4059d200effef3dc8ba783184c5a1ad61cffcf874f8a0358b.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb90de120_687e_4da9_9dfb_960e5a8d59a4.slice/cri-containerd-e03143b1feb02e1af9b753a388e6d38dc0bc7388f8383fb55bd8d29f941fb51e.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb90de120_687e_4da9_9dfb_960e5a8d59a4.slice/cri-containerd-db59bb3a9da0958de349f7b9b383c5190981f936baaded7330093b9011c4360b.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod252b7aeb_fba0_40b2_a517_4e8c226e85af.slice/cri-containerd-185a1a4a4e48e7e9ec004c52cb2b3b8ff29bbd0851350437cf16c7c71bac2930.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod252b7aeb_fba0_40b2_a517_4e8c226e85af.slice/cri-containerd-9caefa3c696f47de213ce8634b8e180ff6c15420e375e6617a9a83245c07ad7c.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod16cb24f9_ddad_4960_a7d9_05dcea3b5c6b.slice/cri-containerd-df5e17f4f6aa511acfaece1877eb6a47161c439d42d989d0a20240ad14d8831d.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod16cb24f9_ddad_4960_a7d9_05dcea3b5c6b.slice/cri-containerd-b6085d35d1e59c6e86c6373131e2d9f96428d10d691f773244d26ccdd1abf011.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37ea20d1_f8a4_4f19_89fc_a80a4d216b45.slice/cri-containerd-9309d2a3589de7f2704b6da7f44989144e81165a9f771f8992fc514ae552dc0f.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod37ea20d1_f8a4_4f19_89fc_a80a4d216b45.slice/cri-containerd-a33df7608da719228e53b0d831526bea6bb35a2667c28aa096616c72f6c29893.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe1b10be_b2c7_4861_a7e4_259c2e0e3f44.slice/cri-containerd-4b143e3b15e87250d381a434fe08771eb617bffb9b14ed5f08a1eacdfce1124b.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe1b10be_b2c7_4861_a7e4_259c2e0e3f44.slice/cri-containerd-9e9545d388f5aeb3c141fece6576db4e0d9e267d8e1edb807b2cea51500724e1.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-dfc3cd0f54070b83bf374735ddb69763fae017ae7e8c82541d1a9ec5ced3b914.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-c0ea5786c5bdb4d036248ab2e58a70384971084bd8fefebed0598405c3612791.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-c351c40d16a914e97b80e13f0297654ce3f2f43b32949224fab3c7bc02de770c.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-e4dcdbc474dc399c2a6333483722f4187a676627a26f681e22047bec726207a5.scope
    643      cgroup_device   multi                                          
