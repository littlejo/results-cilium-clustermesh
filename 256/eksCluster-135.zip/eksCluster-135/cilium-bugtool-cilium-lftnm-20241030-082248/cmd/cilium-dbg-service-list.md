ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.159.230:443 (active)   
                                          2 => 172.31.209.47:443 (active)    
2    10.100.93.213:443     ClusterIP      1 => 172.31.197.13:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.135.0.184:53 (active)      
                                          2 => 10.135.0.163:53 (active)      
4    10.100.0.10:9153      ClusterIP      1 => 10.135.0.184:9153 (active)    
                                          2 => 10.135.0.163:9153 (active)    
5    10.100.108.151:2379   ClusterIP      1 => 10.135.0.9:2379 (active)      
