REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36661     2902789     677    bpf_overlay.c
Interface                 INGRESS     649767    133278627   1132   bpf_host.c
Success                   EGRESS      16552     1303284     1694   bpf_host.c
Success                   EGRESS      277214    34376780    1308   bpf_lxc.c
Success                   EGRESS      37081     2930382     53     encap.h
Success                   INGRESS     319358    36167160    86     l3.h
Success                   INGRESS     340118    37810711    235    trace.h
Unsupported L3 protocol   EGRESS      41        3062        1492   bpf_lxc.c
