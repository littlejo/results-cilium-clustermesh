IP ADDRESS         LOCAL ENDPOINT INFO
172.31.221.141:0   (localhost)                                                                                        
10.135.0.163:0     id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22   
172.31.197.13:0    (localhost)                                                                                        
10.135.0.201:0     id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13     
10.135.0.160:0     (localhost)                                                                                        
10.135.0.184:0     id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D   
10.135.0.9:0       id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC   
