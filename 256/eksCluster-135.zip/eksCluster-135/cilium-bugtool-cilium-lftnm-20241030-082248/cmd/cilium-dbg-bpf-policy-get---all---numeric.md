Endpoint ID: 100
Path: /sys/fs/bpf/tc/globals/cilium_policy_00100

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11522086   115434    0        
Allow    Ingress     1          ANY          NONE         disabled    10322616   108840    0        
Allow    Egress      0          ANY          NONE         disabled    13775765   135097    0        


Endpoint ID: 230
Path: /sys/fs/bpf/tc/globals/cilium_policy_00230

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1646830   20802     0        
Allow    Ingress     1          ANY          NONE         disabled    20282     239       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 366
Path: /sys/fs/bpf/tc/globals/cilium_policy_00366

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2255
Path: /sys/fs/bpf/tc/globals/cilium_policy_02255

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131401   1508      0        
Allow    Egress      0          ANY          NONE         disabled    17668    191       0        


Endpoint ID: 2315
Path: /sys/fs/bpf/tc/globals/cilium_policy_02315

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    131467   1509      0        
Allow    Egress      0          ANY          NONE         disabled    17964    196       0        


