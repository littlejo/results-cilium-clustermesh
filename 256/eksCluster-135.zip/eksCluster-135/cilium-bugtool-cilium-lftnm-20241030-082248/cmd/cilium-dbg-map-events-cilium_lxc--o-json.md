{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.160:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.197.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.221.141:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:25.375Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.916Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.922Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.954Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.955Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:29.980Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.476Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.476Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.476Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.507Z",
  "value": "id=1074  sec_id=4459177 flags=0x0000 ifindex=16  mac=E2:A9:AD:3E:B7:AE nodemac=CA:A8:04:3E:AF:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.507Z",
  "value": "id=1074  sec_id=4459177 flags=0x0000 ifindex=16  mac=E2:A9:AD:3E:B7:AE nodemac=CA:A8:04:3E:AF:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.477Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.477Z",
  "value": "id=1074  sec_id=4459177 flags=0x0000 ifindex=16  mac=E2:A9:AD:3E:B7:AE nodemac=CA:A8:04:3E:AF:FD"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.477Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:37.477Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.291Z",
  "value": "id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.135.0.124:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.679Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.481Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.482Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.482Z",
  "value": "id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.482Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.482Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.483Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.483Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:21.484Z",
  "value": "id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.482Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.482Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.482Z",
  "value": "id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:22.483Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.163:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.483Z",
  "value": "id=2255  sec_id=4477556 flags=0x0000 ifindex=14  mac=E2:3D:11:96:F8:A1 nodemac=FE:41:89:E3:0A:22"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.483Z",
  "value": "id=100   sec_id=4459177 flags=0x0000 ifindex=18  mac=BA:0D:62:2F:1A:42 nodemac=42:A1:5C:76:11:BC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.201:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.484Z",
  "value": "id=230   sec_id=4     flags=0x0000 ifindex=10  mac=CE:24:06:F9:E8:5F nodemac=AE:71:02:8E:B4:13"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.135.0.184:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:23.484Z",
  "value": "id=2315  sec_id=4477556 flags=0x0000 ifindex=12  mac=E2:F8:AB:0D:18:A9 nodemac=66:58:D2:4B:59:4D"
}

