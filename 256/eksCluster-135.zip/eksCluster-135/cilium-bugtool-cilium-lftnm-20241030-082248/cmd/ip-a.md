1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:e7:0d:19:d7:ef brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.197.13/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3441sec preferred_lft 3441sec
    inet6 fe80::8e7:dff:fe19:d7ef/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:00:b7:6d:b0:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.221.141/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::800:b7ff:fe6d:b02f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:8a:50:af:c2:d8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::5c8a:50ff:feaf:c2d8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:b8:31:cb:6d:a7 brd ff:ff:ff:ff:ff:ff
    inet 10.135.0.160/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::90b8:31ff:fecb:6da7/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:6c:f0:56:43:82 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f46c:f0ff:fe56:4382/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:71:02:8e:b4:13 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ac71:2ff:fe8e:b413/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc15a32c7a4d80@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:58:d2:4b:59:4d brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6458:d2ff:fe4b:594d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd85b5066c96e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fe:41:89:e3:0a:22 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::fc41:89ff:fee3:a22/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6356e6d8d9d3@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:a1:5c:76:11:bc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::40a1:5cff:fe76:11bc/64 scope link 
       valid_lft forever preferred_lft forever
