alloc: 205.42MB (215397272 bytes)
total-alloc: 2.28GB (2447650496 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63996274
frees: 61642755
heap-alloc: 205.42MB (215397272 bytes)
heap-sys: 251.59MB (263815168 bytes)
heap-idle: 25.16MB (26378240 bytes)
heap-in-use: 226.44MB (237436928 bytes)
heap-released: 1.87MB (1957888 bytes)
heap-objects: 2353519
stack-in-use: 60.00MB (62914560 bytes)
stack-sys: 60.00MB (62914560 bytes)
stack-mspan-inuse: 3.58MB (3757280 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1012.66KB (1036961 bytes)
gc-sys: 6.38MB (6686184 bytes)
next-gc: when heap-alloc >= 222.18MB (232970120 bytes)
last-gc: 2024-10-30 08:23:19.385920682 +0000 UTC
gc-pause-total: 15.621456ms
gc-pause: 7826987
gc-pause-end: 1730276599385920682
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.000543706703271959
enable-gc: true
debug-gc: false
