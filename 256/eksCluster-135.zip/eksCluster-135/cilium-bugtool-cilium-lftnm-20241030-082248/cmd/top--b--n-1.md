top - 08:22:49 up 32 min,  0 users,  load average: 0.30, 0.39, 0.27
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.7 us, 25.0 sy,  0.0 ni, 64.3 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4485.7 free,   1181.7 used,   2146.8 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6447.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    667 root      20   0 1240432  15640  11100 S  13.3   0.2   0:00.03 cilium-+
      1 root      20   0 1606080 378408  76836 S   0.0   4.7   0:53.40 cilium-+
    393 root      20   0 1229744   8016   3836 S   0.0   0.1   0:01.13 cilium-+
    617 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    627 root      20   0 1228744   3716   3040 S   0.0   0.0   0:00.00 gops
    637 root      20   0 1229000   3596   2912 S   0.0   0.0   0:00.00 gops
    643 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    644 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    699 root      20   0    6576   2408   2084 R   0.0   0.0   0:00.00 top
    717 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
