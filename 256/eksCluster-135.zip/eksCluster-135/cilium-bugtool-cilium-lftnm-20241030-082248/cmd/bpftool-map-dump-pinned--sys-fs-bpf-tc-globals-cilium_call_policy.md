key: 64 00 00 00  value: 61 02 00 00
key: e6 00 00 00  value: 19 02 00 00
key: cf 08 00 00  value: 23 02 00 00
key: 0b 09 00 00  value: 0c 02 00 00
Found 4 elements
