 08:22:49 up 32 min,  0 users,  load average: 0.30, 0.39, 0.27
