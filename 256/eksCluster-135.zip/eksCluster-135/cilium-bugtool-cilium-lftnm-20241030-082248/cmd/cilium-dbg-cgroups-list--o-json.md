[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb90de120_687e_4da9_9dfb_960e5a8d59a4.slice/cri-containerd-db59bb3a9da0958de349f7b9b383c5190981f936baaded7330093b9011c4360b.scope"
      }
    ],
    "ips": [
      "10.135.0.184"
    ],
    "name": "coredns-cc6ccd49c-9m5zx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod16cb24f9_ddad_4960_a7d9_05dcea3b5c6b.slice/cri-containerd-b6085d35d1e59c6e86c6373131e2d9f96428d10d691f773244d26ccdd1abf011.scope"
      }
    ],
    "ips": [
      "10.135.0.163"
    ],
    "name": "coredns-cc6ccd49c-rx7gl",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-dfc3cd0f54070b83bf374735ddb69763fae017ae7e8c82541d1a9ec5ced3b914.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-c0ea5786c5bdb4d036248ab2e58a70384971084bd8fefebed0598405c3612791.scope"
      },
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddd140c75_559e_4556_ba6d_f9b99815f806.slice/cri-containerd-e4dcdbc474dc399c2a6333483722f4187a676627a26f681e22047bec726207a5.scope"
      }
    ],
    "ips": [
      "10.135.0.9"
    ],
    "name": "clustermesh-apiserver-8b449fd7f-7rxtr",
    "namespace": "kube-system"
  }
]

