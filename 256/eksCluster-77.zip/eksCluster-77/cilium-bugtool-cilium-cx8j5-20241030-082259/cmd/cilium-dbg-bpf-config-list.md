KEY             VALUE
AgentLiveness   2107484002973
UTimeOffset     3379442390625000
