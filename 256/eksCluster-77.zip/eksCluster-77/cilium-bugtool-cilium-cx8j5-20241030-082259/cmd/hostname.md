ip-172-31-247-137.eu-west-3.compute.internal
