alloc: 174.65MB (183130016 bytes)
total-alloc: 2.35GB (2523047352 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 65095121
frees: 63086642
heap-alloc: 174.65MB (183130016 bytes)
heap-sys: 251.61MB (263831552 bytes)
heap-idle: 52.91MB (55484416 bytes)
heap-in-use: 198.70MB (208347136 bytes)
heap-released: 7.95MB (8339456 bytes)
heap-objects: 2008479
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 3.35MB (3511680 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.03MB (1077025 bytes)
gc-sys: 6.01MB (6301112 bytes)
next-gc: when heap-alloc >= 218.58MB (229202936 bytes)
last-gc: 2024-10-30 08:23:01.11309906 +0000 UTC
gc-pause-total: 20.675528ms
gc-pause: 494061
gc-pause-end: 1730276581113099060
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.00045735006308144944
enable-gc: true
debug-gc: false
