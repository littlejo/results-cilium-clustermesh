[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-aa8601ac0cf69caab5cc09303b6dcb1173a437e5b2034c8db5848bf9e15c4153.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-a649ee9c96ea39947e080352da5d041feb09caf712aab6e859fb37eb66f41686.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-7b35d0d178d5864b4e44434ee5f550ed72f556583f20d292a9063c9625dbd47b.scope"
      }
    ],
    "ips": [
      "10.77.0.232"
    ],
    "name": "clustermesh-apiserver-6d6ff75cb9-ttfr7",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode096052b_7e74_4b98_b1a3_4a922c199061.slice/cri-containerd-d49941a7c7e852b169d37c08559a92a86f08e50cd0be9495df68e7224e30a5ab.scope"
      }
    ],
    "ips": [
      "10.77.0.188"
    ],
    "name": "coredns-cc6ccd49c-2x6hc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1ae04b0_f1fa_436a_af10_71720e2ae3a8.slice/cri-containerd-a0dabe5e84ad8df0ed634352e2403f2ab0a5b86ef64275be6a0073d9fa7de575.scope"
      }
    ],
    "ips": [
      "10.77.0.224"
    ],
    "name": "coredns-cc6ccd49c-lxgmn",
    "namespace": "kube-system"
  }
]

