CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode439ee80_a06b_4edd_afe5_966da2151816.slice/cri-containerd-6df566d554ced7446ec2abdd5b57c6e136aa227b407edd4c03b8454736a50565.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode439ee80_a06b_4edd_afe5_966da2151816.slice/cri-containerd-a23ea1b259383808c7e0c6a2fb7e14c0c86185ca90b28f21fc1c3d61b4017248.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa87c529_269f_47d1_bb05_7b4b48b6138e.slice/cri-containerd-bdef818c843d8b4e7a857f0a53bb225c28b7e1826d68edcfc7f6e824b9be24e0.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaa87c529_269f_47d1_bb05_7b4b48b6138e.slice/cri-containerd-cb44c19200d391bed7b37f0fecfe370af38747a0d0c2d32eaa3de9d00b4f5a05.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1ae04b0_f1fa_436a_af10_71720e2ae3a8.slice/cri-containerd-d84793e0e83b437be6ddeb764c6dc8ddd275b34582b2a35cc57b405f48595a0f.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda1ae04b0_f1fa_436a_af10_71720e2ae3a8.slice/cri-containerd-a0dabe5e84ad8df0ed634352e2403f2ab0a5b86ef64275be6a0073d9fa7de575.scope
    568      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode096052b_7e74_4b98_b1a3_4a922c199061.slice/cri-containerd-d49941a7c7e852b169d37c08559a92a86f08e50cd0be9495df68e7224e30a5ab.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode096052b_7e74_4b98_b1a3_4a922c199061.slice/cri-containerd-4af7168c08105523632531f93e8a373f053796b7e16fdfc2db134fe7fe8d9fd5.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-8bf5307b7d5dbd6044c997e51950de3f5df8a2bcc026523bd79a080f7798f41d.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-a649ee9c96ea39947e080352da5d041feb09caf712aab6e859fb37eb66f41686.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-7b35d0d178d5864b4e44434ee5f550ed72f556583f20d292a9063c9625dbd47b.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc3988ef2_4e51_42d9_8f95_ebddd87cf451.slice/cri-containerd-aa8601ac0cf69caab5cc09303b6dcb1173a437e5b2034c8db5848bf9e15c4153.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod330124df_9476_4ecf_a478_eee4d554f94d.slice/cri-containerd-d75a1ede9b8a99c3dcda493139a84885bd32d9f2dd2f30972b604f56bb2d878c.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod330124df_9476_4ecf_a478_eee4d554f94d.slice/cri-containerd-9a439f4a906c6184d4197a2957c238e0b4273e07526f33c88f804edc4967e6b6.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded2d5a59_ea00_4a1d_9541_9274e12e4463.slice/cri-containerd-4ae99436b18580fb136945c8b22c18d42c6adc90fbde53a9e4c71fbc8e84206e.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poded2d5a59_ea00_4a1d_9541_9274e12e4463.slice/cri-containerd-fa06908983337046e6308eac9d25484ad79440f8636671b364f03ff26f22abed.scope
    90       cgroup_device   multi                                          
