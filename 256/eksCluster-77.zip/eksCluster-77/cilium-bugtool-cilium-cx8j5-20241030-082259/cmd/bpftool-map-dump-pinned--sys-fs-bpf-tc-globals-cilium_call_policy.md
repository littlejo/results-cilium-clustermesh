key: ad 01 00 00  value: 07 02 00 00
key: d4 03 00 00  value: 6e 02 00 00
key: 05 07 00 00  value: 1b 02 00 00
key: eb 08 00 00  value: 21 02 00 00
Found 4 elements
