IP ADDRESS         LOCAL ENDPOINT INFO
172.31.245.223:0   (localhost)                                                                                        
10.77.0.188:0      id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12   
10.77.0.232:0      id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7   
10.77.0.224:0      id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D   
10.77.0.154:0      id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B     
10.77.0.53:0       (localhost)                                                                                        
172.31.247.137:0   (localhost)                                                                                        
