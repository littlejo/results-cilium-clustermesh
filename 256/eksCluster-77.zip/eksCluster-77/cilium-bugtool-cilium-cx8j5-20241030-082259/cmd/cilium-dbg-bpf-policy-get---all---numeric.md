Endpoint ID: 429
Path: /sys/fs/bpf/tc/globals/cilium_policy_00429

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    151255   1731      0        
Allow    Egress      0          ANY          NONE         disabled    19620    218       0        


Endpoint ID: 980
Path: /sys/fs/bpf/tc/globals/cilium_policy_00980

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11701550   117388    0        
Allow    Ingress     1          ANY          NONE         disabled    10913948   115351    0        
Allow    Egress      0          ANY          NONE         disabled    13883672   136217    0        


Endpoint ID: 1797
Path: /sys/fs/bpf/tc/globals/cilium_policy_01797

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    152773   1754      0        
Allow    Egress      0          ANY          NONE         disabled    19350    214       0        


Endpoint ID: 2181
Path: /sys/fs/bpf/tc/globals/cilium_policy_02181

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2283
Path: /sys/fs/bpf/tc/globals/cilium_policy_02283

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1679274   21247     0        
Allow    Ingress     1          ANY          NONE         disabled    23090     272       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


