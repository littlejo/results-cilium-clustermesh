1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:c6:62:fd:51:bd brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.247.137/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3336sec preferred_lft 3336sec
    inet6 fe80::8c6:62ff:fefd:51bd/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:58:af:fe:c0:33 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.245.223/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::858:afff:fefe:c033/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:54:56:94:2e:a8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1854:56ff:fe94:2ea8/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether de:c5:5e:87:24:53 brd ff:ff:ff:ff:ff:ff
    inet 10.77.0.53/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::dcc5:5eff:fe87:2453/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether f6:6d:e6:2d:15:bf brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f46d:e6ff:fe2d:15bf/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 02:47:6c:5f:b4:2b brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::47:6cff:fe5f:b42b/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc73ddb034349a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether aa:c9:0d:6c:b5:9d brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::a8c9:dff:fe6c:b59d/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd15acb016dba@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:c6:e4:28:10:12 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f8c6:e4ff:fe28:1012/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc7ffb1f2a322c@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:91:94:5f:7f:e7 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::f891:94ff:fe5f:7fe7/64 scope link 
       valid_lft forever preferred_lft forever
