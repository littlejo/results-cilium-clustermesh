REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     37204     2940681     677    bpf_overlay.c
Interface                 INGRESS     665687    135182036   1132   bpf_host.c
Success                   EGRESS      16659     1309407     1694   bpf_host.c
Success                   EGRESS      283966    35293014    1308   bpf_lxc.c
Success                   EGRESS      37720     2974312     53     encap.h
Success                   INGRESS     328985    37087111    86     l3.h
Success                   INGRESS     350181    38762431    235    trace.h
Unsupported L3 protocol   EGRESS      41        3042        1492   bpf_lxc.c
