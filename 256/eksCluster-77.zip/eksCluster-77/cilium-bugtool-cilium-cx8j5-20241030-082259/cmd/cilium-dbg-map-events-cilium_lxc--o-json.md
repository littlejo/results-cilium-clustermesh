{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.904Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.245.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.904Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.247.137:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:43.904Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.610Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.614Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.616Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.653Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:56:48.680Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:31.779Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:31.779Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:31.780Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:31.813Z",
  "value": "id=1870  sec_id=2566015 flags=0x0000 ifindex=16  mac=C6:90:D7:16:E7:14 nodemac=D6:5E:15:D2:65:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.780Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.780Z",
  "value": "id=1870  sec_id=2566015 flags=0x0000 ifindex=16  mac=C6:90:D7:16:E7:14 nodemac=D6:5E:15:D2:65:A2"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.780Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:32.780Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:24.677Z",
  "value": "id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.77.0.146:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.107Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.388Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.389Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.390Z",
  "value": "id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:43.391Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.376Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.383Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.383Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.383Z",
  "value": "id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.370Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.370Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.371Z",
  "value": "id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.371Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.188:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.371Z",
  "value": "id=1797  sec_id=2558193 flags=0x0000 ifindex=14  mac=FA:5D:7F:4E:0B:CB nodemac=FA:C6:E4:28:10:12"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.154:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.371Z",
  "value": "id=2283  sec_id=4     flags=0x0000 ifindex=10  mac=5A:F2:BD:40:53:4B nodemac=02:47:6C:5F:B4:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.232:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.371Z",
  "value": "id=980   sec_id=2566015 flags=0x0000 ifindex=18  mac=0E:0E:C6:F3:13:B4 nodemac=FA:91:94:5F:7F:E7"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.77.0.224:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.371Z",
  "value": "id=429   sec_id=2558193 flags=0x0000 ifindex=12  mac=A6:58:EF:65:3C:D1 nodemac=AA:C9:0D:6C:B5:9D"
}

