CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0afbe836_cbe6_42dc_96a5_541edb4efda7.slice/cri-containerd-b832b35f0417492ba6626bdb23d165c2d54bf27029687dcbe71e873cdfa20266.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0afbe836_cbe6_42dc_96a5_541edb4efda7.slice/cri-containerd-595c62e49c497a4795e0b8f3cd756c512043ba18324509c8755d37a5196180d4.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69b1e6db_8a5f_41dd_b671_0b0123d2fed7.slice/cri-containerd-a4ac49bcb9d0f05f1dfd23321f2b98df92d9eba37b1a3a89a4a7b80533d8d42e.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69b1e6db_8a5f_41dd_b671_0b0123d2fed7.slice/cri-containerd-ecd875c897ad028a0f55f7874fe7c28b708128410d866afd61fea9160061899b.scope
    585      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32cabb3b_f7e0_4730_acd1_522225b52fee.slice/cri-containerd-c7b82e27c9f12ad24cdfbd460d9020db01597dd5845067ef0c64c6141a12b488.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32cabb3b_f7e0_4730_acd1_522225b52fee.slice/cri-containerd-eb38ecbb4748fcf370d3387245ca3d0355d43c0f5840d73bfbce95c85443d859.scope
    589      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ab1a3d_9f0c_40be_937c_182ed5f00fc2.slice/cri-containerd-47bc576164e0fe991c47010bb36a85cd382d4a1f073f90768512eb0de95aa89d.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod13ab1a3d_9f0c_40be_937c_182ed5f00fc2.slice/cri-containerd-642e3d7349768ecfa9433fa52ef4df40d60b2795271c4c1cb3ba33ea1e3f520c.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe36750f_42b1_44ea_87ff_0244d1f01e30.slice/cri-containerd-edeeb5d13d58743e526a6d3e1833296b2a302fdf7a8142b79e932f6e1caf080d.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbe36750f_42b1_44ea_87ff_0244d1f01e30.slice/cri-containerd-5f3730b6e2dc93d8841410a1304d05c3c3ac67962fbb2319a29d1a3a7fa6a08e.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-106088dd25037edfe4558d8d6c5b590844a1d33005a8849b8167fda402744507.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-16566198b0de0d24f5034203dc2fa91d9446816b3b127bd3e04a8f300b97c63f.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-510fbc1ca10d7fe04e3097d87d615be72d60e5b9b2ee0377dbd5f8bbbf404dc6.scope
    671      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-7c840b06920471e186bbb32772c24126f7a5714a5f2b584cdc22aa0467affa86.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod545775ff_6d2d_49d0_bfac_5d0587cdfc07.slice/cri-containerd-4216effc4e03ce323021b3efe32cb6f1287f047ea4987a725e9df373e21c3d67.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod545775ff_6d2d_49d0_bfac_5d0587cdfc07.slice/cri-containerd-cb1a4ab84e163bc689b97cd012285327fda341cb0a06bb71c11a169b3eaebe0c.scope
    91       cgroup_device   multi                                          
