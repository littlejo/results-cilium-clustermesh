{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.496Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.134.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.496Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.149.217:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:31.496Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.932Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.942Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:35.997Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:36.016Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:15.525Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:15.526Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:15.527Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:15.556Z",
  "value": "id=27    sec_id=7196226 flags=0x0000 ifindex=16  mac=FA:A3:D2:3F:89:CE nodemac=CA:95:AF:1F:20:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:16.526Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:16.526Z",
  "value": "id=27    sec_id=7196226 flags=0x0000 ifindex=16  mac=FA:A3:D2:3F:89:CE nodemac=CA:95:AF:1F:20:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:16.526Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:16.526Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.766Z",
  "value": "id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.218.0.76:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:31.248Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.683Z",
  "value": "id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.683Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.684Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.684Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.701Z",
  "value": "id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.701Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.702Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.702Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.685Z",
  "value": "id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.685Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.686Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.686Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.177:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.686Z",
  "value": "id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.172:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.686Z",
  "value": "id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.686Z",
  "value": "id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.218.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:06.687Z",
  "value": "id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43"
}

