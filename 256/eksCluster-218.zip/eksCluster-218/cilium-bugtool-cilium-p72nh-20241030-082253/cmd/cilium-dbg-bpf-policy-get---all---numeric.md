Endpoint ID: 575
Path: /sys/fs/bpf/tc/globals/cilium_policy_00575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    111920   1281      0        
Allow    Egress      0          ANY          NONE         disabled    15574    167       0        


Endpoint ID: 829
Path: /sys/fs/bpf/tc/globals/cilium_policy_00829

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1033
Path: /sys/fs/bpf/tc/globals/cilium_policy_01033

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112285   1283      0        
Allow    Egress      0          ANY          NONE         disabled    16833    181       0        


Endpoint ID: 1363
Path: /sys/fs/bpf/tc/globals/cilium_policy_01363

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656419   20912     0        
Allow    Ingress     1          ANY          NONE         disabled    17700     209       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1575
Path: /sys/fs/bpf/tc/globals/cilium_policy_01575

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11575387   114983    0        
Allow    Ingress     1          ANY          NONE         disabled    9874483    103859    0        
Allow    Egress      0          ANY          NONE         disabled    12395421   122266    0        


