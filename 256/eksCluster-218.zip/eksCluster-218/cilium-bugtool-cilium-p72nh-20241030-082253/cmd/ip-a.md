1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:1b:6e:4d:f6:ad brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.149.217/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 1907sec preferred_lft 1907sec
    inet6 fe80::41b:6eff:fe4d:f6ad/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:69:f7:31:dd:09 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.134.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::469:f7ff:fe31:dd09/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 06:04:36:0e:90:23 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::404:36ff:fe0e:9023/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:c1:f6:bf:e1:be brd ff:ff:ff:ff:ff:ff
    inet 10.218.0.189/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::20c1:f6ff:febf:e1be/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 16:e0:7b:06:3c:9e brd ff:ff:ff:ff:ff:ff
    inet6 fe80::14e0:7bff:fe06:3c9e/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:d5:fd:cb:27:1f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::34d5:fdff:fecb:271f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc46fea092ffbe@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:00:5c:67:e6:39 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ac00:5cff:fe67:e639/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc3236addcfef7@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:b1:a8:09:1e:43 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ecb1:a8ff:fe09:1e43/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc8d7777ad103e@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 72:b6:6f:cb:ac:96 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::70b6:6fff:fecb:ac96/64 scope link 
       valid_lft forever preferred_lft forever
