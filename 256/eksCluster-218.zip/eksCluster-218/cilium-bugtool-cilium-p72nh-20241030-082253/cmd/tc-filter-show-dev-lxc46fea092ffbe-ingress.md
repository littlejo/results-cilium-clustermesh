filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc46fea092ffbe direct-action not_in_hw id 522 tag d1b077d3c9cffe52 jited 
