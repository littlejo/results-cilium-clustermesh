IP ADDRESS         LOCAL ENDPOINT INFO
10.218.0.177:0     id=1575  sec_id=7196226 flags=0x0000 ifindex=18  mac=72:BE:BB:F0:86:36 nodemac=72:B6:6F:CB:AC:96   
10.218.0.53:0      id=575   sec_id=7180845 flags=0x0000 ifindex=14  mac=96:DC:F9:83:FD:80 nodemac=EE:B1:A8:09:1E:43   
172.31.134.255:0   (localhost)                                                                                        
10.218.0.240:0     id=1363  sec_id=4     flags=0x0000 ifindex=10  mac=7A:F1:2D:BC:0D:32 nodemac=36:D5:FD:CB:27:1F     
172.31.149.217:0   (localhost)                                                                                        
10.218.0.189:0     (localhost)                                                                                        
10.218.0.172:0     id=1033  sec_id=7180845 flags=0x0000 ifindex=12  mac=2E:2D:5E:3E:52:9D nodemac=AE:00:5C:67:E6:39   
