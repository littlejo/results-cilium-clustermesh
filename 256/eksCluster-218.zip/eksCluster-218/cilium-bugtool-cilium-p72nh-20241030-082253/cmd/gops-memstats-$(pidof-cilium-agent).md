alloc: 198.41MB (208045392 bytes)
total-alloc: 2.21GB (2371613496 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 62864762
frees: 60782308
heap-alloc: 198.41MB (208045392 bytes)
heap-sys: 251.45MB (263667712 bytes)
heap-idle: 29.52MB (30949376 bytes)
heap-in-use: 221.94MB (232718336 bytes)
heap-released: 7.41MB (7766016 bytes)
heap-objects: 2082454
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 3.45MB (3617440 bytes)
stack-mspan-sys: 3.83MB (4014720 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 981.99KB (1005553 bytes)
gc-sys: 6.03MB (6327832 bytes)
next-gc: when heap-alloc >= 209.82MB (220012168 bytes)
last-gc: 2024-10-30 08:22:51.094221026 +0000 UTC
gc-pause-total: 10.700586ms
gc-pause: 125551
gc-pause-end: 1730276571094221026
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005002569773400208
enable-gc: true
debug-gc: false
