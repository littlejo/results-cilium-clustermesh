key: 3f 02 00 00  value: 42 02 00 00
key: 09 04 00 00  value: 08 02 00 00
key: 53 05 00 00  value: 3d 02 00 00
key: 27 06 00 00  value: 86 02 00 00
Found 4 elements
