top - 08:22:54 up 28 min,  0 users,  load average: 0.15, 0.20, 0.13
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 37.9 us, 20.7 sy,  0.0 ni, 41.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4483.6 free,   1184.4 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6444.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 381548  77756 S   6.7   4.8   0:42.04 cilium-+
    627 root      20   0 1240432  16568  11356 S   6.7   0.2   0:00.03 cilium-+
    395 root      20   0 1229744   7260   2864 S   0.0   0.1   0:01.06 cilium-+
    600 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    626 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    661 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    671 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    678 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    710 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    715 root      20   0 1615752   8356   6284 S   0.0   0.1   0:00.00 runc:[2+
