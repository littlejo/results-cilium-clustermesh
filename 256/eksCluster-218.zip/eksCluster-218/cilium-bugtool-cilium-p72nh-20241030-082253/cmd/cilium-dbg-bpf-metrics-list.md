REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35596     2814562     677    bpf_overlay.c
Interface                 INGRESS     633011    130346043   1132   bpf_host.c
Success                   EGRESS      15376     1205422     1694   bpf_host.c
Success                   EGRESS      267873    33740836    1308   bpf_lxc.c
Success                   EGRESS      35217     2783824     53     encap.h
Success                   INGRESS     311391    35017896    86     l3.h
Success                   INGRESS     332261    36671012    235    trace.h
Unsupported L3 protocol   EGRESS      38        2796        1492   bpf_lxc.c
