ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.163.221:443 (active)    
                                         2 => 172.31.212.38:443 (active)     
2    10.100.248.225:443   ClusterIP      1 => 172.31.149.217:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.218.0.172:53 (active)       
                                         2 => 10.218.0.53:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.218.0.172:9153 (active)     
                                         2 => 10.218.0.53:9153 (active)      
5    10.100.2.145:2379    ClusterIP      1 => 10.218.0.177:2379 (active)     
