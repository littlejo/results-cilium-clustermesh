KEY             VALUE
AgentLiveness   1734054248556
UTimeOffset     3379443107421875
