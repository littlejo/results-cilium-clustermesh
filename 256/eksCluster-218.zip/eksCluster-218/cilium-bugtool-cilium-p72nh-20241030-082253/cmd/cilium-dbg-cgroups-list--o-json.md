[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-510fbc1ca10d7fe04e3097d87d615be72d60e5b9b2ee0377dbd5f8bbbf404dc6.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-7c840b06920471e186bbb32772c24126f7a5714a5f2b584cdc22aa0467affa86.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod072a7bb1_340a_4e2d_b4b4_c18dd8d5b6f7.slice/cri-containerd-106088dd25037edfe4558d8d6c5b590844a1d33005a8849b8167fda402744507.scope"
      }
    ],
    "ips": [
      "10.218.0.177"
    ],
    "name": "clustermesh-apiserver-845857d564-dlw5f",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod69b1e6db_8a5f_41dd_b671_0b0123d2fed7.slice/cri-containerd-a4ac49bcb9d0f05f1dfd23321f2b98df92d9eba37b1a3a89a4a7b80533d8d42e.scope"
      }
    ],
    "ips": [
      "10.218.0.172"
    ],
    "name": "coredns-cc6ccd49c-x5dvr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod32cabb3b_f7e0_4730_acd1_522225b52fee.slice/cri-containerd-c7b82e27c9f12ad24cdfbd460d9020db01597dd5845067ef0c64c6141a12b488.scope"
      }
    ],
    "ips": [
      "10.218.0.53"
    ],
    "name": "coredns-cc6ccd49c-wjwkk",
    "namespace": "kube-system"
  }
]

