filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc1f6a84c3be27 direct-action not_in_hw id 520 tag 5316fea0a2c848b4 jited 
