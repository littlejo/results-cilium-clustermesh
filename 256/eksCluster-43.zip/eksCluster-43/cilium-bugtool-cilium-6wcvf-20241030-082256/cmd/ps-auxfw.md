USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         720  0.0  0.2 1240432 16544 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         741  0.0  0.0   6408  1640 ?        R    08:22   0:00  \_ ps auxfw
root         719  0.0  0.0 1228744 4036 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         710  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops pprof-heap 1
root         700  0.0  0.0 1228744 3596 ?        Ssl  08:22   0:00 /bin/gops stats 1
root         691  0.0  0.0 1228744 3780 ?        Ssl  08:22   0:00 /bin/gops stack 1
root         682  0.0  0.0 1228744 3776 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root           1  3.3  4.7 1605824 378544 ?      Ssl  07:58   0:49 cilium-agent --config-dir=/tmp/cilium/config-map
root         393  0.0  0.0 1229744 7212 ?        Sl   07:58   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
