Endpoint ID: 690
Path: /sys/fs/bpf/tc/globals/cilium_policy_00690

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 882
Path: /sys/fs/bpf/tc/globals/cilium_policy_00882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    185705   1670      0        
Allow    Ingress     1          ANY          NONE         disabled    144153   1659      0        
Allow    Egress      0          ANY          NONE         disabled    82828    806       0        


Endpoint ID: 1150
Path: /sys/fs/bpf/tc/globals/cilium_policy_01150

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11387981   111772    0        
Allow    Ingress     1          ANY          NONE         disabled    9419274    98570     0        
Allow    Egress      0          ANY          NONE         disabled    10929627   109035    0        


Endpoint ID: 1500
Path: /sys/fs/bpf/tc/globals/cilium_policy_01500

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1673858   21179     0        
Allow    Ingress     1          ANY          NONE         disabled    21718     253       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2019
Path: /sys/fs/bpf/tc/globals/cilium_policy_02019

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    191555   1713      0        
Allow    Ingress     1          ANY          NONE         disabled    142309   1640      0        
Allow    Egress      0          ANY          NONE         disabled    81889    795       0        


