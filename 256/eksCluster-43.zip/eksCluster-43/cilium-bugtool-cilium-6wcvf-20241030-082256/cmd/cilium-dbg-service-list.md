ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.139.200:443 (active)   
                                          2 => 172.31.243.62:443 (active)    
2    10.100.187.216:443    ClusterIP      1 => 172.31.231.5:4244 (active)    
3    10.100.0.10:53        ClusterIP      1 => 10.43.0.243:53 (active)       
                                          2 => 10.43.0.8:53 (active)         
4    10.100.0.10:9153      ClusterIP      1 => 10.43.0.243:9153 (active)     
                                          2 => 10.43.0.8:9153 (active)       
5    10.100.139.150:2379   ClusterIP      1 => 10.43.0.116:2379 (active)     
