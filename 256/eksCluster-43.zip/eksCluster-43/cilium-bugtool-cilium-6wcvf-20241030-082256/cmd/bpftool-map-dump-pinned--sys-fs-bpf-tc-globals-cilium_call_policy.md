key: 72 03 00 00  value: 49 02 00 00
key: 7e 04 00 00  value: 8a 02 00 00
key: dc 05 00 00  value: 3d 02 00 00
key: e3 07 00 00  value: 13 02 00 00
Found 4 elements
