filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8e295a7df593 direct-action not_in_hw id 648 tag 5218122f5ad58300 jited 
