REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     34873     2748387     677    bpf_overlay.c
Interface                 INGRESS     625158    129317516   1132   bpf_host.c
Success                   EGRESS      14389     1122217     1694   bpf_host.c
Success                   EGRESS      262610    33323353    1308   bpf_lxc.c
Success                   EGRESS      33824     2671226     53     encap.h
Success                   EGRESS      6766      1073191     86     l3.h
Success                   INGRESS     304756    34113997    86     l3.h
Success                   INGRESS     332657    36857404    235    trace.h
Unsupported L3 protocol   EGRESS      40        2952        1492   bpf_lxc.c
