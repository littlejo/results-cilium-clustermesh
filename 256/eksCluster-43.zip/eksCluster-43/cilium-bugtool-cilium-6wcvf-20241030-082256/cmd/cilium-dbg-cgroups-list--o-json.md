[
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4fc4f1d4_eb24_4a1a_bbf5_a29251fa979f.slice/cri-containerd-a320fc536e63516e71fcc88e2902f8fb345eac489856b1c5da05db876543addd.scope"
      }
    ],
    "ips": [
      "10.43.0.243"
    ],
    "name": "coredns-cc6ccd49c-z664n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb5fc_dc85_43fd_b208_bea7186f8a32.slice/cri-containerd-a4f994c5979ce800d5d9a7c0b3336b16c412758b69f604515b9261c0b73e3268.scope"
      }
    ],
    "ips": [
      "10.43.0.8"
    ],
    "name": "coredns-cc6ccd49c-h2mzr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-b2765c1a0172e6633ae922c765b7259b28f4f7e88fd4419213693e63b258e979.scope"
      },
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-8de4e3aa3568f4665237d9edfa007a35c963b992307132c9e0ff6b1bb405a78d.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-19aa7176f76f38d77886889c8d3aff1a09a1dfd857558592bfb5d6f92594b5f7.scope"
      }
    ],
    "ips": [
      "10.43.0.116"
    ],
    "name": "clustermesh-apiserver-5bb767ff69-hwjpl",
    "namespace": "kube-system"
  }
]

