alloc: 144.73MB (151764184 bytes)
total-alloc: 2.22GB (2384534032 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 63000157
frees: 61861314
heap-alloc: 144.73MB (151764184 bytes)
heap-sys: 247.48MB (259506176 bytes)
heap-idle: 65.97MB (69173248 bytes)
heap-in-use: 181.52MB (190332928 bytes)
heap-released: 704.00KB (720896 bytes)
heap-objects: 1138843
stack-in-use: 64.47MB (67600384 bytes)
stack-sys: 64.47MB (67600384 bytes)
stack-mspan-inuse: 2.75MB (2884320 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.02MB (1072777 bytes)
gc-sys: 6.02MB (6315496 bytes)
next-gc: when heap-alloc >= 214.38MB (224790328 bytes)
last-gc: 2024-10-30 08:23:10.725064251 +0000 UTC
gc-pause-total: 26.690751ms
gc-pause: 113127
gc-pause-end: 1730276590725064251
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.0004137683917475092
enable-gc: true
debug-gc: false
