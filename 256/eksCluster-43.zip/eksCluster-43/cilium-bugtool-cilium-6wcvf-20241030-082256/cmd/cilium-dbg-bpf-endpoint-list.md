IP ADDRESS         LOCAL ENDPOINT INFO
10.43.0.243:0      id=882   sec_id=1442535 flags=0x0000 ifindex=14  mac=FE:94:96:C3:1F:D4 nodemac=3E:F9:58:39:AB:17   
10.43.0.113:0      id=1500  sec_id=4     flags=0x0000 ifindex=10  mac=D6:38:6B:D7:10:80 nodemac=8E:7E:E4:1C:82:3D     
172.31.231.5:0     (localhost)                                                                                        
172.31.203.222:0   (localhost)                                                                                        
10.43.0.116:0      id=1150  sec_id=1460930 flags=0x0000 ifindex=18  mac=02:7C:70:59:09:BE nodemac=C2:56:D6:97:AB:11   
10.43.0.8:0        id=2019  sec_id=1442535 flags=0x0000 ifindex=12  mac=02:15:71:42:71:00 nodemac=C2:8B:AD:94:BB:C5   
10.43.0.60:0       (localhost)                                                                                        
