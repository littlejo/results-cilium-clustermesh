top - 08:22:58 up 33 min,  0 users,  load average: 0.33, 0.34, 0.25
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 10.3 us, 24.1 sy,  0.0 ni, 65.5 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4483.0 free,   1185.3 used,   2145.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6443.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    720 root      20   0 1240432  16544  11356 S  13.3   0.2   0:00.03 cilium-+
      1 root      20   0 1605824 378544  78716 S   0.0   4.7   0:49.66 cilium-+
    393 root      20   0 1229744   7212   2864 S   0.0   0.1   0:01.16 cilium-+
    682 root      20   0 1228744   3776   3104 S   0.0   0.0   0:00.00 gops
    691 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    700 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    710 root      20   0 1228744   4040   3392 S   0.0   0.1   0:00.00 gops
    719 root      20   0 1228744   4036   3392 S   0.0   0.1   0:00.00 gops
    753 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    771 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
