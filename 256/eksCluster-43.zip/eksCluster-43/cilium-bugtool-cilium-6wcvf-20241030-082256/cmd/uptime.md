 08:22:57 up 33 min,  0 users,  load average: 0.33, 0.34, 0.25
