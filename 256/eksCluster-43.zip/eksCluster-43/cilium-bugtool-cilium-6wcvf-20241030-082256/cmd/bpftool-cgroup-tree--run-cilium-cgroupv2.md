CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a4598c8_1479_4035_ae8c_736d2c607bac.slice/cri-containerd-17d775cd92da2215af3082930bdd54343e504fae74243bf5d43b61206d1e37c4.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3a4598c8_1479_4035_ae8c_736d2c607bac.slice/cri-containerd-bb66552d9fcf13987707143c5c5d40590d17b90d18d33339d664af5772fb6222.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb5fc_dc85_43fd_b208_bea7186f8a32.slice/cri-containerd-410f8f6954655f1e8a96f8f843e534e6ba3477efe2c05027bbe661d7b421848b.scope
    591      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeedfb5fc_dc85_43fd_b208_bea7186f8a32.slice/cri-containerd-a4f994c5979ce800d5d9a7c0b3336b16c412758b69f604515b9261c0b73e3268.scope
    603      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24711d45_0372_42e7_a403_1550f1bca2d3.slice/cri-containerd-3fef14b076e45d07fc6d883b826edb8fa84c63b7845b20f4f2b3fbccf16a6ad0.scope
    63       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod24711d45_0372_42e7_a403_1550f1bca2d3.slice/cri-containerd-934367e7f2cb0e3868ea34d52799fdd203c7c821818a461d33cb8a152fb37faf.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4fc4f1d4_eb24_4a1a_bbf5_a29251fa979f.slice/cri-containerd-692378f47969392b73be9cbb55842b5c9c3deb609778804ebd1030cec0b7a572.scope
    595      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4fc4f1d4_eb24_4a1a_bbf5_a29251fa979f.slice/cri-containerd-a320fc536e63516e71fcc88e2902f8fb345eac489856b1c5da05db876543addd.scope
    599      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d0b705f_cf33_4b2b_a47c_5a6c10a4b7c4.slice/cri-containerd-d9aced21ad25803d06e08c570315938ec4f004af273966cb5cb04dcdd3b90a64.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0d0b705f_cf33_4b2b_a47c_5a6c10a4b7c4.slice/cri-containerd-acff5109304386d795f8a6b8468b0cbd190123acde0919e1764f3e3157d8a8aa.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-b2765c1a0172e6633ae922c765b7259b28f4f7e88fd4419213693e63b258e979.scope
    681      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-8de4e3aa3568f4665237d9edfa007a35c963b992307132c9e0ff6b1bb405a78d.scope
    677      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-19aa7176f76f38d77886889c8d3aff1a09a1dfd857558592bfb5d6f92594b5f7.scope
    673      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddfbd9c37_66a4_4fc9_8830_7df6d438ed14.slice/cri-containerd-ec36b49ce0d836fb99c29d535b814b35cd61fa860074fb3cf99c761aef700643.scope
    657      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56715470_2c66_4dc3_94f8_e52905250622.slice/cri-containerd-b074cf685f34dcc04669a6d2114e4b8afac53ed06422dfa9775b675df146abfa.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56715470_2c66_4dc3_94f8_e52905250622.slice/cri-containerd-6f31401577695a862c2c612828a519791258784f380fdf8eecf9841871307f4a.scope
    101      cgroup_device   multi                                          
