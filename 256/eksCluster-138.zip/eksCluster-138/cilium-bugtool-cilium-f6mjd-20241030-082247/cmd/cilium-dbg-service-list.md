ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.209.162:443 (active)    
                                        2 => 172.31.161.87:443 (active)     
2    10.100.74.144:443   ClusterIP      1 => 172.31.148.213:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.138.0.162:53 (active)       
                                        2 => 10.138.0.235:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.138.0.162:9153 (active)     
                                        2 => 10.138.0.235:9153 (active)     
5    10.100.8.115:2379   ClusterIP      1 => 10.138.0.174:2379 (active)     
