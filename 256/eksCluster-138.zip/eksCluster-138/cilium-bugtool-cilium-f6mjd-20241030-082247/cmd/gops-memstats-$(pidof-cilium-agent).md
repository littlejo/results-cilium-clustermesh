alloc: 126.59MB (132739288 bytes)
total-alloc: 2.31GB (2475891888 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 64404917
frees: 63555357
heap-alloc: 126.59MB (132739288 bytes)
heap-sys: 252.42MB (264683520 bytes)
heap-idle: 63.96MB (67067904 bytes)
heap-in-use: 188.46MB (197615616 bytes)
heap-released: 1.71MB (1794048 bytes)
heap-objects: 849560
stack-in-use: 63.53MB (66617344 bytes)
stack-sys: 63.53MB (66617344 bytes)
stack-mspan-inuse: 2.93MB (3072800 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1281897 bytes)
gc-sys: 6.02MB (6311376 bytes)
next-gc: when heap-alloc >= 217.32MB (227872296 bytes)
last-gc: 2024-10-30 08:23:13.770824661 +0000 UTC
gc-pause-total: 12.684536ms
gc-pause: 160617
gc-pause-end: 1730276593770824661
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0005232303213419843
enable-gc: true
debug-gc: false
