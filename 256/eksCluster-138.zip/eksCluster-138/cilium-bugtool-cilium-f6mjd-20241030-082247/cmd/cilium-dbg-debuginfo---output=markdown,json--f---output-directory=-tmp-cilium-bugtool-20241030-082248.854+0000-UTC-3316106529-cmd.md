markdown output at /tmp/cilium-bugtool-20241030-082248.854+0000-UTC-3316106529/cmd/cilium-debuginfo-20241030-082320.205+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082248.854+0000-UTC-3316106529/cmd/cilium-debuginfo-20241030-082320.205+0000-UTC.json
