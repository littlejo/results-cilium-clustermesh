{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.155Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.148.213:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.155Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.174.223:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:42.155Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.000Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.001Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.002Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.052Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:47.063Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.867Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.867Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.867Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.897Z",
  "value": "id=1077  sec_id=4561925 flags=0x0000 ifindex=16  mac=7A:B4:CB:81:32:FB nodemac=B2:18:38:B9:16:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:46.898Z",
  "value": "id=1077  sec_id=4561925 flags=0x0000 ifindex=16  mac=7A:B4:CB:81:32:FB nodemac=B2:18:38:B9:16:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.867Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.868Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.868Z",
  "value": "id=1077  sec_id=4561925 flags=0x0000 ifindex=16  mac=7A:B4:CB:81:32:FB nodemac=B2:18:38:B9:16:7B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:47.868Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.232Z",
  "value": "id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.138.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.529Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.048Z",
  "value": "id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.049Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.053Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:44.054Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.075Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.077Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.077Z",
  "value": "id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:45.078Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.049Z",
  "value": "id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.050Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.050Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:46.050Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.133:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.050Z",
  "value": "id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.050Z",
  "value": "id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.235:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.051Z",
  "value": "id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.138.0.162:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:47.051Z",
  "value": "id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0"
}

