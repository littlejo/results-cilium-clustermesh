IP ADDRESS         LOCAL ENDPOINT INFO
172.31.148.213:0   (localhost)                                                                                        
10.138.0.235:0     id=404   sec_id=4581094 flags=0x0000 ifindex=12  mac=BE:52:6E:3B:55:D1 nodemac=36:6D:7B:B0:11:B5   
172.31.174.223:0   (localhost)                                                                                        
10.138.0.227:0     (localhost)                                                                                        
10.138.0.174:0     id=96    sec_id=4561925 flags=0x0000 ifindex=18  mac=0E:44:78:94:47:98 nodemac=66:E3:86:5E:F6:EC   
10.138.0.162:0     id=1079  sec_id=4581094 flags=0x0000 ifindex=14  mac=82:3A:5D:B0:32:6F nodemac=BA:EE:C6:22:74:C0   
10.138.0.133:0     id=174   sec_id=4     flags=0x0000 ifindex=10  mac=46:32:ED:0A:46:76 nodemac=52:3F:CC:F5:56:9C     
