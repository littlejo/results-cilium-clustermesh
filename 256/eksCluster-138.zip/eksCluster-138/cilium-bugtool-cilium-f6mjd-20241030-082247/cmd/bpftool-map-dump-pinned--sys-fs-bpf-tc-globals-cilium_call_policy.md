key: 60 00 00 00  value: 67 02 00 00
key: ae 00 00 00  value: 26 02 00 00
key: 94 01 00 00  value: 11 02 00 00
key: 37 04 00 00  value: 2a 02 00 00
Found 4 elements
