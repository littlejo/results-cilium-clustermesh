CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9649ed72_ceb9_4527_aa18_dacb01a32c00.slice/cri-containerd-33075db8e923668eee93f1d9f7b4f698622c5a105fa194c970bc5a64eb100076.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9649ed72_ceb9_4527_aa18_dacb01a32c00.slice/cri-containerd-aa0c6982c1192b0609342a33402546d09e58cb9e5e73983811107642a82987e9.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod099b3979_9d2f_43e4_9558_d4fbfb0c47e1.slice/cri-containerd-fe313151e8e4bbc2007bc3ceeb9ef8b4fbd919fa4c671d421e394ee89c2c9248.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod099b3979_9d2f_43e4_9558_d4fbfb0c47e1.slice/cri-containerd-bf89ca6ce36e789f9c3ea122f678b0deea17a7a8c2285bc51587830cd03acdd7.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c39aeb2_bb0e_4bb9_a585_828a3346dd32.slice/cri-containerd-d68b941b72d37bd357d7d308d31e37caaf270b3fe7c42f20a593decca5bc0709.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8c39aeb2_bb0e_4bb9_a585_828a3346dd32.slice/cri-containerd-4cee4bc3e1662aa4b620b23771c4d1e13e27e17b21e714510237163ba00e9d43.scope
    53       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54145c8a_ac89_499f_92cc_083d0121cee6.slice/cri-containerd-eae1997377a0ffdb6d3ab6beedfdd052c6e853c56fb934dbce5373a130fc145b.scope
    572      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54145c8a_ac89_499f_92cc_083d0121cee6.slice/cri-containerd-fe5c06d8354cab4137fd234b94a2dedb1bf69d077b5cf3e3cc9fd15da08410f4.scope
    560      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cd00e2b_75c5_448c_aecf_24e0ce8bbaba.slice/cri-containerd-367d55094949af079c271795192dce80f9bf797cca17028ec97df07b2107d480.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3cd00e2b_75c5_448c_aecf_24e0ce8bbaba.slice/cri-containerd-ec20a9d93f3cfe4067541ebe1b4bc88be94c19b43919a205cede72026169f832.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-c52c764507b14595f7b86b986696e818dae7a7dc77454d893c7b9169383d0dc1.scope
    642      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-95754e018774782746551cfa90ca0869ed18b386311fe815b4dbd59553563b62.scope
    650      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-4e071f0477bd97d8f7f6f15c10a3810cfb6cf3119fba9e4388d7809d82d76aae.scope
    646      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-c84e78b8be3fefe5729de09a461768c8281b30dd47e389b0ebbeac8f77d9011b.scope
    626      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddca59f94_4568_4a35_b73a_b801af127d76.slice/cri-containerd-e993f358106e13174b9b48abe74449f237f62f0355a9843b3a0266e565ed12da.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddca59f94_4568_4a35_b73a_b801af127d76.slice/cri-containerd-2ae9958b38b804daade0c1bb142ad4322eff8971f5e8bb5b7617a9f17bcee8a4.scope
    98       cgroup_device   multi                                          
