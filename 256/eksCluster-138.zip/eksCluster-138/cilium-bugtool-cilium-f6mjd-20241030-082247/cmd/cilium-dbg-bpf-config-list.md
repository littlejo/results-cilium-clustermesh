KEY             VALUE
AgentLiveness   1993713710689
UTimeOffset     3379442591796875
