xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 504
ens6(5) clsact/ingress cil_from_netdev-ens6 id 510
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 498
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 490
cilium_host(7) clsact/egress cil_from_host-cilium_host id 488
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 482
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 483
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 549
lxc5f475f80e90a(12) clsact/ingress cil_from_container-lxc5f475f80e90a id 518
lxc05653cd2350e(14) clsact/ingress cil_from_container-lxc05653cd2350e id 537
lxc14e79b549a12(18) clsact/ingress cil_from_container-lxc14e79b549a12 id 618

flow_dissector:

netfilter:

