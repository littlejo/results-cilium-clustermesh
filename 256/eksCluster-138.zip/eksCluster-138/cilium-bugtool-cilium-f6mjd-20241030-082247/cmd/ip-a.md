1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:c3:2a:c4:1e:05 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.148.213/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3447sec preferred_lft 3447sec
    inet6 fe80::4c3:2aff:fec4:1e05/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:45:31:13:a7:35 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.174.223/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::445:31ff:fe13:a735/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:30:a0:61:20:9d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1030:a0ff:fe61:209d/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether da:e5:ce:2c:17:45 brd ff:ff:ff:ff:ff:ff
    inet 10.138.0.227/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::d8e5:ceff:fe2c:1745/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6e:f4:89:e3:c0:5d brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6cf4:89ff:fee3:c05d/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:3f:cc:f5:56:9c brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::503f:ccff:fef5:569c/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc5f475f80e90a@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 36:6d:7b:b0:11:b5 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::346d:7bff:feb0:11b5/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc05653cd2350e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ba:ee:c6:22:74:c0 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::b8ee:c6ff:fe22:74c0/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc14e79b549a12@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:e3:86:5e:f6:ec brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::64e3:86ff:fe5e:f6ec/64 scope link 
       valid_lft forever preferred_lft forever
