Endpoint ID: 96
Path: /sys/fs/bpf/tc/globals/cilium_policy_00096

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11521615   115413    0        
Allow    Ingress     1          ANY          NONE         disabled    10663290   112531    0        
Allow    Egress      0          ANY          NONE         disabled    13799869   135290    0        


Endpoint ID: 174
Path: /sys/fs/bpf/tc/globals/cilium_policy_00174

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1641770   20724     0        
Allow    Ingress     1          ANY          NONE         disabled    19421     228       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 404
Path: /sys/fs/bpf/tc/globals/cilium_policy_00404

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128221   1467      0        
Allow    Egress      0          ANY          NONE         disabled    18041    197       0        


Endpoint ID: 442
Path: /sys/fs/bpf/tc/globals/cilium_policy_00442

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1079
Path: /sys/fs/bpf/tc/globals/cilium_policy_01079

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    128221   1467      0        
Allow    Egress      0          ANY          NONE         disabled    18995    208       0        


