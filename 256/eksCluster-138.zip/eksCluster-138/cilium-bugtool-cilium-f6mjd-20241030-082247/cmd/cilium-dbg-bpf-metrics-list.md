REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36750     2911582     677    bpf_overlay.c
Interface                 INGRESS     652990    133397119   1132   bpf_host.c
Success                   EGRESS      16725     1317644     1694   bpf_host.c
Success                   EGRESS      279907    34802061    1308   bpf_lxc.c
Success                   EGRESS      37289     2948039     53     encap.h
Success                   INGRESS     322982    36509437    86     l3.h
Success                   INGRESS     343658    38147421    235    trace.h
Unsupported L3 protocol   EGRESS      43        3222        1492   bpf_lxc.c
