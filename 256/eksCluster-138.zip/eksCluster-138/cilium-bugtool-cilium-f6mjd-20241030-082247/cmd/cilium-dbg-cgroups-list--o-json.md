[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod54145c8a_ac89_499f_92cc_083d0121cee6.slice/cri-containerd-eae1997377a0ffdb6d3ab6beedfdd052c6e853c56fb934dbce5373a130fc145b.scope"
      }
    ],
    "ips": [
      "10.138.0.235"
    ],
    "name": "coredns-cc6ccd49c-dj48m",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod099b3979_9d2f_43e4_9558_d4fbfb0c47e1.slice/cri-containerd-fe313151e8e4bbc2007bc3ceeb9ef8b4fbd919fa4c671d421e394ee89c2c9248.scope"
      }
    ],
    "ips": [
      "10.138.0.162"
    ],
    "name": "coredns-cc6ccd49c-slw6b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-4e071f0477bd97d8f7f6f15c10a3810cfb6cf3119fba9e4388d7809d82d76aae.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-c52c764507b14595f7b86b986696e818dae7a7dc77454d893c7b9169383d0dc1.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod69cd1df3_a2ea_4bb8_8ee5_2b7c2995774b.slice/cri-containerd-95754e018774782746551cfa90ca0869ed18b386311fe815b4dbd59553563b62.scope"
      }
    ],
    "ips": [
      "10.138.0.174"
    ],
    "name": "clustermesh-apiserver-5cb697f458-zzsl4",
    "namespace": "kube-system"
  }
]

