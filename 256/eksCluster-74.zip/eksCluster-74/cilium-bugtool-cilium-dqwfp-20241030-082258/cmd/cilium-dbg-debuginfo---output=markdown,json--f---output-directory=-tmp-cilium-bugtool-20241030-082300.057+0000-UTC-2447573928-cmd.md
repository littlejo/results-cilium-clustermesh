markdown output at /tmp/cilium-bugtool-20241030-082300.057+0000-UTC-2447573928/cmd/cilium-debuginfo-20241030-082331.211+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.057+0000-UTC-2447573928/cmd/cilium-debuginfo-20241030-082331.211+0000-UTC.json
