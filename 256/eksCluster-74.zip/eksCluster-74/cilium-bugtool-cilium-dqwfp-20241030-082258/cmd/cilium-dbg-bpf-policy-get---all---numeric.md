Endpoint ID: 383
Path: /sys/fs/bpf/tc/globals/cilium_policy_00383

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 534
Path: /sys/fs/bpf/tc/globals/cilium_policy_00534

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171075   1969      0        
Allow    Egress      0          ANY          NONE         disabled    20625    231       0        


Endpoint ID: 830
Path: /sys/fs/bpf/tc/globals/cilium_policy_00830

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    171956   1977      0        
Allow    Egress      0          ANY          NONE         disabled    21861    246       0        


Endpoint ID: 1943
Path: /sys/fs/bpf/tc/globals/cilium_policy_01943

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11747983   117865    0        
Allow    Ingress     1          ANY          NONE         disabled    11771530   120996    0        
Allow    Egress      0          ANY          NONE         disabled    13925270   136630    0        


Endpoint ID: 3420
Path: /sys/fs/bpf/tc/globals/cilium_policy_03420

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1657234   21007     0        
Allow    Ingress     1          ANY          NONE         disabled    25314     297       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


