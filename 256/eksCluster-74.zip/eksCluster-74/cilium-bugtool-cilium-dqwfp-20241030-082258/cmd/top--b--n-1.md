top - 08:23:00 up 36 min,  0 users,  load average: 0.30, 0.26, 0.19
Tasks:   7 total,   2 running,   5 sleeping,   0 stopped,   0 zombie
%Cpu(s): 51.7 us, 31.0 sy,  0.0 ni, 13.8 id,  0.0 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4452.5 free,   1214.5 used,   2147.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6414.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606336 405636  78132 S  86.7   5.1   1:00.03 cilium-+
    602 root      20   0 1229704  15404   4004 R  13.3   0.2   0:00.02 gops
    638 root      20   0 1240432  16572  11356 S   6.7   0.2   0:00.02 cilium-+
    394 root      20   0 1229744   8020   3836 S   0.0   0.1   0:01.15 cilium-+
    663 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    673 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    692 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
