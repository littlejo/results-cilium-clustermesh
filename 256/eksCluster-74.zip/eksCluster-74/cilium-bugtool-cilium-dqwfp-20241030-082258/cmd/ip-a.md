1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:87:50:89:31:9f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.133.182/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3235sec preferred_lft 3235sec
    inet6 fe80::487:50ff:fe89:319f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:af:ce:eb:df:55 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.160.191/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::4af:ceff:feeb:df55/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether d2:36:2e:a6:d2:09 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d036:2eff:fea6:d209/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether b6:ae:0b:87:82:b6 brd ff:ff:ff:ff:ff:ff
    inet 10.74.0.118/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::b4ae:bff:fe87:82b6/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 32:10:f6:b7:9f:21 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::3010:f6ff:feb7:9f21/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether c2:46:9e:ac:81:5f brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::c046:9eff:feac:815f/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc36817ccf1d73@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:b2:06:3b:43:93 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::1cb2:6ff:fe3b:4393/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcf3265dcc7c5e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether fa:4a:93:ea:e5:49 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f84a:93ff:feea:e549/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcfe8af00a49e1@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:94:e8:db:c0:de brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4094:e8ff:fedb:c0de/64 scope link 
       valid_lft forever preferred_lft forever
