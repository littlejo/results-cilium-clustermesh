ID   Frontend             Service Type   Backend                             
1    10.100.0.1:443       ClusterIP      1 => 172.31.132.150:443 (active)    
                                         2 => 172.31.229.20:443 (active)     
2    10.100.231.204:443   ClusterIP      1 => 172.31.133.182:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.74.0.19:53 (active)         
                                         2 => 10.74.0.247:53 (active)        
4    10.100.0.10:9153     ClusterIP      1 => 10.74.0.19:9153 (active)       
                                         2 => 10.74.0.247:9153 (active)      
5    10.100.96.44:2379    ClusterIP      1 => 10.74.0.165:2379 (active)      
