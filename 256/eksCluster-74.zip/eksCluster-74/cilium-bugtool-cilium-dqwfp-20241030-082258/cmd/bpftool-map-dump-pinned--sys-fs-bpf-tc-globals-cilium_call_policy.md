key: 16 02 00 00  value: 04 02 00 00
key: 3e 03 00 00  value: 14 02 00 00
key: 97 07 00 00  value: 64 02 00 00
key: 5c 0d 00 00  value: 20 02 00 00
Found 4 elements
