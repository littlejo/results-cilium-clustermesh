IP ADDRESS         LOCAL ENDPOINT INFO
10.74.0.19:0       id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93   
10.74.0.118:0      (localhost)                                                                                        
10.74.0.247:0      id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49   
172.31.160.191:0   (localhost)                                                                                        
10.74.0.9:0        id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F     
10.74.0.165:0      id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE   
172.31.133.182:0   (localhost)                                                                                        
