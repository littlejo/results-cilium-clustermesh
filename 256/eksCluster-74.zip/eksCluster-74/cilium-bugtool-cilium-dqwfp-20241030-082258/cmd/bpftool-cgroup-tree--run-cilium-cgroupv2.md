CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaec13a6a_9aa9_45cc_9232_0a73a83115fe.slice/cri-containerd-f2d636198264401df2ec16d0a923b9d50c0a6dc9dbed003dc1683f5c853be85f.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podaec13a6a_9aa9_45cc_9232_0a73a83115fe.slice/cri-containerd-7ff958ba7d15c8ae1223a95a86f2b47871fb1a4ef1d53a61e45f5d67068ee619.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29edc064_aaa5_46ed_8649_d9a8cadd677b.slice/cri-containerd-d4773936142b44703acf99d3168474ca23b4d45cf81a7a31989d705cfbc487cc.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29edc064_aaa5_46ed_8649_d9a8cadd677b.slice/cri-containerd-d9def4aa984448adf0ae516b48e5f4632c17f543ca8bbbaa1ba1f73fa42e2170.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e052420_ad56_40ab_833a_bfc53d3a47cd.slice/cri-containerd-2d9328dde6f31cd995df7ba86fe6aac18cbd9cfeda215e63997de9fd2c8adccf.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6e052420_ad56_40ab_833a_bfc53d3a47cd.slice/cri-containerd-4da59a95151e92270f5805b950349aa11767b0120e634267c43509d24ce407b6.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebe21fb9_6c6a_466b_a80f_70897f669d74.slice/cri-containerd-a4abaeb7c2c230b15f933f19da1372cc45fb0374f4d133877104840f38d22c4e.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebe21fb9_6c6a_466b_a80f_70897f669d74.slice/cri-containerd-8a7542df864f96c79f6b739e3c2a9e1024f0ca4e8a5480788ecd461278600136.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod495568e1_e8c3_4f2e_a8b0_4ee1e906fe7b.slice/cri-containerd-f384a48c362b4cbdd19f00b2551f461ee1e99359a94b017a3cb2f0ae786006e4.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod495568e1_e8c3_4f2e_a8b0_4ee1e906fe7b.slice/cri-containerd-1fcb29650935e19b98ec28673017d96bd4f604b93aecde403f54dfc0438ca84a.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-51596ce12e9e19d74c4f5b52b012d80ef9495e608b0f94dcbfa462a2efa6c2e3.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-1d29f013306928097c66bb0acfc94c9874b5ff12aeafc7d19b402c0350a9a422.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-b0755e8e9ba83b798518e717ac5a428f4ee4840d7779d9349be5647956549b9f.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-ac41de1b7dd9b842e66ffb0f1e54132d0078424e1dcc382d74a47e0b37f1826c.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2e2fe6c_9eae_4427_9d79_c34c149a4bff.slice/cri-containerd-ef30efd2b99d5afc58552a7e1bf2f39f09470ded56b5e69a1296f6bcb91ad336.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode2e2fe6c_9eae_4427_9d79_c34c149a4bff.slice/cri-containerd-37e7aa4eee72cb5d49367d8fd9b29dbfc5cb7127b3ce7441bb5a3a16a6d2868b.scope
    91       cgroup_device   multi                                          
