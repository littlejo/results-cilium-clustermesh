{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.118:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:31.475Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.133.182:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:31.475Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.160.191:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:31.475Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:36.149Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:36.164Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:36.199Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:36.200Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:53:36.213Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:01.325Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:01.325Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:01.326Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:01.356Z",
  "value": "id=1457  sec_id=2471376 flags=0x0000 ifindex=16  mac=46:14:79:A5:BA:15 nodemac=BE:05:88:14:70:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:02.326Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:02.326Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:02.326Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:59:02.327Z",
  "value": "id=1457  sec_id=2471376 flags=0x0000 ifindex=16  mac=46:14:79:A5:BA:15 nodemac=BE:05:88:14:70:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.845Z",
  "value": "id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.74.0.102:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.793Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.518Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.519Z",
  "value": "id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.520Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:36.520Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:37.519Z",
  "value": "id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:37.520Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:37.520Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:37.521Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.520Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.520Z",
  "value": "id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.520Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:38.520Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.19:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.520Z",
  "value": "id=534   sec_id=2464297 flags=0x0000 ifindex=12  mac=46:E6:FF:03:C4:36 nodemac=1E:B2:06:3B:43:93"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.247:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.521Z",
  "value": "id=830   sec_id=2464297 flags=0x0000 ifindex=14  mac=F2:6B:21:00:29:41 nodemac=FA:4A:93:EA:E5:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.165:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.521Z",
  "value": "id=1943  sec_id=2471376 flags=0x0000 ifindex=18  mac=F6:FA:B3:1C:98:EE nodemac=42:94:E8:DB:C0:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.74.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:39.521Z",
  "value": "id=3420  sec_id=4     flags=0x0000 ifindex=10  mac=5A:7B:B1:63:9D:99 nodemac=C2:46:9E:AC:81:5F"
}

