 08:23:00 up 36 min,  0 users,  load average: 0.30, 0.26, 0.19
