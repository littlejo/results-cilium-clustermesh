REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36847     2911730     677    bpf_overlay.c
Interface                 INGRESS     685609    137904613   1132   bpf_host.c
Success                   EGRESS      16535     1301938     1694   bpf_host.c
Success                   EGRESS      302420    37667538    1308   bpf_lxc.c
Success                   EGRESS      37199     2941405     53     encap.h
Success                   INGRESS     346915    39396065    86     l3.h
Success                   INGRESS     367878    41049903    235    trace.h
Unsupported L3 protocol   EGRESS      46        3452        1492   bpf_lxc.c
