KEY             VALUE
AgentLiveness   2207032928248
UTimeOffset     3379442195312500
