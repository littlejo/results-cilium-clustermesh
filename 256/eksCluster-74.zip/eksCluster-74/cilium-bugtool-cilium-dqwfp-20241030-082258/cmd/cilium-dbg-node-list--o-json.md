[
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.0.0.71"
      },
      "ipv6": {}
    },
    "name": "cmesh1/ip-172-31-129-111.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.0.0.0/24",
        "enabled": true,
        "ip": "172.31.129.111"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.0.0.110"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.237.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh238/ip-172-31-226-233.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.237.0.0/24",
        "enabled": true,
        "ip": "172.31.226.233"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.237.0.240"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.169.0.250"
      },
      "ipv6": {}
    },
    "name": "cmesh170/ip-172-31-230-34.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.169.0.0/24",
        "enabled": true,
        "ip": "172.31.230.34"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.169.0.215"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.144.0.89"
      },
      "ipv6": {}
    },
    "name": "cmesh145/ip-172-31-132-52.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.144.0.0/24",
        "enabled": true,
        "ip": "172.31.132.52"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.144.0.121"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.95.0.64"
      },
      "ipv6": {}
    },
    "name": "cmesh96/ip-172-31-214-5.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.95.0.0/24",
        "enabled": true,
        "ip": "172.31.214.5"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.95.0.70"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.213.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh214/ip-172-31-205-133.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.213.0.0/24",
        "enabled": true,
        "ip": "172.31.205.133"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.213.0.28"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.199.0.92"
      },
      "ipv6": {}
    },
    "name": "cmesh200/ip-172-31-205-54.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.199.0.0/24",
        "enabled": true,
        "ip": "172.31.205.54"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.199.0.14"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.35.0.58"
      },
      "ipv6": {}
    },
    "name": "cmesh36/ip-172-31-202-120.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.35.0.0/24",
        "enabled": true,
        "ip": "172.31.202.120"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.35.0.147"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.236.0.21"
      },
      "ipv6": {}
    },
    "name": "cmesh237/ip-172-31-134-110.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.236.0.0/24",
        "enabled": true,
        "ip": "172.31.134.110"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.236.0.22"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.128.0.245"
      },
      "ipv6": {}
    },
    "name": "cmesh129/ip-172-31-189-76.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.128.0.0/24",
        "enabled": true,
        "ip": "172.31.189.76"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.128.0.101"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.223.0.84"
      },
      "ipv6": {}
    },
    "name": "cmesh224/ip-172-31-234-57.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.223.0.0/24",
        "enabled": true,
        "ip": "172.31.234.57"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.223.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.120.0.223"
      },
      "ipv6": {}
    },
    "name": "cmesh121/ip-172-31-138-53.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.120.0.0/24",
        "enabled": true,
        "ip": "172.31.138.53"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.120.0.27"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.45.0.18"
      },
      "ipv6": {}
    },
    "name": "cmesh46/ip-172-31-218-14.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.45.0.0/24",
        "enabled": true,
        "ip": "172.31.218.14"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.45.0.2"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.115.0.241"
      },
      "ipv6": {}
    },
    "name": "cmesh116/ip-172-31-254-132.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.115.0.0/24",
        "enabled": true,
        "ip": "172.31.254.132"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.115.0.3"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.196.0.222"
      },
      "ipv6": {}
    },
    "name": "cmesh197/ip-172-31-145-37.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.196.0.0/24",
        "enabled": true,
        "ip": "172.31.145.37"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.196.0.132"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.137.0.204"
      },
      "ipv6": {}
    },
    "name": "cmesh138/ip-172-31-240-43.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.137.0.0/24",
        "enabled": true,
        "ip": "172.31.240.43"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.137.0.244"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.170.0.200"
      },
      "ipv6": {}
    },
    "name": "cmesh171/ip-172-31-186-20.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.170.0.0/24",
        "enabled": true,
        "ip": "172.31.186.20"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.170.0.83"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.177.0.139"
      },
      "ipv6": {}
    },
    "name": "cmesh178/ip-172-31-201-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.177.0.0/24",
        "enabled": true,
        "ip": "172.31.201.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.177.0.9"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.78.0.194"
      },
      "ipv6": {}
    },
    "name": "cmesh79/ip-172-31-151-179.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.78.0.0/24",
        "enabled": true,
        "ip": "172.31.151.179"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.78.0.187"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.179.0.91"
      },
      "ipv6": {}
    },
    "name": "cmesh180/ip-172-31-242-15.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.179.0.0/24",
        "enabled": true,
        "ip": "172.31.242.15"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.179.0.191"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.36.0.244"
      },
      "ipv6": {}
    },
    "name": "cmesh37/ip-172-31-148-248.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.36.0.0/24",
        "enabled": true,
        "ip": "172.31.148.248"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.36.0.69"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.60.0.164"
      },
      "ipv6": {}
    },
    "name": "cmesh61/ip-172-31-177-157.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.60.0.0/24",
        "enabled": true,
        "ip": "172.31.177.157"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.60.0.75"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.219.0.54"
      },
      "ipv6": {}
    },
    "name": "cmesh220/ip-172-31-216-60.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.219.0.0/24",
        "enabled": true,
        "ip": "172.31.216.60"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.219.0.128"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.162.0.45"
      },
      "ipv6": {}
    },
    "name": "cmesh163/ip-172-31-164-49.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.162.0.0/24",
        "enabled": true,
        "ip": "172.31.164.49"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.162.0.3"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.118.0.202"
      },
      "ipv6": {}
    },
    "name": "cmesh119/ip-172-31-160-70.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.118.0.0/24",
        "enabled": true,
        "ip": "172.31.160.70"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.118.0.108"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.59.0.66"
      },
      "ipv6": {}
    },
    "name": "cmesh60/ip-172-31-237-111.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.59.0.0/24",
        "enabled": true,
        "ip": "172.31.237.111"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.59.0.117"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.57.0.192"
      },
      "ipv6": {}
    },
    "name": "cmesh58/ip-172-31-237-78.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.57.0.0/24",
        "enabled": true,
        "ip": "172.31.237.78"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.57.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.55.0.216"
      },
      "ipv6": {}
    },
    "name": "cmesh56/ip-172-31-227-236.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.55.0.0/24",
        "enabled": true,
        "ip": "172.31.227.236"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.55.0.233"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.14.0.121"
      },
      "ipv6": {}
    },
    "name": "cmesh15/ip-172-31-145-58.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.14.0.0/24",
        "enabled": true,
        "ip": "172.31.145.58"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.14.0.25"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.252.0.219"
      },
      "ipv6": {}
    },
    "name": "cmesh253/ip-172-31-190-227.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.252.0.0/24",
        "enabled": true,
        "ip": "172.31.190.227"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.252.0.246"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.207.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh208/ip-172-31-244-52.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.207.0.0/24",
        "enabled": true,
        "ip": "172.31.244.52"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.207.0.157"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.193.0.49"
      },
      "ipv6": {}
    },
    "name": "cmesh194/ip-172-31-238-226.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.193.0.0/24",
        "enabled": true,
        "ip": "172.31.238.226"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.193.0.37"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.186.0.41"
      },
      "ipv6": {}
    },
    "name": "cmesh187/ip-172-31-180-46.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.186.0.0/24",
        "enabled": true,
        "ip": "172.31.180.46"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.186.0.116"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.212.0.65"
      },
      "ipv6": {}
    },
    "name": "cmesh213/ip-172-31-176-70.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.212.0.0/24",
        "enabled": true,
        "ip": "172.31.176.70"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.212.0.1"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.209.0.136"
      },
      "ipv6": {}
    },
    "name": "cmesh210/ip-172-31-230-218.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.209.0.0/24",
        "enabled": true,
        "ip": "172.31.230.218"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.209.0.226"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.218.0.240"
      },
      "ipv6": {}
    },
    "name": "cmesh219/ip-172-31-149-217.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.218.0.0/24",
        "enabled": true,
        "ip": "172.31.149.217"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.218.0.189"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.3.0.107"
      },
      "ipv6": {}
    },
    "name": "cmesh4/ip-172-31-226-7.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.3.0.0/24",
        "enabled": true,
        "ip": "172.31.226.7"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.3.0.212"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.9.0.30"
      },
      "ipv6": {}
    },
    "name": "cmesh10/ip-172-31-238-115.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.9.0.0/24",
        "enabled": true,
        "ip": "172.31.238.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.9.0.110"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.10.0.230"
      },
      "ipv6": {}
    },
    "name": "cmesh11/ip-172-31-144-15.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.10.0.0/24",
        "enabled": true,
        "ip": "172.31.144.15"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.10.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.240.0.166"
      },
      "ipv6": {}
    },
    "name": "cmesh241/ip-172-31-168-247.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.240.0.0/24",
        "enabled": true,
        "ip": "172.31.168.247"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.240.0.212"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.40.0.125"
      },
      "ipv6": {}
    },
    "name": "cmesh41/ip-172-31-162-144.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.40.0.0/24",
        "enabled": true,
        "ip": "172.31.162.144"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.40.0.196"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.75.0.85"
      },
      "ipv6": {}
    },
    "name": "cmesh76/ip-172-31-195-237.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.75.0.0/24",
        "enabled": true,
        "ip": "172.31.195.237"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.75.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.47.0.17"
      },
      "ipv6": {}
    },
    "name": "cmesh48/ip-172-31-253-19.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.47.0.0/24",
        "enabled": true,
        "ip": "172.31.253.19"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.47.0.179"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.21.0.137"
      },
      "ipv6": {}
    },
    "name": "cmesh22/ip-172-31-219-89.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.21.0.0/24",
        "enabled": true,
        "ip": "172.31.219.89"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.21.0.79"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.15.0.203"
      },
      "ipv6": {}
    },
    "name": "cmesh16/ip-172-31-241-253.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.15.0.0/24",
        "enabled": true,
        "ip": "172.31.241.253"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.15.0.16"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.72.0.7"
      },
      "ipv6": {}
    },
    "name": "cmesh73/ip-172-31-154-219.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.72.0.0/24",
        "enabled": true,
        "ip": "172.31.154.219"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.72.0.172"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.158.0.211"
      },
      "ipv6": {}
    },
    "name": "cmesh159/ip-172-31-137-12.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.158.0.0/24",
        "enabled": true,
        "ip": "172.31.137.12"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.158.0.185"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.93.0.15"
      },
      "ipv6": {}
    },
    "name": "cmesh94/ip-172-31-253-50.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.93.0.0/24",
        "enabled": true,
        "ip": "172.31.253.50"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.93.0.218"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.29.0.183"
      },
      "ipv6": {}
    },
    "name": "cmesh30/ip-172-31-231-174.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.29.0.0/24",
        "enabled": true,
        "ip": "172.31.231.174"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.29.0.229"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.64.0.117"
      },
      "ipv6": {}
    },
    "name": "cmesh65/ip-172-31-165-36.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.64.0.0/24",
        "enabled": true,
        "ip": "172.31.165.36"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.64.0.231"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.77.0.154"
      },
      "ipv6": {}
    },
    "name": "cmesh78/ip-172-31-247-137.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.77.0.0/24",
        "enabled": true,
        "ip": "172.31.247.137"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.77.0.53"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.5.0.225"
      },
      "ipv6": {}
    },
    "name": "cmesh6/ip-172-31-219-104.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.5.0.0/24",
        "enabled": true,
        "ip": "172.31.219.104"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.5.0.183"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.178.0.12"
      },
      "ipv6": {}
    },
    "name": "cmesh179/ip-172-31-169-181.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.178.0.0/24",
        "enabled": true,
        "ip": "172.31.169.181"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.178.0.63"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.139.0.115"
      },
      "ipv6": {}
    },
    "name": "cmesh140/ip-172-31-192-199.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.139.0.0/24",
        "enabled": true,
        "ip": "172.31.192.199"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.139.0.242"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.42.0.221"
      },
      "ipv6": {}
    },
    "name": "cmesh43/ip-172-31-129-213.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.42.0.0/24",
        "enabled": true,
        "ip": "172.31.129.213"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.42.0.108"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.205.0.8"
      },
      "ipv6": {}
    },
    "name": "cmesh206/ip-172-31-195-50.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.205.0.0/24",
        "enabled": true,
        "ip": "172.31.195.50"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.205.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.117.0.54"
      },
      "ipv6": {}
    },
    "name": "cmesh118/ip-172-31-246-191.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.117.0.0/24",
        "enabled": true,
        "ip": "172.31.246.191"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.117.0.112"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.171.0.175"
      },
      "ipv6": {}
    },
    "name": "cmesh172/ip-172-31-197-244.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.171.0.0/24",
        "enabled": true,
        "ip": "172.31.197.244"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.171.0.216"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.116.0.211"
      },
      "ipv6": {}
    },
    "name": "cmesh117/ip-172-31-150-111.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.116.0.0/24",
        "enabled": true,
        "ip": "172.31.150.111"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.116.0.83"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.122.0.221"
      },
      "ipv6": {}
    },
    "name": "cmesh123/ip-172-31-138-178.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.122.0.0/24",
        "enabled": true,
        "ip": "172.31.138.178"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.122.0.75"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.136.0.194"
      },
      "ipv6": {}
    },
    "name": "cmesh137/ip-172-31-140-38.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.136.0.0/24",
        "enabled": true,
        "ip": "172.31.140.38"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.136.0.133"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.25.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh26/ip-172-31-210-57.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.25.0.0/24",
        "enabled": true,
        "ip": "172.31.210.57"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.25.0.58"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.24.0.1"
      },
      "ipv6": {}
    },
    "name": "cmesh25/ip-172-31-171-219.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.24.0.0/24",
        "enabled": true,
        "ip": "172.31.171.219"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.24.0.197"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.26.0.58"
      },
      "ipv6": {}
    },
    "name": "cmesh27/ip-172-31-155-250.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.26.0.0/24",
        "enabled": true,
        "ip": "172.31.155.250"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.26.0.38"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.208.0.131"
      },
      "ipv6": {}
    },
    "name": "cmesh209/ip-172-31-171-115.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.208.0.0/24",
        "enabled": true,
        "ip": "172.31.171.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.208.0.96"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.92.0.73"
      },
      "ipv6": {}
    },
    "name": "cmesh93/ip-172-31-139-231.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.92.0.0/24",
        "enabled": true,
        "ip": "172.31.139.231"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.92.0.181"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.141.0.66"
      },
      "ipv6": {}
    },
    "name": "cmesh142/ip-172-31-219-42.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.141.0.0/24",
        "enabled": true,
        "ip": "172.31.219.42"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.141.0.202"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.189.0.35"
      },
      "ipv6": {}
    },
    "name": "cmesh190/ip-172-31-194-190.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.189.0.0/24",
        "enabled": true,
        "ip": "172.31.194.190"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.189.0.72"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.19.0.254"
      },
      "ipv6": {}
    },
    "name": "cmesh20/ip-172-31-241-81.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.19.0.0/24",
        "enabled": true,
        "ip": "172.31.241.81"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.19.0.189"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.182.0.103"
      },
      "ipv6": {}
    },
    "name": "cmesh183/ip-172-31-154-13.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.182.0.0/24",
        "enabled": true,
        "ip": "172.31.154.13"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.182.0.171"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.62.0.188"
      },
      "ipv6": {}
    },
    "name": "cmesh63/ip-172-31-146-191.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.62.0.0/24",
        "enabled": true,
        "ip": "172.31.146.191"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.62.0.174"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.58.0.217"
      },
      "ipv6": {}
    },
    "name": "cmesh59/ip-172-31-157-22.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.58.0.0/24",
        "enabled": true,
        "ip": "172.31.157.22"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.58.0.15"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.190.0.220"
      },
      "ipv6": {}
    },
    "name": "cmesh191/ip-172-31-163-135.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.190.0.0/24",
        "enabled": true,
        "ip": "172.31.163.135"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.190.0.235"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.79.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh80/ip-172-31-192-135.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.79.0.0/24",
        "enabled": true,
        "ip": "172.31.192.135"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.79.0.13"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.241.0.22"
      },
      "ipv6": {}
    },
    "name": "cmesh242/ip-172-31-225-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.241.0.0/24",
        "enabled": true,
        "ip": "172.31.225.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.241.0.209"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.69.0.74"
      },
      "ipv6": {}
    },
    "name": "cmesh70/ip-172-31-210-245.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.69.0.0/24",
        "enabled": true,
        "ip": "172.31.210.245"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.69.0.34"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.192.0.82"
      },
      "ipv6": {}
    },
    "name": "cmesh193/ip-172-31-170-23.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.192.0.0/24",
        "enabled": true,
        "ip": "172.31.170.23"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.192.0.153"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.239.0.190"
      },
      "ipv6": {}
    },
    "name": "cmesh240/ip-172-31-247-110.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.239.0.0/24",
        "enabled": true,
        "ip": "172.31.247.110"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.239.0.47"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.235.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh236/ip-172-31-200-108.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.235.0.0/24",
        "enabled": true,
        "ip": "172.31.200.108"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.235.0.194"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.157.0.50"
      },
      "ipv6": {}
    },
    "name": "cmesh158/ip-172-31-194-176.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.157.0.0/24",
        "enabled": true,
        "ip": "172.31.194.176"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.157.0.165"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.67.0.176"
      },
      "ipv6": {}
    },
    "name": "cmesh68/ip-172-31-213-86.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.67.0.0/24",
        "enabled": true,
        "ip": "172.31.213.86"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.67.0.142"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.71.0.41"
      },
      "ipv6": {}
    },
    "name": "cmesh72/ip-172-31-209-21.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.71.0.0/24",
        "enabled": true,
        "ip": "172.31.209.21"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.71.0.254"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.152.0.87"
      },
      "ipv6": {}
    },
    "name": "cmesh153/ip-172-31-190-51.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.152.0.0/24",
        "enabled": true,
        "ip": "172.31.190.51"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.152.0.234"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.124.0.207"
      },
      "ipv6": {}
    },
    "name": "cmesh125/ip-172-31-149-67.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.124.0.0/24",
        "enabled": true,
        "ip": "172.31.149.67"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.124.0.127"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.31.0.64"
      },
      "ipv6": {}
    },
    "name": "cmesh32/ip-172-31-222-197.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.31.0.0/24",
        "enabled": true,
        "ip": "172.31.222.197"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.31.0.31"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.150.0.209"
      },
      "ipv6": {}
    },
    "name": "cmesh151/ip-172-31-190-101.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.150.0.0/24",
        "enabled": true,
        "ip": "172.31.190.101"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.150.0.7"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.164.0.229"
      },
      "ipv6": {}
    },
    "name": "cmesh165/ip-172-31-132-35.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.164.0.0/24",
        "enabled": true,
        "ip": "172.31.132.35"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.164.0.234"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.203.0.44"
      },
      "ipv6": {}
    },
    "name": "cmesh204/ip-172-31-244-196.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.203.0.0/24",
        "enabled": true,
        "ip": "172.31.244.196"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.203.0.213"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.180.0.150"
      },
      "ipv6": {}
    },
    "name": "cmesh181/ip-172-31-152-115.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.180.0.0/24",
        "enabled": true,
        "ip": "172.31.152.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.180.0.30"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.131.0.23"
      },
      "ipv6": {}
    },
    "name": "cmesh132/ip-172-31-208-241.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.131.0.0/24",
        "enabled": true,
        "ip": "172.31.208.241"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.131.0.24"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.86.0.89"
      },
      "ipv6": {}
    },
    "name": "cmesh87/ip-172-31-162-134.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.86.0.0/24",
        "enabled": true,
        "ip": "172.31.162.134"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.86.0.33"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.76.0.231"
      },
      "ipv6": {}
    },
    "name": "cmesh77/ip-172-31-185-59.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.76.0.0/24",
        "enabled": true,
        "ip": "172.31.185.59"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.76.0.172"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.149.0.226"
      },
      "ipv6": {}
    },
    "name": "cmesh150/ip-172-31-201-166.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.149.0.0/24",
        "enabled": true,
        "ip": "172.31.201.166"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.149.0.72"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.151.0.73"
      },
      "ipv6": {}
    },
    "name": "cmesh152/ip-172-31-210-247.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.151.0.0/24",
        "enabled": true,
        "ip": "172.31.210.247"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.151.0.202"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.175.0.28"
      },
      "ipv6": {}
    },
    "name": "cmesh176/ip-172-31-192-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.175.0.0/24",
        "enabled": true,
        "ip": "172.31.192.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.175.0.181"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.200.0.240"
      },
      "ipv6": {}
    },
    "name": "cmesh201/ip-172-31-174-157.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.200.0.0/24",
        "enabled": true,
        "ip": "172.31.174.157"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.200.0.192"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.52.0.199"
      },
      "ipv6": {}
    },
    "name": "cmesh53/ip-172-31-153-228.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.52.0.0/24",
        "enabled": true,
        "ip": "172.31.153.228"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.52.0.147"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.167.0.168"
      },
      "ipv6": {}
    },
    "name": "cmesh168/ip-172-31-214-172.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.167.0.0/24",
        "enabled": true,
        "ip": "172.31.214.172"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.167.0.236"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.147.0.155"
      },
      "ipv6": {}
    },
    "name": "cmesh148/ip-172-31-255-51.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.147.0.0/24",
        "enabled": true,
        "ip": "172.31.255.51"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.147.0.73"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.153.0.55"
      },
      "ipv6": {}
    },
    "name": "cmesh154/ip-172-31-218-179.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.153.0.0/24",
        "enabled": true,
        "ip": "172.31.218.179"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.153.0.134"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.112.0.96"
      },
      "ipv6": {}
    },
    "name": "cmesh113/ip-172-31-145-79.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.112.0.0/24",
        "enabled": true,
        "ip": "172.31.145.79"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.112.0.132"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.155.0.219"
      },
      "ipv6": {}
    },
    "name": "cmesh156/ip-172-31-224-54.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.155.0.0/24",
        "enabled": true,
        "ip": "172.31.224.54"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.155.0.32"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.145.0.70"
      },
      "ipv6": {}
    },
    "name": "cmesh146/ip-172-31-238-193.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.145.0.0/24",
        "enabled": true,
        "ip": "172.31.238.193"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.145.0.109"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.106.0.165"
      },
      "ipv6": {}
    },
    "name": "cmesh107/ip-172-31-181-183.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.106.0.0/24",
        "enabled": true,
        "ip": "172.31.181.183"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.106.0.34"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.39.0.31"
      },
      "ipv6": {}
    },
    "name": "cmesh40/ip-172-31-252-16.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.39.0.0/24",
        "enabled": true,
        "ip": "172.31.252.16"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.39.0.24"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.33.0.229"
      },
      "ipv6": {}
    },
    "name": "cmesh34/ip-172-31-250-23.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.33.0.0/24",
        "enabled": true,
        "ip": "172.31.250.23"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.33.0.165"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.246.0.37"
      },
      "ipv6": {}
    },
    "name": "cmesh247/ip-172-31-151-215.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.246.0.0/24",
        "enabled": true,
        "ip": "172.31.151.215"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.246.0.233"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.97.0.62"
      },
      "ipv6": {}
    },
    "name": "cmesh98/ip-172-31-220-44.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.97.0.0/24",
        "enabled": true,
        "ip": "172.31.220.44"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.97.0.210"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.2.0.63"
      },
      "ipv6": {}
    },
    "name": "cmesh3/ip-172-31-178-139.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.2.0.0/24",
        "enabled": true,
        "ip": "172.31.178.139"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.2.0.170"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.84.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh85/ip-172-31-149-34.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.84.0.0/24",
        "enabled": true,
        "ip": "172.31.149.34"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.84.0.35"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.247.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh248/ip-172-31-217-105.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.247.0.0/24",
        "enabled": true,
        "ip": "172.31.217.105"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.247.0.69"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.82.0.97"
      },
      "ipv6": {}
    },
    "name": "cmesh83/ip-172-31-164-11.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.82.0.0/24",
        "enabled": true,
        "ip": "172.31.164.11"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.82.0.149"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.148.0.156"
      },
      "ipv6": {}
    },
    "name": "cmesh149/ip-172-31-175-74.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.148.0.0/24",
        "enabled": true,
        "ip": "172.31.175.74"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.148.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.32.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh33/ip-172-31-172-199.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.32.0.0/24",
        "enabled": true,
        "ip": "172.31.172.199"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.32.0.221"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.83.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh84/ip-172-31-210-93.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.83.0.0/24",
        "enabled": true,
        "ip": "172.31.210.93"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.83.0.165"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.176.0.28"
      },
      "ipv6": {}
    },
    "name": "cmesh177/ip-172-31-181-74.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.176.0.0/24",
        "enabled": true,
        "ip": "172.31.181.74"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.176.0.21"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.165.0.38"
      },
      "ipv6": {}
    },
    "name": "cmesh166/ip-172-31-217-164.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.165.0.0/24",
        "enabled": true,
        "ip": "172.31.217.164"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.165.0.172"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.233.0.53"
      },
      "ipv6": {}
    },
    "name": "cmesh234/ip-172-31-202-43.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.233.0.0/24",
        "enabled": true,
        "ip": "172.31.202.43"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.233.0.205"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.123.0.63"
      },
      "ipv6": {}
    },
    "name": "cmesh124/ip-172-31-210-31.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.123.0.0/24",
        "enabled": true,
        "ip": "172.31.210.31"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.123.0.107"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.230.0.189"
      },
      "ipv6": {}
    },
    "name": "cmesh231/ip-172-31-138-46.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.230.0.0/24",
        "enabled": true,
        "ip": "172.31.138.46"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.230.0.152"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.214.0.126"
      },
      "ipv6": {}
    },
    "name": "cmesh215/ip-172-31-135-249.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.214.0.0/24",
        "enabled": true,
        "ip": "172.31.135.249"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.214.0.94"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.238.0.184"
      },
      "ipv6": {}
    },
    "name": "cmesh239/ip-172-31-148-36.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.238.0.0/24",
        "enabled": true,
        "ip": "172.31.148.36"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.238.0.149"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.215.0.41"
      },
      "ipv6": {}
    },
    "name": "cmesh216/ip-172-31-248-161.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.215.0.0/24",
        "enabled": true,
        "ip": "172.31.248.161"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.215.0.187"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.13.0.138"
      },
      "ipv6": {}
    },
    "name": "cmesh14/ip-172-31-193-152.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.13.0.0/24",
        "enabled": true,
        "ip": "172.31.193.152"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.13.0.250"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.48.0.7"
      },
      "ipv6": {}
    },
    "name": "cmesh49/ip-172-31-162-77.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.48.0.0/24",
        "enabled": true,
        "ip": "172.31.162.77"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.48.0.126"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.161.0.56"
      },
      "ipv6": {}
    },
    "name": "cmesh162/ip-172-31-233-29.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.161.0.0/24",
        "enabled": true,
        "ip": "172.31.233.29"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.161.0.125"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.81.0.185"
      },
      "ipv6": {}
    },
    "name": "cmesh82/ip-172-31-217-76.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.81.0.0/24",
        "enabled": true,
        "ip": "172.31.217.76"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.81.0.66"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.49.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh50/ip-172-31-216-105.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.49.0.0/24",
        "enabled": true,
        "ip": "172.31.216.105"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.49.0.249"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.229.0.125"
      },
      "ipv6": {}
    },
    "name": "cmesh230/ip-172-31-218-213.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.229.0.0/24",
        "enabled": true,
        "ip": "172.31.218.213"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.229.0.174"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.43.0.113"
      },
      "ipv6": {}
    },
    "name": "cmesh44/ip-172-31-231-5.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.43.0.0/24",
        "enabled": true,
        "ip": "172.31.231.5"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.43.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.244.0.137"
      },
      "ipv6": {}
    },
    "name": "cmesh245/ip-172-31-143-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.244.0.0/24",
        "enabled": true,
        "ip": "172.31.143.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.244.0.184"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.61.0.234"
      },
      "ipv6": {}
    },
    "name": "cmesh62/ip-172-31-221-85.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.61.0.0/24",
        "enabled": true,
        "ip": "172.31.221.85"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.61.0.126"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.111.0.228"
      },
      "ipv6": {}
    },
    "name": "cmesh112/ip-172-31-199-216.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.111.0.0/24",
        "enabled": true,
        "ip": "172.31.199.216"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.111.0.155"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.105.0.124"
      },
      "ipv6": {}
    },
    "name": "cmesh106/ip-172-31-250-86.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.105.0.0/24",
        "enabled": true,
        "ip": "172.31.250.86"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.105.0.110"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.255.0.20"
      },
      "ipv6": {}
    },
    "name": "cmesh256/ip-172-31-249-38.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.255.0.0/24",
        "enabled": true,
        "ip": "172.31.249.38"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.255.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.109.0.166"
      },
      "ipv6": {}
    },
    "name": "cmesh110/ip-172-31-242-123.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.109.0.0/24",
        "enabled": true,
        "ip": "172.31.242.123"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.109.0.86"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.22.0.84"
      },
      "ipv6": {}
    },
    "name": "cmesh23/ip-172-31-172-110.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.22.0.0/24",
        "enabled": true,
        "ip": "172.31.172.110"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.22.0.153"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.51.0.202"
      },
      "ipv6": {}
    },
    "name": "cmesh52/ip-172-31-250-78.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.51.0.0/24",
        "enabled": true,
        "ip": "172.31.250.78"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.51.0.237"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.187.0.232"
      },
      "ipv6": {}
    },
    "name": "cmesh188/ip-172-31-242-2.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.187.0.0/24",
        "enabled": true,
        "ip": "172.31.242.2"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.187.0.76"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.143.0.23"
      },
      "ipv6": {}
    },
    "name": "cmesh144/ip-172-31-222-170.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.143.0.0/24",
        "enabled": true,
        "ip": "172.31.222.170"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.143.0.35"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.80.0.129"
      },
      "ipv6": {}
    },
    "name": "cmesh81/ip-172-31-140-137.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.80.0.0/24",
        "enabled": true,
        "ip": "172.31.140.137"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.80.0.244"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.227.0.103"
      },
      "ipv6": {}
    },
    "name": "cmesh228/ip-172-31-245-124.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.227.0.0/24",
        "enabled": true,
        "ip": "172.31.245.124"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.227.0.57"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.232.0.106"
      },
      "ipv6": {}
    },
    "name": "cmesh233/ip-172-31-189-68.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.232.0.0/24",
        "enabled": true,
        "ip": "172.31.189.68"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.232.0.183"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.20.0.119"
      },
      "ipv6": {}
    },
    "name": "cmesh21/ip-172-31-175-194.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.20.0.0/24",
        "enabled": true,
        "ip": "172.31.175.194"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.20.0.125"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.221.0.107"
      },
      "ipv6": {}
    },
    "name": "cmesh222/ip-172-31-212-27.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.221.0.0/24",
        "enabled": true,
        "ip": "172.31.212.27"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.221.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.66.0.226"
      },
      "ipv6": {}
    },
    "name": "cmesh67/ip-172-31-159-51.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.66.0.0/24",
        "enabled": true,
        "ip": "172.31.159.51"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.66.0.136"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.6.0.26"
      },
      "ipv6": {}
    },
    "name": "cmesh7/ip-172-31-154-145.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.6.0.0/24",
        "enabled": true,
        "ip": "172.31.154.145"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.6.0.84"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.197.0.51"
      },
      "ipv6": {}
    },
    "name": "cmesh198/ip-172-31-232-195.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.197.0.0/24",
        "enabled": true,
        "ip": "172.31.232.195"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.197.0.247"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.73.0.34"
      },
      "ipv6": {}
    },
    "name": "cmesh74/ip-172-31-193-140.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.73.0.0/24",
        "enabled": true,
        "ip": "172.31.193.140"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.73.0.198"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.242.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh243/ip-172-31-167-121.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.242.0.0/24",
        "enabled": true,
        "ip": "172.31.167.121"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.242.0.232"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.160.0.1"
      },
      "ipv6": {}
    },
    "name": "cmesh161/ip-172-31-169-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.160.0.0/24",
        "enabled": true,
        "ip": "172.31.169.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.160.0.67"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.133.0.84"
      },
      "ipv6": {}
    },
    "name": "cmesh134/ip-172-31-198-209.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.133.0.0/24",
        "enabled": true,
        "ip": "172.31.198.209"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.133.0.45"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.63.0.110"
      },
      "ipv6": {}
    },
    "name": "cmesh64/ip-172-31-232-42.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.63.0.0/24",
        "enabled": true,
        "ip": "172.31.232.42"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.63.0.235"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.7.0.157"
      },
      "ipv6": {}
    },
    "name": "cmesh8/ip-172-31-250-177.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.7.0.0/24",
        "enabled": true,
        "ip": "172.31.250.177"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.7.0.216"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.12.0.158"
      },
      "ipv6": {}
    },
    "name": "cmesh13/ip-172-31-151-115.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.12.0.0/24",
        "enabled": true,
        "ip": "172.31.151.115"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.12.0.231"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.166.0.205"
      },
      "ipv6": {}
    },
    "name": "cmesh167/ip-172-31-178-44.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.166.0.0/24",
        "enabled": true,
        "ip": "172.31.178.44"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.166.0.247"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.41.0.254"
      },
      "ipv6": {}
    },
    "name": "cmesh42/ip-172-31-192-60.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.41.0.0/24",
        "enabled": true,
        "ip": "172.31.192.60"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.41.0.42"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.46.0.226"
      },
      "ipv6": {}
    },
    "name": "cmesh47/ip-172-31-130-28.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.46.0.0/24",
        "enabled": true,
        "ip": "172.31.130.28"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.46.0.220"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.184.0.193"
      },
      "ipv6": {}
    },
    "name": "cmesh185/ip-172-31-183-204.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.184.0.0/24",
        "enabled": true,
        "ip": "172.31.183.204"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.184.0.70"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.172.0.215"
      },
      "ipv6": {}
    },
    "name": "cmesh173/ip-172-31-136-100.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.172.0.0/24",
        "enabled": true,
        "ip": "172.31.136.100"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.172.0.86"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.140.0.88"
      },
      "ipv6": {}
    },
    "name": "cmesh141/ip-172-31-184-128.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.140.0.0/24",
        "enabled": true,
        "ip": "172.31.184.128"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.140.0.229"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.222.0.117"
      },
      "ipv6": {}
    },
    "name": "cmesh223/ip-172-31-180-162.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.222.0.0/24",
        "enabled": true,
        "ip": "172.31.180.162"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.222.0.136"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.101.0.72"
      },
      "ipv6": {}
    },
    "name": "cmesh102/ip-172-31-255-237.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.101.0.0/24",
        "enabled": true,
        "ip": "172.31.255.237"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.101.0.103"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.211.0.239"
      },
      "ipv6": {}
    },
    "name": "cmesh212/ip-172-31-214-171.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.211.0.0/24",
        "enabled": true,
        "ip": "172.31.214.171"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.211.0.19"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.181.0.226"
      },
      "ipv6": {}
    },
    "name": "cmesh182/ip-172-31-194-217.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.181.0.0/24",
        "enabled": true,
        "ip": "172.31.194.217"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.181.0.57"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.30.0.211"
      },
      "ipv6": {}
    },
    "name": "cmesh31/ip-172-31-183-179.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.30.0.0/24",
        "enabled": true,
        "ip": "172.31.183.179"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.30.0.199"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.74.0.9"
      },
      "ipv6": {}
    },
    "name": "cmesh75/ip-172-31-133-182.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.74.0.0/24",
        "enabled": true,
        "ip": "172.31.133.182"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.74.0.118"
      }
    ],
    "source": "local"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.231.0.21"
      },
      "ipv6": {}
    },
    "name": "cmesh232/ip-172-31-219-47.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.231.0.0/24",
        "enabled": true,
        "ip": "172.31.219.47"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.231.0.9"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.198.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh199/ip-172-31-146-99.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.198.0.0/24",
        "enabled": true,
        "ip": "172.31.146.99"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.198.0.167"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.8.0.22"
      },
      "ipv6": {}
    },
    "name": "cmesh9/ip-172-31-179-121.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.8.0.0/24",
        "enabled": true,
        "ip": "172.31.179.121"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.8.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.183.0.16"
      },
      "ipv6": {}
    },
    "name": "cmesh184/ip-172-31-233-71.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.183.0.0/24",
        "enabled": true,
        "ip": "172.31.233.71"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.183.0.107"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.70.0.195"
      },
      "ipv6": {}
    },
    "name": "cmesh71/ip-172-31-181-32.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.70.0.0/24",
        "enabled": true,
        "ip": "172.31.181.32"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.70.0.126"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.174.0.181"
      },
      "ipv6": {}
    },
    "name": "cmesh175/ip-172-31-129-133.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.174.0.0/24",
        "enabled": true,
        "ip": "172.31.129.133"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.174.0.109"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.113.0.25"
      },
      "ipv6": {}
    },
    "name": "cmesh114/ip-172-31-234-247.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.113.0.0/24",
        "enabled": true,
        "ip": "172.31.234.247"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.113.0.67"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.130.0.195"
      },
      "ipv6": {}
    },
    "name": "cmesh131/ip-172-31-130-213.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.130.0.0/24",
        "enabled": true,
        "ip": "172.31.130.213"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.130.0.14"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.185.0.59"
      },
      "ipv6": {}
    },
    "name": "cmesh186/ip-172-31-238-57.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.185.0.0/24",
        "enabled": true,
        "ip": "172.31.238.57"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.185.0.231"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.154.0.91"
      },
      "ipv6": {}
    },
    "name": "cmesh155/ip-172-31-143-150.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.154.0.0/24",
        "enabled": true,
        "ip": "172.31.143.150"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.154.0.45"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.18.0.87"
      },
      "ipv6": {}
    },
    "name": "cmesh19/ip-172-31-159-147.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.18.0.0/24",
        "enabled": true,
        "ip": "172.31.159.147"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.18.0.58"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.104.0.83"
      },
      "ipv6": {}
    },
    "name": "cmesh105/ip-172-31-177-69.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.104.0.0/24",
        "enabled": true,
        "ip": "172.31.177.69"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.104.0.194"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.201.0.174"
      },
      "ipv6": {}
    },
    "name": "cmesh202/ip-172-31-224-57.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.201.0.0/24",
        "enabled": true,
        "ip": "172.31.224.57"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.201.0.168"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.195.0.20"
      },
      "ipv6": {}
    },
    "name": "cmesh196/ip-172-31-211-96.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.195.0.0/24",
        "enabled": true,
        "ip": "172.31.211.96"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.195.0.203"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.50.0.218"
      },
      "ipv6": {}
    },
    "name": "cmesh51/ip-172-31-186-245.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.50.0.0/24",
        "enabled": true,
        "ip": "172.31.186.245"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.50.0.234"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.132.0.71"
      },
      "ipv6": {}
    },
    "name": "cmesh133/ip-172-31-154-190.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.132.0.0/24",
        "enabled": true,
        "ip": "172.31.154.190"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.132.0.211"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.23.0.199"
      },
      "ipv6": {}
    },
    "name": "cmesh24/ip-172-31-198-128.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.23.0.0/24",
        "enabled": true,
        "ip": "172.31.198.128"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.23.0.219"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.121.0.17"
      },
      "ipv6": {}
    },
    "name": "cmesh122/ip-172-31-197-64.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.121.0.0/24",
        "enabled": true,
        "ip": "172.31.197.64"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.121.0.57"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.27.0.105"
      },
      "ipv6": {}
    },
    "name": "cmesh28/ip-172-31-193-237.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.27.0.0/24",
        "enabled": true,
        "ip": "172.31.193.237"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.27.0.232"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.85.0.116"
      },
      "ipv6": {}
    },
    "name": "cmesh86/ip-172-31-238-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.85.0.0/24",
        "enabled": true,
        "ip": "172.31.238.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.85.0.29"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.226.0.230"
      },
      "ipv6": {}
    },
    "name": "cmesh227/ip-172-31-177-98.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.226.0.0/24",
        "enabled": true,
        "ip": "172.31.177.98"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.226.0.130"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.251.0.229"
      },
      "ipv6": {}
    },
    "name": "cmesh252/ip-172-31-247-176.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.251.0.0/24",
        "enabled": true,
        "ip": "172.31.247.176"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.251.0.173"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.129.0.145"
      },
      "ipv6": {}
    },
    "name": "cmesh130/ip-172-31-202-148.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.129.0.0/24",
        "enabled": true,
        "ip": "172.31.202.148"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.129.0.100"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.204.0.236"
      },
      "ipv6": {}
    },
    "name": "cmesh205/ip-172-31-177-23.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.204.0.0/24",
        "enabled": true,
        "ip": "172.31.177.23"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.204.0.111"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.173.0.151"
      },
      "ipv6": {}
    },
    "name": "cmesh174/ip-172-31-231-64.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.173.0.0/24",
        "enabled": true,
        "ip": "172.31.231.64"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.173.0.164"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.65.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh66/ip-172-31-209-31.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.65.0.0/24",
        "enabled": true,
        "ip": "172.31.209.31"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.65.0.74"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.44.0.81"
      },
      "ipv6": {}
    },
    "name": "cmesh45/ip-172-31-146-155.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.44.0.0/24",
        "enabled": true,
        "ip": "172.31.146.155"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.44.0.86"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.87.0.189"
      },
      "ipv6": {}
    },
    "name": "cmesh88/ip-172-31-214-37.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.87.0.0/24",
        "enabled": true,
        "ip": "172.31.214.37"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.87.0.48"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.254.0.114"
      },
      "ipv6": {}
    },
    "name": "cmesh255/ip-172-31-158-156.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.254.0.0/24",
        "enabled": true,
        "ip": "172.31.158.156"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.254.0.159"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.202.0.160"
      },
      "ipv6": {}
    },
    "name": "cmesh203/ip-172-31-143-84.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.202.0.0/24",
        "enabled": true,
        "ip": "172.31.143.84"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.202.0.241"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.88.0.77"
      },
      "ipv6": {}
    },
    "name": "cmesh89/ip-172-31-166-5.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.88.0.0/24",
        "enabled": true,
        "ip": "172.31.166.5"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.88.0.228"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.114.0.218"
      },
      "ipv6": {}
    },
    "name": "cmesh115/ip-172-31-187-38.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.114.0.0/24",
        "enabled": true,
        "ip": "172.31.187.38"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.114.0.106"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.37.0.125"
      },
      "ipv6": {}
    },
    "name": "cmesh38/ip-172-31-227-217.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.37.0.0/24",
        "enabled": true,
        "ip": "172.31.227.217"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.37.0.187"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.38.0.45"
      },
      "ipv6": {}
    },
    "name": "cmesh39/ip-172-31-189-138.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.38.0.0/24",
        "enabled": true,
        "ip": "172.31.189.138"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.38.0.10"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.138.0.133"
      },
      "ipv6": {}
    },
    "name": "cmesh139/ip-172-31-148-213.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.138.0.0/24",
        "enabled": true,
        "ip": "172.31.148.213"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.138.0.227"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.90.0.197"
      },
      "ipv6": {}
    },
    "name": "cmesh91/ip-172-31-155-193.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.90.0.0/24",
        "enabled": true,
        "ip": "172.31.155.193"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.90.0.170"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.99.0.143"
      },
      "ipv6": {}
    },
    "name": "cmesh100/ip-172-31-202-187.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.99.0.0/24",
        "enabled": true,
        "ip": "172.31.202.187"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.99.0.191"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.103.0.97"
      },
      "ipv6": {}
    },
    "name": "cmesh104/ip-172-31-251-68.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.103.0.0/24",
        "enabled": true,
        "ip": "172.31.251.68"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.103.0.82"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.245.0.7"
      },
      "ipv6": {}
    },
    "name": "cmesh246/ip-172-31-254-192.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.245.0.0/24",
        "enabled": true,
        "ip": "172.31.254.192"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.245.0.232"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.234.0.97"
      },
      "ipv6": {}
    },
    "name": "cmesh235/ip-172-31-167-143.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.234.0.0/24",
        "enabled": true,
        "ip": "172.31.167.143"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.234.0.91"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.89.0.159"
      },
      "ipv6": {}
    },
    "name": "cmesh90/ip-172-31-225-122.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.89.0.0/24",
        "enabled": true,
        "ip": "172.31.225.122"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.89.0.164"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.194.0.247"
      },
      "ipv6": {}
    },
    "name": "cmesh195/ip-172-31-167-218.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.194.0.0/24",
        "enabled": true,
        "ip": "172.31.167.218"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.194.0.30"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.28.0.243"
      },
      "ipv6": {}
    },
    "name": "cmesh29/ip-172-31-152-77.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.28.0.0/24",
        "enabled": true,
        "ip": "172.31.152.77"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.28.0.148"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.216.0.142"
      },
      "ipv6": {}
    },
    "name": "cmesh217/ip-172-31-142-17.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.216.0.0/24",
        "enabled": true,
        "ip": "172.31.142.17"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.216.0.222"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.156.0.114"
      },
      "ipv6": {}
    },
    "name": "cmesh157/ip-172-31-161-63.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.156.0.0/24",
        "enabled": true,
        "ip": "172.31.161.63"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.156.0.191"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.249.0.232"
      },
      "ipv6": {}
    },
    "name": "cmesh250/ip-172-31-223-254.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.249.0.0/24",
        "enabled": true,
        "ip": "172.31.223.254"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.249.0.57"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.125.0.76"
      },
      "ipv6": {}
    },
    "name": "cmesh126/ip-172-31-225-47.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.125.0.0/24",
        "enabled": true,
        "ip": "172.31.225.47"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.125.0.74"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.248.0.105"
      },
      "ipv6": {}
    },
    "name": "cmesh249/ip-172-31-191-30.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.248.0.0/24",
        "enabled": true,
        "ip": "172.31.191.30"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.248.0.25"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.146.0.213"
      },
      "ipv6": {}
    },
    "name": "cmesh147/ip-172-31-159-14.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.146.0.0/24",
        "enabled": true,
        "ip": "172.31.159.14"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.146.0.99"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.142.0.233"
      },
      "ipv6": {}
    },
    "name": "cmesh143/ip-172-31-136-110.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.142.0.0/24",
        "enabled": true,
        "ip": "172.31.136.110"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.142.0.248"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.119.0.224"
      },
      "ipv6": {}
    },
    "name": "cmesh120/ip-172-31-192-187.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.119.0.0/24",
        "enabled": true,
        "ip": "172.31.192.187"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.119.0.185"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.188.0.102"
      },
      "ipv6": {}
    },
    "name": "cmesh189/ip-172-31-189-46.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.188.0.0/24",
        "enabled": true,
        "ip": "172.31.189.46"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.188.0.47"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.53.0.127"
      },
      "ipv6": {}
    },
    "name": "cmesh54/ip-172-31-235-129.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.53.0.0/24",
        "enabled": true,
        "ip": "172.31.235.129"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.53.0.2"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.159.0.199"
      },
      "ipv6": {}
    },
    "name": "cmesh160/ip-172-31-243-44.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.159.0.0/24",
        "enabled": true,
        "ip": "172.31.243.44"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.159.0.194"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.96.0.68"
      },
      "ipv6": {}
    },
    "name": "cmesh97/ip-172-31-175-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.96.0.0/24",
        "enabled": true,
        "ip": "172.31.175.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.96.0.152"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.224.0.20"
      },
      "ipv6": {}
    },
    "name": "cmesh225/ip-172-31-132-154.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.224.0.0/24",
        "enabled": true,
        "ip": "172.31.132.154"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.224.0.123"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.126.0.244"
      },
      "ipv6": {}
    },
    "name": "cmesh127/ip-172-31-190-244.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.126.0.0/24",
        "enabled": true,
        "ip": "172.31.190.244"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.126.0.84"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.163.0.68"
      },
      "ipv6": {}
    },
    "name": "cmesh164/ip-172-31-234-82.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.163.0.0/24",
        "enabled": true,
        "ip": "172.31.234.82"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.163.0.24"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.102.0.39"
      },
      "ipv6": {}
    },
    "name": "cmesh103/ip-172-31-145-117.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.102.0.0/24",
        "enabled": true,
        "ip": "172.31.145.117"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.102.0.165"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.210.0.34"
      },
      "ipv6": {}
    },
    "name": "cmesh211/ip-172-31-156-152.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.210.0.0/24",
        "enabled": true,
        "ip": "172.31.156.152"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.210.0.4"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.68.0.87"
      },
      "ipv6": {}
    },
    "name": "cmesh69/ip-172-31-164-224.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.68.0.0/24",
        "enabled": true,
        "ip": "172.31.164.224"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.68.0.114"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.168.0.52"
      },
      "ipv6": {}
    },
    "name": "cmesh169/ip-172-31-152-47.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.168.0.0/24",
        "enabled": true,
        "ip": "172.31.152.47"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.168.0.192"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.91.0.42"
      },
      "ipv6": {}
    },
    "name": "cmesh92/ip-172-31-250-18.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.91.0.0/24",
        "enabled": true,
        "ip": "172.31.250.18"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.91.0.70"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.127.0.163"
      },
      "ipv6": {}
    },
    "name": "cmesh128/ip-172-31-197-3.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.127.0.0/24",
        "enabled": true,
        "ip": "172.31.197.3"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.127.0.95"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.98.0.149"
      },
      "ipv6": {}
    },
    "name": "cmesh99/ip-172-31-139-133.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.98.0.0/24",
        "enabled": true,
        "ip": "172.31.139.133"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.98.0.68"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.134.0.191"
      },
      "ipv6": {}
    },
    "name": "cmesh135/ip-172-31-128-28.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.134.0.0/24",
        "enabled": true,
        "ip": "172.31.128.28"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.134.0.225"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.206.0.19"
      },
      "ipv6": {}
    },
    "name": "cmesh207/ip-172-31-164-108.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.206.0.0/24",
        "enabled": true,
        "ip": "172.31.164.108"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.206.0.215"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.17.0.33"
      },
      "ipv6": {}
    },
    "name": "cmesh18/ip-172-31-194-203.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.17.0.0/24",
        "enabled": true,
        "ip": "172.31.194.203"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.17.0.137"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.228.0.144"
      },
      "ipv6": {}
    },
    "name": "cmesh229/ip-172-31-148-66.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.228.0.0/24",
        "enabled": true,
        "ip": "172.31.148.66"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.228.0.67"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.250.0.171"
      },
      "ipv6": {}
    },
    "name": "cmesh251/ip-172-31-130-97.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.250.0.0/24",
        "enabled": true,
        "ip": "172.31.130.97"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.250.0.83"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.217.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh218/ip-172-31-250-164.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.217.0.0/24",
        "enabled": true,
        "ip": "172.31.250.164"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.217.0.200"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.107.0.117"
      },
      "ipv6": {}
    },
    "name": "cmesh108/ip-172-31-214-227.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.107.0.0/24",
        "enabled": true,
        "ip": "172.31.214.227"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.107.0.243"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.220.0.35"
      },
      "ipv6": {}
    },
    "name": "cmesh221/ip-172-31-178-150.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.220.0.0/24",
        "enabled": true,
        "ip": "172.31.178.150"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.220.0.60"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.243.0.177"
      },
      "ipv6": {}
    },
    "name": "cmesh244/ip-172-31-196-138.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.243.0.0/24",
        "enabled": true,
        "ip": "172.31.196.138"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.243.0.50"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.16.0.238"
      },
      "ipv6": {}
    },
    "name": "cmesh17/ip-172-31-143-246.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.16.0.0/24",
        "enabled": true,
        "ip": "172.31.143.246"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.16.0.142"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.4.0.217"
      },
      "ipv6": {}
    },
    "name": "cmesh5/ip-172-31-188-9.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.4.0.0/24",
        "enabled": true,
        "ip": "172.31.188.9"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.4.0.170"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.135.0.201"
      },
      "ipv6": {}
    },
    "name": "cmesh136/ip-172-31-197-13.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.135.0.0/24",
        "enabled": true,
        "ip": "172.31.197.13"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.135.0.160"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.34.0.94"
      },
      "ipv6": {}
    },
    "name": "cmesh35/ip-172-31-186-233.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.34.0.0/24",
        "enabled": true,
        "ip": "172.31.186.233"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.34.0.70"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.100.0.173"
      },
      "ipv6": {}
    },
    "name": "cmesh101/ip-172-31-156-41.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.100.0.0/24",
        "enabled": true,
        "ip": "172.31.156.41"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.100.0.160"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.225.0.150"
      },
      "ipv6": {}
    },
    "name": "cmesh226/ip-172-31-212-55.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.225.0.0/24",
        "enabled": true,
        "ip": "172.31.212.55"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.225.0.144"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.11.0.96"
      },
      "ipv6": {}
    },
    "name": "cmesh12/ip-172-31-201-141.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.11.0.0/24",
        "enabled": true,
        "ip": "172.31.201.141"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.11.0.183"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.108.0.210"
      },
      "ipv6": {}
    },
    "name": "cmesh109/ip-172-31-170-46.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.108.0.0/24",
        "enabled": true,
        "ip": "172.31.170.46"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.108.0.39"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.1.0.120"
      },
      "ipv6": {}
    },
    "name": "cmesh2/ip-172-31-198-203.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.1.0.0/24",
        "enabled": true,
        "ip": "172.31.198.203"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.1.0.234"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.191.0.121"
      },
      "ipv6": {}
    },
    "name": "cmesh192/ip-172-31-233-108.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.191.0.0/24",
        "enabled": true,
        "ip": "172.31.233.108"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.191.0.239"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.56.0.66"
      },
      "ipv6": {}
    },
    "name": "cmesh57/ip-172-31-133-234.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.56.0.0/24",
        "enabled": true,
        "ip": "172.31.133.234"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.56.0.171"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.110.0.183"
      },
      "ipv6": {}
    },
    "name": "cmesh111/ip-172-31-152-250.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.110.0.0/24",
        "enabled": true,
        "ip": "172.31.152.250"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.110.0.102"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.54.0.9"
      },
      "ipv6": {}
    },
    "name": "cmesh55/ip-172-31-170-243.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.54.0.0/24",
        "enabled": true,
        "ip": "172.31.170.243"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.54.0.203"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.94.0.166"
      },
      "ipv6": {}
    },
    "name": "cmesh95/ip-172-31-135-220.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.94.0.0/24",
        "enabled": true,
        "ip": "172.31.135.220"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.94.0.89"
      }
    ],
    "source": "clustermesh"
  },
  {
    "health-endpoint-address": {
      "ipv4": {
        "enabled": true,
        "ip": "10.253.0.105"
      },
      "ipv6": {}
    },
    "name": "cmesh254/ip-172-31-194-196.eu-west-3.compute.internal",
    "primary-address": {
      "ipv4": {
        "alloc-range": "10.253.0.0/24",
        "enabled": true,
        "ip": "172.31.194.196"
      },
      "ipv6": {}
    },
    "secondary-addresses": [
      {
        "ip": "10.253.0.108"
      }
    ],
    "source": "clustermesh"
  }
]

