[
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod29edc064_aaa5_46ed_8649_d9a8cadd677b.slice/cri-containerd-d4773936142b44703acf99d3168474ca23b4d45cf81a7a31989d705cfbc487cc.scope"
      }
    ],
    "ips": [
      "10.74.0.19"
    ],
    "name": "coredns-cc6ccd49c-cns7p",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-1d29f013306928097c66bb0acfc94c9874b5ff12aeafc7d19b402c0350a9a422.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-ac41de1b7dd9b842e66ffb0f1e54132d0078424e1dcc382d74a47e0b37f1826c.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4b0417de_0f77_4781_90c7_36e20d8d252b.slice/cri-containerd-51596ce12e9e19d74c4f5b52b012d80ef9495e608b0f94dcbfa462a2efa6c2e3.scope"
      }
    ],
    "ips": [
      "10.74.0.165"
    ],
    "name": "clustermesh-apiserver-66d9dcdfbb-mrn5l",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podebe21fb9_6c6a_466b_a80f_70897f669d74.slice/cri-containerd-8a7542df864f96c79f6b739e3c2a9e1024f0ca4e8a5480788ecd461278600136.scope"
      }
    ],
    "ips": [
      "10.74.0.247"
    ],
    "name": "coredns-cc6ccd49c-ncs9s",
    "namespace": "kube-system"
  }
]

