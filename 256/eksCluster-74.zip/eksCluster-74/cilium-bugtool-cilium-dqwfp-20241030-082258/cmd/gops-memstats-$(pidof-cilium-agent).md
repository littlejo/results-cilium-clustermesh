alloc: 148.47MB (155680280 bytes)
total-alloc: 2.51GB (2690327128 bytes)
sys: 329.02MB (345002340 bytes)
lookups: 0
mallocs: 67094058
frees: 65490866
heap-alloc: 148.47MB (155680280 bytes)
heap-sys: 248.60MB (260677632 bytes)
heap-idle: 63.45MB (66535424 bytes)
heap-in-use: 185.15MB (194142208 bytes)
heap-released: 1.07MB (1122304 bytes)
heap-objects: 1603192
stack-in-use: 67.38MB (70647808 bytes)
stack-sys: 67.38MB (70647808 bytes)
stack-mspan-inuse: 3.17MB (3324480 bytes)
stack-mspan-sys: 3.94MB (4128960 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.06MB (1106337 bytes)
gc-sys: 6.03MB (6327928 bytes)
next-gc: when heap-alloc >= 214.98MB (225419528 bytes)
last-gc: 2024-10-30 08:23:05.580271279 +0000 UTC
gc-pause-total: 10.983747ms
gc-pause: 299206
gc-pause-end: 1730276585580271279
num-gc: 88
num-forced-gc: 0
gc-cpu-fraction: 0.0004970341965243743
enable-gc: true
debug-gc: false
