key: 80 02 00 00  value: 21 02 00 00
key: 8a 02 00 00  value: 7f 02 00 00
key: 28 03 00 00  value: 0e 02 00 00
key: 25 0f 00 00  value: 25 02 00 00
Found 4 elements
