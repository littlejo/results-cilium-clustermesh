CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c102b8_30db_492e_b7ae_464dfe2a9e2b.slice/cri-containerd-44b15ed6d68e657ed962b0eef6e8d787aaa2200c1c1d2893641806818ae6d19b.scope
    495      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c102b8_30db_492e_b7ae_464dfe2a9e2b.slice/cri-containerd-4c4f4c283a2ce9256eb24f816e41c3cb607b3cacf089415fb06822e003325d30.scope
    499      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb8bd9a9_a607_4eed_8978_46301a455d5a.slice/cri-containerd-b2190177c8dfc3a9ff90a0f8175f17ded75e8b5e5a214be883da0e6a362c273f.scope
    566      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb8bd9a9_a607_4eed_8978_46301a455d5a.slice/cri-containerd-2b40269e790700e8c5e7833698cdcd484591a559146dca7729d71cbd9bfffcd5.scope
    553      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4ffe8d9_fba4_4bf3_bc4a_205aad089896.slice/cri-containerd-4ec669b41a2f0d9b145e35d38d70a6aea40fab42d778f006a311ef9f16588690.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda4ffe8d9_fba4_4bf3_bc4a_205aad089896.slice/cri-containerd-b60404c95c9bc8989ba6429918c0812114a8d82394bc4e54ba18e724255eb767.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64da4e20_239f_4b83_aa89_98a6a91010f7.slice/cri-containerd-1a49ac4728fb21da9ac302c43b1e8e65b5716a39a472889e591ff5c924a0631f.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod64da4e20_239f_4b83_aa89_98a6a91010f7.slice/cri-containerd-05f5d7060b81bfc6fe5136abc970efa2c6aae326d50b0680365583c8ff18002a.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-e6c33cde22cc3704ba08a99f54f5a8bfea8e42d4dea1902934b3747f72cd918b.scope
    672      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-24c1090136e6a25950cf690d39e041066b726d67e2e57001b6f014547bccdc54.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-bd6a2ae8893d660b34d25c4f0e8c66565304cc69eee050981d26ecbcd84997e8.scope
    648      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-cd86c851fd58386ef9ce02e70ba61fe1ce4a15ea310a2eb7d33c256e231a75db.scope
    668      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43949070_e10c_4202_ae85_85a7770ef102.slice/cri-containerd-ca72ac7f47db53dc726aad20b7f6af44a7b0cc1660440fcaa68dad6a7c638a54.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod43949070_e10c_4202_ae85_85a7770ef102.slice/cri-containerd-a62afed4f0719ab93f03a0d7c46da67aefb0fe43a37d0613823e99b8783a6fec.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8654f074_352f_4bbf_899f_fdf5ff6ae4ae.slice/cri-containerd-cfe23e66ea87a4fc256bc9d9a578f3c69be5e263ea85d245d429aa51e6d4961a.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8654f074_352f_4bbf_899f_fdf5ff6ae4ae.slice/cri-containerd-137498adf89380c94c051aa0c014a62f9409d76085308a5d0771c16f288c69eb.scope
    98       cgroup_device   multi                                          
