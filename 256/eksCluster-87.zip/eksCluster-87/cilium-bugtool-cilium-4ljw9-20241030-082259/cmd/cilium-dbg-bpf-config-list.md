KEY             VALUE
AgentLiveness   2282096374925
UTimeOffset     3379442050781250
