Endpoint ID: 640
Path: /sys/fs/bpf/tc/globals/cilium_policy_00640

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1675982   21193     0        
Allow    Ingress     1          ANY          NONE         disabled    25412     294       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 650
Path: /sys/fs/bpf/tc/globals/cilium_policy_00650

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11637807   115655    0        
Allow    Ingress     1          ANY          NONE         disabled    9563723    100165    0        
Allow    Egress      0          ANY          NONE         disabled    12681048   125297    0        


Endpoint ID: 808
Path: /sys/fs/bpf/tc/globals/cilium_policy_00808

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176666   2027      0        
Allow    Egress      0          ANY          NONE         disabled    21058    234       0        


Endpoint ID: 1147
Path: /sys/fs/bpf/tc/globals/cilium_policy_01147

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3877
Path: /sys/fs/bpf/tc/globals/cilium_policy_03877

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    176433   2029      0        
Allow    Egress      0          ANY          NONE         disabled    20657    230       0        


