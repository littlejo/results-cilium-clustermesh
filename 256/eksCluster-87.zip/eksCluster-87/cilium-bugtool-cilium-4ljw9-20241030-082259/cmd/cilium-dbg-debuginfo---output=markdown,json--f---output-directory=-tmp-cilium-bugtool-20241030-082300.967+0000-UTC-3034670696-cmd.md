markdown output at /tmp/cilium-bugtool-20241030-082300.967+0000-UTC-3034670696/cmd/cilium-debuginfo-20241030-082332.204+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082300.967+0000-UTC-3034670696/cmd/cilium-debuginfo-20241030-082332.204+0000-UTC.json
