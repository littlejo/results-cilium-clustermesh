REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35890     2834128     677    bpf_overlay.c
Interface                 INGRESS     636126    132030437   1132   bpf_host.c
Success                   EGRESS      15427     1208528     1694   bpf_host.c
Success                   EGRESS      271570    34002658    1308   bpf_lxc.c
Success                   EGRESS      35334     2794307     53     encap.h
Success                   INGRESS     311736    35189762    86     l3.h
Success                   INGRESS     332850    36859408    235    trace.h
Unsupported L3 protocol   EGRESS      39        2882        1492   bpf_lxc.c
