USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         693  0.0  0.0 1229000 4052 ?        Ssl  08:23   0:00 /bin/gops stack 1
root         679  0.0  0.0 1229000 4056 ?        Ssl  08:23   0:00 /bin/gops pprof-cpu 1
root         678  0.0  0.0 1228744 3660 ?        Ssl  08:23   0:00 /bin/gops pprof-heap 1
root         674  0.0  0.1 1240432 15952 ?       Ssl  08:23   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         723  0.0  0.0   6408  1652 ?        R    08:23   0:00  \_ ps auxfw
root         725  0.0  0.0   3852  1288 ?        R    08:23   0:00  \_ bash -c hostname
root           1  2.8  4.7 1606080 379712 ?      Ssl  07:52   0:52 cilium-agent --config-dir=/tmp/cilium/config-map
root         416  0.0  0.1 1229744 8084 ?        Sl   07:52   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
