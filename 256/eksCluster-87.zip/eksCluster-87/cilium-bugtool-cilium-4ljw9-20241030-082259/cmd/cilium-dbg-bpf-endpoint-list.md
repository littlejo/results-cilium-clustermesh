IP ADDRESS        LOCAL ENDPOINT INFO
10.87.0.48:0      (localhost)                                                                                        
10.87.0.189:0     id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49     
172.31.214.37:0   (localhost)                                                                                        
172.31.253.94:0   (localhost)                                                                                        
10.87.0.167:0     id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82   
10.87.0.31:0      id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06   
10.87.0.156:0     id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D   
