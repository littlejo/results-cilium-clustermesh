32: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
33: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
35: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
36: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:45:33+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
38: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
39: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
40: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
41: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
42: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
43: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:45:34+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
48: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:45:38+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
54: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:45:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
57: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:45:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:45:48+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
87: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
90: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
91: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
94: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:13+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
95: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
98: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
99: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
102: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
103: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:20+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
106: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:20+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
130: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:32+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
133: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:32+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
492: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
495: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
496: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:44+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
499: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:44+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 136
501: sched_cls  name tail_handle_ipv4  tag f4ddc99c6a8347bb  gpl
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,104
	btf_id 137
502: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 138
503: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:52:45+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,104
	btf_id 139
526: sched_cls  name handle_policy  tag a0af78cf3ffa6599  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,111,41,80,91,39,84,75,40,37,38
	btf_id 165
527: sched_cls  name tail_handle_ipv4  tag ef783f8f8434b72a  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 166
529: sched_cls  name tail_ipv4_ct_ingress  tag d726028e32b00b16  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 168
530: sched_cls  name __send_drop_notify  tag 2fcbf7fae0725c91  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 169
531: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 170
532: sched_cls  name tail_handle_ipv4_cont  tag 9700f72ebbb307fe  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,111,41,91,82,83,39,76,74,77,112,40,37,38,81
	btf_id 171
533: sched_cls  name tail_ipv4_ct_egress  tag 26737e6f6248c604  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,111,84
	btf_id 172
534: sched_cls  name cil_from_container  tag 08e453a644116551  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 173
535: sched_cls  name tail_handle_arp  tag 9f9e95a739628369  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 174
536: sched_cls  name tail_ipv4_to_endpoint  tag ec3d5d38f6d84d6e  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,111,41,82,83,80,91,39,112,40,37,38
	btf_id 175
537: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 177
538: sched_cls  name tail_handle_ipv4  tag 2ca0211d10eb82d6  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 178
539: sched_cls  name tail_handle_arp  tag b9dd8c42712a8f0a  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 179
541: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 181
542: sched_cls  name tail_ipv4_to_endpoint  tag 5d91c89ae12fb0a7  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,114,41,82,83,80,106,39,113,40,37,38
	btf_id 182
543: sched_cls  name cil_from_container  tag 6891498f396ab5b2  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 113,76
	btf_id 183
544: sched_cls  name tail_ipv4_ct_ingress  tag d2e3f0ea2b5d31c3  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,113,82,83,114,84
	btf_id 184
545: sched_cls  name handle_policy  tag 8b99482b0d742dd7  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,113,82,83,114,41,80,106,39,84,75,40,37,38
	btf_id 185
546: sched_cls  name tail_handle_ipv4_cont  tag aede983ade5c9d02  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,114,41,106,82,83,39,76,74,77,113,40,37,38,81
	btf_id 186
547: sched_cls  name __send_drop_notify  tag 453152737f2ab14b  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
548: sched_cls  name tail_handle_ipv4  tag 00612573f777c8d0  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 189
549: sched_cls  name handle_policy  tag 621aab3a0eaea7b7  gpl
	loaded_at 2024-10-30T07:52:47+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,105,39,84,75,40,37,38
	btf_id 190
550: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
553: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
554: sched_cls  name tail_handle_ipv4_cont  tag 55b6a0db7dd1fc2e  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,105,82,83,39,76,74,77,116,40,37,38,81
	btf_id 191
555: sched_cls  name tail_ipv4_ct_egress  tag 26737e6f6248c604  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 192
556: sched_cls  name __send_drop_notify  tag dd3ff22db6533ebb  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 193
557: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 194
558: sched_cls  name tail_handle_arp  tag e99c5fe4899e60d9  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 195
559: sched_cls  name tail_ipv4_ct_ingress  tag e6f83387de9f397f  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 196
561: sched_cls  name cil_from_container  tag 009d10c1f1dba72b  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 198
562: sched_cls  name tail_ipv4_to_endpoint  tag 69c29db88e6392dd  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,105,39,116,40,37,38
	btf_id 199
563: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
566: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:52:48+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
567: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 201
568: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 202
569: sched_cls  name __send_drop_notify  tag e56fad7c5d73ec63  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 203
571: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,119
	btf_id 205
573: sched_cls  name tail_handle_ipv4_from_host  tag 283334951f1cd9a3  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 207
574: sched_cls  name tail_handle_ipv4_from_host  tag 283334951f1cd9a3  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 209
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 210
576: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 211
577: sched_cls  name __send_drop_notify  tag e56fad7c5d73ec63  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 212
583: sched_cls  name tail_handle_ipv4_from_host  tag 283334951f1cd9a3  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 219
584: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 220
586: sched_cls  name __send_drop_notify  tag e56fad7c5d73ec63  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 222
587: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 223
590: sched_cls  name tail_handle_ipv4_from_host  tag 283334951f1cd9a3  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,126
	btf_id 227
591: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,126
	btf_id 228
593: sched_cls  name __send_drop_notify  tag e56fad7c5d73ec63  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 230
594: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:52:49+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,126,75
	btf_id 231
635: sched_cls  name tail_handle_ipv4_cont  tag f17bc03fb7eec8ad  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,138,41,137,82,83,39,76,74,77,139,40,37,38,81
	btf_id 246
636: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,139
	btf_id 247
637: sched_cls  name cil_from_container  tag 1ba5301a73cae9fb  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 139,76
	btf_id 248
638: sched_cls  name tail_ipv4_ct_ingress  tag 8052e9df125368b9  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 249
639: sched_cls  name handle_policy  tag f38be9faf9dc0b16  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,139,82,83,138,41,80,137,39,84,75,40,37,38
	btf_id 250
640: sched_cls  name tail_ipv4_ct_egress  tag a626896a92ba5f3b  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,139,82,83,138,84
	btf_id 251
641: sched_cls  name __send_drop_notify  tag 3f7fb5099fb2f03c  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 252
642: sched_cls  name tail_ipv4_to_endpoint  tag 753dc90d1b1e5156  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,138,41,82,83,80,137,39,139,40,37,38
	btf_id 253
643: sched_cls  name tail_handle_ipv4  tag 6b4813242939e786  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,139
	btf_id 254
644: sched_cls  name tail_handle_arp  tag 2df7925fe4ec3abe  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,139
	btf_id 255
645: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
648: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
665: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
668: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
669: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
672: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
