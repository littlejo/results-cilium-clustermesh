alloc: 174.55MB (183025440 bytes)
total-alloc: 2.28GB (2446390008 bytes)
sys: 328.77MB (344740196 bytes)
lookups: 0
mallocs: 63770448
frees: 62029864
heap-alloc: 174.55MB (183025440 bytes)
heap-sys: 251.23MB (263438336 bytes)
heap-idle: 50.91MB (53387264 bytes)
heap-in-use: 200.32MB (210051072 bytes)
heap-released: 3.78MB (3964928 bytes)
heap-objects: 1740584
stack-in-use: 64.72MB (67862528 bytes)
stack-sys: 64.72MB (67862528 bytes)
stack-mspan-inuse: 3.11MB (3259360 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 972.45KB (995793 bytes)
gc-sys: 6.03MB (6319640 bytes)
next-gc: when heap-alloc >= 213.26MB (223614856 bytes)
last-gc: 2024-10-30 08:23:05.699699715 +0000 UTC
gc-pause-total: 11.702804ms
gc-pause: 127139
gc-pause-end: 1730276585699699715
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.0003566576323988208
enable-gc: true
debug-gc: false
