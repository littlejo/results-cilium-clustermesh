top - 08:23:01 up 37 min,  0 users,  load average: 0.34, 0.17, 0.11
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s):  3.4 us, 34.5 sy,  0.0 ni, 55.2 id,  3.4 wa,  0.0 hi,  3.4 si,  0.0 st
MiB Mem :   7814.2 total,   4474.7 free,   1193.3 used,   2146.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6436.0 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    674 root      20   0 1240432  15952  10960 S   6.7   0.2   0:00.02 cilium-+
      1 root      20   0 1606080 379712  77880 S   0.0   4.7   0:52.07 cilium-+
    416 root      20   0 1229744   8084   3836 S   0.0   0.1   0:01.14 cilium-+
    678 root      20   0 1228744   3660   2976 S   0.0   0.0   0:00.00 gops
    679 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    693 root      20   0 1229000   4052   3392 S   0.0   0.1   0:00.00 gops
    735 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    751 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    759 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
