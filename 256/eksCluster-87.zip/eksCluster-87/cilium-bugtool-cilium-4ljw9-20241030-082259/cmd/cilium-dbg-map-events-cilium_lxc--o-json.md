{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.48:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.535Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.214.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.535Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.253.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:41.535Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:44.656Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.865Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.874Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.927Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:47.981Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:52:48.043Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:09.117Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:09.117Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:09.117Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:09.148Z",
  "value": "id=3159  sec_id=2884417 flags=0x0000 ifindex=16  mac=B6:4E:EA:74:ED:C3 nodemac=8A:E1:FB:FC:83:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.116Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.117Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.117Z",
  "value": "id=3159  sec_id=2884417 flags=0x0000 ifindex=16  mac=B6:4E:EA:74:ED:C3 nodemac=8A:E1:FB:FC:83:F9"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:58:10.117Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.444Z",
  "value": "id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.87.0.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:25.808Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.542Z",
  "value": "id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.543Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.544Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:26.544Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.555Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.555Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.555Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:27.556Z",
  "value": "id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.543Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.543Z",
  "value": "id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.544Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:28.544Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.167:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.544Z",
  "value": "id=808   sec_id=2890777 flags=0x0000 ifindex=12  mac=96:6F:56:98:AD:B8 nodemac=BE:50:A3:3C:33:82"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.31:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.544Z",
  "value": "id=3877  sec_id=2890777 flags=0x0000 ifindex=14  mac=EE:A4:5C:C7:62:69 nodemac=9E:BA:85:31:3E:06"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.189:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.544Z",
  "value": "id=640   sec_id=4     flags=0x0000 ifindex=10  mac=86:AC:CF:EA:B4:43 nodemac=A6:C5:D5:17:8A:49"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.87.0.156:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:29.544Z",
  "value": "id=650   sec_id=2884417 flags=0x0000 ifindex=18  mac=B6:58:87:7D:06:44 nodemac=9A:3B:A7:E0:79:0D"
}

