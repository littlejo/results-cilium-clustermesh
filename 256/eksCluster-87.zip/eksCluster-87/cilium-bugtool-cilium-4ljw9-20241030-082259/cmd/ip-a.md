1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:18:36:cb:fa:a1 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.214.37/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3159sec preferred_lft 3159sec
    inet6 fe80::818:36ff:fecb:faa1/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:92:24:64:da:53 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.253.94/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::892:24ff:fe64:da53/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:e4:c8:7a:ad:46 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f0e4:c8ff:fe7a:ad46/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a2:1c:ea:3a:61:a3 brd ff:ff:ff:ff:ff:ff
    inet 10.87.0.48/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::a01c:eaff:fe3a:61a3/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether ca:d7:1b:40:12:4a brd ff:ff:ff:ff:ff:ff
    inet6 fe80::c8d7:1bff:fe40:124a/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether a6:c5:d5:17:8a:49 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::a4c5:d5ff:fe17:8a49/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf88dca9afade@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:50:a3:3c:33:82 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::bc50:a3ff:fe3c:3382/64 scope link 
       valid_lft forever preferred_lft forever
14: lxce400b7f1721e@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:ba:85:31:3e:06 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::9cba:85ff:fe31:3e06/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc547c4e1ef03f@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9a:3b:a7:e0:79:0d brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::983b:a7ff:fee0:790d/64 scope link 
       valid_lft forever preferred_lft forever
