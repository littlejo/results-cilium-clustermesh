xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 587
ens6(5) clsact/ingress cil_from_netdev-ens6 id 594
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 576
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 568
cilium_host(7) clsact/egress cil_from_host-cilium_host id 571
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 503
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 502
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 543
lxcf88dca9afade(12) clsact/ingress cil_from_container-lxcf88dca9afade id 534
lxce400b7f1721e(14) clsact/ingress cil_from_container-lxce400b7f1721e id 561
lxc547c4e1ef03f(18) clsact/ingress cil_from_container-lxc547c4e1ef03f id 637

flow_dissector:

netfilter:

