[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-cd86c851fd58386ef9ce02e70ba61fe1ce4a15ea310a2eb7d33c256e231a75db.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-24c1090136e6a25950cf690d39e041066b726d67e2e57001b6f014547bccdc54.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod33a6daf0_eb0c_4add_b777_7693576fd9e3.slice/cri-containerd-e6c33cde22cc3704ba08a99f54f5a8bfea8e42d4dea1902934b3747f72cd918b.scope"
      }
    ],
    "ips": [
      "10.87.0.156"
    ],
    "name": "clustermesh-apiserver-6d84b99c9f-j6c9h",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7614,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf8c102b8_30db_492e_b7ae_464dfe2a9e2b.slice/cri-containerd-4c4f4c283a2ce9256eb24f816e41c3cb607b3cacf089415fb06822e003325d30.scope"
      }
    ],
    "ips": [
      "10.87.0.167"
    ],
    "name": "coredns-cc6ccd49c-2sq4t",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podeb8bd9a9_a607_4eed_8978_46301a455d5a.slice/cri-containerd-b2190177c8dfc3a9ff90a0f8175f17ded75e8b5e5a214be883da0e6a362c273f.scope"
      }
    ],
    "ips": [
      "10.87.0.31"
    ],
    "name": "coredns-cc6ccd49c-v58vc",
    "namespace": "kube-system"
  }
]

