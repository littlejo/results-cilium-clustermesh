{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.203:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:24.877Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.128.255:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:24.877Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.170.243:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:24.877Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.424Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.446Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.493Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.563Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T07:55:29.658Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.308Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.309Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.309Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:30.342Z",
  "value": "id=989   sec_id=1820643 flags=0x0000 ifindex=16  mac=2E:71:E5:52:A2:EB nodemac=4E:F0:D8:76:38:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.309Z",
  "value": "id=989   sec_id=1820643 flags=0x0000 ifindex=16  mac=2E:71:E5:52:A2:EB nodemac=4E:F0:D8:76:38:32"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.309Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.309Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:31.309Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:17.132Z",
  "value": "id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.54.0.237:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:23.579Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.183Z",
  "value": "id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.185Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.186Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:32.191Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.129Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.129Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.129Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:33.129Z",
  "value": "id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.127Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.127Z",
  "value": "id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.127Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:34.128Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.139:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.128Z",
  "value": "id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.229:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.128Z",
  "value": "id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.92:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.128Z",
  "value": "id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.54.0.9:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:35.128Z",
  "value": "id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A"
}

