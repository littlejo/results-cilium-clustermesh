35: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
36: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
37: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
40: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:47:59+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
41: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
42: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
43: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
44: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
45: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
46: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:48:00+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
51: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:48:04+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
53: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:48:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
56: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:48:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
66: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:48:14+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
90: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
93: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
94: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
97: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
98: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
101: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:54:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
102: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:00+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
105: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:00+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
106: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
109: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
133: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
136: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
484: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T07:55:27+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
485: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T07:55:27+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
486: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T07:55:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
487: sched_cls  name tail_handle_ipv4  tag 7705a8dfbea53d32  gpl
	loaded_at 2024-10-30T07:55:27+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
506: sched_cls  name tail_handle_arp  tag df9accd1b65b60b9  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,107
	btf_id 150
507: sched_cls  name cil_from_container  tag da63af7ca6411080  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 107,76
	btf_id 151
508: sched_cls  name __send_drop_notify  tag e7f33475b84c1a4d  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 152
509: sched_cls  name tail_handle_ipv4_cont  tag 6091f18837abaadb  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,108,41,106,82,83,39,76,74,77,107,40,37,38,81
	btf_id 153
510: sched_cls  name tail_ipv4_ct_ingress  tag 392fce3f0e36ee07  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 154
514: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,107,82,83,108,84
	btf_id 155
515: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,107
	btf_id 159
518: sched_cls  name handle_policy  tag 2544db7b99bdb36e  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,107,82,83,108,41,80,106,39,84,75,40,37,38
	btf_id 161
519: sched_cls  name tail_ipv4_to_endpoint  tag 987ff686987b09c8  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,108,41,82,83,80,106,39,107,40,37,38
	btf_id 162
520: sched_cls  name tail_handle_ipv4  tag d77172cbcafae7a1  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,107
	btf_id 163
521: sched_cls  name tail_ipv4_ct_ingress  tag 5f41cb990455f5ab  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 165
522: sched_cls  name tail_handle_ipv4  tag 8c60b7156f888845  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,110
	btf_id 166
523: sched_cls  name cil_from_container  tag 04d8eb3f893e3952  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 110,76
	btf_id 167
524: sched_cls  name tail_ipv4_to_endpoint  tag eb9a52987c8bfb58  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,109,41,82,83,80,100,39,110,40,37,38
	btf_id 168
526: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,110
	btf_id 170
527: sched_cls  name tail_handle_arp  tag d8fec093cf4c815b  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,110
	btf_id 171
528: sched_cls  name __send_drop_notify  tag 7cfc04e871db74d2  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 172
529: sched_cls  name tail_handle_ipv4_cont  tag dbde4091702ab1ef  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,109,41,100,82,83,39,76,74,77,110,40,37,38,81
	btf_id 173
530: sched_cls  name tail_ipv4_ct_egress  tag bf2ab799cf3357be  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,110,82,83,109,84
	btf_id 174
531: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
534: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
535: sched_cls  name handle_policy  tag 8406c0372e4968ed  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,110,82,83,109,41,80,100,39,84,75,40,37,38
	btf_id 175
536: sched_cls  name tail_handle_arp  tag bae25b5161f5907e  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,112
	btf_id 177
537: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
540: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
541: sched_cls  name tail_handle_ipv4_cont  tag c8186015b24178d9  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,101,82,83,39,76,74,77,112,40,37,38,81
	btf_id 178
543: sched_cls  name tail_ipv4_ct_egress  tag bf2ab799cf3357be  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 180
544: sched_cls  name __send_drop_notify  tag 332f04e5c1a8170d  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 181
545: sched_cls  name cil_from_container  tag 8b614685bb7f8f0a  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 112,76
	btf_id 182
546: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,112
	btf_id 183
547: sched_cls  name handle_policy  tag 773d5de9c6b12f45  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,112,82,83,113,41,80,101,39,84,75,40,37,38
	btf_id 184
548: sched_cls  name tail_handle_ipv4  tag aa8049e2069cc6af  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,112
	btf_id 185
549: sched_cls  name tail_ipv4_to_endpoint  tag 02488d526f45a9e0  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,101,39,112,40,37,38
	btf_id 186
550: sched_cls  name tail_ipv4_ct_ingress  tag 2c7b9072f01ff1cf  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,112,82,83,113,84
	btf_id 187
551: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
554: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
555: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
558: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:55:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
559: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,118
	btf_id 189
562: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,118
	btf_id 192
563: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 193
564: sched_cls  name __send_drop_notify  tag 820cf78c8b8d6cb5  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 194
565: sched_cls  name tail_handle_ipv4_from_host  tag 170830a8a255fd1d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,118
	btf_id 195
566: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,119
	btf_id 197
570: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 201
571: sched_cls  name __send_drop_notify  tag 820cf78c8b8d6cb5  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 202
572: sched_cls  name tail_handle_ipv4_from_host  tag 170830a8a255fd1d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,119
	btf_id 203
573: sched_cls  name __send_drop_notify  tag 820cf78c8b8d6cb5  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 205
574: sched_cls  name tail_handle_ipv4_from_host  tag 170830a8a255fd1d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 206
575: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 207
577: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 209
581: sched_cls  name __send_drop_notify  tag 820cf78c8b8d6cb5  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 214
582: sched_cls  name tail_handle_ipv4_from_host  tag 170830a8a255fd1d  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,124
	btf_id 215
583: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,124
	btf_id 216
585: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T07:55:30+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,124,75
	btf_id 218
626: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,136
	btf_id 233
627: sched_cls  name tail_handle_ipv4  tag 3af37ea97ee5e991  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,136
	btf_id 234
628: sched_cls  name cil_from_container  tag c06644d812ac0c0f  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 136,76
	btf_id 235
629: sched_cls  name tail_ipv4_ct_egress  tag 285647a9480b53e0  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 236
631: sched_cls  name tail_ipv4_ct_ingress  tag 3f89d883d36d43fb  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,136,82,83,137,84
	btf_id 238
632: sched_cls  name tail_handle_ipv4_cont  tag 1f094adc14838497  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,137,41,135,82,83,39,76,74,77,136,40,37,38,81
	btf_id 239
633: sched_cls  name tail_handle_arp  tag b6561ef5442df75d  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,136
	btf_id 240
634: sched_cls  name __send_drop_notify  tag 6db9173a8bca970a  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 241
635: sched_cls  name handle_policy  tag 101b3109729929c1  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,136,82,83,137,41,80,135,39,84,75,40,37,38
	btf_id 242
636: sched_cls  name tail_ipv4_to_endpoint  tag 89abb4dfa03766d2  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,137,41,82,83,80,135,39,136,40,37,38
	btf_id 243
637: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
640: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:17+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
653: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
656: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
657: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
660: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
661: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
664: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:19+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
