key: ba 00 00 00  value: 7b 02 00 00
key: f2 07 00 00  value: 06 02 00 00
key: 22 09 00 00  value: 23 02 00 00
key: 69 09 00 00  value: 17 02 00 00
Found 4 elements
