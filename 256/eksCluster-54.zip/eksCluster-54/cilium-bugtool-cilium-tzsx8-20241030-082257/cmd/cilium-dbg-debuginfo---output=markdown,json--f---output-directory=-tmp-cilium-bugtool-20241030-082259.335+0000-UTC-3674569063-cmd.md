markdown output at /tmp/cilium-bugtool-20241030-082259.335+0000-UTC-3674569063/cmd/cilium-debuginfo-20241030-082330.384+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.335+0000-UTC-3674569063/cmd/cilium-debuginfo-20241030-082330.384+0000-UTC.json
