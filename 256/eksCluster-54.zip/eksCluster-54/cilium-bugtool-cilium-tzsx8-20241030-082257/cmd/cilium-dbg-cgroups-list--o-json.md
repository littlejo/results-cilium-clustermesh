[
  {
    "containers": [
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-699d7bf8cfe461d72352ed0841bfed27e70cac04027fba5fa8588a053afd401c.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-79bb97eb402d1b28508448923841958e827fea6c794fdf504e66d1bfb96c43ac.scope"
      },
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-0c97198d938a827730891221c08257ea354600207c398df15bc4d98eda15ac8a.scope"
      }
    ],
    "ips": [
      "10.54.0.139"
    ],
    "name": "clustermesh-apiserver-75f7f64f7c-zxgsc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7bdfff9_be07_460c_8fd0_fdd45d61b76d.slice/cri-containerd-8e93ac1767bee691eed4e0cc1656cd18cbdbbe243e8f4b39750a16e733bedaa9.scope"
      }
    ],
    "ips": [
      "10.54.0.229"
    ],
    "name": "coredns-cc6ccd49c-lb8v5",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7703,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e5a53ca_3526_4eef_b586_8c4fed56e919.slice/cri-containerd-144350837bb3b0b827b28db83e908409d4231226336c0d2f9eeb0fb8561f9579.scope"
      }
    ],
    "ips": [
      "10.54.0.92"
    ],
    "name": "coredns-cc6ccd49c-bz7v7",
    "namespace": "kube-system"
  }
]

