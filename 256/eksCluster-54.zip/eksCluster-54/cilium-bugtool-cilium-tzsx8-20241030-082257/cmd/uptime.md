 08:22:59 up 35 min,  0 users,  load average: 0.29, 0.30, 0.19
