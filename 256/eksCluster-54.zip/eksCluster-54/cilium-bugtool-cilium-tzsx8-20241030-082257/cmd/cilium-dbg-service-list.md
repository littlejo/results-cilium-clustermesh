ID   Frontend            Service Type   Backend                             
1    10.100.0.1:443      ClusterIP      1 => 172.31.132.192:443 (active)    
                                        2 => 172.31.214.125:443 (active)    
2    10.100.94.52:443    ClusterIP      1 => 172.31.170.243:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.54.0.229:53 (active)        
                                        2 => 10.54.0.92:53 (active)         
4    10.100.0.10:9153    ClusterIP      1 => 10.54.0.229:9153 (active)      
                                        2 => 10.54.0.92:9153 (active)       
5    10.100.46.99:2379   ClusterIP      1 => 10.54.0.139:2379 (active)      
