1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:49:81:30:86:23 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.170.243/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3307sec preferred_lft 3307sec
    inet6 fe80::449:81ff:fe30:8623/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:52:ff:a2:d8:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.128.255/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::452:ffff:fea2:d863/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether be:a8:1c:54:f1:d6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::bca8:1cff:fe54:f1d6/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 92:cb:42:fa:47:cf brd ff:ff:ff:ff:ff:ff
    inet 10.54.0.203/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::90cb:42ff:fefa:47cf/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 76:be:af:d2:e1:e6 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::74be:afff:fed2:e1e6/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:aa:31:7c:d4:1a brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::6caa:31ff:fe7c:d41a/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcc82363c2ffab@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ae:17:fb:c2:78:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::ac17:fbff:fec2:78b3/64 scope link 
       valid_lft forever preferred_lft forever
14: lxcd37d8fc65be3@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:7c:0e:c6:3d:a4 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4c7c:eff:fec6:3da4/64 scope link 
       valid_lft forever preferred_lft forever
18: lxcb69ab24b0d44@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 5e:1f:a2:9c:3f:fc brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::5c1f:a2ff:fe9c:3ffc/64 scope link 
       valid_lft forever preferred_lft forever
