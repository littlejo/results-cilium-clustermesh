xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 577
ens6(5) clsact/ingress cil_from_netdev-ens6 id 585
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 570
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 563
cilium_host(7) clsact/egress cil_from_host-cilium_host id 562
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 484
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 485
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 507
lxcc82363c2ffab(12) clsact/ingress cil_from_container-lxcc82363c2ffab id 545
lxcd37d8fc65be3(14) clsact/ingress cil_from_container-lxcd37d8fc65be3 id 523
lxcb69ab24b0d44(18) clsact/ingress cil_from_container-lxcb69ab24b0d44 id 628

flow_dissector:

netfilter:

