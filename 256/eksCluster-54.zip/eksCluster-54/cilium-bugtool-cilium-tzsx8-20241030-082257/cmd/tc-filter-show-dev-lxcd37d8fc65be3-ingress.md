filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcd37d8fc65be3 direct-action not_in_hw id 523 tag 04d8eb3f893e3952 jited 
