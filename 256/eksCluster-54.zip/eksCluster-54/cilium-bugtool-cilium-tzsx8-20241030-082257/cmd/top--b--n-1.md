top - 08:22:59 up 35 min,  0 users,  load average: 0.29, 0.30, 0.19
Tasks:  10 total,   3 running,   7 sleeping,   0 stopped,   0 zombie
%Cpu(s): 68.8 us, 28.1 sy,  0.0 ni,  0.0 id,  0.0 wa,  0.0 hi,  3.1 si,  0.0 st
MiB Mem :   7814.2 total,   4465.6 free,   1202.9 used,   2145.7 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6426.4 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 396468  80232 S  56.2   5.0   0:58.84 cilium-+
    742 root      20   0 1243508  19344  13700 R  12.5   0.2   0:00.02 hubble
    405 root      20   0 1229488   8248   3840 S   0.0   0.1   0:01.16 cilium-+
    651 root      20   0 1229000   6988   4004 S   0.0   0.1   0:00.00 gops
    657 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    679 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1240432  16584  11356 S   0.0   0.2   0:00.02 cilium-+
    720 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    724 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    756 root      20   0 1228744   2720   2216 R   0.0   0.0   0:00.00 gops
