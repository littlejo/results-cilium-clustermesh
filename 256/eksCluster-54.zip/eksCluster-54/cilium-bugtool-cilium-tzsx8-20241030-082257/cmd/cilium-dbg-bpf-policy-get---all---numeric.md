Endpoint ID: 186
Path: /sys/fs/bpf/tc/globals/cilium_policy_00186

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11636911   116893    0        
Allow    Ingress     1          ANY          NONE         disabled    10972369   115907    0        
Allow    Egress      0          ANY          NONE         disabled    14065795   138079    0        


Endpoint ID: 2034
Path: /sys/fs/bpf/tc/globals/cilium_policy_02034

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1657792   21016     0        
Allow    Ingress     1          ANY          NONE         disabled    25064     296       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2338
Path: /sys/fs/bpf/tc/globals/cilium_policy_02338

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    159075   1821      0        
Allow    Egress      0          ANY          NONE         disabled    20882    233       0        


Endpoint ID: 2409
Path: /sys/fs/bpf/tc/globals/cilium_policy_02409

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    159668   1835      0        
Allow    Egress      0          ANY          NONE         disabled    20121    225       0        


Endpoint ID: 2892
Path: /sys/fs/bpf/tc/globals/cilium_policy_02892

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


