USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         702  0.0  0.1 1550728 8808 ?        Rsl  08:22   0:00 /usr/sbin/runc init
root         684  0.0  0.2 1240432 16584 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         708  0.0  0.0   2080   248 ?        R    08:22   0:00  \_ cat /proc/net/xfrm_stat
root         709  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         679  0.0  0.0 1228744 3600 ?        Ssl  08:22   0:00 /bin/gops pprof-cpu 1
root         657  0.0  0.0 1229000 4056 ?        Ssl  08:22   0:00 /bin/gops memstats 1
root         651  0.0  0.0 1229000 4048 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.5  4.8 1606080 387756 ?      Ssl  07:55   0:58 cilium-agent --config-dir=/tmp/cilium/config-map
root         405  0.0  0.1 1229488 8248 ?        Sl   07:55   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
