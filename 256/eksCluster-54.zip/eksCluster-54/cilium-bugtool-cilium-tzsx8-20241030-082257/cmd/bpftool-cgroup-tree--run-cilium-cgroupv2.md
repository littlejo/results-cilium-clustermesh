CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    46       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    39       cgroup_inet_ingress multi           sd_fw_ingress                  
    38       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    41       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    51       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    37       cgroup_inet_ingress multi           sd_fw_ingress                  
    36       cgroup_inet_egress multi           sd_fw_egress                   
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    44       cgroup_inet_ingress multi           sd_fw_ingress                  
    43       cgroup_inet_egress multi           sd_fw_egress                   
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7bdfff9_be07_460c_8fd0_fdd45d61b76d.slice/cri-containerd-808c2d41f8f53b3608fa80fbf0558bb32539f9c22fd6a1ec0dacfb838f722daf.scope
    540      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf7bdfff9_be07_460c_8fd0_fdd45d61b76d.slice/cri-containerd-8e93ac1767bee691eed4e0cc1656cd18cbdbbe243e8f4b39750a16e733bedaa9.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0f95c20_8df9_430b_995d_8e16cf16a07e.slice/cri-containerd-8042a86ccb1deb49998acff9deaf2b82048542d04f9205056b0e57f22675dd4f.scope
    136      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0f95c20_8df9_430b_995d_8e16cf16a07e.slice/cri-containerd-fba600d024828d743d392a70b71da8b0e46d3cf782b0302581ef1211eb667fe9.scope
    93       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podafd05a41_2ffe_4d90_aa25_395f5ec7a22a.slice/cri-containerd-383c2c4d1d2632755b290dd286114c5a2742400fb7c04de1bcdc3acb52879ff6.scope
    56       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podafd05a41_2ffe_4d90_aa25_395f5ec7a22a.slice/cri-containerd-cbe1404c586989711fcb2ff304a14042591585f941547a8bf091dfd7ee61903d.scope
    66       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e5a53ca_3526_4eef_b586_8c4fed56e919.slice/cri-containerd-144350837bb3b0b827b28db83e908409d4231226336c0d2f9eeb0fb8561f9579.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod9e5a53ca_3526_4eef_b586_8c4fed56e919.slice/cri-containerd-36099c9744b4bb06b57d6c77b378dfafbbba423fd48da70f5bea5d53e6836d0c.scope
    534      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7156fce8_3c5f_4004_96d8_87acd6145eaf.slice/cri-containerd-496bebe0f3c1986df464a6762bcdb537a400aa815053b6a8b3ad3e5a98aaf710.scope
    97       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7156fce8_3c5f_4004_96d8_87acd6145eaf.slice/cri-containerd-3aab0928c3b4db00c11dc39c6937b9f589e139933677c616458833acc868d831.scope
    109      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-699d7bf8cfe461d72352ed0841bfed27e70cac04027fba5fa8588a053afd401c.scope
    656      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-79bb97eb402d1b28508448923841958e827fea6c794fdf504e66d1bfb96c43ac.scope
    664      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-0c97198d938a827730891221c08257ea354600207c398df15bc4d98eda15ac8a.scope
    660      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda6ce969d_fe15_4671_85c8_b08c0f2d7ca7.slice/cri-containerd-24c8237ca8849cd8ab87b6e5723c428b3d3c7a45f4a6ff36b57688b876a3e7f6.scope
    640      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c07ef61_357a_44e5_a887_76b01fc9641d.slice/cri-containerd-9a8aaad190a0c1dac36838b148724d61e9c8026d2e1396860cc199e2f2456c5e.scope
    105      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7c07ef61_357a_44e5_a887_76b01fc9641d.slice/cri-containerd-d5009c9e2a5b1dc898805e8d47c939b1b619ef65bb8a556d4406733e23c6d086.scope
    101      cgroup_device   multi                                          
