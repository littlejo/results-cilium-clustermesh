IP ADDRESS         LOCAL ENDPOINT INFO
172.31.170.243:0   (localhost)                                                                                        
172.31.128.255:0   (localhost)                                                                                        
10.54.0.92:0       id=2409  sec_id=1819473 flags=0x0000 ifindex=14  mac=6E:94:85:A9:65:93 nodemac=4E:7C:0E:C6:3D:A4   
10.54.0.9:0        id=2034  sec_id=4     flags=0x0000 ifindex=10  mac=F6:02:B5:E3:CC:65 nodemac=6E:AA:31:7C:D4:1A     
10.54.0.139:0      id=186   sec_id=1820643 flags=0x0000 ifindex=18  mac=E6:61:F0:10:A7:C5 nodemac=5E:1F:A2:9C:3F:FC   
10.54.0.203:0      (localhost)                                                                                        
10.54.0.229:0      id=2338  sec_id=1819473 flags=0x0000 ifindex=12  mac=92:1C:15:90:79:03 nodemac=AE:17:FB:C2:78:B3   
