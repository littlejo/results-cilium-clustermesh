alloc: 182.21MB (191064648 bytes)
total-alloc: 2.38GB (2552303304 bytes)
sys: 324.77MB (340545892 bytes)
lookups: 0
mallocs: 65446678
frees: 63294014
heap-alloc: 182.21MB (191064648 bytes)
heap-sys: 246.88MB (258875392 bytes)
heap-idle: 43.45MB (45555712 bytes)
heap-in-use: 203.44MB (213319680 bytes)
heap-released: 1.50MB (1572864 bytes)
heap-objects: 2152664
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.49MB (3659680 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 995.88KB (1019785 bytes)
gc-sys: 6.47MB (6786704 bytes)
next-gc: when heap-alloc >= 215.62MB (226092600 bytes)
last-gc: 2024-10-30 08:23:00.440233309 +0000 UTC
gc-pause-total: 14.967501ms
gc-pause: 105144
gc-pause-end: 1730276580440233309
num-gc: 85
num-forced-gc: 0
gc-cpu-fraction: 0.00041411017421344367
enable-gc: true
debug-gc: false
