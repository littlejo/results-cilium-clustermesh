REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36835     2915601     677    bpf_overlay.c
Interface                 INGRESS     649019    133039732   1132   bpf_host.c
Success                   EGRESS      16515     1299901     1694   bpf_host.c
Success                   EGRESS      276928    34514953    1308   bpf_lxc.c
Success                   EGRESS      37057     2932316     53     encap.h
Success                   INGRESS     321021    36177331    86     l3.h
Success                   INGRESS     341992    37837077    235    trace.h
Unsupported L3 protocol   EGRESS      40        2972        1492   bpf_lxc.c
