{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.142:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:05.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.193.95:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:05.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.213.86:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:05.099Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.678Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.688Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.733Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.737Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:00:09.760Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.639Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.639Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.640Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:28.670Z",
  "value": "id=101   sec_id=2230850 flags=0x0000 ifindex=16  mac=FA:DB:77:92:53:03 nodemac=8A:50:55:7F:6B:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.639Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.640Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.640Z",
  "value": "id=101   sec_id=2230850 flags=0x0000 ifindex=16  mac=FA:DB:77:92:53:03 nodemac=8A:50:55:7F:6B:41"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:29.640Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:10:50.826Z",
  "value": "id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.67.0.37:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:01.190Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.638Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.639Z",
  "value": "id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.640Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:13.641Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.638Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.638Z",
  "value": "id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.639Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.639Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.639Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.639Z",
  "value": "id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.639Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.639Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.70:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.639Z",
  "value": "id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.233:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.639Z",
  "value": "id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.236:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.640Z",
  "value": "id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.67.0.176:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:16.640Z",
  "value": "id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89"
}

