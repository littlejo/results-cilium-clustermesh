IP ADDRESS        LOCAL ENDPOINT INFO
10.67.0.233:0     id=3882  sec_id=2230850 flags=0x0000 ifindex=18  mac=E6:F4:5F:E2:94:9B nodemac=4E:45:FA:C1:AE:BF   
10.67.0.176:0     id=4085  sec_id=4     flags=0x0000 ifindex=10  mac=C6:28:AA:98:38:47 nodemac=CE:79:5D:8E:1B:89     
10.67.0.142:0     (localhost)                                                                                        
172.31.193.95:0   (localhost)                                                                                        
172.31.213.86:0   (localhost)                                                                                        
10.67.0.70:0      id=195   sec_id=2246302 flags=0x0000 ifindex=12  mac=9A:22:39:0E:9B:D9 nodemac=8A:ED:CB:9D:E3:F8   
10.67.0.236:0     id=2386  sec_id=2246302 flags=0x0000 ifindex=14  mac=EE:13:EE:51:A5:2F nodemac=EE:25:53:EC:F1:6A   
