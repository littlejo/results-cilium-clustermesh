29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:49+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:49+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:50+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:49:50+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:49:51+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:49:55+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
51: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
54: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:50:02+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:50:07+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:31+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:31+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
100: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:35+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
103: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:35+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:59:56+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:59:56+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:00:07+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 124
479: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:00:07+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 125
480: sched_cls  name tail_handle_ipv4  tag 85fb18b6a6a0fd92  gpl
	loaded_at 2024-10-30T08:00:07+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 126
481: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:00:07+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 127
482: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,102
	btf_id 129
483: sched_cls  name tail_handle_ipv4_from_host  tag 890d57a0354282a9  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,102
	btf_id 130
484: sched_cls  name __send_drop_notify  tag 4149fc5e64f85e09  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 131
486: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 133
487: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,102
	btf_id 134
489: sched_cls  name __send_drop_notify  tag 4149fc5e64f85e09  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 137
491: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 139
492: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,103
	btf_id 140
495: sched_cls  name tail_handle_ipv4_from_host  tag 890d57a0354282a9  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,103
	btf_id 143
496: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,105
	btf_id 145
497: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,105,75
	btf_id 146
499: sched_cls  name tail_handle_ipv4_from_host  tag 890d57a0354282a9  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,105
	btf_id 148
500: sched_cls  name __send_drop_notify  tag 4149fc5e64f85e09  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 149
505: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,107
	btf_id 155
506: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,107,75
	btf_id 156
508: sched_cls  name tail_handle_ipv4_from_host  tag 890d57a0354282a9  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,107
	btf_id 158
509: sched_cls  name __send_drop_notify  tag 4149fc5e64f85e09  gpl
	loaded_at 2024-10-30T08:00:08+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 159
510: sched_cls  name tail_handle_ipv4  tag 70f8576a450232b3  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,113
	btf_id 163
516: sched_cls  name tail_ipv4_ct_egress  tag 2a1108d59161bc74  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 165
517: sched_cls  name tail_handle_arp  tag 71fdf5407ec38779  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,113
	btf_id 170
518: sched_cls  name __send_drop_notify  tag 2a3c129efd32e0d2  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 171
520: sched_cls  name tail_handle_ipv4_cont  tag 441b3e4f724e82d3  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,112,41,109,82,83,39,76,74,77,113,40,37,38,81
	btf_id 172
524: sched_cls  name tail_ipv4_to_endpoint  tag 1943c018e6f29c39  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,112,41,82,83,80,109,39,113,40,37,38
	btf_id 174
527: sched_cls  name handle_policy  tag 9b2b4dd6eeb649c1  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,113,82,83,112,41,80,109,39,84,75,40,37,38
	btf_id 178
528: sched_cls  name cil_from_container  tag be1cc7f309d58a50  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 113,76
	btf_id 181
530: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,113
	btf_id 182
531: sched_cls  name tail_handle_ipv4  tag 1ba32b6497c9910b  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,116
	btf_id 185
532: sched_cls  name tail_ipv4_ct_ingress  tag 689c21f129dac305  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,113,82,83,112,84
	btf_id 183
533: sched_cls  name tail_handle_ipv4_cont  tag 2ddd9a36e690911f  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,115,41,114,82,83,39,76,74,77,116,40,37,38,81
	btf_id 186
534: sched_cls  name __send_drop_notify  tag 1f90740fec8c524b  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 187
535: sched_cls  name tail_handle_arp  tag 8846a6011e5ec666  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,116
	btf_id 188
537: sched_cls  name cil_from_container  tag 64d86a2664e4f65c  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 116,76
	btf_id 190
538: sched_cls  name tail_ipv4_to_endpoint  tag 3b0ae115db0f10c2  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,115,41,82,83,80,114,39,116,40,37,38
	btf_id 191
540: sched_cls  name __send_drop_notify  tag 172c860024e82a1f  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 195
541: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 196
542: sched_cls  name tail_handle_arp  tag 75d1075b26b3dcda  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,118
	btf_id 197
543: sched_cls  name cil_from_container  tag 78676a12bdfc0d95  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 118,76
	btf_id 198
544: sched_cls  name handle_policy  tag 410079928467adc6  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,116,82,83,115,41,80,114,39,84,75,40,37,38
	btf_id 192
545: sched_cls  name tail_handle_ipv4_cont  tag d5d2aa415967baa9  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,117,41,100,82,83,39,76,74,77,118,40,37,38,81
	btf_id 199
546: sched_cls  name tail_ipv4_ct_ingress  tag 25a60c5f2355f8b5  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 200
547: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,116
	btf_id 202
548: sched_cls  name tail_ipv4_ct_egress  tag 2a1108d59161bc74  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,116,82,83,115,84
	btf_id 203
549: sched_cls  name handle_policy  tag d6919da7e8d7a4ea  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,118,82,83,117,41,80,100,39,84,75,40,37,38
	btf_id 201
550: sched_cls  name tail_ipv4_ct_ingress  tag 91b351e31f751ccc  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,118,82,83,117,84
	btf_id 204
551: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,118
	btf_id 205
552: sched_cls  name tail_ipv4_to_endpoint  tag 848a1d87cf932910  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,117,41,82,83,80,100,39,118,40,37,38
	btf_id 206
553: sched_cls  name tail_handle_ipv4  tag c93cb39e8f90381b  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,118
	btf_id 207
554: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
557: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
558: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
561: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
562: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
565: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
566: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
569: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:00:09+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
609: sched_cls  name tail_ipv4_ct_ingress  tag 09a7c16825747350  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 221
610: sched_cls  name cil_from_container  tag e77da223784b5fb3  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,76
	btf_id 222
611: sched_cls  name tail_handle_ipv4  tag 4a6cd22f0c2e0b19  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,134
	btf_id 223
612: sched_cls  name handle_policy  tag 02140c8a7aa8e9bb  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,134,82,83,135,41,80,133,39,84,75,40,37,38
	btf_id 224
613: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,134
	btf_id 225
614: sched_cls  name tail_ipv4_ct_egress  tag f2fa03533b3f4115  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,134,82,83,135,84
	btf_id 226
615: sched_cls  name tail_handle_arp  tag 8589e81bfda6c69f  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,134
	btf_id 227
616: sched_cls  name tail_handle_ipv4_cont  tag 1ea5f0ea16f922be  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,135,41,133,82,83,39,76,74,77,134,40,37,38,81
	btf_id 228
617: sched_cls  name __send_drop_notify  tag df1c2b5b409deea0  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 229
619: sched_cls  name tail_ipv4_to_endpoint  tag 4aaf3cf1d1f6a051  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,135,41,82,83,80,133,39,134,40,37,38
	btf_id 231
620: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
623: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:50+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
636: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
639: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
640: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
643: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
644: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
647: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:10:52+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
