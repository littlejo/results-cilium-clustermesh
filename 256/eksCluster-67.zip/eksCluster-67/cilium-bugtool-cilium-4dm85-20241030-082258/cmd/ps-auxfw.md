USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         682  0.0  0.2 1240432 16580 ?       Ssl  08:22   0:00 cilium-bugtool --archiveType=gz --exclude-object-files
root         697  0.0  0.0   6408  1652 ?        R    08:22   0:00  \_ ps auxfw
root         698  0.0  0.2 1240432 16580 ?       R    08:22   0:00  \_ cilium-bugtool --archiveType=gz --exclude-object-files
root         651  0.0  0.0 1228744 4040 ?        Ssl  08:22   0:00 /bin/gops stack 1
root           1  3.8  4.7 1606336 381456 ?      Ssl  07:59   0:53 cilium-agent --config-dir=/tmp/cilium/config-map
root         417  0.0  0.0 1229488 7044 ?        Sl   08:00   0:01 cilium-health-responder --listen 4240 --pidfile /var/run/cilium/state/health-endpoint.pid
