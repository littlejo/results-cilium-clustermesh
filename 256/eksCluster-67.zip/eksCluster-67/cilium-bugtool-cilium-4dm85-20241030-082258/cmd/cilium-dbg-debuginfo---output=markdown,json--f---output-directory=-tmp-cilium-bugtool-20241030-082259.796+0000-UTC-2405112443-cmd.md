markdown output at /tmp/cilium-bugtool-20241030-082259.796+0000-UTC-2405112443/cmd/cilium-debuginfo-20241030-082331.098+0000-UTC.md
json output at /tmp/cilium-bugtool-20241030-082259.796+0000-UTC-2405112443/cmd/cilium-debuginfo-20241030-082331.098+0000-UTC.json
