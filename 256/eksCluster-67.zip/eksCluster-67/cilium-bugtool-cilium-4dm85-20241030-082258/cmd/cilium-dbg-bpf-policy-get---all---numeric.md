Endpoint ID: 195
Path: /sys/fs/bpf/tc/globals/cilium_policy_00195

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    133344   1535      0        
Allow    Egress      0          ANY          NONE         disabled    17888    194       0        


Endpoint ID: 432
Path: /sys/fs/bpf/tc/globals/cilium_policy_00432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2386
Path: /sys/fs/bpf/tc/globals/cilium_policy_02386

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    134015   1541      0        
Allow    Egress      0          ANY          NONE         disabled    19166    209       0        


Endpoint ID: 3882
Path: /sys/fs/bpf/tc/globals/cilium_policy_03882

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11653730   116295    0        
Allow    Ingress     1          ANY          NONE         disabled    10443272   110059    0        
Allow    Egress      0          ANY          NONE         disabled    13277156   130743    0        


Endpoint ID: 4085
Path: /sys/fs/bpf/tc/globals/cilium_policy_04085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1661686   20996     0        
Allow    Ingress     1          ANY          NONE         disabled    21020     248       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


