1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:58:c2:65:39:7f brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.213.86/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 3418sec preferred_lft 3418sec
    inet6 fe80::858:c2ff:fe65:397f/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:b5:52:60:2f brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.193.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::899:b5ff:fe52:602f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:fe:4d:e9:19:93 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::9cfe:4dff:fee9:1993/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 66:b6:8c:91:cc:64 brd ff:ff:ff:ff:ff:ff
    inet 10.67.0.142/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::64b6:8cff:fe91:cc64/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 6a:91:19:09:cd:f3 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6891:19ff:fe09:cdf3/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ce:79:5d:8e:1b:89 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::cc79:5dff:fe8e:1b89/64 scope link 
       valid_lft forever preferred_lft forever
12: lxcf0d2bc373dda@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:ed:cb:9d:e3:f8 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::88ed:cbff:fe9d:e3f8/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc0ca69ea8ccad@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:25:53:ec:f1:6a brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::ec25:53ff:feec:f16a/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc36ce13a03f6a@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:45:fa:c1:ae:bf brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4c45:faff:fec1:aebf/64 scope link 
       valid_lft forever preferred_lft forever
