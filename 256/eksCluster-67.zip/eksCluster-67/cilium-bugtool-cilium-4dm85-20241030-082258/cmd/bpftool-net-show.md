xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 497
ens6(5) clsact/ingress cil_from_netdev-ens6 id 506
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 491
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 486
cilium_host(7) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 481
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 478
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 543
lxcf0d2bc373dda(12) clsact/ingress cil_from_container-lxcf0d2bc373dda id 528
lxc0ca69ea8ccad(14) clsact/ingress cil_from_container-lxc0ca69ea8ccad id 537
lxc36ce13a03f6a(18) clsact/ingress cil_from_container-lxc36ce13a03f6a id 610

flow_dissector:

netfilter:

