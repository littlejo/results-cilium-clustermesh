key: c3 00 00 00  value: 0f 02 00 00
key: 52 09 00 00  value: 20 02 00 00
key: 2a 0f 00 00  value: 64 02 00 00
key: f5 0f 00 00  value: 25 02 00 00
Found 4 elements
