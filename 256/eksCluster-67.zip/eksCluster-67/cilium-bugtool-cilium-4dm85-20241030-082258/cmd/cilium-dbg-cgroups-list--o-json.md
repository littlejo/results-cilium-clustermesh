[
  {
    "containers": [
      {
        "cgroup-id": 7792,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb6a59f7_6156_4aaa_abc1_1154af73a6f5.slice/cri-containerd-bf1786356496adc4a0e45c0f382448a158b6aacf9abdb426309c8eb136bbebea.scope"
      }
    ],
    "ips": [
      "10.67.0.236"
    ],
    "name": "coredns-cc6ccd49c-x6xf9",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9268,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-bfb72839b9eb32702b4037cebf0341bd7fe2d84956e31a42013de99aa7875ebb.scope"
      },
      {
        "cgroup-id": 9184,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-2c5d8b8562da5cc2cb8250c1979833b2f5dbcf3450f895d6fafa48aff0ba1f26.scope"
      },
      {
        "cgroup-id": 9352,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-502ca1eb7feff1daee61a68620682f9d50089518f1e22da42a56e725ce0937f1.scope"
      }
    ],
    "ips": [
      "10.67.0.233"
    ],
    "name": "clustermesh-apiserver-7c6d5f579d-w4b7n",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7708,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf600e516_c5c0_46ba_9099_3db2dd1cffeb.slice/cri-containerd-e57eab17fa401dc382840aa1a6dc62b7bbaaab5d8afc320381e43037ed90c2cd.scope"
      }
    ],
    "ips": [
      "10.67.0.70"
    ],
    "name": "coredns-cc6ccd49c-tn6sf",
    "namespace": "kube-system"
  }
]

