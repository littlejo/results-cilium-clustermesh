alloc: 125.62MB (131725360 bytes)
total-alloc: 2.29GB (2462560368 bytes)
sys: 325.02MB (340808036 bytes)
lookups: 0
mallocs: 64188909
frees: 63022182
heap-alloc: 125.62MB (131725360 bytes)
heap-sys: 247.48MB (259497984 bytes)
heap-idle: 79.38MB (83230720 bytes)
heap-in-use: 168.10MB (176267264 bytes)
heap-released: 4.08MB (4276224 bytes)
heap-objects: 1166727
stack-in-use: 64.50MB (67633152 bytes)
stack-sys: 64.50MB (67633152 bytes)
stack-mspan-inuse: 2.85MB (2991040 bytes)
stack-mspan-sys: 3.86MB (4047360 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.22MB (1274377 bytes)
gc-sys: 6.00MB (6288872 bytes)
next-gc: when heap-alloc >= 211.69MB (221973448 bytes)
last-gc: 2024-10-30 08:23:09.428424418 +0000 UTC
gc-pause-total: 12.094263ms
gc-pause: 106693
gc-pause-end: 1730276589428424418
num-gc: 83
num-forced-gc: 0
gc-cpu-fraction: 0.000439646526357193
enable-gc: true
debug-gc: false
