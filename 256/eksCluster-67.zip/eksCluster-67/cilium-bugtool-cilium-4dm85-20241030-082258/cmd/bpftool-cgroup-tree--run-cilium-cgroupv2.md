CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb6a59f7_6156_4aaa_abc1_1154af73a6f5.slice/cri-containerd-aaedf728ec05daa7e45f9101444896651f41bbaed7a25a289f7ffd083a74a02e.scope
    561      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbb6a59f7_6156_4aaa_abc1_1154af73a6f5.slice/cri-containerd-bf1786356496adc4a0e45c0f382448a158b6aacf9abdb426309c8eb136bbebea.scope
    569      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podada04c2c_428e_44c5_8fac_01045c527053.slice/cri-containerd-5d430a58ada7a6c6b05cb446afbb9edea9424898bde1795d43b1fc940d47b3e1.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podada04c2c_428e_44c5_8fac_01045c527053.slice/cri-containerd-67ba14da43890ea8007237014a2858e5c1602ca3b6f26b06d57875b4b84f42b5.scope
    54       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda83b1ad9_f5ab_40c6_85eb_bbca8ed5c708.slice/cri-containerd-8a2f53630bac23163f878f2ea932bfadc78ba3a2b83359b4871b60374337665c.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda83b1ad9_f5ab_40c6_85eb_bbca8ed5c708.slice/cri-containerd-bb7c2b49e172aeaa212632b964dbf2bd04460a079845479aa61a9c78d8af7619.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf600e516_c5c0_46ba_9099_3db2dd1cffeb.slice/cri-containerd-e57eab17fa401dc382840aa1a6dc62b7bbaaab5d8afc320381e43037ed90c2cd.scope
    565      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf600e516_c5c0_46ba_9099_3db2dd1cffeb.slice/cri-containerd-f7da2a91f04fc6bce7e462237dd5dfe308ff5ccb9ee4c6ec08a2f685bcc31a3c.scope
    557      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-bfb72839b9eb32702b4037cebf0341bd7fe2d84956e31a42013de99aa7875ebb.scope
    643      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-6009e8bb7a891d728ca74fdb384da7424c560aa42cab1b34c6d9038b94a0f3b9.scope
    623      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-2c5d8b8562da5cc2cb8250c1979833b2f5dbcf3450f895d6fafa48aff0ba1f26.scope
    639      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5c783e02_ab49_4def_914e_d4128dd904d9.slice/cri-containerd-502ca1eb7feff1daee61a68620682f9d50089518f1e22da42a56e725ce0937f1.scope
    647      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65fe7bc5_cfbd_4b76_979a_9300f75e7e13.slice/cri-containerd-8d0f2ec4ff449497a80103f09e2cd79860e14a737ea83dcc40596d389410aeab.scope
    103      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod65fe7bc5_cfbd_4b76_979a_9300f75e7e13.slice/cri-containerd-afe5c210780d290eeedd1138b9013f6a120daad4afb8e97e954681f7f3230c44.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod750d6184_f506_4c14_a5a6_785b4a544a31.slice/cri-containerd-399681534fb721754fcc8657a699ec8a17de0b79a2b924d2fa9e495ae9582932.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod750d6184_f506_4c14_a5a6_785b4a544a31.slice/cri-containerd-cdeea5d846455a6702d40a96c38402c8149856a7e35d18f31b8a54aa86f8aad7.scope
    99       cgroup_device   multi                                          
