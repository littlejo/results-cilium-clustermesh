Total: 665
TCP:   1860 (estab 426, closed 1415, orphaned 0, timewait 576)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  445       434       11       
INET	  455       440       15       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                   172.31.213.86%ens5:68         0.0.0.0:*    uid:192 ino:73833 sk:11c cgroup:unreachable:c4e <->                            
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:36983 sk:11d cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15040 sk:11e cgroup:unreachable:f0c <->                                    
UNCONN 0      0                            127.0.0.1:38321      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:36356 sk:11f fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                                 [::]:8472          [::]:*    ino:36982 sk:120 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15041 sk:121 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::858:c2ff:fe65:397f]%ens5:546           [::]:*    uid:192 ino:15847 sk:122 cgroup:unreachable:c4e v6only:1 <->                   
