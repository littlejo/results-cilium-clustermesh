xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 554
ens6(5) clsact/ingress cil_from_netdev-ens6 id 563
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 540
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 534
cilium_host(7) clsact/egress cil_from_host-cilium_host id 530
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 478
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 479
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 570
lxca54e5ea29a7b(12) clsact/ingress cil_from_container-lxca54e5ea29a7b id 538
lxc30497bc35e72(14) clsact/ingress cil_from_container-lxc30497bc35e72 id 587
lxc6e71a8fe72c6(18) clsact/ingress cil_from_container-lxc6e71a8fe72c6 id 642

flow_dissector:

netfilter:

