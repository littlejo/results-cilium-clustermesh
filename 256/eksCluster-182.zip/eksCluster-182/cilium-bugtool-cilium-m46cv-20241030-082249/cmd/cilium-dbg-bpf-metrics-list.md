REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     35579     2812680     677    bpf_overlay.c
Interface                 INGRESS     632009    130508670   1132   bpf_host.c
Success                   EGRESS      15357     1204036     1694   bpf_host.c
Success                   EGRESS      267171    33709866    1308   bpf_lxc.c
Success                   EGRESS      35177     2780680     53     encap.h
Success                   EGRESS      8374      1328203     86     l3.h
Success                   INGRESS     309732    34866941    86     l3.h
Success                   INGRESS     338979    37847834    235    trace.h
Unsupported L3 protocol   EGRESS      44        3308        1492   bpf_lxc.c
