1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:3d:01:7d:c2:63 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.154.13/18 metric 1024 brd 172.31.191.255 scope global dynamic ens5
       valid_lft 3514sec preferred_lft 3514sec
    inet6 fe80::43d:1ff:fe7d:c263/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 06:90:8c:01:88:c7 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.185.127/18 brd 172.31.191.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::490:8cff:fe01:88c7/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 62:92:4d:97:69:09 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::6092:4dff:fe97:6909/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 52:36:5e:66:23:52 brd ff:ff:ff:ff:ff:ff
    inet 10.182.0.171/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::5036:5eff:fe66:2352/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether b6:36:1c:a8:6c:f1 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::b436:1cff:fea8:6cf1/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f2:da:cb:69:30:b0 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::f0da:cbff:fe69:30b0/64 scope link 
       valid_lft forever preferred_lft forever
12: lxca54e5ea29a7b@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 12:b5:16:48:59:4f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::10b5:16ff:fe48:594f/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc30497bc35e72@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:3b:92:3d:43:ea brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::9c3b:92ff:fe3d:43ea/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc6e71a8fe72c6@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether ee:cc:5b:ef:a5:61 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::eccc:5bff:feef:a561/64 scope link 
       valid_lft forever preferred_lft forever
