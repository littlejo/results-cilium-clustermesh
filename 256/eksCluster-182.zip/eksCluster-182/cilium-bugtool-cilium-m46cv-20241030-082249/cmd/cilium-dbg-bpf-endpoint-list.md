IP ADDRESS         LOCAL ENDPOINT INFO
172.31.154.13:0    (localhost)                                                                                        
10.182.0.16:0      id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61   
10.182.0.103:0     id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0     
10.182.0.227:0     id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F   
172.31.185.127:0   (localhost)                                                                                        
10.182.0.240:0     id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA   
10.182.0.171:0     (localhost)                                                                                        
