29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-30T07:51:18+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-30T07:51:19+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-30T07:51:23+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T07:51:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
50: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T07:51:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
57: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-30T07:51:33+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
88: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
91: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:08+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
92: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:10+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
95: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:10+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
96: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
99: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
108: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:24+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
111: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:24+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
127: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:29+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
130: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:29+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
478: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-30T08:01:40+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 76,99
	btf_id 124
479: sched_cls  name cil_to_overlay  tag f54541dd16fdae4c  gpl
	loaded_at 2024-10-30T08:01:40+0000  uid 0
	xlated 392B  jited 304B  memlock 4096B
	btf_id 125
480: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-30T08:01:40+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 126
481: sched_cls  name tail_handle_ipv4  tag c5f6847699444b9f  gpl
	loaded_at 2024-10-30T08:01:40+0000  uid 0
	xlated 2032B  jited 1616B  memlock 4096B  map_ids 75,74,81,76,99
	btf_id 127
511: sched_cls  name tail_handle_arp  tag 268606b02fa13cce  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,111
	btf_id 163
512: sched_cls  name __send_drop_notify  tag 35ca983ca048ead6  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 165
514: sched_cls  name tail_ipv4_ct_ingress  tag 702ae46e215e003f  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 166
517: sched_cls  name handle_policy  tag 252520f1bcb5bbed  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,111,82,83,113,41,80,109,39,84,75,40,37,38
	btf_id 169
521: sched_cls  name tail_ipv4_ct_egress  tag 91c2a3ea3cfda7fc  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,111,82,83,113,84
	btf_id 172
522: sched_cls  name tail_handle_ipv4  tag a156f68b11cf98ee  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,111
	btf_id 175
524: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,111
	btf_id 177
528: sched_cls  name tail_handle_ipv4_cont  tag e8b1c6ac779c3530  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,113,41,109,82,83,39,76,74,77,111,40,37,38,81
	btf_id 178
530: sched_cls  name cil_from_host  tag c56092b330eb77c6  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 2520B  jited 1872B  memlock 4096B  map_ids 76,75,115
	btf_id 184
532: sched_cls  name __send_drop_notify  tag 4791a027a8b98466  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 186
534: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 188
535: sched_cls  name tail_handle_ipv4_from_host  tag 4b0632cbe2bca768  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,115
	btf_id 189
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,115
	btf_id 190
537: sched_cls  name tail_ipv4_to_endpoint  tag 6bfffce70e959882  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,113,41,82,83,80,109,39,111,40,37,38
	btf_id 182
538: sched_cls  name cil_from_container  tag 799bc5d0a1be240a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 111,76
	btf_id 191
540: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 76
	btf_id 195
541: sched_cls  name tail_handle_ipv4_from_host  tag 4b0632cbe2bca768  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,117
	btf_id 197
542: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,117
	btf_id 198
545: sched_cls  name __send_drop_notify  tag 4791a027a8b98466  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 201
546: sched_cls  name tail_handle_ipv4  tag bc6646c7f392d446  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,119
	btf_id 196
548: sched_cls  name tail_handle_ipv4_from_host  tag 4b0632cbe2bca768  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,121
	btf_id 204
549: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,119
	btf_id 205
550: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,121
	btf_id 206
553: sched_cls  name __send_drop_notify  tag 4791a027a8b98466  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 210
554: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,121,75
	btf_id 211
556: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 76,119,82,83,118,84
	btf_id 207
557: sched_cls  name __send_drop_notify  tag b820f806e70e35a8  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 213
558: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 76,122
	btf_id 216
561: sched_cls  name __send_drop_notify  tag 4791a027a8b98466  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 41
	btf_id 219
562: sched_cls  name tail_handle_ipv4_cont  tag c163231ee00eb30a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 9720B  jited 6304B  memlock 12288B  map_ids 75,118,41,100,82,83,39,76,74,77,119,40,37,38,81
	btf_id 214
563: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 76,122,75
	btf_id 220
565: sched_cls  name tail_handle_ipv4_from_host  tag 4b0632cbe2bca768  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 74,75,76,77,41,81,122
	btf_id 223
566: sched_cls  name tail_ipv4_ct_ingress  tag 3ee01d0979192018  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 76,119,82,83,118,84
	btf_id 221
567: sched_cls  name tail_ipv4_to_endpoint  tag c8a8674313932823  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 75,76,118,41,82,83,80,100,39,119,40,37,38
	btf_id 224
568: sched_cls  name handle_policy  tag 886d711fb79a5972  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 76,119,82,83,118,41,80,100,39,84,75,40,37,38
	btf_id 225
569: sched_cls  name tail_handle_arp  tag 855cd2f983c847eb  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,119
	btf_id 226
570: sched_cls  name cil_from_container  tag 3e82b515e762f0bd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 119,76
	btf_id 227
571: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
574: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
575: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
578: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
579: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,128
	btf_id 229
580: sched_cls  name tail_ipv4_ct_egress  tag 91c2a3ea3cfda7fc  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 230
582: sched_cls  name tail_ipv4_to_endpoint  tag 64915add57e3dba3  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,127,41,82,83,80,126,39,128,40,37,38
	btf_id 232
583: sched_cls  name tail_handle_arp  tag a347820e851bd0fb  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,128
	btf_id 233
584: sched_cls  name handle_policy  tag 36bcdf4a87593132  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,128,82,83,127,41,80,126,39,84,75,40,37,38
	btf_id 234
585: sched_cls  name tail_handle_ipv4  tag 88085237d3bfef26  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,128
	btf_id 235
586: sched_cls  name tail_handle_ipv4_cont  tag cc5441a6855c2a9b  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,127,41,126,82,83,39,76,74,77,128,40,37,38,81
	btf_id 236
587: sched_cls  name cil_from_container  tag 53af92a762d44fc8  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 128,76
	btf_id 237
588: sched_cls  name __send_drop_notify  tag 15967fe9c256d938  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 238
589: sched_cls  name tail_ipv4_ct_ingress  tag 19cd2db0388a92c1  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,128,82,83,127,84
	btf_id 239
590: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
593: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
594: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
597: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:01:43+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
637: sched_cls  name tail_ipv4_ct_egress  tag e8e57b1b5b952948  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 253
638: sched_cls  name handle_policy  tag 33cd2c518bfaf9e8  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 76,142,82,83,143,41,80,141,39,84,75,40,37,38
	btf_id 254
639: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 76,142
	btf_id 255
640: sched_cls  name tail_ipv4_ct_ingress  tag 7975691e19716bc8  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 76,142,82,83,143,84
	btf_id 256
641: sched_cls  name tail_handle_ipv4  tag 035ed541c8ee2aba  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 84,76,78,82,83,79,39,142
	btf_id 257
642: sched_cls  name cil_from_container  tag 37c3b7f8a072d012  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 142,76
	btf_id 258
643: sched_cls  name tail_handle_ipv4_cont  tag 2eafc586b9b41365  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 9720B  jited 6344B  memlock 12288B  map_ids 75,143,41,141,82,83,39,76,74,77,142,40,37,38,81
	btf_id 259
644: sched_cls  name tail_ipv4_to_endpoint  tag 050e8079f6688b74  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 75,76,143,41,82,83,80,141,39,142,40,37,38
	btf_id 260
645: sched_cls  name tail_handle_arp  tag 8f80a7bd23243937  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 76,142
	btf_id 261
647: sched_cls  name __send_drop_notify  tag e10c4f7e4a9bbbff  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 41
	btf_id 263
648: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
651: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:40+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
664: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
667: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
668: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
671: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
672: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
675: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-30T08:11:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
