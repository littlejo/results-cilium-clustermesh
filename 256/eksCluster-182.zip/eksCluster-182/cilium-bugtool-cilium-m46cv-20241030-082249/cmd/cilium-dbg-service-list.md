ID   Frontend              Service Type   Backend                            
1    10.100.0.1:443        ClusterIP      1 => 172.31.204.53:443 (active)    
                                          2 => 172.31.152.151:443 (active)   
2    10.100.19.55:443      ClusterIP      1 => 172.31.154.13:4244 (active)   
3    10.100.0.10:9153      ClusterIP      1 => 10.182.0.227:9153 (active)    
                                          2 => 10.182.0.240:9153 (active)    
4    10.100.0.10:53        ClusterIP      1 => 10.182.0.227:53 (active)      
                                          2 => 10.182.0.240:53 (active)      
5    10.100.234.107:2379   ClusterIP      1 => 10.182.0.16:2379 (active)     
