top - 08:22:51 up 31 min,  0 users,  load average: 0.65, 0.27, 0.19
Tasks:   9 total,   1 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 60.0 us, 30.0 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  3.3 si,  0.0 st
MiB Mem :   7814.2 total,   4484.8 free,   1183.3 used,   2146.1 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6445.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 390672  79536 S  80.0   4.9   0:44.89 cilium-+
    395 root      20   0 1229744   8224   3836 S   6.7   0.1   0:01.12 cilium-+
    725 root      20   0 1243764  18960  13828 S   6.7   0.2   0:00.02 hubble
    644 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    678 root      20   0 1228744   3596   2912 S   0.0   0.0   0:00.00 gops
    684 root      20   0 1240432  16540  11356 S   0.0   0.2   0:00.03 cilium-+
    718 root      20   0    2208    796    716 S   0.0   0.0   0:00.00 timeout
    733 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    757 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
