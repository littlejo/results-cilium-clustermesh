KEY             VALUE
AgentLiveness   1926333944286
UTimeOffset     3379442726562500
