CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55ae1644_5991_4039_96b0_bf5230efaf8c.slice/cri-containerd-1ddb4e7f51a85ae80d88337e26d8fe42e3f8af430fc55ca8e3df11ddd23bda21.scope
    593      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55ae1644_5991_4039_96b0_bf5230efaf8c.slice/cri-containerd-7f0e565fc604c9c71bb8f012e2f619cdd14085aaa29542fb24f5e87df3f0a015.scope
    597      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63fdfe7d_ef95_4310_b2e1_136578fccdb2.slice/cri-containerd-1965a1288c63ee105656764445d3977466a6cf4507e79dfcdb9f8af505cbbfaa.scope
    87       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod63fdfe7d_ef95_4310_b2e1_136578fccdb2.slice/cri-containerd-9bdf71975dccd795d7689bed1f13742fdf217ad020fde2677962afd789fa5298.scope
    130      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5dca2ef5_ffc1_4cef_a970_22c69a8df07c.slice/cri-containerd-c52e388a3e11da4c85d2ce55ed9fc4caad1b758f7ca9075ad06444a72d7955c2.scope
    574      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5dca2ef5_ffc1_4cef_a970_22c69a8df07c.slice/cri-containerd-828fa335ec335639ce3a7b5f7d8895b75cfb24c9391bee63e48027a9d60d300e.scope
    578      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f0864de_c032_4192_8fcf_9111fb38e050.slice/cri-containerd-a22e914639d26a2ba17866d919da05e4fb7f04aa10af2a2e836dd3d727c8ae71.scope
    50       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod8f0864de_c032_4192_8fcf_9111fb38e050.slice/cri-containerd-22a1b6362cab0028d54c60a522e650b3bcff1a8cf0187d188bba00ec65d3fea5.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3c263c4_2027_4d47_9a9d_6577e383b3d8.slice/cri-containerd-d09faa651c01b18c8a7545ce9ddf937cf4601e47ae38dbf96d00577a469e1dbb.scope
    99       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podb3c263c4_2027_4d47_9a9d_6577e383b3d8.slice/cri-containerd-0b148266452277e57a647d432aa0a358484cc1da8caee57b2820e0ad478e0ccc.scope
    95       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbffd3b98_63b9_41d0_b486_9dd08ae302f0.slice/cri-containerd-05cba25315d82d78ccf22fd81f81d79dd8b75bc495ef055cccab218599427e47.scope
    91       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podbffd3b98_63b9_41d0_b486_9dd08ae302f0.slice/cri-containerd-e7373361eb71435e0061ee48fd94325bef39db526283617d3aef8108239e8b4c.scope
    111      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-716fab7e387ee6d13153a9e320e999a8b098fa5a91cdd3e0081968c74b3d77bd.scope
    675      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-65c50ad9d15e48b770a14b515a902fe3fec3de472e97f85ba26582019c1b5f40.scope
    667      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-6a70ee3826968a031569cf64e48db6ef6e7fcd0f9ec80e513390031a8383c784.scope
    651      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-58062cf22b60c3723f1614809eab450e737b384c78c5f0d711fe611aa1eabd2c.scope
    671      cgroup_device   multi                                          
