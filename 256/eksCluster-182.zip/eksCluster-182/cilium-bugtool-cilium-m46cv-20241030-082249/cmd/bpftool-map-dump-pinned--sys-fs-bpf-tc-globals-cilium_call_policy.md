key: b4 01 00 00  value: 05 02 00 00
key: e9 01 00 00  value: 48 02 00 00
key: c2 0a 00 00  value: 38 02 00 00
key: f0 0a 00 00  value: 7e 02 00 00
Found 4 elements
