Endpoint ID: 201
Path: /sys/fs/bpf/tc/globals/cilium_policy_00201

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 436
Path: /sys/fs/bpf/tc/globals/cilium_policy_00436

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    233860   2094      0        
Allow    Ingress     1          ANY          NONE         disabled    123406   1412      0        
Allow    Egress      0          ANY          NONE         disabled    87959    848       0        


Endpoint ID: 489
Path: /sys/fs/bpf/tc/globals/cilium_policy_00489

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    232984   2093      0        
Allow    Ingress     1          ANY          NONE         disabled    124317   1424      0        
Allow    Egress      0          ANY          NONE         disabled    87337    841       0        


Endpoint ID: 2754
Path: /sys/fs/bpf/tc/globals/cilium_policy_02754

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1656019   20916     0        
Allow    Ingress     1          ANY          NONE         disabled    19128     225       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 2800
Path: /sys/fs/bpf/tc/globals/cilium_policy_02800

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11456775   113116    0        
Allow    Ingress     1          ANY          NONE         disabled    9733288    102277    0        
Allow    Egress      0          ANY          NONE         disabled    11887365   117551    0        


