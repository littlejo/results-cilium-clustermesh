[
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod5dca2ef5_ffc1_4cef_a970_22c69a8df07c.slice/cri-containerd-828fa335ec335639ce3a7b5f7d8895b75cfb24c9391bee63e48027a9d60d300e.scope"
      }
    ],
    "ips": [
      "10.182.0.227"
    ],
    "name": "coredns-cc6ccd49c-mvzdq",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod55ae1644_5991_4039_96b0_bf5230efaf8c.slice/cri-containerd-7f0e565fc604c9c71bb8f012e2f619cdd14085aaa29542fb24f5e87df3f0a015.scope"
      }
    ],
    "ips": [
      "10.182.0.240"
    ],
    "name": "coredns-cc6ccd49c-dfq4x",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9263,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-58062cf22b60c3723f1614809eab450e737b384c78c5f0d711fe611aa1eabd2c.scope"
      },
      {
        "cgroup-id": 9179,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-65c50ad9d15e48b770a14b515a902fe3fec3de472e97f85ba26582019c1b5f40.scope"
      },
      {
        "cgroup-id": 9347,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod993d15cb_c2cd_41f6_89c9_4fa8d2390cfd.slice/cri-containerd-716fab7e387ee6d13153a9e320e999a8b098fa5a91cdd3e0081968c74b3d77bd.scope"
      }
    ],
    "ips": [
      "10.182.0.16"
    ],
    "name": "clustermesh-apiserver-56765cd49d-rrn9c",
    "namespace": "kube-system"
  }
]

