Node 0, zone      DMA      5      5      5      4     10      8      8      8      6      5    222 
Node 0, zone   Normal    132    232     59     51     14    102     24     15      5      3    858 
