filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc6e71a8fe72c6 direct-action not_in_hw id 642 tag 37c3b7f8a072d012 jited 
