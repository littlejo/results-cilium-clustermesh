alloc: 191.75MB (201060280 bytes)
total-alloc: 2.24GB (2408738200 bytes)
sys: 332.77MB (348934500 bytes)
lookups: 0
mallocs: 63451556
frees: 61472055
heap-alloc: 191.75MB (201060280 bytes)
heap-sys: 255.61MB (268025856 bytes)
heap-idle: 40.35MB (42311680 bytes)
heap-in-use: 215.26MB (225714176 bytes)
heap-released: 4.45MB (4661248 bytes)
heap-objects: 1979501
stack-in-use: 64.34MB (67469312 bytes)
stack-sys: 64.34MB (67469312 bytes)
stack-mspan-inuse: 3.34MB (3504800 bytes)
stack-mspan-sys: 3.84MB (4031040 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 982.24KB (1005817 bytes)
gc-sys: 6.03MB (6323736 bytes)
next-gc: when heap-alloc >= 223.75MB (234618904 bytes)
last-gc: 2024-10-30 08:22:51.435764619 +0000 UTC
gc-pause-total: 7.742664ms
gc-pause: 166862
gc-pause-end: 1730276571435764619
num-gc: 82
num-forced-gc: 0
gc-cpu-fraction: 0.0004962893636300639
enable-gc: true
debug-gc: false
