{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.171:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.774Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.154.13:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.774Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.185.127:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:37.774Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.276Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.282Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:42.310Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:01:43.474Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:39.682Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:39.684Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:39.684Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:39.713Z",
  "value": "id=3135  sec_id=6012649 flags=0x0000 ifindex=16  mac=66:5B:01:5D:1B:47 nodemac=86:D7:D9:EA:B0:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:39.714Z",
  "value": "id=3135  sec_id=6012649 flags=0x0000 ifindex=16  mac=66:5B:01:5D:1B:47 nodemac=86:D7:D9:EA:B0:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:40.683Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:40.683Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:40.683Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:04:40.683Z",
  "value": "id=3135  sec_id=6012649 flags=0x0000 ifindex=16  mac=66:5B:01:5D:1B:47 nodemac=86:D7:D9:EA:B0:90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:40.470Z",
  "value": "id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.182.0.51:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:51.114Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.854Z",
  "value": "id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.855Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.856Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:02.856Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.964Z",
  "value": "id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.964Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.966Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:03.967Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.919Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.919Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.919Z",
  "value": "id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:04.919Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.103:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.919Z",
  "value": "id=2754  sec_id=4     flags=0x0000 ifindex=10  mac=4E:23:4D:F5:FA:5B nodemac=F2:DA:CB:69:30:B0"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.227:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.919Z",
  "value": "id=436   sec_id=6011088 flags=0x0000 ifindex=12  mac=F2:9D:6E:82:EE:0E nodemac=12:B5:16:48:59:4F"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.240:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.919Z",
  "value": "id=489   sec_id=6011088 flags=0x0000 ifindex=14  mac=22:12:54:E9:3B:3A nodemac=9E:3B:92:3D:43:EA"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.182.0.16:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:12:05.920Z",
  "value": "id=2800  sec_id=6012649 flags=0x0000 ifindex=18  mac=1A:71:0F:3D:9E:0B nodemac=EE:CC:5B:EF:A5:61"
}

