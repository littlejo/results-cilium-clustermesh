KEY             VALUE
AgentLiveness   1719985614196
UTimeOffset     3379443138671875
