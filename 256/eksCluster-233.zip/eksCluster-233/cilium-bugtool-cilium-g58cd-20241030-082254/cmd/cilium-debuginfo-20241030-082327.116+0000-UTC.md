# Cilium debug information

#### Cilium environment keys

```
mesh-auth-rotated-identities-queue-size:1024
endpoint-queue-size:25
enable-k8s-endpoint-slice:true
http-retry-timeout:0
identity-change-grace-period:5s
bpf-ct-timeout-regular-tcp:2h13m20s
k8s-service-cache-size:128
state-dir:/var/run/cilium
bpf-lb-source-range-map-max:0
enable-high-scale-ipcache:false
bpf-lb-sock-terminate-pod-connections:false
mesh-auth-signal-backoff-duration:1s
annotate-k8s-node:false
k8s-sync-timeout:3m0s
cni-chaining-target:
enable-unreachable-routes:false
use-full-tls-context:false
enable-bbr:false
bpf-root:/sys/fs/bpf
proxy-portrange-max:20000
hubble-metrics:
proxy-prometheus-port:0
hubble-listen-address::4244
custom-cni-conf:false
bpf-map-event-buffers:
cluster-pool-ipv4-mask-size:24
mesh-auth-mutual-connect-timeout:5s
enable-endpoint-health-checking:true
proxy-max-requests-per-connection:0
hubble-redact-http-headers-allow:
enable-service-topology:false
kvstore-connectivity-timeout:2m0s
dnsproxy-concurrency-limit:0
ingress-secrets-namespace:
log-system-load:false
operator-prometheus-serve-addr::9963
cluster-name:cmesh234
enable-cilium-api-server-access:
enable-health-check-loadbalancer-ip:false
proxy-admin-port:0
hubble-redact-enabled:false
enable-k8s-api-discovery:false
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
envoy-config-timeout:2m0s
trace-payloadlen:128
enable-auto-protect-node-port-range:true
identity-allocation-mode:crd
kube-proxy-replacement-healthz-bind-address:
encryption-strict-mode-cidr:
join-cluster:false
k8s-service-proxy-name:
encryption-strict-mode-allow-remote-node-identities:false
ipsec-key-file:
enable-session-affinity:false
ipv4-native-routing-cidr:
enable-runtime-device-detection:true
local-router-ipv6:
enable-bpf-tproxy:false
tunnel-port:0
enable-tcx:true
arping-refresh-period:30s
hubble-recorder-sink-queue-size:1024
bpf-ct-timeout-service-tcp:2h13m20s
mesh-auth-spire-admin-socket:
enable-ingress-controller:false
fqdn-regex-compile-lru-size:1024
enable-ipsec-xfrm-state-caching:true
bpf-fragments-map-max:8192
enable-pmtu-discovery:false
disable-endpoint-crd:false
config-sources:config-map:kube-system/cilium-config
hubble-export-file-path:
ipv4-service-range:auto
dns-policy-unload-on-shutdown:false
clustermesh-config:/var/lib/cilium/clustermesh/
enable-ipsec:false
enable-ipsec-encrypted-overlay:false
policy-accounting:true
bpf-lb-maglev-map-max:0
synchronize-k8s-nodes:true
wireguard-persistent-keepalive:0s
bpf-lb-rss-ipv6-src-cidr:
egress-gateway-reconciliation-trigger-interval:1s
log-driver:
bgp-config-path:/var/lib/cilium/bgp/config.yaml
k8s-require-ipv6-pod-cidr:false
hubble-event-buffer-capacity:4095
config-dir:/tmp/cilium/config-map
enable-bandwidth-manager:false
vtep-endpoint:
bpf-lb-algorithm:random
enable-host-port:false
hubble-drop-events-interval:2m0s
conntrack-gc-max-interval:0s
enable-well-known-identities:false
enable-ipv4-fragment-tracking:true
operator-api-serve-addr:127.0.0.1:9234
k8s-kubeconfig-path:
mesh-auth-spiffe-trust-domain:spiffe.cilium
pprof-address:localhost
route-metric:0
config:
mesh-auth-mutual-listener-port:0
agent-labels:
ip-masq-agent-config-path:/etc/config/ip-masq-agent
enable-nat46x64-gateway:false
proxy-gid:1337
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
tofqdns-pre-cache:
bpf-auth-map-max:524288
hubble-export-file-compress:false
labels:
node-port-acceleration:disabled
remove-cilium-node-taints:true
hubble-recorder-storage-path:/var/run/cilium/pcaps
envoy-base-id:0
bpf-lb-sock-hostns-only:false
enable-ipv6:false
lib-dir:/var/lib/cilium
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
debug:false
http-retry-count:3
pprof:false
enable-vtep:false
disable-iptables-feeder-rules:
exclude-local-address:
bpf-ct-timeout-regular-tcp-fin:10s
hubble-drop-events-reasons:auth_required,policy_denied
bpf-lb-service-map-max:0
enable-health-checking:true
set-cilium-node-taints:true
enable-health-check-nodeport:true
bpf-lb-affinity-map-max:0
mesh-auth-gc-interval:5m0s
cgroup-root:/run/cilium/cgroupv2
identity-gc-interval:15m0s
allow-localhost:auto
mesh-auth-queue-size:1024
ipam-cilium-node-update-rate:15s
bpf-lb-service-backend-map-max:0
enable-local-node-route:true
hubble-export-file-max-backups:5
kvstore-max-consecutive-quorum-errors:2
k8s-api-server:
l2-announcements-lease-duration:15s
enable-ipv6-masquerade:true
metrics:
bpf-lb-map-max:65536
bpf-events-trace-enabled:true
certificates-directory:/var/run/cilium/certs
gops-port:9890
derive-masq-ip-addr-from-device:
bpf-lb-external-clusterip:false
enable-ipv6-ndp:false
k8s-client-burst:20
pprof-port:6060
hubble-skip-unknown-cgroup-ids:true
container-ip-local-reserved-ports:auto
egress-gateway-policy-map-max:16384
enable-local-redirect-policy:false
preallocate-bpf-maps:false
hubble-redact-http-headers-deny:
k8s-client-qps:10
bpf-policy-map-full-reconciliation-interval:15m0s
set-cilium-is-up-condition:true
enable-recorder:false
hubble-flowlogs-config-path:
tofqdns-max-deferred-connection-deletes:10000
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
enable-wireguard-userspace-fallback:false
cluster-pool-ipv4-cidr:10.233.0.0/16
bpf-lb-rev-nat-map-max:0
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-l7-proxy:true
restore:true
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
external-envoy-proxy:true
enable-bpf-clock-probe:false
enable-masquerade-to-route-source:false
bpf-lb-mode:snat
ipv4-service-loopback-address:169.254.42.1
gateway-api-secrets-namespace:
encrypt-node:false
direct-routing-device:
mke-cgroup-mount:
policy-cidr-match-mode:
ipam-default-ip-pool:default
prometheus-serve-addr:
node-port-bind-protection:true
unmanaged-pod-watcher-interval:15
bpf-policy-map-max:16384
bpf-lb-dsr-l4-xlate:frontend
hubble-event-queue-size:0
dnsproxy-lock-timeout:500ms
cni-log-file:/var/run/cilium/cilium-cni.log
enable-srv6:false
install-no-conntrack-iptables-rules:false
routing-mode:tunnel
k8s-heartbeat-timeout:30s
enable-tracing:false
hubble-export-allowlist:
enable-policy:default
hubble-prefer-ipv6:false
k8s-client-connection-timeout:30s
dns-max-ips-per-restored-rule:1000
endpoint-gc-interval:5m0s
bpf-ct-timeout-regular-tcp-syn:1m0s
enable-custom-calls:false
ipv6-range:auto
enable-route-mtu-for-cni-chaining:false
crd-wait-timeout:5m0s
clustermesh-enable-mcs-api:false
max-controller-interval:0
vtep-cidr:
bpf-ct-global-tcp-max:524288
bgp-announce-pod-cidr:false
dnsproxy-insecure-skip-transparent-mode-check:false
service-no-backend-response:reject
policy-audit-mode:false
node-port-algorithm:random
enable-wireguard:false
ipsec-key-rotation-duration:5m0s
bpf-node-map-max:16384
allocator-list-timeout:3m0s
mesh-auth-enabled:true
cluster-health-port:4240
enable-gateway-api:false
vlan-bpf-bypass:
read-cni-conf:
kvstore-opt:
max-internal-timer-delay:0s
enable-ipip-termination:false
enable-l2-pod-announcements:false
bpf-lb-rss-ipv4-src-cidr:
proxy-max-connection-duration-seconds:0
proxy-xff-num-trusted-hops-egress:0
l2-announcements-renew-deadline:5s
bpf-ct-global-any-max:262144
envoy-secrets-namespace:
enable-envoy-config:false
enable-endpoint-routes:false
k8s-client-connection-keep-alive:30s
agent-health-port:9879
debug-verbose:
envoy-config-retry-interval:15s
bpf-lb-dsr-dispatch:opt
envoy-log:
enable-external-ips:false
enable-xt-socket-fallback:true
enable-host-legacy-routing:false
ipam-multi-pool-pre-allocation:
monitor-aggregation:medium
kube-proxy-replacement:false
install-iptables-rules:true
envoy-keep-cap-netbindservice:false
endpoint-bpf-prog-watchdog-interval:30s
enable-ipv4-big-tcp:false
dnsproxy-enable-transparent-mode:true
tofqdns-proxy-response-max-delay:100ms
enable-bgp-control-plane:false
agent-liveness-update-interval:1s
egress-masquerade-interfaces:ens+
proxy-xff-num-trusted-hops-ingress:0
k8s-require-ipv4-pod-cidr:false
cni-exclusive:true
dnsproxy-lock-count:131
static-cnp-path:
fixed-identity-mapping:
proxy-connect-timeout:2
bpf-sock-rev-map-max:262144
l2-pod-announcements-interface:
bpf-nat-global-max:524288
ipv6-mcast-device:
mtu:0
enable-hubble:true
enable-k8s:true
exclude-node-label-patterns:
bpf-lb-acceleration:disabled
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
bpf-ct-timeout-service-any:1m0s
label-prefix-file:
procfs:/host/proc
hubble-redact-http-userinfo:true
tofqdns-dns-reject-response-code:refused
dnsproxy-concurrency-processing-grace-period:0s
encrypt-interface:
tofqdns-enable-dns-compression:true
hubble-metrics-server:
log-opt:
enable-node-port:false
enable-stale-cilium-endpoint-cleanup:true
direct-routing-skip-unreachable:false
hubble-monitor-events:
proxy-idle-timeout-seconds:60
nat-map-stats-entries:32
kvstore-periodic-sync:5m0s
local-max-addr-scope:252
enable-cilium-endpoint-slice:false
multicast-enabled:false
enable-hubble-recorder-api:true
hubble-redact-kafka-apikey:false
clustermesh-sync-timeout:1m0s
hubble-export-denylist:
kvstore-lease-ttl:15m0s
ipv6-cluster-alloc-cidr:f00d::/64
enable-icmp-rules:true
policy-queue-size:100
dnsproxy-socket-linger-timeout:10
monitor-aggregation-flags:all
bpf-events-policy-verdict-enabled:true
monitor-queue-size:0
clustermesh-ip-identities-sync-timeout:1m0s
enable-xdp-prefilter:false
cni-chaining-mode:none
http-max-grpc-timeout:0
keep-config:false
socket-path:/var/run/cilium/cilium.sock
srv6-encap-mode:reduced
enable-ipv4-masquerade:true
enable-k8s-terminating-endpoint:true
controller-group-metrics:
bypass-ip-availability-upon-restore:false
identity-heartbeat-timeout:30m0s
cflags:
egress-multi-home-ip-rule-compat:false
proxy-portrange-min:10000
devices:
policy-trigger-interval:1s
cilium-endpoint-gc-interval:5m0s
auto-create-cilium-node-resource:true
nat-map-stats-interval:30s
enable-ipv4-egress-gateway:false
enable-bpf-masquerade:false
enable-ipsec-key-watcher:true
bgp-announce-lb-ip:false
http-request-timeout:3600
use-cilium-internal-ip-for-ipsec:false
api-rate-limit:
k8s-namespace:kube-system
enable-ip-masq-agent:false
enable-active-connection-tracking:false
iptables-random-fully:false
datapath-mode:veth
allow-icmp-frag-needed:true
node-port-range:
ipam:cluster-pool
tunnel-protocol:vxlan
max-connected-clusters:511
nodeport-addresses:
kvstore:
ipv6-pod-subnets:
iptables-lock-timeout:5s
tofqdns-min-ttl:0
bpf-events-drop-enabled:true
enable-host-firewall:false
ipv4-node:auto
ipv6-native-routing-cidr:
hubble-export-fieldmask:
http-idle-timeout:0
disable-external-ip-mitigation:false
identity-restore-grace-period:30s
enable-identity-mark:true
monitor-aggregation-interval:5s
disable-envoy-version-check:false
local-router-ipv4:
node-port-mode:snat
tofqdns-idle-connection-grace-period:0s
clustermesh-enable-endpoint-sync:false
enable-ipv6-big-tcp:false
enable-ipv4:true
hubble-disable-tls:false
enable-l2-neigh-discovery:true
enable-encryption-strict-mode:false
nodes-gc-interval:5m0s
bpf-ct-timeout-regular-any:1m0s
enable-svc-source-range-check:true
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
tofqdns-proxy-port:0
vtep-mac:
hubble-drop-events:false
trace-sock:true
bpf-ct-timeout-service-tcp-grace:1m0s
bpf-filter-priority:1
force-device-detection:false
cluster-id:234
enable-cilium-health-api-server-access:
http-normalize-path:true
ipv4-range:auto
node-labels:
conntrack-gc-interval:0s
cni-external-routing:false
ipv6-node:auto
enable-l2-announcements:false
cmdref:
prepend-iptables-chains:true
ipv6-service-range:auto
ipv4-pod-subnets:
enable-node-selector-labels:false
vtep-mask:
enable-mke:false
enable-sctp:false
l2-announcements-retry-period:2s
hubble-socket-path:/var/run/cilium/hubble.sock
hubble-redact-http-urlquery:false
tofqdns-endpoint-max-ip-per-hostname:50
enable-k8s-networkpolicy:true
bpf-lb-maglev-table-size:16381
enable-monitor:true
bpf-lb-sock:false
bpf-map-dynamic-size-ratio:0.0025
auto-direct-node-routes:false
bpf-neigh-global-max:524288
enable-metrics:true
version:false
hubble-export-file-max-size-mb:10
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4           STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                     
503        Disabled           Disabled          7690038    k8s:eks.amazonaws.com/component=coredns                                             10.233.0.144   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh234                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
978        Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.large                                                     ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                      
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                                
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                 
                                                           reserved:host                                                                                              
1380       Disabled           Disabled          4          reserved:health                                                                     10.233.0.53    ready   
1505       Disabled           Disabled          7690038    k8s:eks.amazonaws.com/component=coredns                                             10.233.0.221   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh234                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                            
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=kube-dns                                                                                       
2399       Disabled           Disabled          7677376    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.233.0.178   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                       
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                 
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh234                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                              
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                                
                                                           k8s:k8s-app=clustermesh-apiserver                                                                          
```

#### BPF Policy Get 503

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112510   1290      0        
Allow    Egress      0          ANY          NONE         disabled    15944    172       0        

```


#### BPF CT List 503

```
Invalid argument: unknown type 503
```


#### Endpoint Get 503

```
[
  {
    "id": 503,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-503-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "a1f408d9-a28e-4066-8483-bd1ad373e1ca"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-503",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:42.718Z",
            "success-count": 4
          },
          "uuid": "3f71ea00-175b-4b9c-8bc0-ad0833c9128c"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-8mfzn",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:03:42.716Z",
            "success-count": 1
          },
          "uuid": "ba66dc7f-253a-4062-bff6-5c91691259b7"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-503",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:44.959Z",
            "success-count": 2
          },
          "uuid": "a29669f4-bcfe-4741-84f9-256e56561e20"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (503)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:22.822Z",
            "success-count": 120
          },
          "uuid": "4ddd0d7d-da90-465d-b9fa-bf7180c0df26"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "f638a90336801b55b5b3d56f8ae26210b938934bcb13213fc7564d9d08605d60:eth0",
        "container-id": "f638a90336801b55b5b3d56f8ae26210b938934bcb13213fc7564d9d08605d60",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-8mfzn",
        "pod-name": "kube-system/coredns-cc6ccd49c-8mfzn"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7690038,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:20Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.233.0.144",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "86:fd:d3:ab:dd:de",
        "interface-index": 14,
        "interface-name": "lxc8dc79c0ad5c8",
        "mac": "e6:41:16:23:da:f7"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7690038,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7690038,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 503

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 503

```
Timestamp              Status   State                   Message
2024-10-30T08:11:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:20Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-30T08:03:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:45Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-30T08:03:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-30T08:03:42Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:42Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:42Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7690038

```
ID        LABELS
7690038   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh234
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 978

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 978

```
Invalid argument: unknown type 978
```


#### Endpoint Get 978

```
[
  {
    "id": 978,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-978-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "8a4ba118-4b33-4ceb-887b-161be17741a9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-978",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:40.631Z",
            "success-count": 4
          },
          "uuid": "05216a7e-4da9-4a0f-addf-8282512f5da9"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-978",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:41.741Z",
            "success-count": 2
          },
          "uuid": "d2c6487f-ce6a-46ed-9b1d-9d413000582b"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.large",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:20Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "16:80:44:0a:05:17",
        "interface-name": "cilium_host",
        "mac": "16:80:44:0a:05:17"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 978

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 978

```
Timestamp              Status   State                   Message
2024-10-30T08:11:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:20Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:46Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:46Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:44Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:41Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:41Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:40Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:40Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:40Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### BPF Policy Get 1380

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1660530   21012     0        
Allow    Ingress     1          ANY          NONE         disabled    17794     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        

```


#### BPF CT List 1380

```
Invalid argument: unknown type 1380
```


#### Endpoint Get 1380

```
[
  {
    "id": 1380,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1380-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "68af0466-991f-46de-8b72-9a61159f444e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1380",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:41.730Z",
            "success-count": 4
          },
          "uuid": "1ce066c8-0fd1-4058-aadb-d52c222c7aa0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1380",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:44.951Z",
            "success-count": 2
          },
          "uuid": "27277a3c-606e-461e-9434-b69898095de3"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:20Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.233.0.53",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "3e:6f:fd:5d:f1:98",
        "interface-index": 10,
        "interface-name": "lxc_health",
        "mac": "fa:c1:33:00:63:9f"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1380

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1380

```
Timestamp              Status   State                   Message
2024-10-30T08:11:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:20Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:38Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:38Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:38Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:38Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:37Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:45Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:03:45Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:45Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:03:44Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:43Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:42Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:41Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:41Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:41Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:03:40Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1505

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112642   1292      0        
Allow    Egress      0          ANY          NONE         disabled    16493    178       0        

```


#### BPF CT List 1505

```
Invalid argument: unknown type 1505
```


#### Endpoint Get 1505

```
[
  {
    "id": 1505,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1505-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "bedee0bb-3d45-42ee-8cde-9f9ac7e625b5"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1505",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:42.718Z",
            "success-count": 4
          },
          "uuid": "68574b08-5a20-4463-902d-b6054d64f7f5"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-jhbzw",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:03:42.716Z",
            "success-count": 1
          },
          "uuid": "34a39268-a87b-4b37-85a0-69f2555afc6e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1505",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:18:45.023Z",
            "success-count": 2
          },
          "uuid": "83fc15d9-0431-43bd-9d77-53a6f1d1f557"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1505)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:22.822Z",
            "success-count": 120
          },
          "uuid": "aa9fc446-cd6e-4f3b-90e1-3b077a556ae2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "ff0f6e2fc9f40b706d9eaee490f22e058f76a59b67189972b540f358bc5c6f63:eth0",
        "container-id": "ff0f6e2fc9f40b706d9eaee490f22e058f76a59b67189972b540f358bc5c6f63",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-jhbzw",
        "pod-name": "kube-system/coredns-cc6ccd49c-jhbzw"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7690038,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:20Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.233.0.221",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "de:7c:a8:32:b0:a6",
        "interface-index": 12,
        "interface-name": "lxc72d77f765d2c",
        "mac": "5a:b3:a8:6b:c8:2f"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7690038,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7690038,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1505

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1505

```
Timestamp              Status    State                   Message
2024-10-30T08:11:20Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:20Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:20Z   OK        regenerating            Regenerating endpoint: 
2024-10-30T08:11:20Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:19Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:19Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:19Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:19Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:18Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:18Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:18Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:18Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:17Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:17Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:17Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:17Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:38Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:38Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:38Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:38Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:06:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:06:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:06:37Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:06:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:45Z   OK        ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:03:45Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:03:44Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:03:43Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration trigger due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-30T08:03:42Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:03:42Z   OK        ready                   Set identity for this endpoint
2024-10-30T08:03:42Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:03:42Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 7690038

```
ID        LABELS
7690038   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh234
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2399

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11579476   115337    0        
Allow    Ingress     1          ANY          NONE         disabled    10420447   109928    0        
Allow    Egress      0          ANY          NONE         disabled    12817823   126395    0        

```


#### BPF CT List 2399

```
Invalid argument: unknown type 2399
```


#### Endpoint Get 2399

```
[
  {
    "id": 2399,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2399-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "9d680ffb-4865-4cf3-b66a-1171cf489e5c"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2399",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:21:04.717Z",
            "success-count": 3
          },
          "uuid": "6425dec5-1701-48b6-8327-0c85988e58b9"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-645c88bd8b-q2rqj",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:04.715Z",
            "success-count": 1
          },
          "uuid": "66299bab-6a76-408f-bae9-6d714de5ec85"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2399",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:11:04.752Z",
            "success-count": 1
          },
          "uuid": "94681ab8-7580-45a1-950c-c6dee07fce49"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (2399)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-30T08:23:24.805Z",
            "success-count": 76
          },
          "uuid": "56e8d716-1c57-4363-9c0d-1110bea44a02"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "7b4ae428fe155115198882c50b3923244040df10073a8ec430eed76ca21020d9:eth0",
        "container-id": "7b4ae428fe155115198882c50b3923244040df10073a8ec430eed76ca21020d9",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-645c88bd8b-q2rqj",
        "pod-name": "kube-system/clustermesh-apiserver-645c88bd8b-q2rqj"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 7677376,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=645c88bd8b"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh234",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-30T08:11:20Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.233.0.178",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "1a:20:bd:10:1b:00",
        "interface-index": 18,
        "interface-name": "lxc9956b0e3ae05",
        "mac": "5a:72:06:2f:46:31"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7677376,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 7677376,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2399

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2399

```
Timestamp              Status   State                   Message
2024-10-30T08:11:20Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-30T08:11:20Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:20Z   OK       regenerating            Regenerating endpoint: 
2024-10-30T08:11:20Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-30T08:11:19Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:19Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:19Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:19Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:18Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:18Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:18Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:18Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:17Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-30T08:11:17Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:17Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-30T08:11:17Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-30T08:11:04Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-30T08:11:04Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-30T08:11:04Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-30T08:11:04Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-30T08:11:04Z   OK       ready                   Set identity for this endpoint
2024-10-30T08:11:04Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 7677376

```
ID        LABELS
7677376   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh234
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### Policy get

```
:
 []
Revision: 1

```


#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 33579670                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 33579670                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 33579670                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-4013000000 rw-p 00000000 00:00 0 
4013000000-4014000000 ---p 00000000 00:00 0 
ffff60d70000-ffff610e6000 rw-p 00000000 00:00 0 
ffff610e9000-ffff611db000 rw-p 00000000 00:00 0 
ffff611e2000-ffff612c4000 rw-p 00000000 00:00 0 
ffff612c4000-ffff61305000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61305000-ffff61346000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61346000-ffff61386000 rw-p 00000000 00:00 0 
ffff61386000-ffff61388000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff61388000-ffff6138a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6138a000-ffff61951000 rw-p 00000000 00:00 0 
ffff61951000-ffff61a51000 rw-p 00000000 00:00 0 
ffff61a51000-ffff61a62000 rw-p 00000000 00:00 0 
ffff61a62000-ffff63a62000 rw-p 00000000 00:00 0 
ffff63a62000-ffff63ae2000 ---p 00000000 00:00 0 
ffff63ae2000-ffff63ae3000 rw-p 00000000 00:00 0 
ffff63ae3000-ffff83ae2000 ---p 00000000 00:00 0 
ffff83ae2000-ffff83ae3000 rw-p 00000000 00:00 0 
ffff83ae3000-ffffa3a72000 ---p 00000000 00:00 0 
ffffa3a72000-ffffa3a73000 rw-p 00000000 00:00 0 
ffffa3a73000-ffffa7a64000 ---p 00000000 00:00 0 
ffffa7a64000-ffffa7a65000 rw-p 00000000 00:00 0 
ffffa7a65000-ffffa8262000 ---p 00000000 00:00 0 
ffffa8262000-ffffa8263000 rw-p 00000000 00:00 0 
ffffa8263000-ffffa8362000 ---p 00000000 00:00 0 
ffffa8362000-ffffa83c2000 rw-p 00000000 00:00 0 
ffffa83c2000-ffffa83c4000 r--p 00000000 00:00 0                          [vvar]
ffffa83c4000-ffffa83c5000 r-xp 00000000 00:00 0                          [vdso]
ffffc0ea0000-ffffc0ec1000 rw-p 00000000 00:00 0                          [stack]

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=12) "10.233.0.178": (string) (len=50) "kube-system/clustermesh-apiserver-645c88bd8b-q2rqj",
  (string) (len=12) "10.233.0.205": (string) (len=6) "router",
  (string) (len=11) "10.233.0.53": (string) (len=6) "health",
  (string) (len=12) "10.233.0.144": (string) (len=35) "kube-system/coredns-cc6ccd49c-8mfzn",
  (string) (len=12) "10.233.0.221": (string) (len=35) "kube-system/coredns-cc6ccd49c-jhbzw"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=21) "default:172.31.202.43": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001309c30)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001c0e420,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001c0e420,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4000325c30)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x40000f4000)(frontends:[10.100.149.148]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x40000f4160)(frontends:[10.100.0.10]/ports=[dns-tcp metrics dns]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001034210)(frontends:[]/ports=[apiserv-metrics kvmesh-metrics etcd-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x40006cd8c0)(frontends:[10.100.27.183]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001680fa0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4002b68a90)(172.31.161.90:443/TCP,172.31.246.245:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001680fa8)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-w28tx": (*k8s.Endpoints)(0x40031c6340)(172.31.202.43:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001680fb0)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-dx8mg": (*k8s.Endpoints)(0x4001e44d00)(10.233.0.144:53/TCP[eu-west-3b],10.233.0.144:53/UDP[eu-west-3b],10.233.0.144:9153/TCP[eu-west-3b],10.233.0.221:53/TCP[eu-west-3b],10.233.0.221:53/UDP[eu-west-3b],10.233.0.221:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x4001681410)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-x479v": (*k8s.Endpoints)(0x4002db0c30)(10.233.0.178:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x40017eaee0)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400097cc80)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400f6bc180
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400004b3e0,
  gcExited: (chan struct {}) 0x400004b440,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x40018bb880)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001805038)({
      MetricVec: (*prometheus.MetricVec)(0x4001b791a0)({
       metricMap: (*prometheus.metricMap)(0x4001b791d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7c20)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x40018bb900)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001805040)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79230)({
       metricMap: (*prometheus.metricMap)(0x4001b79260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7c80)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x40018bb980)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805048)({
      MetricVec: (*prometheus.MetricVec)(0x4001b792c0)({
       metricMap: (*prometheus.metricMap)(0x4001b792f0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7ce0)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x40018bba00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805050)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79350)({
       metricMap: (*prometheus.metricMap)(0x4001b79380)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7d40)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x40018bba80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805058)({
      MetricVec: (*prometheus.MetricVec)(0x4001b793e0)({
       metricMap: (*prometheus.metricMap)(0x4001b79410)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7da0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x40018bbb00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805060)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79470)({
       metricMap: (*prometheus.metricMap)(0x4001b794a0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7e00)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x40018bbb80)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805068)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79500)({
       metricMap: (*prometheus.metricMap)(0x4001b79530)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7e60)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x40018bbc00)({
     GaugeVec: (*prometheus.GaugeVec)(0x4001805070)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79590)({
       metricMap: (*prometheus.metricMap)(0x4001b795c0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7ec0)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x40018bbc80)({
     ObserverVec: (*prometheus.HistogramVec)(0x4001805078)({
      MetricVec: (*prometheus.MetricVec)(0x4001b79620)({
       metricMap: (*prometheus.metricMap)(0x4001b79650)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40017e7f20)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x40017eaee0)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001c160e0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001b71590)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 304ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2,
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.233.0.0/24, 
Allocated addresses:
  10.233.0.144 (kube-system/coredns-cc6ccd49c-8mfzn)
  10.233.0.178 (kube-system/clustermesh-apiserver-645c88bd8b-q2rqj)
  10.233.0.205 (router)
  10.233.0.221 (kube-system/coredns-cc6ccd49c-jhbzw)
  10.233.0.53 (health)
ClusterMesh:   255/255 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh129: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=129, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh130: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=130, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh131: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=131, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh132: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=132, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh133: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=133, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh134: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=134, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh135: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=135, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh136: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=136, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh137: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=137, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh138: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=138, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh139: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=139, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh140: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=140, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh141: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=141, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh142: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=142, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh143: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=143, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh144: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=144, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh145: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=145, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh146: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=146, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh147: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=147, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh148: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=148, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh149: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=149, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh150: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=150, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh151: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=151, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh152: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=152, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh153: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=153, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh154: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=154, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh155: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=155, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh156: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=156, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh157: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=157, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh158: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=158, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh159: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=159, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh160: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=160, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh161: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=161, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh162: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=162, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh163: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=163, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh164: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=164, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh165: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=165, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh166: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=166, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh167: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=167, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh168: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=168, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh169: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=169, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh170: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=170, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh171: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=171, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh172: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=172, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh173: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=173, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh174: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=174, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh175: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=175, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh176: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=176, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh177: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=177, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh178: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=178, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh179: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=179, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh180: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=180, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh181: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=181, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh182: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=182, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh183: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=183, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh184: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=184, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh185: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=185, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh186: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=186, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh187: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=187, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh188: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=188, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh189: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=189, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh190: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=190, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh191: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=191, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh192: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=192, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh193: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=193, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh194: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=194, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh195: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=195, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh196: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=196, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh197: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=197, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh198: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=198, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh199: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=199, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh200: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=200, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh201: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=201, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh202: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=202, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh203: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=203, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh204: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=204, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh205: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=205, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh206: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=206, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh207: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=207, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh208: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=208, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh209: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=209, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh210: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=210, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh211: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=211, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh212: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=212, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh213: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=213, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh214: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=214, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh215: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=215, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh216: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=216, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh217: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=217, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh218: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=218, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh219: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=219, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh220: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=220, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh221: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=221, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh222: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=222, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh223: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=223, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh224: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=224, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh225: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=225, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh226: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=226, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh227: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=227, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh228: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=228, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh229: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=229, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh230: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=230, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh231: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=231, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh232: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=232, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh233: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=233, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh235: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=235, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh236: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=236, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh237: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=237, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh238: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=238, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh239: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=239, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh240: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=240, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh241: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=241, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh242: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=242, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh243: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=243, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh244: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=244, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh245: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=245, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh246: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=246, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh247: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=247, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh248: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=248, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh249: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=249, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh250: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=250, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh251: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=251, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh252: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=252, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh253: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=253, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh254: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=254, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh255: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=255, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh256: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=256, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh54: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=54, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: e7e6df8b0fa5135d
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      290/290 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    47s ago        never        0       no error   
  ct-map-pressure                                                     18s ago        never        0       no error   
  daemon-validate-config                                              29s ago        never        0       no error   
  dns-garbage-collector-job                                           50s ago        never        0       no error   
  endpoint-1380-regeneration-recovery                                 never          never        0       no error   
  endpoint-1505-regeneration-recovery                                 never          never        0       no error   
  endpoint-2399-regeneration-recovery                                 never          never        0       no error   
  endpoint-503-regeneration-recovery                                  never          never        0       no error   
  endpoint-978-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m50s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                18s ago        never        0       no error   
  ipcache-inject-labels                                               48s ago        never        0       no error   
  k8s-heartbeat                                                       21s ago        never        0       no error   
  link-cache                                                          3s ago         never        0       no error   
  local-identity-checkpoint                                           19m48s ago     never        0       no error   
  node-neighbor-link-updater                                          8s ago         never        0       no error   
  remote-etcd-cmesh1                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh10                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh100                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh101                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh102                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh103                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh104                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh105                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh106                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh107                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh108                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh109                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh11                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh110                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh111                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh112                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh113                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh114                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh115                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh116                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh117                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh118                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh119                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh12                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh120                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh121                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh122                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh123                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh124                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh125                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh126                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh127                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh128                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh129                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh13                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh130                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh131                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh132                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh133                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh134                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh135                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh136                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh137                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh138                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh139                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh14                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh140                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh141                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh142                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh143                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh144                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh145                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh146                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh147                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh148                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh149                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh15                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh150                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh151                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh152                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh153                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh154                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh155                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh156                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh157                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh158                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh159                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh16                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh160                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh161                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh162                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh163                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh164                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh165                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh166                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh167                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh168                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh169                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh17                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh170                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh171                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh172                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh173                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh174                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh175                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh176                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh177                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh178                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh179                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh18                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh180                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh181                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh182                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh183                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh184                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh185                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh186                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh187                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh188                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh189                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh19                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh190                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh191                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh192                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh193                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh194                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh195                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh196                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh197                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh198                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh199                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh2                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh20                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh200                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh201                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh202                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh203                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh204                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh205                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh206                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh207                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh208                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh209                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh21                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh210                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh211                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh212                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh213                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh214                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh215                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh216                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh217                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh218                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh219                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh22                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh220                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh221                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh222                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh223                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh224                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh225                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh226                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh227                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh228                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh229                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh23                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh230                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh231                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh232                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh233                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh235                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh236                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh237                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh238                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh239                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh24                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh240                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh241                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh242                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh243                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh244                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh245                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh246                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh247                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh248                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh249                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh25                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh250                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh251                                                12m11s ago     never        0       no error   
  remote-etcd-cmesh252                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh253                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh254                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh255                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh256                                                12m10s ago     never        0       no error   
  remote-etcd-cmesh26                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh27                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh28                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh29                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh3                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh30                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh31                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh32                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh33                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh34                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh35                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh36                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh37                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh38                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh39                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh4                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh40                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh41                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh42                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh43                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh44                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh45                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh46                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh47                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh48                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh49                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh5                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh50                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh51                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh52                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh53                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh54                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh55                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh56                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh57                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh58                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh59                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh6                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh60                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh61                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh62                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh63                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh64                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh65                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh66                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh67                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh68                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh69                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh7                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh70                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh71                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh72                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh73                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh74                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh75                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh76                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh77                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh78                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh79                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh8                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh80                                                 12m11s ago     never        0       no error   
  remote-etcd-cmesh81                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh82                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh83                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh84                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh85                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh86                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh87                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh88                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh89                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh9                                                  12m10s ago     never        0       no error   
  remote-etcd-cmesh90                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh91                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh92                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh93                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh94                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh95                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh96                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh97                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh98                                                 12m10s ago     never        0       no error   
  remote-etcd-cmesh99                                                 12m10s ago     never        0       no error   
  resolve-identity-1380                                               4m47s ago      never        0       no error   
  resolve-identity-1505                                               4m46s ago      never        0       no error   
  resolve-identity-2399                                               2m24s ago      never        0       no error   
  resolve-identity-503                                                4m46s ago      never        0       no error   
  resolve-identity-978                                                4m48s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-645c88bd8b-q2rqj   12m24s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-8mfzn                  19m46s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-jhbzw                  19m46s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      19m48s ago     never        0       no error   
  sync-policymap-1380                                                 4m43s ago      never        0       no error   
  sync-policymap-1505                                                 4m43s ago      never        0       no error   
  sync-policymap-2399                                                 12m24s ago     never        0       no error   
  sync-policymap-503                                                  4m43s ago      never        0       no error   
  sync-policymap-978                                                  4m47s ago      never        0       no error   
  sync-to-k8s-ciliumendpoint (1505)                                   5s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (2399)                                   4s ago         never        0       no error   
  sync-to-k8s-ciliumendpoint (503)                                    5s ago         never        0       no error   
  sync-utime                                                          48s ago        never        0       no error   
  write-cni-file                                                      19m50s ago     never        0       no error   
Proxy Status:            OK, ip 10.233.0.205, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 7667712, max 7700479
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 175.06   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium encryption



#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.161.90:443 (active)    
                                         2 => 172.31.246.245:443 (active)   
2    10.100.149.148:443   ClusterIP      1 => 172.31.202.43:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.233.0.144:53 (active)      
                                         2 => 10.233.0.221:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.233.0.144:9153 (active)    
                                         2 => 10.233.0.221:9153 (active)    
5    10.100.27.183:2379   ClusterIP      1 => 10.233.0.178:2379 (active)    
```
