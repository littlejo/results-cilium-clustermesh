{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.205:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.427Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.202.43:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.427Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.252.143:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:40.427Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.949Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:44.958Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.021Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.119Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.179Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:37.290Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:37.290Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:37.290Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:37.322Z",
  "value": "id=186   sec_id=7677376 flags=0x0000 ifindex=16  mac=96:0C:0A:35:A4:A8 nodemac=36:D5:A5:A7:47:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:38.290Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:38.290Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:38.290Z",
  "value": "id=186   sec_id=7677376 flags=0x0000 ifindex=16  mac=96:0C:0A:35:A4:A8 nodemac=36:D5:A5:A7:47:9E"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:38.291Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:04.751Z",
  "value": "id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.233.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.124Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.860Z",
  "value": "id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.862Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.862Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:17.862Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.850Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.851Z",
  "value": "id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.852Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:18.852Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.851Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.852Z",
  "value": "id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.853Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:19.853Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.53:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.852Z",
  "value": "id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.178:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.852Z",
  "value": "id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.144:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.853Z",
  "value": "id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.233.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:20.853Z",
  "value": "id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6"
}

