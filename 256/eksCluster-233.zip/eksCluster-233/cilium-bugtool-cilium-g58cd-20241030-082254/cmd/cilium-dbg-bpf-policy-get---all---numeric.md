Endpoint ID: 503
Path: /sys/fs/bpf/tc/globals/cilium_policy_00503

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112510   1290      0        
Allow    Egress      0          ANY          NONE         disabled    15944    172       0        


Endpoint ID: 978
Path: /sys/fs/bpf/tc/globals/cilium_policy_00978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1380
Path: /sys/fs/bpf/tc/globals/cilium_policy_01380

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1665720   21076     0        
Allow    Ingress     1          ANY          NONE         disabled    17794     211       0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 1505
Path: /sys/fs/bpf/tc/globals/cilium_policy_01505

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0        0         0        
Allow    Ingress     1          ANY          NONE         disabled    112642   1292      0        
Allow    Egress      0          ANY          NONE         disabled    16493    178       0        


Endpoint ID: 2399
Path: /sys/fs/bpf/tc/globals/cilium_policy_02399

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    11581582   115360    0        
Allow    Ingress     1          ANY          NONE         disabled    10421895   109944    0        
Allow    Egress      0          ANY          NONE         disabled    12819535   126415    0        


