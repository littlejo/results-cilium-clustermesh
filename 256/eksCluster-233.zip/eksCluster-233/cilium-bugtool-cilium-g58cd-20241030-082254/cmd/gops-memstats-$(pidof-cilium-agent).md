alloc: 145.59MB (152660464 bytes)
total-alloc: 2.26GB (2427111896 bytes)
sys: 316.77MB (332157284 bytes)
lookups: 0
mallocs: 63727042
frees: 62176301
heap-alloc: 145.59MB (152660464 bytes)
heap-sys: 239.60MB (251240448 bytes)
heap-idle: 64.00MB (67108864 bytes)
heap-in-use: 175.60MB (184131584 bytes)
heap-released: 1.40MB (1466368 bytes)
heap-objects: 1550741
stack-in-use: 64.38MB (67502080 bytes)
stack-sys: 64.38MB (67502080 bytes)
stack-mspan-inuse: 2.97MB (3116160 bytes)
stack-mspan-sys: 3.78MB (3965760 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1.04MB (1086665 bytes)
gc-sys: 6.01MB (6303208 bytes)
next-gc: when heap-alloc >= 217.45MB (228014200 bytes)
last-gc: 2024-10-30 08:23:01.677649364 +0000 UTC
gc-pause-total: 11.646355ms
gc-pause: 102730
gc-pause-end: 1730276581677649364
num-gc: 80
num-forced-gc: 0
gc-cpu-fraction: 0.0005343206727851748
enable-gc: true
debug-gc: false
