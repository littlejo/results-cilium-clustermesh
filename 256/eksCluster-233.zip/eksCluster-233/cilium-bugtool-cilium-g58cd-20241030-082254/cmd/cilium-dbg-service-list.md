ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.161.90:443 (active)    
                                         2 => 172.31.246.245:443 (active)   
2    10.100.149.148:443   ClusterIP      1 => 172.31.202.43:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.233.0.144:53 (active)      
                                         2 => 10.233.0.221:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.233.0.144:9153 (active)    
                                         2 => 10.233.0.221:9153 (active)    
5    10.100.27.183:2379   ClusterIP      1 => 10.233.0.178:2379 (active)    
