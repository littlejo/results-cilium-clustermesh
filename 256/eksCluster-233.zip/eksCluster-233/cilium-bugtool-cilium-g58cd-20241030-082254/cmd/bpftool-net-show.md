xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 573
ens6(5) clsact/ingress cil_from_netdev-ens6 id 580
cilium_net(6) clsact/ingress cil_to_host-cilium_net id 564
cilium_host(7) clsact/ingress cil_to_host-cilium_host id 556
cilium_host(7) clsact/egress cil_from_host-cilium_host id 561
cilium_vxlan(8) clsact/ingress cil_from_overlay-cilium_vxlan id 483
cilium_vxlan(8) clsact/egress cil_to_overlay-cilium_vxlan id 484
lxc_health(10) clsact/ingress cil_from_container-lxc_health id 524
lxc72d77f765d2c(12) clsact/ingress cil_from_container-lxc72d77f765d2c id 509
lxc8dc79c0ad5c8(14) clsact/ingress cil_from_container-lxc8dc79c0ad5c8 id 546
lxc9956b0e3ae05(18) clsact/ingress cil_from_container-lxc9956b0e3ae05 id 631

flow_dissector:

netfilter:

