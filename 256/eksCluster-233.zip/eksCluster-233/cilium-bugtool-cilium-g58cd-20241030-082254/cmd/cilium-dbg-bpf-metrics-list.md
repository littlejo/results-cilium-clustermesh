REASON                    DIRECTION   PACKETS   BYTES       LINE   FILE
Interface                 INGRESS     36883     2917393     677    bpf_overlay.c
Interface                 INGRESS     644737    131967085   1132   bpf_host.c
Success                   EGRESS      16533     1301705     1694   bpf_host.c
Success                   EGRESS      272266    34127791    1308   bpf_lxc.c
Success                   EGRESS      37214     2941386     53     encap.h
Success                   INGRESS     317726    35707092    86     l3.h
Success                   INGRESS     338727    37366826    235    trace.h
Unsupported L3 protocol   EGRESS      38        2812        1492   bpf_lxc.c
