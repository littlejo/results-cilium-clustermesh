[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-766f25831d291920d4ad66b486ac2b59fdf3b63b8817037ab50879403cf8c8ce.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-5878e1884145fe17ef53e1f257f9f8bacc70f4b6be3bf19d326ad596a7bad7d4.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-26a18781ded1a2fc2df1a8687384f09d85a9106fd69cfae9b7df7bed4e0a240a.scope"
      }
    ],
    "ips": [
      "10.233.0.178"
    ],
    "name": "clustermesh-apiserver-645c88bd8b-q2rqj",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0ed2ee1_9fc4_4521_9e86_a60d8be3103b.slice/cri-containerd-88017d4ce1fab875163d813f196af30a5dd71ea923bc21ae85342a0d8cb86133.scope"
      }
    ],
    "ips": [
      "10.233.0.221"
    ],
    "name": "coredns-cc6ccd49c-jhbzw",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75c344c0_522c_4666_a774_ddf5523a6fc4.slice/cri-containerd-6ebb32a88191aae03e0c6b17fa94caaac012ccf62e3a9d6bc551244ce9de2d3a.scope"
      }
    ],
    "ips": [
      "10.233.0.144"
    ],
    "name": "coredns-cc6ccd49c-8mfzn",
    "namespace": "kube-system"
  }
]

