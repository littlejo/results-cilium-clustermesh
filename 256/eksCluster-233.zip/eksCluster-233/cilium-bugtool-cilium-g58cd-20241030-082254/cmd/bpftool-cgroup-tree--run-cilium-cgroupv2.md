CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0ed2ee1_9fc4_4521_9e86_a60d8be3103b.slice/cri-containerd-88017d4ce1fab875163d813f196af30a5dd71ea923bc21ae85342a0d8cb86133.scope
    551      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc0ed2ee1_9fc4_4521_9e86_a60d8be3103b.slice/cri-containerd-ff0f6e2fc9f40b706d9eaee490f22e058f76a59b67189972b540f358bc5c6f63.scope
    532      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75c344c0_522c_4666_a774_ddf5523a6fc4.slice/cri-containerd-f638a90336801b55b5b3d56f8ae26210b938934bcb13213fc7564d9d08605d60.scope
    528      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod75c344c0_522c_4666_a774_ddf5523a6fc4.slice/cri-containerd-6ebb32a88191aae03e0c6b17fa94caaac012ccf62e3a9d6bc551244ce9de2d3a.scope
    555      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbee20829_f810_4b01_bc7e_bd3cc2de154b.slice/cri-containerd-a7f149e31d031b26c425c04771da1b10e5490cfb7d48346488d451114443bd44.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbee20829_f810_4b01_bc7e_bd3cc2de154b.slice/cri-containerd-e71ca2cfbc172430237e56195cf9119ba8a28a42f859e54af1e1f80d351b6c71.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod058e98aa_a164_49cd_bba2_f3d40e88521c.slice/cri-containerd-655dd0b98d4bbb8b433c067c1f5a135924819a6d896636389c7fc212709b960b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod058e98aa_a164_49cd_bba2_f3d40e88521c.slice/cri-containerd-f6c3eee6181b1d3e80297abd5d34e34623e09e9fdd219a7ac17b326725e0808e.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbf9640a_aeab_4d66_8406_a7bdba252055.slice/cri-containerd-56432045d57c34d93c09a617dfaac0e5dcaba59e16e8daf3ce63110d3ee829cd.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcbf9640a_aeab_4d66_8406_a7bdba252055.slice/cri-containerd-abc5372939da5d4948141b6cada9812db4295331b6224165bd98c9ce563171b6.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda76a4e56_7001_4d30_b01b_f4d830871d3a.slice/cri-containerd-30976715524f327722886d9d77eb37f41e05f6827cc37cce4a1654cb275cae2c.scope
    102      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda76a4e56_7001_4d30_b01b_f4d830871d3a.slice/cri-containerd-b8f2de856afc192ff569d45fa5da639bbdd91ffb31cd2c01f6c85e5827956e26.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-5878e1884145fe17ef53e1f257f9f8bacc70f4b6be3bf19d326ad596a7bad7d4.scope
    653      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-26a18781ded1a2fc2df1a8687384f09d85a9106fd69cfae9b7df7bed4e0a240a.scope
    661      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-7b4ae428fe155115198882c50b3923244040df10073a8ec430eed76ca21020d9.scope
    637      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod56c43a0b_f8eb_4c7a_af7d_72d4067edb1e.slice/cri-containerd-766f25831d291920d4ad66b486ac2b59fdf3b63b8817037ab50879403cf8c8ce.scope
    657      cgroup_device   multi                                          
