IP ADDRESS         LOCAL ENDPOINT INFO
172.31.252.143:0   (localhost)                                                                                        
10.233.0.205:0     (localhost)                                                                                        
10.233.0.53:0      id=1380  sec_id=4     flags=0x0000 ifindex=10  mac=FA:C1:33:00:63:9F nodemac=3E:6F:FD:5D:F1:98     
10.233.0.144:0     id=503   sec_id=7690038 flags=0x0000 ifindex=14  mac=E6:41:16:23:DA:F7 nodemac=86:FD:D3:AB:DD:DE   
10.233.0.178:0     id=2399  sec_id=7677376 flags=0x0000 ifindex=18  mac=5A:72:06:2F:46:31 nodemac=1A:20:BD:10:1B:00   
172.31.202.43:0    (localhost)                                                                                        
10.233.0.221:0     id=1505  sec_id=7690038 flags=0x0000 ifindex=12  mac=5A:B3:A8:6B:C8:2F nodemac=DE:7C:A8:32:B0:A6   
