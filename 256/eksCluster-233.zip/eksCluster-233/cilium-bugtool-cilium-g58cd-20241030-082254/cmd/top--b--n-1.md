top - 08:22:56 up 28 min,  0 users,  load average: 0.66, 0.30, 0.16
Tasks:  10 total,   1 running,   9 sleeping,   0 stopped,   0 zombie
%Cpu(s): 63.3 us, 30.0 sy,  0.0 ni,  6.7 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7814.2 total,   4493.4 free,   1174.5 used,   2146.3 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   6454.8 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
      1 root      20   0 1606080 383972  79288 S 100.0   4.8   0:48.91 cilium-+
    666 root      20   0 1240432  16704  11484 S  13.3   0.2   0:00.04 cilium-+
    393 root      20   0 1229744   8032   3836 S   0.0   0.1   0:01.14 cilium-+
    621 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    623 root      20   0 1229000   4056   3392 S   0.0   0.1   0:00.00 gops
    637 root      20   0 1228744   3780   3104 S   0.0   0.0   0:00.00 gops
    653 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    698 root      20   0    6576   2428   2104 R   0.0   0.0   0:00.00 top
    716 root      20   0 1228744   3600   2912 S   0.0   0.0   0:00.00 gops
    722 root      20   0 1615752   8748   6468 S   0.0   0.1   0:00.00 runc:[2+
