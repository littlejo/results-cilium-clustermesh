key: f7 01 00 00  value: 1a 02 00 00
key: 64 05 00 00  value: 0b 02 00 00
key: e1 05 00 00  value: 01 02 00 00
key: 5f 09 00 00  value: 76 02 00 00
Found 4 elements
