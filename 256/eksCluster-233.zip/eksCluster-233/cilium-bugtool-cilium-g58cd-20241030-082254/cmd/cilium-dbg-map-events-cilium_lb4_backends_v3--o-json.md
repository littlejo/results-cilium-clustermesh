{
  "action": "update",
  "desired-action": "sync",
  "key": "1",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.074Z",
  "value": "ANY://172.31.161.90"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "2",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:38.074Z",
  "value": "ANY://172.31.246.245"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "3",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:42.038Z",
  "value": "ANY://172.31.202.43"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "4",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.736Z",
  "value": "ANY://10.233.0.144"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "5",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.736Z",
  "value": "ANY://10.233.0.144"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "6",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.756Z",
  "value": "ANY://10.233.0.221"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "7",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:03:45.756Z",
  "value": "ANY://10.233.0.221"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:06:46.069Z",
  "value": "ANY://10.233.0.242"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "9",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.677Z",
  "value": "ANY://10.233.0.178"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:14.872Z",
  "value": "ANY://10.233.0.242"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "8",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-30T08:11:15.234Z",
  "value": "\u003cnil\u003e"
}

