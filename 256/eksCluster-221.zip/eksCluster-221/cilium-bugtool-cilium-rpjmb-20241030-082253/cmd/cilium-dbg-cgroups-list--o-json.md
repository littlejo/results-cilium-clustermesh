[
  {
    "containers": [
      {
        "cgroup-id": 9258,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-727f46de6ac26b00a19c1f9be0898871c990efc99aedb1a886d356fe17a9e6e0.scope"
      },
      {
        "cgroup-id": 9174,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-65bfec95792e2634646f116d2b6a4b65f060f98a6ac23b3fefd3474e2ccab1b3.scope"
      },
      {
        "cgroup-id": 9342,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8422a666_ddb0_4040_8a74_354799e6d17b.slice/cri-containerd-25cb427c333a222dcf69f8e826a39a1d39ac7b1010b5fb3da303badb39cedf36.scope"
      }
    ],
    "ips": [
      "10.221.0.96"
    ],
    "name": "clustermesh-apiserver-669b4d7f96-8w22b",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7698,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcd0e352b_4076_45d3_b6cf_8347883ff52a.slice/cri-containerd-b76e61c3e0ef2440f66e7664c9f629cf83ff08c857e2784acad13b5645608e17.scope"
      }
    ],
    "ips": [
      "10.221.0.33"
    ],
    "name": "coredns-cc6ccd49c-n8jkc",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7782,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod660585ca_5e9f_4ab9_825d_9a043f3b086f.slice/cri-containerd-bd74ecfaf1373fa571af7eaeb0ce91d8ee0d61dda03483abd0122017cfc4c0e5.scope"
      }
    ],
    "ips": [
      "10.221.0.134"
    ],
    "name": "coredns-cc6ccd49c-2thcm",
    "namespace": "kube-system"
  }
]

