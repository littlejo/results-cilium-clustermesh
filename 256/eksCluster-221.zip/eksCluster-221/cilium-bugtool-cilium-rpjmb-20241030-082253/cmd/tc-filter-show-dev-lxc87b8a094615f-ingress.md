filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc87b8a094615f direct-action not_in_hw id 515 tag 993a7f5c3da11cba jited 
