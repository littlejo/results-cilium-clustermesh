key: 07 00 00 00  value: 0a dd 00 86 23 c1 00 00  00 00 00 00
key: 05 00 00 00  value: 0a dd 00 21 23 c1 00 00  00 00 00 00
key: 03 00 00 00  value: ac 1f d4 1b 10 94 00 00  00 00 00 00
key: 04 00 00 00  value: 0a dd 00 21 00 35 00 00  00 00 00 00
key: 09 00 00 00  value: 0a dd 00 60 09 4b 00 00  00 00 00 00
key: 06 00 00 00  value: 0a dd 00 86 00 35 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f 80 c2 01 bb 00 00  00 00 00 00
key: 02 00 00 00  value: ac 1f ce 42 01 bb 00 00  00 00 00 00
Found 8 elements
