ID   Frontend             Service Type   Backend                            
1    10.100.0.1:443       ClusterIP      1 => 172.31.128.194:443 (active)   
                                         2 => 172.31.206.66:443 (active)    
2    10.100.137.108:443   ClusterIP      1 => 172.31.212.27:4244 (active)   
3    10.100.0.10:53       ClusterIP      1 => 10.221.0.33:53 (active)       
                                         2 => 10.221.0.134:53 (active)      
4    10.100.0.10:9153     ClusterIP      1 => 10.221.0.33:9153 (active)     
                                         2 => 10.221.0.134:9153 (active)    
5    10.100.79.199:2379   ClusterIP      1 => 10.221.0.96:2379 (active)     
