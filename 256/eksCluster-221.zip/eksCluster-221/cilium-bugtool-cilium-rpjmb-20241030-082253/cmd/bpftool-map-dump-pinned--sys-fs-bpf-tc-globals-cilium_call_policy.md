key: 04 03 00 00  value: 09 02 00 00
key: 1a 04 00 00  value: 2d 02 00 00
key: e1 04 00 00  value: 80 02 00 00
key: 8c 0d 00 00  value: 3e 02 00 00
Found 4 elements
