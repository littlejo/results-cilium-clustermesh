1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:77:64:a5:a9:43 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.212.27/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 1979sec preferred_lft 1979sec
    inet6 fe80::877:64ff:fea5:a943/64 scope link 
       valid_lft forever preferred_lft forever
5: ens6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:99:e1:ec:59:f1 brd ff:ff:ff:ff:ff:ff
    altname enp0s6
    inet 172.31.213.95/18 brd 172.31.255.255 scope global ens6
       valid_lft forever preferred_lft forever
    inet6 fe80::899:e1ff:feec:59f1/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 32:be:af:84:fa:e0 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::30be:afff:fe84:fae0/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0a:b1:b9:6e:72:3b brd ff:ff:ff:ff:ff:ff
    inet 10.221.0.144/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::8b1:b9ff:fe6e:723b/64 scope link 
       valid_lft forever preferred_lft forever
8: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 02:d8:68:47:22:cd brd ff:ff:ff:ff:ff:ff
    inet6 fe80::d8:68ff:fe47:22cd/64 scope link 
       valid_lft forever preferred_lft forever
10: lxc_health@if9: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 42:4c:54:a1:a2:26 brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::404c:54ff:fea1:a226/64 scope link 
       valid_lft forever preferred_lft forever
12: lxc87b8a094615f@if11: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:b4:95:8d:b7:cf brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::4cb4:95ff:fe8d:b7cf/64 scope link 
       valid_lft forever preferred_lft forever
14: lxc03ee8918a994@if13: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 22:a4:a7:c6:e4:6f brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::20a4:a7ff:fec6:e46f/64 scope link 
       valid_lft forever preferred_lft forever
18: lxc3aae1ea58ebb@if17: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:00:2d:19:9e:62 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::8800:2dff:fe19:9e62/64 scope link 
       valid_lft forever preferred_lft forever
