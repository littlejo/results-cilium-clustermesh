Linux ip-172-31-212-27.eu-west-3.compute.internal 6.1.112-122.189.amzn2023.aarch64 #1 SMP Tue Oct  8 17:01:34 UTC 2024 aarch64 aarch64 aarch64 GNU/Linux
