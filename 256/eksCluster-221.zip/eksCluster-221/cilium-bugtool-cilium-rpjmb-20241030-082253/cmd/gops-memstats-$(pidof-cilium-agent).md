alloc: 180.71MB (189491288 bytes)
total-alloc: 2.18GB (2341804416 bytes)
sys: 324.83MB (340611428 bytes)
lookups: 0
mallocs: 62605747
frees: 60471472
heap-alloc: 180.71MB (189491288 bytes)
heap-sys: 247.32MB (259334144 bytes)
heap-idle: 47.45MB (49758208 bytes)
heap-in-use: 199.87MB (209575936 bytes)
heap-released: 2.38MB (2490368 bytes)
heap-objects: 2134275
stack-in-use: 64.66MB (67796992 bytes)
stack-sys: 64.66MB (67796992 bytes)
stack-mspan-inuse: 3.40MB (3568480 bytes)
stack-mspan-sys: 3.81MB (3998400 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1001.25KB (1025281 bytes)
gc-sys: 6.10MB (6397608 bytes)
next-gc: when heap-alloc >= 219.62MB (230287208 bytes)
last-gc: 2024-10-30 08:22:56.777209537 +0000 UTC
gc-pause-total: 19.525017ms
gc-pause: 479873
gc-pause-end: 1730276576777209537
num-gc: 81
num-forced-gc: 0
gc-cpu-fraction: 0.0006078042296741298
enable-gc: true
debug-gc: false
