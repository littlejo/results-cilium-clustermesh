IP ADDRESS        LOCAL ENDPOINT INFO
10.221.0.134:0    id=1050  sec_id=7274570 flags=0x0000 ifindex=14  mac=3E:85:C5:10:D6:A6 nodemac=22:A4:A7:C6:E4:6F   
10.221.0.33:0     id=772   sec_id=7274570 flags=0x0000 ifindex=12  mac=82:EF:5B:EB:0E:5E nodemac=4E:B4:95:8D:B7:CF   
172.31.212.27:0   (localhost)                                                                                        
10.221.0.107:0    id=3468  sec_id=4     flags=0x0000 ifindex=10  mac=CE:8B:1A:7B:D6:78 nodemac=42:4C:54:A1:A2:26     
10.221.0.96:0     id=1249  sec_id=7282897 flags=0x0000 ifindex=18  mac=2E:2D:2E:14:F6:D9 nodemac=8A:00:2D:19:9E:62   
10.221.0.144:0    (localhost)                                                                                        
172.31.213.95:0   (localhost)                                                                                        
